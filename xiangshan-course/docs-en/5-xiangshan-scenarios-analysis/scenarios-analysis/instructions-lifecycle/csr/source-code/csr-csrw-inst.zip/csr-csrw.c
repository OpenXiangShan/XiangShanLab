#include <am.h>
#include <klib.h>

#define MT_VEC_VAL 0x80001234UL

int main(const char *args) {
    (void)args;
    asm volatile(
        "li    t0, 0x80001234\n"
        "csrw  mtvec, t0\n"
        "csrr  t1, mtvec\n"
        "li    t2, 0x80001234\n"
        "bne   t1,t2,  1f\n"
        "j     2f\n"
        "1:    j 1b\n"
        "2:    j 2b\n"
    );
    return 0;
}
