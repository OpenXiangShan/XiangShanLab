#!/usr/bin/env python3
"""Summarize a secret0/secret7 monitor pair into the final leak verdict.

Leak (secret_dependent_wrong_path_dcache) requires ALL of:
  1. stale ABTB prediction activity under ABTB_ENABLE=0 (bug presence),
  2. the secret-dependent probe line actually touched on the wrong path
     (encoding step executed), and
  3. the pair asymmetry: the touched probe line tracks the secret value,
     i.e. each run touches its own probe line, not the other's.
"""

import argparse
import json
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text())


def touched_probe_lines(mon):
    lines = set()
    for row in mon.get("rows", []):
        if row["kind"] in ("dcache_outer_probe_secret_line", "loadunit_probe_secret_line"):
            for key in ("addr", "vaddr", "paddr"):
                if row.get(key):
                    lines.add(int(row[key], 16) & ~63)
    return lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--secret0", type=Path, required=True)
    ap.add_argument("--secret1", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    m0, m1 = load(args.secret0), load(args.secret1)
    expected0 = int(m0["probe_secret_line"], 16) & ~63
    expected1 = int(m1["probe_secret_line"], 16) & ~63
    t0, t1 = touched_probe_lines(m0), touched_probe_lines(m1)

    stale = (m0["abtb_stale_prediction_under_disable"]
             or m1["abtb_stale_prediction_under_disable"])
    gadget_fetch = (m0["gadget_fetch_under_disable"]
                    or m1["gadget_fetch_under_disable"])
    own_line0 = expected0 in t0
    own_line1 = expected1 in t1
    cross0 = expected1 in t0
    cross1 = expected0 in t1

    verdict = {
        "inputs": {"secret0": str(args.secret0), "secret1": str(args.secret1)},
        "counts_secret0": m0["counts"],
        "counts_secret1": m1["counts"],
        "abtb_stale_prediction_under_disable": stale,
        "stale_abtb_targets_gadget": m0["stale_abtb_targets_gadget"]
                                     or m1["stale_abtb_targets_gadget"],
        "gadget_fetch_under_disable": gadget_fetch,
        "probe_lines_touched_secret0": [hex(x) for x in sorted(t0)],
        "probe_lines_touched_secret1": [hex(x) for x in sorted(t1)],
        "expected_probe_line_secret0": hex(expected0),
        "expected_probe_line_secret1": hex(expected1),
        "own_probe_line_hit_secret0": own_line0,
        "own_probe_line_hit_secret1": own_line1,
        "cross_probe_line_hit": cross0 or cross1,
        "secret_dependent_wrong_path_dcache": bool(
            stale and own_line0 and own_line1 and not (cross0 or cross1)),
    }
    args.out.write_text(json.dumps(verdict, indent=1, sort_keys=True))
    print(json.dumps(verdict, indent=1, sort_keys=True))


if __name__ == "__main__":
    main()
