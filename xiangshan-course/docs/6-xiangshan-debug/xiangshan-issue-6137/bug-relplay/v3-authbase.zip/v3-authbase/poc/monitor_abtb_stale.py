#!/usr/bin/env python3
"""Monitor the #6137 ABTB stale-prediction leak from an FST waveform.

Streams the FST through fst2vcd, samples the BPU/ABTB/icache/dcache/loadunit
signals and records every event that happens while sbpctl.ABTB_ENABLE == 0:

  - disabled_abtb_prediction_fire  bpu->ftq prediction fires with a valid ABTB
  - disabled_abtb_pc_mismatch      ABTB S2 start points at `gadget` while the
                                   BPU S2 start is the fallthrough path
  - gadget_icache_*                icache requests/hits/miss/outer traffic for
                                   the gadget fetch block under disable
  - secret/probe dcache + loadunit wrong-path accesses
    (probe line index == secret byte -> secret-dependent encoding)

Output: JSON with counts / first events / bounded rows + derived verdicts.
"""

import argparse
import json
import re
import subprocess
from collections import Counter
from contextlib import contextmanager
from pathlib import Path

ROW_LIMIT = 200


def parse_int(bits):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, 2)


def hx(value):
    return None if value is None else hex(value)


@contextmanager
def wave_lines(path: Path):
    # emus sometimes write VCD text under a .fst name: detect by magic bytes
    with path.open("rb") as probe:
        magic = probe.read(16)
    is_text_vcd = magic.startswith(b"$date") or magic.startswith(b"$version") \
        or magic.startswith(b"$timescale") or magic.startswith(b"$comment")
    if path.suffix == ".fst" and not is_text_vcd:
        proc = subprocess.Popen(
            ["fst2vcd", str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
        )
        try:
            yield proc.stdout
        finally:
            if proc.stdout is not None:
                proc.stdout.close()
            stderr = proc.stderr.read() if proc.stderr is not None else ""
            rc = proc.wait()
            if rc not in (0, -13):
                raise RuntimeError(f"fst2vcd failed with code {rc}: {stderr}")
    else:
        with path.open("r", errors="replace") as f:
            yield f


def read_symbols(objdump_path: Path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\w+\s+.*\s([A-Za-z_][A-Za-z0-9_]*)$")
    with objdump_path.open("r", errors="replace") as f:
        for raw in f:
            m = sym_re.match(raw.strip())
            if m:
                symbols[m.group(2)] = int(m.group(1), 16)
    required = [
        "_start", "victim_loop", "attack_setup", "branch_site", "fallthrough",
        "done", "gadget", "train_data", "secret_data", "flag_zero", "probe_array",
    ]
    missing = [s for s in required if s not in symbols]
    if missing:
        raise SystemExit(f"objdump {objdump_path} lacks symbols: {missing}")
    return symbols


def parse_header(lines):
    name_to_code = {}
    stack = []
    for raw in lines:
        line = raw.strip()
        if line.startswith("$enddefinitions"):
            break
        if line.startswith("$scope"):
            stack.append(line.split()[2])
        elif line.startswith("$upscope"):
            stack.pop()
        elif line.startswith("$var"):
            parts = line.split()
            code = parts[3]
            name = ".".join(stack + [parts[4]])
            name_to_code[name] = code
    return name_to_code


# ordered candidate suffixes per logical signal; first hit wins.
# tree note: kunminghu-v3 renames interfaces between months (csrCtrl ->
# frontendCsrCtrl, dcache client_out -> buffers, icache mainPipe.io_req ->
# fromFtq_toPrefetch), hence multiple candidates per slot.
CANDIDATES = {
    "abtb_enable": ["inner_bpu.abtb.io_enable",
                    "frontend.io_csrCtrl_bp_ctrl_abtbEnable",
                    "io_frontendCsrCtrl_bp_ctrl_abtbEnable"],
    "pred_ready": ["inner_ftq.io_fromBpu_prediction_ready",
                   "frontend._inner_ftq_io_fromBpu_prediction_ready"],
    "pred_valid": ["inner_bpu.io_toFtq_prediction_valid",
                   "frontend._inner_bpu_io_toFtq_prediction_valid"],
    "pred_start": ["inner_bpu.io_toFtq_prediction_bits_startPc_addr",
                   "frontend._inner_bpu_io_toFtq_prediction_bits_startPc_addr"],
    "pred_target": ["inner_bpu.io_toFtq_prediction_bits_target_addr"],  # optional
    "bpu_s2_valid": ["inner_bpu.s2_valid"],
    "bpu_s2_start": ["inner_bpu.s2_startPc_addr",
                     "inner_bpu.s2_startPc_dup_0_addr"],
    "abtb_s2_valid": ["inner_bpu.abtb.s2_valid"],
    "abtb_s2_start": ["inner_bpu.abtb.s2_startPc_addr"],
    "abtb_debug_start": ["inner_bpu.abtb.io_debug_startPc_addr"],  # optional
    "out_v0": ["inner_bpu.abtb.io_prediction_0_valid"],
    "out_v1": ["inner_bpu.abtb.io_prediction_1_valid"],
    "out_v2": ["inner_bpu.abtb.io_prediction_2_valid"],
    "out_v3": ["inner_bpu.abtb.io_prediction_3_valid"],
    "out_r0": ["inner_bpu.abtb.io_abtbResult_0_valid"],
    "out_meta": ["inner_bpu.abtb.io_meta_valid"],
    "ic_req_ready": ["inner_icache.io_fromFtq_toPrefetch_ready",
                     "inner_icache.mainPipe.io_req_ready"],
    "ic_req_valid": ["inner_icache.io_fromFtq_toPrefetch_valid",
                     "inner_icache.mainPipe.io_req_valid"],
    "ic_req_start": ["inner_icache.io_fromFtq_toPrefetch_bits_req_0_startVAddr_addr",
                     "inner_icache.mainPipe.io_req_bits_startVAddr_addr"],
    "ic_resp_valid": ["inner_icache.mainPipe.io_resp_valid"],  # optional
    "ic_resp_vaddr": ["inner_icache.mainPipe.io_resp_bits_vAddr_0_addr"],  # optional
    "ic_hit0": ["inner_icache.mainPipe.io_perf_rawHits_0"],
    "ic_hit1": ["inner_icache.mainPipe.io_perf_rawHits_1"],
    "ic_miss_valid": ["inner_icache.mainPipe.io_missReq_valid"],
    "ic_miss_blk": ["inner_icache.mainPipe.io_missReq_bits_blkPAddr"],
    "ic_outer_valid": ["frontend.auto_inner_icache_client_out_a_valid"],
    "ic_outer_ready": ["frontend.auto_inner_icache_client_out_a_ready"],
    "ic_outer_addr": ["frontend.auto_inner_icache_client_out_a_bits_address"],
    "dc_outer_valid": ["core.auto_memBlock_inner_buffers_out_a_valid",
                       "core.auto_memBlock_inner_dcache_client_out_a_valid"],
    "dc_outer_ready": ["core.auto_memBlock_inner_buffers_out_a_ready",
                       "core.auto_memBlock_inner_dcache_client_out_a_ready"],
    "dc_outer_addr": ["core.auto_memBlock_inner_buffers_out_a_bits_address",
                      "core.auto_memBlock_inner_dcache_client_out_a_bits_address"],
    "dc_outer_vaddr": ["core.auto_memBlock_inner_buffers_out_a_bits_user_vaddr",
                       "core.auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr"],
    "dc_outer_opcode": ["core.auto_memBlock_inner_buffers_out_a_bits_opcode",
                        "core.auto_memBlock_inner_dcache_client_out_a_bits_opcode"],
    "dc_outer_size": ["core.auto_memBlock_inner_buffers_out_a_bits_size",
                      "core.auto_memBlock_inner_dcache_client_out_a_bits_size"],
}
LOAD_UNITS = 3
REQUIRED = {"abtb_enable", "pred_ready", "pred_valid", "pred_start",
            "bpu_s2_valid", "bpu_s2_start", "abtb_s2_valid", "abtb_s2_start",
            "ic_req_ready", "ic_req_valid", "ic_req_start", "ic_hit0",
            "ic_miss_valid", "ic_miss_blk", "ic_outer_valid", "ic_outer_ready",
            "ic_outer_addr", "dc_outer_valid", "dc_outer_ready", "dc_outer_addr"}


def build_signals(name_to_code):
    sig, missing = {}, []
    for key, suffixes in CANDIDATES.items():
        pick = None
        for sfx in suffixes:
            hits = [n for n in name_to_code if n.endswith(sfx)]
            if hits:
                pick = name_to_code[sorted(hits, key=len)[0]]
                break
        if pick is None:
            missing.append(key)
            if key in REQUIRED:
                raise KeyError(f"missing required VCD signal: {key} ({suffixes[0]})")
        else:
            sig[key] = pick
    for unit in range(LOAD_UNITS):
        prefix = f".core.memBlock._inner_LoadUnit_{unit}_io_lqWrite"
        for field in ("valid", "bits_uop_pc", "bits_vaddr", "bits_paddr"):
            sfx = f"memBlock.inner_LoadUnit_{unit}.io_lqWrite_{field}"
            hits = [n for n in name_to_code if n.endswith(sfx)]
            if not hits:
                sfx2 = f"memBlock._inner_LoadUnit_{unit}_io_lqWrite_{field}"
                hits = [n for n in name_to_code if n.endswith(sfx2)]
            if hits:
                sig[f"lu{unit}_{field.replace('bits_', '')}"] = \
                    name_to_code[sorted(hits, key=len)[0]]
            else:
                missing.append(f"lu{unit}_{field}")
    return sig, missing


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("wave", type=Path)
    ap.add_argument("objdump", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--secret", type=int, required=True)
    ap.add_argument("--line-size", type=int, default=64)
    args = ap.parse_args()

    syms = read_symbols(args.objdump)
    probe_secret_line = syms["probe_array"] + args.secret * 64

    def classes_for_addr(addr):
        if addr is None:
            return ["?"]
        classes = []
        line = line_addr(addr)
        for name in ("gadget", "branch_site", "fallthrough", "victim_loop",
                     "attack_setup", "done", "_start", "train_data",
                     "secret_data", "flag_zero"):
            if addr == syms[name] or line == line_addr(syms[name]):
                classes.append(name)
        if syms["probe_array"] <= addr < syms["probe_array"] + 16384:
            classes.append("probe_secret_line" if line == line_addr(probe_secret_line)
                           else "probe_other_line")
        return classes or [f"0x{addr:x}"]

    def pc_byte_addr(encoded):
        # BPU-internal PCs are halfword-folded (byte addr >> 1)
        return None if encoded is None else encoded << 1

    def line_addr(addr):
        return None if addr is None else (addr // args.line_size) * args.line_size

    counts = Counter()
    first = {}
    rows = []

    def record(kind, row):
        counts[kind] += 1
        row = dict(sorted(row.items()))
        if kind not in first:
            first[kind] = row
        if len(rows) < ROW_LIMIT:
            rows.append({"kind": kind, **row})

    with wave_lines(args.wave) as lines:
        sig, missing = build_signals(parse_header(lines))
        watch = {c for c in sig.values() if c}
        vals = {}

        def evaluate(t):
            cycle = t // 2

            def get(name):
                code = sig.get(name)
                if code is None:
                    return None
                v = vals.get(code)
                return None if v is None else parse_int(v)

            def is_one(name):
                code = sig.get(name)
                return bool(code) and vals.get(code) == "1"

            disabled = get("abtb_enable") == 0
            pred_fire = is_one("pred_valid") and is_one("pred_ready")
            abtb_s2 = pc_byte_addr(get("abtb_s2_start"))
            bpu_s2 = pc_byte_addr(get("bpu_s2_start"))
            ic_fire = is_one("ic_req_valid") and is_one("ic_req_ready")
            ic_start = pc_byte_addr(get("ic_req_start"))

            stale_out = any(is_one(k) for k in
                            ("out_v0", "out_v1", "out_v2", "out_v3",
                             "out_r0", "out_meta"))
            if disabled and stale_out:
                record("disabled_abtb_output_valid", {
                    "t": t, "cycle": cycle,
                    "out_v": "".join("1" if is_one(k) else "0" for k in
                                     ("out_v0", "out_v1", "out_v2", "out_v3")),
                    "res_v0": "1" if is_one("out_r0") else "0",
                    "meta_v": "1" if is_one("out_meta") else "0",
                })
            if disabled and pred_fire and is_one("abtb_s2_valid"):
                ev = {
                    "t": t, "cycle": cycle,
                    "pred_start": hx(pc_byte_addr(get("pred_start"))),
                    "pred_target": hx(pc_byte_addr(get("pred_target"))),
                    "abtb_s2_start": hx(abtb_s2),
                    "bpu_s2_start": hx(bpu_s2),
                }
                record("disabled_abtb_prediction_fire", ev)
                if ic_fire or is_one("ic_resp_valid"):
                    record("disabled_abtb_with_icache_activity", {
                        **ev, "ic_req_fire": ic_fire,
                        "ic_req_start": hx(ic_start),
                        "ic_resp_valid": is_one("ic_resp_valid"),
                    })
            if (disabled and pred_fire and is_one("abtb_s2_valid")
                    and abtb_s2 is not None and bpu_s2 is not None
                    and abtb_s2 != bpu_s2):
                record("disabled_abtb_pc_mismatch", {
                    "t": t, "cycle": cycle,
                    "abtb_s2_start": hx(abtb_s2),
                    "bpu_s2_start": hx(bpu_s2),
                    "ic_req_fire": ic_fire,
                    "ic_req_start": hx(ic_start),
                })
            if (disabled and abtb_s2 is not None and bpu_s2 is not None
                    and abtb_s2 != bpu_s2
                    and "gadget" in classes_for_addr(abtb_s2)
                    and "gadget" not in classes_for_addr(bpu_s2)):
                record("disabled_abtb_pc_mismatch", {
                    "t": t, "cycle": cycle,
                    "abtb_s2_start": hx(abtb_s2),
                    "bpu_s2_start": hx(bpu_s2),
                    "pred_fire": pred_fire,
                    "ic_req_fire": ic_fire,
                    "ic_req_start": hx(ic_start),
                    "ic_hit": is_one("ic_hit0") or is_one("ic_hit1"),
                })

            if disabled and ic_fire and ic_start is not None \
                    and "gadget" in classes_for_addr(ic_start):
                record("gadget_icache_req_under_disable", {
                    "t": t, "cycle": cycle, "ic_req_start": hx(ic_start),
                    "hit": is_one("ic_hit0") or is_one("ic_hit1"),
                })
            if disabled and is_one("ic_resp_valid"):
                rv = pc_byte_addr(get("ic_resp_vaddr"))
                if rv is not None and "gadget" in classes_for_addr(rv):
                    record("gadget_icache_resp_under_disable", {
                        "t": t, "cycle": cycle, "vaddr": hx(rv),
                    })
            if disabled and is_one("ic_miss_valid"):
                blk = get("ic_miss_blk")
                if blk is not None and "gadget" in classes_for_addr(blk << 6):
                    record("gadget_icache_miss_under_disable", {
                        "t": t, "cycle": cycle, "blk": hx(blk << 6),
                    })
            if disabled and is_one("ic_outer_valid") and is_one("ic_outer_ready"):
                oa = get("ic_outer_addr")
                if oa is not None and line_addr(oa) == line_addr(syms["gadget"]):
                    record("gadget_icache_outer_under_disable", {
                        "t": t, "cycle": cycle, "addr": hx(oa),
                    })

            if disabled and is_one("dc_outer_valid") and is_one("dc_outer_ready"):
                line = line_addr(get("dc_outer_addr"))
                cls = classes_for_addr(line)
                if any(k in cls for k in ("secret_data", "flag_zero", "train_data",
                                          "probe_secret_line", "probe_other_line")):
                    kind = ("dcache_outer_probe_secret_line"
                            if "probe_secret_line" in cls
                            else f"dcache_outer_{cls[0]}")
                    record(kind, {
                        "t": t, "cycle": cycle,
                        "addr": hx(get("dc_outer_addr")),
                        "vaddr": hx(get("dc_outer_vaddr")),
                        "opcode": get("dc_outer_opcode"),
                        "size": get("dc_outer_size"),
                    })

            for unit in range(3):
                if disabled and is_one(f"lu{unit}_valid"):
                    pc = get(f"lu{unit}_pc")
                    va = get(f"lu{unit}_vaddr")
                    pa = get(f"lu{unit}_paddr")
                    cls = classes_for_addr(pa) if pa is not None else classes_for_addr(va)
                    if pc is not None and "gadget" in classes_for_addr(pc):
                        record("loadunit_gadget_pc", {
                            "t": t, "cycle": cycle, "vaddr": hx(va),
                            "line_class": cls[:1],
                        })
                    if any(k in cls for k in ("secret_data", "probe_secret_line",
                                              "probe_other_line")):
                        kind = ("loadunit_probe_secret_line"
                                if "probe_secret_line" in cls
                                else "loadunit_secret_data"
                                if "secret_data" in cls
                                else "loadunit_probe_other_line")
                        record(kind, {
                            "t": t, "cycle": cycle, "vaddr": hx(va),
                            "paddr": hx(pa), "pc": hx(pc),
                        })

        t = None
        for raw in lines:
            line = raw.strip()
            if not line:
                continue
            if line[0] == "#":
                new_t = int(line[1:])
                if t is not None and new_t != t:
                    evaluate(t)
                t = new_t
                continue
            c0 = line[0]
            if c0 in "01xzXZ":
                code = line[1:].strip()
                if code in watch:
                    vals[code] = c0
            elif c0 in "bB":
                parts = line.split()
                if len(parts) == 2 and parts[1] in watch:
                    vals[parts[1]] = parts[0][1:]
        if t is not None:
            evaluate(t)

    verdict = {
        "wave": str(args.wave),
        "secret": args.secret,
        "probe_secret_line": hx(probe_secret_line),
        "missing_signals": missing,
        "counts": dict(counts),
        "first": first,
        "rows": rows,
        "abtb_stale_prediction_under_disable": counts["disabled_abtb_prediction_fire"] > 0,
        "abtb_stale_output_under_disable": counts["disabled_abtb_output_valid"] > 0,
        "stale_abtb_targets_gadget": counts["disabled_abtb_pc_mismatch"] > 0,
        "gadget_fetch_under_disable": (counts["disabled_abtb_with_icache_activity"] > 0
                                       or counts["gadget_icache_req_under_disable"] > 0),
        "secret_dependent_probe_line": counts["dcache_outer_probe_secret_line"] > 0
                                       or counts["loadunit_probe_secret_line"] > 0,
    }
    args.out.write_text(json.dumps(verdict, indent=1, sort_keys=True))
    print(json.dumps({k: verdict[k] for k in (
        "secret", "counts", "abtb_stale_prediction_under_disable",
        "stale_abtb_targets_gadget", "gadget_fetch_under_disable",
        "secret_dependent_probe_line")}, indent=1))


if __name__ == "__main__":
    main()
