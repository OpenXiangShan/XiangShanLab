#!/usr/bin/env python3
"""Cycle-by-cycle S1-source-path trace for #6137 around the leak window.

Dumps a compact table of the ABTB disable plane, ABTB pipeline/output state,
BPU S1 consumers and fetch/data effects, so the stale-prediction chain can be
read directly off one page.  Signals resolve by ordered candidate suffixes.
"""

import argparse
import json
import re
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path


def parse_int(bits):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, 2)


def hx(v):
    if v is None:
        return "."
    return hex(v)


@contextmanager
def wave_lines(path: Path):
    with path.open("rb") as probe:
        magic = probe.read(16)
    is_text = magic.startswith(b"$date") or magic.startswith(b"$version") \
        or magic.startswith(b"$timescale") or magic.startswith(b"$comment")
    if path.suffix == ".fst" and not is_text:
        proc = subprocess.Popen(["fst2vcd", str(path)], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True,
                                errors="replace")
        try:
            yield proc.stdout
        finally:
            proc.stdout.close()
            proc.wait()
    else:
        with path.open("r", errors="replace") as f:
            yield f


def parse_header(lines):
    name_to_code = {}
    stack = []
    for raw in lines:
        line = raw.strip()
        if line.startswith("$enddefinitions"):
            break
        if line.startswith("$scope"):
            stack.append(line.split()[2])
        elif line.startswith("$upscope"):
            stack.pop()
        elif line.startswith("$var"):
            p = line.split()
            name_to_code[".".join(stack + [p[4]])] = p[3]
    return name_to_code


CANDIDATES = {
    "abtb_en":        ["inner_bpu.abtb.io_enable"],
    "s0_fire":        ["inner_bpu.abtb_io_stageCtrl_s0_fire",
                       "inner_bpu.abtb.s0_fire"],
    "s1_fire":        ["inner_bpu.abtb_io_stageCtrl_s1_fire",
                       "inner_bpu.abtb.s1_fire"],
    "s2_fire":        ["inner_bpu.abtb_io_stageCtrl_s2_fire",
                       "inner_bpu.abtb.s2_fire"],
    "abtb_s2_valid":  ["inner_bpu.abtb.s2_valid"],
    "abtb_s2_start":  ["inner_bpu.abtb.s2_startPc_addr"],
    "abtb_dbg_start": ["inner_bpu.abtb.io_debug_startPc_addr"],
    "pred0_valid":    ["inner_bpu.abtb.io_prediction_0_valid"],
    "pred1_valid":    ["inner_bpu.abtb.io_prediction_1_valid"],
    "pred0_target":   ["inner_bpu.abtb.io_prediction_0_bits_target_addr"],
    "abtbres0_valid": ["inner_bpu.abtb.io_abtbResult_0_valid"],
    "meta_valid":     ["inner_bpu.abtb.io_meta_valid"],
    "jump0":          ["inner_bpu.abtb.io_predCtrl_jumpValidVec_0"],
    "jump1":          ["inner_bpu.abtb.io_predCtrl_jumpValidVec_1"],
    "cond0":          ["inner_bpu.abtb.io_predCtrl_conditionValidVec_0"],
    "takenmask0":     ["inner_bpu.s1_abtbTakenMask_0"],
    "takenmask1":     ["inner_bpu.s1_abtbTakenMask_1"],
    "ftoh0_0":        ["inner_bpu.s1_abtbFirstTakenBrOH_0"],
    "ftoh0_1":        ["inner_bpu.s1_abtbFirstTakenBrOH_1"],
    "abtbres_target": ["inner_bpu.s1_abtbResult_target_addr"],
    "pred_valid":     ["inner_bpu.io_toFtq_prediction_valid"],
    "pred_ready":     ["inner_ftq.io_fromBpu_prediction_ready"],
    "pred_start":     ["inner_bpu.io_toFtq_prediction_bits_startPc_addr"],
    "pred_taken":     ["inner_bpu.io_toFtq_prediction_bits_taken"],
    "bpu_s2_valid":   ["inner_bpu.s2_valid"],
    "bpu_s2_start":   ["inner_bpu.s2_startPc_addr",
                       "inner_bpu.s2_startPc_dup_0_addr"],
    "ic_fire":        None,  # composed below
    "ic_req_valid":   ["inner_icache.io_fromFtq_toPrefetch_valid",
                       "inner_icache.mainPipe.io_req_valid"],
    "ic_req_ready":   ["inner_icache.io_fromFtq_toPrefetch_ready",
                       "inner_icache.mainPipe.io_req_ready"],
    "ic_req_start":   ["inner_icache.io_fromFtq_toPrefetch_bits_req_0_startVAddr_addr",
                       "inner_icache.mainPipe.io_req_bits_startVAddr_addr"],
    "dc_fire":        None,
    "dc_valid":       ["core.auto_memBlock_inner_buffers_out_a_valid",
                       "core.auto_memBlock_inner_dcache_client_out_a_valid"],
    "dc_ready":       ["core.auto_memBlock_inner_buffers_out_a_ready",
                       "core.auto_memBlock_inner_dcache_client_out_a_ready"],
    "dc_addr":        ["core.auto_memBlock_inner_buffers_out_a_bits_address",
                       "core.auto_memBlock_inner_dcache_client_out_a_bits_address"],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("wave", type=Path)
    ap.add_argument("--from-cycle", type=int, required=True)
    ap.add_argument("--to-cycle", type=int, required=True)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    with wave_lines(args.wave) as lines:
        n2c = parse_header(lines)
        sig, missing = {}, []
        for key, cands in CANDIDATES.items():
            if not cands:
                continue
            pick = None
            for sfx in cands:
                hits = [n for n in n2c if n.endswith(sfx)]
                if hits:
                    pick = n2c[sorted(hits, key=len)[0]]
                    break
            if pick:
                sig[key] = pick
            else:
                missing.append(key)
        watch = set(sig.values())
        vals = {}
        rows = []

        def sample(t):
            def get(k):
                c = sig.get(k)
                if c is None:
                    return None
                v = vals.get(c)
                return None if v is None else parse_int(v)

            def one(k):
                c = sig.get(k)
                return "1" if (c and vals.get(c) == "1") else "0"

            row = {
                "cycle": t // 2,
                "en": one("abtb_en"),
                "fire_s012": one("s0_fire") + one("s1_fire") + one("s2_fire"),
                "abtbS2v": one("abtb_s2_valid"),
                "abtbS2pc": hx(get("abtb_s2_start")),
                "abtbDbg": hx(get("abtb_dbg_start")),
                "predV_0": one("pred0_valid") + one("pred1_valid"),
                "predT0": hx(get("pred0_target")),
                "resV0": one("abtbres0_valid"),
                "metaV": one("meta_valid"),
                "jmp01": one("jump0") + one("jump1"),
                "cond0": one("cond0"),
                "mask01": one("takenmask0") + one("takenmask1"),
                "ftoh01": one("ftoh0_0") + one("ftoh0_1"),
                "resTgt": hx(get("abtbres_target")),
                "bpuV": one("pred_valid") + one("pred_ready"),
                "bpuPc": hx(get("pred_start")),
                "bpuTkn": one("pred_taken"),
                "s2v": one("bpu_s2_valid"),
                "s2pc": hx(get("bpu_s2_start")),
                "icFr": one("ic_req_valid") + one("ic_req_ready"),
                "icPc": hx(get("ic_req_start")),
                "dcFr": one("dc_valid") + one("dc_ready"),
                "dcAddr": hx(get("dc_addr")),
            }
            rows.append(row)

        t = None
        for raw in lines:
            line = raw.strip()
            if not line:
                continue
            if line[0] == "#":
                new_t = int(line[1:])
                if t is not None and new_t != t:
                    if args.from_cycle * 2 <= t <= args.to_cycle * 2:
                        sample(t)
                t = new_t
                continue
            if line[0] in "01xzXZ":
                code = line[1:].strip()
                if code in watch:
                    vals[code] = line[0]
            elif line[0] in "bB":
                p = line.split()
                if len(p) == 2 and p[1] in watch:
                    vals[p[1]] = p[0][1:]

    cols = ["cycle", "en", "fire_s012", "abtbS2v", "abtbS2pc", "abtbDbg",
            "predV_0", "predT0", "resV0", "metaV", "jmp01", "cond0",
            "mask01", "ftoh01", "resTgt", "bpuV", "bpuPc", "bpuTkn",
            "s2v", "s2pc", "icFr", "icPc", "dcFr", "dcAddr"]
    # dedupe consecutive identical rows (keep changes)
    dedup, prev = [], None
    for r in rows:
        key = tuple(r[c] for c in cols[1:])
        if key != prev:
            dedup.append(r)
            prev = key
    out_lines = ["\t".join(cols)]
    for r in dedup:
        out_lines.append("\t".join(str(r[c]) for c in cols))
    table = "\n".join(out_lines) + "\n"
    if missing:
        table = f"# missing: {missing}\n" + table
    print(table)
    if args.out:
        Path(args.out).write_text(table)


if __name__ == "__main__":
    main()
