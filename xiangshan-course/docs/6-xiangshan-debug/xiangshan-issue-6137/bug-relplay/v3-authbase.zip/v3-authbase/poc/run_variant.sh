#!/usr/bin/env bash
# Replay the #6137 PoC pair (secret 0/7) on one emu variant.
# Usage: run_variant.sh <emu-binary> <tag> [window_begin] [window_end] [cycles] [secrets...]
set -euo pipefail
cd "$(dirname "$0")"

export PATH="/nfs/home/zhaoxufan/project/debug/tools/fst/bin:$PATH"

EMU="${1:?emu path}"
TAG="${2:?variant tag}"
WB="${3:-9200}"
WE="${4:-10400}"
CYCLES="${5:-12000}"
shift 5 || true
SECRETS=("$@")
# 5/7: both probe lines stay cold (probe[0] is warmed during training)
[ ${#SECRETS[@]} -eq 0 ] && SECRETS=(7 5)

mkdir -p results waves

for S in "${SECRETS[@]}"; do
  W="${TAG}_secret${S}_${WB}_${WE}"
  echo "=== ${TAG} secret ${S}: run ==="
  "$EMU" -C "$CYCLES" -b "$WB" -e "$WE" -i "poc/poc_abtb_secret${S}.bin" \
    --no-diff --dump-wave-full --wave-path="waves/${W}.fst" \
    --force-dump-result > "results/${W}.run.log" 2>&1 || true
  for _ in $(seq 1 60); do [ -s "waves/${W}.fst" ] && break; sleep 1; done
  echo "=== ${TAG} secret ${S}: monitor ==="
  python3 monitor_abtb_stale.py "waves/${W}.fst" \
    "poc/poc_abtb_secret${S}.objdump" "results/${W}.monitor.json" \
    --secret "$S" > "results/${W}.monitor.log" || true
  tail -4 "results/${W}.monitor.log" || true
  grep -E "Assertion|ABORT|HIT GOOD TRAP|guest cycle" "results/${W}.run.log" | head -3 || true
done
