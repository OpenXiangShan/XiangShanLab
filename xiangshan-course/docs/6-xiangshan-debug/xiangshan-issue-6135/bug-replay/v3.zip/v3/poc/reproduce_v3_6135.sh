#!/usr/bin/env bash
# Reproduce the #6135 full side-channel pair on the kunminghu-v3 baseline emu
# (e85a929a3, EMU_TRACE=vcd build). Mirrors the issue author's
# run_sidechannel_poc.sh with local toolchain/emu paths; parameters kept
# identical to the author's producing run (SUMMARY_7800_15000).
set -euo pipefail
cd "$(dirname "$0")"

# the local / partition is full; keep gcc/emu temp traffic on NFS
export TMPDIR="${TMPDIR:-/nfs/home/zhaoxufan/project/debug/6135/tmp/buildtmp}"
mkdir -p "$TMPDIR"

RISCV_GCC="${RISCV_GCC:-/usr/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/usr/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/usr/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/nfs/home/zhaoxufan/project/debug/xs-bug-replay-6135/xs-env/XiangShan/build/emu}"

# Author's producing run used window 7800-15000 (their May-build emu boots
# ~4070 cycles slower); this rebuild of the same commit boots faster, so the
# attack lands at ~C4900 and the window below is what the delivered artifacts
# use. Override with WAVE_BEGIN/WAVE_END to move it.
CYCLES="${CYCLES:-12000}"
WAVE_BEGIN="${WAVE_BEGIN:-2500}"
WAVE_END="${WAVE_END:-6500}"
SECRETS="${SECRETS:-0 1}"

RESULTS="$(cd ../results && pwd)"
WAVES="$(cd ../waves && pwd)"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in $SECRETS; do
  prefix="ras_disable_sidechannel_secret${secret}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  wave="${WAVES}/${prefix}_${WAVE_BEGIN}_${WAVE_END}.vcd"
  run_log="${RESULTS}/${prefix}_${WAVE_BEGIN}_${WAVE_END}.run.log"
  monitor_json="${RESULTS}/${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
  monitor_log="${RESULTS}/${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

  echo "[build] SECRET_BIT=${secret} -> ${elf}"
  "$RISCV_GCC" \
    -DSECRET_BIT="${secret}" \
    -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
    -nostdlib -nostartfiles -static -fno-pic \
    -T link.ld \
    -Wl,--no-relax \
    -o "$elf" \
    ras_disable_sidechannel.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d -t "$elf" > "$objdump"
  mv "$objdump" "$RESULTS/${prefix}.objdump"

  echo "[run] SECRET_BIT=${secret} ${EMU}"
  "$EMU" \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    -i "$bin" \
    --no-diff \
    --dump-wave-full \
    --wave-path="$wave" \
    --force-dump-result \
    > "$run_log" 2>&1
  for _ in $(seq 1 30); do [[ -s "$wave" ]] && break; sleep 1; done

  echo "[parse] ${wave}"
  # the author's monitor exits 1 when predicates fail; keep going so both
  # secrets always run and the summary makes the pair verdict
  set +e
  python3 ./monitor_ras_disable_sidechannel.py "$wave" "$RESULTS/${prefix}.objdump" "$secret" "$monitor_json" > "$monitor_log"
  set -e
  cat "$monitor_log"
done

python3 ./summarize_sidechannel_pair.py \
  --results "$RESULTS" \
  --wave-begin "$WAVE_BEGIN" --wave-end "$WAVE_END" \
  --secrets $SECRETS
