#!/usr/bin/env python3
"""Summarize the #6135 side-channel pair from the two monitor JSONs.

Extracted verbatim (field handling) from the issue author's inline summary
block in run_sidechannel_poc.sh; only the CLI changed (args instead of env).
"""
import argparse
import json
from pathlib import Path


def first_time(events, name, **filters):
    for event in events.get(name, []):
        if all(event.get(key) == value for key, value in filters.items()):
            return event.get("time")
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    parser.add_argument("--wave-begin", required=True)
    parser.add_argument("--wave-end", required=True)
    parser.add_argument("--secrets", nargs="+", required=True)
    args = parser.parse_args()

    results_dir = Path(args.results)
    secrets = set(args.secrets)
    out_path = results_dir / f"pair_summary_{args.wave_begin}_{args.wave_end}.json"
    results = []
    for path in sorted(
        results_dir.glob(
            f"ras_disable_sidechannel_secret*_{args.wave_begin}_{args.wave_end}.monitor.json"
        )
    ):
        with path.open() as f:
            data = json.load(f)
        if str(data["secret_bit"]) not in secrets:
            continue
        events = data.get("events", {})
        expected_ret_site = data.get("expected_ret_site")
        expected_gadget = data["expected_gadget"]
        expected_probe = data["expected_probe"]
        results.append(
            {
                "file": str(path),
                "secret_bit": data["secret_bit"],
                "expected_ret_site": expected_ret_site,
                "expected_gadget": expected_gadget,
                "expected_probe": expected_probe,
                "csr_disable_write_time": data.get("csr_disable_write_time"),
                "ras_disable_time": data.get("ras_disable_time"),
                "first_prediction_time": data.get("first_prediction_time"),
                "key_event_times": {
                    "ret_site_ftq_fetch": first_time(
                        events, "post_disable_ftq_fetch_ret_site", ret_site=expected_ret_site
                    ),
                    "gadget_ftq_fetch": first_time(
                        events, "post_disable_ftq_fetch_gadget", gadget=expected_gadget
                    ),
                    "gadget_decode": first_time(
                        events, "post_disable_decode_gadget", gadget=expected_gadget
                    ),
                    "gadget_dispatch": first_time(
                        events, "post_disable_dispatch_gadget", gadget=expected_gadget
                    ),
                    "probe_load_s1": first_time(
                        events, "post_disable_probe_load_s1", probe=expected_probe
                    ),
                    "dcache_probe_request": first_time(
                        events, "post_disable_dcache_probe_request", probe=expected_probe
                    ),
                    "redirect_to_common_after": first_time(
                        events, "victim_ret_redirect_to_common_after"
                    ),
                    "result_delta0_store": first_time(
                        events, "post_disable_result_delta_store", result="result_delta0"
                    ),
                    "result_delta1_store": first_time(
                        events, "post_disable_result_delta_store", result="result_delta1"
                    ),
                    "hit_loop_commit": first_time(
                        events, "post_disable_commit_label", label="hit_loop"
                    ),
                },
                "rdcycle": data.get("rdcycle"),
                "predicate": data["predicate"],
            }
        )
    out_path.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps(results, indent=2, sort_keys=True))
    if not all(item["predicate"].get("success") for item in results):
        raise SystemExit("one or more sidechannel predicates failed")


if __name__ == "__main__":
    main()
