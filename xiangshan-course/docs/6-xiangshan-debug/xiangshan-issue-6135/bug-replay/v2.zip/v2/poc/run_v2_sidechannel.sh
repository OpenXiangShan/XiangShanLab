#!/usr/bin/env bash
# Build + run both secret variants of the #6135 side-channel PoC on
# kunminghu-v2 (baseline only, no patch) and parse the waves.
#
# Usage:
#   bash run_v2_sidechannel.sh                     # both secrets
#   SECRETS="0" bash run_v2_sidechannel.sh         # one secret
#
# Notes:
# - The emu at xs-env/XiangShan/build/emu must be the kunminghu-v2 build
#   (commit 0fa7bb82, difftest submodule copilot/flash-42) left over from the
#   #6149 work; it writes VCD text waves.
# - v2 boots from flash (~1400 cycles) before reaching 0x80000000, so wave
#   windows are shifted accordingly; the defaults below cover the attack
#   phase, widen if the PoC timing parameters change.
set -euo pipefail
cd "$(dirname "$0")"

# the local / partition is full; keep gcc/emu temp traffic on NFS
export TMPDIR="${TMPDIR:-/nfs/home/zhaoxufan/project/debug/6135/tmp/buildtmp}"
mkdir -p "$TMPDIR"

RISCV_GCC="${RISCV_GCC:-/usr/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/usr/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/usr/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/nfs/home/zhaoxufan/project/debug/xs-env/XiangShan/build/emu}"

CYCLES="${CYCLES:-16000}"
WAVE_BEGIN="${WAVE_BEGIN:-8600}"
WAVE_END="${WAVE_END:-10600}"
SECRETS="${SECRETS:-0 1}"

RESULTS="$(cd ../results && pwd)"
WAVES="$(cd ../waves && pwd)"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in $SECRETS; do
  prefix="ras_disable_sidechannel_secret${secret}_v2"
  W="${prefix}_${WAVE_BEGIN}_${WAVE_END}"

  echo "[build] SECRET_BIT=${secret} -> ${prefix}.elf (RAS_OFF=0x5f, sbpctl bit5 on v2)"
  "$RISCV_GCC" \
    -DSECRET_BIT="${secret}" \
    -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
    -nostdlib -nostartfiles -static -fno-pic \
    -T link.ld \
    -Wl,--no-relax \
    -o "${prefix}.elf" \
    ras_disable_sidechannel_v2.S
  "$RISCV_OBJCOPY" -O binary "${prefix}.elf" "${prefix}.bin"
  "$RISCV_OBJDUMP" -d -t "${prefix}.elf" > "${RESULTS}/${prefix}.objdump"

  echo "[run] SECRET_BIT=${secret} ${EMU}"
  "$EMU" \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    -i "${prefix}.bin" \
    --no-diff \
    --dump-wave-full \
    --wave-path="${WAVES}/${W}.vcd" \
    --force-dump-result \
    > "${RESULTS}/${W}.run.log" 2>&1
  for _ in $(seq 1 30); do [[ -s "${WAVES}/${W}.vcd" ]] && break; sleep 1; done

  echo "[parse] ${W}.vcd"
  python3 ./monitor_v2_ras_disable_sidechannel.py \
    "${WAVES}/${W}.vcd" "${RESULTS}/${prefix}.objdump" "$secret" \
    "${RESULTS}/${W}.monitor.json" | tee "${RESULTS}/${W}.monitor.log"
done

python3 ./summarize_sidechannel_pair.py \
  --results "$RESULTS" \
  --wave-begin "$WAVE_BEGIN" --wave-end "$WAVE_END" \
  --secrets $SECRETS || true
