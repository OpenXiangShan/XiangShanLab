#!/usr/bin/env python3
"""kunminghu-v2 monitor for the #6135 RAS-disable side-channel PoC.

Port of the issue author's V3 monitor (monitor_ras_disable_sidechannel.py) with
three V2-specific changes:

1. Signal map: V2 names (no µRAS; single newRAS; IFU predecode RET redirect is
   the leak path per the #6149 V2 analysis, NewFtq.scala:1143-1145).
2. Addresses are full vaddrs in the V2 wave (V3 uses PrunedAddr >>1).
3. The "prediction" event on V2 is the FTQ->BPU redirect whose cfiUpdate.target
   was replaced by the ungated RAS top (pd_isRet=1): that redirect IS the
   wrong-path driver, so first_prediction_time = first such redirect whose
   target is the secret-selected ret_site after the disable.

Event names are kept identical to the V3 monitor so summarize_sidechannel_pair.py
works for both generations.
"""
import json
import re
import sys
from pathlib import Path


RAS_POP = 1
PROBE0 = 0x80020000
PROBE1 = 0x80020040

DECODE_SLOTS = 6
DISPATCH_SLOTS = 6
COMMIT_SLOTS = 8  # endpoint.commit_8..15 exist but expose no io_* signals on v2
STORE_SLOTS = 3
LOAD_UNITS = 3

# (logical name -> ordered candidate suffixes; first match wins)
SIGNAL_CANDIDATES = {
    "ras_enable": [
        "backend io_frontendCsrCtrl_bp_ctrl_ras_enable",
        "predictors.ras.io_ctrl_ras_enable",
    ],
    "ras_push_valid": ["predictors.ras.RASStack io_spec_push_valid"],
    "ras_push_addr": ["predictors.ras.RASStack io_spec_push_addr"],
    "ras_pop_valid": ["predictors.ras.RASStack io_spec_pop_valid"],
    "ras_top": ["predictors.ras s3_top"],
    "ftq_wen": ["inner_ftq io_toIfu_req_valid"],
    "ftq_start": ["inner_ftq io_toIfu_req_bits_startAddr"],
    "ftq_idx": [
        "inner_ftq io_toIfu_req_bits_ftqIdx_value",
        "inner_ftq io_toIfu_req_bits_ftqIdx_flag",
    ],
    "redir_valid": ["inner_ftq io_toBpu_redirect_valid"],
    "redir_pc": ["inner_ftq io_toBpu_redirect_bits_cfiUpdate_pc"],
    "redir_target": ["inner_ftq io_toBpu_redirect_bits_cfiUpdate_target"],
    "redir_pd_is_ret": ["inner_ftq io_toBpu_redirect_bits_cfiUpdate_pd_isRet"],
    "tl_a_valid": ["inner_dcache auto_client_out_a_valid"],
    "tl_a_address": ["inner_dcache auto_client_out_a_bits_address"],
    "tl_a_opcode": ["inner_dcache auto_client_out_a_bits_opcode"],
}
for slot in range(DECODE_SLOTS):
    SIGNAL_CANDIDATES[f"decode{slot}_valid"] = [f"ctrlBlock.decode io_out_{slot}_valid"]
    SIGNAL_CANDIDATES[f"decode{slot}_pc"] = [f"ctrlBlock.decode io_out_{slot}_bits_pc"]
for slot in range(DISPATCH_SLOTS):
    SIGNAL_CANDIDATES[f"dispatch{slot}_valid"] = [f"ctrlBlock.dispatch io_enqRob_req_{slot}_valid"]
    SIGNAL_CANDIDATES[f"dispatch{slot}_pc"] = [f"ctrlBlock.dispatch io_enqRob_req_{slot}_bits_pc"]
for slot in range(COMMIT_SLOTS):
    endpoint = "commit" if slot == 0 else f"commit_{slot}"
    SIGNAL_CANDIDATES[f"commit{slot}_valid"] = [f"endpoint.{endpoint} io_valid"]
    SIGNAL_CANDIDATES[f"commit{slot}_bits_valid"] = [f"endpoint.{endpoint} io_bits_valid"]
    SIGNAL_CANDIDATES[f"commit{slot}_pc"] = [f"endpoint.{endpoint} io_bits_pc"]
for slot in range(STORE_SLOTS):
    endpoint = "store" if slot == 0 else f"store_{slot}"
    SIGNAL_CANDIDATES[f"store{slot}_valid"] = [f"endpoint.{endpoint} io_valid"]
    SIGNAL_CANDIDATES[f"store{slot}_bits_valid"] = [f"endpoint.{endpoint} io_bits_valid"]
    SIGNAL_CANDIDATES[f"store{slot}_addr"] = [f"endpoint.{endpoint} io_bits_addr"]
    SIGNAL_CANDIDATES[f"store{slot}_data"] = [f"endpoint.{endpoint} io_bits_data"]
    SIGNAL_CANDIDATES[f"store{slot}_pc"] = [f"endpoint.{endpoint} io_bits_pc"]
for unit in range(LOAD_UNITS):
    SIGNAL_CANDIDATES[f"ld{unit}_s1_vaddr_valid"] = [
        f"inner_LoadUnit_{unit} io_lsTopdownInfo_s1_vaddr_valid"
    ]
    SIGNAL_CANDIDATES[f"ld{unit}_s1_vaddr"] = [
        f"inner_LoadUnit_{unit} io_lsTopdownInfo_s1_vaddr_bits"
    ]


def clean_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_int(bits, base=2):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, base)


def hx(value):
    return None if value is None else hex(value)


def read_symbols(objdump_path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\w+\s+.*\s([A-Za-z_][A-Za-z0-9_]*)$")
    with objdump_path.open("r", errors="replace") as f:
        for raw in f:
            match = sym_re.match(raw.strip())
            if match:
                addr, name = match.groups()
                symbols[name] = int(addr, 16)
    required = [
        "_start", "trap_handler",
        "secret0_call", "secret1_call",
        "secret0_ret_site", "secret1_ret_site",
        "secret0_gadget", "secret1_gadget",
        "victim_context_entry", "victim_actual_ret", "common_after",
        "measure_probe0", "measure_probe1",
        "hit_loop", "miss_loop", "wrong_path_sink",
        "result_delta0", "result_delta1",
    ]
    missing = [name for name in required if name not in symbols]
    if missing:
        raise RuntimeError(f"missing objdump symbols: {missing}")
    return symbols


def read_header(path):
    scope = []
    vars_seen = []
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
            elif line.startswith("$upscope"):
                if scope:
                    scope.pop()
            elif line.startswith("$var "):
                match = var_re.match(line)
                if not match:
                    continue
                width, code, name = match.groups()
                name = clean_name(name)
                vars_seen.append({
                    "width": int(width),
                    "code": code,
                    "name": name,
                    "full": ".".join(scope + [name]),
                })
    return vars_seen


def choose_by_suffix(vars_seen, suffix):
    # V2 waves keep a single space between scope components; normalize both.
    def norm(text):
        return re.sub(r"[.\s]+", ".", text)
    want = norm(suffix)
    last = want.split(".")[-1]
    matches = [
        var for var in vars_seen
        if norm(var["full"]).endswith(want)
        or (var["name"] == last and want in norm(var["full"]))
    ]
    if not matches:
        return None
    return sorted(matches, key=lambda var: (len(var["full"]), var["full"]))[0]


def choose_signals(vars_seen):
    selected = {}
    missing = {}
    for key, candidates in SIGNAL_CANDIDATES.items():
        sig = None
        for suffix in candidates:
            sig = choose_by_suffix(vars_seen, suffix)
            if sig is not None:
                break
        if sig is None:
            missing[key] = candidates[0]
        else:
            selected[key] = sig
    return selected, missing


def parse_wave(path, selected, symbols):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)
    values = {key: None for key in selected}
    events = []
    current_time = None
    in_body = False

    ret0 = symbols["secret0_ret_site"]
    ret1 = symbols["secret1_ret_site"]
    gadget0 = symbols["secret0_gadget"]
    gadget1 = symbols["secret1_gadget"]
    common_after = symbols["common_after"]
    victim_entry = symbols["victim_context_entry"]
    victim_ret = symbols["victim_actual_ret"]
    result_delta0 = symbols["result_delta0"]
    result_delta1 = symbols["result_delta1"]
    ras_disable_time = None

    def ret_site_name(value):
        if value == ret0:
            return "secret0_ret_site"
        if value == ret1:
            return "secret1_ret_site"
        return None

    def gadget_name(value):
        if value == gadget0:
            return "secret0_gadget"
        if value == gadget1:
            return "secret1_gadget"
        return None

    def probe_name(addr):
        if addr == PROBE0:
            return "probe0"
        if addr == PROBE1:
            return "probe1"
        return None

    def pc_label(value):
        labels = {
            symbols["measure_probe0"]: "measure_probe0",
            symbols["measure_probe1"]: "measure_probe1",
            symbols["hit_loop"]: "hit_loop",
            symbols["miss_loop"]: "miss_loop",
        }
        return labels.get(value)

    def result_name(addr):
        if addr == result_delta0:
            return "result_delta0"
        if addr == result_delta1:
            return "result_delta1"
        return None

    def after_disable():
        return ras_disable_time is not None and current_time is not None and current_time > ras_disable_time

    def emit_current():
        nonlocal ras_disable_time
        if current_time is None:
            return
        # V2: the CSR write itself is not watched; the enable's 1->0 edge is
        # the disable point (sbpctl.RAS_ENABLE is bit5, write 0x5f).
        if values.get("ras_enable") == 0 and ras_disable_time is None:
            ras_disable_time = current_time
            events.append({"type": "ras_disabled", "time": current_time})

        if not after_disable():
            return

        if values.get("redir_valid") == 1:
            pc = values.get("redir_pc")
            target = values.get("redir_target")
            pd_is_ret = values.get("redir_pd_is_ret")
            ret_site = ret_site_name(target)
            if pd_is_ret == 1 and ret_site:
                # IFU predecode RET redirect: FTQ replaced cfiUpdate.target
                # with the ungated RAS top (NewFtq.scala:1143-1145).
                events.append({
                    "type": "disabled_ras_spec_pop_to_ret_site",
                    "time": current_time,
                    "ret_site": ret_site,
                    "target": target,
                    "pc": pc,
                })
                events.append({
                    "type": "disabled_ifu_ret_redirect_any",
                    "time": current_time,
                    "target": target,
                    "pc": pc,
                    "ret_site": ret_site,
                    "gadget": gadget_name(target),
                })
            # Recovery redirect. The backend-resolved ret misprediction on V2
            # reports cfiUpdate_pc = wrong_path_sink (observed) rather than the
            # ret's own pc, and can carry pd_isRet=1; the reliable marker is
            # the target: common_after is reached exactly once, by the
            # architectural return. The leak redirect above targets the
            # secret-selected ret_site instead, so there is no ambiguity.
            if target == common_after:
                events.append({
                    "type": "victim_ret_redirect_to_common_after",
                    "time": current_time,
                    "pc": pc,
                    "target": target,
                })

        if values.get("ftq_wen") == 1:
            start = values.get("ftq_start")
            if start is not None and symbols["_start"] <= start <= symbols["wrong_path_sink"]:
                events.append({
                    "type": "post_disable_ftq_fetch_any_poc_block",
                    "time": current_time,
                    "start": start,
                    "ftq_idx": values.get("ftq_idx"),
                    "ret_site": ret_site_name(start),
                    "gadget": gadget_name(start),
                })
            ret_site = ret_site_name(start)
            if ret_site:
                events.append({
                    "type": "post_disable_ftq_fetch_ret_site",
                    "time": current_time,
                    "ret_site": ret_site,
                    "start": start,
                    "ftq_idx": values.get("ftq_idx"),
                })
            gadget = gadget_name(start)
            if gadget:
                events.append({
                    "type": "post_disable_ftq_fetch_gadget",
                    "time": current_time,
                    "gadget": gadget,
                    "start": start,
                    "ftq_idx": values.get("ftq_idx"),
                })

        for slot in range(DECODE_SLOTS):
            if values.get(f"decode{slot}_valid") == 1:
                pc = values.get(f"decode{slot}_pc")
                label = pc_label(pc)
                if label:
                    events.append({
                        "type": "post_disable_decode_label", "time": current_time,
                        "slot": slot, "label": label, "pc": pc,
                    })
                gadget = gadget_name(pc)
                if gadget:
                    events.append({
                        "type": "post_disable_decode_gadget", "time": current_time,
                        "slot": slot, "gadget": gadget, "pc": pc,
                    })

        for slot in range(DISPATCH_SLOTS):
            if values.get(f"dispatch{slot}_valid") == 1:
                pc = values.get(f"dispatch{slot}_pc")
                label = pc_label(pc)
                if label:
                    events.append({
                        "type": "post_disable_dispatch_label", "time": current_time,
                        "slot": slot, "label": label, "pc": pc,
                    })
                gadget = gadget_name(pc)
                if gadget:
                    events.append({
                        "type": "post_disable_dispatch_gadget", "time": current_time,
                        "slot": slot, "gadget": gadget, "pc": pc,
                    })

        for slot in range(COMMIT_SLOTS):
            pc = values.get(f"commit{slot}_pc")
            label = pc_label(pc)
            if (
                values.get(f"commit{slot}_valid") == 1
                and values.get(f"commit{slot}_bits_valid") in (None, 1)
                and label
            ):
                events.append({
                    "type": "post_disable_commit_label", "time": current_time,
                    "slot": slot, "label": label, "pc": pc,
                })

        for slot in range(STORE_SLOTS):
            addr = values.get(f"store{slot}_addr")
            result = result_name(addr)
            if (
                values.get(f"store{slot}_valid") == 1
                and values.get(f"store{slot}_bits_valid") in (None, 1)
                and result
            ):
                events.append({
                    "type": "post_disable_result_delta_store", "time": current_time,
                    "slot": slot, "result": result, "addr": addr,
                    "data": values.get(f"store{slot}_data"),
                    "pc": values.get(f"store{slot}_pc"),
                })

        for unit in range(LOAD_UNITS):
            if values.get(f"ld{unit}_s1_vaddr_valid") == 1:
                probe = probe_name(values.get(f"ld{unit}_s1_vaddr"))
                if probe:
                    events.append({
                        "type": "post_disable_probe_load_s1", "time": current_time,
                        "pipe": unit, "probe": probe,
                        "addr": values.get(f"ld{unit}_s1_vaddr"),
                    })

        if values.get("tl_a_valid") == 1:
            probe = probe_name(values.get("tl_a_address"))
            if probe:
                events.append({
                    "type": "post_disable_dcache_probe_request", "time": current_time,
                    "probe": probe,
                    "addr": values.get("tl_a_address"),
                    "opcode": values.get("tl_a_opcode"),
                })

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            first = line[0]
            if first == "#":
                emit_current()
                current_time = int(line[1:])
            elif first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bBhH":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_int(parts[0][1:], 16 if first in "hH" else 2)
                        for key in keys:
                            values[key] = value
        emit_current()

    return events, ras_disable_time


def event_out(event):
    out = dict(event)
    for key in ("ret_pruned", "pop_addr_pruned", "start", "pc", "target", "addr", "data"):
        if key in out:
            out[key] = hx(out[key])
    return out


def main(argv):
    if len(argv) != 5:
        print("usage: monitor_v2_ras_disable_sidechannel.py <wave.vcd> <objdump> <secret_bit> <out.json>", file=sys.stderr)
        return 2
    wave = Path(argv[1])
    objdump = Path(argv[2])
    secret_bit = int(argv[3])
    out = Path(argv[4])

    expected_ret_site = f"secret{secret_bit}_ret_site"
    expected_gadget = f"secret{secret_bit}_gadget"
    expected_probe = f"probe{secret_bit}"
    symbols = read_symbols(objdump)
    selected, missing = choose_signals(read_header(wave))
    events, ras_time = parse_wave(wave, selected, symbols)

    by_type = {}
    for event in events:
        by_type.setdefault(event["type"], []).append(event)

    predictions = [
        e for e in by_type.get("disabled_ras_spec_pop_to_ret_site", [])
        if e.get("ret_site") == expected_ret_site
    ]
    first_prediction_time = min((e["time"] for e in predictions), default=None)

    def after_prediction(event):
        return first_prediction_time is not None and event["time"] >= first_prediction_time

    ret_fetches = [
        e for e in by_type.get("post_disable_ftq_fetch_ret_site", [])
        if e.get("ret_site") == expected_ret_site and after_prediction(e)
    ]
    fetches = [e for e in by_type.get("post_disable_ftq_fetch_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    wrong_fetches = [
        e for e in by_type.get("post_disable_ftq_fetch_ret_site", [])
        if e.get("ret_site") != expected_ret_site and after_prediction(e)
    ]
    redirects = by_type.get("victim_ret_redirect_to_common_after", [])
    decodes = [e for e in by_type.get("post_disable_decode_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    dispatches = [e for e in by_type.get("post_disable_dispatch_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    probe_loads = [
        e for e in by_type.get("post_disable_probe_load_s1", [])
        if e.get("probe") == expected_probe and after_prediction(e)
    ]
    dcache_requests = [
        e for e in by_type.get("post_disable_dcache_probe_request", [])
        if e.get("probe") == expected_probe and after_prediction(e)
    ]
    label_decodes = [e for e in by_type.get("post_disable_decode_label", []) if after_prediction(e)]
    label_dispatches = [e for e in by_type.get("post_disable_dispatch_label", []) if after_prediction(e)]
    label_commits = [e for e in by_type.get("post_disable_commit_label", []) if after_prediction(e)]
    result_stores = [e for e in by_type.get("post_disable_result_delta_store", []) if after_prediction(e)]
    delta0_stores = [e for e in result_stores if e.get("result") == "result_delta0"]
    delta1_stores = [e for e in result_stores if e.get("result") == "result_delta1"]
    delta0 = delta0_stores[0].get("data") if delta0_stores else None
    delta1 = delta1_stores[0].get("data") if delta1_stores else None
    selected_delta = delta0 if secret_bit == 0 else delta1
    other_delta = delta1 if secret_bit == 0 else delta0
    selected_probe_faster = (
        selected_delta is not None
        and other_delta is not None
        and selected_delta < other_delta
    )
    hit_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") == "hit_loop"
    ]
    miss_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") == "miss_loop"
    ]
    measure_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") in ("measure_probe0", "measure_probe1")
    ]

    result = {
        "wave": str(wave),
        "arch": "kunminghu-v2",
        "secret_bit": secret_bit,
        "expected_ret_site": expected_ret_site,
        "expected_gadget": expected_gadget,
        "expected_probe": expected_probe,
        "symbols": {
            key: hx(symbols[key])
            for key in sorted(symbols)
            if key in {
                "secret0_call", "secret1_call", "secret0_gadget", "secret1_gadget",
                "secret0_ret_site", "secret1_ret_site",
                "victim_context_entry", "victim_actual_ret", "common_after",
                "measure_probe0", "measure_probe1", "hit_loop", "miss_loop",
                "result_delta0", "result_delta1",
            }
        },
        "probe_addresses": {"probe0": hx(PROBE0), "probe1": hx(PROBE1)},
        "selected_signal_count": len(selected),
        "missing_signal_count": len(missing),
        "missing_signals": missing,
        "csr_disable_write_time": None,
        "ras_disable_time": ras_time,
        "first_prediction_time": first_prediction_time,
        "rdcycle": {
            "delta0_cycles": delta0,
            "delta1_cycles": delta1,
            "selected_delta_cycles": selected_delta,
            "other_delta_cycles": other_delta,
            "selected_probe_faster": selected_probe_faster,
        },
        "predicate": {
            "csr_disable_seen": ras_time is not None,
            "ras_enable_zero_seen": ras_time is not None,
            "disabled_ras_prediction_to_expected_ret_site": bool(predictions),
            "victim_return_redirected_to_common_after": bool(redirects),
            "expected_ret_site_ftq_fetch_after_prediction": bool(ret_fetches),
            "expected_gadget_ftq_fetch_after_disable": bool(fetches),
            "unexpected_ret_site_ftq_fetch_after_prediction": bool(wrong_fetches),
            "expected_gadget_decode_after_disable": bool(decodes),
            "expected_gadget_dispatch_after_disable": bool(dispatches),
            "expected_probe_load_after_prediction": bool(probe_loads),
            "expected_dcache_probe_request_after_prediction": bool(dcache_requests),
            "measure_probe_code_seen_after_prediction": bool(measure_events),
            "rdcycle_delta0_observed": bool(delta0_stores),
            "rdcycle_delta1_observed": bool(delta1_stores),
            "selected_probe_faster_than_other": selected_probe_faster,
            "hit_loop_seen": bool(hit_events),
            "miss_loop_seen": bool(miss_events),
            "icache_ftq_sidechannel_success": bool(ras_time is not None and predictions and redirects and ret_fetches),
            "dcache_sidechannel_success": bool(ras_time is not None and predictions and redirects and probe_loads),
            "timing_sidechannel_success": bool(selected_probe_faster or hit_events),
            "success": bool(
                ras_time is not None
                and predictions
                and ret_fetches
                and fetches
                and decodes
                and dispatches
                and probe_loads
                and dcache_requests
                and redirects
                and measure_events
                and delta0_stores
                and delta1_stores
                and selected_probe_faster
                and hit_events
                and not wrong_fetches
            ),
        },
        "events": {
            key: [event_out(e) for e in by_type[key]]
            for key in sorted(by_type)
        },
    }

    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "secret_bit": secret_bit,
        "ras_disable_time": ras_time,
        "first_prediction_time": first_prediction_time,
        "rdcycle": result["rdcycle"],
        "predicate": result["predicate"],
        "missing_signals": result["missing_signals"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
