#!/usr/bin/env bash
# Reproduce the two PR #6461 verification experiments.
#
# Required emus (build instructions in ../README.md):
#   EMU_ASSERT    PR head dcdf1c1c9 built as-is (assertion enabled)
#   EMU_NOASSERT  PR head with the single assertion line disabled
# Defaults point at the working build dirs used for the report.
set -euo pipefail
cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/usr/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/usr/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/usr/bin/riscv64-unknown-elf-objdump}"
EMU_ASSERT="${EMU_ASSERT:-/nfs/home/zhaoxufan/project/debug/6149/v3-patched/build/emu}"
EMU_NOASSERT="${EMU_NOASSERT:-/nfs/home/zhaoxufan/project/debug/6149/v3-patched/emu-noassert.bak}"

for CAND in ../../tools/fst/bin /nfs/home/zhaoxufan/project/debug/tools/fst/bin; do
  [[ -d "$CAND" ]] && export PATH="$CAND:$PATH" && break
done

echo "===== experiment 1: minimal assertion PoC ====="
for R in 1 0; do
  "$RISCV_GCC" -nostdlib -nostartfiles -march=rv64gc_zicsr -mabi=lp64 -DRAS_OFF=$R \
    -T linker.ld -Wl,--no-relax -o minret_rasoff$R.elf ras_min_ret_assert.S
  "$RISCV_OBJCOPY" -O binary minret_rasoff$R.elf minret_rasoff$R.bin
done
echo "--- [1] RAS_OFF=1 @ PR head (expect ABORT + assertion message) ---"
"$EMU_ASSERT" -C 20000 -i minret_rasoff1.bin --no-diff 2>&1 |
  grep -E "Assertion|ERROR.*mbtb|instrCnt" | head -4 || true
echo "--- [2] RAS_OFF=0 @ PR head (expect healthy park) ---"
"$EMU_ASSERT" -C 20000 -i minret_rasoff0.bin --no-diff 2>&1 | grep instrCnt || true
echo "--- [3] RAS_OFF=1 @ assertion-disabled build (expect healthy park) ---"
"$EMU_NOASSERT" -C 20000 -i minret_rasoff1.bin --no-diff 2>&1 | grep instrCnt || true

echo "===== experiment 2: S1 residual pair (assertion-disabled build) ====="
for S in 1 0; do
  "$RISCV_GCC" -nostdlib -nostartfiles -march=rv64gc_zicsr -mabi=lp64 \
    -DSECRET_BIT=$S -DDELAY_ITERS=768 -DTRAIN_ITERS=128 \
    -T linker.ld -Wl,--no-relax -o patched_s$S.elf ras_enable_secret_fetch_mtvec.S
  "$RISCV_OBJCOPY" -O binary patched_s$S.elf patched_s$S.bin
  "$RISCV_OBJDUMP" -d -t patched_s$S.elf > patched_s$S.objdump
  W="patched_s${S}_11000_13500"
  "$EMU_NOASSERT" -C 16000 -b 11000 -e 13500 -i patched_s$S.bin --no-diff \
    --dump-wave-full --wave-path=$W.vcd --force-dump-result > $W.run.log 2>&1
  for _ in $(seq 1 30); do [[ -s "$W.vcd" ]] && break; sleep 1; done
  # this difftest writes VCD text; monitor takes the file directly
  python3 ./monitor_ras_enable_secret_fetch.py "$W.vcd" patched_s$S.objdump \
    "$W.monitor.json" --secret-bit $S > "$W.monitor.log" || true
  cat "$W.monitor.log"
done
python3 ./summarize_pair.py \
  --secret0 patched_s0_11000_13500.monitor.json \
  --secret1 patched_s1_11000_13500.monitor.json \
  --out pair_patched.json || true
echo "expected: no s3 events, s1_disabled_uras_prediction present (see analysis.md §2.3)"
