# PR #6461（head `dcdf1c1c9`）验证

对应 `../analysis.md` §2。本文件夹包含两个实验：

1. **修复暴露既有 assertion 缺陷（非硬件功能错误）**：#6461 的 gate 修复使 "RAS 禁用时 return 由 mBTB 提供 target" 成为正常状态，而基线（#5639）引入的旧 assertion 仍要求 resolved return 的 source 为 RAS——最小 PoC（一次 `csrw sbpctl,0x3f` + 两条 `ret`）在 PR head 原样构建上即触发 fatal abort。
2. **S1 µRAS 残留**：完整 #6149 PoC 在"PR head + 仅禁用该 assertion"的构建上复跑——S3/state 层修复生效，但 µRAS 仍在禁用态驱动 S1 预测 target（6 次 secret 相关事件），本配置下未转化为实际 fetch。

## 使用的两个 emu（构建方法）

| emu | 源码 | 用途 |
| --- | --- | --- |
| PR head 原样 | `git fetch origin pull/6461/head && git checkout dcdf1c1c9`，`make init`（含 rocket-chip 嵌套子模块 cde/hardfloat、XSCache/OpenNCB），`make emu EMU_TRACE=1 -j64` | 实验 1（assertion 演示） |
| PR head + assertion 禁用 | 同上，另把 `src/main/scala/xiangshan/frontend/Bundles.scala` 中 `retError := src.s3Mbtb` 一行置为 `false.B`（仅此一处，纯断言改动，不影响功能逻辑；emu 健康性经 coremark 验证 IPC 0.57） | 实验 2（S1 残留，需要完整运行 RAS 禁用场景） |

## 实验 1：最小 assertion PoC（`poc/ras_min_ret_assert.S`）

编译期开关 `RAS_OFF`：1 = 写 `0x3f`（清 RAS_ENABLE），0 = 写 `0x7f`（全开）。程序其余完全一致（mtvec 已设、两条 `la ra; ret`、park 循环）。

| 运行 | emu | 结果 |
| --- | --- | --- |
| `RAS_OFF=1` | PR head 原样 | **ABORT @ C8357，instrCnt=18**：`Assertion failed ... Ftq.sv:41996` / `[ERROR] ... prediction source cannot be mbtb when resolved branch type is return`（`results/minret_rasoff1_assertemu.log`） |
| `RAS_OFF=0`（对照） | PR head 原样 | 正常 park，C20000 提交 11630 条（`results/minret_rasoff0_assertemu.log`） |
| `RAS_OFF=1` | assertion 禁用 | 与对照完全一致（11630 条，`results/minret_rasoff1_noassertemu.log`）——证明唯一阻塞就是该 assertion，RTL 功能行为本身正常 |

结论（注意与硬件功能错误区分）：该 assertion 并非 #6461 新增（基线 `Bundles.scala:411/440` 已有）；基线上它从不触发，恰恰是因为 #6149 的 bug 让 return 恒由 RAS 提供 target（source 恒为 s3Ras）——bug 掩盖了这条过时断言。#6461 修复 gate 后旧不变量被暴露，任何"关 RAS 后执行 ret"的程序（即 #6149 场景本身）都会 fatal abort。对照③（禁用该 assertion）功能行为与 RAS 开启时完全一致，证明这不是硬件产生错误 target，而是应随 PR 更新的验证断言（建议对 `!ras_enable` 豁免）。

## 实验 2：S1 µRAS 残留（`poc/ras_enable_secret_fetch_mtvec.S`，与 v3/ 同一 PoC）

在 assertion 禁用构建上复跑双 secret（参数 TRAIN=128/DELAY=768，波形窗口 C11000-C13500）：

| 指标 | V3 基线 | PR head + assertion 禁用 |
| --- | --- | --- |
| `s3_disabled_ras_prediction` | 16 次 | 0 次（`s3_useRas` 全程 0）——S3 consumer gate 生效 |
| 主 RAS 栈顶吸收 poison 地址 | 是 | 否（state gate 生效） |
| `s1_disabled_uras_prediction` | 2 次 | **6 次 → gadget1（`0x40000042`），`csr_ras_enable=0`**——µRAS 残留确认 |
| S1 错误目标是否转化为 FTQ fetch | 是 | 否（fetch 发出前被仲裁纠正） |
| `secret_dependent_wrong_path_fetch` | true | false |

解读：µRAS（`MicroRas.scala`）在 PR head 仍不消费 `io.enable`，S1 的两个 target mux（`Bpu.scala:279/313`）仍只查 `isReturn && isCanUse`——静态与动态一致。本配置下 S1 的错误目标被 S3（不再使用 RAS）的预测经仲裁纠正、未转化为实际 fetch，属于依赖仲裁顺序的偶然行为，而非设计保证；若 mBTB 未覆盖该块，S1 目标仍可能直接驱动 fetch。

## 文件清单

```text
poc/    ras_min_ret_assert.S、ras_enable_secret_fetch_mtvec.S、linker.ld、
        monitor 与 summarize 脚本、四个 bin（minret_rasoff{0,1}、patched_s{0,1}）
waves/  patched_s{0,1}_11000_13500.vcd.gz（实验 2 波形，gzip 压缩的 VCD 文本；monitor 已支持直接解析 .vcd.gz。实验 1 无需波形，abort 日志即证据）
results/ 实验 1 三组运行日志、实验 2 的 monitor JSON/log、objdump、pair_patched.json
```
