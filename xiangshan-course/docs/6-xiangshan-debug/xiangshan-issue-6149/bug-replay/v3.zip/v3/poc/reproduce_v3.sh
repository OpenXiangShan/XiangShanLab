#!/usr/bin/env bash
# Reproduce the #6149 leak pair on the kunminghu-v3 baseline emu.
#
# Requires: riscv64-unknown-elf-gcc toolchain; the v3 replay emu at
#   /nfs/home/zhaoxufan/project/debug/xs-bug-replay-6149/xs-env/XiangShan/build/verilator-compile/emu
#   (kunminghu-v3 @ e85a929a3); fst2vcd on PATH (../../tools/fst/bin relative to repo root).
set -euo pipefail
cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/usr/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/usr/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/usr/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/nfs/home/zhaoxufan/project/debug/xs-bug-replay-6149/xs-env/XiangShan/build/verilator-compile/emu}"

# fst2vcd for wave parsing (adjust if laid out differently)
for CAND in ../../tools/fst/bin /nfs/home/zhaoxufan/project/debug/tools/fst/bin; do
  [[ -d "$CAND" ]] && export PATH="$CAND:$PATH" && break
done
command -v fst2vcd >/dev/null || { echo "[error] fst2vcd not found" >&2; exit 2; }

CYCLES="${CYCLES:-11000}"
WAVE_BEGIN="${WAVE_BEGIN:-6500}"
WAVE_END="${WAVE_END:-9000}"

for S in 1 0; do
  P="ras_enable_secret${S}_mtvec"
  W="${P}_${WAVE_BEGIN}_${WAVE_END}"
  echo "=== secret $S ==="
  "$RISCV_GCC" -nostdlib -nostartfiles -march=rv64gc_zicsr -mabi=lp64 \
    -DSECRET_BIT=$S -DDELAY_ITERS=768 -DTRAIN_ITERS=128 -T linker.ld -Wl,--no-relax \
    -o "$P.elf" ras_enable_secret_fetch_mtvec.S
  "$RISCV_OBJCOPY" -O binary "$P.elf" "$P.bin"
  "$RISCV_OBJDUMP" -d -t "$P.elf" > "$P.objdump"
  "$EMU" -C "$CYCLES" -b "$WAVE_BEGIN" -e "$WAVE_END" -i "$P.bin" --no-diff \
    --dump-wave-full --wave-path="$W.fst" --force-dump-result > "$W.run.log" 2>&1
  for _ in $(seq 1 30); do [[ -s "$W.fst" ]] && break; sleep 1; done
  python3 ./monitor_ras_enable_secret_fetch.py "$W.fst" "$P.objdump" "$W.monitor.json" \
    --secret-bit $S > "$W.monitor.log" || true
  cat "$W.monitor.log"
done
python3 ./summarize_pair.py \
  --secret0 "ras_enable_secret0_mtvec_${WAVE_BEGIN}_${WAVE_END}.monitor.json" \
  --secret1 "ras_enable_secret1_mtvec_${WAVE_BEGIN}_${WAVE_END}.monitor.json" \
  --out pair_verify.json || true
echo "see pair_verify.json (secret_dependent_wrong_path_fetch expected true)"
