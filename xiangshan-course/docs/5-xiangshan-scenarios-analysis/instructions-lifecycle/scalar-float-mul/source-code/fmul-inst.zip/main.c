#include <klib.h>

/*
 * 一条用例 = 清标志、装两个源、乘一次。结果与标志不回读，
 * 直接在执行单元的输出端口上看。操作数以位模式传入，用
 * fmv.w.x 原样搬进浮点寄存器，避免编译器改写这条乘法。
 */
#define CASE(A, B, RND)                                                     \
  __asm__ volatile(                                                         \
      "csrw    fflags, zero\n\t"                                            \
      "fmv.w.x fa0, %0\n\t"                                                 \
      "fmv.w.x fa1, %1\n\t"                                                 \
      "fmul.s  fa2, fa0, fa1, " #RND                                        \
      :                                                                     \
      : "r"((uint32_t)(A)), "r"((uint32_t)(B))                              \
      : "fa0", "fa1", "fa2")

int main() {
  CASE(0x7F7FFFFF, 0x40000000, rne); /* 最大有限数 * 2 -> +inf */
  CASE(0x7F7FFFFF, 0x40000000, rdn); /* 同上，向下舍入 -> 最大有限数 */
  CASE(0x7FC00000, 0x40000000, rne); /* qNaN */
  CASE(0x7F800001, 0x40000000, rne); /* sNaN */
  CASE(0x7F800000, 0xC0000000, rne); /* +inf * -2.0 */
  CASE(0x7F800000, 0x00000000, rne); /* +inf * +0 */
  CASE(0x80000000, 0x40000000, rne); /* -0 * +2.0 */
  CASE(0x00000001, 0x3F000000, rne); /* 最小次正规数 * 0.5 */
  CASE(0x00000001, 0x40000000, rne); /* 最小次正规数 * 2.0 */
  CASE(0x3F800000, 0x40400000, rne); /* 1.0 * 3.0 */
  return 0;
}
