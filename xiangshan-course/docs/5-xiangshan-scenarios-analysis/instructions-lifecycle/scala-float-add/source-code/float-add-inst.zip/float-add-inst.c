#include <klib.h>

volatile float a = 1.25f;
volatile float b = 2.50f;
volatile float c;

int main() {
  c = a + b;// 目标：生成 fadd.s
  assert(c == 3.75f);
  printf("success\n");
  return 0;
}