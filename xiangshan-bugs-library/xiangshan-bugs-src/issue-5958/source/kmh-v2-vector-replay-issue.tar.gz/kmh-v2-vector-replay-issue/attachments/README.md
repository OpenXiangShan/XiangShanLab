# Kunminghu v2 Vector Replay Issue Attachments

This archive contains a standalone reproducer and supporting evidence for a
Kunminghu v2 `LoadQueueReplay` assertion:

```text
LoadQueueReplay: vector load, should not have replay entry ... when commit or flush.
```

## Contents

```text
environment-report.md
kmh-v2-vector-replay-min-poc/
bin/kmh-v2-vector-replay-min-poc.bin
bin/kmh-v2-vector-replay-min-poc.disasm
logs/old-rtl-failure.log
logs/patched-rtl-pass.log
logs/xiangshan-git-status.txt
logs/xiangshan-submodule-status.txt
logs/nexus-am-poc-commit.txt
patches/possible-fix-loadqueue-replay-vector-release.patch
```

`possible-fix-loadqueue-replay-vector-release.patch` is not required to
reproduce the issue. It is included as context for the suspected fix: release
matching stale vector replay entries on VL merge-buffer commit/flush feedback
instead of asserting that the entry cannot exist.

## Build

```sh
make -C kmh-v2-vector-replay-min-poc
```

## Run

```sh
/path/to/kmh-v2/difftest/emu \
  -s 241027 \
  -i kmh-v2-vector-replay-min-poc/build/kmh-v2-vector-replay-min-poc.bin \
  --diff /path/to/riscv64-nemu-interpreter-so \
  -e 0
```

The prebuilt binary is also available at:

```text
bin/kmh-v2-vector-replay-min-poc.bin
```
