#include <stddef.h>
#include <stdint.h>

enum {
  kLength = 16,
  kRuntimeBase = 0x80000000ull,
  kRuntimeSize = 0x40000000ull,
  kSrcVa = 0x900200000ull,
  kDstVa = 0x900201000ull,
  kPageSize = 4096,
  kCrossSrcVa = 0x900210000ull,
  kCrossDstVa = 0x900220000ull,
  kCrossOffset = kPageSize - 8,
  kPteV = 1u << 0,
  kPteR = 1u << 1,
  kPteW = 1u << 2,
  kPteX = 1u << 3,
  kPteA = 1u << 6,
  kPteD = 1u << 7,
  kProtRwxad = kPteR | kPteW | kPteX | kPteA | kPteD,
  kSatpSv39 = 8ull << 60,
  kMstatusMppMask = 3ull << 11,
  kMstatusMppS = 1ull << 11,
  kMstatusMprv = 1ull << 17,
  kMstatusVsDirty = 3ull << 9,
  kPmpR = 1u << 0,
  kPmpW = 1u << 1,
  kPmpX = 1u << 2,
  kPmpNapOt = 3u << 3,
};

static uint8_t src[4096] __attribute__((aligned(4096)));
static uint8_t dst[4096] __attribute__((aligned(4096)));
static uint8_t cross_src[8192] __attribute__((aligned(4096)));
static uint8_t cross_dst[8192] __attribute__((aligned(4096)));
static uintptr_t root_pt[512] __attribute__((aligned(4096)));
static uintptr_t l1_pt[512] __attribute__((aligned(4096)));
static uintptr_t l0_pt[512] __attribute__((aligned(4096)));

static uintptr_t make_pte(uintptr_t pa, uintptr_t prot) {
  return kPteV | prot | ((pa >> 12) << 10);
}

static uintptr_t vpn(uintptr_t va, unsigned int level) {
  return (va >> (12u + level * 9u)) & 0x1ffu;
}

static void zero_page(uintptr_t *page) {
  for (size_t i = 0; i < 512; ++i) {
    page[i] = 0;
  }
}

static void map_1g_identity(uintptr_t va, uintptr_t prot) {
  root_pt[vpn(va, 2)] = make_pte(va, prot);
}

static void map_4k(uintptr_t va, uintptr_t pa, uintptr_t prot) {
  root_pt[vpn(va, 2)] = make_pte((uintptr_t)l1_pt, 0);
  l1_pt[vpn(va, 1)] = make_pte((uintptr_t)l0_pt, 0);
  l0_pt[vpn(va, 0)] = make_pte(pa, prot);
}

static void enable_sv39(void) {
  uintptr_t satp = kSatpSv39 | ((uintptr_t)root_pt >> 12);

  __asm__ volatile(
      "csrw satp, %0\n\t"
      "sfence.vma\n\t"
      :
      : "r"(satp)
      : "memory");
}

static void enable_bare(void) {
  __asm__ volatile(
      "csrw satp, zero\n\t"
      "sfence.vma\n\t"
      :
      :
      : "memory");
}

static uintptr_t enter_s_mode_data_access(void) {
  uintptr_t status;
  uintptr_t new_status;

  __asm__ volatile("csrr %0, mstatus" : "=r"(status) : : "memory");
  new_status = (status & ~kMstatusMppMask) | kMstatusMppS | kMstatusMprv | kMstatusVsDirty;
  __asm__ volatile("csrw mstatus, %0" : : "r"(new_status) : "memory");
  return status;
}

static void leave_s_mode_data_access(uintptr_t status) {
  __asm__ volatile("csrw mstatus, %0" : : "r"(status) : "memory");
}

static void allow_all_pmp(void) {
  uintptr_t cfg = kPmpR | kPmpW | kPmpX | kPmpNapOt;

  __asm__ volatile(
      "li t0, -1\n\t"
      "csrw pmpaddr15, t0\n\t"
      "slli %0, %0, 56\n\t"
      "csrw pmpcfg2, %0\n\t"
      "sfence.vma\n\t"
      : "+r"(cfg)
      :
      : "t0", "memory");
}

static inline size_t set_vl_e8_m1(size_t requested_vl) {
  uintptr_t actual_vl;

  __asm__ volatile(
      "mv a0, %1\n\t"
      ".word 0x0c0572d7\n\t" /* vsetvli t0, a0, e8, m1, ta, ma */
      "mv %0, t0\n\t"
      : "=r"(actual_vl)
      : "r"(requested_vl)
      : "a0", "t0", "memory");
  return (size_t)actual_vl;
}

static inline void vle8_v8(const void *addr) {
  __asm__ volatile(
      "mv a0, %0\n\t"
      ".word 0x02050407\n\t" /* vle8.v v8, (a0) */
      :
      : "r"(addr)
      : "a0", "memory");
}

static inline void vse8_v8(void *addr) {
  __asm__ volatile(
      "mv a1, %0\n\t"
      ".word 0x02058427\n\t" /* vse8.v v8, (a1) */
      :
      : "r"(addr)
      : "a1", "memory");
}

static inline void __attribute__((noreturn)) finish(uintptr_t code) {
  __asm__ volatile(
      "mv a0, %0\n\t"
      ".word 0x0005006b\n\t"
      :
      : "r"(code)
      : "a0", "memory");
  __builtin_unreachable();
}

static void fill_range(uint8_t *base, size_t offset, size_t len, uint8_t seed) {
  for (size_t i = 0; i < len; ++i) {
    base[offset + i] = (uint8_t)(seed + i * 7u);
  }
}

static void zero_range(uint8_t *base, size_t offset, size_t len) {
  for (size_t i = 0; i < len; ++i) {
    base[offset + i] = 0;
  }
}

static void init_data(void) {
  for (size_t i = 0; i < kLength; ++i) {
    src[i] = (uint8_t)(0x31u + i * 7u);
    dst[i] = 0u;
  }
}

static void init_page_table(void) {
  zero_page(root_pt);
  zero_page(l1_pt);
  zero_page(l0_pt);
  map_1g_identity(kRuntimeBase, kProtRwxad);
  map_4k(kSrcVa, (uintptr_t)src, kProtRwxad);
  map_4k(kDstVa, (uintptr_t)dst, kProtRwxad);
  map_4k(kCrossSrcVa, (uintptr_t)cross_src, kProtRwxad);
  map_4k(kCrossSrcVa + kPageSize, (uintptr_t)cross_src + kPageSize, kProtRwxad);
  map_4k(kCrossDstVa, (uintptr_t)cross_dst, kProtRwxad);
  map_4k(kCrossDstVa + kPageSize, (uintptr_t)cross_dst + kPageSize, kProtRwxad);
}

static int check_range(const uint8_t *expected, const uint8_t *observed, size_t len) {
  for (size_t i = 0; i < len; ++i) {
    if (observed[i] != expected[i]) {
      return -1;
    }
  }
  return 0;
}

static void vector_roundtrip_once(uintptr_t load_addr, uintptr_t store_addr, int translated) {
  uintptr_t status;

  if (set_vl_e8_m1(kLength) != kLength) {
    finish(2);
  }

  status = 0;
  if (translated) {
    status = enter_s_mode_data_access();
  }
  vle8_v8((const void *)load_addr);
  vse8_v8((void *)store_addr);
  __asm__ volatile("fence rw, rw" ::: "memory");
  if (translated) {
    leave_s_mode_data_access(status);
  }
}

int main(void) {
  allow_all_pmp();
  if (set_vl_e8_m1(1) != 1) {
    finish(2);
  }
  enable_bare();

  init_data();
  vector_roundtrip_once((uintptr_t)src, (uintptr_t)dst, 0);
  if (check_range(src, dst, kLength) != 0) {
    finish(1);
  }

  init_data();
  init_page_table();
  enable_sv39();
  vector_roundtrip_once(kSrcVa, kDstVa, 1);
  if (check_range(src, dst, kLength) != 0) {
    finish(1);
  }

  fill_range(cross_src, kCrossOffset, kLength, 0x61u);
  zero_range(cross_dst, kCrossOffset, kLength);
  vector_roundtrip_once(kCrossSrcVa + kCrossOffset, kCrossDstVa + kCrossOffset, 1);

  enable_bare();

  if (check_range(cross_src + kCrossOffset, cross_dst + kCrossOffset, kLength) != 0) {
    finish(1);
  }

  finish(0);
}
