# Kunminghu v2 Vector Replay Minimal POC

This is a standalone minimized reproducer for the Kunminghu v2
`LoadQueueReplay` vector-load assertion:

```text
LoadQueueReplay: vector load, should not have replay entry ... when commit or flush.
```

The test intentionally does not depend on SnippetGen or AM's shared test
runtime. It keeps only the pieces needed to hit the replay/merge-buffer
ordering window:

1. Configure allow-all PMP.
2. Execute one bare vector byte load/store round trip as warm-up.
3. Enable a minimal Sv39 page table.
4. Execute one translated 4 KiB-local vector byte load/store round trip.
5. Execute one translated vector byte load/store round trip crossing a 4 KiB
   page boundary.

Each vector round trip uses this instruction shape:

```text
vsetvli
vle8.v v8, (src)
vse8.v v8, (dst)
fence rw, rw
scalar byte compare
```

There is no fence between `vsetvli` and `vle8.v`. The final fence only makes
the store result visible before the scalar comparison.

Build:

```sh
make -C tests/kmh-v2-vector-replay-min-poc
```

Run with the old Kunminghu v2 difftest runner:

```sh
/nfs/home/liujunqi/XS/artifacts/kmh-runners/kmh-v2/difftest/emu \
  -s 241027 \
  -i tests/kmh-v2-vector-replay-min-poc/build/kmh-v2-vector-replay-min-poc.bin \
  --diff /nfs/home/liujunqi/XS/artifacts/kmh-runners/kmh-v2/difftest/riscv64-nemu-interpreter-so \
  -e 0
```

Observed old-RTL result with seed `241027`:

```text
ABORT at pc = 0x80000258
Core-0 instrCnt = 5361, cycleCnt = 7468
LoadQueueReplay: vector load, should not have replay entry 8 when commit or flush.
```

With the RTL fix that releases stale vector replay entries on VL merge-buffer
commit/flush feedback, the same binary reaches:

```text
HIT GOOD TRAP at pc = 0x80000070
Core-0 instrCnt = 5470, cycleCnt = 7911
```
