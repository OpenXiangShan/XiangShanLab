"""
VectorFloatFMA 验证环境
集成 Agent 和 Reference Model
"""

from toffee import Env
from agent import VectorFloatFMAAgent
from model import VectorFloatFMAModel


class VectorFloatFMAEnv(Env):
    """向量浮点乘加融合验证环境"""
    
    def __init__(self, bundle, dut=None):
        super().__init__()
        # 保存 bundle 和 dut 引用
        self.bundle = bundle
        self.dut = dut
        # 创建 Agent
        self.agent = VectorFloatFMAAgent(bundle)
        
        # 挂载参考模型
        # 注意：由于硬件的精确舍入和异常处理很复杂，
        # 这里的模型主要用于基本功能验证
        # self.attach(VectorFloatFMAModel())
