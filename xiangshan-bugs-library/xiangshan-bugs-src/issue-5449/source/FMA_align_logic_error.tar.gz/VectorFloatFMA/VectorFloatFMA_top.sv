module VectorFloatFMA_top();

  logic  clock;
  logic  reset;
  logic  io_fire;
  logic [63:0] io_fp_a;
  logic [63:0] io_fp_b;
  logic [63:0] io_fp_c;
  logic  io_uop_idx;
  logic [63:0] io_widen_a;
  logic [63:0] io_widen_b;
  logic [2:0] io_round_mode;
  logic [1:0] io_fp_format;
  logic [3:0] io_op_code;
  logic [63:0] io_frs1;
  logic  io_is_vec;
  logic  io_is_frs1;
  logic  io_res_widening;
  logic [63:0] io_fp_result;
  logic [19:0] io_fflags;
  logic  io_fp_aIsFpCanonicalNAN;
  logic  io_fp_bIsFpCanonicalNAN;
  logic  io_fp_cIsFpCanonicalNAN;


 VectorFloatFMA VectorFloatFMA(
    .clock(clock),
    .reset(reset),
    .io_fire(io_fire),
    .io_fp_a(io_fp_a),
    .io_fp_b(io_fp_b),
    .io_fp_c(io_fp_c),
    .io_uop_idx(io_uop_idx),
    .io_widen_a(io_widen_a),
    .io_widen_b(io_widen_b),
    .io_round_mode(io_round_mode),
    .io_fp_format(io_fp_format),
    .io_op_code(io_op_code),
    .io_frs1(io_frs1),
    .io_is_vec(io_is_vec),
    .io_is_frs1(io_is_frs1),
    .io_res_widening(io_res_widening),
    .io_fp_result(io_fp_result),
    .io_fflags(io_fflags),
    .io_fp_aIsFpCanonicalNAN(io_fp_aIsFpCanonicalNAN),
    .io_fp_bIsFpCanonicalNAN(io_fp_bIsFpCanonicalNAN),
    .io_fp_cIsFpCanonicalNAN(io_fp_cIsFpCanonicalNAN)
 );


  export "DPI-C" function get_clockxxPfBDHP51VF5;
  export "DPI-C" function set_clockxxPfBDHP51VF5;
  export "DPI-C" function get_resetxxPfBDHP51VF5;
  export "DPI-C" function set_resetxxPfBDHP51VF5;
  export "DPI-C" function get_io_firexxPfBDHP51VF5;
  export "DPI-C" function set_io_firexxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_axxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_axxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_bxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_bxxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_cxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_cxxPfBDHP51VF5;
  export "DPI-C" function get_io_uop_idxxxPfBDHP51VF5;
  export "DPI-C" function set_io_uop_idxxxPfBDHP51VF5;
  export "DPI-C" function get_io_widen_axxPfBDHP51VF5;
  export "DPI-C" function set_io_widen_axxPfBDHP51VF5;
  export "DPI-C" function get_io_widen_bxxPfBDHP51VF5;
  export "DPI-C" function set_io_widen_bxxPfBDHP51VF5;
  export "DPI-C" function get_io_round_modexxPfBDHP51VF5;
  export "DPI-C" function set_io_round_modexxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_formatxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_formatxxPfBDHP51VF5;
  export "DPI-C" function get_io_op_codexxPfBDHP51VF5;
  export "DPI-C" function set_io_op_codexxPfBDHP51VF5;
  export "DPI-C" function get_io_frs1xxPfBDHP51VF5;
  export "DPI-C" function set_io_frs1xxPfBDHP51VF5;
  export "DPI-C" function get_io_is_vecxxPfBDHP51VF5;
  export "DPI-C" function set_io_is_vecxxPfBDHP51VF5;
  export "DPI-C" function get_io_is_frs1xxPfBDHP51VF5;
  export "DPI-C" function set_io_is_frs1xxPfBDHP51VF5;
  export "DPI-C" function get_io_res_wideningxxPfBDHP51VF5;
  export "DPI-C" function set_io_res_wideningxxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_resultxxPfBDHP51VF5;
  export "DPI-C" function get_io_fflagsxxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_aIsFpCanonicalNANxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_aIsFpCanonicalNANxxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_bIsFpCanonicalNANxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_bIsFpCanonicalNANxxPfBDHP51VF5;
  export "DPI-C" function get_io_fp_cIsFpCanonicalNANxxPfBDHP51VF5;
  export "DPI-C" function set_io_fp_cIsFpCanonicalNANxxPfBDHP51VF5;


  function void get_clockxxPfBDHP51VF5;
    output logic  value;
    value=clock;
  endfunction

  function void set_clockxxPfBDHP51VF5;
    input logic  value;
    clock=value;
  endfunction

  function void get_resetxxPfBDHP51VF5;
    output logic  value;
    value=reset;
  endfunction

  function void set_resetxxPfBDHP51VF5;
    input logic  value;
    reset=value;
  endfunction

  function void get_io_firexxPfBDHP51VF5;
    output logic  value;
    value=io_fire;
  endfunction

  function void set_io_firexxPfBDHP51VF5;
    input logic  value;
    io_fire=value;
  endfunction

  function void get_io_fp_axxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_fp_a;
  endfunction

  function void set_io_fp_axxPfBDHP51VF5;
    input logic [63:0] value;
    io_fp_a=value;
  endfunction

  function void get_io_fp_bxxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_fp_b;
  endfunction

  function void set_io_fp_bxxPfBDHP51VF5;
    input logic [63:0] value;
    io_fp_b=value;
  endfunction

  function void get_io_fp_cxxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_fp_c;
  endfunction

  function void set_io_fp_cxxPfBDHP51VF5;
    input logic [63:0] value;
    io_fp_c=value;
  endfunction

  function void get_io_uop_idxxxPfBDHP51VF5;
    output logic  value;
    value=io_uop_idx;
  endfunction

  function void set_io_uop_idxxxPfBDHP51VF5;
    input logic  value;
    io_uop_idx=value;
  endfunction

  function void get_io_widen_axxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_widen_a;
  endfunction

  function void set_io_widen_axxPfBDHP51VF5;
    input logic [63:0] value;
    io_widen_a=value;
  endfunction

  function void get_io_widen_bxxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_widen_b;
  endfunction

  function void set_io_widen_bxxPfBDHP51VF5;
    input logic [63:0] value;
    io_widen_b=value;
  endfunction

  function void get_io_round_modexxPfBDHP51VF5;
    output logic [2:0] value;
    value=io_round_mode;
  endfunction

  function void set_io_round_modexxPfBDHP51VF5;
    input logic [2:0] value;
    io_round_mode=value;
  endfunction

  function void get_io_fp_formatxxPfBDHP51VF5;
    output logic [1:0] value;
    value=io_fp_format;
  endfunction

  function void set_io_fp_formatxxPfBDHP51VF5;
    input logic [1:0] value;
    io_fp_format=value;
  endfunction

  function void get_io_op_codexxPfBDHP51VF5;
    output logic [3:0] value;
    value=io_op_code;
  endfunction

  function void set_io_op_codexxPfBDHP51VF5;
    input logic [3:0] value;
    io_op_code=value;
  endfunction

  function void get_io_frs1xxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_frs1;
  endfunction

  function void set_io_frs1xxPfBDHP51VF5;
    input logic [63:0] value;
    io_frs1=value;
  endfunction

  function void get_io_is_vecxxPfBDHP51VF5;
    output logic  value;
    value=io_is_vec;
  endfunction

  function void set_io_is_vecxxPfBDHP51VF5;
    input logic  value;
    io_is_vec=value;
  endfunction

  function void get_io_is_frs1xxPfBDHP51VF5;
    output logic  value;
    value=io_is_frs1;
  endfunction

  function void set_io_is_frs1xxPfBDHP51VF5;
    input logic  value;
    io_is_frs1=value;
  endfunction

  function void get_io_res_wideningxxPfBDHP51VF5;
    output logic  value;
    value=io_res_widening;
  endfunction

  function void set_io_res_wideningxxPfBDHP51VF5;
    input logic  value;
    io_res_widening=value;
  endfunction

  function void get_io_fp_resultxxPfBDHP51VF5;
    output logic [63:0] value;
    value=io_fp_result;
  endfunction

  function void get_io_fflagsxxPfBDHP51VF5;
    output logic [19:0] value;
    value=io_fflags;
  endfunction

  function void get_io_fp_aIsFpCanonicalNANxxPfBDHP51VF5;
    output logic  value;
    value=io_fp_aIsFpCanonicalNAN;
  endfunction

  function void set_io_fp_aIsFpCanonicalNANxxPfBDHP51VF5;
    input logic  value;
    io_fp_aIsFpCanonicalNAN=value;
  endfunction

  function void get_io_fp_bIsFpCanonicalNANxxPfBDHP51VF5;
    output logic  value;
    value=io_fp_bIsFpCanonicalNAN;
  endfunction

  function void set_io_fp_bIsFpCanonicalNANxxPfBDHP51VF5;
    input logic  value;
    io_fp_bIsFpCanonicalNAN=value;
  endfunction

  function void get_io_fp_cIsFpCanonicalNANxxPfBDHP51VF5;
    output logic  value;
    value=io_fp_cIsFpCanonicalNAN;
  endfunction

  function void set_io_fp_cIsFpCanonicalNANxxPfBDHP51VF5;
    input logic  value;
    io_fp_cIsFpCanonicalNAN=value;
  endfunction



  initial begin
    $dumpfile("VectorFloatFMA.fst");
    $dumpvars(0, VectorFloatFMA_top);
  end

  export "DPI-C" function finish_PfBDHP51VF5;
  function void finish_PfBDHP51VF5;
    $finish;
  endfunction


endmodule
