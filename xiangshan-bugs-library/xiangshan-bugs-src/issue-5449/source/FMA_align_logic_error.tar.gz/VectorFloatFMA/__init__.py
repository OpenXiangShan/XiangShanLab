#coding=utf8

try:
    from . import xspcomm as xsp
except Exception as e:
    import xspcomm as xsp

if __package__ or "." in __name__:
    from .libUT_VectorFloatFMA import *
else:
    from libUT_VectorFloatFMA import *


class DUTVectorFloatFMA(object):

    # initialize
    def __init__(self, *args, **kwargs):
        self.dut = DutUnifiedBase(*args)
        self.xclock = xsp.XClock(self.dut.pxcStep, self.dut.pSelf)
        self.xport  = xsp.XPort()
        self.xclock.Add(self.xport)
        self.event = self.xclock.getEvent()
        self.internal_signals = {}
        self.xcfg = xsp.XSignalCFG(self.dut.GetXSignalCFGPath(), self.dut.GetXSignalCFGBasePtr())
        

        # set output files
        if kwargs.get("waveform_filename"):
            self.dut.SetWaveform(kwargs.get("waveform_filename"))
        if kwargs.get("coverage_filename"):
            self.dut.SetCoverage(kwargs.get("coverage_filename"))

        # All pins
        self.clock = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.reset = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_fire = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_fp_a = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_fp_b = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_fp_c = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_uop_idx = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_widen_a = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_widen_b = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_round_mode = xsp.XPin(xsp.XData(3, xsp.XData.In), self.event)
        self.io_fp_format = xsp.XPin(xsp.XData(2, xsp.XData.In), self.event)
        self.io_op_code = xsp.XPin(xsp.XData(4, xsp.XData.In), self.event)
        self.io_frs1 = xsp.XPin(xsp.XData(64, xsp.XData.In), self.event)
        self.io_is_vec = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_is_frs1 = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_res_widening = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_fp_result = xsp.XPin(xsp.XData(64, xsp.XData.Out), self.event)
        self.io_fflags = xsp.XPin(xsp.XData(20, xsp.XData.Out), self.event)
        self.io_fp_aIsFpCanonicalNAN = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_fp_bIsFpCanonicalNAN = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)
        self.io_fp_cIsFpCanonicalNAN = xsp.XPin(xsp.XData(0, xsp.XData.In), self.event)


        # BindDPI or Native pin address
        self.clock.BindDPIPtr(self.dut.GetDPIHandle("clock", 0), self.dut.GetDPIHandle("clock", 1))
        self.reset.BindDPIPtr(self.dut.GetDPIHandle("reset", 0), self.dut.GetDPIHandle("reset", 1))
        self.io_fire.BindDPIPtr(self.dut.GetDPIHandle("io_fire", 0), self.dut.GetDPIHandle("io_fire", 1))
        self.io_fp_a.BindDPIPtr(self.dut.GetDPIHandle("io_fp_a", 0), self.dut.GetDPIHandle("io_fp_a", 1))
        self.io_fp_b.BindDPIPtr(self.dut.GetDPIHandle("io_fp_b", 0), self.dut.GetDPIHandle("io_fp_b", 1))
        self.io_fp_c.BindDPIPtr(self.dut.GetDPIHandle("io_fp_c", 0), self.dut.GetDPIHandle("io_fp_c", 1))
        self.io_uop_idx.BindDPIPtr(self.dut.GetDPIHandle("io_uop_idx", 0), self.dut.GetDPIHandle("io_uop_idx", 1))
        self.io_widen_a.BindDPIPtr(self.dut.GetDPIHandle("io_widen_a", 0), self.dut.GetDPIHandle("io_widen_a", 1))
        self.io_widen_b.BindDPIPtr(self.dut.GetDPIHandle("io_widen_b", 0), self.dut.GetDPIHandle("io_widen_b", 1))
        self.io_round_mode.BindDPIPtr(self.dut.GetDPIHandle("io_round_mode", 0), self.dut.GetDPIHandle("io_round_mode", 1))
        self.io_fp_format.BindDPIPtr(self.dut.GetDPIHandle("io_fp_format", 0), self.dut.GetDPIHandle("io_fp_format", 1))
        self.io_op_code.BindDPIPtr(self.dut.GetDPIHandle("io_op_code", 0), self.dut.GetDPIHandle("io_op_code", 1))
        self.io_frs1.BindDPIPtr(self.dut.GetDPIHandle("io_frs1", 0), self.dut.GetDPIHandle("io_frs1", 1))
        self.io_is_vec.BindDPIPtr(self.dut.GetDPIHandle("io_is_vec", 0), self.dut.GetDPIHandle("io_is_vec", 1))
        self.io_is_frs1.BindDPIPtr(self.dut.GetDPIHandle("io_is_frs1", 0), self.dut.GetDPIHandle("io_is_frs1", 1))
        self.io_res_widening.BindDPIPtr(self.dut.GetDPIHandle("io_res_widening", 0), self.dut.GetDPIHandle("io_res_widening", 1))
        self.io_fp_result.BindDPIPtr(self.dut.GetDPIHandle("io_fp_result", 0), self.dut.GetDPIHandle("io_fp_result", 1))
        self.io_fflags.BindDPIPtr(self.dut.GetDPIHandle("io_fflags", 0), self.dut.GetDPIHandle("io_fflags", 1))
        self.io_fp_aIsFpCanonicalNAN.BindDPIPtr(self.dut.GetDPIHandle("io_fp_aIsFpCanonicalNAN", 0), self.dut.GetDPIHandle("io_fp_aIsFpCanonicalNAN", 1))
        self.io_fp_bIsFpCanonicalNAN.BindDPIPtr(self.dut.GetDPIHandle("io_fp_bIsFpCanonicalNAN", 0), self.dut.GetDPIHandle("io_fp_bIsFpCanonicalNAN", 1))
        self.io_fp_cIsFpCanonicalNAN.BindDPIPtr(self.dut.GetDPIHandle("io_fp_cIsFpCanonicalNAN", 0), self.dut.GetDPIHandle("io_fp_cIsFpCanonicalNAN", 1))


        # Add2Port
        self.xport.Add("clock", self.clock.xdata)
        self.xport.Add("reset", self.reset.xdata)
        self.xport.Add("io_fire", self.io_fire.xdata)
        self.xport.Add("io_fp_a", self.io_fp_a.xdata)
        self.xport.Add("io_fp_b", self.io_fp_b.xdata)
        self.xport.Add("io_fp_c", self.io_fp_c.xdata)
        self.xport.Add("io_uop_idx", self.io_uop_idx.xdata)
        self.xport.Add("io_widen_a", self.io_widen_a.xdata)
        self.xport.Add("io_widen_b", self.io_widen_b.xdata)
        self.xport.Add("io_round_mode", self.io_round_mode.xdata)
        self.xport.Add("io_fp_format", self.io_fp_format.xdata)
        self.xport.Add("io_op_code", self.io_op_code.xdata)
        self.xport.Add("io_frs1", self.io_frs1.xdata)
        self.xport.Add("io_is_vec", self.io_is_vec.xdata)
        self.xport.Add("io_is_frs1", self.io_is_frs1.xdata)
        self.xport.Add("io_res_widening", self.io_res_widening.xdata)
        self.xport.Add("io_fp_result", self.io_fp_result.xdata)
        self.xport.Add("io_fflags", self.io_fflags.xdata)
        self.xport.Add("io_fp_aIsFpCanonicalNAN", self.io_fp_aIsFpCanonicalNAN.xdata)
        self.xport.Add("io_fp_bIsFpCanonicalNAN", self.io_fp_bIsFpCanonicalNAN.xdata)
        self.xport.Add("io_fp_cIsFpCanonicalNAN", self.io_fp_cIsFpCanonicalNAN.xdata)


        # Cascaded ports
        self.io = self.xport.NewSubPort("io_")
        self.io_fp = self.xport.NewSubPort("io_fp_")
        self.io_is = self.xport.NewSubPort("io_is_")
        self.io_widen = self.xport.NewSubPort("io_widen_")


    def __del__(self):
        self.Finish()

    ################################
    #         User APIs            #
    ################################
    def InitClock(self, name: str):
        self.xclock.Add(self.xport[name])

    def Step(self, i:int = 1):
        self.xclock.Step(i)

    def StepRis(self, callback, args=(), kwargs={}):
        self.xclock.StepRis(callback, args, kwargs)

    def StepFal(self, callback, args=(), kwargs={}):
        self.xclock.StepFal(callback, args, kwargs)

    def ResumeWaveformDump(self):
        return self.dut.ResumeWaveformDump()

    def PauseWaveformDump(self):
        return self.dut.PauseWaveformDump()

    def WaveformPaused(self) -> int:
        """ Returns 1 if waveform export is paused """
        return self.dut.WaveformPaused()

    def GetXPort(self):
        return self.xport

    def GetXClock(self):
        return self.xclock

    def SetWaveform(self, filename: str):
        self.dut.SetWaveform(filename)

    def GetWaveFormat(self) -> str:
        """
        Get the waveform extension, or an empty string if disabled.

        Returns:
            str: The extension of waveform file.
        """
        return self.dut.GetWaveFormat()

    def FlushWaveform(self):
        self.dut.FlushWaveform()

    def SetCoverage(self, filename: str):
        self.dut.SetCoverage(filename)

    def GetCovMetrics(self) -> int:
        """
        Get the bitmask for collected coverage metrics. 0 means coverage is disabled

        Returns:
            int: Collected coverage metrics bitmask:
                - Bit 0: line   (Line coverage)
                - Bit 1: cond   (Condition coverage)
                - Bit 2: fsm    (Finite-State Machine coverage)
                - Bit 3: toggle (Toggle coverage)
                - Bit 4: branch (Branch coverage)
                - Bit 5: assert (Assertion coverage)
        """
        return self.dut.GetCovMetrics()
    
    def CheckPoint(self, name: str) -> int:
        self.dut.CheckPoint(name)

    def Restore(self, name: str) -> int:
        self.dut.Restore(name)

    def GetInternalSignal(self, name: str, index=-1, is_array=False, use_vpi=False):
        if name not in self.internal_signals:
            signal = None
            if self.dut.GetXSignalCFGBasePtr() != 0 and not use_vpi:
                xname = "CFG:" + name
                if is_array:
                    assert index < 0, "Index is not supported for array signal"
                    signal = self.xcfg.NewXDataArray(name, xname)
                elif index >= 0:
                    signal = self.xcfg.NewXData(name, index, xname)
                else:
                    signal = self.xcfg.NewXData(name, xname)
            else:
                assert index < 0, "Index is not supported for VPI signal"
                assert not is_array, "Array is not supported for VPI signal"
                signal = xsp.XData.FromVPI(self.dut.GetVPIHandleObj(name),
                                           self.dut.GetVPIFuncPtr("vpi_get"),
                                           self.dut.GetVPIFuncPtr("vpi_get_value"),
                                           self.dut.GetVPIFuncPtr("vpi_put_value"), "VPI:" + name)
                if use_vpi:
                    assert signal is not None, f"Internal signal {name} not found (Check VPI is enabled)"
            if signal is None:
                return None
            if not isinstance(signal, xsp.XData):
                self.internal_signals[name] = [xsp.XPin(s, self.event) for s in signal]
            else:
                self.internal_signals[name] = xsp.XPin(signal, self.event)
        return self.internal_signals[name]

    def GetInternalSignalList(self, prefix="", deep=99, use_vpi=False):
        if self.dut.GetXSignalCFGBasePtr() != 0 and not use_vpi:
            return self.xcfg.GetSignalNames(prefix)
        else:
            return self.dut.VPIInternalSignalList(prefix, deep)

    def VPIInternalSignalList(self, prefix="", deep=99):
        return self.dut.VPIInternalSignalList(prefix, deep)

    def Finish(self):
        self.dut.Finish()

    def RefreshComb(self):
        self.dut.RefreshComb()

    ################################
    #      End of User APIs        #
    ################################

    def __getitem__(self, key):
        return xsp.XPin(self.port[key], self.event)

    # Async APIs wrapped from XClock
    async def AStep(self,i: int):
        return await self.xclock.AStep(i)

    async def ACondition(self,fc_cheker):
        return await self.xclock.ACondition(fc_cheker)

    def RunStep(self,i: int):
        return self.xclock.RunStep(i)

    def __setattr__(self, name, value):
        assert not isinstance(getattr(self, name, None),
                              (xsp.XPin, xsp.XData)), \
        f"XPin and XData of DUT are read-only, do you mean to set the value of the signal? please use `{name}.value = ` instead."
        return super().__setattr__(name, value)


if __name__=="__main__":
    dut=DUTVectorFloatFMA()
    dut.Step(100)
