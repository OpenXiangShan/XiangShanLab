try:
    from UT_VectorFloatFMA import *
except:
    try:
        from VectorFloatFMA import *
    except:
        from __init__ import *


if __name__ == "__main__":
    dut = DUTVectorFloatFMA()
    # dut.InitClock("clk")

    dut.Step(1)

    dut.Finish()
