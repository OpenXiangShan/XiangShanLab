module VectorFloatFMA_top;

  wire  clock;
  wire  reset;
  wire  io_fire;
  wire [63:0] io_fp_a;
  wire [63:0] io_fp_b;
  wire [63:0] io_fp_c;
  wire  io_uop_idx;
  wire [63:0] io_widen_a;
  wire [63:0] io_widen_b;
  wire [2:0] io_round_mode;
  wire [1:0] io_fp_format;
  wire [3:0] io_op_code;
  wire [63:0] io_frs1;
  wire  io_is_vec;
  wire  io_is_frs1;
  wire  io_res_widening;
  wire [63:0] io_fp_result;
  wire [19:0] io_fflags;
  wire  io_fp_aIsFpCanonicalNAN;
  wire  io_fp_bIsFpCanonicalNAN;
  wire  io_fp_cIsFpCanonicalNAN;


 VectorFloatFMA VectorFloatFMA(
    .clock(clock),
    .reset(reset),
    .io_fire(io_fire),
    .io_fp_a(io_fp_a),
    .io_fp_b(io_fp_b),
    .io_fp_c(io_fp_c),
    .io_uop_idx(io_uop_idx),
    .io_widen_a(io_widen_a),
    .io_widen_b(io_widen_b),
    .io_round_mode(io_round_mode),
    .io_fp_format(io_fp_format),
    .io_op_code(io_op_code),
    .io_frs1(io_frs1),
    .io_is_vec(io_is_vec),
    .io_is_frs1(io_is_frs1),
    .io_res_widening(io_res_widening),
    .io_fp_result(io_fp_result),
    .io_fflags(io_fflags),
    .io_fp_aIsFpCanonicalNAN(io_fp_aIsFpCanonicalNAN),
    .io_fp_bIsFpCanonicalNAN(io_fp_bIsFpCanonicalNAN),
    .io_fp_cIsFpCanonicalNAN(io_fp_cIsFpCanonicalNAN)
 );


endmodule
