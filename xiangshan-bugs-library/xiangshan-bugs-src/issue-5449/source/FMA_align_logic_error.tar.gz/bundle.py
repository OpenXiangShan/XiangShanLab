"""
VectorFloatFMA Bundle 定义
定义 DUT 的所有输入输出信号接口
"""

from toffee import Bundle, Signals


class VectorFloatFMABundle(Bundle):
    """向量浮点乘加融合模块接口定义"""
    
    # 不包含时钟和复位信号 - 它们由 Toffee 框架管理
    # clock, reset = Signals(2)  # 移除这一行
    
    # 输入信号
    io_fp_a, io_fp_b, io_fp_c = Signals(3)  # 64位源操作数
    io_fire = Signals(1)  # 输入有效信号
    io_round_mode = Signals(1)  # 3位舍入模式
    io_fp_format = Signals(1)  # 2位浮点格式
    io_op_code = Signals(1)  # 4位操作码
    
    # 固定为特定值的输入信号（本次验证不使用）
    io_is_vec = Signals(1)  # 固定为1
    io_widen_a, io_widen_b = Signals(2)  # 固定为0
    io_frs1 = Signals(1)  # 固定为0
    io_is_frs1 = Signals(1)  # 固定为0
    io_uop_idx = Signals(1)  # 固定为0
    io_res_widening = Signals(1)  # 固定为0
    io_fp_aIsFpCanonicalNAN = Signals(1)  # 固定为0
    io_fp_bIsFpCanonicalNAN = Signals(1)  # 固定为0
    io_fp_cIsFpCanonicalNAN = Signals(1)  # 固定为0
    
    # 输出信号
    io_fp_result = Signals(1)  # 64位计算结果
    io_fflags = Signals(1)  # 20位异常标志位
    
    def set_fixed_signals(self):
        """设置固定值的信号"""
        self.io_is_vec.value = 1
        self.io_widen_a.value = 0
        self.io_widen_b.value = 0
        self.io_frs1.value = 0
        self.io_is_frs1.value = 0
        self.io_uop_idx.value = 0
        self.io_res_widening.value = 0
        self.io_fp_aIsFpCanonicalNAN.value = 0
        self.io_fp_bIsFpCanonicalNAN.value = 0
        self.io_fp_cIsFpCanonicalNAN.value = 0
