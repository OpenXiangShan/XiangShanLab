import pytest
import toffee_test
from toffee import start_clock
import struct
import math

from bundle import VectorFloatFMABundle
from env import VectorFloatFMAEnv

try:
    from VectorFloatFMA.libUT_VectorFloatFMA import DUTVectorFloatFMA
except ImportError:
    from VectorFloatFMA import DUTVectorFloatFMA


def float64_to_bits(f):
    """将双精度浮点数转换为64位整数表示"""
    return struct.unpack('Q', struct.pack('d', f))[0]


def bits_to_float64(bits):
    """将64位整数转换为双精度浮点数"""
    return struct.unpack('d', struct.pack('Q', bits))[0]


async def reset_env(env):
    """复位环境"""
    env.dut.reset.value = 1
    env.bundle.io_fire.value = 0
    await env.bundle.step(3)
    env.dut.reset.value = 0
    await env.bundle.step(2)

@toffee_test.fixture
async def env(toffee_request):
    """初始化测试环境"""
    dut = toffee_request.create_dut(DUTVectorFloatFMA, "clock")
    start_clock(dut)
    bundle = VectorFloatFMABundle().bind(dut)
    dut.reset.value = 1
    bundle.io_fire.value = 0
    return VectorFloatFMAEnv(bundle, dut)

@toffee_test.testcase
async def test_fma_c_dominates_prod_f64_fix(env):
    """
    Input: FP64 (Double Precision)
    """
    await reset_env(env)

    # Product = 1.0 * 2.0 = 2.0 (Exponent = 1024, Bias=1023+1)
    val_a = 1.0
    val_b = 2.0
    val_prod = 2.0
    
    val_c = 2.0**60 
    
    a_bits = float64_to_bits(val_a)
    b_bits = float64_to_bits(val_b)
    c_bits = float64_to_bits(val_c)

    fmt_double = 1 
    
    print(f"\n[Test Setup] Testing FMA F64 Bug:")
    print(f"  A={val_a}, B={val_b} -> Prod={val_prod}")
    print(f"  C={val_c:.4e} (2^60)")
    print(f"  Expected Result: {val_c:.4e} (Product implies no change to C due to precision)")

    result = await env.agent.exec_macc(a_bits, b_bits, c_bits, fp_format=fmt_double, round_mode=0)
    
    result_bits = result['fp_result']
    result_float = bits_to_float64(result_bits)

    print(f"  Actual Result: {result_float:.4e} (Hex: 0x{result_bits:016X})")

    
    expected = val_c
    
    assert math.isclose(result_float, expected, rel_tol=1e-15), \
            f"BUG DETECTED: F64 alignment logic failed.\nExpected value: {expected}\nActual value: {result_float}\n" \
            f"Analysis: The result differs significantly from C, indicating that the adder directly added the product to C without alignment."

    print("  ✓ Test Passed: Large C handled correctly in F64 path")