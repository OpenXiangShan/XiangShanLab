"""
VectorFloatFMA Agent 定义
实现驱动方法和监测方法
"""

from toffee import Agent, driver_method, monitor_method


class VectorFloatFMAAgent(Agent):
    """向量浮点乘加融合模块驱动器"""
    
    def __init__(self, bundle):
        super().__init__(bundle)
        self.bundle.set_fixed_signals()
        
    @driver_method()
    async def exec_fma(self, fp_a, fp_b, fp_c, op_code, fp_format, round_mode):
        """
        执行浮点乘加操作
        
        Args:
            fp_a: 源操作数 vs2 (64位)
            fp_b: 源操作数 vs1 (64位)
            fp_c: 源操作数 vd (64位)
            op_code: 操作码 (0-8)
            fp_format: 浮点格式 (1=FP16, 2=FP32, 3=FP64)
            round_mode: 舍入模式 (0-4)
            
        Returns:
            dict: 包含结果和标志位的字典
        """
        # 设置输入信号
        # print(f"DEBUG: Setting io_fp_a = {fp_a:016x}")
        # print(f"DEBUG: Setting io_fp_b = {fp_b:016x}")
        # print(f"DEBUG: Setting io_fp_c = {fp_c:016x}")
        # print(f"DEBUG: Setting op_code = {op_code}, fp_format = {fp_format}, round_mode = {round_mode}")
        
        self.bundle.io_fp_a.value = fp_a
        self.bundle.io_fp_b.value = fp_b
        self.bundle.io_fp_c.value = fp_c
        self.bundle.io_op_code.value = op_code
        self.bundle.io_fp_format.value = fp_format
        self.bundle.io_round_mode.value = round_mode
        self.bundle.io_fire.value = 1
        
        # fire 信号拉高 1 个周期，保持与 start_clock 的额外监测周期对齐
        await self.bundle.step()
        self.bundle.io_fire.value = 0

        # 4 级流水线 + start_clock 额外的监测周期
        for _ in range(5):
            await self.bundle.step()
        
        # 读取结果
        result_value = self.bundle.io_fp_result.value
        fflags_value = self.bundle.io_fflags.value
        # print(f"DEBUG: Got io_fp_result = {result_value:016x}, io_fflags = {fflags_value:05x}")
        
        result = {
            'fp_result': result_value,
            'fflags': fflags_value,
            'inputs': {
                'fp_a': fp_a,
                'fp_b': fp_b,
                'fp_c': fp_c,
                'op_code': op_code,
                'fp_format': fp_format,
                'round_mode': round_mode
            }
        }
        
        return result
    
    @driver_method()
    async def exec_mul(self, fp_a, fp_b, fp_format=3, round_mode=0):
        """
        执行浮点乘法操作 (vfmul: vd = vs2 * vs1)
        
        Args:
            fp_a: 源操作数 vs2
            fp_b: 源操作数 vs1
            fp_format: 浮点格式 (默认FP64)
            round_mode: 舍入模式 (默认RNE)
        """
        return await self.exec_fma(fp_a, fp_b, 0, op_code=0, 
                                   fp_format=fp_format, round_mode=round_mode)
    
    @driver_method()
    async def exec_macc(self, fp_a, fp_b, fp_c, fp_format=3, round_mode=0):
        """
        执行浮点乘加操作 (vfmacc: vd = +(vs2*vs1) + vd)
        
        Args:
            fp_a: 源操作数 vs2
            fp_b: 源操作数 vs1
            fp_c: 源操作数 vd
            fp_format: 浮点格式 (默认FP64)
            round_mode: 舍入模式 (默认RNE)
        """
        return await self.exec_fma(fp_a, fp_b, fp_c, op_code=1, 
                                   fp_format=fp_format, round_mode=round_mode)
    
    @driver_method()
    async def exec_nmacc(self, fp_a, fp_b, fp_c, fp_format=3, round_mode=0):
        """
        执行浮点负乘负加操作 (vfnmacc: vd = -(vs2*vs1) - vd)
        """
        return await self.exec_fma(fp_a, fp_b, fp_c, op_code=2, 
                                   fp_format=fp_format, round_mode=round_mode)
    
    @driver_method()
    async def exec_msac(self, fp_a, fp_b, fp_c, fp_format=3, round_mode=0):
        """
        执行浮点乘减操作 (vfmsac: vd = +(vs2*vs1) - vd)
        """
        return await self.exec_fma(fp_a, fp_b, fp_c, op_code=3, 
                                   fp_format=fp_format, round_mode=round_mode)
    
    @driver_method()
    async def exec_nmsac(self, fp_a, fp_b, fp_c, fp_format=3, round_mode=0):
        """
        执行浮点负乘加操作 (vfnmsac: vd = -(vs2*vs1) + vd)
        """
        return await self.exec_fma(fp_a, fp_b, fp_c, op_code=4, 
                                   fp_format=fp_format, round_mode=round_mode)
