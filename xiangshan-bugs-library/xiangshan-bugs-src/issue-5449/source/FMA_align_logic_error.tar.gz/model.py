"""
VectorFloatFMA Reference Model
使用 Python 的浮点运算作为参考模型，包含异常标志位计算
"""

from toffee import Model, driver_hook
import struct
import math


# IEEE 754 异常标志位定义（RISC-V fflags）
class FFlags:
    NV = 0x10  # Invalid operation (bit 4)
    DZ = 0x08  # Divide by zero (bit 3)
    OF = 0x04  # Overflow (bit 2)
    UF = 0x02  # Underflow (bit 1)
    NX = 0x01  # Inexact (bit 0)


class VectorFloatFMAModel(Model):
    """向量浮点乘加融合参考模型"""
    
    def __init__(self):
        super().__init__()
        
    def _int_to_float64(self, val):
        """将64位整数转换为双精度浮点数"""
        return struct.unpack('d', struct.pack('Q', val))[0]
    
    def _float64_to_int(self, val):
        """将双精度浮点数转换为64位整数"""
        return struct.unpack('Q', struct.pack('d', val))[0]
    
    def _int_to_float32(self, val):
        """将32位整数转换为单精度浮点数"""
        return struct.unpack('f', struct.pack('I', val & 0xFFFFFFFF))[0]
    
    def _float32_to_int(self, val):
        """将单精度浮点数转换为32位整数"""
        return struct.unpack('I', struct.pack('f', val))[0]
    
    def _is_nan(self, val):
        """检查是否为 NaN"""
        return math.isnan(val)
    
    def _is_inf(self, val):
        """检查是否为无穷大"""
        return math.isinf(val)
    
    def _is_subnormal_f32(self, bits):
        """检查 FP32 是否为次正规数"""
        exp = (bits >> 23) & 0xFF
        mantissa = bits & 0x7FFFFF
        return exp == 0 and mantissa != 0
    
    def _is_subnormal_f64(self, bits):
        """检查 FP64 是否为次正规数"""
        exp = (bits >> 52) & 0x7FF
        mantissa = bits & 0xFFFFFFFFFFFFF
        return exp == 0 and mantissa != 0
    
    def _compute_fma_with_flags(self, a, b, c, op_code, fp_format):
        """
        计算FMA操作的参考结果和异常标志位
        
        Args:
            a, b, c: 浮点数
            op_code: 操作码
            fp_format: 浮点格式 (2=FP32, 3=FP64)
            
        Returns:
            (result, flags): 计算结果和异常标志位
        """
        flags = 0
        
        # 检查输入是否为 NaN（产生 Invalid 标志）
        if self._is_nan(a) or self._is_nan(b) or (op_code != 0 and self._is_nan(c)):
            # 返回 quiet NaN
            if fp_format == 2:
                return (float('nan'), FFlags.NV)
            else:
                return (float('nan'), FFlags.NV)
        
        # 检查 Inf * 0 的情况（Invalid）
        if (self._is_inf(a) and b == 0) or (a == 0 and self._is_inf(b)):
            return (float('nan'), FFlags.NV)
        
        # 计算乘法部分
        product = a * b
        
        # 根据操作码计算最终结果
        if op_code == 0:  # vfmul: vd = vs2 * vs1
            result = product
        elif op_code == 1:  # vfmacc: vd = +(vs2*vs1) + vd
            # 检查 Inf + (-Inf) 的情况
            if self._is_inf(product) and self._is_inf(c) and (product > 0) != (c > 0):
                return (float('nan'), FFlags.NV)
            result = product + c
        elif op_code == 2:  # vfnmacc: vd = -(vs2*vs1) - vd
            neg_product = -product
            neg_c = -c
            if self._is_inf(neg_product) and self._is_inf(neg_c) and (neg_product > 0) != (neg_c > 0):
                return (float('nan'), FFlags.NV)
            result = neg_product + neg_c
        elif op_code == 3:  # vfmsac: vd = +(vs2*vs1) - vd
            neg_c = -c
            if self._is_inf(product) and self._is_inf(neg_c) and (product > 0) != (neg_c > 0):
                return (float('nan'), FFlags.NV)
            result = product + neg_c
        elif op_code == 4:  # vfnmsac: vd = -(vs2*vs1) + vd
            neg_product = -product
            if self._is_inf(neg_product) and self._is_inf(c) and (neg_product > 0) != (c > 0):
                return (float('nan'), FFlags.NV)
            result = neg_product + c
        else:
            raise ValueError(f"Unsupported op_code: {op_code}")
        
        # 检查结果标志位
        if self._is_inf(result) and not self._is_inf(a) and not self._is_inf(b) and not self._is_inf(c):
            flags |= FFlags.OF | FFlags.NX  # Overflow 通常也设置 Inexact
        
        return (result, flags)

    def _compute_fma(self, a, b, c, op_code):
        """
        计算FMA操作的参考结果（兼容旧接口）
        """
        result, _ = self._compute_fma_with_flags(a, b, c, op_code, 3)
        return result
    
    @driver_hook(agent_name="agent", driver_name="exec_fma")
    def model_fma(self, fp_a, fp_b, fp_c, op_code, fp_format, round_mode):
        """
        FMA操作的参考模型
        返回预期的结果和标志位
        """
        flags = 0
        
        # 根据格式解析输入
        if fp_format == 3:  # FP64
            a = self._int_to_float64(fp_a)
            b = self._int_to_float64(fp_b)
            c = self._int_to_float64(fp_c)
            
            result, flags = self._compute_fma_with_flags(a, b, c, op_code, fp_format)
            
            # 检查结果是否为次正规数（Underflow）
            result_int = self._float64_to_int(result)
            if self._is_subnormal_f64(result_int):
                flags |= FFlags.UF
            
        elif fp_format == 2:  # FP32 - 处理2个32位数（向量模式）
            # 低32位
            a0 = self._int_to_float32(fp_a & 0xFFFFFFFF)
            b0 = self._int_to_float32(fp_b & 0xFFFFFFFF)
            c0 = self._int_to_float32(fp_c & 0xFFFFFFFF)
            result0, flags0 = self._compute_fma_with_flags(a0, b0, c0, op_code, fp_format)
            result0_int = self._float32_to_int(result0)
            
            # 检查次正规数
            if self._is_subnormal_f32(result0_int):
                flags0 |= FFlags.UF
            
            # 高32位
            a1 = self._int_to_float32(fp_a >> 32)
            b1 = self._int_to_float32(fp_b >> 32)
            c1 = self._int_to_float32(fp_c >> 32)
            result1, flags1 = self._compute_fma_with_flags(a1, b1, c1, op_code, fp_format)
            result1_int = self._float32_to_int(result1)
            
            if self._is_subnormal_f32(result1_int):
                flags1 |= FFlags.UF
            
            result_int = (result1_int << 32) | result0_int
            flags = flags0 | flags1  # 合并两个通道的标志
            
            return {
                'fp_result': result_int,
                'fflags': flags,
                'fflags_lo': flags0,
                'fflags_hi': flags1
            }
        else:
            # FP16等其他格式暂不实现精确验证
            return None
        
        return {
            'fp_result': result_int,
            'fflags': flags
        }
    
    @driver_hook(agent_name="agent", driver_name="exec_mul")
    def model_mul(self, fp_a, fp_b, fp_format, round_mode):
        """乘法操作的参考模型"""
        return self.model_fma(fp_a, fp_b, 0, 0, fp_format, round_mode)
    
    @driver_hook(agent_name="agent", driver_name="exec_macc")
    def model_macc(self, fp_a, fp_b, fp_c, fp_format, round_mode):
        """乘加操作的参考模型"""
        return self.model_fma(fp_a, fp_b, fp_c, 1, fp_format, round_mode)
    
    @driver_hook(agent_name="agent", driver_name="exec_nmacc")
    def model_nmacc(self, fp_a, fp_b, fp_c, fp_format, round_mode):
        """负乘负加操作的参考模型"""
        return self.model_fma(fp_a, fp_b, fp_c, 2, fp_format, round_mode)
    
    @driver_hook(agent_name="agent", driver_name="exec_msac")
    def model_msac(self, fp_a, fp_b, fp_c, fp_format, round_mode):
        """乘减操作的参考模型"""
        return self.model_fma(fp_a, fp_b, fp_c, 3, fp_format, round_mode)
    
    @driver_hook(agent_name="agent", driver_name="exec_nmsac")
    def model_nmsac(self, fp_a, fp_b, fp_c, fp_format, round_mode):
        """负乘加操作的参考模型"""
        return self.model_fma(fp_a, fp_b, fp_c, 4, fp_format, round_mode)
