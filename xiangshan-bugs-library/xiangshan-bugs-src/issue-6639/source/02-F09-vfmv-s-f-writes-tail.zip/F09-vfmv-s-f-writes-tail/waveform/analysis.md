# F09 waveform corroboration

## Comparison with the existing report

The rebuilt, traced DUT reproduces the same element-zero and tail corruption, at the same `cycleCnt=6046`. Its runtime revision is `b9636416b8`, dirty flag `0`; the image and reference library are unchanged. This is a new instrumented emulator, whose hash is recorded in `run.json`.

**The first e64 trace does not support “scalar replication directly overwrote the tail” as the explanation of the final zero result.** The raw move result contains the correct replicated scalar, but the valid merge receives execution-path VL zero and an all-zero old destination. The current issue description already limits its claim to element corruption, so its observable claim is corroborated. The original PoC diagnostic wording must not be promoted to a waveform conclusion.

## Observed chain

All cycles below are falling-edge sample indices in this FST, starting at the first sampled edge including reset. They are not the DUT's `cycleCnt`. Bus values outside valid/enable cycles are not accepted transactions.

| File cycle | Actual observation |
| --- | --- |
| 6105 | Dispatch lane 3 has valid/ready, PC `0x800006cc`, instruction `0x4200d157`, ROB `(flag=0,value=0x13)`, uop 0, destination physical vector register `0x30` (48). |
| 6111 | A flush is present for younger ROB `(0,0x16)`, level 0. The target subsequently executes and commits; it was not discarded. |
| 6116 | The matching EXU input is valid; its execution-path VL is `0`. The selected FP bypass supplies scalar `0x3ff8000000000000`, expanded to `0x3ff80000000000003ff8000000000000`. The unselected FP read-port data is not evidence of the operand. |
| 6117 | VMove is valid for ROB `(0,0x13)` / destination 48 and produces raw vector value `0x3ff80000000000003ff8000000000000`. Merge is valid, `end=0`, `activeEn=0`, `vta=0`; all 16 old-destination bytes and all 16 output bytes are zero. |
| 6118 | Actual vector register-file write port 0 has `wen=1`, address `0x30`, data `0`. |
| 6119 | Physical vector register 48 reads zero. ROB commit lane 0 has `isCommit=1`, `commitValid=1`, target PC `0x800006cc` and ROB `(0,0x13)`. |
| 6120 | The diff snapshot RAT maps architectural `v2` to physical register 48. This is a delayed snapshot, not a same-cycle combinational commit mapping. |

![Actual sampled FST waveform](waveform-evidence.png)

The graph shows actual signals only. Full exact paths and values are in [samples.json](samples.json); the longer window, all merge bytes, flush context and register mapping are in [detail-samples.json](detail-samples.json). The retained [probe samples](probe-samples.json) include the dispatch instruction identity. The command, hashes and replay comparison are in [run.json](run.json). The full raw FST is retained separately in the complete 20260926 evidence archive; this submission includes its extracted samples and figure.

## Interpretation and limits

The trace localizes the zero result to the destination merge inputs/path after a correct scalar move result. The execution-path VL zero is not a claim that the architectural test configured VL zero: the supplied instruction sequence requests VL=2. This trace also shows `vpRen_2=0` for the issue transaction despite a nonzero old-destination physical index; the reason for all affected control/read inputs is not isolated by a fix-and-retest experiment. No unique root cause or single-line remedy is claimed.

The general textual commit `data` field is not used as a vector result. This conclusion uses the actual vector register-file write port, physical state and RAT mapping. Later e32 and second-e64 no-diff cases are separate executions; this first-e64 FST does not supply their internal explanation.

Relevant fixed sources: `BypassNetwork.scala` scalar expansion and bypass selection; `VMove.scala` raw result generation; `Exu.scala` merge inputs/boundary selection; `yunsuan.vector.v2.MergeUnit`; and `RenameTable.scala` diff RAT export. The main [issue description](../issue_description.md) links the relevant fixed-version source and records DUT/reference versions; [run.json](run.json) records the traced run and hashes.
