# vfmv.s.f zeros element zero and an undisturbed tail element

Tested on Kunminghu-v3 `b9636416b8`, `MinimalConfig`, single core, VLEN=128. This issue was not reproduced in the latest Kunminghu-v2 version.

The first e64 case initializes `v2` with bytes `c0..cf` and loads FP64 1.5 (`0x3ff8000000000000`) into `ft1`. After `vfmv.s.f v2,ft1` at PC `0x800006cc`, both 64-bit elements are zero:

```asm
fld       ft1, 0(a2)
vl1re64.v v2, (a1)
vsetivli x0, 2, e64, m1, tu, mu
vfmv.s.f v2, ft1
```

Element 0 should become `0x3ff8000000000000`; element 1 should retain `0xcfcecdcccbcac9c8` under `tu`. Instead, both are `0x0000000000000000`. Only the first e64 execution is covered.

## Evidence

All three seeds reproduce the mismatch: [seed 0 log](logs/replay-20260926/seed0.log) / [metadata](logs/replay-20260926/seed0.json), [seed 1 log](logs/replay-20260926/seed1.log) / [metadata](logs/replay-20260926/seed1.json), [seed 2 log](logs/replay-20260926/seed2.log) / [metadata](logs/replay-20260926/seed2.json).

![Difftest log excerpts](screenshots/runtime-difference.png)

The raw move correctly produces `0x3ff80000000000003ff8000000000000`. The following merge receives execution-path VL/end zero and zero old-destination data, writes zero to the RF, and the target commits. This does **not** show scalar replication directly overwriting the tail.

![Raw move result and zero merge/writeback](waveform/waveform-evidence.png)

Traced replay at the same DUT revision: [full log](waveform/run.log), [metadata](waveform/run.json), [waveform analysis](waveform/analysis.md).

The test requests VL=2; the internal VL zero is a separate observation. The analysis uses actual RF writes and register mapping, not the generic commit `data` field.

## Specification and replay

RISC-V Unprivileged ISA **20240411**, §31.16.2, specifies transfer into element 0, with the remaining elements treated as tail: [official PDF, page 375](https://docs.riscv.org/reference/isa/v20240411/_attachments/riscv-unprivileged.pdf#page=375).

![Specification excerpt](screenshots/spec-page-375.png)

[C test](poc/main.c) · [assembly](poc/probe.S) · [BIN](poc/build/f09-vfmv-s-f-writes-tail-riscv64-xs-light-kunminghu-v3.bin) · [ELF](poc/build/f09-vfmv-s-f-writes-tail-riscv64-xs-light-kunminghu-v3.elf) · [disassembly](poc/build/f09-vfmv-s-f-writes-tail-riscv64-xs-light-kunminghu-v3.txt) · [replay script](replay.sh)

Run `bash replay.sh 0` (then `1` and `2`), with `XS_EMU` and `XS_REF` pointing to the pinned models.
