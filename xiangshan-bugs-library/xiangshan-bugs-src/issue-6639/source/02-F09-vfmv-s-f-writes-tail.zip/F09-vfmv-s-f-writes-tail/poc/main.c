/* F09 -- vfmv.s.f writes zero to element 0 and the undisturbed tail
 * element in the first e64 case. The trace shows a correct raw move
 * result followed by a zero merge result and RF write.
 */
#include "vt-common.h"

static uint8_t preset[16] __attribute__((aligned(16)));
static uint8_t s[16] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f09_vfmv_s_f_e64(void *o, const void *p, const void *s);
extern void f09_vfmv_s_f_e32(void *o, const void *p, const void *s);
static void put64(uint8_t *b, uint64_t v) { for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k)); }

int main(void) {
  int bugs = 0;
  for (int i = 0; i < 16; i++) preset[i] = (uint8_t)(0xC0 + i);
  if (vt_init("F09") != 0) return 1;
  printf("[F09] start cyc=%lu\n", (unsigned long)cyc());

  put64(s, 0x3FF8000000000000UL); /* 1.5 (fp64) */
  memset(out, 0, 16); f09_vfmv_s_f_e64(out, preset, s); VT_FENCE();
  {
    int ok = (out_q(out, 0) == 0x3FF8000000000000UL && out_q(out, 1) == bytes_q(preset + 8));
    if (!ok) bugs++;
    printf("[F09] e64 vl=2 tu: v2=%016lx_%016lx expect=%016lx_%016lx %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           (unsigned long)bytes_q(preset + 8), 0x3FF8000000000000UL,
           ok ? "ok" : "BUG: element 1 overwritten");
  }
  put64(s, 0xFFFFFFFF3FC00000UL); /* 1.5f boxed */
  memset(out, 0, 16); f09_vfmv_s_f_e32(out, preset, s); VT_FENCE();
  {
    uint64_t e0 = (bytes_q(preset) & 0xFFFFFFFF00000000UL) | 0x3FC00000UL;
    int ok = (out_q(out, 0) == e0 && out_q(out, 1) == bytes_q(preset + 8));
    if (!ok) bugs++;
    printf("[F09] e32 vl=4 tu: v2=%016lx_%016lx expect=%016lx_%016lx %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           (unsigned long)bytes_q(preset + 8), (unsigned long)e0,
           ok ? "ok" : "BUG: elements 1..3 overwritten");
  }
  put64(s, 0x3FF8000000000000UL);
  memset(out, 0, 16); f09_vfmv_s_f_e64(out, preset, s); VT_FENCE();
  {
    int ok = (out_q(out, 0) == 0x3FF8000000000000UL && out_q(out, 1) == bytes_q(preset + 8));
    if (!ok) bugs++;
    printf("[F09] e64 vl=2 tu (2nd run): v2=%016lx_%016lx expect=%016lx_%016lx %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           (unsigned long)bytes_q(preset + 8), 0x3FF8000000000000UL,
           ok ? "ok" : "BUG: element 1 overwritten");
  }
  printf("[F09] done bugs=%d verdict=%s\n", bugs, bugs ? "VFMV_S_F_WRITES_TAIL" : "clean");
  return 0;
}
