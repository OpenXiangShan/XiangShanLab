/* F09: vfmv.s.f must write element 0 only. v2 preset from a1, f1 from a2. */
#include "probe-common.S"

  .align 6
  .globl f09_vfmv_s_f_e64
  .type  f09_vfmv_s_f_e64, @function
f09_vfmv_s_f_e64:
  fld f1, 0(a2)
  vl1re64.v v2, (a1)
  vsetivli x0, 2, e64, m1, tu, mu
  vfmv.s.f v2, f1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f09_vfmv_s_f_e64, .-f09_vfmv_s_f_e64

  .align 6
  .globl f09_vfmv_s_f_e32
  .type  f09_vfmv_s_f_e32, @function
f09_vfmv_s_f_e32:
  fld f1, 0(a2)
  vl1re64.v v2, (a1)
  vsetivli x0, 4, e32, m1, tu, mu
  vfmv.s.f v2, f1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f09_vfmv_s_f_e32, .-f09_vfmv_s_f_e32
