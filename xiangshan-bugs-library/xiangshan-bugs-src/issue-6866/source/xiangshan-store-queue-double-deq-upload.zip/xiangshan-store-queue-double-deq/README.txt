xiangshan xiangshan-store-queue-double-deq reproducer
=====================================================

Issue: [BUG] A pre-commit / load-replay redirect race marks a cancelled store as committed, dequeues it into the store buffer, and trips the `double deq!` assertion

Files: 12

Files
-----

README.txt
    This file.

TIMELINE.md
    Annotated timeline around t=1944.
    SHA-256: f37065c49ec607f42dc6302c448f47b7a5de87a19dac1071f7eb44cc7f5ec0e1

comparison.json
    Sanitized DUT-versus-reference record.
    SHA-256: 339fad7330193224ba86d0af32931ff1030e8f3a49fe075a9d9db1fec3d95d05

disassembly.txt
    Full objdump of the reproducer.
    SHA-256: 75da60c262f2c0bb07b4d6fc2c4f777c663215cd7866bda06fc985c765d50a18

head-a0c2a26cbe.log
    Abort log of a re-run on the default-branch HEAD.
    SHA-256: 4c2f29cd1c6f0805c31d0d5d2f862f4267df38c81cd7f9d2721ed1d95da5e5e7

image.bin
    Raw memory image loaded by the emulator.
    SHA-256: c87ccde4bc306a0eb9096ab27dae0ee53f5f1f7c933ac89bae8e62fa82573de8

oracle.md
    Reference/comparison description (renamed).
    SHA-256: f29db4ad05eb42c58a9a476ed140f636385ec5c0222d30d8c66bc969062d32a3

prog.S
    Reproducer source (riscv-tests 2-stage_translation).
    SHA-256: 6faec336d2047f47d2cd812a6ab8ef1015ef3b93ba2623206d2058e0172e8b8d

prog.elf
    Reproducer ELF (binary).
    SHA-256: efab33369a6ccd16461323e093cd95aaaeedfad7e8edf227e0fba25615c22283

signals.csv
    Signal samples for the same window.
    SHA-256: 902770c17f081d15e46626d9cf7393d2face5a54c9f5a85851ce48095b87c199

sim.log
    Abort log of the recorded revision.
    SHA-256: 469970e076a063c07b41fb84ffc080e1fc2837210c09599b950327414662b8c0

wave.fst
    FST waveform, window 1929-1945.
    SHA-256: 57666106eb38261ab882da2872ef50808317679de2911da72958c34283dc3a22

Reproduction summary
--------------------

- Build the VS-stage and G-stage page tables, write vsatp and hgatp, then hfence.vvma / hfence.gvma.
- Execute the sw and the hlv.w at 0x800002f8; the load replay issues a redirect with robIdx = 75 covering store-queue entry 11.
- Run the ELF on KMHv3 with the store-queue assertions enabled; the simulation aborts at double deq! index: 11.
- Run the same ELF on KMHv2 and compare: the program completes with a0 = 0.

Expected:
  The store squashed by the redirect must not enter the store buffer and must not consume dequeue credit. The same ELF passes on KMHv2 (a0 = 0, 2585 cycles).

Observed:
  Assertion abort at PhysicalStoreQueue.sv:17820, double deq! index: 11, instrCnt = 162, cycleCnt = 1,945.

Notes
-----

- Full run manifests, code-evidence markdown, waveform analysis JSON,
  symbol tables, and raw instruction traces are omitted because their
  headers contain internal paths.
- Absolute paths in the remaining text files have been replaced by
  file names; the objdump header now names prog.elf.
- A local Spike build is not usable as an oracle for this case: it lacks the Smrnmi CSR 0x744 used during initialization.
