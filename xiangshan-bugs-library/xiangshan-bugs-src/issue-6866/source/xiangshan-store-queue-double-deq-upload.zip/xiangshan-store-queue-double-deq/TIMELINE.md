# 波形时间线：xiangshan-store-queue-double-deq

- 波形：`wave.fst`（FST，窗口 1929–1945）
- 锚点：t=1944
- 采样方式：直接读取 value-change（`TOP.clock` 无下降沿，不按时钟聚合）
- 断言日志时间：快照 `time=1949`；head `time=1947`。波形的 t 是采样时间，比日志早几拍。

## 关键时间线

| t | raw_redirect_valid | redirectReg_valid | preCommitPtr_valid | preCommitPtr | committed_11 | needCancel_11 | addrValid_11 | dataValid_11 | deqCancel_11 | sqDeqCnt | sbuf0_valid | sbuf0_ready | deqPtr_0 | deqPtr_1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1929 | 0 | 0 | 1 | 12 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1930 | 0 | 0 | 1 | 12 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1931 | 0 | 0 | 1 | 12 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1932 | 0 | 0 | 1 | 12 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1933 | 0 | 0 | 1 | 12 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1934 | 1 | 0 | 1 | 12 | 1 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 11 | 12 |
| 1935 | 0 | 1 | 0 | 12 | 1 | 0 | 1 | 1 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1936 | 0 | 0 | 1 | 12 | 1 | 0 | 1 | 1 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1937 | 0 | 0 | 0 | 12 | 1 | 0 | 1 | 1 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1938 | 0 | 0 | 0 | 12 | 1 | 0 | 1 | 1 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1939 | 0 | 0 | 0 | 12 | 1 | 1 | 1 | 1 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1940 | 0 | 0 | 0 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1941 | 0 | 0 | 0 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1942 | 0 | 0 | 0 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 11 | 12 |
| 1943 | 0 | 0 | 0 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 11 | 12 |
| 1944 | 0 | 0 | 0 | 12 | 1 | 0 | 0 | 0 | 1 | 1 | 0 | 1 | 11 | 12 |
| 1945 | 0 | 0 | 0 | 12 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 12 | 13 |

## 读法

1. t=1929：store 地址 stage 分配表项 11。
2. t=1934：raw redirect 到达 VSQ（`raw_redirect_valid=1`），但 `redirectReg_valid` 还是 0。
   同一拍 `preCommitPtr_valid=1`、`preCommitPtr=12`，表项 11 被置 `committed=1`。
3. t=1935：`redirectReg_valid=1`，pre-commit 被屏蔽。但表项已经 committed。
   同一拍 `sbuf0_valid=1`，表项开始向 Sbuffer 请求写入。
4. t=1939：`needCancel_11=1`。
5. t=1940：`addrValid_11=0`、`dataValid_11=0`，但 `committed_11=1`。
6. t=1943：`sbuf0_valid=1`、`sbuf0_ready=1`，Sbuffer 接受写入，产生 dequeue credit。
7. t=1944：`sqDeqCnt=1`、`deqCancel_11=1`、`addrValid_11=0`、`vecInactive_11=0`，断言触发。
8. t=1945：`deqPtr_0/1` 从 11/12 推进到 12/13。

## 结论

- 关键窗口是 t=1934 到 t=1935：pre-commit 用晚一拍的 `redirectReg.valid` 做屏蔽，漏掉了同一拍的 raw redirect。
- 表项 11 先被 commit，再被 redirect 取消，最后仍然出队。
- 断言只是最后一步的症状。

完整信号集见 `signals.csv`。
