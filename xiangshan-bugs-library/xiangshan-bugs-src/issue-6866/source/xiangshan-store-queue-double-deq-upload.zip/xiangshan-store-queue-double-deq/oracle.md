# 独立模型对照：store queue double deq

## 本用例的 oracle 选择

程序是 riscv-tests 的 `hypervisor/2-stage_translation`，使用本仓库的出口补丁
（`riscv-tests.patch`）。补丁把退出方式改成
“`a0`=0 通过 / `a0`=TESTNUM 自检失败”，并在 `TESTNUM==1` 时按通过处理 `scall`。

期望行为：

> 这条普通 store 被 load replay redirect squash 后，不得再出队，也不得写 Sbuffer。
> 程序应正常提交或产生架构异常，不应触发 store queue 的内部不变量。

## Spike 结果：不可用（环境缺少 CSR）

```console
$ spike --isa=rv64gch --priv=msu -m0x80000000:0x10000000 prog.elf
core 0: exception trap_illegal_instruction, epc 0x00000000800000f0
```

反汇编在 `0x800000f0` 处是：

```
800000f0: 74445073    csrwi 0x744, 8     # mnstatus（Smrnmi）
```

本地 Spike 构建不支持 CSR `0x744`，因此程序在初始化阶段即报非法指令，**不能**作为本用例的 oracle。

## 采用的差分 oracle

同一份 `prog.elf`（sha256 见 `manifest.json`）在 **KMHv2** 上通过：

| DUT | 结果 | 记录 |
| --- | --- | --- |
| KMHv3（`TestkitV3Config`） | `error`（断言 abort，`double deq! index: 11`） | `run/` |
| KMHv2（`TestkitCmoConfig`） | `pass`（`a0=0`，2585 cycles） | `<run>` |

两版共用同一套测试生成器、同一份 ELF、同一套观察者（`difftest` 提交信息），差异只在
DUT 的 store queue 实现（KMHv3 换成 `NewStoreQueue`）。因此“KMHv2 通过、KMHv3 断言退出”
已经排除了测试与观察者因素。

## HEAD 复跑

默认分支 `a0c2a26cbe3c862175174bad03a1a23c406315ed` 上仍复现：

```
[ERROR][time=1947] ...physicalQueue: double deq! index: 11
```

日志见 `head-a0c2a26cbe.log`。该 commit 已包含 #6768 与 #6769，因此不是这两个
PR 的覆盖面。

## 备注

- riscv-tests 上游对该测试的断言语义是“两阶段翻译下 load/store 正常完成”，没有对本
  实现内部不变量的要求；这里判定的是 KMHv3 自己声明的不变量被打破。
- 本用例没有缺 fence。触发 redirect 的是正常的 `hlv.w` load replay，不是软件顺序错误。
