# kunminghu-v3 @ c8d7b3a5c: VirtualStoreQueue "retirePtr update error!" + core stall
# after a multi-register segmented vector store followed by an AMO.
# Plain riscv-tests env-p program (M-mode). Build:
#   riscv64-unknown-elf-gcc -march=rv64gcv -mabi=lp64 -static -mcmodel=medany -nostdlib -nostartfiles \
#       -I env -I env/p -T env/link.ld vsq_segstore_amo.S -o vsq_segstore_amo.elf
#include "riscv_test.h"
RVTEST_RV64M
RVTEST_CODE_BEGIN
        li      t0, MSTATUS_VS
        csrs    mstatus, t0             # enable the vector unit
        vsetvli t0, x0, e64, m8, ta, ma # zero all 32 vector registers first
        vmv.v.i v0, 0
        vmv.v.i v8, 0
        vmv.v.i v16, 0
        vmv.v.i v24, 0
        csrwi   vstart, 0
        li      t0, 40                  # a few scalar instructions between the setup and the test body
1:      addi    t0, t0, -1
        bnez    t0, 1b
        vsetvli t0, x0, e8, m4, tu, mu  # LMUL = 4
        la      t1, buf
        vsseg2e8.v v0, (t1)             # 2-field segmented store, 8 registers of data
        la      t2, buf2
        amomin.d t3, t2, (t2)           # any AMO right after -> VirtualStoreQueue assertion
        RVTEST_PASS
RVTEST_CODE_END
        .data
RVTEST_DATA_BEGIN
        .align 6
buf:    .fill 1024, 1, 0
        .align 6
buf2:   .fill 64, 1, 0
RVTEST_DATA_END
