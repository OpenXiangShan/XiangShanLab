// Dual-core probe (kunminghu-v2, KunminghuV2Config, NUM_CORES=2): same sequence as repro.S on hart 0, with a writer on hart 1.
// Hart 1 writes Z once every PERIOD cycles (mcycle-paced, PERIOD not a multiple of hart 0's iteration length), so in most
// iterations Z is in hart 0's L1, C hits and reads early, and some writes land between C's read and B's read.
// CoRR litmus on Z (cacheable, PA = VA 0x8060_0000):
//   hart 1 (M mode): forever { wait mcycle >= next; Z := Z + 1 ; fence; next += PERIOD }
//   hart 0 (S mode), ITER times: fence; A: ld X (NC); FILL x ld ABUF; B: ld Z+(A&0) (waits for A's data);
//     C: ld Z (independent, younger than B, reads early); fence; violation if C < B (CoRR, RVWMO read-read).
//   FILL = 71 (default): B gets A's lqIdx.value. -DFILL=70: control, no wrap onto B.
// Exit (hart 0 trap insn, a0): 0 done. uart: "v <hex>" violations, "d <hex>" iterations with B != C,
//   "i <hex>" ITER, "z <hex>" last value of C (number of hart 1 writes seen so far).
#define CSR_MENVCFG    0x30a
#define CSR_SPFCTL     0x5c1
#define UART_TX        0x40600004
#define PT_ROOT        0x80010000
#define PT_L1          0x80011000
#define X_PA           0x80300000
#define X_VA           0xC0300000
#define ABUF           0x80400000
#define Z_ADDR         0x80600000
#define OLDV           0x0123456789abcdef
#ifndef FILL
#define FILL 71
#endif
#ifndef ITER
#define ITER 1500
#endif
#ifndef PERIOD
#define PERIOD 1009
#endif

.macro EXIT code
  li a0, \code
  .insn r 0x6b, 0, 0, x0, a0, x0
1:
  j 1b
.endm

  .section .text.init
  .option norvc
  .globl _start
_start:
  csrr t0, mhartid
  bnez t0, hart1
  la t0, m_trap
  csrw mtvec, t0
  li t0, -1
  csrw pmpaddr0, t0
  li t0, 0x1f                      // NAPOT RWX over everything
  csrw pmpcfg0, t0
  csrwi CSR_SPFCTL, 0              // all prefetchers off (CSRCustom.scala SpfctlBundle, 0x5c1 in both heads)
  li t0, 1
  csrw mcounteren, t0              // S-mode rdcycle (CALIB)
  li t0, PT_ROOT                   // Sv39 root table and the 2 MiB-level table, zeroed here
  li t1, 1024
0:
  sd zero, 0(t0)
  addi t0, t0, 8
  addi t1, t1, -1
  bnez t1, 0b
  li s0, PT_ROOT
  li t1, ((0x40000000 >> 12) << 10) | 0xc7     // gigapage 1: identity, D A W R V
  sd t1, 8(s0)
  li t1, (((PT_L1 >> 12) << 10) | 0x01)           // VA 0x8000_0000..0xBFFF_FFFF: next level (PT_L1)
  sd t1, 16(s0)
  li t0, PT_L1                     // 512 leaves of 2 MiB, identity, D A X W R V; the leaf holding X_PA stays invalid,
  li t1, ((0x80000000 >> 12) << 10) | 0xcf     // so X has no cacheable alias at all (review C6')
  li t2, (0x200000 >> 12) << 10    // PPN step of 2 MiB
  li t3, 512
  li t4, (X_PA - 0x80000000) >> 21 // index of the 2 MiB page that contains X_PA
  li t5, 0
1:
  beq t5, t4, 2f
  sd t1, 0(t0)
2:
  add t1, t1, t2
  addi t0, t0, 8
  addi t5, t5, 1
  bne t5, t3, 1b
  li t1, ((0x80000000 >> 12) << 10) | 0xc7     // gigapage 3: VA 0xC000_0000 -> PA 0x8000_0000, D A W R V
  li t2, 1
  slli t2, t2, 61                  // PBMT = NC
  or t1, t1, t2
  sd t1, 24(s0)
  li t1, 1
  slli t1, t1, 62                  // menvcfg.PBMTE
  csrs CSR_MENVCFG, t1
  srli t0, s0, 12
  li t1, 8
  slli t1, t1, 60                  // Sv39
  or t0, t0, t1
  csrw satp, t0
  sfence.vma
  li t0, 0x1800
  csrc mstatus, t0
  li t0, 0x0800                    // MPP = S
  csrs mstatus, t0
  la t0, s_entry
  csrw mepc, t0
  mret

  .balign 64
s_entry:
  li s1, X_VA
  li s2, ABUF
  li s3, Z_ADDR
  li s9, 0                         // violations
  li s8, 0                         // iterations with B != C
  li s10, ITER
  li s4, OLDV
  sd s4, 0(s1)                     // X := OLDV (NC)
  sd zero, 0(s2)
  fence rw, rw
  ld t0, 0(s2)
  ld t0, 0(s1)
  fence rw, rw
loop:
  fence rw, rw
  ld a1, 0(s1)                     // A (NC)
  .rept FILL
  ld t6, 0(s2)
  .endr
  and t0, a1, zero
  add t0, t0, s3
  ld a2, 0(t0)                     // B: older, executes after A's data
  ld a3, 0(s3)                     // C: younger, executes early
  fence rw, rw
  beq a2, a3, 2f
  addi s8, s8, 1
2:
  bgeu a3, a2, 1f
  addi s9, s9, 1                   // C < B: CoRR violation
1:
  addi s10, s10, -1
  bnez s10, loop
  mv a0, s9
  li a2, 'v'
  call s_line
  mv a0, s8
  li a2, 'd'
  call s_line
  li a0, ITER
  li a2, 'i'
  call s_line
  mv a0, a3
  li a2, 'z'
  call s_line
  EXIT 0

  .balign 64
hart1:                             // M mode, physical addresses, no setup
  la t0, h1_trap
  csrw mtvec, t0
  li t0, Z_ADDR
  li t1, 0
  li t4, PERIOD
  csrr t3, mcycle
  add t3, t3, t4
3:
  csrr t2, mcycle
  bltu t2, t3, 3b
  addi t1, t1, 1
  sd t1, 0(t0)
  fence rw, rw
  add t3, t3, t4
  j 3b
  .balign 64
h1_trap:
  j h1_trap

// ---- uartlite helpers (VA = PA through gigapage 1)
s_line:                            // a2 = tag char, a0 = value
  mv s11, ra
  mv t6, a0
  mv a0, a2
  call s_putc
  li a0, ' '
  call s_putc
  mv a0, t6
  call s_puthex
  li a0, 10
  call s_putc
  mv ra, s11
  ret
s_putc:
  li t0, UART_TX
  sb a0, 0(t0)
  ret
s_puthex:                          // 16 hex digits of a0
  mv t3, a0
  mv t4, ra
  li t5, 64
1:
  addi t5, t5, -4
  srl a0, t3, t5
  andi a0, a0, 15
  sltiu t2, a0, 10
  bnez t2, 2f
  addi a0, a0, 39
2:
  addi a0, a0, 48
  call s_putc
  bnez t5, 1b
  mv ra, t4
  ret

  .balign 64
m_trap:                            // any trap from S-mode: print mcause, mepc; exit 2
  la sp, 0x80020000
  csrr a0, mcause
  call s_puthex
  li a0, ' '
  call s_putc
  csrr a0, mepc
  call s_puthex
  li a0, 10
  call s_putc
  EXIT 2
