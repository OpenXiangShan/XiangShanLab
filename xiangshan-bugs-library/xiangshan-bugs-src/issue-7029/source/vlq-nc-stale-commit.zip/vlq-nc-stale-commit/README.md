# vlq-nc-stale-commit reproduction

Bare-metal images for the XiangShan emu (kunminghu-v2, KunminghuV2Config, 1 core), loaded at 0x80000000.

- `repro.S`: source. `-DFILL=N` sets the number of filler loads between A and B (default 71).
- `repro-fill71.bin`: FILL = 71, B reuses A's `lqIdx.value`.
- `control-fill70.bin`: FILL = 70, no reuse.
- `build.sh`: rebuilds all four images with clang 19 and llvm-objcopy 19 and checks `SHA256SUMS`.

Run each image with the emu and compare the final `[PERF] ... loadQueueRAR: ld_ld_violation` line:

```bash
./build/emu -i repro-fill71.bin   -C 400000
./build/emu -i control-fill70.bin -C 400000
```

Both images exit with `HIT GOOD TRAP`. The program prints `i <hex>` (iterations) on the UART.

Dual core (`NUM_CORES=2` emu):

- `repro-2core.S`: hart 0 runs the same sequence; hart 1 increments Z periodically. `-DFILL=N` as above.
- `repro-2core-fill71.bin` / `control-2core-fill70.bin`.

```bash
./build/emu -i repro-2core-fill71.bin   --no-diff -C 2000000
./build/emu -i control-2core-fill70.bin --no-diff -C 2000000
```

Hart 0 prints `v <hex>` (iterations where the younger load C read a smaller value than the older load B), `d <hex>` (iterations with B != C), `i <hex>` (iterations), `z <hex>` (last value of C).
