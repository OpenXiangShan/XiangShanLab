#!/bin/sh
# Rebuild the images (bare metal, load address 0x80000000) and check them against SHA256SUMS. clang 19 + llvm-objcopy 19.
set -e
cd "$(dirname "$0")"
cc() { clang-19 --target=riscv64-unknown-elf -march=rv64gc -mabi=lp64d -mno-relax "$@"; }
img() { out=$1; shift; cc "$@" -c -o "$out.o" && llvm-objcopy-19 -O binary --only-section=.text.init "$out.o" "$out.bin" && rm "$out.o"; }
img repro-fill71         repro.S
img control-fill70       repro.S       -DFILL=70
img repro-2core-fill71   repro-2core.S
img control-2core-fill70 repro-2core.S -DFILL=70
sha256sum -c SHA256SUMS
