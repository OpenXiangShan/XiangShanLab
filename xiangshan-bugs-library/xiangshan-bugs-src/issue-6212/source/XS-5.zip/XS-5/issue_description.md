# VS-Stage PTW Guest-Page-Fault mtval2 Is Not Precise

## Bug Description

The supplied PoC triggers an instruction guest-page fault during the implicit VS root-PTE read. The faulting guest physical address is the actual root-PTE slot address `0x40000008`, so the expected `mtval2` is `0x10000002`. The tested DUT reports the page-table page base `0x10000000` instead.

Affected version: `v3.2.2-alpha-1931-g96c3f568f` (`96c3f568f943a096ffd3d712dc6f462ac4b1ba33`).

The difference is one PTE slot, not just formatting. The VS entry VA is `0x40000000`, the VS root GPA is `0x40000000`, and the root index used by this access is `1`, so the implicit PTE read is at `0x40000000 + 1 * 8 = 0x40000008`.

## RISC-V Specification Requirement

RISC-V Privileged Architecture, Section 15.4.4 Machine Second Trap Value (mtval2), with guest-page-fault GPA semantics mirrored from Section 15.2.8 htval and two-stage translation behavior in Section 15.5. For guest-page faults during implicit VS-stage page-table accesses, the reported value identifies the guest physical address of the faulting implicit memory access, shifted right by two.

For this implicit VS-stage PTE access, mcause should be instruction guest page fault, mepc and mtval should identify the faulting guest virtual fetch, and mtval2 should identify the precise PTE GPA shifted right by two.

![specification evidence 1](./images/spec_01.png)

![specification evidence 2](./images/spec_02.png)

## Steps to Reproduce

1. Use the supplied `poc/program.elf` artifact in the XiangShan replay environment.
2. Run the built image with XiangShan as DUT using the same replay/no-diff mode represented by `logs/`.
3. Compare the architecture-visible trap or CSR state around the highlighted instruction sequence.

Minimal source excerpt:

```asm
.equ GPA_VS_ROOT,      0x40000000
.equ ACTUAL_PTE_GPA,   (GPA_VS_ROOT + 8)
.equ EXPECTED_MTVAL2,  (ACTUAL_PTE_GPA >> 2)

/* Prove the precise mtval2 value is representable, then enter VS translation. */
li   t0, EXPECTED_MTVAL2
csrw mtval2, t0
csrr t1, mtval2
bne  t1, t0, mtval2_warl_inconclusive

/* First VS fetch at 0x40000000 faults during root-PTE read at GPA 0x40000008. */
mret

trap_handler:
  csrr t3, mtval2
  li   t4, EXPECTED_MTVAL2
  bne  t3, t4, wrong_mtval2
```

## Expected Result

mcause = 20, mepc = 0x40000000, mtval = 0x40000000, and mtval2 = 0x10000002.

## Actual Result

The replay reports:

```text
mtval2 different right = 0x0000000010000002, wrong = 0x0000000010000000
```

Here `right` is the reference model and `wrong` is the XiangShan DUT. The DUT-only run also reaches the self-check path that detects `mtval2 = 0x10000000`.

Trace context before the mismatch:

![Trace context before mismatch](images/trace_context.png)

Replay trace screenshot:

![Difftest replay trace screenshot](images/replay_trace.png)

DUT-only self-check screenshot:

![DUT-only self-check screenshot](images/dut_self_check.png)

## Evidence Interpretation

The first screenshot shows the replay mismatch on `mtval2`. The second screenshot is the DUT-only self-check reaching `HIT GOOD TRAP`, which means the test observed the imprecise page-base value directly on XiangShan. Reporting the page base loses the precise PTE slot that faulted.

This issue is stably reproducible on v3; it was not reproducible on v2 after testing.

The fix should propagate the precise guest physical address of the faulting implicit VS-stage PTE access into `mtval2`, without replacing the PTE-slot address used by hypervisor policy code with the page-table page base.
