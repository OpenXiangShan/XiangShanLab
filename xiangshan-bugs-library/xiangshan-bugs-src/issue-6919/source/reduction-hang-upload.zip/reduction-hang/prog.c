/* Tests/cases-form program generated from vredsum_vs SEW=16. */
typedef unsigned long uint64_t;
#define NUM_CASES 4
#define TEST_TITLE "检查 vredsum_vs 在 SEW=16、LMUL=m1 下的 4 个定向用例"

/* ============================================================================
 * vredsum.vs - directed RVV test, SEW=16, LMUL=m1.
 *
 * Category: vred; format: OPMVV.
 * Target: KMHV3, VLEN=128, LMUL=m1.  The program is execution-oriented:
 * it issues the instruction with special operands, stores the destination
 * and exits with success.  Unsupported SEW/operand combinations are emitted
 * deliberately so the DUT can be checked for an illegal-instruction trap.
 * Store addresses come from arch-fuzz's address generator and are rebased
 * into mem_buf; the raw generated address is recorded per case.
 * ==========================================================================*/


#define SEW            16
#define AVL            8
#define VEC_BYTES      16
#define MEM_BUF_SIZE   4096
#define RES_BYTES      256

static const unsigned char vec_data[16][VEC_BYTES]
    __attribute__((aligned(16))) = {
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 0 */
    { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff }, /* 1 */
    { 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55 }, /* 2 */
    { 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa }, /* 3 */
    { 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80 }, /* 4 */
    { 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f, 0xff, 0x7f }, /* 5 */
    { 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c, 0x00, 0x3c }, /* 6 */
    { 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc, 0x00, 0xbc }, /* 7 */
    { 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c, 0x00, 0x7c }, /* 8 */
    { 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e, 0x00, 0x7e }, /* 9 */
    { 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b, 0xff, 0x7b }, /* 10 */
    { 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00 }, /* 11 */
    { 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00 }, /* 12 */
    { 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80 }, /* 13 */
    { 0x00, 0xff, 0x00, 0xff, 0x00, 0xff, 0x00, 0xff, 0x00, 0xff, 0x00, 0xff, 0x00, 0xff, 0x00, 0xff }, /* 14 */
    { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f }, /* 15 */
};

static const unsigned char idx8[16] __attribute__((aligned(16))) =
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
static const unsigned short idx16[16] __attribute__((aligned(16))) =
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
static const unsigned int idx32[16] __attribute__((aligned(16))) =
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
static const unsigned long idx64[16] __attribute__((aligned(16))) =
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
static const unsigned char off8[16] __attribute__((aligned(16))) =
    { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 };
static const unsigned short off16[16] __attribute__((aligned(16))) =
    { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 };
static const unsigned int off32[16] __attribute__((aligned(16))) =
    { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 };
static const unsigned long off64[16] __attribute__((aligned(16))) =
    { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 };

static unsigned char mem_buf[MEM_BUF_SIZE] __attribute__((aligned(64)));
static unsigned char res_data[RES_BYTES] __attribute__((aligned(16)));

static inline double bits_to_double(unsigned long bits)
{
    double value;

    __builtin_memcpy(&value, &bits, sizeof(value));
    return value;
}

/* case 0: directed operand pattern */


/* case 1: directed operand pattern */

/* case 2: directed operand pattern */


/* case 3: directed operand pattern */

/* case 4: directed operand pattern */


/* case 5: directed operand pattern */



extern char case0_probe[];
extern char case2_probe[];
extern char case4_probe[];
extern char case5_probe[];
static void case0(void)
{
    asm volatile(
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        "vle16.v v1, (%0)\n"
        "vle16.v v2, (%1)\n"
        "vle16.v v3, (%2)\n"
        "vle16.v v4, (%3)\n"
        "vle16.v v5, (%4)\n"
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        ".global case0_probe\n"
        "case0_probe:\n"
        "vredsum.vs v4, v2, v1\n"
        "vse16.v v4, (%5)\n"
        "fence.i\n"
        "fence\n"
        :
        : "r"(&vec_data[0][0]), "r"(&vec_data[1][0]), "r"(&vec_data[0][0]), "r"(&vec_data[2][0]), "r"(&vec_data[2][0]), "r"(res_data)
        : "memory");
}


static void case2(void)
{
    asm volatile(
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        "vle16.v v1, (%0)\n"
        "vle16.v v2, (%1)\n"
        "vle16.v v3, (%2)\n"
        "vle16.v v4, (%3)\n"
        "vle16.v v5, (%4)\n"
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        ".global case2_probe\n"
        "case2_probe:\n"
        "vredsum.vs v4, v2, v1\n"
        "vse16.v v4, (%5)\n"
        "fence.i\n"
        "fence\n"
        :
        : "r"(&vec_data[4][0]), "r"(&vec_data[5][0]), "r"(&vec_data[4][0]), "r"(&vec_data[6][0]), "r"(&vec_data[6][0]), "r"(res_data)
        : "memory");
}


static void case4(void)
{
    asm volatile(
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        "vle16.v v1, (%0)\n"
        "vle16.v v2, (%1)\n"
        "vle16.v v3, (%2)\n"
        "vle16.v v4, (%3)\n"
        "vle16.v v5, (%4)\n"
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        ".global case4_probe\n"
        "case4_probe:\n"
        "vredsum.vs v4, v2, v1\n"
        "vse16.v v4, (%5)\n"
        "fence.i\n"
        "fence\n"
        :
        : "r"(&vec_data[8][0]), "r"(&vec_data[9][0]), "r"(&vec_data[8][0]), "r"(&vec_data[10][0]), "r"(&vec_data[10][0]), "r"(res_data)
        : "memory");
}


static void case5(void)
{
    asm volatile(
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        "vle16.v v1, (%0)\n"
        "vle16.v v2, (%1)\n"
        "vle16.v v3, (%2)\n"
        "vle16.v v4, (%3)\n"
        "vle16.v v5, (%4)\n"
        "vsetivli zero, 8, e16, m1, ta, ma\n"
        ".global case5_probe\n"
        "case5_probe:\n"
        "vredsum.vs v4, v2, v1\n"
        "vse16.v v4, (%5)\n"
        "fence.i\n"
        "fence\n"
        :
        : "r"(&vec_data[12][0]), "r"(&vec_data[13][0]), "r"(&vec_data[12][0]), "r"(&vec_data[14][0]), "r"(&vec_data[14][0]), "r"(res_data)
        : "memory");
}


static const unsigned char case_expected_tab[NUM_CASES] = {0, 0, 0, 0};
static const char *const case_name_tab[NUM_CASES] = {"case0", "case2", "case4", "case5"};
static const char *const case_expect_tab[NUM_CASES] = {"正常执行完成", "正常执行完成", "正常执行完成", "正常执行完成"};
extern char test_completion[];

/* -------------------------------------------------------------------------
 * Tests/cases-style bare-metal runtime.
 * Derived from prog.c
 * (UART report, 0x0005006b exit, mcause/mepc checking).
 * -----------------------------------------------------------------------*/
static char report_text[4096];
static uint64_t report_length __attribute__((section(".data"))) = 0;
static uint64_t report_item;

static inline void put_text(const char *text)
{
    while (*text)
        report_text[report_length++] = *text++;
}

static inline void put_hexadecimal(uint64_t value)
{
    char digits[16];
    int count = 0;

    do
        digits[count++] = "0123456789abcdef"[value & 15];
    while (value >>= 4);
    put_text("0x");
    while (count)
        report_text[report_length++] = digits[--count];
}

static inline void put_decimal(uint64_t value)
{
    char digits[20];
    int count = 0;

    do
        digits[count++] = '0' + value % 10;
    while (value /= 10);
    while (count)
        report_text[report_length++] = digits[--count];
}

static inline void put_item_start(void)
{
    put_text("   ");
    put_decimal(++report_item);
    put_text(") ");
}

static inline void put_item(const char *text)
{
    put_item_start();
    put_text(text);
    put_text("\n");
}

static inline const char *cause_name(uint64_t cause)
{
    switch (cause) {
    case 0: return "指令地址非对齐";
    case 1: return "取指访问错误";
    case 2: return "非法指令";
    case 3: return "断点";
    case 4: return "加载地址非对齐";
    case 5: return "读取访问错误";
    case 6: return "存储地址非对齐";
    case 7: return "存储访问错误";
    case 8: case 9: case 11: return "环境调用";
    case 12: return "取指页错误";
    case 13: return "读取页错误";
    case 15: return "存储页错误";
    default: return "未知异常";
    }
}

#define CASE_UNRUN     0
#define CASE_EXECUTED  1
#define CASE_TRAPPED   2
#define CASE_FAILED    3

static volatile uint64_t phase __attribute__((section(".data"))) = 1;
static volatile uint64_t trap_expected __attribute__((section(".data"))) = 0;
static volatile uint64_t expect_pc __attribute__((section(".data"))) = 0;
static volatile uint64_t trap_ok __attribute__((section(".data"))) = 0;
static volatile uint64_t current_case __attribute__((section(".data"))) = 0;
static volatile uint64_t case_state[NUM_CASES]
    __attribute__((section(".data")));

static unsigned char stack[4096]
    __attribute__((section(".stack"), aligned(16), used));
static unsigned char trap_stack[1024]
    __attribute__((section(".stack"), aligned(16), used));
static volatile uint64_t trap_frame __attribute__((section(".data")));

static __attribute__((naked, aligned(4), noreturn)) void park_hart(void)
{
    asm volatile(
        "1: wfi\n"
        "j 1b\n"
    );
}

static __attribute__((noreturn)) void report_exit(int code)
{
    for (uint64_t index = 0; index < report_length; index++) {
        while (*(volatile unsigned char *)0x40600008 & 0x08) {}
        *(volatile unsigned char *)0x40600004 = report_text[index];
    }
    asm volatile("fence iorw, iorw" ::: "memory");
    asm volatile("mv a0, %0\n.word 0x0005006b" :: "r"((uint64_t)code)
                 : "a0", "memory");
    park_hart();
}

static __attribute__((noreturn)) void report_unexpected(
    uint64_t cause, uint64_t pc, uint64_t tval, int code, const char *what)
{
    report_length = 0;
    report_item = 0;
    put_text("测试内容：\n   " TEST_TITLE "\n");
    put_text("运行结果：\n");
    put_item(what);
    put_item_start();
    put_text("异常mcause = ");
    put_decimal(cause);
    put_text("（");
    put_text(cause_name(cause));
    put_text("）\n");
    put_item_start();
    put_text("异常mepc = ");
    put_hexadecimal(pc);
    put_text("\n");
    put_item_start();
    put_text("异常mtval = ");
    put_hexadecimal(tval);
    put_text("\n");
    put_text("测试结论：\n   测试失败\n");
    report_exit(code);
}

static __attribute__((noreturn)) void report_all(void)
{
    int pass = 1;

    report_length = 0;
    report_item = 0;
    put_text("测试内容：\n   " TEST_TITLE "\n");
    put_text("预期结果：\n");
    for (uint64_t index = 0; index < NUM_CASES; index++) {
        put_item_start();
        put_text(case_name_tab[index]);
        put_text("：");
        put_text(case_expect_tab[index]);
        put_text("\n");
    }
    put_text("运行结果：\n");
    report_item = 0;
    for (uint64_t index = 0; index < NUM_CASES; index++) {
        put_item_start();
        put_text(case_name_tab[index]);
        put_text("：");
        if (case_state[index] == CASE_TRAPPED) {
            put_text("在目标指令处触发非法指令异常\n");
        } else if (case_state[index] == CASE_EXECUTED) {
            put_text("正常执行完成\n");
        } else if (case_state[index] == CASE_FAILED) {
            put_text("与标量参考模型不一致\n");
            pass = 0;
        } else {
            put_text("未完成\n");
            pass = 0;
        }
        if (case_expected_tab[index] && case_state[index] != CASE_TRAPPED)
            pass = 0;
        if (!case_expected_tab[index] && case_state[index] != CASE_EXECUTED)
            pass = 0;
    }
    put_text("说明：算术结果由 Spike 差分比对检查。\n");
    put_text("测试结论：\n   ");
    put_text(pass ? "测试通过\n" : "测试失败\n");
    report_exit(pass ? 0 : 1);
}

/* Restore the interrupted integer context and return to mepc.  This makes
 * the handler transparent, so an expected illegal instruction can be
 * skipped while the remainder of the directed case still executes with
 * the original operand registers. */
static __attribute__((naked, noreturn, aligned(4), used)) void trap_resume(void)
{
    asm volatile(
        "la t0, trap_frame\n"
        "ld sp, 0(t0)\n"
        "ld ra, 0(sp)\n"
        "ld gp, 8(sp)\n"
        "ld tp, 16(sp)\n"
        "ld t0, 24(sp)\n"
        "ld t1, 32(sp)\n"
        "ld t2, 40(sp)\n"
        "ld s0, 48(sp)\n"
        "ld s1, 56(sp)\n"
        "ld a0, 64(sp)\n"
        "ld a1, 72(sp)\n"
        "ld a2, 80(sp)\n"
        "ld a3, 88(sp)\n"
        "ld a4, 96(sp)\n"
        "ld a5, 104(sp)\n"
        "ld a6, 112(sp)\n"
        "ld a7, 120(sp)\n"
        "ld s2, 128(sp)\n"
        "ld s3, 136(sp)\n"
        "ld s4, 144(sp)\n"
        "ld s5, 152(sp)\n"
        "ld s6, 160(sp)\n"
        "ld s7, 168(sp)\n"
        "ld s8, 176(sp)\n"
        "ld s9, 184(sp)\n"
        "ld s10, 192(sp)\n"
        "ld s11, 200(sp)\n"
        "ld t3, 208(sp)\n"
        "ld t4, 216(sp)\n"
        "ld t5, 224(sp)\n"
        "ld t6, 232(sp)\n"
        "ld sp, 240(sp)\n"
        "mret\n"
    );
}

static __attribute__((noreturn, used)) void trap_dispatch(
    uint64_t cause, uint64_t pc, uint64_t tval, uint64_t status)
{
    (void)status;

    if (trap_expected && pc == expect_pc && cause == 2) {
        trap_ok = 1;
        case_state[current_case] = CASE_TRAPPED;
        asm volatile("csrw mepc, %0" :: "r"(pc + 4));
        trap_resume();
    }
    if (pc == (uint64_t)test_completion && cause == 9)
        report_all();
    if (phase == 1)
        report_unexpected(cause, pc, tval, 2, "初始化阶段发生异常");
    report_unexpected(cause, pc, tval, 1, "发生未预期的异常");
}

static __attribute__((naked, aligned(4), used)) void trap_stub(void)
{
    asm volatile(
        "csrrw sp, mscratch, sp\n"
        "addi sp, sp, -256\n"
        "sd ra, 0(sp)\n"
        "sd gp, 8(sp)\n"
        "sd tp, 16(sp)\n"
        "sd t0, 24(sp)\n"
        "sd t1, 32(sp)\n"
        "sd t2, 40(sp)\n"
        "sd s0, 48(sp)\n"
        "sd s1, 56(sp)\n"
        "sd a0, 64(sp)\n"
        "sd a1, 72(sp)\n"
        "sd a2, 80(sp)\n"
        "sd a3, 88(sp)\n"
        "sd a4, 96(sp)\n"
        "sd a5, 104(sp)\n"
        "sd a6, 112(sp)\n"
        "sd a7, 120(sp)\n"
        "sd s2, 128(sp)\n"
        "sd s3, 136(sp)\n"
        "sd s4, 144(sp)\n"
        "sd s5, 152(sp)\n"
        "sd s6, 160(sp)\n"
        "sd s7, 168(sp)\n"
        "sd s8, 176(sp)\n"
        "sd s9, 184(sp)\n"
        "sd s10, 192(sp)\n"
        "sd s11, 200(sp)\n"
        "sd t3, 208(sp)\n"
        "sd t4, 216(sp)\n"
        "sd t5, 224(sp)\n"
        "sd t6, 232(sp)\n"
        "csrr t0, mscratch\n"
        "sd t0, 240(sp)\n"
        "la t0, trap_frame\n"
        "sd sp, 0(t0)\n"
        "csrr a0, mcause\n"
        "csrr a1, mepc\n"
        "csrr a2, mtval\n"
        "csrr a3, mstatus\n"
        "call trap_dispatch\n"
    );
}

static void run_case0(void)
{
    trap_expected = 0;
    expect_pc = (uint64_t)case0_probe;
    trap_ok = 0;
    current_case = 0;
    case0();
    if (trap_expected)
        case_state[0] = trap_ok ? CASE_TRAPPED : CASE_UNRUN;
    else
        case_state[0] = CASE_EXECUTED;
}

static void run_case2(void)
{
    trap_expected = 0;
    expect_pc = (uint64_t)case2_probe;
    trap_ok = 0;
    current_case = 1;
    case2();
    if (trap_expected)
        case_state[1] = trap_ok ? CASE_TRAPPED : CASE_UNRUN;
    else
        case_state[1] = CASE_EXECUTED;
}

static void run_case4(void)
{
    trap_expected = 0;
    expect_pc = (uint64_t)case4_probe;
    trap_ok = 0;
    current_case = 2;
    case4();
    if (trap_expected)
        case_state[2] = trap_ok ? CASE_TRAPPED : CASE_UNRUN;
    else
        case_state[2] = CASE_EXECUTED;
}

static void run_case5(void)
{
    trap_expected = 0;
    expect_pc = (uint64_t)case5_probe;
    trap_ok = 0;
    current_case = 3;
    case5();
    if (trap_expected)
        case_state[3] = trap_ok ? CASE_TRAPPED : CASE_UNRUN;
    else
        case_state[3] = CASE_EXECUTED;
}

static __attribute__((noreturn, noinline, used)) void run(void)
{
    phase = 2;
    run_case0();
    run_case2();
    run_case4();
    run_case5();
    asm volatile(
        ".global test_completion\n"
        "test_completion:\n"
        "ecall\n"
        ::: "memory");
    park_hart();
}

void entry(void)
{
    asm volatile("csrw mscratch, %0"
                 :: "r"((uint64_t)trap_stack + sizeof(trap_stack)));
    asm volatile("csrw mtvec, %0" :: "r"((uint64_t)trap_stub));
    asm volatile(
        "csrw medeleg, zero\n"
        "csrw mideleg, zero\n"
        "csrw mie, zero\n"
        "csrw sie, zero"
    );
    asm volatile("csrw 0x744, %0" :: "r"(8UL)); /* mnstatus.NMIE */
    asm volatile(
        "csrw satp, zero\n"
        "csrw vsatp, zero\n"
        "csrw hgatp, zero"
    );
    asm volatile(
        "csrw pmpaddr0, %0\n"
        "csrw pmpcfg0, %1"
        :: "r"(~0UL), "r"(0x1fUL)
    );
    asm volatile(
        "csrw mcounteren, %0\n"
        "csrw scounteren, %0\n"
        "csrw hcounteren, %0"
        :: "r"(0xffffffffUL)
    );
    asm volatile(
        "csrw menvcfg, %0\n"
        "csrw henvcfg, %0"
        :: "r"(1UL << 63)
    );
    asm volatile(
        "csrw 0x30c, %0\n"
        "csrw 0x30d, %0\n"
        "csrw 0x30e, %0\n"
        "csrw 0x30f, %0\n"
        "csrw 0x60c, %0\n"
        "csrw 0x60d, %0\n"
        "csrw 0x60e, %0\n"
        "csrw 0x60f, %0\n"
        "csrw 0x10c, %0\n"
        "csrw 0x10d, %0\n"
        "csrw 0x10e, %0\n"
        "csrw 0x10f, %0"
        :: "r"(~0UL)
    );
    asm volatile(
        "csrw 0x308, zero\n"
        "csrw 0x609, zero\n"
        "csrw 0x350, %0\n"
        "csrw 0x150, %0\n"
        "csrw 0x250, %0"
        :: "r"(0x70UL)
    );
    asm volatile(
        "csrw hstatus, %0\n"
        "csrw vsstatus, %1"
        :: "r"((2UL << 32) | (1UL << 12)), "r"((3UL << 13) | (3UL << 9))
    );
    asm volatile("csrw mstatus, %0" :: "r"(0x6e00UL));
    asm volatile(
        "la t0, run\n"
        "csrw mepc, t0\n"
        "mret"
        ::: "t0", "memory"
    );
    park_hart();
}

__attribute__((naked, section(".text.init"))) void _start(void)
{
    asm volatile(
        "csrr t0, mhartid\n"
        "bnez t0, park_hart\n"
        "csrw mstatus, zero\n"
        "csrw mie, zero\n"
        ".option push\n"
        ".option norelax\n"
        "la gp, __global_pointer$\n"
        ".option pop\n"
        "la sp, stack + 4096\n"
        "j entry\n"
    );
}
