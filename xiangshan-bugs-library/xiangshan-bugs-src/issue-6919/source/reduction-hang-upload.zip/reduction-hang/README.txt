xiangshan reduction-hang reproducer
===================================

Issue: [BUG] Vector reductions never write element 0 and block ROB commit (CROB-STUCK)

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: c74acb9d37e8f337f73124eabb00662de15c17214f55a1184d439e78ebbc68e0

prog.c
    Reproducer source.
    SHA-256: 24e93143082f4731be7248afb5c7c9babd8a91b1abdd02b2d2d6202c6c92b875

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: 714d85bd4e3a0ae9e1466e5854c28ec2e8530c586116671a0cb0a3f5b811f191

sim.log
    Difftest log of the failing run.
    SHA-256: 4eb5d735fe9eb0727898586336807b7ce6b08350f2b33cfa319a255e64713c28

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures SEW=16, LMUL=m1, loads `v1` and `v2`, and executes `vredsum.vs` at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB; the run stops after 15000 cycles without a commit.
- Run the same ELF on the Spike difftest reference: the reference completes and writes the reduction result.

Expected:
  `vredsum.vs` SEW=16 must complete without a hang and write `v4_low = 0x555555555555fff8`.

Observed:
  The DUT hangs and keeps the old destination value:
  
  ```text
  No instruction of core 0 commits for 15000 cycles, maybe get stuck
   v4_low different at pc = 0x23ed181b74f6, right = 0x555555555555fff8, wrong = 0x5555555555555555
  [CROB-STUCK] ... headPC=0000080000962 ...
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
