#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
RISCV_NM="${RISCV_NM:-/opt/riscv/bin/riscv64-unknown-elf-nm}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

CYCLES="${CYCLES:-18000}"
TRAIN_ROUNDS="${TRAIN_ROUNDS:-64}"
TIMEOUT_SECS="${TIMEOUT_SECS:-90}"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in 0 1; do
  prefix="secret_${secret}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  symbols="${prefix}.symbols"
  run_log="${prefix}_nowave_perf.log"

  echo "[build] SECRET_VALUE=$secret"
  "$RISCV_GCC" \
    -nostdlib -nostartfiles -static \
    -march=rv64gc_zicsr -mabi=lp64d \
    -DSECRET_VALUE="$secret" \
    -DTRAIN_ROUNDS="$TRAIN_ROUNDS" \
    -T linker.ld \
    -o "$elf" \
    secret_train_probe.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d "$elf" > "$objdump"
  "$RISCV_NM" -n "$elf" > "$symbols"

  echo "[run-nowave] SECRET_VALUE=$secret"
  timeout "${TIMEOUT_SECS}s" "$EMU" \
    -i "$bin" \
    --no-diff \
    -C "$CYCLES" \
    --force-dump-result \
    > "$run_log" 2>&1
done

python3 ./parse_perf_observable.py \
  secret_0_nowave_perf.log \
  secret_1_nowave_perf.log \
  --json-out timing_verdict.json
