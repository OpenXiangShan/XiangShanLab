#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
RISCV_NM="${RISCV_NM:-/opt/riscv/bin/riscv64-unknown-elf-nm}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

CYCLES="${CYCLES:-18000}"
WAVE_BEGIN="${WAVE_BEGIN:-7800}"
WAVE_END="${WAVE_END:-18000}"
TRAIN_ROUNDS="${TRAIN_ROUNDS:-64}"
TIMEOUT_SECS="${TIMEOUT_SECS:-180}"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in 0 1; do
  prefix="secret_${secret}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  symbols="${prefix}.symbols"
  wave="${prefix}_${WAVE_BEGIN}_${WAVE_END}.vcd"
  run_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.run.log"
  monitor_json="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
  monitor_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

  echo "[build] SECRET_VALUE=$secret"
  "$RISCV_GCC" \
    -nostdlib -nostartfiles -static \
    -march=rv64gc_zicsr -mabi=lp64d \
    -DSECRET_VALUE="$secret" \
    -DTRAIN_ROUNDS="$TRAIN_ROUNDS" \
    -T linker.ld \
    -o "$elf" \
    secret_train_probe.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d "$elf" > "$objdump"
  "$RISCV_NM" -n "$elf" > "$symbols"

  echo "[run] SECRET_VALUE=$secret"
  timeout "${TIMEOUT_SECS}s" "$EMU" \
    -i "$bin" \
    --no-diff \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    --dump-wave-full \
    --wave-path="$wave" \
    > "$run_log" 2>&1

  echo "[monitor] SECRET_VALUE=$secret"
  python3 ./monitor_secret_probe_vcd.py "$wave" "$symbols" --json-out "$monitor_json" > "$monitor_log"
done

python3 - <<'PY'
import json
from pathlib import Path

rows = {}
for secret in (0, 1):
    path = next(Path(".").glob(f"secret_{secret}_*.monitor.json"))
    rows[secret] = json.loads(path.read_text())

delta0 = rows[0]["rdcycle_delta_values"][0] if rows[0].get("rdcycle_delta_values") else None
delta1 = rows[1]["rdcycle_delta_values"][0] if rows[1].get("rdcycle_delta_values") else None
recovered0 = rows[0]["recovered_bit_values"][0] if rows[0].get("recovered_bit_values") else None
recovered1 = rows[1]["recovered_bit_values"][0] if rows[1].get("recovered_bit_values") else None

print("secret=0")
print(json.dumps({
    "wrongpath_taken": rows[0]["wrongpath_train_taken_count"],
    "wrongpath_not_taken": rows[0]["wrongpath_train_not_taken_count"],
    "probe_redirect_count": rows[0]["probe_redirect_count"],
    "secret_probe_redirect_seen": rows[0]["secret_probe_redirect_seen"],
    "rdcycle_delta": delta0,
    "recovered_bit": recovered0,
}, indent=2))
print("secret=1")
print(json.dumps({
    "wrongpath_taken": rows[1]["wrongpath_train_taken_count"],
    "wrongpath_not_taken": rows[1]["wrongpath_train_not_taken_count"],
    "probe_redirect_count": rows[1]["probe_redirect_count"],
    "secret_probe_redirect_seen": rows[1]["secret_probe_redirect_seen"],
    "rdcycle_delta": delta1,
    "recovered_bit": recovered1,
}, indent=2))

secret_dependent_train = rows[0]["wrongpath_train_not_taken_count"] > 0 and rows[1]["wrongpath_train_taken_count"] > 0
secret_dependent_probe = rows[0]["probe_redirect_count"] == 0 and rows[1]["probe_redirect_count"] > 0
software_timing = delta0 is not None and delta1 is not None and delta1 > delta0
secret_recovery = recovered0 == 0 and recovered1 == 1

verdict = {
    "secret_dependent_wrongpath_training": int(secret_dependent_train),
    "secret_dependent_attacker_probe_redirect": int(secret_dependent_probe),
    "secret_dependent_mcycle_delta": int(software_timing),
    "guest_threshold_recovers_secret_bit": int(secret_recovery),
    "security_primitive_confirmed": int(secret_dependent_train and secret_dependent_probe),
    "secret_recovery_confirmed": int(secret_dependent_train and secret_dependent_probe and software_timing and secret_recovery),
}
Path("verdict.json").write_text(json.dumps(verdict, indent=2, sort_keys=True) + "\n")
print(json.dumps(verdict, indent=2, sort_keys=True))
if not verdict["security_primitive_confirmed"]:
    raise SystemExit(1)
PY
