#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


PREFIX_BACKEND = "TOP.SimTop.cpu.l_soc.core_with_l2.core.backend"
PREFIX_FTQ = "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ftq"


def clean_name(name: str) -> str:
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_value(value: str | None) -> int | None:
    if value is None:
        return None
    value = value.strip().lower()
    if value in {"0", "1"}:
        return int(value)
    if value.startswith("b"):
        bits = value[1:]
        if any(c in bits for c in "xz"):
            return None
        return int(bits, 2)
    if value in {"x", "z"}:
        return None
    return None


def parse_symbols(path: Path) -> dict[str, int]:
    out: dict[str, int] = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if len(fields) >= 3:
            try:
                out[fields[2]] = int(fields[0], 16)
            except ValueError:
                pass
    return out


def pruned_to_addr(value: int | None) -> int | None:
    if value is None:
        return None
    return int(value) << 1


def parse_header(path: Path):
    wanted = {
        "redirect_valid": f"{PREFIX_BACKEND}.io_frontend_toFtq_redirect_valid",
        "redirect_pc": f"{PREFIX_BACKEND}.io_frontend_toFtq_redirect_bits_pc",
        "redirect_target": f"{PREFIX_BACKEND}.io_frontend_toFtq_redirect_bits_target",
        "redirect_offset": f"{PREFIX_BACKEND}.io_frontend_toFtq_redirect_bits_ftqOffset",
        "redirect_mispredict": f"{PREFIX_BACKEND}.io_frontend_toFtq_redirect_bits_isMisPred",
        "train_valid": f"{PREFIX_FTQ}.trainCache_valid",
        "train_ready": f"{PREFIX_FTQ}.io_toBpu_train_ready",
        "train_start": f"{PREFIX_FTQ}.trainCache_bits_startPc_addr",
    }
    for i in range(8):
        wanted[f"branch_{i}_valid"] = f"{PREFIX_FTQ}.trainCache_bits_branches_{i}_valid"
        wanted[f"branch_{i}_cfi"] = f"{PREFIX_FTQ}.trainCache_bits_branches_{i}_bits_cfiPosition"
        wanted[f"branch_{i}_target"] = f"{PREFIX_FTQ}.trainCache_bits_branches_{i}_bits_target_addr"
        wanted[f"branch_{i}_taken"] = f"{PREFIX_FTQ}.trainCache_bits_branches_{i}_bits_taken"
        wanted[f"branch_{i}_mispredict"] = f"{PREFIX_FTQ}.trainCache_bits_branches_{i}_bits_mispredict"
    for i in range(3):
        endpoint = "store" if i == 0 else f"store_{i}"
        wanted[f"store_{i}_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_valid"
        wanted[f"store_{i}_bits_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_valid"
        wanted[f"store_{i}_addr"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_addr"
        wanted[f"store_{i}_data"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_data"
        wanted[f"store_{i}_pc"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_pc"

    selected = {}
    code_to_keys = {}
    scope: list[str] = []
    var_re = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope"):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            m = var_re.match(line)
            if not m:
                continue
            code, raw_name = m.groups()
            full = ".".join(scope + [clean_name(raw_name)])
            for key, suffix in wanted.items():
                if full.endswith(suffix):
                    selected[key] = {"code": code, "full": full}
                    code_to_keys.setdefault(code, []).append(key)
    return selected, code_to_keys


def parse_vcd(path: Path, selected, code_to_keys, consts):
    values = {key: None for key in selected}
    now = 0
    in_body = False
    train_rows = []
    redirect_rows = []
    probe_redirects = []
    wrongpath_trains = []
    rdcycle_delta_stores = []
    recovered_bit_stores = []

    start_pc = consts["start_pc"]
    victim_offset = consts["victim_offset"]
    probe_offset = consts["probe_offset"]
    victim_target = consts["victim_target"]
    probe_fallthrough = consts["probe_fallthrough"]
    probe_pc = consts["probe_pc"]
    result_delta = consts.get("result_delta")
    recovered_bit = consts.get("recovered_bit")

    def sample(time: int):
        train_fire = parse_value(values.get("train_valid")) == 1 and parse_value(values.get("train_ready")) == 1
        if train_fire:
            row = {
                "time": time,
                "start": pruned_to_addr(parse_value(values.get("train_start"))),
                "branches": [],
            }
            for i in range(8):
                if parse_value(values.get(f"branch_{i}_valid")) == 1:
                    cfi = parse_value(values.get(f"branch_{i}_cfi"))
                    target = pruned_to_addr(parse_value(values.get(f"branch_{i}_target")))
                    taken = parse_value(values.get(f"branch_{i}_taken"))
                    branch_pc = None if cfi is None else start_pc + (cfi - 1) * 2
                    row["branches"].append(
                        {
                            "slot": i,
                            "cfi": cfi,
                            "pc": branch_pc,
                            "target": target,
                            "taken": taken,
                            "mispredict": parse_value(values.get(f"branch_{i}_mispredict")),
                        }
                    )
            train_rows.append(row)
            for branch in row["branches"]:
                if (
                    row["start"] == start_pc
                    and branch["pc"] == probe_pc
                    and branch["target"] is not None
                    and time > 0
                ):
                    wrongpath_trains.append({"time": time, **branch})

        if parse_value(values.get("redirect_valid")) == 1:
            row = {
                "time": time,
                "pc": parse_value(values.get("redirect_pc")),
                "target": parse_value(values.get("redirect_target")),
                "offset": parse_value(values.get("redirect_offset")),
                "is_mispredict": parse_value(values.get("redirect_mispredict")),
            }
            redirect_rows.append(row)
            # When the attacker jumps directly to probe_branch, XiangShan starts
            # a new FTQ block at probe_pc. A misprediction of the probe itself
            # redirects to its fallthrough at probe_fallthrough.
            if row["pc"] == probe_pc and row["offset"] == 1 and row["target"] == probe_fallthrough:
                probe_redirects.append(row)

        if result_delta is not None:
            for i in range(3):
                valid = parse_value(values.get(f"store_{i}_valid")) == 1
                bits_valid = parse_value(values.get(f"store_{i}_bits_valid"))
                addr = parse_value(values.get(f"store_{i}_addr"))
                if valid and bits_valid in (None, 1) and addr == result_delta:
                    rdcycle_delta_stores.append(
                        {
                            "time": time,
                            "slot": i,
                            "addr": addr,
                            "pc": parse_value(values.get(f"store_{i}_pc")),
                            "data": parse_value(values.get(f"store_{i}_data")),
                        }
                    )
                if valid and bits_valid in (None, 1) and addr == recovered_bit:
                    recovered_bit_stores.append(
                        {
                            "time": time,
                            "slot": i,
                            "addr": addr,
                            "pc": parse_value(values.get(f"store_{i}_pc")),
                            "data": parse_value(values.get(f"store_{i}_data")),
                        }
                    )

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                continue
            if line[0] in "01xz":
                code = line[1:]
                val = line[0]
                for key in code_to_keys.get(code, []):
                    values[key] = val
                continue
            if line[0] in "bBrR":
                parts = line.split()
                if len(parts) >= 2:
                    val, code = parts[0], parts[1]
                    for key in code_to_keys.get(code, []):
                        values[key] = val
        sample(now)

    victim_redirect_seen = any(
        row["pc"] == start_pc
        and row["target"] == victim_target
        and row["offset"] == victim_offset
        and row["is_mispredict"] == 1
        for row in redirect_rows
    )
    taken_train = [row for row in wrongpath_trains if row["taken"] == 1]
    not_taken_train = [row for row in wrongpath_trains if row["taken"] == 0]
    first_victim_time = min(
        [
            row["time"]
            for row in redirect_rows
            if row["pc"] == start_pc and row["target"] == victim_target and row["offset"] == victim_offset
        ]
        or [None]
    )
    post_victim_trains = [
        row for row in wrongpath_trains if first_victim_time is not None and row["time"] >= first_victim_time
    ]

    return {
        "constants": {k: hex(v) if isinstance(v, int) else v for k, v in consts.items()},
        "missing": sorted(set(selected) ^ set(selected) | {k for k in []}),
        "selected_signal_count": len(selected),
        "victim_redirect_seen": victim_redirect_seen,
        "wrongpath_train_count": len(wrongpath_trains),
        "wrongpath_train_taken_count": len(taken_train),
        "wrongpath_train_not_taken_count": len(not_taken_train),
        "post_victim_wrongpath_train_count": len(post_victim_trains),
        "probe_redirect_count": len(probe_redirects),
        "secret_probe_redirect_seen": bool(probe_redirects),
        "rdcycle_delta_store_count": len(rdcycle_delta_stores),
        "first_rdcycle_delta_store": rdcycle_delta_stores[0] if rdcycle_delta_stores else None,
        "rdcycle_delta_values": [row["data"] for row in rdcycle_delta_stores[:8]],
        "recovered_bit_store_count": len(recovered_bit_stores),
        "first_recovered_bit_store": recovered_bit_stores[0] if recovered_bit_stores else None,
        "recovered_bit_values": [row["data"] for row in recovered_bit_stores[:8]],
        "first_wrongpath_trains": wrongpath_trains[:8],
        "first_probe_redirects": probe_redirects[:8],
        "first_rdcycle_delta_stores": rdcycle_delta_stores[:8],
        "first_recovered_bit_stores": recovered_bit_stores[:8],
        "redirect_rows_sample": redirect_rows[:16],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("vcd", type=Path)
    ap.add_argument("symbols", type=Path)
    ap.add_argument("--json-out", type=Path, required=True)
    args = ap.parse_args()

    syms = parse_symbols(args.symbols)
    required = ["train_block", "victim_branch", "probe_branch", "probe_fallthrough", "victim_taken"]
    missing_syms = [s for s in required if s not in syms]
    if missing_syms:
        raise SystemExit(f"missing symbols: {missing_syms}")

    consts = {
        "start_pc": syms["train_block"],
        "victim_pc": syms["victim_branch"],
        "probe_pc": syms["probe_branch"],
        "probe_fallthrough": syms["probe_fallthrough"],
        "victim_target": syms["victim_taken"],
    }
    if "result_delta" in syms:
        consts["result_delta"] = syms["result_delta"]
    if "recovered_bit" in syms:
        consts["recovered_bit"] = syms["recovered_bit"]
    # XiangShan cfiPosition uses one-based halfword positions within the FTQ block.
    consts["victim_offset"] = (consts["victim_pc"] - consts["start_pc"]) // 2 + 1
    consts["probe_offset"] = (consts["probe_pc"] - consts["start_pc"]) // 2 + 1

    selected, code_to_keys = parse_header(args.vcd)
    result = parse_vcd(args.vcd, selected, code_to_keys, consts)
    result["missing"] = [
        key
        for key in [
            "redirect_valid",
            "redirect_pc",
            "redirect_target",
            "redirect_offset",
            "redirect_mispredict",
            "train_valid",
            "train_ready",
            "train_start",
            "store_0_valid",
            "store_0_bits_valid",
            "store_0_addr",
            "store_0_data",
            "store_0_pc",
            "store_1_valid",
            "store_1_bits_valid",
            "store_1_addr",
            "store_1_data",
            "store_1_pc",
            "store_2_valid",
            "store_2_bits_valid",
            "store_2_addr",
            "store_2_data",
            "store_2_pc",
        ]
        if key not in selected
    ]
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
