#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


KEYS = [
    "commit_branch_num",
    "commit_branch_mispredicts",
    "commit_branch_mispredicts_s1_source_Ubtb",
    "commit_branch_mispredicts_s3_source_Tage",
    "commit_branch_mispredicts_reason_BTB",
    "commit_branch_mispredicts_reason_TAGE",
    "commit_conditional_branch_mispredicts_reason_BTB",
    "commit_branch_mispredicts_type_conditional",
    "commit_branch_mispredicts_type_direct",
    "commit_branch_mispredicts_type_indirect",
    "commit_branch_mispredicts_type_ret",
    "commitInstr",
    "commitInstrBranch",
    "commitInstrStore",
]


PERF_RE = re.compile(r"\[PERF\s*\].*:\s*([^,]+),\s*(-?\d+)\s*$")


def parse_perf(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in path.read_text(errors="replace").splitlines():
        match = PERF_RE.search(line)
        if not match:
            continue
        key, raw_value = match.groups()
        key = key.strip()
        if key in KEYS:
            values[key] = int(raw_value)
    return values


def delta(secret0: dict[str, int], secret1: dict[str, int], key: str) -> int | None:
    if key not in secret0 or key not in secret1:
        return None
    return secret1[key] - secret0[key]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("secret0_log", type=Path)
    ap.add_argument("secret1_log", type=Path)
    ap.add_argument("--json-out", type=Path, required=True)
    args = ap.parse_args()

    counters = {
        "0": parse_perf(args.secret0_log),
        "1": parse_perf(args.secret1_log),
    }
    deltas = {key: delta(counters["0"], counters["1"], key) for key in KEYS}

    total_mispredict_delta = deltas["commit_branch_mispredicts"]
    conditional_mispredict_delta = deltas["commit_branch_mispredicts_type_conditional"]
    tage_reason_delta = deltas["commit_branch_mispredicts_reason_TAGE"]

    observable = (
        total_mispredict_delta is not None
        and conditional_mispredict_delta is not None
        and total_mispredict_delta >= 1
        and conditional_mispredict_delta >= 1
    )

    result = {
        "logs": {
            "secret_0": str(args.secret0_log),
            "secret_1": str(args.secret1_log),
        },
        "counters": counters,
        "deltas_secret1_minus_secret0": deltas,
        "predicate": {
            "secret1_has_extra_committed_branch_mispredict": bool(
                total_mispredict_delta is not None and total_mispredict_delta >= 1
            ),
            "secret1_has_extra_conditional_branch_mispredict": bool(
                conditional_mispredict_delta is not None and conditional_mispredict_delta >= 1
            ),
            "secret1_has_extra_tage_reason_mispredict": bool(
                tage_reason_delta is not None and tage_reason_delta >= 1
            ),
            "emulator_perf_counter_observable": observable,
        },
    }

    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["predicate"], indent=2, sort_keys=True))
    return 0 if observable else 1


if __name__ == "__main__":
    raise SystemExit(main())
