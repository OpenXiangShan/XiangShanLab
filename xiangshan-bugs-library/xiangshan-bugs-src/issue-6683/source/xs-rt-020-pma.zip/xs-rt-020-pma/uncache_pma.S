
.option norvc
.section .text.init
.globl _start
_start:
  /* M-mode, no interrupts, bare translation */
  csrci mstatus, 8
  csrw mie, zero
  csrw satp, zero
  la t0, trap_handler
  csrw mtvec, t0

  li s0, 0x80100000
  li ra, 0x1111111111111111

  /* Allocate a dirty cache line while the page is still cacheable. */
  sd ra, 0(s0)
  sd ra, 8(s0)
  sd ra, 16(s0)
  sd ra, 24(s0)
  sd ra, 32(s0)
  sd ra, 40(s0)
  sd ra, 48(s0)
  sd ra, 56(s0)
  ld t0, 0(s0)
  ld t1, 56(s0)
  fence

  /* PMA entry 0: NAPOT 4KB at 0x80100000, R/W, not cacheable, not atomic.
     pmaaddr = (pa>>2) | 9 trailing ones. cfg byte = R|W|A_NAPOT = 0x1b. */
  li t2, 0x200401FF
  csrw 0x7c8, t2
  li t3, 0x1b
  csrw 0x7c0, t3
  fence
  csrr s8, 0x7c8
  csrr s9, 0x7c0

  /* Dependent load-after-store on the uncache page. */
  li t3, 0x2222222222222222
  sd t3, 0(s0)
  ld t4, 0(s0)
  sd t4, 32(s0)
  ld t5, 32(s0)

  /* Byte store then dependent byte load, same address. */
  li t6, 0xab
  sb t6, 24(s0)
  lbu a1, 24(s0)

  /* Train backward branch taken, then make it not-taken.
     Speculative body does an uncache store of poison and an uncache load. */
  li s2, 0
  li a3, 1
  li a4, 24
spec_br:
  bnez a3, spec_body
  j spec_join
spec_body:
  beqz s2, spec_train_only
  li t0, 0xdeadbeefdeadbeef
  sd t0, 16(s0)
  ld a5, 0(s0)
spec_train_only:
  addi a4, a4, -1
  bnez a4, spec_br
  li s2, 1
  li a3, 0
  li a4, 1
  j spec_br
spec_join:
  ld a6, 16(s0)

  /* Loop-exit mispredict: extra uncache store would write -1. */
  li a4, 6
cnt_loop:
  addi a4, a4, -1
  sd a4, 8(s0)
  bnez a4, cnt_loop
  ld a7, 8(s0)

  /* Evict the stale dirty line (set 0, 8 ways) and read again. */
  li t0, 32
  li t1, 0x81000000
  li t2, 0x2000
evict:
  sd t0, 0(t1)
  add t1, t1, t2
  addi t0, t0, -1
  bnez t0, evict
  fence
  ld s3, 0(s0)
  ld s4, 32(s0)

  /* Checks. Distinct good-trap PCs identify an agreed failure. */
  bne t4, t3, fail_raw
  bne t5, t3, fail_dep
  li t0, 0xab
  bne a1, t0, fail_byte
  bne a6, ra, fail_spec
  bnez a7, fail_extra
  bne s3, t3, fail_evict
  bne s4, t3, fail_evict2

  /* Misaligned load: PMA MMIO should access-fault (mcause=5). */
  la t0, mis_fault
  csrw mtvec, t0
  lw t0, 1(s0)
  la t0, trap_handler
  csrw mtvec, t0
  j pass_nommio
mis_fault:
  csrr s5, mcause
  csrr s6, mtval
  la t0, trap_handler
  csrw mtvec, t0
  li t0, 5
  bne s5, t0, pass_other
  j pass_mmio

pass_nommio:
  li a0, 0
  .word 0x0000006b
pass_mmio:
  li a0, 0
  .word 0x0000006b
pass_other:
  li a0, 6
  .word 0x0000006b
fail_raw:
  li a0, 1
  .word 0x0000006b
fail_dep:
  li a0, 2
  .word 0x0000006b
fail_byte:
  li a0, 3
  .word 0x0000006b
fail_spec:
  li a0, 4
  .word 0x0000006b
fail_extra:
  li a0, 5
  .word 0x0000006b
fail_evict:
  li a0, 7
  .word 0x0000006b
fail_evict2:
  li a0, 8
  .word 0x0000006b

trap_handler:
  csrr a0, mcause
  csrr a1, mtval
  ori a0, a0, 0x100
  .word 0x0000006b
