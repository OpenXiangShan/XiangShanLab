xiangshan vlm-vsm-overrun reproducer
====================================

Issue: [BUG] vlm.v/vsm.v ignore ceil(vl/8) and transfer a full 16-byte line

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: 3c544977fdf9081537955dd75f7c52900dd69e9bf76538f5ce5bf96287f2ebed

prog.c
    Reproducer source.
    SHA-256: fe6151c433334ee5475a63829818407fc7281d5d0864aefef909a72d8645f2ef

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: 3c303368acb831043c8b26eb2db1850fd9c9dbc713b6b81c7e4a91fbfde50a74

sim.log
    Difftest log of the failing run.
    SHA-256: 42a218600d1c28d577fbf3aa4ad19ad5595c94bb0a940f46685471d218623ed2

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures `vl=8`, points a memory buffer at all-`0xaa` data, and executes `vlm.v` into the mask register at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB.
- Run the same ELF on the Spike difftest reference and compare the destination register; the same program also contains the `vsm.v` probe.

Expected:
  For `vlm.v v2, (mem)` with `vl=8` and source `0xaa`, Spike produces `v2_low = 0x9e9fd003136a0caa`, `v2_high = 0xc6c5f37686b0ffdb` (only the low byte changed).

Observed:
  The DUT overwrites both halves with the source pattern:
  
  ```text
   v2_low  different at pc = 0xfffe10d5004db516, right = 0x9e9fd003136a0caa, wrong = 0xaaaaaaaaaaaaaaaa
  v2_high different at pc = 0xfffe10d5004db516, right = 0xc6c5f37686b0ffdb, wrong = 0xaaaaaaaaaaaaaaaa
  Core 0: ABORT at pc = 0xfffe10d5004db516
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
