li x13, 0x80
li x14, 0x1490534e200a47ba
li x15, 0xfdf7618d2496ba28
li x16, 0xc7be21a994d6aa8f
li x17, 0xcffdb58628089f8a
li x18, 0xfffffffffffffffe
li x19, 0x2210dc3ced2682e5
li x20, 0xd9288d531a6e8a27
vsetvli x9, x0, e64, m1
li x8, 0x0
vmv.v.x v13, x8
li x8, 0xaaaaaaaaaaaaaaaa
vmv.v.x v14, x8
li x8, 0xf0f0f0f0f0f0f0f
vmv.v.x v15, x8
li x8, 0x0
vmv.v.x v16, x8
li x8, 0xf0f0f0f0f0f0f0f
vmv.v.x v17, x8
li x8, 0x5555555555555555
vmv.v.x v18, x8
li x8, 0xf0f0f0f0f0f0f0f
vmv.v.x v19, x8
li x8, 0xffffffffffffffff
vmv.v.x v20, x8
li x9, 0x8fffffb8
li x10, 0x7fff
sd x10, 0(x9)
li x10, 0x100
sd x10, 8(x9)
li x10, 0x1000
sd x10, 16(x9)
li x10, 0x2c92056bca470fac
sd x10, 24(x9)
li x10, 0x666adfe29621898f
sd x10, 32(x9)
li x10, 0x2b07c73b2b2eeb90
sd x10, 40(x9)
li x10, 0xbe60ebff7a3af395
sd x10, 48(x9)
li x10, 0x9d41418aadb35b20
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
# >>> SYNTHETIC BLOCK START 01 [source=no-block-markers]
srai x14, x19, 10
c.add x20, x19
subw x15, x13, x15
li x2, 2415919067
c.sdsp x16, 0(sp)
addw x17, x17, x16
li x9, 2415919039
vsoxseg6ei16.v v13, (x9), v18, v0.t
fence.i
mulh x14, x13, x17
ori x18, x16, -1816
fence.i
li x8, 2415919058
vle8ff.v v14, (x8), v0.t
srlw x15, x18, x19
c.andi x14, 31
mulhsu x14, x16, x19
# <<< SYNTHETIC BLOCK END   01
# >>> SYNTHETIC BLOCK START 02 [source=no-block-markers]
mulhsu x20, x19, x15
c.subw x13, x13
li x10, 2415919041
vluxseg4ei8.v v15, (x10), v14, v0.t
fence.i
remu x13, x16, x15
li x12, 2415919045
lb x15, 13(x12)
li x8, 2415919064
lwu x20, 9(x8)
c.srai x14, 32
fence.i
c.addi16sp sp, 16
c.subw x14, x13
div x19, x18, x19
remu x13, x17, x18
or x13, x18, x13
# <<< SYNTHETIC BLOCK END   02
