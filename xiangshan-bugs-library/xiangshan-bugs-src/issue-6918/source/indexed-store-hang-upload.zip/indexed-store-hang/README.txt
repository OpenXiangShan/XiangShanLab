xiangshan indexed-store-hang reproducer
=======================================

Issue: [BUG] Indexed and segment vector stores never commit and block ROB (CROB-STUCK)

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: 64ab30d9326cfe5fb8b408b12582b75eae92a15e82ad0a59bf9e6b8dd77def5e

prog.c
    Reproducer source.
    SHA-256: eed446740b5778b264b2539a9497ec3876f9a0ae24c4b6935c8ae8dc2466517c

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: 2dca1a0b15777ba954506937d89fc8d52d686b9e9d745d61c75a95c7079561a0

sim.log
    Difftest log of the failing run.
    SHA-256: 6f04e9b739f832d91e8f1134eadf499eb09b73d894670485fe241101d4afd1f0

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures SEW=8, LMUL=m1, loads the value and stride registers, and executes `vsse8.v` at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB; the run stops after 15000 cycles without a commit.
- Run the same ELF on the Spike difftest reference: the reference completes the store and retires.

Expected:
  `vsse8.v` SEW=8 must complete and retire, with the same memory side effects as the Spike reference.

Observed:
  The DUT stops making progress:
  
  ```text
  No instruction of core 0 commits for 15000 cycles, maybe get stuck
  Core 0: ABORT at pc = 0x22019c64aae1
  [CROB-STUCK] ... headPC=0000080000962 ...
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
