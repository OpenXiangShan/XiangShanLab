.text
   .global _start
 _start:
    li t1, 0x00006000
    or t0, t0, t1
    csrw mstatus, t0
   
    addi x1, x0, 0x1ab
    slli x1, x1, 4
    mv t1, x1
    csrrw x0, mstatus, x1

    li x1, 0x00006888
    csrrs t0, mstatus, x1
    
    li t1, 0x0000800
    csrc  mstatus, t1
    csrr t2, mstatus

  end:
    j end

