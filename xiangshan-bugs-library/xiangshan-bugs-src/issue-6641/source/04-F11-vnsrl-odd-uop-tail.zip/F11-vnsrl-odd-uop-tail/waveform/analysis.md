# F11 waveform evidence: narrow results bypassed and odd uop treated as all tail

## Capture and agreement with the issue

This is a new seed-0 trace of the unchanged PoC and reference library on pinned DUT source `b9636416b81d266f3a3d4d1e46d4e66e6a574bcd`, `MinimalConfig`. The FST-enabled rebuild is a different emulator binary from the original one. [run.json](run.json) records the command, hashes and `dirty=0` stamp. Both final `v2_low` and `v2_high` equal all ones, exactly matching the original ta-case mismatch. No watchdog triggers.

The waveform corroborates the ta report and supplies micro-operation evidence for both normal-result selection and an incorrect odd-uop merge boundary. It does not establish that these are the only required fixes.

![F11: both narrow uops, internal narrow results, merge and vector write ports](waveform.png)

The figure uses actual FST samples read with wavekit. The raw FST is retained in the original full evidence archive (`issue-packages-20260926`), outside this submission package. Exact paths are in [figure selection](waveform-selection.json), values in [figure samples](waveform-samples.json), and additional identity/control/commit evidence in [detail samples](detail-samples.json) and [mapping samples](mapping-samples.json). Cycles are falling-edge sample indices from the beginning of the FST, including reset, not printed DUT `cycleCnt`. A write-port sample denotes a stable request before the next rising edge. Invalid-cycle data in the plot must not be interpreted as a result.

## Instruction and two-uop association

| FST cycle | Observed event |
| --- | --- |
| 6209 | ROB enqueue slots 4 and 5: valid 1, PC `0x8000054c`, instruction `0xb2443157`, ROB `(flag=0,value=32)`; `io_enq_canAccept=1`. |
| 6218 | Two simultaneous valid EXU inputs for the same ROB. `issuePipes_1`: uop 0 / pdest `0x32`; `issuePipes_2`: uop 1 / pdest `0x33`. Both have fuType `0x400000`, opcode `0x1e8`, SEW encoding 0, VL 16, vta 1. |
| 6219 | Both EX0 contexts and Vialu output slots are valid. Both `Vialu.isNarrow_regs_0=1`. Their distinct normal and internal narrow outputs are listed below. |
| 6220 | Vector write port 1 has wen 1, address `0x32`, normal-shaped source data; port 2 has wen 1, address `0x33`, all-ones data. |
| 6221 | ROB commit slot 0 has isCommit 1, commitValid 1 and ROB `(0,32)`. |
| 6222 | Committed `rename.rat.diffRatBuffer.io_diffRat_vecRat_2` becomes `0x33`, tying architectural v2 to the odd-uop all-ones write. v3 remains mapped to 3. |

Both EXU flush inputs assert at sample 6215, then are zero when the two target uops execute at 6218–6219. The two uops execute in different pipes at the same time; the trace does not show uop 1 consuming a just-produced uop 0 result.

## Measured data at the valid release cycle 6219

| Observation | Uop 0 (`issuePipes_1.exu`) | Uop 1 (`issuePipes_2.exu`) |
| --- | --- | --- |
| Physical destination | `0x32` | `0x33` |
| `Vialu.vialus_0.misc.out_res_narrow[31:0]` | `0x03020100` | `0x0b0a0908` |
| `Vialu.vialus_1.misc.out_res_narrow[31:0]` | `0x07060504` | `0x0f0e0d0c` |
| `_Vialu_out_ex_0_bits_data_vec_normal[127:0]` | `0x07ab06ab05ab04ab_03ab02ab01ab00ab` | `0x0fab0eab0dab0cab_0bab0aab09ab08ab` |
| `eewOHEx_0[3:0]` | `0x1` (8-bit) | `0x1` (8-bit) |
| `mgus_0.in_data_end[4:0]` | 16 | 0 |
| `mgus_0.out_activeEn[15:0]` | `0xffff` | `0x0000` |
| `mgus_0.in_ctrl_vta` | 1 | 1 |
| Actual merge oldVd, all 16 bytes | `08` repeated | `08` repeated |
| Merged output / subsequent RF data | `0x07ab06ab05ab04ab_03ab02ab01ab00ab` | `0xffffffffffffffff_ffffffffffffffff` |

The four observed internal 32-bit narrow results contain exactly bytes `00..0f`. `VIAlu.scala:70` connects `misc.out.res.narrow` to the narrow result, and `VIAluWrapper.scala:149–150` defines separate normal/narrow concatenations. The top-level unused narrow bus is optimized out of this generated trace; the figure deliberately shows the four real internal lane signals rather than fabricating an aggregate waveform.

`Exu.scala:144–146` selects the normal result for merge. At this instruction's release, that selected normal result retains the sixteen-bit source pattern. Separately, `Exu.scala:141–163` uses uopIdx as a destination-register index: uop 1 receives end=0 even though its narrow bytes are part of the active 128-bit v2 destination. `MergeUnit.scala:70–90` consequently selects all-ones tail-agnostic bytes. The trace shows the zero active mask and final all-ones write directly.

## Important boundaries

- This waveform covers **ta only**. The previously reported tu self-check is a separate no-diff execution. Its stored `07ab...00ab` value remains valid log evidence, but this ta trace does not establish the tu forwarding/oldVd mechanism.
- In this actual ta trace, both merge oldVd inputs are sixteen `0x08` bytes, confirmed by each `mgus_0.in_data_oldVd_N` signal. Do not describe them as the initialized v2 contents or as the first uop's newly generated result. This qualification is compatible with the current MD, which treats detailed causes as hypotheses.
- `VecRegionModule.scala:337–339` ties the sampled write-data-path signals to physical register write controls. Retirement and the later architectural RAT snapshot show that v2 takes pdest `0x33`; no generic commit `data` field is used as a vector value.
- No ta observation contradicts the report. A unique repair, a waveform-level explanation of the tu run, and root-cause independence from other reports remain unverified.
