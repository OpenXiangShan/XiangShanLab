/* F11: vnsrl.wi e8 vl=16 ta from 16 x e16 (v4/v5 from a2, 32 B). v2 preset from a1. */
#include "probe-common.S"

  .align 6
  .globl f11_vnsrl
  .type  f11_vnsrl, @function
f11_vnsrl:
  vl1re64.v v2, (a1)
  vl2re64.v v4, (a2)
  vsetivli x0, 16, e8, m1, ta, ma
  vnsrl.wi v2, v4, 8
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f11_vnsrl, .-f11_vnsrl

  .align 6
  .globl f11_vnsrl_tu
  .type  f11_vnsrl_tu, @function
f11_vnsrl_tu:
  vl1re64.v v2, (a1)
  vl2re64.v v4, (a2)
  vsetivli x0, 16, e8, m1, tu, mu
  vnsrl.wi v2, v4, 8
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f11_vnsrl_tu, .-f11_vnsrl_tu
