/* F11 -- vnsrl.wi e8 with ta writes all ones to active bytes. The
 * traced uops compute the expected narrow bytes internally, but the
 * merge selects normal-shaped output and treats the odd uop as tail.
 * The tu observation has one separate self-check; its mechanism is
 * not established by this ta waveform.
 */
#include "vt-common.h"

static uint8_t preset[16] __attribute__((aligned(16)));
static uint8_t h[32] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f11_vnsrl(void *o, const void *p, const void *h);
extern void f11_vnsrl_tu(void *o, const void *p, const void *h);

int main(void) {
  int bugs = 0, i;
  uint8_t exp[16];
  for (i = 0; i < 16; i++) preset[i] = (uint8_t)(0xC0 + i);
  for (i = 0; i < 16; i++) { h[2 * i] = 0xAB; h[2 * i + 1] = (uint8_t)i; } /* h[i] = (i << 8) | 0xAB */
  for (i = 0; i < 16; i++) exp[i] = (uint8_t)i;                              /* >> 8 -> i */
  if (vt_init("F11") != 0) return 1;
  printf("[F11] start cyc=%lu\n", (unsigned long)cyc());

  memset(out, 0, 16); f11_vnsrl(out, preset, h); VT_FENCE();
  { int ok = !memcmp_(out, exp, 16); if (!ok) bugs++;
    printf("[F11] vnsrl.wi ta: v2=%016lx_%016lx expect=0f0e0d0c0b0a0908_0706050403020100 %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           ok ? "ok" : (out_q(out, 1) == ONES && out_q(out, 0) == ONES ? "BUG: whole register all-ones" : "BUG")); }
  memset(out, 0, 16); f11_vnsrl_tu(out, preset, h); VT_FENCE();
  { int ok = !memcmp_(out, exp, 16); if (!ok) bugs++;
    printf("[F11] vnsrl.wi tu: v2=%016lx_%016lx expect=0f0e0d0c0b0a0908_0706050403020100 %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0), ok ? "ok" : "BUG"); }
  printf("[F11] done bugs=%d verdict=%s\n", bugs, bugs ? "NARROW_ODD_UOP_TAIL" : "clean");
  return 0;
}
