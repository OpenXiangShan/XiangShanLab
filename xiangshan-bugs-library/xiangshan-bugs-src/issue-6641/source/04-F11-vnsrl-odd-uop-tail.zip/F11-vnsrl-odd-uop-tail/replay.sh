#!/usr/bin/env bash
set -euo pipefail
case_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
emu="${XS_EMU:-/data/runs/caijf/dut/vector/recheck-v3-20260924/emu-from-objects}"
ref="${XS_REF:-/data/runs/caijf/xiangshan-current/v3/ready-to-run/riscv64-nemu-interpreter-so}"
image="$case_dir/poc/build/f11-vnsrl-odd-uop-tail-riscv64-xs-light-kunminghu-v3.bin"
verify() {
  local got
  got=$(sha256sum -- "$1")
  if [[ "${got%% *}" != "$2" ]]; then
    printf 'Hash mismatch: %s
' "$1" >&2
    exit 2
  fi
}
verify "$emu" 0abff033b2704ea5797db9209f545c154c2d16f1c52764dbbdd9e0b870944c10
verify "$ref" 9188e7dda30709962f0bfbc1dd87cea73d88a18c92c30892f93ed529c22def43
verify "$image" b6df3899e34bb256bc8d7d66ea88dd9ddcab123d0d3f83ca6aa4c96e56b35c14
exec timeout 900s "$emu" -i "$image" --diff "$ref" -C 100000 --log-end=0 --seed="${1:-0}"
