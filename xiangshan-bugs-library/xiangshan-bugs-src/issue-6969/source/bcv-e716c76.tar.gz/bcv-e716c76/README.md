# Run

The emu is kunminghu-v3 `e716c76582`, DefaultConfig.

```
./build/emu -i bin/bcv-d0.bin --no-diff -C 6000000
./build/emu -i bin/bcv-d1.bin --no-diff -C 6000000
./build/emu -i bin/bcv-d2.bin --no-diff -C 6000000
./build/emu -i bin/bcv-u1.bin --no-diff -C 6000000
```

To run with difftest, use a NEMU reference that has bitmap checking: build NEMU master (`de1cb67b`) from `riscv64-xs-ref_defconfig` with `CONFIG_RV_MBMC=y` added.

```
./build/emu -i bin/bcv-d0.bin --diff <nemu-mbmc>/build/riscv64-nemu-interpreter-so -C 6000000
./build/emu -i bin/bcv-d2.bin --diff <nemu-mbmc>/build/riscv64-nemu-interpreter-so -C 6000000
```

# Results

The exit PC is the `pc` the emu prints when the program traps out. The UART lines are printed by the program.

| Image | Expected | Actual |
|---|---|---|
| `bcv-d0.bin` | exit PC `0x80000218`, UART `N0000000000000000` | exit PC `0x80000224` |
| `bcv-d1.bin` | exit PC `0x8000022c`, UART `N0000000000000000` | exit PC `0x80000232`, UART `H0000000000000044` `N0000000000000001` |
| `bcv-d2.bin` | exit PC `0x80000214`, UART `N0000000000000000` | same as expected |
| `bcv-u1.bin` | exit PC `0x80000230`, UART `N0000000000000000` | exit PC `0x80000236`, UART `H000000000000003c` `N0000000000000001` |
| `bcv-d0.bin`, difftest | passes, exit PC `0x80000218` | difftest aborts: the reference raises a load access fault at `0x80000188` (`mepc` right = `0x80000188`), the DUT does not (`mepc` wrong = `0x8000018c`) |
| `bcv-d2.bin`, difftest | passes, exit PC `0x80000214` | same as expected |
