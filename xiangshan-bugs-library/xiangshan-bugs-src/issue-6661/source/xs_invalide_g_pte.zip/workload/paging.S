# Sv39 identity-mapped page tables for tests that need S mode.
# Include after common.S. Tables live in .data (4 KiB aligned). Clobbers t0-t2.
#
#   root[0]  0x00000000 .. 0x3fffffff  1 GiB leaf, RW      (devices)
#   root[1]  0x40000000 .. 0x7fffffff  1 GiB leaf, RW      (UART)
#   root[2]  0x80000000 .. 0xbfffffff  -> pt_l1
#   pt_l1[0] 0x80000000 .. 0x801fffff  2 MiB leaf, RWX     (code, data)
#   pt_l1[1] 0x80200000 .. 0x803fffff  -> pt_l0            (4 KiB pages, tests fill entries)
#
# paging_setup    a0 = ASID. Builds the tables, writes satp (Sv39), sfence.vma.
# ENTER_SMODE lbl jumps to lbl in S mode.
# A test installs its own M-mode handler with `csrw mtvec` before ENTER_SMODE and
# leaves S mode with `ecall`, which its handler turns into a jump back to M-mode code.

  .set PTE_V, 0x01
  .set PTE_R, 0x02
  .set PTE_W, 0x04
  .set PTE_X, 0x08
  .set PTE_G, 0x20
  .set PTE_A, 0x40
  .set PTE_D, 0x80
  .set PTE_LEAF_RW,  0xc7        # V R W A D
  .set PTE_LEAF_RWX, 0xcf        # V R W X A D
  .set TEST_PAGE,    0x80200000  # pt_l0[0]

  .macro ENTER_SMODE lbl
  la t0, \lbl
  csrw mepc, t0
  li t0, 0x1800                  # mstatus.MPP
  csrc mstatus, t0
  li t0, 0x0800                  # MPP = S
  csrs mstatus, t0
  mret
  .endm

  .text
  .globl paging_setup
paging_setup:
  li t0, -1
  srli t0, t0, 10
  csrw pmpaddr0, t0              # PMP entry 0: whole address space
  li t0, 0x1f                    # NAPOT, R W X
  csrw pmpcfg0, t0
  la t0, pt_root
  li t1, PTE_LEAF_RW             # root[0]: ppn 0
  sd t1, 0(t0)
  li t1, (0x40000000 >> 12) << 10 | PTE_LEAF_RW
  sd t1, 8(t0)
  la t2, pt_l1
  srli t2, t2, 12
  slli t2, t2, 10
  ori t2, t2, PTE_V
  sd t2, 16(t0)                  # root[2] -> pt_l1
  la t0, pt_l1
  li t1, (0x80000000 >> 12) << 10 | PTE_LEAF_RWX
  sd t1, 0(t0)
  la t2, pt_l0
  srli t2, t2, 12
  slli t2, t2, 10
  ori t2, t2, PTE_V
  sd t2, 8(t0)                   # pt_l1[1] -> pt_l0
  la t0, pt_root
  srli t0, t0, 12
  slli t1, a0, 44                # ASID
  or t0, t0, t1
  li t1, 8
  slli t1, t1, 60                # MODE = Sv39
  or t0, t0, t1
  csrw satp, t0
  sfence.vma
  ret

  .data
  .align 12
pt_root: .space 4096
pt_l1:   .space 4096
pt_l0:   .space 4096
