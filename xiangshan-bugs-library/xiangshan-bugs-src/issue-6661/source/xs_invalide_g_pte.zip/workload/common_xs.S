# XiangShan harness: run test(), print result over the sim UART, compare with
# the Spike-derived expectation on the body elements, then execute the XS trap (a0==0 -> GOOD TRAP).
  .equ UART_TX, 0x40600004
  .section .text.init
  .globl _start
_start:
  la t0, trap_handler
  csrw mtvec, t0
  li t0, (1 << 9)          # mstatus.VS = Initial
  csrs mstatus, t0
  la a0, old_vd
  la a1, src1
  la a2, src2
  la a3, result
  jal ra, test
print_result:
  la s0, result
  la s1, expected
  li s2, 16
  li s3, 0                 # mismatch bitmap
  li s4, 0                 # byte index
  la t0, ncheck
  lbu s5, 0(t0)            # bytes that must match (body; all 16 when vl=0)
  la a0, msg
  jal ra, puts
1:
  lbu a0, 0(s0)
  jal ra, puthex
  lbu t0, 0(s0)
  lbu t1, 0(s1)
  bgeu s4, s5, 2f          # tail under ta: any value (incl. all-ones) is legal
  beq t0, t1, 2f
  li t2, 1
  sll t2, t2, s4
  or s3, s3, t2
2:
  addi s0, s0, 1
  addi s1, s1, 1
  addi s4, s4, 1
  bne s4, s2, 1b
  li a0, '\n'
  jal ra, putc
  la a0, msg_vstart          # "VSTART: xx" = vstart captured by the test right after the DUT instruction
  jal ra, puts               # (0xee = not captured; at a trap: vstart as seen by the handler)
  la t0, vstart_after
  lbu a0, 0(t0)
  jal ra, puthex
  li a0, '\n'
  jal ra, putc
  snez a0, s3              # 0 = match -> GOOD TRAP, 1 = mismatch -> BAD TRAP
  .word 0x0005006b         # XiangShan trap (rs1=a0), code = a0
3: j 3b

putc:
  li t3, UART_TX
  sb a0, 0(t3)
  ret
puts:
  mv t4, ra
  mv t5, a0
4: lbu a0, 0(t5)
  beqz a0, 5f
  jal ra, putc
  addi t5, t5, 1
  j 4b
5: mv ra, t4
  ret
puthex:                    # print byte a0 as " xx"
  mv t4, ra
  mv t5, a0
  li a0, ' '
  jal ra, putc
  srli a0, t5, 4
  jal ra, nib
  andi a0, t5, 15
  jal ra, nib
  mv ra, t4
  ret
nib:
  li t6, 10
  blt a0, t6, 6f
  addi a0, a0, 'a'-10
  j putc
6: addi a0, a0, '0'
  j putc

  .align 2
trap_handler:              # any trap: report mcause, then print whatever is in result
  csrr t0, vstart
  la t1, vstart_after
  sb t0, 0(t1)
  la a0, msg_trap
  jal ra, puts
  csrr a0, mcause
  jal ra, puthex
  li a0, '\n'
  jal ra, putc
  vsetivli x0, 16, e8, m1, ta, ma
  la a3, result
  vse8.v v3, (a3)          # dump v3 as it was left at the trap
  j print_result

  .section .rodata
msg: .asciz "RESULT:"
msg_trap: .asciz "MCAUSE:"
msg_vstart: .asciz "VSTART:"
  .data
vstart_after: .byte 0xee
