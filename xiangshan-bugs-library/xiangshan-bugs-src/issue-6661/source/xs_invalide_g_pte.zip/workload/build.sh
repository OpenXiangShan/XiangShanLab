#!/usr/bin/env bash
# Build XiangShan variants of ../t*.S. Usage: bash build.sh [DEPS_DIR]
# Each ../tN.S carries two header comments:
#   # EXPECT: <16 comma-separated bytes>   expected `result` bytes (Spike reference)
#   # NCHECK: <n>                          number of leading bytes that must match (tail under ta is not compared)
# tN.S here = the same test with common_xs.S, plus an appended .data block holding expected/ncheck.
set -e
D=${1:-/home/jinyan/Project/moir/deps}
cd "$(dirname "$0")"
for src in ../t*.S; do
  t=$(basename "$src" .S)
  e=$(sed -n 's/^# EXPECT: *//p' "$src" | head -1); n=$(sed -n 's/^# NCHECK: *//p' "$src" | head -1)
  [ -n "$e" ] && [ -n "$n" ] || { echo "$src: missing # EXPECT / # NCHECK header" >&2; exit 1; }
  { sed 's/\.include "common.S"/.include "common_xs.S"/' "$src"; printf '  .data\n  .align 4\nexpected: .byte %s\nncheck: .byte %s\n' "$e" "$n"; } > "$t.S"
  "$D/riscv/bin/riscv64-unknown-elf-gcc" -march=rv64gcv_zicbom_zacas -I .. -mabi=lp64d -nostdlib -nostartfiles -static -T ../link.ld -o "$t.elf" "$t.S"
  "$D/riscv/bin/riscv64-unknown-elf-objcopy" -O binary "$t.elf" "$t.bin"
done
ls *.bin | wc -l
