# EXPECT: 1,0x5a,0,0,0,0,0,0,0,0,0,0,0,0,0,0
# NCHECK: 2
  .include "common_xs.S"
  .include "paging.S"
  .text
  .globl test
test:
  mv s10, ra                     # paging_setup clobbers ra
  li t0, TEST_PAGE
  li t1, 0x5a
  sb t1, 0(t0)                   # data at the test page (physical), before paging
  la t0, pt_l0
  li t1, PTE_G                   # pt_l0[0]: V=0, G=1  (invalid, global)
  sd t1, 0(t0)
  li a0, 1
  jal ra, paging_setup           # ASID 1
  la t0, m_handler
  csrw mtvec, t0
  li s5, 0                       # fault counter
  ENTER_SMODE s_code
s_code:
  li s7, TEST_PAGE               # s7: not touched by the M-mode handler
  lbu s6, 0(s7)                  # 1st: page fault; after repair + sfence.vma x0,asid: must succeed
  ecall
  .align 2
m_handler:
  csrr t0, mcause
  li t1, 9
  beq t0, t1, m_done
  addi s5, s5, 1
  li t1, 2
  bge s5, t1, m_done             # second fault: give up (bug)
  la t0, pt_l0
  li t1, (TEST_PAGE >> 12) << 10 | PTE_LEAF_RW | PTE_G
  sd t1, 0(t0)                   # repair the PTE
  li t0, 1
  sfence.vma x0, t0              # ASID 1 only
  mret                           # retry the load
m_done:
  csrw satp, zero
  sfence.vma
  sb s5, 0(a3)                   # result[0] = number of page faults (1 expected)
  sb s6, 1(a3)                   # result[1] = loaded byte (0x5a)
  mv ra, s10
  ret
  .align 2
  .data
  .align 4
old_vd: .space 16
src1:   .space 16
src2:   .space 16
result: .space 16
  .data
  .align 4
expected: .byte 1,0x5a,0,0,0,0,0,0,0,0,0,0,0,0,0,0
ncheck: .byte 2
