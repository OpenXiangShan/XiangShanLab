#!/usr/bin/env python3
import argparse
import json


def hamming_weight(value):
    return int(value & ((1 << 64) - 1)).bit_count()


def load_leakage(path):
    with open(path) as f:
        data = json.load(f)

    candidates = [
        event for event in data.get("recovered_secret_candidates", [])
        if event.get("toIntRf_valid") == "1"
        and event.get("backend_rf_wen") == "1"
        and event.get("backend_rf_data") is not None
    ]
    if not candidates:
        raise ValueError(f"{path}: no redirect-killed RF write candidate")

    event = candidates[0]
    value = event["backend_rf_data"]
    return {
        "monitor_json": path,
        "time": event.get("time"),
        "load_unit": event.get("load_unit"),
        "redirect_robIdx": event.get("redirect_robIdx"),
        "writeback_robIdx": event.get("writeback_robIdx"),
        "backend_rf_pdest": event.get("backend_rf_pdest"),
        "hamming_weight": hamming_weight(value),
        "expected_rf_data": data.get("expected_rf_data"),
        "expected_rf_data_hex": (
            f"0x{data['expected_rf_data']:016x}"
            if data.get("expected_rf_data") is not None else None
        ),
    }


def parse_template(value):
    if "=" not in value:
        raise argparse.ArgumentTypeError("template must be LABEL=JSON")
    label, path = value.split("=", 1)
    if not label or not path:
        raise argparse.ArgumentTypeError("template must be LABEL=JSON")
    return label, path


def parse_expectation(value):
    if "=" not in value:
        raise argparse.ArgumentTypeError("expectation must be JSON=LABEL")
    path, label = value.split("=", 1)
    if not path or not label:
        raise argparse.ArgumentTypeError("expectation must be JSON=LABEL")
    return path, label


def same_context(leakages):
    fields = (
        "time",
        "load_unit",
        "redirect_robIdx",
        "writeback_robIdx",
        "backend_rf_pdest",
    )
    return all(
        len({json.dumps(leakage.get(field), sort_keys=True) for leakage in leakages}) == 1
        for field in fields
    )


def classify(templates, attack):
    ranked = sorted(
        (
            {
                "label": label,
                "distance": abs(template["hamming_weight"] - attack["hamming_weight"]),
                "template_hamming_weight": template["hamming_weight"],
                "template_json": template["monitor_json"],
            }
            for label, template in templates
        ),
        key=lambda item: (item["distance"], item["label"]),
    )
    return ranked


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Template attack over redirect-killed RF write bus Hamming weight. "
            "Templates are LABEL=monitor.json; attack traces are classified by "
            "nearest Hamming-weight leakage."
        )
    )
    ap.add_argument(
        "--template",
        action="append",
        type=parse_template,
        required=True,
        help="Template as LABEL=monitor.json. Repeat for multiple classes.",
    )
    ap.add_argument(
        "--expect",
        action="append",
        type=parse_expectation,
        default=[],
        help="Expected classification as monitor.json=LABEL.",
    )
    ap.add_argument("attack_json", nargs="+")
    args = ap.parse_args()

    templates = [
        (label, load_leakage(path))
        for label, path in args.template
    ]
    attacks = [load_leakage(path) for path in args.attack_json]
    expectations = dict(args.expect)
    all_leakages = [template for _, template in templates] + attacks
    context_ok = same_context(all_leakages)
    template_paths = {template["monitor_json"] for _, template in templates}

    classifications = []
    for attack in attacks:
        ranked = classify(templates, attack)
        top = ranked[0] if ranked else None
        expected_label = expectations.get(attack["monitor_json"])
        predicted_label = top["label"] if top else None
        classifications.append({
            "attack_json": attack["monitor_json"],
            "attack_hamming_weight": attack["hamming_weight"],
            "predicted_label": predicted_label,
            "expected_label": expected_label,
            "matches_expected_label": (
                expected_label is None or expected_label == predicted_label
            ),
            "is_held_out_from_templates": attack["monitor_json"] not in template_paths,
            "nearest_template_distance": top["distance"] if top else None,
            "expected_rf_data_hex": attack["expected_rf_data_hex"],
            "ranking": ranked,
        })

    ambiguous = [
        item for item in classifications
        if len(item["ranking"]) > 1
        and item["ranking"][0]["distance"] == item["ranking"][1]["distance"]
    ]
    expected_labels_match = all(
        item["matches_expected_label"]
        for item in classifications
    )
    held_out_attack_traces = all(
        item["is_held_out_from_templates"]
        for item in classifications
    )
    summary = {
        "rf_hw_template_attack_success": (
            context_ok
            and bool(classifications)
            and not ambiguous
            and expected_labels_match
            and all(item["nearest_template_distance"] == 0 for item in classifications)
        ),
        "same_microarchitectural_context": context_ok,
        "held_out_attack_traces": held_out_attack_traces,
        "expected_labels_match": expected_labels_match,
        "leakage_feature": "redirect-killed RF write data bus Hamming weight",
        "template_classes": [
            {
                "label": label,
                "monitor_json": leakage["monitor_json"],
                "hamming_weight": leakage["hamming_weight"],
                "expected_rf_data_hex": leakage["expected_rf_data_hex"],
            }
            for label, leakage in templates
        ],
        "classifications": classifications,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["rf_hw_template_attack_success"]:
        raise SystemExit("RF Hamming-weight template attack not proven")


if __name__ == "__main__":
    main()
