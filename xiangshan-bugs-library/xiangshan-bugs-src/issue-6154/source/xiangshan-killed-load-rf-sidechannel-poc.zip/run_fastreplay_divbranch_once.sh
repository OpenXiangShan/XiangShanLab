#!/usr/bin/env bash
set -euo pipefail

usage="usage: run_fastreplay_divbranch_once.sh DIV_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [LOAD_BASE_DEP_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES] [START_OFFSET]"

div_reps="${1:?${usage}}"
loads="${2:?${usage}}"
bubbles="${3:?${usage}}"
secret="${4:-64}"
delay="${5:-0}"
load_base_dep="${6:-0}"
dump_begin="${7:-7800}"
dump_end="${8:-8600}"
max_cycles="${9:-9000}"
start_offset="${10:-0}"
prefix="fastdiv_dr${div_reps}_l${loads}_b${bubbles}_d${delay}_ld${load_base_dep}_off${start_offset}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DSTART_OFFSET="${start_offset}" \
  -DDIV_REPS="${div_reps}" \
  -DFALLTHROUGH_DELAY="${delay}" \
  -DLOAD_BASE_DEP_DELAY="${load_base_dep}" \
  -DLOAD_REPS="${loads}" \
  -DBUBBLE_REPS="${bubbles}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_fastreplay_divbranch.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

secret_base="$(awk '$3 == "secret_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${secret_base}"
