#!/usr/bin/env bash
set -euo pipefail

warm="${1:?usage: run_fastreplay_warm_once.sh WARM_REPS SETTLE_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]}"
settle="${2:?usage: run_fastreplay_warm_once.sh WARM_REPS SETTLE_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]}"
loads="${3:?usage: run_fastreplay_warm_once.sh WARM_REPS SETTLE_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]}"
bubbles="${4:?usage: run_fastreplay_warm_once.sh WARM_REPS SETTLE_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]}"
secret="${5:-64}"
delay="${6:-6}"
dump_begin="${7:-8000}"
dump_end="${8:-11000}"
max_cycles="${9:-12000}"
prefix="fastwarm_w${warm}_s${settle}_l${loads}_b${bubbles}_d${delay}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DWARM_REPS="${warm}" \
  -DSETTLE_REPS="${settle}" \
  -DLOAD_REPS="${loads}" \
  -DBUBBLE_REPS="${bubbles}" \
  -DFALLTHROUGH_DELAY="${delay}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_fastreplay_warm.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

secret_base="$(awk '$3 == "secret_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${secret_base}"
