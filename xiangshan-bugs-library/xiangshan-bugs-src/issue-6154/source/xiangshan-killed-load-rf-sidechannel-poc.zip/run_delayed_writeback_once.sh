#!/usr/bin/env bash
set -euo pipefail

usage="usage: run_delayed_writeback_once.sh BRANCH_DEP_REPS LOAD_REPS TARGET_ALLOC_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]"
branch_dep="${1:?${usage}}"
loads="${2:?${usage}}"
target_allocs="${3:?${usage}}"
secret="${4:-64}"
fallthrough_delay="${5:-0}"
dump_begin="${6:-8000}"
dump_end="${7:-9000}"
max_cycles="${8:-10000}"
prefix="delaywb_bd${branch_dep}_l${loads}_ta${target_allocs}_fd${fallthrough_delay}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DBRANCH_DEP_REPS="${branch_dep}" \
  -DLOAD_REPS="${loads}" \
  -DTARGET_ALLOC_REPS="${target_allocs}" \
  -DFALLTHROUGH_DELAY="${fallthrough_delay}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_delayed_writeback.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

probe_base="$(awk '$3 == "probe_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${probe_base}"
