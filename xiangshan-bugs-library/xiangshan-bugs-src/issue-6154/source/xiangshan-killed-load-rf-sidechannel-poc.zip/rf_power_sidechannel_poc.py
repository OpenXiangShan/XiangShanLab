#!/usr/bin/env python3
import argparse
import json


def hamming_weight(value):
    return int(value & ((1 << 64) - 1)).bit_count()


def load_event(path):
    with open(path) as f:
        data = json.load(f)

    candidates = [
        event for event in data.get("recovered_secret_candidates", [])
        if event.get("toIntRf_valid") == "1"
        and event.get("backend_rf_wen") == "1"
        and event.get("backend_rf_data") is not None
    ]
    if not candidates:
        raise ValueError(f"{path}: no redirect-killed RF write candidate")

    event = candidates[0]
    value = event["backend_rf_data"]
    expected = data.get("expected_rf_data")
    secret_offset = data.get("secret_offset")
    return {
        "monitor_json": path,
        "time": event.get("time"),
        "load_unit": event.get("load_unit"),
        "cycles_after_redirect": event.get("cycles_after_redirect"),
        "redirect_robIdx": event.get("redirect_robIdx"),
        "writeback_robIdx": event.get("writeback_robIdx"),
        "backend_rf_pdest": event.get("backend_rf_pdest"),
        "backend_rf_wen": event.get("backend_rf_wen"),
        "toIntRf_valid": event.get("toIntRf_valid"),
        "backend_rf_data": value,
        "backend_rf_data_hex": f"0x{value:016x}",
        "expected_rf_data": expected,
        "secret_offset": secret_offset,
        "data_matches_expected": expected is None or value == expected,
        "hamming_weight": hamming_weight(value),
    }


def same_field(events, field):
    values = {json.dumps(event.get(field), sort_keys=True) for event in events}
    return len(values) == 1


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Power/EM-style leakage checker for redirect-killed load RF writes. "
            "It uses the RF data bus value from monitor JSONs as an ideal "
            "Hamming-weight leakage model."
        )
    )
    ap.add_argument("monitor_json", nargs="+")
    args = ap.parse_args()

    events = [load_event(path) for path in args.monitor_json]
    weights = sorted({event["hamming_weight"] for event in events})
    values = sorted({event["backend_rf_data"] for event in events})
    same_context = all(
        same_field(events, field)
        for field in (
            "time",
            "load_unit",
            "redirect_robIdx",
            "writeback_robIdx",
            "backend_rf_pdest",
        )
    )
    all_redirect_killed = all(
        event["cycles_after_redirect"] is not None
        and event["cycles_after_redirect"] >= 0
        for event in events
    )
    all_drive_rf = all(
        event["toIntRf_valid"] == "1" and event["backend_rf_wen"] == "1"
        for event in events
    )
    all_match_expected = all(event["data_matches_expected"] for event in events)

    summary = {
        "rf_power_sidechannel_leak_observed": (
            len(events) >= 2
            and same_context
            and all_redirect_killed
            and all_drive_rf
            and all_match_expected
            and len(weights) >= 2
        ),
        "same_microarchitectural_context": same_context,
        "all_events_are_redirect_killed": all_redirect_killed,
        "all_events_drive_rf_write": all_drive_rf,
        "all_data_matches_expected_secret": all_match_expected,
        "distinct_bus_values": [f"0x{value:016x}" for value in values],
        "distinct_hamming_weights": weights,
        "leakage_model": "RF write data bus Hamming weight",
        "security_interpretation": (
            "A physical power/EM observer with cycle alignment could "
            "distinguish these redirect-killed wrong-path load secrets from "
            "RF write bus switching activity."
        ),
        "software_timing_leak_proven": False,
        "observations": events,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["rf_power_sidechannel_leak_observed"]:
        raise SystemExit("RF power side-channel leakage not proven")


if __name__ == "__main__":
    main()
