#!/usr/bin/env python3
import argparse
import json


def rob_after(write_flag, write_value, redirect_flag, redirect_value):
    if None in (write_flag, write_value, redirect_flag, redirect_value):
        return False
    if write_flag != redirect_flag:
        return write_value < redirect_value
    return write_value > redirect_value


def hamming_weight(value):
    return int(value).bit_count()


def load_observation(path):
    with open(path) as f:
        result = json.load(f)

    candidates = result.get("recovered_secret_candidates", [])
    if not candidates:
        raise ValueError(f"{path}: no killed RF writeback candidate")

    event = candidates[0]
    redirect = event["redirect_robIdx"]
    writeback = event["writeback_robIdx"]
    killed = rob_after(
        writeback.get("flag"),
        writeback.get("value"),
        redirect.get("flag"),
        redirect.get("value"),
    )
    recovered = event.get("backend_rf_data")
    if recovered is None:
        raise ValueError(f"{path}: candidate has no RF data")

    lsq = event.get("lsq_ldin") or {}
    busytable_wb = event.get("dispatch_busytable_wb") or {}
    return {
        "monitor_json": path,
        "time": event.get("time"),
        "load_unit": event.get("load_unit"),
        "redirect_robIdx": redirect,
        "writeback_robIdx": writeback,
        "is_killed_by_redirect": killed,
        "toIntRf_valid": event.get("toIntRf_valid"),
        "backend_rf_wen": event.get("backend_rf_wen"),
        "backend_rf_pdest": event.get("backend_rf_pdest"),
        "recovered_secret": recovered,
        "recovered_secret_hex": f"0x{recovered:016x}",
        "hamming_weight": hamming_weight(recovered),
        "lsq_ldin_valid": lsq.get("valid"),
        "lsq_ldin_updateAddrValid": lsq.get("updateAddrValid"),
        "lsq_ldin_robIdx": lsq.get("robIdx"),
        "busytable_wb_valid": busytable_wb.get("valid"),
        "busytable_wb_pdest": busytable_wb.get("pdest"),
        "predicate": result.get("predicate", {}),
    }


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Exploit-style checker for the killed-load RF bus leak. "
            "Each input is a monitor JSON produced by monitor_secret_probe_vcd.py."
        )
    )
    ap.add_argument("monitor_json", nargs="+")
    args = ap.parse_args()

    observations = [load_observation(path) for path in args.monitor_json]
    values = [obs["recovered_secret"] for obs in observations]
    summary = {
        "observations": observations,
        "all_events_are_redirect_killed": all(
            obs["is_killed_by_redirect"] for obs in observations
        ),
        "all_events_drive_rf_write": all(
            obs["toIntRf_valid"] == "1" and obs["backend_rf_wen"] == "1"
            for obs in observations
        ),
        "all_events_reach_lsq_ldin": all(
            obs["lsq_ldin_valid"] == "1" and obs["lsq_ldin_updateAddrValid"] == "1"
            for obs in observations
        ),
        "all_events_mark_busytable_ready": all(
            obs["busytable_wb_valid"] == "1"
            and obs["busytable_wb_pdest"] == obs["backend_rf_pdest"]
            for obs in observations
        ),
        "distinct_recovered_secret_count": len(set(values)),
        "differential_rf_bus_leakage_observed": len(set(values)) > 1,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["all_events_are_redirect_killed"]:
        raise SystemExit("not all observations are redirect-killed events")
    if not summary["all_events_drive_rf_write"]:
        raise SystemExit("not all observations drive the RF write port")
    if not summary["all_events_mark_busytable_ready"]:
        raise SystemExit("not all observations mark the busy table ready input")
    if len(observations) > 1 and not summary["differential_rf_bus_leakage_observed"]:
        raise SystemExit("observations did not expose distinct recovered values")


if __name__ == "__main__":
    main()
