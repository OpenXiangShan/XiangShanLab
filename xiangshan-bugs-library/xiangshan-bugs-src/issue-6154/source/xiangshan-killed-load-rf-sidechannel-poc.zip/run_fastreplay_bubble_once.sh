#!/usr/bin/env bash
set -euo pipefail

usage="usage: run_fastreplay_bubble_once.sh LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [FALLTHROUGH_DELAY] [BRANCH_DEP_DELAY] [LOAD_BASE_DEP_DELAY] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]"

loads="${1:?${usage}}"
bubbles="${2:?${usage}}"
secret="${3:-64}"
delay="${4:-6}"
branch_dep="${5:-0}"
load_base_dep="${6:-0}"
dump_begin="${7:-8000}"
dump_end="${8:-8500}"
max_cycles="${9:-9000}"
prefix="fastrep_l${loads}_b${bubbles}_d${delay}_bd${branch_dep}_ld${load_base_dep}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DFALLTHROUGH_DELAY="${delay}" \
  -DBRANCH_DEP_DELAY="${branch_dep}" \
  -DLOAD_BASE_DEP_DELAY="${load_base_dep}" \
  -DLOAD_REPS="${loads}" \
  -DBUBBLE_REPS="${bubbles}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_fastreplay_bubble.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

secret_base="$(awk '$3 == "secret_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${secret_base}"
