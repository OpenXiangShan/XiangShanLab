#!/usr/bin/env bash
set -euo pipefail

usage="usage: run_fastreplay_target_probe_once.sh DIV_REPS LOAD_REPS BUBBLE_REPS [SECRET_VALUE] [START_OFFSET] [TARGET_OFFSET] [TARGET_GAP_REPS] [TARGET_PROBE_REPS] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]"

div_reps="${1:?${usage}}"
loads="${2:?${usage}}"
bubbles="${3:?${usage}}"
secret="${4:-64}"
start_offset="${5:-0}"
target_offset="${6:-1344}"
target_gap="${7:-0}"
target_reps="${8:-1}"
dump_begin="${9:-8240}"
dump_end="${10:-8600}"
max_cycles="${11:-9000}"
prefix="fasttarget_dr${div_reps}_l${loads}_b${bubbles}_off${start_offset}_toff${target_offset}_tg${target_gap}_tr${target_reps}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DSTART_OFFSET="${start_offset}" \
  -DTARGET_OFFSET="${target_offset}" \
  -DDIV_REPS="${div_reps}" \
  -DLOAD_REPS="${loads}" \
  -DBUBBLE_REPS="${bubbles}" \
  -DTARGET_GAP_REPS="${target_gap}" \
  -DTARGET_PROBE_REPS="${target_reps}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_fastreplay_target_probe.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

secret_base="$(awk '$3 == "secret_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${secret_base}"
