#!/usr/bin/env python3
import argparse
import json


def main():
    ap = argparse.ArgumentParser(
        description="Recover the killed-load secret value from monitor JSON."
    )
    ap.add_argument("monitor_json")
    ap.add_argument("--expect", type=lambda x: int(x, 0))
    args = ap.parse_args()

    with open(args.monitor_json) as f:
        result = json.load(f)

    candidates = result.get("recovered_secret_candidates", [])
    if not candidates:
        raise SystemExit("no killed RF writeback secret candidate found")

    # Prefer the first candidate: the current PoC is constructed to produce one
    # decisive killed scalar-load RF writeback event.
    candidate = candidates[0]
    recovered = candidate["backend_rf_data"]
    verdict = {
        "monitor_json": args.monitor_json,
        "recovered_secret": recovered,
        "recovered_secret_hex": hex(recovered),
        "event": candidate,
        "matches_expected": None if args.expect is None else recovered == args.expect,
    }
    print(json.dumps(verdict, indent=2, sort_keys=True))
    if args.expect is not None and recovered != args.expect:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
