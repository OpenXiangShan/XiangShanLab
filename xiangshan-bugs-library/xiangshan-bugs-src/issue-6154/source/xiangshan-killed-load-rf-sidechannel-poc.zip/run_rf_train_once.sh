#!/usr/bin/env bash
set -euo pipefail

usage="usage: run_rf_train_once.sh LABEL SECRET_VALUE [FALLTHROUGH_DELAY] [TRAIN_REPS] [DUMP_BEGIN] [DUMP_END] [MAX_CYCLES]"

label="${1:?${usage}}"
secret="${2:?${usage}}"
delay="${3:-6}"
train_reps="${4:-160}"
dump_begin="${5:-8000}"
dump_end="${6:-8500}"
max_cycles="${7:-9000}"
prefix="train_${label}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DFALLTHROUGH_DELAY="${delay}" \
  -DTRAIN_REPS="${train_reps}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_writeback_train.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

secret_base="$(awk '$3 == "secret_area" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles="${max_cycles}" \
  -b "${dump_begin}" -e "${dump_end}" \
  --dump-wave \
  --wave-path="${prefix}_${dump_begin}_${dump_end}.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_${dump_begin}_${dump_end}.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_${dump_begin}_${dump_end}.vcd" \
  "${prefix}_${dump_begin}_${dump_end}.monitor.json" \
  --secret-offset "${secret}" \
  --expected-rf-data "${secret}" \
  --probe-base "${secret_base}"
