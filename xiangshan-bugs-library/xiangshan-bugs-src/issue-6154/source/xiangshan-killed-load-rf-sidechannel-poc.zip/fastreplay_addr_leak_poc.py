#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


OFF_RE = re.compile(r"_off([0-9a-fA-Fx]+)_")


def parse_start_offset(path):
    match = OFF_RE.search(Path(path).name)
    if not match:
        return None
    return int(match.group(1), 0)


def req_fired(req):
    if req.get("fire") is not None:
        return req.get("fire") is True
    return req.get("valid") == "1" and req.get("ready") == "1"


def source_valid(req, source):
    return req.get("sources", {}).get(source, {}).get("valid") == "1"


def summarize_req(req):
    return {
        "time": req.get("time"),
        "load_unit": req.get("load_unit"),
        "lqIdx": req.get("lqIdx"),
        "offset": req.get("offset"),
        "fire": req.get("fire"),
        "ready": req.get("ready"),
        "source_valid": {
            "fastReplay": source_valid(req, "fastReplay"),
            "replay": source_valid(req, "replay"),
            "scalar": source_valid(req, "scalar"),
            "prefetch": source_valid(req, "prefetch"),
        },
    }


def pre_redirect_same_line_reqs(data, observation):
    redirect_time = observation["time"] - observation["cycles_after_redirect"]
    line = observation["offset"] // 64
    matches = []
    fields_available = False
    for req in data.get("probe_range_dcache_reqs", []):
        req_offset = req.get("offset")
        req_time = req.get("time")
        if req_offset is None or req_time is None:
            continue
        if "fire" in req or ("valid" in req and "ready" in req):
            fields_available = True
        if req_offset // 64 != line:
            continue
        if req_time >= redirect_time:
            continue
        if req_fired(req):
            matches.append(summarize_req(req))
    return fields_available, matches


def load_observation(path):
    with open(path) as f:
        data = json.load(f)

    events = data.get("fired_killed_fast_replays", [])
    if not events:
        raise ValueError(f"{path}: no fired killed fastReplay event")

    probe_base = data.get("probe_base")
    if probe_base is None:
        raise ValueError(f"{path}: no probe_base in monitor JSON")

    start_offset = parse_start_offset(path)
    observations = []
    for event in events:
        snapshot = event.get("load_unit_snapshot", {})
        dcache = snapshot.get("dcache", {})
        load_pipe = dcache.get("load_pipe", {})
        req = load_pipe.get("req", {})
        tag_read = load_pipe.get("tag_read", {})
        vaddr = event.get("vaddr")
        redirect = event.get("redirect_robIdx", {})
        replay = event.get("replay_robIdx", {})
        if vaddr is None:
            raise ValueError(f"{path}: fired replay has no vaddr")
        observation = {
            "monitor_json": path,
            "start_offset": start_offset,
            "time": event.get("time"),
            "cycles_after_redirect": event.get("cycles_after_redirect"),
            "load_unit": event.get("load_unit"),
            "redirect_robIdx": redirect,
            "replay_robIdx": replay,
            "vaddr": vaddr,
            "offset": vaddr - probe_base,
            "ready": event.get("ready"),
            "fire": event.get("fire"),
            "tag_write_intend": dcache.get("tag_write_intend"),
            "main_tag_write_valid": dcache.get("main_tag_write_valid"),
            "dcache_req_ready": req.get("ready"),
            "dcache_req_valid": req.get("valid"),
            "dcache_tag_read_ready": tag_read.get("ready"),
            "dcache_tag_read_valid": tag_read.get("valid"),
        }
        fields_available, pre_reqs = pre_redirect_same_line_reqs(
            data,
            observation,
        )
        observation["pre_redirect_request_fields_available"] = fields_available
        observation["pre_redirect_accepted_same_line_count"] = len(pre_reqs)
        observation["pre_redirect_accepted_same_line_requests"] = pre_reqs
        observation["pre_redirect_scalar_same_line_count"] = sum(
            1 for req in pre_reqs if req["source_valid"]["scalar"]
        )
        observations.append(observation)
    return observations


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Exploit-style checker for redirect-killed fastReplay address "
            "leakage. It expects monitor JSONs produced from runs that differ "
            "only in START_OFFSET."
        )
    )
    ap.add_argument("monitor_json", nargs="+")
    args = ap.parse_args()

    observations = []
    for path in args.monitor_json:
        observations.extend(load_observation(path))

    starts = sorted({obs["start_offset"] for obs in observations})
    offsets = sorted({obs["offset"] for obs in observations})
    lines = sorted({obs["offset"] // 64 for obs in observations})

    post_redirect_fired = (
        len(starts) >= 2
        and len(offsets) >= 2
        and all(obs["cycles_after_redirect"] is not None for obs in observations)
        and all(obs["cycles_after_redirect"] >= 0 for obs in observations)
        and all(obs["fire"] is True for obs in observations)
        and all(obs["ready"] == "1" for obs in observations)
        and all(obs["dcache_req_valid"] == "1" for obs in observations)
        and all(obs["dcache_req_ready"] == "1" for obs in observations)
        and all(obs["dcache_tag_read_ready"] == "1" for obs in observations)
        and all(obs["tag_write_intend"] == "0" for obs in observations)
    )
    any_pre_redirect_same_line = any(
        obs["pre_redirect_accepted_same_line_count"] > 0
        for obs in observations
    )
    all_pre_redirect_fields_available = all(
        obs["pre_redirect_request_fields_available"]
        for obs in observations
    )

    summary = {
        "post_redirect_fired_fastreplay_addr_leak_observed": post_redirect_fired,
        "isolated_new_cache_footprint_observed": (
            post_redirect_fired
            and all_pre_redirect_fields_available
            and not any_pre_redirect_same_line
        ),
        "software_timing_leak_proven": False,
        "pre_redirect_accepted_same_line_observed": any_pre_redirect_same_line,
        "pre_redirect_request_fields_available": all_pre_redirect_fields_available,
        "distinct_start_offsets": starts,
        "distinct_fired_request_offsets": offsets,
        "distinct_fired_request_cache_lines": lines,
        "observations": observations,
    }

    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["post_redirect_fired_fastreplay_addr_leak_observed"]:
        raise SystemExit("post-redirect fired fastReplay address leakage not proven")


if __name__ == "__main__":
    main()
