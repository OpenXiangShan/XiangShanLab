#!/usr/bin/env bash
set -euo pipefail

gap="${1:?usage: run_gap_probe_once.sh GAP [SECRET_VALUE]}"
secret="${2:-64}"
prefix="gap${gap}_secret${secret}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_VALUE="${secret}" \
  -DFALLTHROUGH_DELAY=6 \
  -DGAP_REPS="${gap}" \
  -DTAIL_REPS=156 \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_probe_gap.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

probe_base="$(awk '$3 == "probe_base" { print "0x" $1 }' "${prefix}.symbols")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles=9000 \
  -b 8000 -e 8500 \
  --dump-wave \
  --wave-path="${prefix}_8000_8500.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_8000_8500.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_8000_8500.vcd" \
  "${prefix}_8000_8500.monitor.json" \
  --secret-offset "${secret}" \
  --probe-base "${probe_base}"
