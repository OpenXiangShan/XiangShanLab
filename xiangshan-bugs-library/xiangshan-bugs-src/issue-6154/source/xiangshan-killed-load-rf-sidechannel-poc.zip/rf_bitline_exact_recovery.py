#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def parse_expectation(value):
    if "=" not in value:
        raise argparse.ArgumentTypeError("expectation must be JSON=VALUE")
    path, expected = value.split("=", 1)
    if not path or not expected:
        raise argparse.ArgumentTypeError("expectation must be JSON=VALUE")
    return path, int(expected, 0)


def load_event(path):
    with open(path) as f:
        data = json.load(f)

    candidates = [
        event for event in data.get("recovered_secret_candidates", [])
        if event.get("toIntRf_valid") == "1"
        and event.get("backend_rf_wen") == "1"
        and event.get("backend_rf_data") is not None
    ]
    if not candidates:
        raise ValueError(f"{path}: no redirect-killed RF write candidate")

    event = candidates[0]
    value = event["backend_rf_data"] & ((1 << 64) - 1)
    return {
        "monitor_json": path,
        "time": event.get("time"),
        "load_unit": event.get("load_unit"),
        "cycles_after_redirect": event.get("cycles_after_redirect"),
        "redirect_robIdx": event.get("redirect_robIdx"),
        "writeback_robIdx": event.get("writeback_robIdx"),
        "backend_rf_pdest": event.get("backend_rf_pdest"),
        "toIntRf_valid": event.get("toIntRf_valid"),
        "backend_rf_wen": event.get("backend_rf_wen"),
        "backend_rf_data": value,
        "backend_rf_data_hex": f"0x{value:016x}",
        "expected_rf_data": data.get("expected_rf_data"),
        "lsq_ldin_valid": (event.get("lsq_ldin") or {}).get("valid"),
        "busytable_wb_valid": (event.get("dispatch_busytable_wb") or {}).get("valid"),
    }


def bit_vector(value):
    return [(value >> bit) & 1 for bit in range(64)]


def value_from_bits(bits):
    value = 0
    for bit, observed in enumerate(bits):
        if observed:
            value |= 1 << bit
    return value


def same_context(events):
    fields = (
        "time",
        "load_unit",
        "redirect_robIdx",
        "writeback_robIdx",
        "backend_rf_pdest",
    )
    return all(
        len({json.dumps(event.get(field), sort_keys=True) for event in events}) == 1
        for field in fields
    )


def classify_attack(event, expected):
    observed_bits = bit_vector(event["backend_rf_data"])
    recovered = value_from_bits(observed_bits)
    return {
        "attack_json": event["monitor_json"],
        "recovered_value": recovered,
        "recovered_value_hex": f"0x{recovered:016x}",
        "expected_value": expected,
        "expected_value_hex": f"0x{expected:016x}",
        "matches_expected_value": recovered == expected,
        "set_bit_count": sum(observed_bits),
        "observed_set_bits": [bit for bit, value in enumerate(observed_bits) if value],
    }


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Exact-value exploit model for redirect-killed RF writes under a "
            "spatial bitline power/EM observer. A zero trace calibrates the "
            "quiet level; held-out attack traces are recovered from the 64 "
            "RF write data bitlines."
        )
    )
    ap.add_argument(
        "--zero-template",
        required=True,
        help="monitor JSON whose killed RF write value is zero",
    )
    ap.add_argument(
        "--expect",
        action="append",
        type=parse_expectation,
        default=[],
        help="Expected exact value as monitor.json=0xVALUE",
    )
    ap.add_argument("attack_json", nargs="+")
    args = ap.parse_args()

    zero = load_event(args.zero_template)
    attacks = [load_event(path) for path in args.attack_json]
    expectations = dict(args.expect)
    all_events = [zero] + attacks

    zero_ok = zero["backend_rf_data"] == 0
    context_ok = same_context(all_events)
    all_killed = all(
        event["cycles_after_redirect"] is not None
        and event["cycles_after_redirect"] >= 0
        for event in all_events
    )
    all_drive_rf = all(
        event["toIntRf_valid"] == "1" and event["backend_rf_wen"] == "1"
        for event in all_events
    )
    template_paths = {args.zero_template}

    classifications = []
    for event in attacks:
        expected = expectations.get(event["monitor_json"])
        if expected is None:
            expected = event["expected_rf_data"]
        if expected is None:
            raise ValueError(f"{event['monitor_json']}: no expected value")
        item = classify_attack(event, expected & ((1 << 64) - 1))
        item["is_held_out_from_templates"] = event["monitor_json"] not in template_paths
        classifications.append(item)

    exact_match = all(item["matches_expected_value"] for item in classifications)
    held_out = all(item["is_held_out_from_templates"] for item in classifications)
    summary = {
        "rf_bitline_exact_recovery_success": (
            zero_ok
            and context_ok
            and all_killed
            and all_drive_rf
            and held_out
            and exact_match
            and bool(classifications)
        ),
        "leakage_model": "spatial RF write data bitline power/EM leakage",
        "zero_template_valid": zero_ok,
        "same_microarchitectural_context": context_ok,
        "all_events_are_redirect_killed": all_killed,
        "all_events_drive_rf_write": all_drive_rf,
        "held_out_attack_traces": held_out,
        "exact_values_match": exact_match,
        "zero_template": {
            "monitor_json": zero["monitor_json"],
            "value_hex": zero["backend_rf_data_hex"],
        },
        "classifications": classifications,
        "software_timing_leak_proven": False,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["rf_bitline_exact_recovery_success"]:
        raise SystemExit("RF bitline exact recovery not proven")


if __name__ == "__main__":
    main()
