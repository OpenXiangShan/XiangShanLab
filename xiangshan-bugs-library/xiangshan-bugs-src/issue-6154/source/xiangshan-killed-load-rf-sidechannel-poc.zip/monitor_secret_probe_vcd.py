#!/usr/bin/env python3
import argparse
import json
import re


BASE = "TOP.SimTop.cpu.l_soc.core_with_l2.core"
MEM = f"{BASE}.memBlock"
BACKEND = f"{BASE}.backend.inner_intRegion"
CTRLBLOCK = f"{BASE}.backend.inner_ctrlBlock"
LSQ = f"{MEM}.inner_lsq"
VLQ = f"{LSQ}.loadQueue.virtualLoadQueue"
DCACHE = f"{MEM}.inner_dcache.dcache"
TRACKED_VLQ_ENTRIES = 8
TRACKED_DISPATCH_INT_UOPS = 22
TRACKED_LSQ_ENQ_REQS = 8


def bits_to_int(bits):
    if not bits or any(ch not in "01" for ch in bits):
        return None
    return int(bits, 2)


def rob_after(write_flag, write_value, redirect_flag, redirect_value):
    if None in (write_flag, write_value, redirect_flag, redirect_value):
        return False
    if write_flag != redirect_flag:
        return write_value < redirect_value
    return write_value > redirect_value


def signal_set():
    signals = {}
    for i in range(3):
        ldu = f"{MEM}.inner_LoadUnit_{i}"
        s0 = f"{ldu}.s0"
        s1 = f"{ldu}.s1"
        s2 = f"{ldu}.s2"
        s3 = f"{MEM}.inner_LoadUnit_{i}.s3"
        signals[f"ld{i}_redirect_valid"] = f"{s3}.io_redirect_valid"
        signals[f"ld{i}_redirect_flag"] = f"{s3}.io_redirect_bits_robIdx_flag"
        signals[f"ld{i}_redirect_value"] = f"{s3}.io_redirect_bits_robIdx_value"
        signals[f"ld{i}_toRob_valid"] = f"{s3}.io_ldout_toRob_valid"
        signals[f"ld{i}_rob_flag"] = f"{s3}.io_ldout_toRob_bits_robIdx_flag"
        signals[f"ld{i}_rob_value"] = f"{s3}.io_ldout_toRob_bits_robIdx_value"
        signals[f"ld{i}_wb_rename_time"] = (
            f"{s3}.io_ldout_toRob_bits_debugInfo_perfDebugInfo_renameTime"
        )
        signals[f"ld{i}_wb_dispatch_time"] = (
            f"{s3}.io_ldout_toRob_bits_debugInfo_perfDebugInfo_dispatchTime"
        )
        signals[f"ld{i}_wb_issue_time"] = (
            f"{s3}.io_ldout_toRob_bits_debugInfo_perfDebugInfo_issueTime"
        )
        signals[f"ld{i}_wb_vaddr"] = (
            f"{s3}.io_ldout_toRob_bits_debugInfo_vaddr"
        )
        signals[f"ld{i}_wb_paddr"] = (
            f"{s3}.io_ldout_toRob_bits_debugInfo_paddr"
        )
        signals[f"ld{i}_toIntRf_valid"] = f"{s3}.io_ldout_toIntRf_valid"
        signals[f"ld{i}_rf_wen"] = f"{BACKEND}.io_toIntPreg_{6 + i}_wen"
        signals[f"ld{i}_rf_pdest"] = f"{BACKEND}.io_toIntPreg_{6 + i}_pdest"
        signals[f"ld{i}_rf_data"] = (
            f"{BACKEND}.intWBDataPath.io_toIntPreg_{6 + i}_data"
        )
        signals[f"ld{i}_dispatch_wb_valid"] = (
            f"{CTRLBLOCK}.io_toDispatch_wbPregsInt_{6 + i}_valid"
        )
        signals[f"ld{i}_dispatch_wb_pdest"] = (
            f"{CTRLBLOCK}.io_toDispatch_wbPregsInt_{6 + i}_bits"
        )
        signals[f"ld{i}_load_wakeup_valid"] = (
            f"{MEM}.io_mem_to_ooo_wakeup_{i}_valid"
        )
        signals[f"ld{i}_load_wakeup_rfWen"] = (
            f"{MEM}.io_mem_to_ooo_wakeup_{i}_bits_rfWen"
        )
        signals[f"ld{i}_load_wakeup_fpWen"] = (
            f"{MEM}.io_mem_to_ooo_wakeup_{i}_bits_fpWen"
        )
        signals[f"ld{i}_load_wakeup_pdest"] = (
            f"{MEM}.io_mem_to_ooo_wakeup_{i}_bits_pdest"
        )
        signals[f"ld{i}_dcache_valid"] = (
            f"{MEM}.inner_LoadUnit_{i}.io_dcache_req_valid"
        )
        signals[f"ld{i}_dcache_vaddr"] = (
            f"{MEM}.inner_LoadUnit_{i}.io_dcache_req_bits_vaddr"
        )
        signals[f"ld{i}_dcache_lq_value"] = (
            f"{MEM}.inner_LoadUnit_{i}.io_dcache_req_bits_lqIdx_value"
        )
        signals[f"ld{i}_s3_lq_value"] = f"{s3}.io_ldout_toRob_bits_lqIdx_value"
        signals[f"ld{i}_lqWrite_valid"] = f"{s3}.io_lqWrite_valid"
        signals[f"ld{i}_exceptionInfo_valid"] = f"{s3}.io_exceptionInfo_valid"
        signals[f"ld{i}_fastReplay_valid"] = f"{s3}.io_fastReplay_valid"
        signals[f"ld{i}_fastReplay_ready"] = f"{s3}.io_fastReplay_ready"
        signals[f"ld{i}_fastReplay_rob_flag"] = (
            f"{s3}.io_fastReplay_bits_uop_robIdx_flag"
        )
        signals[f"ld{i}_fastReplay_rob_value"] = (
            f"{s3}.io_fastReplay_bits_uop_robIdx_value"
        )
        signals[f"ld{i}_fastReplay_lq_value"] = (
            f"{s3}.io_fastReplay_bits_uop_lqIdx_value"
        )
        signals[f"ld{i}_fastReplay_pdest"] = (
            f"{s3}.io_fastReplay_bits_uop_pdest"
        )
        signals[f"ld{i}_fastReplay_vaddr"] = f"{s3}.io_fastReplay_bits_vaddr"
        signals[f"ld{i}_fastReplay_paddr"] = f"{s3}.io_fastReplay_bits_paddr"
        signals[f"ld{i}_s0_fastReplay_valid"] = f"{s0}.io_fastReplay_valid"
        signals[f"ld{i}_s0_fastReplay_ready"] = f"{s0}.io_fastReplay_ready"
        signals[f"ld{i}_s0_dcache_ready"] = f"{s0}.io_dcacheReq_ready"
        signals[f"ld{i}_s0_pipeIn_valid"] = f"{s0}.pipeIn_valid"
        signals[f"ld{i}_s0_pipeOut_valid"] = f"{s0}.io_pipeOut_valid"
        signals[f"ld{i}_s1_pipeIn_valid"] = f"{s1}.io_pipeIn_valid"
        signals[f"ld{i}_s1_pipeOut_valid"] = f"{s1}.io_pipeOut_valid"
        signals[f"ld{i}_s2_pipeIn_valid"] = f"{s2}.io_pipeIn_valid"
        signals[f"ld{i}_s2_pipeOut_valid"] = f"{s2}.io_pipeOut_valid"
        signals[f"ld{i}_s3_pipeIn_valid"] = f"{s3}.io_pipeIn_valid"
        signals[f"ld{i}_s3_pipeOut_valid"] = f"{s3}.io_pipeOut_valid"
        signals[f"ld{i}_src_unalign_valid"] = f"{ldu}.io_unalignTail_valid"
        signals[f"ld{i}_src_unalign_ready"] = f"{ldu}.io_unalignTail_ready"
        signals[f"ld{i}_src_replay_valid"] = f"{ldu}.io_replay_valid"
        signals[f"ld{i}_src_replay_ready"] = f"{ldu}.io_replay_ready"
        signals[f"ld{i}_src_prefetch_valid"] = f"{ldu}.io_prefetchReq_valid"
        signals[f"ld{i}_src_prefetch_ready"] = f"{ldu}.io_prefetchReq_ready"
        signals[f"ld{i}_src_vector_valid"] = f"{ldu}.io_vecldin_valid"
        signals[f"ld{i}_src_vector_ready"] = f"{ldu}.io_vecldin_ready"
        signals[f"ld{i}_src_scalar_valid"] = f"{ldu}.io_ldin_valid"
        signals[f"ld{i}_src_scalar_ready"] = f"{ldu}.io_ldin_ready"
        signals[f"dcache_ld{i}_req_ready"] = (
            f"{DCACHE}.ldu_{i}.io_lsu_req_ready"
        )
        signals[f"dcache_ld{i}_req_valid"] = (
            f"{DCACHE}.ldu_{i}.io_lsu_req_valid"
        )
        signals[f"dcache_ld{i}_tag_read_ready"] = (
            f"{DCACHE}.ldu_{i}.io_tag_read_ready"
        )
        signals[f"dcache_ld{i}_tag_read_valid"] = (
            f"{DCACHE}.ldu_{i}.io_tag_read_valid"
        )
        signals[f"dcache_ld{i}_s1_valid"] = f"{DCACHE}.ldu_{i}.s1_valid"
        signals[f"lsq_ldin{i}_valid"] = f"{LSQ}.io_ldu_ldin_{i}_valid"
        signals[f"lsq_ldin{i}_rob_flag"] = (
            f"{LSQ}.io_ldu_ldin_{i}_bits_uop_robIdx_flag"
        )
        signals[f"lsq_ldin{i}_rob_value"] = (
            f"{LSQ}.io_ldu_ldin_{i}_bits_uop_robIdx_value"
        )
        signals[f"lsq_ldin{i}_lq_flag"] = (
            f"{LSQ}.io_ldu_ldin_{i}_bits_uop_lqIdx_flag"
        )
        signals[f"lsq_ldin{i}_lq_value"] = (
            f"{LSQ}.io_ldu_ldin_{i}_bits_uop_lqIdx_value"
        )
        signals[f"lsq_ldin{i}_vaddr"] = f"{LSQ}.io_ldu_ldin_{i}_bits_vaddr"
        signals[f"lsq_ldin{i}_paddr"] = f"{LSQ}.io_ldu_ldin_{i}_bits_paddr"
        signals[f"lsq_ldin{i}_updateAddrValid"] = (
            f"{LSQ}.io_ldu_ldin_{i}_bits_updateAddrValid"
        )

    signals["dcache_tag_write_intend"] = (
        f"{DCACHE}.mainPipe.io_tag_write_intend"
    )
    signals["dcache_main_tag_read_ready"] = (
        f"{DCACHE}.mainPipe.io_tag_read_ready"
    )
    signals["dcache_main_tag_read_valid"] = (
        f"{DCACHE}.mainPipe.io_tag_read_valid"
    )
    signals["dcache_main_tag_write_valid"] = (
        f"{DCACHE}.mainPipe.io_tag_write_valid"
    )

    for i in range(7):
        signals[f"memIssue{i}_valid"] = f"{BASE}.backend.io_mem_intIssue_{i}_0_valid"
        signals[f"memIssue{i}_fuOpType"] = (
            f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_fuOpType"
        )
        signals[f"memIssue{i}_src0"] = f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_src_0"
        signals[f"memIssue{i}_rob_flag"] = (
            f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_robIdx_flag"
        )
        signals[f"memIssue{i}_rob_value"] = (
            f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_robIdx_value"
        )
        if i < 5:
            signals[f"memIssue{i}_pdest"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_pdest"
            )
            signals[f"memIssue{i}_rename_time"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_perfDebugInfo_renameTime"
            )
            signals[f"memIssue{i}_dispatch_time"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_perfDebugInfo_dispatchTime"
            )
            signals[f"memIssue{i}_issue_time"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_perfDebugInfo_issueTime"
            )
        if i < 3:
            signals[f"memIssue{i}_pc"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_pc"
            )
            signals[f"memIssue{i}_lq_flag"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_lqIdx_flag"
            )
            signals[f"memIssue{i}_lq_value"] = (
                f"{BASE}.backend.io_mem_intIssue_{i}_0_bits_lqIdx_value"
            )

    for i in range(TRACKED_LSQ_ENQ_REQS):
        prefix = f"{BASE}.backend.io_mem_lsqEnqIO_req_{i}"
        signals[f"lsqEnq{i}_valid"] = f"{prefix}_valid"
        signals[f"lsqEnq{i}_pc"] = f"{prefix}_bits_pc"
        signals[f"lsqEnq{i}_fuOpType"] = f"{prefix}_bits_fuOpType"
        for src in range(4):
            signals[f"lsqEnq{i}_psrc{src}"] = f"{prefix}_bits_psrc_{src}"
            signals[f"lsqEnq{i}_srcType{src}"] = f"{prefix}_bits_srcType_{src}"
        signals[f"lsqEnq{i}_pdest"] = f"{prefix}_bits_pdest"
        signals[f"lsqEnq{i}_rob_flag"] = f"{prefix}_bits_robIdx_flag"
        signals[f"lsqEnq{i}_rob_value"] = f"{prefix}_bits_robIdx_value"
        signals[f"lsqEnq{i}_lq_flag"] = f"{prefix}_bits_lqIdx_flag"
        signals[f"lsqEnq{i}_lq_value"] = f"{prefix}_bits_lqIdx_value"
        signals[f"lsqEnq{i}_rename_time"] = (
            f"{prefix}_bits_perfDebugInfo_renameTime"
        )

    for i in range(TRACKED_VLQ_ENTRIES):
        signals[f"vlq{i}_allocated"] = f"{VLQ}.allocated_{i}"
        signals[f"vlq{i}_committed"] = f"{VLQ}.committed_{i}"
        signals[f"vlq{i}_rob_flag"] = f"{VLQ}.robIdx_{i}_flag"
        signals[f"vlq{i}_rob_value"] = f"{VLQ}.robIdx_{i}_value"

    for i in range(TRACKED_DISPATCH_INT_UOPS):
        prefix = f"{CTRLBLOCK}.io_toIssueBlock_intUops_{i}"
        signals[f"dispatch_int_uop{i}_valid"] = f"{prefix}_valid"
        signals[f"dispatch_int_uop{i}_rfWen"] = f"{prefix}_bits_rfWen"
        signals[f"dispatch_int_uop{i}_psrc0"] = f"{prefix}_bits_psrc_0"
        signals[f"dispatch_int_uop{i}_psrc1"] = f"{prefix}_bits_psrc_1"
        signals[f"dispatch_int_uop{i}_pdest"] = f"{prefix}_bits_pdest"
        signals[f"dispatch_int_uop{i}_rob_flag"] = f"{prefix}_bits_robIdx_flag"
        signals[f"dispatch_int_uop{i}_rob_value"] = f"{prefix}_bits_robIdx_value"
        signals[f"dispatch_int_uop{i}_srcState0"] = f"{prefix}_bits_srcState_0"
        signals[f"dispatch_int_uop{i}_srcState1"] = f"{prefix}_bits_srcState_1"

    return signals


def parse_header(path, signals):
    stack = []
    ids = {}
    expected = {v: k for k, v in signals.items()}
    # VCD names are emitted both under full paths and as aliased shorter paths.
    suffixes = {tuple(path.split(".")[-4:]): key for path, key in expected.items()}
    with open(path, "r", errors="replace") as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("$enddefinitions"):
                break
            if stripped.startswith("$scope"):
                stack.append(stripped.split()[2])
            elif stripped.startswith("$upscope"):
                stack.pop()
            elif stripped.startswith("$var"):
                parts = stripped.split()
                ident = parts[3]
                name = parts[4]
                full_path = ".".join(stack + [name])
                logical = expected.get(full_path)
                if logical is None:
                    logical = suffixes.get(tuple((stack + [name])[-4:]))
                if logical is not None:
                    ids.setdefault(ident, []).append(logical)
    found = {logical for logicals in ids.values() for logical in logicals}
    missing = sorted(set(signals) - found)
    return ids, missing


def parse_vcd(path, secret_offset, probe_base, expected_rf_data=None):
    signals = signal_set()
    ids, missing = parse_header(path, signals)
    values = {name: "0" for name in signals}
    time = 0
    killed_writebacks = []
    all_load_writebacks = []
    post_redirect_killed_writebacks = []
    killed_fast_replays = []
    post_redirect_fast_replays = []
    all_fast_replays = []
    redirect_events = []
    mem_issues = []
    probe_dcache_reqs = []
    probe_range_dcache_reqs = []
    probe_range_mem_issues = []
    lsq_enq_reqs = []
    vlq_change_trace = []
    dispatch_uops = []
    last_vlq = {}
    last_redirect = [None for _ in range(3)]

    if expected_rf_data is None:
        expected_rf_data = secret_offset

    secret_probe_addr = probe_base + secret_offset
    probe_limit = probe_base + 8192

    def load_unit_snapshot(i):
        return {
            "s0_fastReplay": {
                "valid": values[f"ld{i}_s0_fastReplay_valid"],
                "ready": values[f"ld{i}_s0_fastReplay_ready"],
            },
            "s0_dcache_ready": values[f"ld{i}_s0_dcache_ready"],
            "dcache": {
                "tag_write_intend": values["dcache_tag_write_intend"],
                "main_tag_read": {
                    "ready": values["dcache_main_tag_read_ready"],
                    "valid": values["dcache_main_tag_read_valid"],
                },
                "main_tag_write_valid": values["dcache_main_tag_write_valid"],
                "load_pipe": {
                    "req": {
                        "ready": values[f"dcache_ld{i}_req_ready"],
                        "valid": values[f"dcache_ld{i}_req_valid"],
                    },
                    "tag_read": {
                        "ready": values[f"dcache_ld{i}_tag_read_ready"],
                        "valid": values[f"dcache_ld{i}_tag_read_valid"],
                    },
                    "s1_valid": values[f"dcache_ld{i}_s1_valid"],
                },
            },
            "pipe_valid": {
                "s0_pipeIn": values[f"ld{i}_s0_pipeIn_valid"],
                "s0_pipeOut": values[f"ld{i}_s0_pipeOut_valid"],
                "s1_pipeIn": values[f"ld{i}_s1_pipeIn_valid"],
                "s1_pipeOut": values[f"ld{i}_s1_pipeOut_valid"],
                "s2_pipeIn": values[f"ld{i}_s2_pipeIn_valid"],
                "s2_pipeOut": values[f"ld{i}_s2_pipeOut_valid"],
                "s3_pipeIn": values[f"ld{i}_s3_pipeIn_valid"],
                "s3_pipeOut": values[f"ld{i}_s3_pipeOut_valid"],
            },
            "sources": {
                "unalign": {
                    "valid": values[f"ld{i}_src_unalign_valid"],
                    "ready": values[f"ld{i}_src_unalign_ready"],
                },
                "replay": {
                    "valid": values[f"ld{i}_src_replay_valid"],
                    "ready": values[f"ld{i}_src_replay_ready"],
                },
                "prefetch": {
                    "valid": values[f"ld{i}_src_prefetch_valid"],
                    "ready": values[f"ld{i}_src_prefetch_ready"],
                },
                "vector": {
                    "valid": values[f"ld{i}_src_vector_valid"],
                    "ready": values[f"ld{i}_src_vector_ready"],
                },
                "scalar": {
                    "valid": values[f"ld{i}_src_scalar_valid"],
                    "ready": values[f"ld{i}_src_scalar_ready"],
                },
            },
        }

    def vlq_snapshot(lq_idx):
        if lq_idx is None or lq_idx < 0 or lq_idx >= TRACKED_VLQ_ENTRIES:
            return None
        return {
            "entry": lq_idx,
            "allocated": values[f"vlq{lq_idx}_allocated"],
            "committed": values[f"vlq{lq_idx}_committed"],
            "robIdx": {
                "flag": bits_to_int(values[f"vlq{lq_idx}_rob_flag"]),
                "value": bits_to_int(values[f"vlq{lq_idx}_rob_value"]),
            },
        }

    def evaluate(snapshot_time):
        nonlocal last_vlq
        for i in range(3):
            current_redirect = None
            if values[f"ld{i}_redirect_valid"] == "1":
                current_redirect = {
                    "flag": bits_to_int(values[f"ld{i}_redirect_flag"]),
                    "value": bits_to_int(values[f"ld{i}_redirect_value"]),
                    "time": snapshot_time,
                }
                redirect_events.append({
                    "time": snapshot_time,
                    "load_unit": i,
                    "robIdx": {
                        "flag": current_redirect["flag"],
                        "value": current_redirect["value"],
                    },
                })
            active_redirect = current_redirect or last_redirect[i]

            if active_redirect is not None and values[f"ld{i}_toRob_valid"] == "1":
                redirect_flag = active_redirect["flag"]
                redirect_value = active_redirect["value"]
                write_flag = bits_to_int(values[f"ld{i}_rob_flag"])
                write_value = bits_to_int(values[f"ld{i}_rob_value"])
                rename_time = bits_to_int(values[f"ld{i}_wb_rename_time"])
                was_in_flight_at_redirect = (
                    rename_time is not None
                    and rename_time <= active_redirect["time"]
                )
                if (
                    rob_after(write_flag, write_value, redirect_flag, redirect_value)
                    and was_in_flight_at_redirect
                ):
                    lq_idx = bits_to_int(values[f"ld{i}_s3_lq_value"])
                    event = {
                        "time": snapshot_time,
                        "load_unit": i,
                        "cycles_after_redirect": (
                            snapshot_time - active_redirect["time"]
                        ),
                        "redirect_robIdx": {"flag": redirect_flag, "value": redirect_value},
                        "writeback_robIdx": {"flag": write_flag, "value": write_value},
                        "perf_time": {
                            "rename": rename_time,
                            "dispatch": bits_to_int(
                                values[f"ld{i}_wb_dispatch_time"]
                            ),
                            "issue": bits_to_int(values[f"ld{i}_wb_issue_time"]),
                        },
                        "lqIdx": lq_idx,
                        "toIntRf_valid": values[f"ld{i}_toIntRf_valid"],
                        "backend_rf_wen": values[f"ld{i}_rf_wen"],
                        "backend_rf_pdest": bits_to_int(values[f"ld{i}_rf_pdest"]),
                        "backend_rf_data": bits_to_int(values[f"ld{i}_rf_data"]),
                        "dispatch_busytable_wb": {
                            "valid": values[f"ld{i}_dispatch_wb_valid"],
                            "pdest": bits_to_int(values[f"ld{i}_dispatch_wb_pdest"]),
                        },
                        "load_early_wakeup": {
                            "valid": values[f"ld{i}_load_wakeup_valid"],
                            "rfWen": values[f"ld{i}_load_wakeup_rfWen"],
                            "fpWen": values[f"ld{i}_load_wakeup_fpWen"],
                            "pdest": bits_to_int(values[f"ld{i}_load_wakeup_pdest"]),
                        },
                        "lqWrite_valid": values[f"ld{i}_lqWrite_valid"],
                        "exceptionInfo_valid": values[f"ld{i}_exceptionInfo_valid"],
                        "lsq_ldin": {
                            "valid": values[f"lsq_ldin{i}_valid"],
                            "robIdx": {
                                "flag": bits_to_int(values[f"lsq_ldin{i}_rob_flag"]),
                                "value": bits_to_int(values[f"lsq_ldin{i}_rob_value"]),
                            },
                            "lqIdx": {
                                "flag": bits_to_int(values[f"lsq_ldin{i}_lq_flag"]),
                                "value": bits_to_int(values[f"lsq_ldin{i}_lq_value"]),
                            },
                            "vaddr": bits_to_int(values[f"lsq_ldin{i}_vaddr"]),
                            "paddr": bits_to_int(values[f"lsq_ldin{i}_paddr"]),
                            "updateAddrValid": values[f"lsq_ldin{i}_updateAddrValid"],
                        },
                        "virtual_load_queue_entry": vlq_snapshot(lq_idx),
                    }
                    post_redirect_killed_writebacks.append(event)
                    if current_redirect is not None:
                        killed_writebacks.append(event)

            if values[f"ld{i}_toRob_valid"] == "1":
                all_load_writebacks.append({
                    "time": snapshot_time,
                    "load_unit": i,
                    "robIdx": {
                        "flag": bits_to_int(values[f"ld{i}_rob_flag"]),
                        "value": bits_to_int(values[f"ld{i}_rob_value"]),
                    },
                    "lqIdx": bits_to_int(values[f"ld{i}_s3_lq_value"]),
                    "vaddr": bits_to_int(values[f"ld{i}_wb_vaddr"]),
                    "paddr": bits_to_int(values[f"ld{i}_wb_paddr"]),
                    "toIntRf_valid": values[f"ld{i}_toIntRf_valid"],
                    "backend_rf_wen": values[f"ld{i}_rf_wen"],
                    "backend_rf_pdest": bits_to_int(values[f"ld{i}_rf_pdest"]),
                    "backend_rf_data": bits_to_int(values[f"ld{i}_rf_data"]),
                    "perf_time": {
                        "rename": bits_to_int(values[f"ld{i}_wb_rename_time"]),
                        "dispatch": bits_to_int(
                            values[f"ld{i}_wb_dispatch_time"]
                        ),
                        "issue": bits_to_int(values[f"ld{i}_wb_issue_time"]),
                    },
                    "active_redirect": active_redirect,
                    "current_redirect": current_redirect,
                })

            if values[f"ld{i}_fastReplay_valid"] == "1":
                all_fast_replays.append({
                    "time": snapshot_time,
                    "load_unit": i,
                    "replay_robIdx": {
                        "flag": bits_to_int(values[f"ld{i}_fastReplay_rob_flag"]),
                        "value": bits_to_int(values[f"ld{i}_fastReplay_rob_value"]),
                    },
                    "valid": values[f"ld{i}_fastReplay_valid"],
                    "ready": values[f"ld{i}_fastReplay_ready"],
                    "fire": (
                        values[f"ld{i}_fastReplay_valid"] == "1"
                        and values[f"ld{i}_fastReplay_ready"] == "1"
                    ),
                    "lqIdx": bits_to_int(values[f"ld{i}_fastReplay_lq_value"]),
                    "pdest": bits_to_int(values[f"ld{i}_fastReplay_pdest"]),
                    "vaddr": bits_to_int(values[f"ld{i}_fastReplay_vaddr"]),
                    "paddr": bits_to_int(values[f"ld{i}_fastReplay_paddr"]),
                    "current_redirect": current_redirect,
                    "active_redirect": active_redirect,
                    "load_unit_snapshot": load_unit_snapshot(i),
                })

            if active_redirect is not None and values[f"ld{i}_fastReplay_valid"] == "1":
                redirect_flag = active_redirect["flag"]
                redirect_value = active_redirect["value"]
                replay_flag = bits_to_int(values[f"ld{i}_fastReplay_rob_flag"])
                replay_value = bits_to_int(values[f"ld{i}_fastReplay_rob_value"])
                if rob_after(replay_flag, replay_value, redirect_flag, redirect_value):
                    event = {
                        "time": snapshot_time,
                        "load_unit": i,
                        "cycles_after_redirect": snapshot_time - active_redirect["time"],
                        "redirect_robIdx": {
                            "flag": redirect_flag,
                            "value": redirect_value,
                        },
                        "replay_robIdx": {
                            "flag": replay_flag,
                            "value": replay_value,
                        },
                        "valid": values[f"ld{i}_fastReplay_valid"],
                        "ready": values[f"ld{i}_fastReplay_ready"],
                        "fire": (
                            values[f"ld{i}_fastReplay_valid"] == "1"
                            and values[f"ld{i}_fastReplay_ready"] == "1"
                        ),
                        "lqIdx": bits_to_int(values[f"ld{i}_fastReplay_lq_value"]),
                        "pdest": bits_to_int(values[f"ld{i}_fastReplay_pdest"]),
                        "vaddr": bits_to_int(values[f"ld{i}_fastReplay_vaddr"]),
                        "paddr": bits_to_int(values[f"ld{i}_fastReplay_paddr"]),
                        "load_unit_snapshot": load_unit_snapshot(i),
                    }
                    post_redirect_fast_replays.append(event)
                    if current_redirect is not None:
                        killed_fast_replays.append(event)

            if values[f"ld{i}_dcache_valid"] == "1":
                vaddr = bits_to_int(values[f"ld{i}_dcache_vaddr"])
                dcache_event = {
                    "time": snapshot_time,
                    "load_unit": i,
                    "vaddr": vaddr,
                    "lqIdx": bits_to_int(values[f"ld{i}_dcache_lq_value"]),
                    "valid": values[f"ld{i}_dcache_valid"],
                    "ready": values[f"ld{i}_s0_dcache_ready"],
                    "fire": (
                        values[f"ld{i}_dcache_valid"] == "1"
                        and values[f"ld{i}_s0_dcache_ready"] == "1"
                    ),
                    "dcache": {
                        "tag_write_intend": values["dcache_tag_write_intend"],
                        "main_tag_write_valid": values["dcache_main_tag_write_valid"],
                        "load_pipe_req_ready": values[f"dcache_ld{i}_req_ready"],
                        "load_pipe_req_valid": values[f"dcache_ld{i}_req_valid"],
                        "load_pipe_tag_read_ready": values[
                            f"dcache_ld{i}_tag_read_ready"
                        ],
                        "load_pipe_tag_read_valid": values[
                            f"dcache_ld{i}_tag_read_valid"
                        ],
                    },
                    "sources": {
                        "fastReplay": {
                            "valid": values[f"ld{i}_s0_fastReplay_valid"],
                            "ready": values[f"ld{i}_s0_fastReplay_ready"],
                        },
                        "replay": {
                            "valid": values[f"ld{i}_src_replay_valid"],
                            "ready": values[f"ld{i}_src_replay_ready"],
                        },
                        "scalar": {
                            "valid": values[f"ld{i}_src_scalar_valid"],
                            "ready": values[f"ld{i}_src_scalar_ready"],
                        },
                        "prefetch": {
                            "valid": values[f"ld{i}_src_prefetch_valid"],
                            "ready": values[f"ld{i}_src_prefetch_ready"],
                        },
                    },
                }
                if vaddr is not None and probe_base <= vaddr < probe_limit:
                    event = dict(dcache_event)
                    event["offset"] = vaddr - probe_base
                    probe_range_dcache_reqs.append(event)
                if vaddr == secret_probe_addr:
                    event = dict(dcache_event)
                    event["which"] = "secret_probe"
                    probe_dcache_reqs.append(event)

            if current_redirect is not None:
                last_redirect[i] = current_redirect

        for i in range(7):
            if values[f"memIssue{i}_valid"] == "1":
                src0 = bits_to_int(values[f"memIssue{i}_src0"])
                rob_idx = {
                    "flag": bits_to_int(values[f"memIssue{i}_rob_flag"]),
                    "value": bits_to_int(values[f"memIssue{i}_rob_value"]),
                }
                event = {
                    "time": snapshot_time,
                    "issue_port": i,
                    "fuOpType": bits_to_int(values[f"memIssue{i}_fuOpType"]),
                    "src0": src0,
                    "robIdx": rob_idx,
                }
                if i < 5:
                    event["pdest"] = bits_to_int(values[f"memIssue{i}_pdest"])
                    event["perf_rename_time"] = bits_to_int(
                        values[f"memIssue{i}_rename_time"]
                    )
                    event["perf_dispatch_time"] = bits_to_int(
                        values[f"memIssue{i}_dispatch_time"]
                    )
                    event["perf_issue_time"] = bits_to_int(
                        values[f"memIssue{i}_issue_time"]
                    )
                if i < 3:
                    event["pc"] = bits_to_int(values[f"memIssue{i}_pc"])
                    event["lqIdx"] = {
                        "flag": bits_to_int(values[f"memIssue{i}_lq_flag"]),
                        "value": bits_to_int(values[f"memIssue{i}_lq_value"]),
                    }
                if src0 is not None and probe_base <= src0 < probe_limit:
                    probe_range_mem_issues.append({
                        **event,
                        "offset": src0 - probe_base,
                    })
                if src0 == secret_probe_addr:
                    mem_issues.append({
                        **event,
                        "which": "secret_probe",
                    })

        for i in range(TRACKED_LSQ_ENQ_REQS):
            if values[f"lsqEnq{i}_valid"] == "1":
                lsq_enq_reqs.append({
                    "time": snapshot_time,
                    "slot": i,
                    "pc": bits_to_int(values[f"lsqEnq{i}_pc"]),
                    "fuOpType": bits_to_int(values[f"lsqEnq{i}_fuOpType"]),
                    "psrc": [
                        bits_to_int(values[f"lsqEnq{i}_psrc{src}"])
                        for src in range(4)
                    ],
                    "srcType": [
                        bits_to_int(values[f"lsqEnq{i}_srcType{src}"])
                        for src in range(4)
                    ],
                    "pdest": bits_to_int(values[f"lsqEnq{i}_pdest"]),
                    "robIdx": {
                        "flag": bits_to_int(values[f"lsqEnq{i}_rob_flag"]),
                        "value": bits_to_int(values[f"lsqEnq{i}_rob_value"]),
                    },
                    "lqIdx": {
                        "flag": bits_to_int(values[f"lsqEnq{i}_lq_flag"]),
                        "value": bits_to_int(values[f"lsqEnq{i}_lq_value"]),
                    },
                    "perf_rename_time": bits_to_int(
                        values[f"lsqEnq{i}_rename_time"]
                    ),
                })

        for i in range(TRACKED_DISPATCH_INT_UOPS):
            if values[f"dispatch_int_uop{i}_valid"] == "1":
                dispatch_uops.append({
                    "time": snapshot_time,
                    "slot": i,
                    "rfWen": values[f"dispatch_int_uop{i}_rfWen"],
                    "psrc": [
                        bits_to_int(values[f"dispatch_int_uop{i}_psrc0"]),
                        bits_to_int(values[f"dispatch_int_uop{i}_psrc1"]),
                    ],
                    "pdest": bits_to_int(values[f"dispatch_int_uop{i}_pdest"]),
                    "robIdx": {
                        "flag": bits_to_int(values[f"dispatch_int_uop{i}_rob_flag"]),
                        "value": bits_to_int(values[f"dispatch_int_uop{i}_rob_value"]),
                    },
                    "srcState": [
                        values[f"dispatch_int_uop{i}_srcState0"],
                        values[f"dispatch_int_uop{i}_srcState1"],
                    ],
                })

        for i in range(TRACKED_VLQ_ENTRIES):
            snap = vlq_snapshot(i)
            key = (
                snap["allocated"],
                snap["committed"],
                snap["robIdx"]["flag"],
                snap["robIdx"]["value"],
            )
            if last_vlq.get(i) != key:
                last_vlq[i] = key
                vlq_change_trace.append({
                    "time": snapshot_time,
                    **snap,
                })

    with open(path, "r", errors="replace") as f:
        in_body = False
        for raw in f:
            line = raw.strip()
            if not in_body:
                if line.startswith("$enddefinitions"):
                    in_body = True
                continue
            if not line:
                continue
            if line[0] == "#":
                evaluate(time)
                time = int(line[1:])
                continue
            if line[0] in "01xz":
                logicals = ids.get(line[1:])
                if logicals is not None:
                    for logical in logicals:
                        values[logical] = line[0]
            elif line[0] in "bB":
                parts = line[1:].split(None, 1)
                if len(parts) != 2:
                    continue
                bits, ident = parts
                logicals = ids.get(ident)
                if logicals is not None:
                    for logical in logicals:
                        values[logical] = bits
        evaluate(time)

    killed_secret_wbs = [
        e for e in killed_writebacks
        if e["toIntRf_valid"] == "1"
        and e["backend_rf_wen"] == "1"
        and e["backend_rf_data"] == expected_rf_data
    ]
    recovered_secret_candidates = [
        e for e in killed_writebacks
        if e["toIntRf_valid"] == "1"
        and e["backend_rf_wen"] == "1"
        and e["backend_rf_data"] is not None
    ]
    delayed_killed_writebacks = [
        e for e in post_redirect_killed_writebacks
        if e["cycles_after_redirect"] > 0
    ]
    delayed_secret_wbs = [
        e for e in delayed_killed_writebacks
        if e["toIntRf_valid"] == "1"
        and e["backend_rf_wen"] == "1"
        and e["backend_rf_data"] == expected_rf_data
    ]
    killed_lsq_ldin_updates = [
        e for e in killed_writebacks
        if e["lqWrite_valid"] == "1"
        and e["lsq_ldin"]["valid"] == "1"
        and e["lsq_ldin"]["updateAddrValid"] == "1"
        and e["lsq_ldin"]["robIdx"] == e["writeback_robIdx"]
    ]
    killed_busytable_ready_marks = [
        e for e in killed_writebacks
        if e["backend_rf_wen"] == "1"
        and e["dispatch_busytable_wb"]["valid"] == "1"
        and e["dispatch_busytable_wb"]["pdest"] == e["backend_rf_pdest"]
    ]
    killed_load_early_wakeups_same_cycle = [
        e for e in killed_writebacks
        if e["load_early_wakeup"]["valid"] == "1"
        and e["load_early_wakeup"]["rfWen"] == "1"
        and e["load_early_wakeup"]["pdest"] == e["backend_rf_pdest"]
    ]
    fired_killed_fast_replays = [
        e for e in killed_fast_replays
        if e["fire"]
    ]
    fired_post_redirect_fast_replays = [
        e for e in post_redirect_fast_replays
        if e["fire"]
    ]
    first_kill_time = min((e["time"] for e in killed_secret_wbs), default=None)
    killed_pdest = (
        killed_secret_wbs[0]["backend_rf_pdest"]
        if killed_secret_wbs else None
    )
    killed_redirect = (
        killed_secret_wbs[0]["redirect_robIdx"]
        if killed_secret_wbs else None
    )
    killed_redirect_time = (
        killed_secret_wbs[0]["time"] - killed_secret_wbs[0]["cycles_after_redirect"]
        if killed_secret_wbs else None
    )
    same_cycle_pdest_reuse = [
        u for u in dispatch_uops
        if first_kill_time is not None
        and killed_pdest is not None
        and u["time"] == first_kill_time
        and u["rfWen"] == "1"
        and u["pdest"] == killed_pdest
    ]
    post_kill_pdest_reuse = [
        u for u in dispatch_uops
        if first_kill_time is not None
        and killed_pdest is not None
        and u["time"] > first_kill_time
        and u["rfWen"] == "1"
        and u["pdest"] == killed_pdest
    ]
    same_cycle_consumers_of_killed_pdest = [
        u for u in dispatch_uops
        if first_kill_time is not None
        and killed_pdest is not None
        and u["time"] == first_kill_time
        and killed_pdest in u["psrc"]
    ]
    post_kill_consumers_of_killed_pdest = [
        u for u in dispatch_uops
        if first_kill_time is not None
        and killed_pdest is not None
        and u["time"] > first_kill_time
        and killed_pdest in u["psrc"]
    ]
    post_kill_ready_consumers_of_killed_pdest = [
        u for u in post_kill_consumers_of_killed_pdest
        if any(
            psrc == killed_pdest and state == "1"
            for psrc, state in zip(u["psrc"], u["srcState"])
        )
    ]
    post_kill_probe_issues = [
        e for e in mem_issues
        if first_kill_time is not None
        and e["time"] > first_kill_time
        and e["which"] == "secret_probe"
    ]
    post_kill_probe_reqs = [
        e for e in probe_dcache_reqs
        if first_kill_time is not None
        and e["time"] > first_kill_time
        and e["which"] == "secret_probe"
    ]
    post_kill_probe_range_issues = [
        e for e in probe_range_mem_issues
        if first_kill_time is not None and e["time"] > first_kill_time
    ]
    post_kill_probe_range_reqs = [
        e for e in probe_range_dcache_reqs
        if first_kill_time is not None and e["time"] > first_kill_time
    ]
    same_cycle_probe_issues = [
        e for e in mem_issues
        if first_kill_time is not None
        and e["time"] == first_kill_time
        and e["which"] == "secret_probe"
    ]
    same_cycle_probe_reqs = [
        e for e in probe_dcache_reqs
        if first_kill_time is not None
        and e["time"] == first_kill_time
        and e["which"] == "secret_probe"
    ]
    same_or_post_kill_probe_issues = [
        e for e in mem_issues
        if first_kill_time is not None
        and e["time"] >= first_kill_time
        and e["which"] == "secret_probe"
    ]
    same_or_post_kill_probe_reqs = [
        e for e in probe_dcache_reqs
        if first_kill_time is not None
        and e["time"] >= first_kill_time
        and e["which"] == "secret_probe"
    ]
    same_or_post_kill_probe_range_issues = [
        e for e in probe_range_mem_issues
        if first_kill_time is not None and e["time"] >= first_kill_time
    ]
    same_or_post_kill_probe_range_reqs = [
        e for e in probe_range_dcache_reqs
        if first_kill_time is not None and e["time"] >= first_kill_time
    ]
    same_or_post_kill_wrong_path_probe_issues = []
    if killed_redirect is not None:
        for e in same_or_post_kill_probe_range_issues:
            rename_time = e.get("perf_rename_time")
            if rob_after(
                e["robIdx"]["flag"],
                e["robIdx"]["value"],
                killed_redirect["flag"],
                killed_redirect["value"],
            ) and (
                rename_time is not None
                and killed_redirect_time is not None
                and rename_time <= killed_redirect_time
            ):
                same_or_post_kill_wrong_path_probe_issues.append(e)
    lsq_enq_uses_killed_pdest = [
        e for e in lsq_enq_reqs
        if killed_pdest is not None and killed_pdest in e["psrc"]
    ]
    pre_or_same_kill_lsq_enq_uses_killed_pdest = [
        e for e in lsq_enq_uses_killed_pdest
        if first_kill_time is not None and e["time"] <= first_kill_time
    ]
    same_or_post_kill_lsq_enq_uses_killed_pdest = [
        e for e in lsq_enq_uses_killed_pdest
        if first_kill_time is not None and e["time"] >= first_kill_time
    ]
    post_kill_lsq_enq_uses_killed_pdest = [
        e for e in lsq_enq_uses_killed_pdest
        if first_kill_time is not None and e["time"] > first_kill_time
    ]
    same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest = []
    if killed_redirect is not None and killed_redirect_time is not None:
        for e in same_or_post_kill_lsq_enq_uses_killed_pdest:
            rename_time = e.get("perf_rename_time")
            if (
                rename_time is not None
                and rename_time <= killed_redirect_time
                and rob_after(
                    e["robIdx"]["flag"],
                    e["robIdx"]["value"],
                    killed_redirect["flag"],
                    killed_redirect["value"],
                )
            ):
                same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest.append(e)

    return {
        "wave": path,
        "missing_signals": missing,
        "secret_offset": secret_offset,
        "expected_rf_data": expected_rf_data,
        "probe_base": probe_base,
        "killed_writebacks": killed_writebacks[:20],
        "all_load_writebacks": all_load_writebacks[:240],
        "post_redirect_killed_writebacks": (
            post_redirect_killed_writebacks[:80]
        ),
        "delayed_killed_writebacks": delayed_killed_writebacks[:80],
        "killed_secret_writebacks": killed_secret_wbs[:20],
        "delayed_secret_writebacks": delayed_secret_wbs[:80],
        "recovered_secret_candidates": recovered_secret_candidates[:20],
        "killed_lsq_ldin_updates": killed_lsq_ldin_updates[:20],
        "killed_busytable_ready_marks": killed_busytable_ready_marks[:20],
        "redirect_events": redirect_events[:80],
        "killed_fast_replays": killed_fast_replays[:40],
        "fired_killed_fast_replays": fired_killed_fast_replays[:40],
        "all_fast_replays": all_fast_replays[:200],
        "post_redirect_fast_replays": post_redirect_fast_replays[:80],
        "fired_post_redirect_fast_replays": (
            fired_post_redirect_fast_replays[:80]
        ),
        "killed_load_early_wakeups_same_cycle": (
            killed_load_early_wakeups_same_cycle[:20]
        ),
        "dispatch_uops": dispatch_uops[:200],
        "same_cycle_pdest_reuse": same_cycle_pdest_reuse[:40],
        "post_kill_pdest_reuse": post_kill_pdest_reuse[:80],
        "same_cycle_consumers_of_killed_pdest": (
            same_cycle_consumers_of_killed_pdest[:40]
        ),
        "post_kill_consumers_of_killed_pdest": (
            post_kill_consumers_of_killed_pdest[:80]
        ),
        "post_kill_ready_consumers_of_killed_pdest": (
            post_kill_ready_consumers_of_killed_pdest[:80]
        ),
        "probe_mem_issues": mem_issues[:80],
        "probe_dcache_reqs": probe_dcache_reqs[:80],
        "probe_range_mem_issues": probe_range_mem_issues[:120],
        "probe_range_dcache_reqs": probe_range_dcache_reqs[:120],
        "post_kill_probe_issues": post_kill_probe_issues[:40],
        "post_kill_probe_dcache_reqs": post_kill_probe_reqs[:40],
        "post_kill_probe_range_issues": post_kill_probe_range_issues[:80],
        "post_kill_probe_range_dcache_reqs": post_kill_probe_range_reqs[:80],
        "same_cycle_probe_issues": same_cycle_probe_issues[:40],
        "same_cycle_probe_dcache_reqs": same_cycle_probe_reqs[:40],
        "same_or_post_kill_probe_issues": (
            same_or_post_kill_probe_issues[:80]
        ),
        "same_or_post_kill_probe_dcache_reqs": (
            same_or_post_kill_probe_reqs[:80]
        ),
        "same_or_post_kill_probe_range_issues": (
            same_or_post_kill_probe_range_issues[:120]
        ),
        "same_or_post_kill_probe_range_dcache_reqs": (
            same_or_post_kill_probe_range_reqs[:120]
        ),
        "same_or_post_kill_wrong_path_probe_issues": (
            same_or_post_kill_wrong_path_probe_issues[:120]
        ),
        "lsq_enq_reqs": lsq_enq_reqs[:240],
        "lsq_enq_uses_killed_pdest": lsq_enq_uses_killed_pdest[:120],
        "pre_or_same_kill_lsq_enq_uses_killed_pdest": (
            pre_or_same_kill_lsq_enq_uses_killed_pdest[:120]
        ),
        "same_or_post_kill_lsq_enq_uses_killed_pdest": (
            same_or_post_kill_lsq_enq_uses_killed_pdest[:120]
        ),
        "post_kill_lsq_enq_uses_killed_pdest": (
            post_kill_lsq_enq_uses_killed_pdest[:120]
        ),
        "same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest": (
            same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest[:120]
        ),
        "vlq_change_trace": vlq_change_trace[:400],
        "counts": {
            "killed_writebacks": len(killed_writebacks),
            "all_load_writebacks": len(all_load_writebacks),
            "post_redirect_killed_writebacks": (
                len(post_redirect_killed_writebacks)
            ),
            "delayed_killed_writebacks": len(delayed_killed_writebacks),
            "killed_secret_writebacks": len(killed_secret_wbs),
            "delayed_secret_writebacks": len(delayed_secret_wbs),
            "recovered_secret_candidates": len(recovered_secret_candidates),
            "killed_lsq_ldin_updates": len(killed_lsq_ldin_updates),
            "killed_busytable_ready_marks": len(killed_busytable_ready_marks),
            "redirect_events": len(redirect_events),
            "killed_fast_replays": len(killed_fast_replays),
            "fired_killed_fast_replays": len(fired_killed_fast_replays),
            "all_fast_replays": len(all_fast_replays),
            "post_redirect_fast_replays": len(post_redirect_fast_replays),
            "fired_post_redirect_fast_replays": (
                len(fired_post_redirect_fast_replays)
            ),
            "killed_load_early_wakeups_same_cycle": (
                len(killed_load_early_wakeups_same_cycle)
            ),
            "dispatch_uops": len(dispatch_uops),
            "same_cycle_pdest_reuse": len(same_cycle_pdest_reuse),
            "post_kill_pdest_reuse": len(post_kill_pdest_reuse),
            "same_cycle_consumers_of_killed_pdest": (
                len(same_cycle_consumers_of_killed_pdest)
            ),
            "post_kill_consumers_of_killed_pdest": (
                len(post_kill_consumers_of_killed_pdest)
            ),
            "post_kill_ready_consumers_of_killed_pdest": (
                len(post_kill_ready_consumers_of_killed_pdest)
            ),
            "probe_mem_issues": len(mem_issues),
            "probe_dcache_reqs": len(probe_dcache_reqs),
            "probe_range_mem_issues": len(probe_range_mem_issues),
            "probe_range_dcache_reqs": len(probe_range_dcache_reqs),
            "post_kill_probe_issues": len(post_kill_probe_issues),
            "post_kill_probe_dcache_reqs": len(post_kill_probe_reqs),
            "post_kill_probe_range_issues": len(post_kill_probe_range_issues),
            "post_kill_probe_range_dcache_reqs": len(post_kill_probe_range_reqs),
            "same_cycle_probe_issues": len(same_cycle_probe_issues),
            "same_cycle_probe_dcache_reqs": len(same_cycle_probe_reqs),
            "same_or_post_kill_probe_issues": (
                len(same_or_post_kill_probe_issues)
            ),
            "same_or_post_kill_probe_dcache_reqs": (
                len(same_or_post_kill_probe_reqs)
            ),
            "same_or_post_kill_probe_range_issues": (
                len(same_or_post_kill_probe_range_issues)
            ),
            "same_or_post_kill_probe_range_dcache_reqs": (
                len(same_or_post_kill_probe_range_reqs)
            ),
            "same_or_post_kill_wrong_path_probe_issues": (
                len(same_or_post_kill_wrong_path_probe_issues)
            ),
            "lsq_enq_reqs": len(lsq_enq_reqs),
            "lsq_enq_uses_killed_pdest": len(lsq_enq_uses_killed_pdest),
            "pre_or_same_kill_lsq_enq_uses_killed_pdest": (
                len(pre_or_same_kill_lsq_enq_uses_killed_pdest)
            ),
            "same_or_post_kill_lsq_enq_uses_killed_pdest": (
                len(same_or_post_kill_lsq_enq_uses_killed_pdest)
            ),
            "post_kill_lsq_enq_uses_killed_pdest": (
                len(post_kill_lsq_enq_uses_killed_pdest)
            ),
            "same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest": (
                len(same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest)
            ),
            "vlq_change_trace": len(vlq_change_trace),
        },
        "predicate": {
            "secret_written_by_killed_load": bool(killed_secret_wbs),
            "delayed_killed_writeback": bool(delayed_killed_writebacks),
            "delayed_secret_writeback": bool(delayed_secret_wbs),
            "recoverable_secret_on_killed_rf_bus": bool(recovered_secret_candidates),
            "killed_load_reaches_lsq_ldin": bool(killed_lsq_ldin_updates),
            "killed_load_marks_busytable_ready": bool(killed_busytable_ready_marks),
            "killed_load_fast_replay_valid": bool(killed_fast_replays),
            "killed_load_fast_replay_fired": bool(fired_killed_fast_replays),
            "post_redirect_fast_replay_valid": bool(post_redirect_fast_replays),
            "post_redirect_fast_replay_fired": (
                bool(fired_post_redirect_fast_replays)
            ),
            "killed_load_early_wakeup_same_cycle": (
                bool(killed_load_early_wakeups_same_cycle)
            ),
            "same_cycle_reallocates_killed_pdest": bool(same_cycle_pdest_reuse),
            "post_kill_reuses_killed_pdest": bool(post_kill_pdest_reuse),
            "post_kill_ready_consumer_of_killed_pdest": (
                bool(post_kill_ready_consumers_of_killed_pdest)
            ),
            "post_kill_secret_probe_issue": bool(post_kill_probe_issues),
            "post_kill_secret_probe_dcache_req": bool(post_kill_probe_reqs),
            "same_cycle_secret_probe_issue": bool(same_cycle_probe_issues),
            "same_cycle_secret_probe_dcache_req": bool(same_cycle_probe_reqs),
            "same_or_post_kill_secret_probe_issue": (
                bool(same_or_post_kill_probe_issues)
            ),
            "same_or_post_kill_secret_probe_dcache_req": (
                bool(same_or_post_kill_probe_reqs)
            ),
            "post_kill_any_probe_range_issue": bool(post_kill_probe_range_issues),
            "post_kill_any_probe_range_dcache_req": bool(post_kill_probe_range_reqs),
            "same_or_post_kill_any_probe_range_issue": (
                bool(same_or_post_kill_probe_range_issues)
            ),
            "same_or_post_kill_any_probe_range_dcache_req": (
                bool(same_or_post_kill_probe_range_reqs)
            ),
            "same_or_post_kill_wrong_path_probe_issue": (
                bool(same_or_post_kill_wrong_path_probe_issues)
            ),
            "lsq_enq_uses_killed_pdest": bool(lsq_enq_uses_killed_pdest),
            "pre_or_same_kill_lsq_enq_uses_killed_pdest": (
                bool(pre_or_same_kill_lsq_enq_uses_killed_pdest)
            ),
            "same_or_post_kill_lsq_enq_uses_killed_pdest": (
                bool(same_or_post_kill_lsq_enq_uses_killed_pdest)
            ),
            "post_kill_lsq_enq_uses_killed_pdest": (
                bool(post_kill_lsq_enq_uses_killed_pdest)
            ),
            "same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest": (
                bool(same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest)
            ),
            "security_poc_reproduced": bool(
                killed_secret_wbs and same_or_post_kill_probe_reqs
            ),
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("wave")
    ap.add_argument("out_json")
    ap.add_argument("--secret-offset", type=lambda x: int(x, 0), required=True)
    ap.add_argument("--probe-base", type=lambda x: int(x, 0), required=True)
    ap.add_argument("--expected-rf-data", type=lambda x: int(x, 0))
    args = ap.parse_args()

    result = parse_vcd(
        args.wave,
        args.secret_offset,
        args.probe_base,
        args.expected_rf_data,
    )
    with open(args.out_json, "w") as f:
        json.dump(result, f, indent=2, sort_keys=True)
    print(json.dumps({
        "predicate": result["predicate"],
        "counts": result["counts"],
        "first_killed_secret_writeback": (
            result["killed_secret_writebacks"][0]
            if result["killed_secret_writebacks"] else None
        ),
        "first_recovered_secret_candidate": (
            result["recovered_secret_candidates"][0]
            if result["recovered_secret_candidates"] else None
        ),
        "first_post_kill_probe_dcache_req": (
            result["post_kill_probe_dcache_reqs"][0]
            if result["post_kill_probe_dcache_reqs"] else None
        ),
        "missing_signals": result["missing_signals"][:20],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
