#!/usr/bin/env python3
import argparse
import glob
import json
from pathlib import Path


def load_json(path):
    with open(path) as f:
        return json.load(f)


def fired(req):
    if req.get("fire") is True:
        return True
    return req.get("valid") == "1" and req.get("ready") == "1"


def has_fire_fields(req):
    return "fire" in req or ("valid" in req and "ready" in req)


def source_valid(req, source):
    return req.get("sources", {}).get(source, {}).get("valid") == "1"


def compact_event(path, event, extra=None):
    item = {
        "monitor_json": Path(path).name,
        "time": event.get("time"),
        "load_unit": event.get("load_unit"),
        "cycles_after_redirect": event.get("cycles_after_redirect"),
        "redirect_robIdx": event.get("redirect_robIdx"),
        "writeback_robIdx": event.get("writeback_robIdx"),
        "replay_robIdx": event.get("replay_robIdx"),
        "backend_rf_pdest": event.get("backend_rf_pdest"),
        "backend_rf_data": event.get("backend_rf_data"),
    }
    if extra:
        item.update(extra)
    return item


def fastreplay_pre_touch(data, event):
    probe_base = data.get("probe_base")
    vaddr = event.get("vaddr")
    if probe_base is None or vaddr is None:
        return {
            "offset": None,
            "pre_redirect_same_line_accepted_count": None,
            "pre_redirect_same_line_unknown_count": None,
            "pre_redirect_scalar_same_line_count": None,
            "isolated_new_cache_footprint": False,
            "fields_complete": False,
        }

    offset = vaddr - probe_base
    redirect_time = event.get("time")
    if redirect_time is not None and event.get("cycles_after_redirect") is not None:
        redirect_time -= event["cycles_after_redirect"]

    accepted = []
    unknown = []
    scalar = []
    for req in data.get("probe_range_dcache_reqs", []):
        req_offset = req.get("offset")
        req_time = req.get("time")
        if req_offset is None or req_time is None or redirect_time is None:
            continue
        if req_offset // 64 != offset // 64 or req_time >= redirect_time:
            continue
        if not has_fire_fields(req):
            unknown.append(req)
            continue
        if fired(req):
            accepted.append(req)
            if source_valid(req, "scalar"):
                scalar.append(req)

    fields_complete = not unknown
    return {
        "offset": offset,
        "pre_redirect_same_line_accepted_count": len(accepted),
        "pre_redirect_same_line_unknown_count": len(unknown),
        "pre_redirect_scalar_same_line_count": len(scalar),
        "isolated_new_cache_footprint": fields_complete and not accepted,
        "fields_complete": fields_complete,
    }


def analyze_file(path):
    data = load_json(path)
    fired_fr = []
    isolated_fr = []
    unresolved_fr = []
    for event in data.get("fired_killed_fast_replays", []):
        detail = fastreplay_pre_touch(data, event)
        item = compact_event(path, event, detail)
        fired_fr.append(item)
        if detail["isolated_new_cache_footprint"]:
            isolated_fr.append(item)
        if not detail["fields_complete"]:
            unresolved_fr.append(item)

    recovered_rf = [
        compact_event(path, event)
        for event in data.get("recovered_secret_candidates", [])
        if event.get("toIntRf_valid") == "1"
        and event.get("backend_rf_wen") == "1"
        and event.get("backend_rf_data") is not None
    ]

    return {
        "monitor_json": Path(path).name,
        "recovered_rf_candidates": recovered_rf,
        "delayed_killed_writebacks": [
            compact_event(path, event)
            for event in data.get("delayed_killed_writebacks", [])
        ],
        "delayed_secret_writebacks": [
            compact_event(path, event)
            for event in data.get("delayed_secret_writebacks", [])
        ],
        "post_kill_ready_consumers": data.get(
            "post_kill_ready_consumers_of_killed_pdest",
            [],
        ),
        "same_cycle_pdest_reuse": data.get("same_cycle_pdest_reuse", []),
        "post_kill_pdest_reuse": data.get("post_kill_pdest_reuse", []),
        "wrong_path_lsq_uses_killed_pdest": data.get(
            "same_or_post_kill_wrong_path_lsq_enq_uses_killed_pdest",
            [],
        ),
        "same_or_post_secret_probe_dcache_reqs": data.get(
            "same_or_post_kill_probe_dcache_reqs",
            [],
        ),
        "fired_killed_fast_replays": fired_fr,
        "isolated_fast_replays": isolated_fr,
        "unresolved_fast_replays": unresolved_fr,
    }


def limited(items, limit):
    return items[:limit]


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Scan monitor JSONs for software-observable exploit candidates "
            "beyond the already-proven physical RF side-channel."
        )
    )
    ap.add_argument(
        "monitor_json",
        nargs="*",
        help="monitor JSON files; defaults to *.monitor.json in cwd",
    )
    ap.add_argument(
        "--include-stale-reparse-sources",
        action="store_true",
        help=(
            "include old foo.monitor.json files even when "
            "foo.reparse.monitor.json is present"
        ),
    )
    ap.add_argument("--limit", type=int, default=20, help="example limit")
    args = ap.parse_args()

    paths = args.monitor_json or sorted(glob.glob("*.monitor.json"))
    if not args.include_stale_reparse_sources:
        path_names = {Path(path).name for path in paths}
        replaced = {
            name.replace(".reparse.monitor.json", ".monitor.json")
            for name in path_names
            if name.endswith(".reparse.monitor.json")
        }
        paths = [
            path for path in paths
            if Path(path).name not in replaced
        ]
    results = [analyze_file(path) for path in paths]

    rf_files = [r for r in results if r["recovered_rf_candidates"]]
    delayed = [
        item
        for r in results
        for item in r["delayed_killed_writebacks"]
    ]
    delayed_secret = [
        item
        for r in results
        for item in r["delayed_secret_writebacks"]
    ]
    ready_consumers = [
        {"monitor_json": r["monitor_json"], "events": r["post_kill_ready_consumers"]}
        for r in results
        if r["post_kill_ready_consumers"]
    ]
    same_cycle_reuse = [
        {"monitor_json": r["monitor_json"], "events": r["same_cycle_pdest_reuse"]}
        for r in results
        if r["same_cycle_pdest_reuse"]
    ]
    wrong_lsq = [
        {"monitor_json": r["monitor_json"], "events": r["wrong_path_lsq_uses_killed_pdest"]}
        for r in results
        if r["wrong_path_lsq_uses_killed_pdest"]
    ]
    secret_probe = [
        {"monitor_json": r["monitor_json"], "events": r["same_or_post_secret_probe_dcache_reqs"]}
        for r in results
        if r["same_or_post_secret_probe_dcache_reqs"]
    ]
    fired_fr = [
        item for r in results for item in r["fired_killed_fast_replays"]
    ]
    isolated_fr = [
        item for r in results for item in r["isolated_fast_replays"]
    ]
    unresolved_fr = [
        item for r in results for item in r["unresolved_fast_replays"]
    ]

    software_candidate = bool(
        delayed_secret
        or ready_consumers
        or wrong_lsq
        or secret_probe
        or isolated_fr
    )

    summary = {
        "monitor_jsons_scanned": len(paths),
        "rf_physical_sidechannel_candidate_files": len(rf_files),
        "software_observable_candidate_found": software_candidate,
        "delayed_killed_writeback_count": len(delayed),
        "delayed_secret_writeback_count": len(delayed_secret),
        "post_kill_ready_consumer_file_count": len(ready_consumers),
        "same_cycle_pdest_reuse_file_count": len(same_cycle_reuse),
        "wrong_path_lsq_uses_killed_pdest_file_count": len(wrong_lsq),
        "same_or_post_secret_probe_dcache_file_count": len(secret_probe),
        "fired_killed_fastreplay_count": len(fired_fr),
        "isolated_fastreplay_cache_footprint_count": len(isolated_fr),
        "unresolved_fastreplay_pre_touch_count": len(unresolved_fr),
        "examples": {
            "delayed_killed_writebacks": limited(delayed, args.limit),
            "delayed_secret_writebacks": limited(delayed_secret, args.limit),
            "post_kill_ready_consumers": limited(ready_consumers, args.limit),
            "same_cycle_pdest_reuse": limited(same_cycle_reuse, args.limit),
            "wrong_path_lsq_uses_killed_pdest": limited(wrong_lsq, args.limit),
            "same_or_post_secret_probe_dcache": limited(secret_probe, args.limit),
            "fired_killed_fastreplays": limited(fired_fr, args.limit),
            "isolated_fastreplay_cache_footprints": limited(isolated_fr, args.limit),
            "unresolved_fastreplay_pre_touch": limited(unresolved_fr, args.limit),
        },
    }

    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
