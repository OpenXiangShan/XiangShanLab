#!/usr/bin/env bash
set -euo pipefail

gap="${1:?usage: run_direct_ptr_probe_once.sh GAP [SECRET_OFFSET] [FALLTHROUGH_DELAY] [TAIL_REPS] [PRE_CONSUMER_FILLER_REPS]}"
secret_offset="${2:-64}"
delay="${3:-6}"
tail="${4:-156}"
filler="${5:-0}"
prefix="directptr_gap${gap}_off${secret_offset}_d${delay}_tail${tail}_fill${filler}"

/opt/riscv/bin/riscv64-unknown-elf-gcc \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
  -DSECRET_OFFSET="${secret_offset}" \
  -DFALLTHROUGH_DELAY="${delay}" \
  -DGAP_REPS="${gap}" \
  -DTAIL_REPS="${tail}" \
  -DPRE_CONSUMER_FILLER_REPS="${filler}" \
  -T linker.ld \
  -o "${prefix}.elf" \
  secret_probe_direct_ptr.S

/opt/riscv/bin/riscv64-unknown-elf-objcopy -O binary "${prefix}.elf" "${prefix}.bin"
/opt/riscv/bin/riscv64-unknown-elf-objdump -d "${prefix}.elf" > "${prefix}.objdump"
/opt/riscv/bin/riscv64-unknown-elf-nm -n "${prefix}.elf" > "${prefix}.symbols"

probe_base="$(awk '$3 == "probe_base" { print "0x" $1 }' "${prefix}.symbols")"
expected_rf_data="$(python3 -c 'import sys; print(hex(int(sys.argv[1], 0) + int(sys.argv[2], 0)))' "${probe_base}" "${secret_offset}")"

/root/HardwareAgent/XiangShan/build_vcd/emu \
  --max-cycles=9000 \
  -b 8000 -e 8500 \
  --dump-wave \
  --wave-path="${prefix}_8000_8500.vcd" \
  -i "${prefix}.bin" \
  --no-diff > "${prefix}_8000_8500.run.log" 2>&1

python3 monitor_secret_probe_vcd.py \
  "${prefix}_8000_8500.vcd" \
  "${prefix}_8000_8500.monitor.json" \
  --secret-offset "${secret_offset}" \
  --probe-base "${probe_base}" \
  --expected-rf-data "${expected_rf_data}"
