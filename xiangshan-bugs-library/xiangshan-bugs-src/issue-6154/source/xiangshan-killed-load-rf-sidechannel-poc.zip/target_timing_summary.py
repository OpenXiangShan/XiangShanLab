#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


TOFF_RE = re.compile(r"_toff([0-9a-fA-Fx]+)_")


def parse_target_offset(path):
    match = TOFF_RE.search(Path(path).name)
    if not match:
        return None
    return int(match.group(1), 0)


def source_valid(req, name):
    return req.get("sources", {}).get(name, {}).get("valid") == "1"


def summarize_req(req):
    return {
        "time": req.get("time"),
        "load_unit": req.get("load_unit"),
        "lqIdx": req.get("lqIdx"),
        "fire": req.get("fire"),
        "ready": req.get("ready"),
        "sources": {
            "scalar": source_valid(req, "scalar"),
            "fastReplay": source_valid(req, "fastReplay"),
            "replay": source_valid(req, "replay"),
            "prefetch": source_valid(req, "prefetch"),
        },
    }


def event_offset(data, event):
    base = data.get("probe_base")
    vaddr = event.get("vaddr")
    if base is None or vaddr is None:
        return None
    return vaddr - base


def redirect_time(data):
    redirects = [
        event.get("time")
        for event in data.get("redirect_events", [])
        if event.get("time") is not None
    ]
    return min(redirects) if redirects else None


def load_observation(path):
    with open(path) as f:
        data = json.load(f)

    target_offset = parse_target_offset(path)
    if target_offset is None:
        raise ValueError(f"{path}: cannot infer TARGET_OFFSET from filename")

    target_wbs = [
        wb for wb in data.get("all_load_writebacks", [])
        if event_offset(data, wb) == target_offset
    ]
    target_wb = target_wbs[0] if target_wbs else None
    issue_time = (
        target_wb.get("perf_time", {}).get("issue")
        if target_wb else None
    )
    writeback_time = target_wb.get("time") if target_wb else None
    latency = (
        writeback_time - issue_time
        if issue_time is not None and writeback_time is not None
        else None
    )

    redir_time = redirect_time(data)
    target_reqs = [
        req for req in data.get("probe_range_dcache_reqs", [])
        if req.get("offset") == target_offset
    ]
    fired_target_reqs = [
        req for req in target_reqs
        if req.get("fire") is True
    ]
    pre_redirect_reqs = [
        req for req in fired_target_reqs
        if redir_time is not None and req.get("time") is not None
        and req["time"] < redir_time
    ]
    target_scalar_reqs = [
        req for req in fired_target_reqs
        if source_valid(req, "scalar")
    ]
    target_fast_replay_reqs = [
        req for req in fired_target_reqs
        if source_valid(req, "fastReplay")
    ]
    killed_fast_replays = [
        event for event in data.get("fired_killed_fast_replays", [])
        if event_offset(data, event) == target_offset
    ]
    post_redirect_fast_replays = [
        event for event in data.get("fired_post_redirect_fast_replays", [])
        if event_offset(data, event) == target_offset
    ]

    return {
        "monitor_json": path,
        "target_offset": target_offset,
        "redirect_time": redir_time,
        "target_writeback": target_wb,
        "issue_to_writeback_latency": latency,
        "target_request_timeline": [
            summarize_req(req) for req in target_reqs
        ],
        "pre_redirect_accepted_same_line_requests": [
            summarize_req(req) for req in pre_redirect_reqs
        ],
        "target_scalar_request_times": [
            req.get("time") for req in target_scalar_reqs
        ],
        "target_fast_replay_request_times": [
            req.get("time") for req in target_fast_replay_reqs
        ],
        "killed_fast_replay_times": [
            event.get("time") for event in killed_fast_replays
        ],
        "post_redirect_fast_replay_times": [
            event.get("time") for event in post_redirect_fast_replays
        ],
        "has_killed_fast_replay_to_target": bool(killed_fast_replays),
    }


def main():
    ap = argparse.ArgumentParser(
        description=(
            "Summarize redirect-target load timing controls for the "
            "killed-fastReplay PoC."
        )
    )
    ap.add_argument("monitor_json", nargs="+")
    args = ap.parse_args()

    observations = [load_observation(path) for path in args.monitor_json]
    killed_latencies = [
        obs["issue_to_writeback_latency"]
        for obs in observations
        if obs["has_killed_fast_replay_to_target"]
        and obs["issue_to_writeback_latency"] is not None
    ]
    control_latencies = [
        obs["issue_to_writeback_latency"]
        for obs in observations
        if not obs["has_killed_fast_replay_to_target"]
        and obs["issue_to_writeback_latency"] is not None
    ]
    inconclusive_controls = [
        obs for obs in observations
        if not obs["has_killed_fast_replay_to_target"]
        and obs["issue_to_writeback_latency"] in killed_latencies
    ]
    near_controls = []
    for obs in observations:
        latency = obs["issue_to_writeback_latency"]
        if obs["has_killed_fast_replay_to_target"] or latency is None:
            continue
        if any(abs(latency - killed) <= 4 for killed in killed_latencies):
            near_controls.append(obs)

    summary = {
        "target_timing_leak_proven": bool(killed_latencies)
        and bool(control_latencies)
        and not inconclusive_controls
        and not near_controls
        and min(killed_latencies) > max(control_latencies),
        "killed_target_latencies": killed_latencies,
        "control_target_latencies": control_latencies,
        "near_latency_controls_without_killed_replay": [
            {
                "monitor_json": obs["monitor_json"],
                "target_offset": obs["target_offset"],
                "latency": obs["issue_to_writeback_latency"],
            }
            for obs in near_controls
        ],
        "observations": observations,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not summary["target_timing_leak_proven"]:
        raise SystemExit("target timing leak not proven")


if __name__ == "__main__":
    main()
