xiangshan vnclip-rounding reproducer
====================================

Issue: [BUG] vnclip commits the unrounded narrow result and keeps vxsat at zero

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: 592d1428a8e180b4e5cf78df500981b201aa486b4c4a671096a82ae2bf3a2097

prog.c
    Reproducer source.
    SHA-256: 08c102f10916279ac3e161c04a4416b45d55c9c2f5b99d265c8e09da4e460271

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: 2d59d599c1d569819bbab6aa638af7c549cd739f1915d60b7685b71a4e7f41db

sim.log
    Difftest log of the failing run.
    SHA-256: 6bac9b767d680e9d7363dffbcbfc01b2081174d78c751878673e151dfcb17de0

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures SEW=16, LMUL=m1, sets `vxrm=RNU`, fills `v2` with `0xffff`, and executes `vnclip.wi v4, v2, 1` at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB.
- Run the same ELF on the Spike difftest reference and compare `v4`, `vxsat` and `vcsr`.

Expected:
  `vnclip.wi v4, v2, 1` with `vs2=0xffff`, SEW=16, `vxrm=RNU` must produce `v4 = 0` and `vxsat = 1`.

Observed:
  The DUT commits the unrounded value and no saturation flag:
  
  ```text
   v4_low  different at pc = 0xfffe10d5004db516, right = 0x0000000000000000, wrong = 0xffffffffffffffff
  v4_high different at pc = 0xfffe10d5004db516, right = 0x0000000000000000, wrong = 0xffffffffffffffff
  Core 0: ABORT at pc = 0xfffe10d5004db516
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
