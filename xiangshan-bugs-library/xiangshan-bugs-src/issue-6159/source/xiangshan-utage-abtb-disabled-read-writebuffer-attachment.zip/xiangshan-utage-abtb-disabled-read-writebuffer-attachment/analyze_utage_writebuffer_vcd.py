#!/usr/bin/env python3
import json
import re
import sys
from collections import Counter
from pathlib import Path


VCD = Path(sys.argv[1])
START_TIME = int(sys.argv[2]) if len(sys.argv) > 2 else 0
END_TIME = int(sys.argv[3]) if len(sys.argv) > 3 else 1 << 62


def value_to_int(raw):
    if raw is None or raw == "" or any(c in raw for c in "xzXZ"):
        return None
    return int(raw, 2)


def h(value):
    return None if value is None else hex(value)


def bank_id(index, banks=4):
    if index is None:
        return None
    return index & (banks - 1)


def parse_header(path):
    scopes = []
    name_to_code = {}
    header_end = 0
    with path.open(errors="replace") as f:
        for lineno, line in enumerate(f, 1):
            s = line.strip()
            if s.startswith("$scope"):
                parts = s.split()
                scopes.append(parts[2])
            elif s.startswith("$upscope"):
                if scopes:
                    scopes.pop()
            elif s.startswith("$var"):
                parts = s.split()
                code = parts[3]
                name = parts[4]
                name_to_code[".".join(scopes + [name])] = code
            elif s.startswith("$enddefinitions"):
                header_end = lineno
                break
    return header_end, name_to_code


HEADER_END, NAME_CODE = parse_header(VCD)


def find_suffix(suffix):
    matches = [(name, code) for name, code in NAME_CODE.items() if name.endswith(suffix)]
    matches.sort(key=lambda x: (".inner_bpu." not in x[0], len(x[0])))
    return matches[0] if matches else (None, None)


sig = {}


def add(key, suffix):
    name, code = find_suffix(suffix)
    if code is not None:
        sig[key] = (name, code)


add("abtb_enable", ".core.frontend.io_csrCtrl_bp_ctrl_abtbEnable")
add("s0_fire", ".core.frontend.inner_bpu.s0_fire")
add("stage_s0_fire", ".core.frontend.inner_bpu.abtb_io_stageCtrl_s0_fire_probe")

table_re = re.compile(r"\.core\.frontend\.(?:inner_bpu|inner\.bpu)\.utage\.(MicroTageTable(?:_(\d+))?)\.")
for fullname, code in NAME_CODE.items():
    m = table_re.search(fullname)
    if not m:
        continue
    table = int(m.group(2) or 0)
    local = fullname.split(f".{m.group(1)}.", 1)[-1]
    key_base = f"t{table}"
    signal_leaf = local.rsplit(".", 1)[-1]
    wanted = {
        "io_req_bits_readIndex": "read_index",
        "bankId": "read_bank",
        "io_tryWrite_valid": "try_write",
        "io_tryWrite_bits_writeIndex": "write_index",
        "io_tryWrite_bits_forceWrite": "force_write",
        "io_writeSuccess": "write_success",
        "writeSuccess": "write_success_inner",
        "tryWrite": "try_write_inner",
        "writeBankId": "write_bank",
        "io_train_t1_alloc_valid": "alloc_valid",
        "io_train_t1_update_0_valid": "update0_valid",
        "io_train_t0_trainIndex_valid": "train_index_valid",
    }
    if signal_leaf in wanted:
        sig[f"{key_base}_{wanted[signal_leaf]}"] = (fullname, code)
    bank_m = re.search(r"\.utage_entry_sram_bank(\d+)\.io_w_req_valid$", fullname)
    if bank_m:
        sig[f"{key_base}_bank{bank_m.group(1)}_w_req_valid"] = (fullname, code)
    bank_m = re.search(r"\.utage_entry_sram_bank(\d+)\.io_r_req_valid$", fullname)
    if bank_m:
        sig[f"{key_base}_bank{bank_m.group(1)}_r_req_valid"] = (fullname, code)

watch_codes = {code for _, code in sig.values()}
code_to_keys = {}
for key, (_, code) in sig.items():
    code_to_keys.setdefault(code, []).append(key)


def raw(vals, key):
    item = sig.get(key)
    if not item:
        return None
    return vals.get(item[1])


def get(vals, key):
    return value_to_int(raw(vals, key))


def one(vals, key):
    return raw(vals, key) == "1"


counts = Counter()
first = {}
events = []


def record(kind, row, limit=64):
    counts[kind] += 1
    first.setdefault(kind, row)
    if len(events) < limit:
        events.append({"kind": kind, **row})


def snapshot(t, vals):
    if t is None or t < START_TIME or t > END_TIME:
        return
    disabled = raw(vals, "abtb_enable") == "0"
    if disabled:
        counts["abtb_disabled_samples"] += 1
    tables = sorted({
        int(m.group(1))
        for key in sig
        for m in [re.match(r"t(\d+)_", key)]
        if m
    })
    for table in tables:
        prefix = f"t{table}"
        try_write = one(vals, f"{prefix}_try_write") or one(vals, f"{prefix}_try_write_inner")
        alloc = one(vals, f"{prefix}_alloc_valid")
        update = one(vals, f"{prefix}_update0_valid")
        if alloc:
            counts["alloc_valid_samples"] += 1
        if update:
            counts["update_valid_samples"] += 1
        if not try_write:
            continue
        write_success = one(vals, f"{prefix}_write_success") or one(vals, f"{prefix}_write_success_inner")
        read_index = get(vals, f"{prefix}_read_index")
        write_index = get(vals, f"{prefix}_write_index")
        read_bank = get(vals, f"{prefix}_read_bank")
        if read_bank is None:
            read_bank = bank_id(read_index)
        write_bank = get(vals, f"{prefix}_write_bank")
        if write_bank is None:
            write_bank = bank_id(write_index)
        row = {
            "t": t,
            "table": table,
            "abtb_enable": raw(vals, "abtb_enable"),
            "s0_fire": raw(vals, "s0_fire") or raw(vals, "stage_s0_fire"),
            "read_index": h(read_index),
            "read_bank": read_bank,
            "write_index": h(write_index),
            "write_bank": write_bank,
            "read_bank_r_req_valid": raw(vals, f"{prefix}_bank{read_bank}_r_req_valid") if read_bank is not None else None,
            "write_bank_r_req_valid": raw(vals, f"{prefix}_bank{write_bank}_r_req_valid") if write_bank is not None else None,
            "write_bank_w_req_valid": raw(vals, f"{prefix}_bank{write_bank}_w_req_valid") if write_bank is not None else None,
            "force_write": raw(vals, f"{prefix}_force_write"),
            "write_success": "1" if write_success else "0",
            "alloc_valid": raw(vals, f"{prefix}_alloc_valid"),
            "update0_valid": raw(vals, f"{prefix}_update0_valid"),
        }
        record("try_write", row)
        if read_bank is not None and read_bank == write_bank and raw(vals, f"{prefix}_bank{write_bank}_r_req_valid") == "1":
            record("samebank_read_write_try", row)
        if disabled:
            record("disabled_try_write", row)
            if read_bank is not None and read_bank == write_bank and raw(vals, f"{prefix}_bank{write_bank}_r_req_valid") == "1":
                record("disabled_samebank_read_write_try", row)
            if not write_success:
                record("disabled_blocked_write", row)
                if read_bank is not None and read_bank == write_bank and raw(vals, f"{prefix}_bank{write_bank}_r_req_valid") == "1":
                    record("disabled_samebank_blocked_write", row)
        if not write_success:
            record("blocked_write", row)


vals = {}
current_time = None
scalar_re = re.compile(r"^([01xzXZ])(.+)$")

with VCD.open(errors="replace") as f:
    for _ in range(HEADER_END):
        next(f)
    for line in f:
        s = line.strip()
        if not s:
            continue
        if s.startswith("#"):
            snapshot(current_time, vals)
            current_time = int(s[1:])
            if current_time > END_TIME + 20:
                break
            continue
        if s[0] in "bB":
            parts = s.split(" ", 1)
            if len(parts) == 2 and parts[1] in watch_codes:
                for key in code_to_keys[parts[1]]:
                    vals[sig[key][1]] = parts[0][1:]
        else:
            m = scalar_re.match(s)
            if m and m.group(2) in watch_codes:
                vals[m.group(2)] = m.group(1)

snapshot(current_time, vals)

print(json.dumps({
    "vcd": str(VCD),
    "time_window": [START_TIME, END_TIME],
    "signals_found": sorted(sig.keys()),
    "signal_count": len(sig),
    "counts": dict(sorted(counts.items())),
    "first": first,
    "events": events,
}, indent=2, sort_keys=True))
