#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build/emu}"

PREFIX="${PREFIX:-utage_train_then_disable}"
TRAIN_ITERS="${TRAIN_ITERS:-345}"
DISABLED_ITERS="${DISABLED_ITERS:-512}"
CYCLES="${CYCLES:-9500}"
WAVE_BEGIN="${WAVE_BEGIN:-8000}"
WAVE_END="${WAVE_END:-9500}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
WAVE="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
RUN_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.run.log"
SEC_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.utage_security.json"
WB_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.utage_writebuffer.json"

"$RISCV_GCC" \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr -mabi=lp64d \
  -DTRAIN_ITERS="$TRAIN_ITERS" \
  -DDISABLED_ITERS="$DISABLED_ITERS" \
  -T link_writebuffer.ld \
  -o "$ELF" \
  utage_train_then_disable.S
"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -dr "$ELF" > "$OBJDUMP"

"$EMU" \
  -i "$BIN" \
  --no-diff \
  -C "$CYCLES" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  --dump-wave \
  --wave-path="$WAVE" \
  > "$RUN_LOG" 2>&1

python3 ./analyze_utage_security_vcd.py \
  "$WAVE" \
  "$ELF" \
  "$WAVE_BEGIN" \
  "$WAVE_END" \
  > "$SEC_JSON"

python3 ./analyze_utage_writebuffer_vcd.py \
  "$WAVE" \
  "$WAVE_BEGIN" \
  "$WAVE_END" \
  > "$WB_JSON"

python3 - "$SEC_JSON" "$WB_JSON" <<'PY'
import json
import sys

security = json.load(open(sys.argv[1]))
writebuffer = json.load(open(sys.argv[2]))
print(json.dumps({
    "security_counts": security["counts"],
    "writebuffer_counts": writebuffer["counts"],
    "first_disabled_samebank_blocked_write": writebuffer["first"].get("disabled_samebank_blocked_write"),
    "first_disabled_utage_source": security["first"].get("disabled_prediction_uses_utage_source"),
}, indent=2, sort_keys=True))
PY
