#!/usr/bin/env python3
import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path


VCD = Path(sys.argv[1])
ELF = Path(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] != "-" else None
START_TIME = int(sys.argv[3]) if len(sys.argv) > 3 else 0
END_TIME = int(sys.argv[4]) if len(sys.argv) > 4 else 1 << 62


def value_to_int(raw):
    if raw is None or raw == "" or any(c in raw for c in "xzXZ"):
        return None
    return int(raw, 2)


def h(value):
    return None if value is None else hex(value)


def line_addr(addr, line_size=64):
    if addr is None:
        return None
    return addr & ~(line_size - 1)


def load_symbols(path):
    if path is None:
        return {}
    out = subprocess.check_output(
        ["/opt/riscv/bin/riscv64-unknown-elf-nm", "-n", str(path)],
        text=True,
    )
    syms = {}
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 3:
            syms[parts[2]] = int(parts[0], 16)
    if "secret_data" in syms and "probe_array" in syms:
        # Existing ABTB stale PoC stores byte value 7 in secret_data.
        syms["probe_secret_line"] = syms["probe_array"] + 7 * 64
    return syms


SYMS = load_symbols(ELF)
TARGETS = {
    name: SYMS[name]
    for name in [
        "branch_site",
        "fallthrough",
        "gadget",
        "train_data",
        "secret_data",
        "flag_zero",
        "probe_array",
        "probe_secret_line",
    ]
    if name in SYMS
}


def classes_for_addr(addr):
    if addr is None:
        return []
    aliases = {addr}
    if addr >= 0x40000000:
        aliases.add(addr + 0x40000000)
    if addr >= 0x80000000:
        aliases.add(addr - 0x40000000)
    out = []
    for name, target in TARGETS.items():
        if target in aliases or addr == target:
            out.append(name)
        elif line_addr(addr) == line_addr(target) or any(line_addr(a) == line_addr(target) for a in aliases):
            out.append(name + "_line")
    return sorted(set(out))


def pc_byte_addr(encoded_addr):
    if encoded_addr is None:
        return None
    return encoded_addr << 1


def parse_header(path):
    scopes = []
    name_to_code = {}
    header_end = 0
    with path.open(errors="replace") as f:
        for lineno, line in enumerate(f, 1):
            s = line.strip()
            if s.startswith("$scope"):
                parts = s.split()
                scopes.append(parts[2])
            elif s.startswith("$upscope"):
                if scopes:
                    scopes.pop()
            elif s.startswith("$var"):
                parts = s.split()
                code = parts[3]
                name = parts[4]
                name_to_code[".".join(scopes + [name])] = code
            elif s.startswith("$enddefinitions"):
                header_end = lineno
                break
    return header_end, name_to_code


HEADER_END, NAME_CODE = parse_header(VCD)


def find_code(suffix, required=True):
    matches = [(name, code) for name, code in NAME_CODE.items() if name.endswith(suffix)]
    if not matches:
        if required:
            raise KeyError(f"missing VCD signal suffix: {suffix}")
        return None
    # Prefer the inner_bpu/local signal when duplicate names exist.
    matches.sort(key=lambda x: (".inner_bpu." not in x[0], len(x[0])))
    return matches[0][1]


SIG = {}


def add(name, suffix, required=True):
    suffixes = suffix if isinstance(suffix, (list, tuple)) else [suffix]
    code = None
    for candidate in suffixes:
        code = find_code(candidate, False)
        if code is not None:
            break
    if code is None and required:
        raise KeyError(f"missing VCD signal suffix: {' or '.join(suffixes)}")
    if code is not None:
        SIG[name] = code


add("abtb_enable", ".core.frontend.io_csrCtrl_bp_ctrl_abtbEnable")
add("pred_ready", [
    ".core.frontend._inner_ftq_io_fromBpu_prediction_ready",
    ".core.frontend.inner_ftq.io_fromBpu_prediction_ready",
    ".core.frontend.inner_ftq.io_fromBpu_prediction_ready_0",
], False)
add("pred_valid", [
    ".core.frontend._inner_bpu_io_toFtq_prediction_valid",
    ".core.frontend.inner_bpu.io_toFtq_prediction_valid",
], False)
add("pred_start", [
    ".core.frontend._inner_bpu_io_toFtq_prediction_bits_startPc_addr",
    ".core.frontend.inner_bpu.io_toFtq_prediction_bits_startPc_addr",
], False)
add("pred_target", [
    ".core.frontend._inner_bpu_io_toFtq_prediction_bits_target_addr",
    ".core.frontend.inner_bpu.io_toFtq_prediction_bits_target_addr",
], False)
add("pred_s3_override", [
    ".core.frontend._inner_bpu_io_toFtq_prediction_bits_s3Override",
    ".core.frontend.inner_bpu.io_toFtq_prediction_bits_s3Override",
], False)
add("bp_s1_source", [
    ".core.frontend._inner_bpu_io_toFtq_perfMeta_bpSource_s1Source",
    ".core.frontend.inner_bpu.io_toFtq_perfMeta_bpSource_s1Source",
], False)
add("bp_s3_source", [
    ".core.frontend._inner_bpu_io_toFtq_perfMeta_bpSource_s3Source",
    ".core.frontend.inner_bpu.io_toFtq_perfMeta_bpSource_s3Source",
], False)
add("bp_s3_override", [
    ".core.frontend._inner_bpu_io_toFtq_perfMeta_bpSource_s3Override",
    ".core.frontend.inner_bpu.io_toFtq_perfMeta_bpSource_s3Override",
], False)
add("bpu_s2_valid", ".core.frontend.inner_bpu.s2_valid", False)
add("bpu_s2_start", ".core.frontend.inner_bpu.s2_startPc_addr", False)
add("abtb_s2_valid", ".core.frontend.inner_bpu.abtb.s2_valid", False)
add("abtb_s2_start", ".core.frontend.inner_bpu.abtb.s2_startPc_addr", False)
add("s1_abtb_valid", ".core.frontend.inner_bpu.s1_abtbValid", False)
add("s1_abtb_taken", ".core.frontend.inner_bpu.s1_abtbResult_taken", False)
add("debug_s1_abtb", ".core.frontend.inner_bpu.debug_s1UseAbtb", False)
add("debug_s1_abtb_utage", ".core.frontend.inner_bpu.debug_s1UseAbtbUtage", False)
add("dc_outer_ready", ".core.auto_memBlock_inner_dcache_client_out_a_ready", False)
add("dc_outer_valid", ".core.auto_memBlock_inner_dcache_client_out_a_valid", False)
add("dc_outer_addr", ".core.auto_memBlock_inner_dcache_client_out_a_bits_address", False)
add("dc_outer_vaddr", ".core.auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr", False)
add("dc_outer_opcode", ".core.auto_memBlock_inner_dcache_client_out_a_bits_opcode", False)

for idx in range(8):
    add(f"s1_abtb_taken_mask_{idx}", f".core.frontend.inner_bpu.s1_abtbTakenMask_{idx}", False)
    add(f"toftq_utage_valid_{idx}", [
        f".core.frontend._inner_bpu_io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_valid",
        f".core.frontend.inner_bpu.io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_valid",
    ], False)
    add(f"toftq_utage_hit_{idx}", [
        f".core.frontend._inner_bpu_io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_hit",
        f".core.frontend.inner_bpu.io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_hit",
    ], False)
    add(f"toftq_utage_pred_taken_{idx}", [
        f".core.frontend._inner_bpu_io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_predTaken",
        f".core.frontend.inner_bpu.io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_predTaken",
    ], False)
    add(f"toftq_utage_base_taken_{idx}", [
        f".core.frontend._inner_bpu_io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_baseTaken",
        f".core.frontend.inner_bpu.io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_baseTaken",
    ], False)
    add(f"toftq_utage_cfi_{idx}", [
        f".core.frontend._inner_bpu_io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_cfiPosition",
        f".core.frontend.inner_bpu.io_toFtq_meta_bits_resolveMeta_utage_abtbResult_{idx}_cfiPosition",
    ], False)
    add(f"ftq_train_utage_valid_{idx}", [
        f".core.frontend._inner_ftq_io_toBpu_train_bits_meta_utage_abtbResult_{idx}_valid",
        f".core.frontend.inner_ftq.io_toBpu_train_bits_meta_utage_abtbResult_{idx}_valid",
    ], False)
    add(f"ftq_train_utage_hit_{idx}", [
        f".core.frontend._inner_ftq_io_toBpu_train_bits_meta_utage_abtbResult_{idx}_hit",
        f".core.frontend.inner_ftq.io_toBpu_train_bits_meta_utage_abtbResult_{idx}_hit",
    ], False)
    add(f"ftq_train_utage_pred_taken_{idx}", [
        f".core.frontend._inner_ftq_io_toBpu_train_bits_meta_utage_abtbResult_{idx}_predTaken",
        f".core.frontend.inner_ftq.io_toBpu_train_bits_meta_utage_abtbResult_{idx}_predTaken",
    ], False)

for unit in range(3):
    prefix = f".core.memBlock._inner_LoadUnit_{unit}_io_lqWrite"
    add(f"lu{unit}_valid", prefix + "_valid", False)
    add(f"lu{unit}_pc", prefix + "_bits_uop_pc", False)
    add(f"lu{unit}_vaddr", prefix + "_bits_vaddr", False)
    add(f"lu{unit}_paddr", prefix + "_bits_paddr", False)


WATCH_CODES = set(SIG.values())
INV_SIG = {v: k for k, v in SIG.items()}


def raw(vals, name):
    code = SIG.get(name)
    if code is None:
        return None
    return vals.get(code)


def get(vals, name):
    return value_to_int(raw(vals, name))


def one(vals, name):
    return raw(vals, name) == "1"


def source_name(value, stage):
    if value is None:
        return None
    if stage == 1:
        return {
            0: "Ubtb",
            1: "Abtb",
            2: "UbtbUtage",
            3: "AbtbUtage",
            4: "Fallthrough",
        }.get(value, f"unknown_{value}")
    return {
        0: "Ras",
        1: "ITTage",
        2: "Sc",
        3: "Tage",
        4: "Mbtb",
        5: "Fallthrough",
    }.get(value, f"unknown_{value}")


counts = Counter()
first = {}
rows = {
    "disabled_predictions": [],
    "disabled_utage_source": [],
    "disabled_utage_meta_hit": [],
    "loadunit_secret": [],
    "dcache_probe": [],
}


def keep(bucket, row, limit=32):
    if len(rows[bucket]) < limit:
        rows[bucket].append(row)


def note(name, row):
    counts[name] += 1
    first.setdefault(name, row)


def utage_meta(vals, prefix):
    out = []
    for idx in range(8):
        valid = raw(vals, f"{prefix}_utage_valid_{idx}")
        hit = raw(vals, f"{prefix}_utage_hit_{idx}")
        pred = raw(vals, f"{prefix}_utage_pred_taken_{idx}")
        base = raw(vals, f"{prefix}_utage_base_taken_{idx}")
        cfi = get(vals, f"{prefix}_utage_cfi_{idx}")
        if any(x == "1" for x in [valid, hit, pred, base]):
            out.append({
                "idx": idx,
                "valid": valid,
                "hit": hit,
                "predTaken": pred,
                "baseTaken": base,
                "cfiPosition": cfi,
            })
    return out


def snapshot(t, vals):
    if t is None or t < START_TIME or t > END_TIME:
        return
    cycle = t // 2
    pred_ready = one(vals, "pred_ready") if "pred_ready" in SIG else True
    pred_fire = one(vals, "pred_valid") and pred_ready
    abtb_disabled = raw(vals, "abtb_enable") == "0"
    s1_source = get(vals, "bp_s1_source")
    s3_source = get(vals, "bp_s3_source")
    s1_source_name = source_name(s1_source, 1)
    s3_source_name = source_name(s3_source, 3)
    toftq_meta = utage_meta(vals, "toftq")
    ftq_train_meta = utage_meta(vals, "ftq_train")
    any_toftq_utage_hit = any(x.get("valid") == "1" and x.get("hit") == "1" for x in toftq_meta)
    any_ftq_train_utage_hit = any(x.get("valid") == "1" and x.get("hit") == "1" for x in ftq_train_meta)

    if pred_fire:
        row = {
            "t": t,
            "cycle": cycle,
            "abtb_enable": raw(vals, "abtb_enable"),
            "pred_start": h(get(vals, "pred_start")),
            "pred_start_byte": h(pc_byte_addr(get(vals, "pred_start"))),
            "pred_target": h(get(vals, "pred_target")),
            "pred_target_byte": h(pc_byte_addr(get(vals, "pred_target"))),
            "pred_s3_override": raw(vals, "pred_s3_override"),
            "bpu_s2_start_byte": h(pc_byte_addr(get(vals, "bpu_s2_start"))),
            "abtb_s2_valid": raw(vals, "abtb_s2_valid"),
            "abtb_s2_start_byte": h(pc_byte_addr(get(vals, "abtb_s2_start"))),
            "s1_abtb_valid": raw(vals, "s1_abtb_valid"),
            "s1_abtb_taken": raw(vals, "s1_abtb_taken"),
            "debug_s1UseAbtb": raw(vals, "debug_s1_abtb"),
            "debug_s1UseAbtbUtage": raw(vals, "debug_s1_abtb_utage"),
            "bp_s1_source": s1_source_name,
            "bp_s3_source": s3_source_name,
            "bp_s3_override": raw(vals, "bp_s3_override"),
            "toftq_utage_meta": toftq_meta,
            "ftq_train_utage_meta": ftq_train_meta,
        }
        note("prediction_fire", row)
        if s1_source_name in ("AbtbUtage", "UbtbUtage") or raw(vals, "debug_s1_abtb_utage") == "1":
            note("prediction_uses_utage_source", row)
            if abtb_disabled:
                note("disabled_prediction_uses_utage_source", row)
                keep("disabled_utage_source", row)
        if any_toftq_utage_hit or any_ftq_train_utage_hit:
            note("prediction_with_utage_meta_hit", row)
            if abtb_disabled:
                note("disabled_prediction_with_utage_meta_hit", row)
                keep("disabled_utage_meta_hit", row)
        if abtb_disabled:
            note("disabled_prediction_fire", row)
            keep("disabled_predictions", row)

    for unit in range(3):
        if one(vals, f"lu{unit}_valid"):
            pc = get(vals, f"lu{unit}_pc")
            paddr = get(vals, f"lu{unit}_paddr")
            vaddr = get(vals, f"lu{unit}_vaddr")
            cls = classes_for_addr(paddr) or classes_for_addr(vaddr)
            row = {
                "t": t,
                "cycle": cycle,
                "unit": unit,
                "pc": h(pc),
                "paddr": h(paddr),
                "vaddr": h(vaddr),
                "class": cls,
                "abtb_enable": raw(vals, "abtb_enable"),
                "bp_s1_source": s1_source_name,
                "bp_s3_source": s3_source_name,
                "toftq_utage_meta": toftq_meta,
            }
            if "secret_data" in cls:
                note("loadunit_secret_data", row)
                keep("loadunit_secret", row)
            if "probe_secret_line" in cls:
                note("loadunit_probe_secret_line", row)
                keep("loadunit_secret", row)

    if one(vals, "dc_outer_valid") and one(vals, "dc_outer_ready"):
        addr = get(vals, "dc_outer_addr")
        vaddr = get(vals, "dc_outer_vaddr")
        cls = classes_for_addr(addr) or classes_for_addr(vaddr)
        row = {
            "t": t,
            "cycle": cycle,
            "addr": h(addr),
            "vaddr": h(vaddr),
            "opcode": get(vals, "dc_outer_opcode"),
            "class": cls,
            "abtb_enable": raw(vals, "abtb_enable"),
            "bp_s1_source": s1_source_name,
            "bp_s3_source": s3_source_name,
            "toftq_utage_meta": toftq_meta,
        }
        if "probe_secret_line" in cls:
            note("dcache_outer_probe_secret_line", row)
            keep("dcache_probe", row)


vals = {}
current_time = None
scalar_re = re.compile(r"^([01xzXZ])(.+)$")

with VCD.open(errors="replace") as f:
    for _ in range(HEADER_END):
        next(f)
    for line in f:
        s = line.strip()
        if not s:
            continue
        if s.startswith("#"):
            snapshot(current_time, vals)
            current_time = int(s[1:])
            if current_time > END_TIME + 20:
                break
            continue
        if s[0] in "bB":
            parts = s.split(" ", 1)
            if len(parts) == 2 and parts[1] in WATCH_CODES:
                vals[parts[1]] = parts[0][1:]
        else:
            m = scalar_re.match(s)
            if m and m.group(2) in WATCH_CODES:
                vals[m.group(2)] = m.group(1)

snapshot(current_time, vals)

summary = {
    "vcd": str(VCD),
    "elf": str(ELF) if ELF else None,
    "time_window": [START_TIME, END_TIME],
    "targets": {k: h(v) for k, v in TARGETS.items()},
    "signals_found": sorted(SIG.keys()),
    "counts": dict(sorted(counts.items())),
    "first": first,
    "rows": rows,
    "interpretation": {
        "stage1_source_enum": {
            "0": "Ubtb",
            "1": "Abtb",
            "2": "UbtbUtage",
            "3": "AbtbUtage",
            "4": "Fallthrough",
        },
        "evidence_limit": "uTage internal bank rckEn is only available if the VCD includes MicroTageTable internals; this parser uses BPU/FTQ exposed uTage source and meta when internals are absent.",
    },
}

print(json.dumps(summary, indent=2, sort_keys=True))
