#include <klib.h>

volatile unsigned long observed_stopi;
volatile unsigned long observed_iid;
volatile unsigned long observed_iprio;
volatile unsigned long poc_result = 2;
volatile unsigned long return_to_mmode;
volatile unsigned long trap_mcause;
volatile unsigned long trap_mepc;

extern void m_trap_entry(void);
extern void s_mode_check(void);

#define BIT(n) (1UL << (n))

#define CSR_MSTATUS   0x300
#define CSR_MIDELEG   0x303
#define CSR_MIE       0x304
#define CSR_MTVEC     0x305
#define CSR_MVIP      0x309
#define CSR_MSTATEEN0 0x30c
#define CSR_MEPC      0x341
#define CSR_MCAUSE    0x342
#define CSR_SSTATUS   0x100
#define CSR_SIE       0x104
#define CSR_SIP       0x144
#define CSR_SISELECT  0x150
#define CSR_SIREG     0x151
#define CSR_STOPEI    0x15c
#define CSR_STOPI     0xdb0

#define SSIP BIT(1)
#define SEIP BIT(9)
#define MSTATUS_MPP_MASK (3UL << 11)
#define MSTATUS_MPP_S    (1UL << 11)
#define MSTATUS_MIE      BIT(3)
#define MSTATUS_SIE      BIT(1)
#define MSTATEEN0_AIA    BIT(59)
#define MSTATEEN0_IMSIC  BIT(58)
#define MSTATEEN0_CSRIND BIT(60)

static inline unsigned long read_csr_num(unsigned long csr)
{
    unsigned long value = 0;
    switch (csr) {
    case CSR_MSTATUS: asm volatile("csrr %0, 0x300" : "=r"(value)); break;
    case CSR_MCAUSE:  asm volatile("csrr %0, 0x342" : "=r"(value)); break;
    case CSR_SSTATUS: asm volatile("csrr %0, 0x100" : "=r"(value)); break;
    case CSR_SIE:     asm volatile("csrr %0, 0x104" : "=r"(value)); break;
    case CSR_SIP:     asm volatile("csrr %0, 0x144" : "=r"(value)); break;
    case CSR_STOPI:   asm volatile("csrr %0, 0xdb0" : "=r"(value)); break;
    default: break;
    }
    return value;
}

static void setup_pmp(void)
{
    asm volatile(
        "li   t0, -1\n\t"
        "csrw pmpaddr0, t0\n\t"
        "li   t0, 0x1f\n\t"
        "csrw pmpcfg0, t0\n\t"
        ::: "t0", "memory"
    );
}

static void run_poc(void)
{
    unsigned long mstatus;
    unsigned long stateen = MSTATEEN0_AIA | MSTATEEN0_IMSIC | MSTATEEN0_CSRIND;

    setup_pmp();
    asm volatile("csrw 0x305, %0" :: "r"((unsigned long)m_trap_entry) : "memory");
    asm volatile("csrci 0x300, 0x8" ::: "memory");
    asm volatile("csrw 0x303, %0" :: "r"(SEIP | SSIP) : "memory");
    asm volatile("csrw 0x308, zero" ::: "memory");
    asm volatile("csrs 0x30c, %0" :: "r"(stateen) : "memory");
    asm volatile("csrw 0x15c, zero" ::: "memory");

    asm volatile("csrw 0x150, %0" :: "r"(0x30UL) : "memory");
    asm volatile("csrw 0x151, %0" :: "r"(5UL << 8) : "memory");
    asm volatile("csrw 0x104, %0" :: "r"(SEIP | SSIP) : "memory");
    asm volatile("csrs 0x144, %0" :: "r"(SSIP) : "memory");
    asm volatile("csrs 0x309, %0" :: "r"(SEIP) : "memory");

    asm volatile("csrr %0, 0x300" : "=r"(mstatus));
    mstatus &= ~MSTATUS_MPP_MASK;
    mstatus |= MSTATUS_MPP_S;
    mstatus &= ~MSTATUS_MIE;
    mstatus &= ~MSTATUS_SIE;
    asm volatile("csrw 0x300, %0" :: "r"(mstatus) : "memory");
    asm volatile("csrw 0x341, %0" :: "r"((unsigned long)s_mode_check) : "memory");
    asm volatile("la %0, 1f" : "=r"(return_to_mmode));
    asm volatile("mret\n1:" ::: "memory");
}

int main(void)
{
    run_poc();

    unsigned long sip = read_csr_num(CSR_SIP);
    unsigned long sie = read_csr_num(CSR_SIE);
    unsigned long stopi = observed_stopi;
    unsigned long iid = observed_iid;
    unsigned long iprio = observed_iprio;

    printf("[*] observed sip=0x%lx sie=0x%lx\n", sip, sie);
    printf("[*] observed stopi=0x%lx iid=%lu iprio=%lu\n", stopi, iid, iprio);
    printf("[*] spec expects iid=1 iprio=5 when SSI(prio=5) competes with software-only SEI(prio=256)\n");

    if (poc_result == 1) {
        printf("=== BUG CONFIRMED? ===\n");
        return 0;
    }

    if (poc_result == 0) {
        printf("=== PASS ===\n");
        return 0;
    }

    printf("=== UNEXPECTED: S-mode checker did not complete??? mcause=0x%lx mepc=0x%lx ===\n", trap_mcause, trap_mepc);
    return 2;
}
