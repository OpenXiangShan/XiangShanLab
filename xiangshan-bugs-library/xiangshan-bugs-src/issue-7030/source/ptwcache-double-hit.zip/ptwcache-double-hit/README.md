# PtwCache l0 + sp double hit: reproduction

## Files

| File | Content |
|---|---|
| `repro.S` | Test program. Bare metal, loaded at 0x80000000. M-mode builds an Sv39 page table, S-mode runs the test. The header comment describes the layout. |
| `repro_st.bin` | `repro.S`, no defines. ld page 0, ld page 8, sd MARK0 to page 0, sd MARK3 to page 3, then reads the candidate physical pages. |
| `repro_ld.bin` | `repro.S -DVAR_LD`. sd page 0, sd page 8 (store DTLB), then ld page 0 and ld page 3 (load DTLB). |
| `control.bin` | `repro.S -DCTL_NOSP`. `repro_st.bin` without the page-8 load. |
| `build.sh` | Rebuilds the three images and checks `SHA256SUMS`. Needs `clang-19`, `riscv64-linux-gnu-ld` and `llvm-objcopy-19` (override with `CLANG`, `RVLD`, `OBJCOPY`). |

Region (VA 0x80600000-0x8060ffff): page 0 -> `P` = 0x80315000 (ordinary 4 KiB leaf); pages 1-15 -> `Q` = 0x80300000 (NAPOT leaves, N = 1, PPN 0x80308).

## Run

```bash
./build/emu -i repro_st.bin --no-diff -C 200000
./build/emu -i repro_ld.bin --no-diff -C 200000
./build/emu -i control.bin  --no-diff -C 200000
```

With the default emu, `repro_st.bin` and `repro_ld.bin` stop on the PtwCache assertion `normal page and super page both hit`. To see where the accesses go, build the emu with `STOP_COND=0` added to the `make emu` variables; the assertion is then printed and the run continues.

## Reading the result

The program ends with `li a0, CODE` and the trap instruction (`.insn r 0x6b, 0, 0, x0, a0, x0`). The v2 emu prints code 0 as `HIT GOOD TRAP`, 2 as `ABORT`, 3 as `EXCEEDING CYCLE/INSTR LIMIT` and other codes as `HIT BAD TRAP`. Read the code from the trap PC.

CODE = 10 * c0 + c3:
- c0 (page 0): 0 = `P`, 1 = `Q`, 2 = 0x80310000, 3 = none of these.
- c3 (page 3): 1 = `Q` + 0x3000, 2 = 0x80313000, 3 = none of these.
- 91 / 92: a warm-up load returned a wrong value. 98: unexpected trap. 99: no code matched.

Correct results are 1 or 11.

| CODE | trap PC in `repro_st.bin` | trap PC in `repro_ld.bin` | trap PC in `control.bin` |
|---|---|---|---|
| 1 | 0x800003c4 | 0x80000328 | 0x80000394 |
| 11 | 0x80000400 | 0x80000364 | 0x800003d0 |
| 22 | 0x80000450 | 0x800003b4 | 0x80000420 |

Other codes: run `riscv64-linux-gnu-objdump -D -b binary -m riscv:rv64 --adjust-vma=0x80000000 <image>` and read the `li a0` just before the trap PC.
