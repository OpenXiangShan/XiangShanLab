#!/bin/sh
# Rebuild the images from repro.S and check them against SHA256SUMS.
# Tools: clang-19, GNU ld for RISC-V, llvm-objcopy-19 (override with CLANG, RVLD, OBJCOPY).
set -e
cd "$(dirname "$0")"
CLANG=${CLANG:-clang-19}
RVLD=${RVLD:-riscv64-linux-gnu-ld}
OBJCOPY=${OBJCOPY:-llvm-objcopy-19}
img() {  # img NAME [-D...]
  out=$1; shift
  $CLANG --target=riscv64-unknown-elf -march=rv64gc -mabi=lp64d -mno-relax "$@" -c repro.S -o "$out.o"
  $RVLD -m elf64lriscv -Ttext=0x80000000 -e _start --no-relax -o "$out.elf" "$out.o"
  $OBJCOPY -O binary --only-section=.text "$out.elf" "$out.bin"
  rm -f "$out.o" "$out.elf"
}
img repro_st
img repro_ld -DVAR_LD
img control  -DCTL_NOSP
sha256sum -c SHA256SUMS
