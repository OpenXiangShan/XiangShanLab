// PtwCache l0 + sp double hit (kunminghu-v2).
// When the l0 page cache and the superpage cache (sp) both hit, the PtwCache response takes ppn/perm/v from l0 and
// n from sp. The L1 TLB then builds a 64 KiB entry with PPN = l0.ppn[high:4] ++ vpn[3:0]. PtwCache also has
// XSError("normal page and super page both hit") for this case.
// The page table holds an inconsistent Svnapot region: page 0 has its own 4 KiB leaf, pages 1..15 are NAPOT leaves.
// The Svnapot chapter allows this; one of the translations is to be used, never a mix.
//
// Memory map (Sv39, built in M-mode; S-mode runs the test):
//   VA 0x8000_0000..0x805F_FFFF -> identity, 2 MiB leaves (code, page tables, physical check window)
//   VA 0x8060_0000..            -> PT_L0 (4 KiB level):  page 0 = ordinary leaf -> P = 0x8031_5000 (PPN[3:0] = 5)
//                                                         pages 1..15 = NAPOT leaves (N=1, PPN 0x80308) -> Q = 0x8030_0000
//   -DCTL_CONS: page 0 is a NAPOT leaf too (consistent region)
// Sequences (S-mode, fence rw,rw between steps so each translation finishes before the next access issues):
//   default (ST): ld page 0 (load DTLB; walk -> l0 line, NAPOT siblings excluded from the sector)
//                 ld page 8 (walk -> NAPOT leaf -> sp)          [-DCTL_NOSP: skipped]
//                 sd MARK0 -> page 0 (store DTLB miss -> page cache: l0 hit + sp hit)
//                 sd MARK3 -> page 3
//                 then read the candidate physical pages through the identity map and report where the marks landed
//   -DVAR_LD:     sd (same sentinel) -> page 0, sd (same sentinel) -> page 8 through the store DTLB,
//                 then ld page 0 and ld page 3 through the load DTLB and classify the values read
// Every physical page involved holds a sentinel SENT|pa at offset 0 (written in M-mode, bare).
// Exit: a0 = code, then the custom trap instruction (.insn r 0x6b, rs1 = a0). The v2 emu prints code 0 as
// HIT GOOD TRAP, 2 as ABORT, 3 as EXCEEDING CYCLE/INSTR LIMIT and other codes as HIT BAD TRAP: identify the code
// by the trap PC (README.md).
//   a0 = 10*c0 + c3   c0: page 0 went to P -> 0, Q+0 -> 1, P[..:4]++0 = 0x8031_0000 -> 2, none of these -> 3
//                     c3: page 3 went to Q+3 -> 1, 0x8031_3000 (mixed) -> 2, none -> 3
//   91 / 92 sanity check of the warm-up loads failed, 98 unexpected trap (mcause in t0), 99 dispatch fell through
// Correct results: default and -DVAR_LD -> 1 or 11 (page 0 at P or Q+0, page 3 at Q+3); CTL_CONS -> 11; CTL_NOSP -> 1.

#define CSR_SPFCTL     0x5c1
#define PT_ROOT        0x80010000
#define PT_L1          0x80011000
#define PT_L0          0x80012000
#define VREG           0x80600000
#define Q_PA           0x80300000
#define P_PA           0x80315000
#define M_PA           0x80310000
#define NAPOT_PPN      0x80308
#define SENT           0x5a5a000000000000
#define MARK0          0x1111000011110000
#define MARK3          0x3333000033330000
#define LEAF_FLAGS     0xc7                    // D A W R V
#define NAPOT_PTE      ((1 << 63) | (NAPOT_PPN << 10) | LEAF_FLAGS)

.macro EXIT code
  li a0, \code
  .insn r 0x6b, 0, 0, x0, a0, x0
1:
  j 1b
.endm

.macro PUTSENT pa                              // M-mode, bare: *pa = SENT | pa
  li t0, \pa
  li t1, SENT | \pa
  sd t1, 0(t0)
.endm

// EQSET val, imm, out, code: if register \val == imm then \out = code
.macro EQSET val, imm, out, code
  li t0, \imm
  bne \val, t0, 8f
  li \out, \code
8:
.endm

  .section .text.init
  .option norvc
  .globl _start
_start:
  la t0, m_trap
  csrw mtvec, t0
  li t0, -1
  csrw pmpaddr0, t0
  li t0, 0x1f                                  // NAPOT RWX over everything
  csrw pmpcfg0, t0
  csrwi CSR_SPFCTL, 0                          // L1 prefetchers off
  li t0, PT_ROOT                               // zero PT_ROOT, PT_L1, PT_L0 (3 x 512 entries)
  li t1, 1536
0:
  sd zero, 0(t0)
  addi t0, t0, 8
  addi t1, t1, -1
  bnez t1, 0b
  li s0, PT_ROOT
  li t1, ((PT_L1 >> 12) << 10) | 0x01          // VA 0x8000_0000..0xBFFF_FFFF -> PT_L1
  sd t1, 16(s0)
  li t0, PT_L1                                 // 2 MiB identity leaves 0..2: D A X W R V
  li t1, ((0x80000000 >> 12) << 10) | 0xcf
  sd t1, 0(t0)
  li t1, ((0x80200000 >> 12) << 10) | 0xcf
  sd t1, 8(t0)
  li t1, ((0x80400000 >> 12) << 10) | 0xcf
  sd t1, 16(t0)
  li t1, ((PT_L0 >> 12) << 10) | 0x01          // 2 MiB slot 3 (VA 0x8060_0000) -> PT_L0
  sd t1, 24(t0)
  li t0, PT_L0
#ifdef CTL_CONS
  li t1, NAPOT_PTE
#else
  li t1, ((P_PA >> 12) << 10) | LEAF_FLAGS     // page 0: ordinary 4 KiB leaf -> P
#endif
  sd t1, 0(t0)
  li t1, NAPOT_PTE                             // pages 1..15: NAPOT leaves -> Q
  li t2, 15
1:
  addi t0, t0, 8
  sd t1, 0(t0)
  addi t2, t2, -1
  bnez t2, 1b
  PUTSENT P_PA
  PUTSENT Q_PA
  PUTSENT (Q_PA + 0x3000)
  PUTSENT (Q_PA + 0x8000)
  PUTSENT M_PA
  PUTSENT (M_PA + 0x3000)
  fence rw, rw
  srli t0, s0, 12
  li t1, 8
  slli t1, t1, 60                              // Sv39
  or t0, t0, t1
  csrw satp, t0
  sfence.vma
  li t0, 0x1800
  csrc mstatus, t0
  li t0, 0x0800                                // MPP = S
  csrs mstatus, t0
  la t0, s_entry
  csrw mepc, t0
  mret

  .balign 64
s_entry:
  li s1, VREG
  li s2, VREG + 0x3000
  li s3, VREG + 0x8000
  li s5, 3                                     // c0
  li s6, 3                                     // c3
#ifdef VAR_LD
  li t0, SENT | P_PA                           // warm the store DTLB / page cache, memory unchanged
  sd t0, 0(s1)
  fence rw, rw
#ifndef CTL_NOSP
  li t0, SENT | (Q_PA + 0x8000)
  sd t0, 0(s3)
  fence rw, rw
#endif
  ld a1, 0(s1)                                 // page 0 through the load DTLB
  fence rw, rw
  ld a2, 0(s2)                                 // page 3
  fence rw, rw
  EQSET a1, SENT | P_PA, s5, 0
  EQSET a1, SENT | Q_PA, s5, 1
  EQSET a1, SENT | M_PA, s5, 2
  EQSET a2, SENT | (Q_PA + 0x3000), s6, 1
  EQSET a2, SENT | (M_PA + 0x3000), s6, 2
#else
  ld a1, 0(s1)                                 // page 0 through the load DTLB
  fence rw, rw
#ifdef CTL_CONS
  li t0, SENT | Q_PA
#else
  li t0, SENT | P_PA
#endif
  beq a1, t0, 2f
  EXIT 91
2:
#ifndef CTL_NOSP
  ld a2, 0(s3)                                 // page 8 -> NAPOT leaf into sp
  fence rw, rw
  li t0, SENT | (Q_PA + 0x8000)
  beq a2, t0, 3f
  EXIT 92
3:
#endif
  li t0, MARK0
  sd t0, 0(s1)                                 // page 0 through the store DTLB
  fence rw, rw
  li t0, MARK3
  sd t0, 0(s2)                                 // page 3
  fence rw, rw
  li t1, P_PA                                  // where did the marks land (identity map, 2 MiB leaf 1)
  ld t2, 0(t1)
  EQSET t2, MARK0, s5, 0
  li t1, Q_PA
  ld t2, 0(t1)
  EQSET t2, MARK0, s5, 1
  li t1, M_PA
  ld t2, 0(t1)
  EQSET t2, MARK0, s5, 2
  li t1, Q_PA + 0x3000
  ld t2, 0(t1)
  EQSET t2, MARK3, s6, 1
  li t1, M_PA + 0x3000
  ld t2, 0(t1)
  EQSET t2, MARK3, s6, 2
#endif
  li t0, 10
  mul t1, s5, t0
  add t1, t1, s6
  .irp code, 1, 2, 3, 11, 12, 13, 21, 22, 23, 31, 32, 33
  li t0, \code
  bne t1, t0, 9f
  EXIT \code
9:
  .endr
  EXIT 99

  .balign 64
m_trap:                                        // any trap: S-mode faults are not delegated
  csrr t0, mcause
  csrr t1, mepc
  csrr t2, mtval
  EXIT 98
