// Reproducer: a store-class uop that never issues (exception at decode) flushes itself while the StoreQueue's
// vecExceptionFlag is set; its SQ entry is not cancelled and the next fence never completes.
// kunminghu-v2, KunminghuV2Config.  Flat binary loaded at 0x80000000, no paging.  Build (LLVM):
//   clang --target=riscv64-unknown-elf -march=rv64gcv -mabi=lp64d -mno-relax [-D...] -c repro.S -o x.o
//   llvm-objcopy -O binary --only-section=.text.init x.o x.bin
//   default = tgt; -DCTL_FSON = control (FS on, the fsd executes).  Other variants: -DNOPS=16, -DV_BP (execute
//   breakpoint on an sd instead of the fsd), -DCTL_EXC, -DCTL_NOVEC, "-DK=2 -DVL=4 -DLMUL=m1".
//
// Flow:
//   M: PMP0 = 4 KiB at R_REGION read-only for S, PMP1 = the rest RWX; delegate store access fault (cause 7) to S;
//      warm the S trap handler into the I-cache; FS = Off; mret to S.
//   S: vsse32.v (vl 32, stride 64 B).  Elements 0..15 write 16 untouched lines (fills the 16-entry sbuffer), element 16
//      hits R_REGION -> store access fault.  The StoreQueue sets vecExceptionFlag; V's remaining flows wait for the
//      sbuffer.
//   S trap handler (stvec): first instruction fsd with FS = Off -> illegal instruction at decode.  The uop gets an SQ
//      entry but is never issued, and it flushes itself while vecExceptionFlag is still set.
//   M trap: check mcause/mepc, then `fence rw, rw`; on correct hardware the program then checks the S trap and the
//      stored elements and exits with the trap instruction, a0 = 0 (GOOD TRAP).  Every exit has its own label:
//   exit_ok 0 | exit_bad_cause 1 | exit_bad_strap 2 | exit_elem_missing 3 | exit_trig_store_visible 4 |
//   exit_trig_rejected 5 | exit_first_no_trap 6 | exit_no_fault 7 (from S-mode)

#ifndef K
#define K 16
#endif
#ifndef VL
#define VL 32
#endif
#ifndef LMUL
#define LMUL m8
#endif
#ifndef NOPS
#define NOPS 0
#endif
#define R_REGION   0x80300000
#define VBASE      (R_REGION - K * 64)
#define SCRATCH    0x80040000
#define TRIG_DATA  0x80050000
#define TRIG_INIT  0x1111222233334444
#define PATTERN    0x5A000000

.macro EXIT code
  li a0, \code
  .insn r 0x6b, 0, 0, x0, a0, x0
.endm

  .section .text.init
  .option norvc
  .globl _start
_start:
  lla t0, m_trap
  csrw mtvec, t0
  lla t0, s_trap
  csrw stvec, t0
  li t0, (R_REGION >> 2) | 0x1ff       // NAPOT 4 KiB
  csrw pmpaddr0, t0
  li t0, -1
  csrw pmpaddr1, t0
  li t0, 0x1f19                         // entry 0: NAPOT R; entry 1: NAPOT RWX
  csrw pmpcfg0, t0
  li t0, 1 << 7                         // delegate store/AMO access fault only
  csrw medeleg, t0
  csrw mideleg, zero
  li t0, (1 << 13) | (1 << 9)           // FS = Initial, VS = Initial
  csrs mstatus, t0
  li sp, SCRATCH
  li t6, SCRATCH + 64
  li t5, 0x7777
  // warm-up: run the S trap handler once in M-mode so that it is in the I-cache when V traps
  li s11, 1
  jal ra, s_trap
  li s11, 0
#ifdef CTL_EXC
  li t0, TRIG_DATA
  li t1, TRIG_INIT
  sd t1, 0(t0)
#endif
  fence rw, rw
#if defined(V_BP) || defined(CTL_EXC)
  csrw tselect, zero
#ifdef V_BP
  lla t0, s_first
  li t2, (6 << 60) | (1 << 4) | (1 << 2) // mcontrol6: S, execute; action 0 = breakpoint exception; match ==
#else
  li t0, TRIG_DATA
  li t2, (6 << 60) | (1 << 4) | (1 << 1) // mcontrol6: S, store
#endif
  csrw tdata2, t0
  csrw tdata1, t2
  csrr t1, tdata1
  srli t3, t1, 60
  li t4, 6
  bne t3, t4, exit_trig_rejected
  andi t3, t1, 0x1f
  andi t4, t2, 0x1f
  bne t3, t4, exit_trig_rejected
#endif
#ifndef CTL_FSON
  li t0, 3 << 13
  csrc mstatus, t0                      // FS = Off: fsd is illegal at decode
#endif
  li t0, 3 << 11
  csrc mstatus, t0
  li t0, 1 << 11                        // MPP = S
  csrs mstatus, t0
  lla t0, s_entry
  csrw mepc, t0
  mret

  .align 6
s_entry:
#ifdef CTL_EXC
  li t6, TRIG_DATA
#endif
#ifndef CTL_NOVEC
  li a2, VL
  vsetvli t0, a2, e32, LMUL, ta, ma
  vid.v v8
  li t2, PATTERN
  vadd.vx v8, v8, t2
#endif
  li a0, VBASE
  li t1, 64
  fence rw, rw                          // start with an empty sbuffer
#ifdef CTL_NOVEC
  li t2, PATTERN
  .rept K
  sw t2, 0(a0)
  addi a0, a0, 64
  addi t2, t2, 1
  .endr
v_insn:
  sw t2, 0(a0)                          // a0 = R_REGION: scalar store access fault (no vecExceptionFlag)
#else
v_insn:
  vsse32.v v8, (a0), t1                 // element K is at R_REGION: store access fault at element K
#endif
exit_no_fault:
  EXIT 7

  .align 6
s_trap:
  .rept NOPS
  nop
  .endr
s_first:
#if defined(V_BP) || defined(CTL_EXC)
  sd t5, 0(t6)
#else
  fsd f0, 0(sp)
#endif
s_after:
  bnez s11, s_ret                       // warm-up call from M-mode
s_ecall:
  ecall                                 // reached in S-mode only if s_first did not trap
s_ret:
  ret

  .align 6
m_trap:
  csrr s6, mcause
  csrr s7, mepc
#if defined(V_BP) || defined(CTL_EXC)
  csrw tdata1, zero
#endif
#ifdef CTL_FSON
  li t1, 9
  lla t0, s_ecall
#else
  lla t0, s_ecall                       // cause 9 at s_ecall: s_first did not trap
  bne s7, t0, 1f
  li t1, 9
  beq s6, t1, exit_first_no_trap
1:
  lla t0, s_first
#if defined(V_BP) || defined(CTL_EXC)
  li t1, 3
#else
  li t1, 2
#endif
#endif
  bne s6, t1, exit_bad_cause
  bne s7, t0, exit_bad_cause
finish:
  fence rw, rw                          // never completes while the uncancelled entry blocks the SQ
  csrr t0, scause
  li t1, 7
  bne t0, t1, exit_bad_strap
  csrr t0, stval
  srli t0, t0, 12
  li t1, R_REGION >> 12
  bne t0, t1, exit_bad_strap
  csrr t0, sepc
  lla t1, v_insn
  bne t0, t1, exit_bad_strap
  li a0, VBASE
  li t2, PATTERN
  li t3, K
2:
  lwu t4, 0(a0)
  bne t4, t2, exit_elem_missing
  addi a0, a0, 64
  addi t2, t2, 1
  addi t3, t3, -1
  bnez t3, 2b
#ifdef CTL_EXC
  li a0, TRIG_DATA
  ld t4, 0(a0)
  li t2, TRIG_INIT
  bne t4, t2, exit_trig_store_visible
#endif
exit_ok:
  EXIT 0
exit_bad_cause:
  EXIT 1
exit_bad_strap:
  EXIT 2
exit_elem_missing:
  EXIT 3
exit_trig_store_visible:
  EXIT 4
exit_trig_rejected:
  EXIT 5
exit_first_no_trap:
  EXIT 6
