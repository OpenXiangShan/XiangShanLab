# StoreQueue: `needCancel` misses the flush-itself case while `vecExceptionFlag` is set

kunminghu-v2 (tested on f7e05ec27c), KunminghuV2Config, single core. Flat binaries, loaded at 0x80000000.

| File | Content |
|---|---|
| `repro.S` | Source of both images (comments at the top describe the flow) |
| `repro.bin` | Vector store faults; the first instruction of the S trap handler is `fsd` with FS = Off; then `fence` |
| `control.bin` | Same program with FS on (`-DCTL_FSON`): the `fsd` executes |
| `build.sh` | Rebuilds both images with LLVM and checks them against `SHA256SUMS` |

Run:

```bash
./build/emu -i repro.bin   --no-diff -C 60000   # EXCEEDING CYCLE/INSTR LIMIT, instrCnt = 72 (hangs at the fence)
./build/emu -i control.bin --no-diff -C 60000   # HIT GOOD TRAP after 4882 cycles
```

On correct hardware both images end with HIT GOOD TRAP.
