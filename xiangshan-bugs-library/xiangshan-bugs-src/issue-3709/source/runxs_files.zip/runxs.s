.text
   .global _start
 _start:
    li t1, 0x00006000
    or t0, t0, t1
    csrw mstatus, t0
    csrr t0, mstatus
    csrr t3, fflags

    fcvt.d.w fs0, zero
    fcvt.d.w ft6, zero
    addi x1, x0, 0x400
    slli x1, x1, 4
    mv t1, x1
    csrr t0, mstatus
    # this instr changed mstatus
    csrc mstatus, x1
    nop
    nop
    csrr t1, mstatus
    # 
    li t4, 0x00006000
    addi t4, t4, 0x00000001
    # this instr may have a bug
    fle.d x23, fs0, ft6

    nop
    nop
    csrr t2, mstatus

  end:
    j end

