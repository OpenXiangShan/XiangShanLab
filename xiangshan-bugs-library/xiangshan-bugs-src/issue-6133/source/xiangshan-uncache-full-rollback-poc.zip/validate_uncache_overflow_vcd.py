#!/usr/bin/env python3
import json
import re
import sys
from collections import deque


UNCACHE_SCOPE_SUFFIX = (
    "TOP.SimTop.cpu.l_soc.core_with_l2.core.memBlock.inner_lsq."
    "loadQueue.uncacheBuffer"
)

NEEDED_REFS = {
    "clock": "clock",
    "req0_valid": "io_req_0_valid",
    "req0_ftq": "io_req_0_bits_uop_ftqPtr_value",
    "req0_offset": "io_req_0_bits_uop_ftqOffset",
    "req0_is_rvc": "io_req_0_bits_uop_isRVC",
    "req0_rob": "io_req_0_bits_uop_robIdx_value",
    "req0_vaddr": "io_req_0_bits_vaddr",
    "req0_paddr": "io_req_0_bits_paddr",
    "req0_nc": "io_req_0_bits_nc",
    "req0_mmio": "io_req_0_bits_mmio",
    "req0_mem_mm": "io_req_0_bits_memBackTypeMM",
    "req1_valid": "io_req_1_valid",
    "req1_ftq": "io_req_1_bits_uop_ftqPtr_value",
    "req1_offset": "io_req_1_bits_uop_ftqOffset",
    "req1_is_rvc": "io_req_1_bits_uop_isRVC",
    "req1_rob": "io_req_1_bits_uop_robIdx_value",
    "req1_vaddr": "io_req_1_bits_vaddr",
    "req1_paddr": "io_req_1_bits_paddr",
    "req1_nc": "io_req_1_bits_nc",
    "req1_mmio": "io_req_1_bits_mmio",
    "req1_mem_mm": "io_req_1_bits_memBackTypeMM",
    "req2_valid": "io_req_2_valid",
    "req2_ftq": "io_req_2_bits_uop_ftqPtr_value",
    "req2_offset": "io_req_2_bits_uop_ftqOffset",
    "req2_is_rvc": "io_req_2_bits_uop_isRVC",
    "req2_rob": "io_req_2_bits_uop_robIdx_value",
    "req2_vaddr": "io_req_2_bits_vaddr",
    "req2_paddr": "io_req_2_bits_paddr",
    "req2_nc": "io_req_2_bits_nc",
    "req2_mmio": "io_req_2_bits_mmio",
    "req2_mem_mm": "io_req_2_bits_memBackTypeMM",
    "freelist_valid_count": "_freeList_io_validCount",
    "freelist_empty": "_freeList_io_empty",
    "freelist_can0": "_freeList_io_canAllocate_0",
    "freelist_can1": "_freeList_io_canAllocate_1",
    "freelist_can2": "_freeList_io_canAllocate_2",
    "uncache_ready": "io_uncache_req_ready",
    "uncache_valid": "io_uncache_req_valid",
    "uncache_rob": "io_uncache_req_bits_robIdx_value",
    "uncache_addr": "io_uncache_req_bits_addr",
    "uncache_vaddr": "io_uncache_req_bits_vaddr",
    "uncache_id": "io_uncache_req_bits_id",
    "uncache_nc": "io_uncache_req_bits_nc",
    "uncache_mem_mm": "io_uncache_req_bits_memBackTypeMM",
    "rollback_valid": "io_rollback_valid",
    "rollback_ftq": "io_rollback_bits_ftqIdx_value",
    "rollback_offset": "io_rollback_bits_ftqOffset",
    "rollback_is_rvc": "io_rollback_bits_isRVC",
    "rollback_level": "io_rollback_bits_level",
    "rollback_rob": "io_rollback_bits_robIdx_value",
}


VAR_RE = re.compile(r"\s*\$var\s+\S+\s+\d+\s+(\S+)\s+(\S+)")


def parse_header(path):
    scope = []
    code_by_name = {}
    matched_paths = {}

    with open(path, "r", errors="replace") as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("$scope "):
                parts = stripped.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if stripped.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            if stripped.startswith("$enddefinitions"):
                break

            m = VAR_RE.match(line)
            if not m:
                continue
            code, ref = m.group(1), m.group(2)
            full_path = ".".join(scope + [ref])
            if ".".join(scope).endswith(UNCACHE_SCOPE_SUFFIX):
                for name, expected_ref in NEEDED_REFS.items():
                    if ref == expected_ref:
                        code_by_name[name] = code
                        matched_paths[name] = full_path

    missing = sorted(set(NEEDED_REFS) - set(code_by_name))
    if missing:
        raise RuntimeError("missing required uncacheBuffer VCD signals: " + ", ".join(missing))
    return code_by_name, matched_paths


def bit_to_int(value):
    if value is None:
        return None
    if any(c in value for c in "xXzZ"):
        return None
    return int(value, 2)


def scalar(values, codes, name):
    return bit_to_int(values.get(codes[name], "0"))


def vector(values, codes, name):
    return bit_to_int(values.get(codes[name], "0"))


def req_lane(values, codes, lane):
    return {
        "lane": lane,
        "valid": scalar(values, codes, f"req{lane}_valid") == 1,
        "rob": vector(values, codes, f"req{lane}_rob"),
        "ftq": vector(values, codes, f"req{lane}_ftq"),
        "offset": vector(values, codes, f"req{lane}_offset"),
        "is_rvc": scalar(values, codes, f"req{lane}_is_rvc"),
        "vaddr": vector(values, codes, f"req{lane}_vaddr"),
        "paddr": vector(values, codes, f"req{lane}_paddr"),
        "nc": scalar(values, codes, f"req{lane}_nc"),
        "mmio": scalar(values, codes, f"req{lane}_mmio"),
        "mem_mm": scalar(values, codes, f"req{lane}_mem_mm"),
    }


def rob_less(a, b):
    if a is None or b is None:
        return False
    return ((b - a) & 0x1FF) < 0x100 and a != b


def oldest(reqs):
    result = None
    for req in reqs:
        if result is None or rob_less(req["rob"], result["rob"]):
            result = req
    return result


def update_value(values, interesting_codes, line):
    line = line.strip()
    if not line:
        return
    first = line[0]
    if first in "01xXzZ":
        code = line[1:]
        if code in interesting_codes:
            values[code] = first
    elif first in "bB":
        parts = line.split()
        if len(parts) == 2 and parts[1] in interesting_codes:
            values[parts[1]] = parts[0][1:]


def sample(values, codes, time, cycle, history, events, max_events):
    lanes = [req_lane(values, codes, i) for i in range(3)]
    reqs = [
        req for req in lanes
        if req["valid"] and (req["mmio"] == 1 or req["nc"] == 1)
    ]
    can = [scalar(values, codes, f"freelist_can{i}") == 1 for i in range(3)]
    valid_count = vector(values, codes, "freelist_valid_count")
    free_slots = None if valid_count is None else 16 - valid_count

    cycle_rec = {
        "time": time,
        "cycle": cycle,
        "requests": reqs,
        "can_allocate": can,
        "freelist_valid_count": valid_count,
        "free_slots": free_slots,
        "freelist_empty": scalar(values, codes, "freelist_empty"),
    }
    history.append(cycle_rec)

    if reqs and len(events["req_samples"]) < max_events:
        events["req_samples"].append(cycle_rec)

    if scalar(values, codes, "uncache_valid") == 1:
        uncache = {
            "time": time,
            "cycle": cycle,
            "ready": scalar(values, codes, "uncache_ready"),
            "rob": vector(values, codes, "uncache_rob"),
            "addr": vector(values, codes, "uncache_addr"),
            "vaddr": vector(values, codes, "uncache_vaddr"),
            "id": vector(values, codes, "uncache_id"),
            "nc": scalar(values, codes, "uncache_nc"),
            "mem_mm": scalar(values, codes, "uncache_mem_mm"),
        }
        events["uncache_reqs_seen"] += 1
        if len(events["uncache_reqs"]) < max_events:
            events["uncache_reqs"].append(uncache)

    if scalar(values, codes, "rollback_valid") == 1:
        rollback = {
            "time": time,
            "cycle": cycle,
            "rob": vector(values, codes, "rollback_rob"),
            "ftq": vector(values, codes, "rollback_ftq"),
            "offset": vector(values, codes, "rollback_offset"),
            "is_rvc": scalar(values, codes, "rollback_is_rvc"),
            "level": scalar(values, codes, "rollback_level"),
        }
        events["rollbacks_seen"] += 1

        src = history[-3] if len(history) >= 3 else None
        rejected = []
        if src is not None:
            for idx, req in enumerate(src["requests"]):
                if idx >= len(src["can_allocate"]) or not src["can_allocate"][idx]:
                    rejected.append(req)
        expected = oldest(rejected)
        rollback["expected_source_cycle"] = src
        rollback["expected_oldest_rejected"] = expected
        rollback["matches_expected"] = bool(expected) and all(
            rollback[k] == expected[k]
            for k in ("rob", "ftq", "offset", "is_rvc")
        )
        if not rollback["matches_expected"]:
            events["rollback_mismatches"].append(rollback)
        if len(events["rollbacks"]) < max_events:
            events["rollbacks"].append(rollback)


def parse_wave(wave):
    codes, matched_paths = parse_header(wave)
    interesting_codes = set(codes.values())
    values = {code: "0" for code in interesting_codes}
    time = 0
    cycle = 0
    clock = 0
    history = deque(maxlen=8)
    events = {
        "req_samples": [],
        "uncache_reqs": [],
        "uncache_reqs_seen": 0,
        "rollbacks": [],
        "rollbacks_seen": 0,
        "rollback_mismatches": [],
    }

    with open(wave, "r", errors="replace") as f:
        for line in f:
            if line.startswith("#"):
                time = int(line[1:])
                continue
            old_clock = clock
            update_value(values, interesting_codes, line)
            clock = scalar(values, codes, "clock") or 0
            if old_clock == 0 and clock == 1:
                sample(values, codes, time, cycle, history, events, 200)
                cycle += 1

    predicate = {
        "mmio_or_nc_reqs_seen": len(events["req_samples"]) > 0,
        "uncache_reqs_seen": events["uncache_reqs_seen"] > 0,
        "rollbacks_seen": events["rollbacks_seen"] > 0,
        "rollback_metadata_mismatch_seen": len(events["rollback_mismatches"]) > 0,
        "reproduced": len(events["rollback_mismatches"]) > 0,
    }
    return {
        "wave": wave,
        "sampled_cycles": cycle,
        "signal_paths": matched_paths,
        "predicate": predicate,
        "events": events,
    }


def main():
    if len(sys.argv) != 3:
        print("usage: validate_uncache_overflow_vcd.py <wave.vcd> <out.json>", file=sys.stderr)
        return 2

    result = parse_wave(sys.argv[1])
    with open(sys.argv[2], "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result["predicate"], indent=2))
    for mismatch in result["events"]["rollback_mismatches"][:4]:
        expected = mismatch.get("expected_oldest_rejected")
        print(
            "mismatch time={time} cycle={cycle} rollback=rob{rob}/ftq{ftq}/off{offset} "
            "expected={expected}".format(
                expected=(
                    None if expected is None
                    else "rob{rob}/ftq{ftq}/off{offset}".format(**expected)
                ),
                **mismatch,
            )
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
