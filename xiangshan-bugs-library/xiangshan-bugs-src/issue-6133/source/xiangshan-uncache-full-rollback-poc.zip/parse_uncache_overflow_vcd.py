#!/usr/bin/env python3
import json
import sys
from collections import deque


SIGNALS = {
    "clock": "hH+!",

    "req0_valid": "zov",
    "req0_ftq": "lT<",
    "req0_offset": "mT<",
    "req0_is_rvc": "jT<",
    "req0_rob": "V]e",
    "req0_vaddr": "=g`",
    "req0_paddr": "X#\\",
    "req0_nc": "_5k",
    "req0_mmio": "vT<",
    "req0_mem_mm": "A}F",

    "req1_valid": "{ov",
    "req1_ftq": "i|F",
    "req1_offset": "j|F",
    "req1_is_rvc": "h|F",
    "req1_rob": "Q2F",
    "req1_vaddr": "]U`",
    "req1_paddr": "$|[",
    "req1_nc": "^5k",
    "req1_mmio": "q|F",
    "req1_mem_mm": "r|F",

    "req2_valid": "|ov",
    "req2_ftq": "F|F",
    "req2_offset": "G|F",
    "req2_is_rvc": "D|F",
    "req2_rob": "?2F",
    "req2_vaddr": "\"|[",
    "req2_paddr": "CU`",
    "req2_nc": "Ozu",
    "req2_mmio": "P|F",
    "req2_mem_mm": "I]e",

    "freelist_valid_count": "p_&!",
    "freelist_empty": "q_&!",
    "freelist_can0": ".N`",
    "freelist_can1": "/N`",
    "freelist_can2": "0N`",

    "uncache_ready": "fq*!",
    "uncache_valid": "aKW",
    "uncache_rob": "wj+",
    "uncache_addr": "4!W",
    "uncache_vaddr": "M&G",
    "uncache_id": "9L9",
    "uncache_nc": "Lbe",
    "uncache_mem_mm": "Mbe",

    "rollback_valid": "lgg",
    "rollback_ftq": "K{F",
    "rollback_offset": "L{F",
    "rollback_is_rvc": "M{F",
    "rollback_level": "9+X",
    "rollback_rob": "!h[",
}

IDS = set(SIGNALS.values())
ID_TO_NAMES = {}
for name, code in SIGNALS.items():
    ID_TO_NAMES.setdefault(code, []).append(name)


def bit_to_int(value):
    if value is None:
        return None
    if any(c in value for c in "xXzZ"):
        return None
    return int(value, 2)


def scalar(values, name):
    return bit_to_int(values.get(SIGNALS[name], "0"))


def vector(values, name):
    return bit_to_int(values.get(SIGNALS[name], "0"))


def req_lane(values, lane):
    return {
        "lane": lane,
        "valid": scalar(values, f"req{lane}_valid") == 1,
        "rob": vector(values, f"req{lane}_rob"),
        "ftq": vector(values, f"req{lane}_ftq"),
        "offset": vector(values, f"req{lane}_offset"),
        "is_rvc": scalar(values, f"req{lane}_is_rvc"),
        "vaddr": vector(values, f"req{lane}_vaddr"),
        "paddr": vector(values, f"req{lane}_paddr"),
        "nc": scalar(values, f"req{lane}_nc"),
        "mmio": scalar(values, f"req{lane}_mmio"),
        "mem_mm": scalar(values, f"req{lane}_mem_mm"),
    }


def rob_less(a, b):
    if a is None or b is None:
        return False
    # ROB index is 9-bit circular in this config. For the short local window, the
    # ordered batch has no wrap, but keep a circular comparison for reporting.
    return ((b - a) & 0x1FF) < 0x100 and a != b


def oldest(reqs):
    out = None
    for req in reqs:
        if out is None or rob_less(req["rob"], out["rob"]):
            out = req
    return out


def update_value(values, line):
    line = line.strip()
    if not line:
        return
    c0 = line[0]
    if c0 in "01xXzZ":
        code = line[1:]
        if code in IDS:
            values[code] = c0
    elif c0 in "bB":
        parts = line.split()
        if len(parts) == 2 and parts[1] in IDS:
            values[parts[1]] = parts[0][1:]


def sample(values, time, cycle, history, events, max_events):
    lanes = [req_lane(values, i) for i in range(3)]
    reqs = [
        req for req in lanes
        if req["valid"] and (req["mmio"] == 1 or req["nc"] == 1)
    ]
    can = [scalar(values, f"freelist_can{i}") == 1 for i in range(3)]
    valid_count = vector(values, "freelist_valid_count")
    free_slots = None if valid_count is None else 16 - valid_count

    cycle_rec = {
        "time": time,
        "cycle": cycle,
        "requests": reqs,
        "can_allocate": can,
        "freelist_valid_count": valid_count,
        "free_slots": free_slots,
        "freelist_empty": scalar(values, "freelist_empty"),
    }
    history.append(cycle_rec)

    if reqs and len(events["req_samples"]) < max_events:
        events["req_samples"].append(cycle_rec)

    if scalar(values, "uncache_valid") == 1:
        uncache = {
            "time": time,
            "cycle": cycle,
            "ready": scalar(values, "uncache_ready"),
            "rob": vector(values, "uncache_rob"),
            "addr": vector(values, "uncache_addr"),
            "vaddr": vector(values, "uncache_vaddr"),
            "id": vector(values, "uncache_id"),
            "nc": scalar(values, "uncache_nc"),
            "mem_mm": scalar(values, "uncache_mem_mm"),
        }
        events["uncache_reqs_seen"] += 1
        if len(events["uncache_reqs"]) < max_events:
            events["uncache_reqs"].append(uncache)

    if scalar(values, "rollback_valid") == 1:
        rollback = {
            "time": time,
            "cycle": cycle,
            "rob": vector(values, "rollback_rob"),
            "ftq": vector(values, "rollback_ftq"),
            "offset": vector(values, "rollback_offset"),
            "is_rvc": scalar(values, "rollback_is_rvc"),
            "level": scalar(values, "rollback_level"),
        }
        events["rollbacks_seen"] += 1

        # The implementation registers LoadUnit S3 requests into s2, chooses a
        # rejected uncache request in the next cycle, then registers rollback
        # valid/bits. In the sampled waveform, rollback N should match the
        # oldest uncache request from two sampled cycles earlier when the
        # freelist can no longer allocate all requested lanes.
        src = history[-3] if len(history) >= 3 else None
        expected = None
        rejected = []
        if src is not None:
            for idx, req in enumerate(src["requests"]):
                if idx >= len(src["can_allocate"]) or not src["can_allocate"][idx]:
                    rejected.append(req)
            expected = oldest(rejected)
        rollback["expected_source_cycle"] = src
        rollback["expected_oldest_rejected"] = expected
        rollback["matches_expected"] = bool(expected) and all(
            rollback[k] == expected[k]
            for k in ("rob", "ftq", "offset", "is_rvc")
        )
        if not rollback["matches_expected"]:
            events["rollback_mismatches"].append(rollback)
        if len(events["rollbacks"]) < max_events:
            events["rollbacks"].append(rollback)


def main():
    if len(sys.argv) != 3:
        print("usage: parse_uncache_overflow_vcd.py <wave.vcd> <out.json>", file=sys.stderr)
        sys.exit(2)

    wave, out_path = sys.argv[1:]
    values = {code: "0" for code in IDS}
    time = 0
    cycle = 0
    clock = 0
    history = deque(maxlen=8)
    events = {
        "req_samples": [],
        "uncache_reqs": [],
        "uncache_reqs_seen": 0,
        "rollbacks": [],
        "rollbacks_seen": 0,
        "rollback_mismatches": [],
    }
    max_events = 200

    with open(wave, "r", errors="replace") as f:
        for line in f:
            if line.startswith("#"):
                time = int(line[1:])
                continue
            old_clock = clock
            update_value(values, line)
            clock = scalar(values, "clock") or 0
            if old_clock == 0 and clock == 1:
                sample(values, time, cycle, history, events, max_events)
                cycle += 1

    result = {
        "wave": wave,
        "sampled_cycles": cycle,
        "predicate": {
            "mmio_or_nc_reqs_seen": len(events["req_samples"]) > 0,
            "uncache_reqs_seen": events["uncache_reqs_seen"] > 0,
            "rollbacks_seen": events["rollbacks_seen"] > 0,
            "rollback_metadata_mismatch_seen": len(events["rollback_mismatches"]) > 0,
            "reproduced": len(events["rollback_mismatches"]) > 0,
        },
        "events": events,
    }
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result["predicate"], indent=2))


if __name__ == "__main__":
    main()
