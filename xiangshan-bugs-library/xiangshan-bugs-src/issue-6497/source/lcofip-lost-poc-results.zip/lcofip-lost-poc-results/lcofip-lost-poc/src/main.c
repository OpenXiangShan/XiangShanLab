#include <klib.h>

// =============================================================================
// PoC: mip.LCOFIP count-overflow request lost when it coincides with a
//      software write to mip / sip (XiangShan NewCSR, MachineLevel.scala).
//
//   when (fromSip.LCOFIP.valid || fromVSip.LCOFIP.valid || wen) {
//     reg.LCOFIP := Mux1H(... wen -> wdata.LCOFIP ...)     // write wins
//   }.elsewhen(lcofiReq) {
//     reg.LCOFIP := lcofiReq                                // request dropped
//   }
//
// lcofiReq is a 1-cycle pulse (ofFromPerfCnt && !mhpmevent.OF); after the
// pulse mhpmevent.OF == 1 so no further request can be generated for that
// counter (Sscofpmf). If the pulse lands in the write cycle of a CSR write to
// mip/sip whose bit13 write value is 0 (e.g. `csrrc x0, mip, SSIP`), the
// request is lost forever: OF == 1 while LCOFIP stays 0.
//
// Method: arm one hpmcounter to overflow after exactly k events (counter =
// -k, OF = 0, LCOFIP = 0), then run a fixed burst of CSR instructions and
// read back OF and LCOFIP. Sweeping k walks the overflow cycle across the
// whole burst; every k with OF == 1 && LCOFIP == 0 is a lost interrupt.
// Controls: identical burst on an unrelated CSR (mscratch) and a NOP burst.
// =============================================================================

#define CSR_SIP           0x144
#define CSR_MIDELEG       0x303
#define CSR_MIE           0x304
#define CSR_MCOUNTINHIBIT 0x320
#define CSR_MHPMEVENT3    0x323
#define CSR_MHPMEVENT11   0x32b
#define CSR_MSCRATCH      0x340
#define CSR_MIP           0x344
#define CSR_MHPMCOUNTER3  0xb03
#define CSR_MHPMCOUNTER11 0xb0b
#define CSR_SCOUNTOVF     0xda0

#define S_(x) #x
#define S(x) S_(x)

#define CSRR(csr) ({ unsigned long __v; \
    asm volatile("csrr %0, " S(csr) : "=r"(__v) : : "memory"); __v; })
#define CSRW(csr, v) asm volatile("csrw " S(csr) ", %0" : : "r"(v) : "memory")

#define BIT(n) (1UL << (n))
#define MIP_SSIP     BIT(1)
#define MIP_LCOFIP   BIT(13)

// mhpmevent (XiangShan): [63]OF [62]MINH [61]SINH [60]UINH [59]VSINH [58]VUINH
// [54:50]OPTYPE2 [49:45]OPTYPE1 [44:40]OPTYPE0 [39:30]EV3 [29:20]EV2 [19:10]EV1 [9:0]EV0
// Backend (mhpmevent11..18) event ids: 0 noEvent, 1 decoder_fused_instr,
//   2 decoder_waitInstr, 3 decoder_stall_cycle, 4 decoder_utilization,
//   5 frontend_stall_cycle, 6 backend_stall_cycle, ...
// Frontend (mhpmevent3..10): 19 IBuffer_4_4_valid, 21 Front_Bubble, 2 ifu_req
#define EV(e0) ((unsigned long)(e0))

#define REP2(x) x x
#define REP4(x) REP2(x) REP2(x)

// bursts: 4 back-to-back CSR instructions (each is noSpec+blockBackward+flush)
#define B_CSRRC_MIP  REP4("csrrc x0, " S(CSR_MIP)      ", %[m]\n\t")
#define B_CSRRC_SIP  REP4("csrrc x0, " S(CSR_SIP)      ", %[m]\n\t")
#define B_CSRRC_MSCR REP4("csrrc x0, " S(CSR_MSCRATCH) ", %[m]\n\t")
#define B_NOP        REP4("nop\n\t")

// One trial: clear LCOFIP, OF:=0 + select event, counter:=init, burst, read.
// OF is read BEFORE mip so a late overflow can never look like a loss.
#define DEFINE_RUNNER(fname, BURST, EVCSR, CNTCSR)                          \
static void fname(unsigned long evsel, unsigned long init, unsigned long m, \
                  unsigned long *of_o, unsigned long *ip_o, unsigned long *cnt_o) \
{                                                                            \
    unsigned long of, ip, cnt;                                               \
    asm volatile(                                                            \
        "csrw " S(CSR_MIP) ", x0\n\t"                                        \
        "csrw " S(EVCSR)   ", %[ev]\n\t"                                     \
        "csrw " S(CNTCSR)  ", %[init]\n\t"                                   \
        BURST                                                                \
        "csrr %[cnt], " S(CNTCSR) "\n\t"                                     \
        "csrr %[of],  " S(EVCSR)  "\n\t"                                     \
        "csrr %[ip],  " S(CSR_MIP) "\n\t"                                    \
        : [of] "=&r"(of), [ip] "=&r"(ip), [cnt] "=&r"(cnt)                   \
        : [ev] "r"(evsel), [init] "r"(init), [m] "r"(m)                      \
        : "memory");                                                         \
    *of_o = of; *ip_o = ip; *cnt_o = cnt;                                    \
}

DEFINE_RUNNER(run_csrrc_mip_c11,  B_CSRRC_MIP,  CSR_MHPMEVENT11, CSR_MHPMCOUNTER11)
DEFINE_RUNNER(run_csrrc_sip_c11,  B_CSRRC_SIP,  CSR_MHPMEVENT11, CSR_MHPMCOUNTER11)
DEFINE_RUNNER(run_csrrc_mscr_c11, B_CSRRC_MSCR, CSR_MHPMEVENT11, CSR_MHPMCOUNTER11)
DEFINE_RUNNER(run_nop_c11,        B_NOP,        CSR_MHPMEVENT11, CSR_MHPMCOUNTER11)

typedef void (*runner_t)(unsigned long, unsigned long, unsigned long,
                         unsigned long *, unsigned long *, unsigned long *);

struct result {
    unsigned long E;        // events counted during one burst (calibration)
    unsigned long klim;     // k range actually swept
    unsigned long n_ovf;    // trials with OF == 1
    unsigned long n_lost;   // OF == 1 && LCOFIP == 0
    unsigned long n_weird;  // OF == 0 && LCOFIP == 1 (should be 0)
    unsigned long first_k;  // first k that lost the request (0 = none)
};

#define KMAX 300

static void sweep(runner_t run, unsigned long evsel, struct result *r)
{
    unsigned long of, ip, cnt;
    run(evsel, 0, MIP_SSIP, &of, &ip, &cnt);   // calibration: counter from 0
    r->E = cnt;
    r->klim = cnt + 4;
    if (r->klim > KMAX) r->klim = KMAX;
    r->n_ovf = r->n_lost = r->n_weird = r->first_k = 0;
    for (unsigned long k = 1; k <= r->klim; k++) {
        run(evsel, -k, MIP_SSIP, &of, &ip, &cnt);
        int OF = (of >> 63) & 1;
        int IP = (ip >> 13) & 1;
        if (!OF) { if (IP) r->n_weird++; continue; }
        r->n_ovf++;
        if (!IP) { r->n_lost++; if (!r->first_k) r->first_k = k; }
    }
}

static void report(const char *name, const struct result *r)
{
    printf("%-22s E=%lu swept k=1..%lu  overflow=%lu  LOST=%lu  weird=%lu  first_lost_k=%lu\n",
           name, r->E, r->klim, r->n_ovf, r->n_lost, r->n_weird, r->first_k);
}

int main(void)
{
    printf("=== mip.LCOFIP lost-on-CSR-write PoC ===\n");
    printf("mcountinhibit=%lx mideleg=%lx mie=%lx mip=%lx scountovf=%lx\n",
           CSRR(CSR_MCOUNTINHIBIT), CSRR(CSR_MIDELEG), CSRR(CSR_MIE),
           CSRR(CSR_MIP), CSRR(CSR_SCOUNTOVF));

    CSRW(CSR_MIE, 0);                          // never take the interrupt; we poll mip
    CSRW(CSR_MCOUNTINHIBIT, 0);

    // pick a backend event that actually counts during the burst
    unsigned long cand[3] = { EV(4), EV(6), EV(2) };  // decoder_utilization, backend_stall_cycle, decoder_waitInstr
    unsigned long best = cand[0], bestE = 0;
    for (int i = 0; i < 3; i++) {
        unsigned long of, ip, cnt;
        run_csrrc_mip_c11(cand[i], 0, MIP_SSIP, &of, &ip, &cnt);
        printf("probe backend event %lu: %lu events during 4x csrrc mip burst\n", cand[i], cnt);
        if (cnt > bestE) { bestE = cnt; best = cand[i]; }
    }
    if (bestE == 0) {
        printf("=== UNEXPECTED: no backend event counted; cannot arm overflow ===\n");
        return 3;
    }
    printf("using mhpmevent11 = event %lu\n", best);

    struct result r_mip, r_mip1, r_sip, r_mscr, r_nop;

    // 1. RMW write to mip with bit13 mask 0 (the reported scenario). An RMW
    //    preserves an already-pending LCOFIP, so every OF=1/LCOFIP=0 outcome
    //    is a genuine same-cycle race, not a software clear.
    //    (A plain `csrw mip,x0` is not used: it legitimately clears any
    //    LCOFIP that became pending earlier in the burst.)
    sweep(run_csrrc_mip_c11, best, &r_mip);
    report("csrrc x0,mip,SSIP", &r_mip);

    // 2. same burst, but count a 1-per-cycle event (backend_stall_cycle) so
    //    LOST directly measures the vulnerable cycles per CSR instruction
    //    (expected 2 per RMW: read cycle T0 + write cycle T1).
    sweep(run_csrrc_mip_c11, EV(6), &r_mip1);
    report("csrrc mip (1/cycle ev)", &r_mip1);

    // 3. same through the sip alias (mideleg.LCOFI=1 -> fromSip.LCOFIP.valid)
    CSRW(CSR_MIDELEG, MIP_SSIP | MIP_LCOFIP);
    sweep(run_csrrc_sip_c11, best, &r_sip);
    report("csrrc x0,sip,SSIP", &r_sip);
    CSRW(CSR_MIDELEG, 0);

    // controls: same CSR pipeline timing but no write to mip
    sweep(run_csrrc_mscr_c11, best, &r_mscr);
    report("ctrl csrrc mscratch", &r_mscr);
    sweep(run_nop_c11, best, &r_nop);
    report("ctrl nop", &r_nop);

    // persistence: reproduce one lost case, then wait and re-read
    if (r_mip.first_k) {
        unsigned long of, ip, cnt;
        run_csrrc_mip_c11(best, -r_mip.first_k, MIP_SSIP, &of, &ip, &cnt);
        printf("replay k=%lu: mhpmevent11.OF=%lu mip.LCOFIP=%lu\n",
               r_mip.first_k, (of >> 63) & 1, (ip >> 13) & 1);
        for (volatile int i = 0; i < 2000; i++) ;
        unsigned long ip2 = CSRR(CSR_MIP), ovf2 = CSRR(CSR_SCOUNTOVF), ev2 = CSRR(CSR_MHPMEVENT11);
        printf("after delay: mip.LCOFIP=%lu scountovf[11]=%lu mhpmevent11.OF=%lu -> %s\n",
               (ip2 >> 13) & 1, (ovf2 >> 11) & 1, (ev2 >> 63) & 1,
               ((ip2 >> 13) & 1) ? "recovered" : "PERMANENTLY LOST");
    }

    unsigned long lost = r_mip.n_lost + r_mip1.n_lost + r_sip.n_lost;
    unsigned long ctrl_lost = r_mscr.n_lost + r_nop.n_lost;
    if (ctrl_lost) {
        printf("=== UNEXPECTED: control bursts lost requests too (%lu) ===\n", ctrl_lost);
        return 3;
    }
    if (lost) {
        printf("=== BUG CONFIRMED: %lu overflow requests lost to same-cycle mip/sip writes ===\n", lost);
        return 1;
    }
    printf("=== PASS: no overflow request lost ===\n");
    return 0;
}
