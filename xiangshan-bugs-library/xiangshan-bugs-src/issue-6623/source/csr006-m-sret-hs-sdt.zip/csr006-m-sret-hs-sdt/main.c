#include <klib.h>
#include <stdint.h>

/*
 * CSR-006: M-mode SRET returning to HS must clear sstatus.SDT.
 * SretEvent only clears SDT for sretInHS or M→U/VS/VU; M→HS keeps the bit.
 */

#define MSTATUS_MPP_S (1UL << 11)
#define MSTATUS_SDT   (1UL << 24)
#define MENVCFG_DTE   (1UL << 59)
#define PMP_R         (1UL << 0)
#define PMP_W         (1UL << 1)
#define PMP_X         (1UL << 2)
#define PMP_A_NAPOT   (3UL << 3)

static volatile uint64_t hs_sstatus;
static volatile uint64_t m_continue;

void m_trap(void);
void s_entry(void);

__attribute__((naked, aligned(4))) void m_trap(void) {
  asm volatile(
    "la t1, m_continue\n\t"
    "ld t0, 0(t1)\n\t"
    "csrw mepc, t0\n\t"
    "li t0, 0x1800\n\t"
    "csrs mstatus, t0\n\t"
    "mret\n\t");
}

__attribute__((naked, aligned(4))) void s_entry(void) {
  asm volatile(
    "csrr t0, sstatus\n\t"
    "la t1, hs_sstatus\n\t"
    "sd t0, 0(t1)\n\t"
    "ecall\n\t");
}

static void pmp_allow_all(void) {
  asm volatile("csrw 0x3a0, x0" ::: "memory");
  asm volatile("csrw 0x3b0, %0" :: "r"(~(uintptr_t)0) : "memory");
  asm volatile("csrw 0x3a0, %0" :: "r"(PMP_A_NAPOT | PMP_R | PMP_W | PMP_X) : "memory");
}

int main(void) {
  uint64_t menvcfg, mstatus;

  printf("csr006-m-sret-hs-sdt start\n");
  pmp_allow_all();
  asm volatile("csrw satp, x0" ::: "memory");
  asm volatile("sfence.vma" ::: "memory");
  asm volatile("csrw mtvec, %0" :: "r"(m_trap) : "memory");

  asm volatile("csrr %0, 0x30a" : "=r"(menvcfg));
  menvcfg |= MENVCFG_DTE;
  asm volatile("csrw 0x30a, %0" :: "r"(menvcfg) : "memory");

  asm volatile("csrr %0, mstatus" : "=r"(mstatus));
  mstatus |= MSTATUS_SDT;
  asm volatile("csrw mstatus, %0" :: "r"(mstatus) : "memory");

  hs_sstatus = 0;
  asm volatile(
    "la t0, 1f\n\t"
    "sd t0, m_continue, t1\n\t"
    "csrr t0, mstatus\n\t"
    "li t1, 0x1888\n\t"
    "not t1, t1\n\t"
    "and t0, t0, t1\n\t"
    "li t1, 0x800\n\t"
    "or t0, t0, t1\n\t"
    "ori t0, t0, 0x100\n\t" /* SPP = S so SRET lands in HS */
    "csrw mstatus, t0\n\t"
    "la t0, s_entry\n\t"
    "csrw sepc, t0\n\t"
    "sret\n\t"
    "1:\n\t"
    ::: "t0", "t1", "memory");

  printf("hs_sstatus=0x%lx sdt=%lu\n", hs_sstatus, (hs_sstatus & MSTATUS_SDT) != 0);

  if ((hs_sstatus & MSTATUS_SDT) != 0) {
    printf("FAIL csr006 M-mode SRET to HS left SDT set\n");
    return 1;
  }

  printf("csr006-m-sret-hs-sdt pass\n");
  return 0;
}
