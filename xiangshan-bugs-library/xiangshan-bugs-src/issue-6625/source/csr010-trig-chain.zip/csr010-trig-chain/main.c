#include <klib.h>
#include <stdint.h>

/*
 * CSR-010: execute trigger update is not mirrored to the memory tdata
 * chain. Chain: t0 execute (chain=1) then t1 load. Hitting the execute
 * trigger then a matching load must fire the chain.
 */

#define TDATA1_TYPE_MCONTROL (2UL << 60)
#define TDATA1_DMODE         (1UL << 59)
#define MCONTROL_EXECUTE     (1UL << 2)
#define MCONTROL_LOAD        (1UL << 0)
#define MCONTROL_M           (1UL << 6)
#define MCONTROL_CHAIN       (1UL << 11)
#define MCONTROL_ACTION_DBG  (0UL << 12)
#define PMP_R        (1UL << 0)
#define PMP_W        (1UL << 1)
#define PMP_X        (1UL << 2)
#define PMP_A_NAPOT  (3UL << 3)
#define CAUSE_BREAKPOINT 3UL

static volatile uint64_t cell;
static volatile uint64_t trap_count;
static volatile uint64_t trap_mcause;
static volatile uint64_t resume;

void m_trap(void);
void trig_target(void);

__attribute__((naked, aligned(4))) void m_trap(void) {
  asm volatile(
    "csrr t0, mcause\n\t"
    "la t1, trap_mcause\n\t"
    "sd t0, 0(t1)\n\t"
    "la t1, trap_count\n\t"
    "ld t2, 0(t1)\n\t"
    "addi t2, t2, 1\n\t"
    "sd t2, 0(t1)\n\t"
    "la t1, resume\n\t"
    "ld t0, 0(t1)\n\t"
    "csrw mepc, t0\n\t"
    "mret\n\t");
}

__attribute__((naked, aligned(4))) void trig_target(void) {
  asm volatile(
    "ret\n\t");
}

static void pmp_allow_all(void) {
  asm volatile("csrw 0x3a0, x0" ::: "memory");
  asm volatile("csrw 0x3b0, %0" :: "r"(~(uintptr_t)0) : "memory");
  asm volatile("csrw 0x3a0, %0" :: "r"(PMP_A_NAPOT | PMP_R | PMP_W | PMP_X) : "memory");
}

static void write_trig(uint64_t tselect, uint64_t tdata1, uint64_t tdata2) {
  asm volatile("csrw 0x7a0, %0" :: "r"(tselect) : "memory");
  asm volatile("csrw 0x7a1, %0" :: "r"(tdata1) : "memory");
  asm volatile("csrw 0x7a2, %0" :: "r"(tdata2) : "memory");
}

int main(void) {
  uint64_t t0_cfg, t1_cfg, dummy;

  printf("csr010-trig-chain start\n");
  pmp_allow_all();
  asm volatile("csrw mtvec, %0" :: "r"(m_trap) : "memory");
  cell = 0x55;
  trap_count = trap_mcause = 0;

  t0_cfg = TDATA1_TYPE_MCONTROL | MCONTROL_EXECUTE | MCONTROL_M | MCONTROL_CHAIN;
  t1_cfg = TDATA1_TYPE_MCONTROL | MCONTROL_LOAD | MCONTROL_M;
  write_trig(0, t0_cfg, (uintptr_t)trig_target);
  write_trig(1, t1_cfg, (uintptr_t)&cell);

  asm volatile(
      "la t0, 1f\n\t"
      "sd t0, resume, t1\n\t"
      "jal ra, trig_target\n\t"
      "ld %0, cell\n\t"
      "1:\n\t"
      : "=r"(dummy) :: "t0", "t1", "ra", "memory");

  printf("traps=%lu mcause=%lu dummy=0x%lx\n", trap_count, trap_mcause, dummy);

  if (trap_count == 0 || trap_mcause != CAUSE_BREAKPOINT) {
    printf("FAIL csr010 execute-load chain did not fire\n");
    return 1;
  }

  printf("csr010-trig-chain pass\n");
  return 0;
}
