1. `CONFIG=KunminghuV2Config` 

2. Run `make ARCH=riscv64-xs` to compile 

3. use `path_to_xs-env/XiangShan/build/emu  --no-diff -i ./build/sv39test-riscv64-xs.bin` to run the PoC

4. print log:
The image is /root/xs-env/nexus-am/apps/archTest/build/sv39test-riscv64-xs.bin
[ARCH-POC] main start
[TRAP] #0 mcause=0xc mepc=0x8000201c mtval=0x8000201c mstatus=0x8000040a00006800 satp=0x8000000000080005
  [PAGE-WALK] mtval=0x8000201c vpn2=2 vpn1=0 vpn0=2
              L2 PTE=0x20001801
              L1 PTE=0x20001c01
              L0 PTE=0x2000084b
  [TRAMP] va=0x80002000
          vpn2=2 vpn1=0 vpn0=2
          L2 PTE(saved)=0x20001801
          L1 PTE(saved)=0x20001c01
          L0 PTE(saved)=0x2000084b
[ARCH-POC] back to main

5.Sv39 IPF Conformance Test – PoC Description
This PoC exercises the core’s Sv39 implementation by triggering an instruction fetch from a supervisor-mode trampoline mapped through a three-level page table, then comparing the hardware’s behavior against the RISC-V Privileged Specification.

*Execution flow and privilege setup
The C entry (main) initializes PMP to allow full R/W/X access over the entire physical address space and sets mtvec to a machine-mode trap handler.
arch_test_entry switches from M-mode to S-mode with satp = 0 (Bare mode) and mstatus.MPP = S, jumping to the S-mode function set_page_table.

*Page table construction (Sv39)
In set_page_table (still in S-mode, Bare), three page-table pages (l2_pgt, l1_pgt, l0_pgt) are zeroed.
map_page is called to map the S-mode trampoline function s_tramp with a leaf PTE having flags 0x4b (V=1, R=1, W=0, X=1, U=0, A=1, D=0).
map_page computes vpn2/vpn1/vpn0 for s_tramp, installs:
a valid non-leaf L2 PTE pointing to l1_pgt,
a valid non-leaf L1 PTE pointing to l0_pgt,
a valid leaf L0 PTE pointing to the physical page containing s_tramp,
and saves the VPNs and PTE values in global debug variables.
sstatus.SPP is set to U and sepc is set to a dummy U-mode routine (U_dummy), preparing for an S→U return. Execution then jumps directly to s_tramp while still in S-mode Bare (identity mapping).

*Enabling Sv39 and triggering the fault
In s_tramp (S-mode, Bare), the code loads the root page table base (l2_pgt), constructs satp with MODE=8 (Sv39), ASID=0, and PPN of l2_pgt, and writes it to satp.
Immediately after updating satp, it executes sfence.vma x0, x0 and then sret is expected to return to U-mode at U_dummy, now under Sv39 translation.
On the tested core, the sfence.vma instruction at virtual address 0x8000201c instead raises a machine trap with:
mcause = 0xC (Instruction Page Fault),
mepc = 0x8000201c,
mtval = 0x8000201c,
satp = 0x8000000000080005 (MODE=8, Sv39, root PPN pointing to l2_pgt).

*Software page walk and mismatch with expected behavior
The M-mode trap handler performs a software Sv39 page-table walk using satp and mtval:
It reconstructs vpn2=2, vpn1=0, vpn0=2 and reads:
L2 PTE = 0x20001801 (valid non-leaf),
L1 PTE = 0x20001c01 (valid non-leaf),
L0 PTE = 0x2000084b (valid leaf with V=1, R=1, X=1, U=0, A=1, D=0),
These values exactly match the PTEs previously written by map_page.
Under the RISC-V Sv39 rules, this mapping is a valid, executable supervisor-only page for the faulting VA, and with A=1 and no reserved bits set, an instruction page fault must not be raised for an S-mode instruction fetch at this address.
Therefore, the core’s behavior (raising an Instruction Page Fault on sfence.vma at 0x8000201c with the above PTE configuration) is inconsistent with the Sv39 specification and indicates a non-conforming implementation.


