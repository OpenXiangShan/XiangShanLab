// Minimal Sv39 IPF PoC (for bug report)

#include <stdio.h>
#include <stdint.h>
#include <klib.h>


extern void init_pmp(void);
extern void init_trap_vector(void);
extern void arch_test_entry(void);
extern void s_tramp(void);


extern uint64_t g_tramp_vpn0, g_tramp_vpn1, g_tramp_vpn2;
extern uint64_t g_tramp_l2_pte, g_tramp_l1_pte, g_tramp_l0_pte;

// save s_tramp  VA
uintptr_t g_tramp_va;

//   mcause, mepc, mtval, mstatus, satp, l2_pte, l1_pte, l0_pte
void dump_trap(uint64_t mcause, uint64_t mepc,
               uint64_t mtval,  uint64_t mstatus, uint64_t satp,
               uint64_t l2_pte, uint64_t l1_pte, uint64_t l0_pte) {
  static int cnt = 0;

  printf("[TRAP] #%d mcause=0x%lx mepc=0x%lx mtval=0x%lx mstatus=0x%lx satp=0x%lx\n",
         cnt, mcause, mepc, mtval, mstatus, satp);

  uint64_t mode = satp >> 60;
  if (mode == 8) {  // Sv39
    uint64_t vpn0 = (mtval >> 12) & 0x1ff;
    uint64_t vpn1 = (mtval >> 21) & 0x1ff;
    uint64_t vpn2 = (mtval >> 30) & 0x1ff;

    printf("  [PAGE-WALK] mtval=0x%lx vpn2=%lu vpn1=%lu vpn0=%lu\n",
           (unsigned long)mtval,
           (unsigned long)vpn2,
           (unsigned long)vpn1,
           (unsigned long)vpn0);

    printf("              L2 PTE=0x%lx\n", (unsigned long)l2_pte);
    printf("              L1 PTE=0x%lx\n", (unsigned long)l1_pte);
    printf("              L0 PTE=0x%lx\n", (unsigned long)l0_pte);
  }

  if (cnt == 0) {
    printf("  [TRAMP] va=0x%lx\n", (unsigned long)g_tramp_va);
    printf("          vpn2=%lu vpn1=%lu vpn0=%lu\n",
           (unsigned long)g_tramp_vpn2,
           (unsigned long)g_tramp_vpn1,
           (unsigned long)g_tramp_vpn0);
    printf("          L2 PTE(saved)=0x%lx\n", (unsigned long)g_tramp_l2_pte);
    printf("          L1 PTE(saved)=0x%lx\n", (unsigned long)g_tramp_l1_pte);
    printf("          L0 PTE(saved)=0x%lx\n", (unsigned long)g_tramp_l0_pte);
  }

  cnt++;
}

int main(void) {
  printf("[ARCH-POC] main start\n");

  g_tramp_va = (uintptr_t)&s_tramp;

  init_pmp();
  init_trap_vector();

  arch_test_entry();

  printf("[ARCH-POC] back to main\n");
  return 0;
}