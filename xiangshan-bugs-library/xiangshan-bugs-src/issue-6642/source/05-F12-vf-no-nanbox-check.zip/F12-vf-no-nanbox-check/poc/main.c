/* F12 -- the confirmed e32 vfadd.vf case uses an improperly NaN-boxed
 * FP32 scalar as an ordinary finite value. The selected FP bypass
 * carries the raw 64-bit register value and replicates its low SEW
 * bits for the vector operation. Later subcases in this PoC are not
 * covered by the three-seed difftest result.
 */
#include "vt-common.h"

static uint8_t preset[16] __attribute__((aligned(16)));
static uint8_t img[16] __attribute__((aligned(16)));
static uint8_t src[16] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f12_vfadd_vf_e16(void *o, const void *p, const void *img, const void *v);
extern void f12_vfadd_vf_e32(void *o, const void *p, const void *img, const void *v);
extern void f12_vfmv_s_f_e16(void *o, const void *p, const void *img);
extern void f12_fadd_s_ref(void *o, const void *unused, const void *img);
static void put64(uint8_t *b, uint64_t v) { for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k)); }
static void put32(uint8_t *p, int i, uint32_t v) { for (int k = 0; k < 4; k++) p[4 * i + k] = (uint8_t)(v >> (8 * k)); }
static void put16(uint8_t *p, int i, uint16_t v) { p[2 * i] = (uint8_t)v; p[2 * i + 1] = (uint8_t)(v >> 8); }
static uint32_t get32(const uint8_t *p, int i) { return (uint32_t)(bytes_q(p + 4 * i) & 0xFFFFFFFFu); }
static uint16_t get16(const uint8_t *p, int i) { return (uint16_t)(p[2 * i] | (p[2 * i + 1] << 8)); }

int main(void) {
  int bugs = 0, i;
  for (i = 0; i < 16; i++) preset[i] = (uint8_t)(0xC0 + i);
  if (vt_init("F12") != 0) return 1;
  printf("[F12] start cyc=%lu\n", (unsigned long)cyc());

  /* scalar reference: unboxed 1.0f + itself -> canonical NaN, boxed */
  put64(img, 0x000000003F800000UL);
  memset(out, 0, 16); f12_fadd_s_ref(out, 0, img); VT_FENCE();
  printf("[F12] scalar fadd.s(unboxed 1.0f) = %016lx (expect ffffffff7fc00000) %s\n",
         (unsigned long)out_q(out, 0), out_q(out, 0) == 0xFFFFFFFF7FC00000UL ? "ok" : "unexpected");

  /* vfadd.vf e32 with the same unboxed 1.0f: every element must be 0x7FC00000 */
  put32(src, 0, 0x3F800000); put32(src, 1, 0x40000000); put32(src, 2, 0xC0400000); put32(src, 3, 0x3F000000);
  memset(out, 0, 16); f12_vfadd_vf_e32(out, preset, img, src); VT_FENCE();
  { int ok = (get32(out, 0) == 0x7FC00000 && get32(out, 1) == 0x7FC00000 && get32(out, 2) == 0x7FC00000 && get32(out, 3) == 0x7FC00000);
    if (!ok) bugs++;
    printf("[F12] vfadd.vf e32 unboxed scalar: v2=%016lx_%016lx expect 7fc00000 x4 %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           ok ? "ok" : (get32(out, 0) == 0x40000000 ? "BUG: scalar used as 1.0f" : "BUG")); }

  /* vfadd.vf e16 with an unboxed fp16 2.0 (0x4000, upper bits 0) */
  put64(img, 0x0000000000004000UL);
  put16(src, 0, 0x3E00); put16(src, 1, 0x4000); put16(src, 2, 0xC200); put16(src, 3, 0x3800);
  memset(out, 0, 16); f12_vfadd_vf_e16(out, preset, img, src); VT_FENCE();
  { int ok = (get16(out, 0) == 0x7E00 && get16(out, 1) == 0x7E00 && get16(out, 2) == 0x7E00 && get16(out, 3) == 0x7E00);
    if (!ok) bugs++;
    printf("[F12] vfadd.vf e16 unboxed scalar: v2=%016lx_%016lx expect 7e00 x4 %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           ok ? "ok" : (get16(out, 0) == 0x4300 ? "BUG: scalar used as 2.0" : "BUG")); }

  /* vfmv.s.f e16 vl=1 tu from an unboxed fp16 1.5 (0x3E00): element 0 must be 0x7E00, rest preset */
  put64(img, 0x0000000000003E00UL);
  memset(out, 0, 16); f12_vfmv_s_f_e16(out, preset, img); VT_FENCE();
  { int ok = (get16(out, 0) == 0x7E00 && !memcmp_(out + 2, preset + 2, 14));
    if (!ok) bugs++;
    printf("[F12] vfmv.s.f e16 unboxed scalar: v2=%016lx_%016lx expect elem0=7e00, rest preset %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           ok ? "ok" : (get16(out, 0) == 0x3E00 ? "BUG: raw bits used (and tail written, see F09)" : "BUG")); }

  printf("[F12] done bugs=%d verdict=%s\n", bugs, bugs ? "NO_NANBOX_CHECK" : "clean");
  return 0;
}
