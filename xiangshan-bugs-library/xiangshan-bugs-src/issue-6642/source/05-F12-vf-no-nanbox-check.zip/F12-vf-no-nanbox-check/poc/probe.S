/* F12: e32 vfadd.vf NaN-boxing reproducer; f1 is loaded from a2,
 * v3 from a3, and v2 preset from a1. Other subcases are unverified. */
#include "probe-common.S"

  .align 6
  .globl f12_vfadd_vf_e16
  .type  f12_vfadd_vf_e16, @function
f12_vfadd_vf_e16:
  fld f1, 0(a2)
  vl1re64.v v2, (a1)
  vl1re64.v v3, (a3)
  vsetivli x0, 4, e16, m1, tu, mu
  vfadd.vf v2, v3, f1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f12_vfadd_vf_e16, .-f12_vfadd_vf_e16

  .align 6
  .globl f12_vfadd_vf_e32
  .type  f12_vfadd_vf_e32, @function
f12_vfadd_vf_e32:
  fld f1, 0(a2)
  vl1re64.v v2, (a1)
  vl1re64.v v3, (a3)
  vsetivli x0, 4, e32, m1, tu, mu
  vfadd.vf v2, v3, f1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f12_vfadd_vf_e32, .-f12_vfadd_vf_e32

  .align 6
  .globl f12_vfmv_s_f_e16
  .type  f12_vfmv_s_f_e16, @function
f12_vfmv_s_f_e16:
  fld f1, 0(a2)
  vl1re64.v v2, (a1)
  vsetivli x0, 1, e16, m1, tu, mu
  vfmv.s.f v2, f1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f12_vfmv_s_f_e16, .-f12_vfmv_s_f_e16

/* Scalar reference: fadd.s with the same unboxed image must yield the canonical NaN. */
  .align 6
  .globl f12_fadd_s_ref
  .type  f12_fadd_s_ref, @function
f12_fadd_s_ref:
  fld f1, 0(a2)
  fadd.s f2, f1, f1
  fsd f2, 0(a0)
  ret
  .size f12_fadd_s_ref, .-f12_fadd_s_ref
