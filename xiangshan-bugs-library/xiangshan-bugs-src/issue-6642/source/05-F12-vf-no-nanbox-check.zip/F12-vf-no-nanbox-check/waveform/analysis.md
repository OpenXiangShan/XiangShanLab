# F12: waveform corroboration of missing NaN-box validation on the selected vector scalar path

**Status: corroborates the reported wrong result and refines the operand-path explanation.** This is one supplementary seed-0 trace of freshly rebuilt FST-enabled XiangShan `b9636416b81d266f3a3d4d1e46d4e66e6a574bcd`, using the unchanged packaged image and reference. The trace emulator is a different binary; exact hashes and invocation are in [run.json](run.json). Its architectural differences equal the original run's differences.

![Actual sampled waveform](waveform-evidence.png)

## Observed chain

Cycle numbers are **falling-edge sample indices from the first falling edge of this FST**, not printed DUT `cycleCnt`. Samples are post-evaluation. Data accompanied by a valid/write-enable at sample c is the interface value before the following rising edge. Inactive values are not valid results.

| Sample | Actual observation |
|---|---|
| 13688 | ROB enqueue lane 4 is valid and `canAccept=1`: PC `0x80000790`, instruction `0x0230d157` (`vfadd.vf v2,v3,ft1`), full ROB `(flag=0,value=0xe)`, vector physical destination `0x31` (49). The producer `fld ft1,0(a2)` at PC `0x80000780` is valid on lane 0, ROB `(0,0xa)`, FP destination `0x22` (34). |
| 13695 | FP RF port 4 writes physical register `0x22` with the complete 64-bit value `0x000000003f800000`. The target issue input is valid with ROB `(0,0xe)`, FP source select enabled and physical source 0 equal to `0x22`. |
| 13698 | EXU input is valid with ROB `(0,0xe)`, `uopIdx=0`, `pdest=0x31`, `vsew=2` (e32), and `vl=4`. Source 0 selects FP (`fpRen_0=1`), `bypassDelay_0=1`, and bypass source index 4. Selected `bypass.in_fpWb1_4` is `0x000000003f800000`; `bypass.out_src_0` and valid `Vfmac.in_ex0Next.bits.data.src_0` are `0x3f8000003f8000003f8000003f800000`. |
| 13698 | Vfmac operand 1 is `0x3f000000c0400000400000003f800000`, encoding vector elements `{1.0,2.0,-3.0,0.5}` from low to high. The selected scalar operand contains four copies of `1.0`, not canonical NaN. |
| 13700 | `Vfmac.out_ex_1.valid=1` and raw vector result is `0x3fc00000c00000004040000040000000`. EXU output is valid with ROB `(0,0xe)`, `toVpRf.wen=1`, `pdest=0x31`, and the same data. Vfmac stage-1 control also carries ROB `(0,0xe)` and destination `0x31`. |
| 13701–13702 | Actual vector RF port 0 writes address `0x31` with that result at 13701; physical vector register 49 reads it at 13702. Commit lane 0 at 13702 is valid for PC `0x80000790`, opcode `0x0230d157`, `vecwen=1`, `wdest=2`, `wpdest=0x31`. |

The stored result encodes `{2.0,3.0,-2.0,1.5}`. It agrees with the original difftest log and differs from the expected four canonical NaNs (`0x7fc00000` each). The expected values are an interpretation supported by the report's specification evidence; they are not invented waveform signals.

There is a flush at 13693, ROB `(0,0x11)`, level 0. This is younger than target `(0,0xe)` in ROB order; the target proceeds to execute and commit. Flush values are retained in `execute-samples.json`.

## Relationship to the report and source

The actual selected input is the **FP bypass**, with the full unboxed value retained before its low 32 bits are replicated. The separate `in_fpRdData_0` port is not selected on this cycle and contains an unrelated value; interpreting that unselected port as the operand would be incorrect. `BypassNetwork.scala:50–58` selects the bypass value for `delay1`; `:23–28` replicates its low SEW bits. See the pinned [BypassNetwork source](https://github.com/OpenXiangShan/XiangShan/blob/b9636416b81d266f3a3d4d1e46d4e66e6a574bcd/src/main/scala/xiangshan/backend/vector/BypassNetwork.scala#L23-L58).

The trace therefore directly supports the report's operand-validation concern for this selected vector execution: the malformed box reaches Vfmac as repeated ordinary single-precision `1.0` and produces a finite result. This is stronger than inferring the path solely from an architectural mismatch. It does not establish an exhaustive cause for every vector FP operation, or prove that a particular code change fixes the implementation. No fix-and-retest was performed.

The scalar `fadd.s` control in the original report is separate, earlier execution. This focused waveform figure does not claim to independently trace that control's full pipeline; its successful canonical-NaN result remains supported by the preserved runtime log.

## Reproducibility and signal identities

- The original raw FST is retained separately in the complete 20260926 evidence archive. This submission contains extracted samples and the figure; the original trace SHA-256 and replay command are in [run.json](run.json).
- `selection.json` and `samples.json`: precise plotted signal paths, widths, sample indices, timestamps and full hexadecimal values. Panels use stated, different zoom windows with one common trace origin.
- `locate-`, `execute-`, `input-`, `output-selection.json` / `*-samples.json`: wider supporting evidence for full ROB identity, producer/source physical register, selected bypass, FU valid, output/write enables, physical state, retirement and flush.
- Active 128-bit operand/result labels in the figure are split upper-64/lower-64 for readability; exact values are retained in JSON. Only long inactive unrelated values are abbreviated in the image.
- Extraction uses the user-provided wavekit `FstReader`, clock `TOP.clock`, `sample_on_posedge=False`. Native timestamps imply no assumed physical clock frequency.

Target execution prefix: `TOP.SimTop.cpu.l_soc.core_with_l2.core.backend.inner_vecRegion.issuePipes.exu`; producer write endpoint: `...backend.inner_fpRegion.fpRegFile`; actual vector RF write endpoint: `...backend.inner_vecRegion.vfRegFile`. A generic integer/FP commit-data field is not used as the vector result.
