#include <klib.h>
#include <stdint.h>

/*
 * VEC-01: keep-VL vsetvli with unchanged VLMAX must stay legal.
 *
 * Contract (RVV): vsetvli x0, x0, <new vtype> is reserved only when VLMAX
 * changes. e8/m1 and e16/m2 have the same VLMAX, so the second vsetvli must
 * keep VL and accept the new vtype (vill=0).
 *
 * DUT execute path (VSetFuncUnit on DefaultConfig / CI emu) treats
 * (vlmax & oldVlmax).orR as "VLMAX changed", which is equality.
 */

#define MSTATUS_VS (3UL << 9)
#define MSTATUS_FS (3UL << 13)
#define VTYPE_VILL (1UL << 63)

int main(void) {
  uint64_t vl1 = 0, vl2 = 0, vtype = 0, mstatus = 0;

  printf("vec01-keepvl-polarity start\n");

  asm volatile("csrr %0, mstatus" : "=r"(mstatus));
  mstatus |= MSTATUS_VS | MSTATUS_FS;
  asm volatile("csrw mstatus, %0" :: "r"(mstatus) : "memory");

  /* VLMAX(e8,m1) = VLEN/8. Request AVL=4 so VL is a stable non-zero keep value. */
  asm volatile("vsetvli %0, %1, e8, m1, tu, mu" : "=r"(vl1) : "r"(4UL));
  /* Same VLMAX: VLEN*2/16 = VLEN/8. Keep VL, change policy bits. */
  asm volatile("vsetvli zero, zero, e16, m2, ta, ma");
  asm volatile("csrr %0, vl" : "=r"(vl2));
  asm volatile("csrr %0, vtype" : "=r"(vtype));

  printf("vl1=%lu vl2=%lu vtype=0x%lx vill=%lu\n",
         vl1, vl2, vtype, (vtype & VTYPE_VILL) != 0);

  if (vl1 != 4) {
    printf("FAIL vec01 unexpected initial vl\n");
    return 1;
  }
  if ((vtype & VTYPE_VILL) != 0) {
    printf("FAIL vec01 keep-vl same-vlmax set vill\n");
    return 1;
  }
  if (vl2 != vl1) {
    printf("FAIL vec01 keep-vl dropped vl\n");
    return 1;
  }

  printf("vec01-keepvl-polarity pass\n");
  return 0;
}
