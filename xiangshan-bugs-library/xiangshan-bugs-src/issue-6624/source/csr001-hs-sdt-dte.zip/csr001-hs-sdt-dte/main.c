#include <klib.h>
#include <stdint.h>

/*
 * CSR-001: HS double-trap must use the DTE-visible sstatus.SDT, not raw
 * mstatus.SDT. With menvcfg.DTE=0, leftover mstatus.SDT=1 must not upgrade
 * a delegated HS breakpoint into EX_DBLTRP=16.
 *
 * Wave-1 miss: empty PMP denied S-mode fetch (mcause=1). This AM installs
 * an unlocked NAPOT identity PMP (R=W=X=1) before mret.
 */

#define MSTATUS_MPP_S    (1UL << 11)
#define MSTATUS_SDT      (1UL << 24)
#define MENVCFG_DTE      (1UL << 59)
#define CAUSE_BREAKPOINT 3UL
#define CAUSE_DBLTRP     16UL
#define CAUSE_ECALL_S    9UL
#define PMP_R            (1UL << 0)
#define PMP_W            (1UL << 1)
#define PMP_X            (1UL << 2)
#define PMP_A_NAPOT      (3UL << 3)

static volatile uint64_t m_trap_count;
static volatile uint64_t m_mcause;
static volatile uint64_t s_trap_count;
static volatile uint64_t s_scause;
static volatile uint64_t m_continue;

void m_trap(void);
void s_trap(void);
void s_entry(void);

__attribute__((naked, aligned(4))) void m_trap(void) {
  asm volatile(
    "csrr t0, mcause\n\t"
    "la t1, m_mcause\n\t"
    "sd t0, 0(t1)\n\t"
    "la t1, m_trap_count\n\t"
    "ld t2, 0(t1)\n\t"
    "addi t2, t2, 1\n\t"
    "sd t2, 0(t1)\n\t"
    "la t1, m_continue\n\t"
    "ld t0, 0(t1)\n\t"
    "csrw mepc, t0\n\t"
    "li t0, 0x1800\n\t"
    "csrs mstatus, t0\n\t"
    "mret\n\t");
}

__attribute__((naked, aligned(4))) void s_trap(void) {
  asm volatile(
    "csrr t0, scause\n\t"
    "la t1, s_scause\n\t"
    "sd t0, 0(t1)\n\t"
    "la t1, s_trap_count\n\t"
    "ld t2, 0(t1)\n\t"
    "addi t2, t2, 1\n\t"
    "sd t2, 0(t1)\n\t"
    "ecall\n\t");
}

__attribute__((naked, aligned(4))) void s_entry(void) {
  asm volatile(
    "ebreak\n\t"
    "ecall\n\t");
}

static void pmp_allow_all(void) {
  asm volatile("csrw 0x3a0, x0" ::: "memory");
  asm volatile("csrw 0x3b0, %0" :: "r"(~(uintptr_t)0) : "memory");
  asm volatile("csrw 0x3a0, %0" :: "r"(PMP_A_NAPOT | PMP_R | PMP_W | PMP_X) : "memory");
}

int main(void) {
  uint64_t menvcfg, mstatus;

  printf("csr001-hs-sdt-dte start\n");
  pmp_allow_all();
  asm volatile("csrw satp, x0" ::: "memory");
  asm volatile("sfence.vma" ::: "memory");
  asm volatile("csrw mtvec, %0" :: "r"(m_trap) : "memory");
  asm volatile("csrw stvec, %0" :: "r"(s_trap) : "memory");

  /* Leave a raw mstatus.SDT=1 behind a closed DTE. */
  asm volatile("csrr %0, 0x30a" : "=r"(menvcfg));
  menvcfg |= MENVCFG_DTE;
  asm volatile("csrw 0x30a, %0" :: "r"(menvcfg) : "memory");
  asm volatile("csrr %0, mstatus" : "=r"(mstatus));
  mstatus |= MSTATUS_SDT;
  asm volatile("csrw mstatus, %0" :: "r"(mstatus) : "memory");
  menvcfg &= ~MENVCFG_DTE;
  asm volatile("csrw 0x30a, %0" :: "r"(menvcfg) : "memory");

  asm volatile("csrw medeleg, %0" :: "r"(1UL << CAUSE_BREAKPOINT) : "memory");

  m_trap_count = s_trap_count = 0;
  m_mcause = s_scause = 0;

  asm volatile(
    "la t0, 1f\n\t"
    "sd t0, m_continue, t1\n\t"
    "csrr t0, mstatus\n\t"
    "li t1, 0x1888\n\t"
    "not t1, t1\n\t"
    "and t0, t0, t1\n\t"
    "li t1, 0x800\n\t"
    "or t0, t0, t1\n\t"
    "csrw mstatus, t0\n\t"
    "la t0, s_entry\n\t"
    "csrw mepc, t0\n\t"
    "mret\n\t"
    "1:\n\t"
    ::: "t0", "t1", "memory");

  printf("m_trap=%lu mcause=%lu s_trap=%lu scause=%lu\n",
         m_trap_count, m_mcause, s_trap_count, s_scause);

  if (m_mcause == CAUSE_DBLTRP) {
    printf("FAIL csr001 leftover SDT raised HS double-trap\n");
    return 1;
  }
  if (s_trap_count == 0 || s_scause != CAUSE_BREAKPOINT) {
    printf("FAIL csr001 breakpoint did not enter HS\n");
    return 1;
  }
  if (m_mcause != CAUSE_ECALL_S) {
    printf("FAIL csr001 unexpected M cause after HS handler\n");
    return 1;
  }

  printf("csr001-hs-sdt-dte pass\n");
  return 0;
}
