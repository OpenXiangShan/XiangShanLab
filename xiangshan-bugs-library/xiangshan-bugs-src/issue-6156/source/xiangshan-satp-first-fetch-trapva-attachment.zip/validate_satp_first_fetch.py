#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path


EXPECTED_BARE_PC = 0x0000004000000004
WRONG_SV39_PC = 0xFFFFFFC000000004
IPF_CAUSE = 12
SATP_MODE_SV39 = 8

SIGNALS = {
    "satp_mode": "io_csrio_tlb_satp_mode",
    "rob_exception_valid": "io_robio_exception_valid",
    "exception_vec_ipf": "io_csrio_exception_bits_exceptionVec_12",
    "trap_mepc_valid": "trapToM_mepc_valid",
    "trap_mepc_epc": "trapToM_mepc_bits_epc",
    "trap_mtval": "trapToM_mtval_bits_ALL",
    "trap_mcause": "trapToM_mcause_bits_ExceptionCode",
    "diff_mepc": "diffCSRState_csr_mepc",
    "diff_mtval": "diffCSRState_csr_mtval",
    "diff_mcause": "diffCSRState_csr_mcause",
    "diff_satp": "diffCSRState_csr_satp",
}

REQUIRED = {
    "satp_mode",
    "rob_exception_valid",
    "exception_vec_ipf",
    "trap_mepc_valid",
    "trap_mepc_epc",
    "trap_mtval",
    "trap_mcause",
    "diff_mepc",
    "diff_mtval",
    "diff_mcause",
}


def bits_to_int(bits):
    bits = bits.strip().lower()
    if not bits or "x" in bits or "z" in bits:
        return None
    return int(bits, 2)


def parse_header(vcd_path):
    code_to_fields = {}
    field_to_codes = {field: [] for field in SIGNALS}
    with vcd_path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if not line.startswith("$var "):
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            code = parts[3]
            leaf = parts[4].lstrip("\\")
            leaf = leaf.split()[0]
            for field, expected_leaf in SIGNALS.items():
                if leaf == expected_leaf:
                    code_to_fields.setdefault(code, set()).add(field)
                    field_to_codes[field].append(code)

    missing = sorted(field for field in REQUIRED if not field_to_codes[field])
    if missing:
        raise SystemExit("missing required VCD signals: " + ", ".join(missing))
    return code_to_fields, field_to_codes


def parse_vcd(vcd_path):
    code_to_fields, field_to_codes = parse_header(vcd_path)
    tracked = set(code_to_fields)
    values = {field: None for field in SIGNALS}
    observations = {
        "satp_mode_sv39": [],
        "instruction_page_fault": [],
        "trap_to_m_wrong_mepc": [],
        "trap_to_m_wrong_mtval": [],
        "trap_to_m_ipf_cause": [],
        "diff_wrong_mepc": [],
        "diff_wrong_mtval": [],
        "diff_ipf_cause": [],
    }
    csr_timeline = []
    time = None
    in_body = False

    def observe(fields, value):
        nonlocal time
        if value is None:
            return
        for field in fields:
            values[field] = value

        if values["satp_mode"] == SATP_MODE_SV39 and any(f == "satp_mode" for f in fields):
            observations["satp_mode_sv39"].append({"time": time, "value": values["satp_mode"]})

        if values["rob_exception_valid"] == 1 and values["exception_vec_ipf"] == 1:
            observations["instruction_page_fault"].append({"time": time})

        if values["trap_mepc_valid"] == 1 and values["trap_mepc_epc"] is not None:
            trap_pc = (values["trap_mepc_epc"] << 1) & ((1 << 64) - 1)
            if trap_pc == WRONG_SV39_PC:
                observations["trap_to_m_wrong_mepc"].append({"time": time, "value": f"0x{trap_pc:016x}"})

        if values["trap_mepc_valid"] == 1 and values["trap_mtval"] == WRONG_SV39_PC:
            observations["trap_to_m_wrong_mtval"].append({"time": time, "value": f"0x{values['trap_mtval']:016x}"})

        if values["trap_mepc_valid"] == 1 and values["trap_mcause"] == IPF_CAUSE:
            observations["trap_to_m_ipf_cause"].append({"time": time, "value": f"0x{values['trap_mcause']:x}"})

        if "diff_mepc" in fields and values["diff_mepc"] == WRONG_SV39_PC:
            observations["diff_wrong_mepc"].append({"time": time, "value": f"0x{values['diff_mepc']:016x}"})

        if "diff_mtval" in fields and values["diff_mtval"] == WRONG_SV39_PC:
            observations["diff_wrong_mtval"].append({"time": time, "value": f"0x{values['diff_mtval']:016x}"})

        if "diff_mcause" in fields and values["diff_mcause"] == IPF_CAUSE:
            observations["diff_ipf_cause"].append({"time": time, "value": f"0x{values['diff_mcause']:x}"})

        if {"diff_mepc", "diff_mtval", "diff_mcause"} & set(fields):
            csr_timeline.append(
                {
                    "time": time,
                    "satp_mode": values["satp_mode"],
                    "mepc": None if values["diff_mepc"] is None else f"0x{values['diff_mepc']:016x}",
                    "mtval": None if values["diff_mtval"] is None else f"0x{values['diff_mtval']:016x}",
                    "mcause": None if values["diff_mcause"] is None else f"0x{values['diff_mcause']:016x}",
                    "satp": None if values["diff_satp"] is None else f"0x{values['diff_satp']:016x}",
                }
            )

    with vcd_path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if not line:
                continue
            head = line[0]
            if head == "#":
                time = int(line[1:])
                continue
            if head in "01xXzZ":
                code = line[1:]
                if code in tracked:
                    value = None if head in "xXzZ" else int(head)
                    observe(code_to_fields[code], value)
                continue
            if head in "bB":
                try:
                    bits, code = line[1:].split(None, 1)
                except ValueError:
                    continue
                if code in tracked:
                    observe(code_to_fields[code], bits_to_int(bits))

    return {
        "codes": {field: sorted(codes) for field, codes in field_to_codes.items() if codes},
        "observations": observations,
        "csr_timeline_tail": csr_timeline[-12:],
    }


def parse_log(log_path):
    text = log_path.read_text(errors="replace")
    checks = {
        "committed_satp_write": re.search(
            r"\[\d+\] commit pc 0000004000000000 inst 18051073 .*csrw\s+satp", text
        ),
        "wrong_exception_pc": re.search(
            r"\[\d+\] exception pc ffffffc000000004 inst 00000000 cause 000000000000000c", text
        ),
        "mepc_mismatch": re.search(
            r"mepc different at pc = 0x0080000024, right = 0x0000004000000004, wrong = 0xffffffc000000004",
            text,
        ),
        "mtval_mismatch": re.search(
            r"mtval different at pc = 0x0080000024, right = 0x0000004000000004, wrong = 0xffffffc000000004",
            text,
        ),
    }
    return {
        "all_required_lines_present": all(checks.values()),
        "matches": {name: None if match is None else match.group(0) for name, match in checks.items()},
    }


def main():
    if len(sys.argv) != 4:
        print("usage: validate_satp_first_fetch.py <wave.vcd> <run.log> <out.json>", file=sys.stderr)
        return 2

    vcd_path = Path(sys.argv[1])
    log_path = Path(sys.argv[2])
    out_path = Path(sys.argv[3])

    vcd = parse_vcd(vcd_path)
    log = parse_log(log_path)
    obs = vcd["observations"]
    reproduced = (
        bool(obs["satp_mode_sv39"])
        and bool(obs["instruction_page_fault"])
        and bool(obs["trap_to_m_wrong_mepc"])
        and bool(obs["trap_to_m_wrong_mtval"])
        and bool(obs["trap_to_m_ipf_cause"])
        and bool(obs["diff_wrong_mepc"])
        and bool(obs["diff_wrong_mtval"])
        and bool(obs["diff_ipf_cause"])
        and log["all_required_lines_present"]
    )
    result = {
        "predicate": "reproduced" if reproduced else "failed",
        "expected_bare_fault_pc": f"0x{EXPECTED_BARE_PC:016x}",
        "observed_wrong_sv39_fault_pc": f"0x{WRONG_SV39_PC:016x}",
        "vcd_path": str(vcd_path),
        "log_path": str(log_path),
        "vcd": vcd,
        "log": log,
    }
    out_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if reproduced else 1


if __name__ == "__main__":
    raise SystemExit(main())
