#!/usr/bin/env bash
set -euo pipefail

XS_EMU="${XS_EMU:-/path/to/XiangShan/build/emu}"
XS_DIFF="${XS_DIFF:-/path/to/XiangShan/ready-to-run/riscv64-nemu-interpreter-so}"
RISCV_GCC="${RISCV_GCC:-riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-riscv64-unknown-elf-objdump}"

if [[ ! -x "$XS_EMU" ]]; then
  echo "XS_EMU does not point to an executable: $XS_EMU" >&2
  exit 2
fi

if [[ ! -f "$XS_DIFF" ]]; then
  echo "XS_DIFF does not point to a reference model: $XS_DIFF" >&2
  exit 2
fi

"$RISCV_GCC" \
  -march=rv64gc -mabi=lp64 -mcmodel=medany \
  -nostdlib -nostartfiles \
  -T linker.ld \
  -o poc.elf \
  poc.S

"$RISCV_OBJCOPY" -O binary poc.elf poc.bin
"$RISCV_OBJDUMP" -d -s poc.elf > poc.objdump

"$XS_EMU" \
  --max-cycles=20000 \
  -b 0 -e 0 \
  --dump-commit-trace \
  -i poc.bin \
  --diff "$XS_DIFF" \
  > validation_nodump_diff.log 2>&1 || true

"$XS_EMU" \
  --max-cycles=1700 \
  -b 1450 -e 1560 \
  --dump-wave-full \
  --wave-path=validation_satp_fault_1450_1560.vcd \
  --dump-commit-trace \
  -i poc.bin \
  --diff "$XS_DIFF" \
  > validation_wave_diff.log 2>&1 || true

python3 validate_satp_first_fetch.py \
  validation_satp_fault_1450_1560.vcd \
  validation_wave_diff.log \
  validation_monitor.json \
  > validation_monitor.log
