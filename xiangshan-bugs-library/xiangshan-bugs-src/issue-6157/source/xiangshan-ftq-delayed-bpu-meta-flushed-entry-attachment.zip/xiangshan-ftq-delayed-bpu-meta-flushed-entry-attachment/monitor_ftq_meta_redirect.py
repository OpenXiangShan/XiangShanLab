#!/usr/bin/env python3
import argparse
import json
import os
import re


FTQ_SIZE = 8
FTQ_MODULO = 16


TARGET_PATTERNS = {
    "redirect_valid": r"\.inner_ftq\.io_toBpu_redirect_valid$",
    "backend_redirect_valid": r"\.inner_ftq\.io_fromBackend_redirect_valid$",
    "from_bpu_meta_valid": r"\.inner_ftq\.io_fromBpu_meta_valid$",
    "from_bpu_s3_ptr_flag": r"\.inner_ftq\.io_fromBpu_s3FtqPtr_flag$",
    "from_bpu_s3_ptr_value": r"\.inner_ftq\.io_fromBpu_s3FtqPtr_value$",
    "from_bpu_pred_valid": r"\.inner_ftq\.io_fromBpu_prediction_valid$",
    "from_bpu_pred_ready": r"\.inner_ftq\.io_fromBpu_prediction_ready$",
    "to_backend_wen": r"\.inner_ftq\.io_toBackend_wen$",
    "bpu_enqueue": r"\.inner_ftq\.bpuEnqueue$",
    "bpu_s3_redirect": r"\.inner_ftq\.bpuS3Redirect$",
    "new_entry_ptr_flag": r"\.inner_ftq\.newEntryPtr_flag$",
    "new_entry_ptr_value": r"\.inner_ftq\.newEntryPtr_value$",
    "bpu_ptr_flag": r"\.inner_ftq\.bpuPtr_ptrs_0_flag$",
    "bpu_ptr_value": r"\.inner_ftq\.bpuPtr_ptrs_0_value$",
    "redirect_cfi_pc": r"\.inner_ftq\.io_toBpu_redirect_bits_cfiPc_addr$",
    "redirect_target": r"\.inner_ftq\.io_toBpu_redirect_bits_target_addr$",
    "redirect_ras_action": r"\.inner_ftq\.io_toBpu_redirect_bits_attribute_rasAction$",
}

REQUIRED = [
    "redirect_valid",
    "from_bpu_meta_valid",
    "from_bpu_s3_ptr_flag",
    "from_bpu_s3_ptr_value",
    "from_bpu_pred_valid",
    "from_bpu_pred_ready",
    "to_backend_wen",
    "bpu_enqueue",
    "new_entry_ptr_flag",
    "new_entry_ptr_value",
    "bpu_ptr_flag",
    "bpu_ptr_value",
]


def normalize(name):
    name = re.sub(r"\s+\[[^\]]+\]$", "", name)
    return name.replace("[", "_").replace("]", "").replace(":", "_")


def bits_to_int(bits):
    if any(ch in bits for ch in "xXzZ"):
        return None
    return int(bits, 2)


def parse_header(vcd_path):
    var_re = re.compile(r"^\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")
    scopes = []
    code_names = {}
    targets = {}
    header_lines = 0
    with open(vcd_path, "r", errors="replace") as fh:
        for raw in fh:
            header_lines += 1
            line = raw.strip()
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scopes.append(parts[2])
            elif line.startswith("$upscope"):
                if scopes:
                    scopes.pop()
            elif line.startswith("$var "):
                match = var_re.match(line)
                if not match:
                    continue
                code, raw_name = match.groups()
                full_name = normalize(".".join(scopes + [raw_name]))
                code_names.setdefault(code, []).append(full_name)
                for key, pattern in TARGET_PATTERNS.items():
                    if key not in targets and re.search(pattern, full_name):
                        targets[key] = code
            elif line.startswith("$enddefinitions"):
                break
    return targets, code_names, header_lines


def parse_value(raw):
    line = raw.strip()
    if not line:
        return None, None
    if line[0] in "01xXzZ":
        return line[1:], None if line[0] in "xXzZ" else int(line[0])
    if line[0] in "bB":
        parts = line.split()
        if len(parts) != 2:
            return None, None
        return parts[1], bits_to_int(parts[0][1:])
    return None, None


def abs_ptr(flag, value):
    if flag is None or value is None:
        return None
    return flag * FTQ_SIZE + value


def distance(start, end):
    if start is None or end is None:
        return None
    value = end - start
    if value < 0:
        value += FTQ_MODULO
    return value


def run_monitor(vcd_path, max_events):
    targets, code_names, header_lines = parse_header(vcd_path)
    missing = [key for key in REQUIRED if key not in targets]
    result = {
        "predicate_result": "not_satisfied",
        "waveform_path": os.path.abspath(vcd_path),
        "waveform_format": "vcd",
        "header_lines": header_lines,
        "signals_observed": {
            key: {"code": code, "names": code_names.get(code, [])[:6]}
            for key, code in sorted(targets.items())
        },
        "counts": {
            "redirect_cycles": 0,
            "meta_valid_cycles": 0,
            "meta_valid_during_redirect": 0,
            "meta_valid_during_redirect_without_enqueue": 0,
            "meta_valid_for_redirect_flushed_entry": 0,
            "prediction_fire_during_redirect": 0,
        },
        "evidence": [],
        "errors": [],
    }
    if missing:
        result["errors"].append("missing required signals: " + ", ".join(missing))
        return result

    values = {}
    current_time = None
    target_codes = set(targets.values())

    def val(key):
        code = targets.get(key)
        return None if code is None else values.get(code)

    def evaluate_time():
        nonlocal current_time
        if current_time is None:
            return
        redirect = val("redirect_valid") == 1
        meta_valid = val("from_bpu_meta_valid") == 1
        pred_fire = val("from_bpu_pred_valid") == 1 and val("from_bpu_pred_ready") == 1
        if redirect:
            result["counts"]["redirect_cycles"] += 1
        if meta_valid:
            result["counts"]["meta_valid_cycles"] += 1
        if redirect and pred_fire:
            result["counts"]["prediction_fire_during_redirect"] += 1
        if redirect and meta_valid:
            result["counts"]["meta_valid_during_redirect"] += 1
        if not (redirect and meta_valid and val("bpu_enqueue") == 0 and val("to_backend_wen") == 0):
            return

        result["counts"]["meta_valid_during_redirect_without_enqueue"] += 1
        s3_ptr = abs_ptr(val("from_bpu_s3_ptr_flag"), val("from_bpu_s3_ptr_value"))
        new_ptr = abs_ptr(val("new_entry_ptr_flag"), val("new_entry_ptr_value"))
        old_bpu_ptr = abs_ptr(val("bpu_ptr_flag"), val("bpu_ptr_value"))
        flushed_span = distance(new_ptr, old_bpu_ptr)
        s3_distance = distance(new_ptr, s3_ptr)
        in_flushed_interval = (
            flushed_span is not None
            and s3_distance is not None
            and flushed_span > 0
            and s3_distance < flushed_span
        )
        if not in_flushed_interval:
            return

        result["counts"]["meta_valid_for_redirect_flushed_entry"] += 1
        if len(result["evidence"]) >= max_events:
            return
        result["evidence"].append({
            "time": current_time,
            "redirect_valid": val("redirect_valid"),
            "backend_redirect_valid": val("backend_redirect_valid"),
            "from_bpu_meta_valid": val("from_bpu_meta_valid"),
            "from_bpu_s3_ptr": [val("from_bpu_s3_ptr_flag"), val("from_bpu_s3_ptr_value")],
            "new_entry_ptr": [val("new_entry_ptr_flag"), val("new_entry_ptr_value")],
            "old_bpu_ptr": [val("bpu_ptr_flag"), val("bpu_ptr_value")],
            "flushed_span_from_new_entry_to_old_bpu_ptr": flushed_span,
            "s3_distance_from_new_entry_ptr": s3_distance,
            "bpu_enqueue": val("bpu_enqueue"),
            "to_backend_wen": val("to_backend_wen"),
            "from_bpu_prediction_valid": val("from_bpu_pred_valid"),
            "from_bpu_prediction_ready": val("from_bpu_pred_ready"),
            "bpu_s3_redirect": val("bpu_s3_redirect"),
            "redirect_cfi_pc_raw": val("redirect_cfi_pc"),
            "redirect_target_raw": val("redirect_target"),
            "redirect_ras_action": val("redirect_ras_action"),
        })

    with open(vcd_path, "r", errors="replace") as fh:
        for line in fh:
            if line.startswith("$"):
                continue
            if line.startswith("#"):
                evaluate_time()
                try:
                    current_time = int(line[1:].strip())
                except ValueError:
                    current_time = None
                continue
            code, value = parse_value(line)
            if code in target_codes:
                values[code] = value
    evaluate_time()

    if result["counts"]["meta_valid_for_redirect_flushed_entry"] > 0:
        result["predicate_result"] = "satisfied"
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vcd", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-events", type=int, default=16)
    args = parser.parse_args()
    result = run_monitor(args.vcd, args.max_events)
    with open(args.out, "w") as fh:
        json.dump(result, fh, indent=2, sort_keys=True)
        fh.write("\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
