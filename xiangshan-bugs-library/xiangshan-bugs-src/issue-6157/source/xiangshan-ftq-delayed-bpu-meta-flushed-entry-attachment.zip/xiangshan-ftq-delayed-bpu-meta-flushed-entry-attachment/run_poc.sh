#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build/emu}"
DIFF="${DIFF:-/root/HardwareAgent/XiangShan/ready-to-run/riscv64-nemu-interpreter-so}"

PREFIX="${PREFIX:-validation_ftq_delayed_bpu_meta}"
CYCLES="${CYCLES:-1500}"
WAVE_BEGIN="${WAVE_BEGIN:-0}"
WAVE_END="${WAVE_END:-1500}"
TIMEOUT_SECS="${TIMEOUT_SECS:-120}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
WAVE="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
RUN_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.run.log"
MONITOR_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
MONITOR_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"
DIFF_LOG="${PREFIX}_diff.run.log"

"$RISCV_GCC" \
  -nostdlib -nostartfiles \
  -march=rv64gc \
  -mabi=lp64 \
  -T linker.ld \
  -o "$ELF" \
  poc.S

"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -d "$ELF" > "$OBJDUMP"

timeout "${TIMEOUT_SECS}s" "$EMU" \
  -i "$BIN" \
  --no-diff \
  -C "$CYCLES" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  --dump-wave \
  --wave-path="$WAVE" \
  > "$RUN_LOG" 2>&1

python3 ./monitor_ftq_meta_redirect.py \
  --vcd "$WAVE" \
  --out "$MONITOR_JSON" \
  > "$MONITOR_LOG"

if [[ -n "$DIFF" && -e "$DIFF" ]]; then
  timeout "${TIMEOUT_SECS}s" "$EMU" \
    -b 0 \
    -e 0 \
    -i "$BIN" \
    --diff "$DIFF" \
    -C "$CYCLES" \
    > "$DIFF_LOG" 2>&1
fi

python3 - "$MONITOR_JSON" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
data = json.loads(path.read_text())
counts = data.get("counts", {})

print("predicate_result =", data.get("predicate_result"))
for key in (
    "redirect_cycles",
    "meta_valid_cycles",
    "meta_valid_during_redirect",
    "meta_valid_during_redirect_without_enqueue",
    "meta_valid_for_redirect_flushed_entry",
    "prediction_fire_during_redirect",
):
    print(f"{key} =", counts.get(key))

if data.get("predicate_result") != "satisfied":
    raise SystemExit(1)
PY
