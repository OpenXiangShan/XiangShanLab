xiangshan vf-compare-fflags reproducer
======================================

Issue: [BUG] Vector floating-point comparisons do not set fflags.NV on NaN inputs

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: 8c34b5c136f0fe51a65573fa385f0b304094f6103b907653e7d6c09a5c7ed963

prog.c
    Reproducer source.
    SHA-256: b8818cc9e449fa15db6f66ef3899987e7bb3ed88d8949e8ed864263e3c75b839

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: c185ce873e70a9557cc5dd41cca8e7c631970561edd56949ddacaeb8d2370b50

sim.log
    Difftest log of the failing run.
    SHA-256: 176f3b028cec7d6d307a3dd0c79832d43ca6ce07285178af3de80f425cad17d3

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures SEW=16, LMUL=m1, loads a signaling NaN pattern into `v1`, and executes `vmfge.vf` at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB.
- Run the same ELF on the Spike difftest reference and compare `fcsr` at the probe.

Expected:
  For `vmfge.vf` SEW=16 with a signaling NaN operand, `fcsr` must become `0x0000000000000010` (`NV`).

Observed:
  The DUT leaves all flags clear:
  
  ```text
     fcsr different at pc = 0xffffd688bf579564, right = 0x0000000000000010, wrong = 0x0000000000000000
  Core 0: ABORT at pc = 0xffffd688bf579564
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
