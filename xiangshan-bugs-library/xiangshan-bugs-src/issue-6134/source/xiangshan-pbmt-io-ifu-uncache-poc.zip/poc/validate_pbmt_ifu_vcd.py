#!/usr/bin/env python3
import json
import sys


EXPECTED_PATHS = {
    "s2_pbmt": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.s2_icacheMeta_0_itlbPbmt",
    "s2_pmp_mmio": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.s2_icacheMeta_0_pmpMmio",
    "s3_use_uncache": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.s3_useUncacheFetch",
    "s3_pmp_mmio": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.s3_icacheMeta_0_pmpMmio",
    "to_uncache_valid": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend._inner_ifu_io_toUncache_req_valid",
    "to_uncache_ready": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.io_toUncache_req_ready",
    "to_uncache_addr": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend._inner_ifu_io_toUncache_req_bits_addr_addr",
    "backend_empty": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.io_backendEmpty",
    "ibuffer_empty": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.io_ibufferEmpty",
    "is_first_instr": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.isFirstInstr",
    "uncache_state": "TOP.SimTop.cpu.l_soc.core_with_l2.core.frontend.inner_ifu.uncacheUnit.uncacheState",
}

FALLBACK_SUFFIXES = {
    "s2_pbmt": ".inner_ifu.s2_icacheMeta_0_itlbPbmt",
    "s2_pmp_mmio": ".inner_ifu.s2_icacheMeta_0_pmpMmio",
    "s3_use_uncache": ".inner_ifu.s3_useUncacheFetch",
    "s3_pmp_mmio": ".inner_ifu.s3_icacheMeta_0_pmpMmio",
    "to_uncache_valid": ".frontend._inner_ifu_io_toUncache_req_valid",
    "to_uncache_ready": ".inner_ifu.io_toUncache_req_ready",
    "to_uncache_addr": ".frontend._inner_ifu_io_toUncache_req_bits_addr_addr",
    "backend_empty": ".inner_ifu.io_backendEmpty",
    "ibuffer_empty": ".inner_ifu.io_ibufferEmpty",
    "is_first_instr": ".inner_ifu.isFirstInstr",
    "uncache_state": ".inner_ifu.uncacheUnit.uncacheState",
}


def clean_name(name):
    return name.replace("\\", "").split("[", 1)[0]


def parse_value_token(line):
    if line[0] in "01xz":
        return line[0], line[1:]
    if line[0] == "b":
        parts = line.split()
        if len(parts) == 2:
            return parts[0][1:].replace("x", "0").replace("z", "0"), parts[1]
    return None, None


def value_to_int(value):
    if value is None or value in ("x", "z", ""):
        return None
    if set(value) <= {"0", "1"}:
        return int(value, 2)
    return int(value, 10)


def pick_signal_key(path):
    for key, expected in EXPECTED_PATHS.items():
        if path == expected:
            return key
    for key, suffix in FALLBACK_SUFFIXES.items():
        if path.endswith(suffix):
            return key
    return None


def parse_vcd(path, pbmt_max_delta=32):
    id_to_key = {}
    matched_paths = {}
    values = {key: None for key in EXPECTED_PATHS}
    scopes = []
    time = None
    in_header = True
    last_pbmt_io = None
    pbmt_seen = []
    unsafe_events = []
    all_fires = []
    missing_paths = []

    def snapshot():
        return {key: value_to_int(values[key]) for key in values}

    def evaluate_current_time():
        nonlocal last_pbmt_io
        if time is None:
            return

        s2_pbmt = value_to_int(values["s2_pbmt"])
        s2_pmp_mmio = value_to_int(values["s2_pmp_mmio"])
        if s2_pbmt == 2 and s2_pmp_mmio == 0:
            item = {
                "time": time,
                "s2_pbmt": s2_pbmt,
                "s2_pmp_mmio": s2_pmp_mmio,
            }
            if not pbmt_seen or pbmt_seen[-1] != item:
                pbmt_seen.append(item)
            last_pbmt_io = item

        fire = values["to_uncache_valid"] == "1" and values["to_uncache_ready"] == "1"
        if not fire:
            return

        fire_item = {
            "time": time,
            "to_uncache_addr": value_to_int(values["to_uncache_addr"]),
            "s3_use_uncache": value_to_int(values["s3_use_uncache"]),
            "s3_pmp_mmio": value_to_int(values["s3_pmp_mmio"]),
            "backend_empty": value_to_int(values["backend_empty"]),
            "ibuffer_empty": value_to_int(values["ibuffer_empty"]),
            "is_first_instr": value_to_int(values["is_first_instr"]),
            "uncache_state": value_to_int(values["uncache_state"]),
        }
        if not all_fires or all_fires[-1] != fire_item:
            all_fires.append(fire_item)

        unsafe_empty = values["backend_empty"] == "0" or values["ibuffer_empty"] == "0"
        pbmt_recent = (
            last_pbmt_io is not None
            and last_pbmt_io["time"] <= time
            and time - last_pbmt_io["time"] <= pbmt_max_delta
        )
        unsafe = (
            values["s3_use_uncache"] == "1"
            and values["s3_pmp_mmio"] == "0"
            and unsafe_empty
            and values["is_first_instr"] == "0"
            and value_to_int(values["uncache_state"]) == 2
            and pbmt_recent
        )
        if unsafe:
            event = dict(fire_item)
            event["preceding_pbmt_io"] = dict(last_pbmt_io)
            event["pbmt_delta"] = time - last_pbmt_io["time"]
            if not unsafe_events or unsafe_events[-1] != event:
                unsafe_events.append(event)

    with open(path, "r", errors="replace") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue

            if in_header:
                if line.startswith("$scope"):
                    parts = line.split()
                    scopes.append(parts[2])
                elif line.startswith("$upscope"):
                    if scopes:
                        scopes.pop()
                elif line.startswith("$var"):
                    parts = line.split()
                    if len(parts) >= 5:
                        code = parts[3]
                        var_name = clean_name(parts[4])
                        path_name = ".".join(scopes + [var_name])
                        key = pick_signal_key(path_name)
                        if key and key not in matched_paths:
                            id_to_key[code] = key
                            matched_paths[key] = path_name
                elif line == "$enddefinitions $end":
                    in_header = False
                continue

            if line.startswith("#"):
                evaluate_current_time()
                time = int(line[1:])
                continue

            value, code = parse_value_token(line)
            if code is None:
                continue
            key = id_to_key.get(code)
            if key:
                values[key] = value

    evaluate_current_time()

    for key in EXPECTED_PATHS:
        if key not in matched_paths:
            missing_paths.append(EXPECTED_PATHS[key])

    first_event = unsafe_events[0] if unsafe_events else None
    return {
        "predicate": "PASS" if unsafe_events and not missing_paths else "FAIL",
        "predicate_definition": "PBMT-IO s2 observation followed within 32 VCD ticks by a toUncache valid/ready send with s3_use_uncache=1, s3_pmp_mmio=0, uncache_state=2, is_first_instr=0, and backend or ibuffer non-empty.",
        "matched_paths": matched_paths,
        "missing_paths": missing_paths,
        "final_values": snapshot(),
        "pbmt_seen_count": len(pbmt_seen),
        "pbmt_seen_first": pbmt_seen[:5],
        "all_uncache_fire_count": len(all_fires),
        "all_uncache_fire_first": all_fires[:10],
        "unsafe_uncache_fire_count": len(unsafe_events),
        "unsafe_uncache_fire_first": unsafe_events[:10],
        "first_decisive_event": first_event,
    }


def main():
    if len(sys.argv) != 2:
        print("usage: validate_pbmt_ifu_vcd.py <wave.vcd>", file=sys.stderr)
        return 2
    result = parse_vcd(sys.argv[1])
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["predicate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
