#!/usr/bin/env python3
import json
import sys


SIGNALS = {
    "s2_pbmt": ".frontend.inner_ifu.s2_icacheMeta_0_itlbPbmt",
    "s2_pmp_mmio": ".frontend.inner_ifu.s2_icacheMeta_0_pmpMmio",
    "s3_use_uncache": ".frontend.inner_ifu.s3_useUncacheFetch",
    "s3_pmp_mmio": ".frontend.inner_ifu.s3_icacheMeta_0_pmpMmio",
    "to_uncache_valid": ".frontend._inner_ifu_io_toUncache_req_valid",
    "to_uncache_ready": ".frontend.inner_ifu.io_toUncache_req_ready",
    "to_uncache_pruned_addr": ".frontend._inner_ifu_io_toUncache_req_bits_addr_addr",
    "backend_empty": ".frontend.inner_ifu.io_backendEmpty",
    "ibuffer_empty": ".frontend.inner_ifu.io_ibufferEmpty",
    "is_first_instr": ".frontend.inner_ifu.isFirstInstr",
    "ifu_uncache_state": ".frontend.inner_ifu.uncacheUnit.uncacheState",
    "instr_req_valid": ".frontend.inner_instrUncache.io_fromIfu_req_valid",
    "instr_req_ready": ".frontend.inner_instrUncache.io_fromIfu_req_ready",
    "instr_req_pruned_addr": ".frontend.inner_instrUncache.io_fromIfu_req_bits_addr_addr",
    "tl_a_valid": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_valid",
    "tl_a_ready": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_ready",
    "tl_a_address": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_bits_address",
}


def clean_name(name):
    return name.replace("\\", "").split("[", 1)[0]


def parse_value_token(line):
    if not line:
        return None, None
    if line[0] in "01xz":
        return line[0], line[1:]
    if line[0] == "b":
        parts = line.split()
        if len(parts) == 2:
            return parts[0][1:].replace("x", "0").replace("z", "0"), parts[1]
    return None, None


def to_int(value):
    if value is None or value in ("", "x", "z"):
        return None
    return int(value, 2) if set(value) <= {"0", "1"} else int(value)


def pick_key(path):
    for key, suffix in SIGNALS.items():
        if path.endswith(suffix):
            return key
    return None


def parse_vcd(path, max_delta=64):
    id_to_keys = {}
    matched = {}
    values = {key: None for key in SIGNALS}
    scopes = []
    in_header = True
    time = None
    last_pbmt_io = None
    last_unsafe_ifu = None
    ifu_events = []
    instr_events = []
    tl_events = []
    chains = []

    def snapshot(keys):
        return {key: to_int(values[key]) for key in keys}

    def evaluate():
        nonlocal last_pbmt_io, last_unsafe_ifu
        if time is None:
            return

        s2_pbmt = to_int(values["s2_pbmt"])
        s2_pmp_mmio = to_int(values["s2_pmp_mmio"])
        if s2_pbmt == 2 and s2_pmp_mmio == 0:
            last_pbmt_io = {"time": time, "s2_pbmt": s2_pbmt, "s2_pmp_mmio": s2_pmp_mmio}

        to_uncache_fire = values["to_uncache_valid"] == "1" and values["to_uncache_ready"] == "1"
        if to_uncache_fire:
            item = snapshot([
                "s3_use_uncache",
                "s3_pmp_mmio",
                "to_uncache_pruned_addr",
                "backend_empty",
                "ibuffer_empty",
                "is_first_instr",
                "ifu_uncache_state",
            ])
            item["time"] = time
            item["to_uncache_full_addr"] = None
            if item["to_uncache_pruned_addr"] is not None:
                item["to_uncache_full_addr"] = item["to_uncache_pruned_addr"] << 1
            item["preceding_pbmt_io"] = last_pbmt_io
            ifu_events.append(item)

            pbmt_recent = (
                last_pbmt_io is not None
                and last_pbmt_io["time"] <= time
                and time - last_pbmt_io["time"] <= max_delta
            )
            unsafe = (
                pbmt_recent
                and item["s3_use_uncache"] == 1
                and item["s3_pmp_mmio"] == 0
                and item["ifu_uncache_state"] == 2
                and item["is_first_instr"] == 0
                and (item["backend_empty"] == 0 or item["ibuffer_empty"] == 0)
            )
            if unsafe:
                last_unsafe_ifu = dict(item)

        instr_fire = values["instr_req_valid"] == "1" and values["instr_req_ready"] == "1"
        if instr_fire:
            item = snapshot(["instr_req_pruned_addr"])
            item["time"] = time
            item["instr_req_full_addr"] = None
            if item["instr_req_pruned_addr"] is not None:
                item["instr_req_full_addr"] = item["instr_req_pruned_addr"] << 1
            instr_events.append(item)

        tl_fire = values["tl_a_valid"] == "1" and values["tl_a_ready"] == "1"
        if tl_fire:
            item = snapshot(["tl_a_address"])
            item["time"] = time
            tl_events.append(item)
            if (
                last_unsafe_ifu is not None
                and last_unsafe_ifu["time"] <= time
                and time - last_unsafe_ifu["time"] <= max_delta
            ):
                chains.append({
                    "pbmt_io_observed": last_unsafe_ifu["preceding_pbmt_io"],
                    "unsafe_ifu_to_uncache_fire": last_unsafe_ifu,
                    "tl_get_fire": item,
                    "delta_ifu_to_tl": time - last_unsafe_ifu["time"],
                })

    with open(path, "r", errors="replace") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if in_header:
                if line.startswith("$scope"):
                    parts = line.split()
                    scopes.append(parts[2])
                elif line.startswith("$upscope"):
                    if scopes:
                        scopes.pop()
                elif line.startswith("$var"):
                    parts = line.split()
                    if len(parts) >= 5:
                        code = parts[3]
                        path_name = ".".join(scopes + [clean_name(parts[4])])
                        key = pick_key(path_name)
                        if key and key not in matched:
                            matched[key] = path_name
                            id_to_keys.setdefault(code, []).append(key)
                elif line == "$enddefinitions $end":
                    in_header = False
                continue
            if line.startswith("#"):
                evaluate()
                time = int(line[1:])
                continue
            value, code = parse_value_token(line)
            if code is None:
                continue
            keys = id_to_keys.get(code, [])
            for key in keys:
                values[key] = value
    evaluate()

    missing = [key for key in SIGNALS if key not in matched]
    return {
        "predicate": "PASS" if chains and not missing else "FAIL",
        "predicate_definition": (
            "Find a PBMT-IO, non-PMP-MMIO instruction fetch that fires IFU->InstrUncache "
            "while not first instruction and backend/ibuffer are not empty, then observe a "
            "real InstrUncache TileLink A-channel Get within the correlation window."
        ),
        "matched_paths": matched,
        "missing_signals": missing,
        "unsafe_ifu_fire_count": sum(
            1
            for e in ifu_events
            if e.get("preceding_pbmt_io")
            and e["s3_use_uncache"] == 1
            and e["s3_pmp_mmio"] == 0
            and e["ifu_uncache_state"] == 2
            and e["is_first_instr"] == 0
            and (e["backend_empty"] == 0 or e["ibuffer_empty"] == 0)
        ),
        "instr_req_fire_count": len(instr_events),
        "tl_get_fire_count": len(tl_events),
        "attack_chain_count": len(chains),
        "first_attack_chain": chains[0] if chains else None,
        "first_tl_gets": tl_events[:10],
    }


def main():
    if len(sys.argv) != 2:
        print("usage: prove_pbmt_attack_chain.py <wave.vcd>", file=sys.stderr)
        return 2
    result = parse_vcd(sys.argv[1])
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["predicate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
