#!/usr/bin/env python3
import json
import sys


TARGET_FETCH_PA = 0x80000114
TARGET_TL_ADDRS = {0x80000110, 0x80000118}
TARGET_MEM_WINDOW_LO = 0x80000100
TARGET_MEM_WINDOW_HI = 0x80000200

SIGNALS = {
    "s2_pbmt": ".frontend.inner_ifu.s2_icacheMeta_0_itlbPbmt",
    "s2_pmp_mmio": ".frontend.inner_ifu.s2_icacheMeta_0_pmpMmio",
    "s3_use_uncache": ".frontend.inner_ifu.s3_useUncacheFetch",
    "s3_pmp_mmio": ".frontend.inner_ifu.s3_icacheMeta_0_pmpMmio",
    "to_uncache_valid": ".frontend._inner_ifu_io_toUncache_req_valid",
    "to_uncache_ready": ".frontend.inner_ifu.io_toUncache_req_ready",
    "to_uncache_pruned_addr": ".frontend._inner_ifu_io_toUncache_req_bits_addr_addr",
    "backend_empty": ".frontend.inner_ifu.io_backendEmpty",
    "ibuffer_empty": ".frontend.inner_ifu.io_ibufferEmpty",
    "is_first_instr": ".frontend.inner_ifu.isFirstInstr",
    "ifu_uncache_state": ".frontend.inner_ifu.uncacheUnit.uncacheState",
    "tl_a_valid": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_valid",
    "tl_a_ready": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_ready",
    "tl_a_address": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_bits_address",
    "tl_d_valid": ".frontend.inner_instrUncache.entries_0.io_mmioGrant_valid",
    "tl_d_data": ".frontend.inner_instrUncache.entries_0.io_mmioGrant_bits_data",
    "mem_ar_valid": "._l_simMMIO_io_mem_0_ar_valid",
    "mem_ar_addr": "._l_simMMIO_io_mem_0_ar_bits_addr",
    "sim_ar_ready": "._l_simMMIO_io_axi4_0_ar_ready",
    "sim_r_valid": "._l_simMMIO_io_axi4_0_r_valid",
    "sim_r_data": "._l_simMMIO_io_axi4_0_r_bits_data",
    "sim_r_last": "._l_simMMIO_io_axi4_0_r_bits_last",
}


def clean_name(name):
    return name.replace("\\", "").split("[", 1)[0]


def parse_value_token(line):
    if not line:
        return None, None
    if line[0] in "01xz":
        return line[0], line[1:]
    if line[0] == "b":
        parts = line.split()
        if len(parts) == 2:
            return parts[0][1:].replace("x", "0").replace("z", "0"), parts[1]
    return None, None


def to_int(value):
    if value is None or value in ("", "x", "z"):
        return None
    return int(value, 2) if set(value) <= {"0", "1"} else int(value)


def pick_key(path):
    for key, suffix in SIGNALS.items():
        if path.endswith(suffix):
            return key
    return None


def in_target_mem_window(addr):
    return addr is not None and TARGET_MEM_WINDOW_LO <= addr < TARGET_MEM_WINDOW_HI


def parse_vcd(path, max_delta=256):
    id_to_keys = {}
    matched = {}
    values = {key: None for key in SIGNALS}
    scopes = []
    in_header = True
    time = None

    last_pbmt_io = None
    last_unsafe_ifu = None
    last_tl_a = None
    last_mem_ar = None
    ifu_events = []
    tl_a_events = []
    tl_d_events = []
    mem_ar_events = []
    sim_r_events = []
    tl_timing_chains = []
    external_chains = []

    def snapshot(keys):
        return {key: to_int(values[key]) for key in keys}

    def evaluate():
        nonlocal last_pbmt_io, last_unsafe_ifu, last_tl_a, last_mem_ar
        if time is None:
            return

        s2_pbmt = to_int(values["s2_pbmt"])
        s2_pmp_mmio = to_int(values["s2_pmp_mmio"])
        if s2_pbmt == 2 and s2_pmp_mmio == 0:
            last_pbmt_io = {"time": time, "s2_pbmt": s2_pbmt, "s2_pmp_mmio": s2_pmp_mmio}

        to_uncache_fire = values["to_uncache_valid"] == "1" and values["to_uncache_ready"] == "1"
        if to_uncache_fire:
            item = snapshot([
                "s3_use_uncache",
                "s3_pmp_mmio",
                "to_uncache_pruned_addr",
                "backend_empty",
                "ibuffer_empty",
                "is_first_instr",
                "ifu_uncache_state",
            ])
            item["time"] = time
            item["to_uncache_full_addr"] = None
            if item["to_uncache_pruned_addr"] is not None:
                item["to_uncache_full_addr"] = item["to_uncache_pruned_addr"] << 1
            item["preceding_pbmt_io"] = last_pbmt_io
            ifu_events.append(item)

            pbmt_recent = (
                last_pbmt_io is not None
                and last_pbmt_io["time"] <= time
                and time - last_pbmt_io["time"] <= max_delta
            )
            unsafe = (
                pbmt_recent
                and item["s3_use_uncache"] == 1
                and item["s3_pmp_mmio"] == 0
                and item["ifu_uncache_state"] == 2
                and item["is_first_instr"] == 0
                and (item["backend_empty"] == 0 or item["ibuffer_empty"] == 0)
                and item["to_uncache_full_addr"] == TARGET_FETCH_PA
            )
            if unsafe:
                last_unsafe_ifu = dict(item)

        tl_a_fire = values["tl_a_valid"] == "1" and values["tl_a_ready"] == "1"
        if tl_a_fire:
            item = snapshot(["tl_a_address"])
            item["time"] = time
            tl_a_events.append(item)
            if item["tl_a_address"] in TARGET_TL_ADDRS:
                last_tl_a = item

        tl_d_fire = values["tl_d_valid"] == "1"
        if tl_d_fire:
            item = snapshot(["tl_d_data"])
            item["time"] = time
            tl_d_events.append(item)
            if (
                last_unsafe_ifu is not None
                and last_tl_a is not None
                and last_unsafe_ifu["time"] <= last_tl_a["time"] <= time
                and last_tl_a["time"] - last_unsafe_ifu["time"] <= max_delta
                and time - last_tl_a["time"] <= max_delta
            ):
                tl_timing_chains.append({
                    "pbmt_io_observed": last_unsafe_ifu["preceding_pbmt_io"],
                    "unsafe_ifu_to_uncache_fire": last_unsafe_ifu,
                    "tl_get_fire": last_tl_a,
                    "tl_grant_valid": item,
                    "delta_ifu_to_tl": last_tl_a["time"] - last_unsafe_ifu["time"],
                    "delta_tl_to_grant": time - last_tl_a["time"],
                })

        mem_ar_fire = values["mem_ar_valid"] == "1" and values["sim_ar_ready"] == "1"
        if mem_ar_fire:
            item = snapshot(["mem_ar_addr"])
            item["time"] = time
            mem_ar_events.append(item)
            if in_target_mem_window(item["mem_ar_addr"]):
                last_mem_ar = item

        sim_r_fire = values["sim_r_valid"] == "1"
        if sim_r_fire:
            item = snapshot(["sim_r_data", "sim_r_last"])
            item["time"] = time
            sim_r_events.append(item)
            if (
                last_unsafe_ifu is not None
                and last_tl_a is not None
                and last_mem_ar is not None
                and last_unsafe_ifu["time"] <= last_tl_a["time"] <= last_mem_ar["time"] <= time
                and last_tl_a["time"] - last_unsafe_ifu["time"] <= max_delta
                and last_mem_ar["time"] - last_tl_a["time"] <= max_delta
                and time - last_mem_ar["time"] <= max_delta
            ):
                external_chains.append({
                    "pbmt_io_observed": last_unsafe_ifu["preceding_pbmt_io"],
                    "unsafe_ifu_to_uncache_fire": last_unsafe_ifu,
                    "tl_get_fire": last_tl_a,
                    "simmmio_mem_ar_fire": last_mem_ar,
                    "simmmio_r_valid": item,
                    "delta_ifu_to_tl": last_tl_a["time"] - last_unsafe_ifu["time"],
                    "delta_tl_to_mem_ar": last_mem_ar["time"] - last_tl_a["time"],
                    "delta_mem_ar_to_r": time - last_mem_ar["time"],
                })

    with open(path, "r", errors="replace") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if in_header:
                if line.startswith("$scope"):
                    parts = line.split()
                    scopes.append(parts[2])
                elif line.startswith("$upscope"):
                    if scopes:
                        scopes.pop()
                elif line.startswith("$var"):
                    parts = line.split()
                    if len(parts) >= 5:
                        code = parts[3]
                        path_name = ".".join(scopes + [clean_name(parts[4])])
                        key = pick_key(path_name)
                        if key:
                            matched.setdefault(key, path_name)
                            id_to_keys.setdefault(code, []).append(key)
                elif line == "$enddefinitions $end":
                    in_header = False
                continue

            if line.startswith("#"):
                evaluate()
                time = int(line[1:])
                continue

            value, code = parse_value_token(line)
            if code is None:
                continue
            for key in id_to_keys.get(code, []):
                values[key] = value
    evaluate()

    missing = [key for key in SIGNALS if key not in matched]
    target_mem_ars = [e for e in mem_ar_events if in_target_mem_window(e["mem_ar_addr"])]
    return {
        "predicate": "PASS" if tl_timing_chains and not missing else "FAIL",
        "predicate_definition": (
            "PBMT-IO, non-PMP-MMIO instruction fetch fires unsafe IFU uncache before "
            "frontend/backend quiescence, then receives an uncache TileLink D-channel "
            "grant. SimMMIO memory AR/R is tracked separately when the request reaches "
            "the top-level external memory model."
        ),
        "target_fetch_pa": TARGET_FETCH_PA,
        "target_tl_addrs": sorted(TARGET_TL_ADDRS),
        "target_mem_window": [TARGET_MEM_WINDOW_LO, TARGET_MEM_WINDOW_HI],
        "matched_paths": matched,
        "missing_signals": missing,
        "unsafe_ifu_fire_count": sum(
            1
            for e in ifu_events
            if e.get("preceding_pbmt_io")
            and e["s3_use_uncache"] == 1
            and e["s3_pmp_mmio"] == 0
            and e["ifu_uncache_state"] == 2
            and e["is_first_instr"] == 0
            and (e["backend_empty"] == 0 or e["ibuffer_empty"] == 0)
            and e["to_uncache_full_addr"] == TARGET_FETCH_PA
        ),
        "tl_target_get_count": sum(1 for e in tl_a_events if e["tl_a_address"] in TARGET_TL_ADDRS),
        "tl_grant_valid_count": len(tl_d_events),
        "tl_timing_chain_count": len(tl_timing_chains),
        "target_mem_ar_count": len(target_mem_ars),
        "sim_r_valid_count": len(sim_r_events),
        "external_timing_chain_count": len(external_chains),
        "first_tl_timing_chain": tl_timing_chains[0] if tl_timing_chains else None,
        "first_external_timing_chain": external_chains[0] if external_chains else None,
        "first_ifu_events": ifu_events[:10],
        "first_tl_gets": tl_a_events[:10],
        "first_target_mem_ar": target_mem_ars[:10],
        "first_sim_r": sim_r_events[:10],
    }


def main():
    if len(sys.argv) != 2:
        print("usage: prove_pbmt_external_timing.py <wave.vcd>", file=sys.stderr)
        return 2
    result = parse_vcd(sys.argv[1])
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["predicate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
