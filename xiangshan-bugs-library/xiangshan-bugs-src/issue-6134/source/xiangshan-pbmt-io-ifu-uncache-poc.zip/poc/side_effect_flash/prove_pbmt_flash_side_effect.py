#!/usr/bin/env python3
import json
import re
import sys


TARGET_VA = 0x40054320
TARGET_PA = 0x10054320
FLASH_BASE = 0x10000000
FLASH_SIZE = 0x8000

SIGNALS = {
    "s2_pbmt": ".frontend.inner_ifu.s2_icacheMeta_0_itlbPbmt",
    "s2_pmp_mmio": ".frontend.inner_ifu.s2_icacheMeta_0_pmpMmio",
    "s3_use_uncache": ".frontend.inner_ifu.s3_useUncacheFetch",
    "s3_pmp_mmio": ".frontend.inner_ifu.s3_icacheMeta_0_pmpMmio",
    "to_uncache_valid": ".frontend._inner_ifu_io_toUncache_req_valid",
    "to_uncache_ready": ".frontend.inner_ifu.io_toUncache_req_ready",
    "to_uncache_pruned_addr": ".frontend._inner_ifu_io_toUncache_req_bits_addr_addr",
    "backend_empty": ".frontend.inner_ifu.io_backendEmpty",
    "ibuffer_empty": ".frontend.inner_ifu.io_ibufferEmpty",
    "is_first_instr": ".frontend.inner_ifu.isFirstInstr",
    "ifu_uncache_state": ".frontend.inner_ifu.uncacheUnit.uncacheState",
    "tl_a_valid": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_valid",
    "tl_a_ready": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_ready",
    "tl_a_address": ".frontend.inner_instrUncache.entries_0.io_mmioAcquire_bits_address",
    "tl_d_valid": ".frontend.inner_instrUncache.entries_0.io_mmioGrant_valid",
    "tl_d_data": ".frontend.inner_instrUncache.entries_0.io_mmioGrant_bits_data",
    "flash_ar_ready": ".l_simMMIO._flash_auto_in_ar_ready",
    "flash_r_valid": ".l_simMMIO._flash_auto_in_r_valid",
    "flash_r_data": ".l_simMMIO._flash_auto_in_r_bits_data",
    "flash_r_last": ".l_simMMIO._flash_auto_in_r_bits_last",
}

XBAR_AR_VALID = re.compile(r"\.l_simMMIO\._axi4xbar_auto_out_(\d+)_ar_valid$")
XBAR_AR_ADDR = re.compile(r"\.l_simMMIO\._axi4xbar_auto_out_(\d+)_ar_bits_addr$")


def clean_name(name):
    return name.replace("\\", "").split("[", 1)[0]


def parse_value_token(line):
    if not line:
        return None, None
    if line[0] in "01xz":
        return line[0], line[1:]
    if line[0] == "b":
        parts = line.split()
        if len(parts) == 2:
            return parts[0][1:].replace("x", "0").replace("z", "0"), parts[1]
    return None, None


def to_int(value):
    if value is None or value in ("", "x", "z"):
        return None
    return int(value, 2) if set(value) <= {"0", "1"} else int(value)


def pick_fixed_key(path):
    for key, suffix in SIGNALS.items():
        if path.endswith(suffix):
            return key
    return None


def is_targetish_flash_addr(addr):
    if addr is None:
        return False
    # Some SimMMIO-internal AXI wires carry the full address, others carry the
    # address after range stripping. Accept both forms, but keep exact target.
    return addr in (TARGET_PA, TARGET_PA - FLASH_BASE)


def parse_vcd(path, max_delta=256):
    id_to_fixed = {}
    id_to_xbar = {}
    matched = {}
    xbar_matched = {}
    values = {key: None for key in SIGNALS}
    xbar = {}
    scopes = []
    in_header = True
    time = None

    last_pbmt_io = None
    last_unsafe_ifu = None
    last_tl_a = None
    last_flash_ar = None
    ifu_events = []
    tl_a_events = []
    tl_d_events = []
    flash_ar_events = []
    flash_r_events = []
    chains = []

    def snapshot(keys):
        return {key: to_int(values[key]) for key in keys}

    def xbar_item(idx):
        item = xbar.setdefault(idx, {"ar_valid": None, "ar_addr": None})
        return item

    def evaluate():
        nonlocal last_pbmt_io, last_unsafe_ifu, last_tl_a, last_flash_ar
        if time is None:
            return

        s2_pbmt = to_int(values["s2_pbmt"])
        s2_pmp_mmio = to_int(values["s2_pmp_mmio"])
        if s2_pbmt == 2 and s2_pmp_mmio == 0:
            last_pbmt_io = {"time": time, "s2_pbmt": s2_pbmt, "s2_pmp_mmio": s2_pmp_mmio}

        to_uncache_fire = values["to_uncache_valid"] == "1" and values["to_uncache_ready"] == "1"
        if to_uncache_fire:
            item = snapshot([
                "s3_use_uncache",
                "s3_pmp_mmio",
                "to_uncache_pruned_addr",
                "backend_empty",
                "ibuffer_empty",
                "is_first_instr",
                "ifu_uncache_state",
            ])
            item["time"] = time
            item["to_uncache_full_addr"] = None
            if item["to_uncache_pruned_addr"] is not None:
                item["to_uncache_full_addr"] = item["to_uncache_pruned_addr"] << 1
            item["preceding_pbmt_io"] = last_pbmt_io
            ifu_events.append(item)

            pbmt_recent = (
                last_pbmt_io is not None
                and last_pbmt_io["time"] <= time
                and time - last_pbmt_io["time"] <= max_delta
            )
            unsafe = (
                pbmt_recent
                and item["s3_use_uncache"] == 1
                and item["s3_pmp_mmio"] == 0
                and item["ifu_uncache_state"] == 2
                and item["is_first_instr"] == 0
                and (item["backend_empty"] == 0 or item["ibuffer_empty"] == 0)
                and item["to_uncache_full_addr"] == TARGET_PA
            )
            if unsafe:
                last_unsafe_ifu = dict(item)

        tl_a_fire = values["tl_a_valid"] == "1" and values["tl_a_ready"] == "1"
        if tl_a_fire:
            item = snapshot(["tl_a_address"])
            item["time"] = time
            tl_a_events.append(item)
            if item["tl_a_address"] == TARGET_PA:
                last_tl_a = item

        tl_d_fire = values["tl_d_valid"] == "1"
        if tl_d_fire:
            item = snapshot(["tl_d_data"])
            item["time"] = time
            tl_d_events.append(item)

        flash_ar_ready = values["flash_ar_ready"] == "1"
        if flash_ar_ready:
            for idx, xv in xbar.items():
                if xv.get("ar_valid") != "1":
                    continue
                addr = to_int(xv.get("ar_addr"))
                if not is_targetish_flash_addr(addr):
                    continue
                item = {
                    "time": time,
                    "xbar_out": idx,
                    "ar_addr": addr,
                    "ar_addr_full_if_stripped": addr + FLASH_BASE if addr == TARGET_PA - FLASH_BASE else addr,
                    "flash_ar_ready": 1,
                }
                flash_ar_events.append(item)
                last_flash_ar = item

        flash_r_fire = values["flash_r_valid"] == "1"
        if flash_r_fire:
            item = snapshot(["flash_r_data", "flash_r_last"])
            item["time"] = time
            flash_r_events.append(item)
            if (
                last_unsafe_ifu is not None
                and last_tl_a is not None
                and last_flash_ar is not None
                and last_unsafe_ifu["time"] <= last_tl_a["time"] <= last_flash_ar["time"] <= time
                and last_tl_a["time"] - last_unsafe_ifu["time"] <= max_delta
                and last_flash_ar["time"] - last_tl_a["time"] <= max_delta
                and time - last_flash_ar["time"] <= max_delta
            ):
                chains.append({
                    "pbmt_io_observed": last_unsafe_ifu["preceding_pbmt_io"],
                    "unsafe_ifu_to_uncache_fire": last_unsafe_ifu,
                    "tl_get_fire": last_tl_a,
                    "flash_axi_ar_fire": last_flash_ar,
                    "flash_axi_r_valid": item,
                    "delta_ifu_to_tl": last_tl_a["time"] - last_unsafe_ifu["time"],
                    "delta_tl_to_flash_ar": last_flash_ar["time"] - last_tl_a["time"],
                    "delta_flash_ar_to_r": time - last_flash_ar["time"],
                })

    with open(path, "r", errors="replace") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if in_header:
                if line.startswith("$scope"):
                    parts = line.split()
                    scopes.append(parts[2])
                elif line.startswith("$upscope"):
                    if scopes:
                        scopes.pop()
                elif line.startswith("$var"):
                    parts = line.split()
                    if len(parts) >= 5:
                        code = parts[3]
                        path_name = ".".join(scopes + [clean_name(parts[4])])
                        fixed_key = pick_fixed_key(path_name)
                        if fixed_key:
                            matched.setdefault(fixed_key, path_name)
                            id_to_fixed.setdefault(code, []).append(fixed_key)
                        m_valid = XBAR_AR_VALID.search(path_name)
                        if m_valid:
                            idx = int(m_valid.group(1))
                            xbar_matched.setdefault(idx, {})["ar_valid"] = path_name
                            id_to_xbar.setdefault(code, []).append((idx, "ar_valid"))
                        m_addr = XBAR_AR_ADDR.search(path_name)
                        if m_addr:
                            idx = int(m_addr.group(1))
                            xbar_matched.setdefault(idx, {})["ar_addr"] = path_name
                            id_to_xbar.setdefault(code, []).append((idx, "ar_addr"))
                elif line == "$enddefinitions $end":
                    in_header = False
                continue

            if line.startswith("#"):
                evaluate()
                time = int(line[1:])
                continue

            value, code = parse_value_token(line)
            if code is None:
                continue
            for key in id_to_fixed.get(code, []):
                values[key] = value
            for idx, field in id_to_xbar.get(code, []):
                xbar_item(idx)[field] = value
    evaluate()

    missing = [key for key in SIGNALS if key not in matched]
    return {
        "predicate": "PASS" if chains and not missing else "FAIL",
        "predicate_definition": (
            "PBMT-IO instruction fetch to VA 0x40054320 maps to flash PA 0x10054320, "
            "fires unsafe IFU uncache before frontend/backend quiescence, then emits a "
            "TileLink Get, a SimMMIO flash AXI AR handshake, and a flash R response."
        ),
        "target_va": TARGET_VA,
        "target_pa": TARGET_PA,
        "flash_size_bytes": FLASH_SIZE,
        "target_flash_offset": TARGET_PA - FLASH_BASE,
        "target_is_oob_for_flash_model": (TARGET_PA - FLASH_BASE) >= FLASH_SIZE,
        "matched_paths": matched,
        "matched_xbar_ar_paths": xbar_matched,
        "missing_signals": missing,
        "unsafe_ifu_fire_count": sum(
            1
            for e in ifu_events
            if e.get("preceding_pbmt_io")
            and e["s3_use_uncache"] == 1
            and e["s3_pmp_mmio"] == 0
            and e["ifu_uncache_state"] == 2
            and e["is_first_instr"] == 0
            and (e["backend_empty"] == 0 or e["ibuffer_empty"] == 0)
            and e["to_uncache_full_addr"] == TARGET_PA
        ),
        "tl_target_get_count": sum(1 for e in tl_a_events if e["tl_a_address"] == TARGET_PA),
        "flash_target_ar_count": len(flash_ar_events),
        "flash_r_valid_count": len(flash_r_events),
        "side_effect_chain_count": len(chains),
        "first_side_effect_chain": chains[0] if chains else None,
        "first_ifu_events": ifu_events[:10],
        "first_tl_gets": tl_a_events[:10],
        "first_flash_ar": flash_ar_events[:10],
        "first_flash_r": flash_r_events[:10],
    }


def main():
    if len(sys.argv) != 2:
        print("usage: prove_pbmt_flash_side_effect.py <wave.vcd>", file=sys.stderr)
        return 2
    result = parse_vcd(sys.argv[1])
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["predicate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
