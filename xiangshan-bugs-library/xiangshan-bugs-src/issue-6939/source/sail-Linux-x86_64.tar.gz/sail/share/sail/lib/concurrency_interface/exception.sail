/*==========================================================================*/
/*     Sail                                                                 */
/*                                                                          */
/*  Sail and the Sail architecture models here, comprising all files and    */
/*  directories except the ASL-derived Sail code in the aarch64 directory,  */
/*  are subject to the BSD two-clause licence below.                        */
/*                                                                          */
/*  The ASL derived parts of the ARMv8.3 specification in                   */
/*  aarch64/no_vector and aarch64/full are copyright ARM Ltd.               */
/*                                                                          */
/*  Copyright (c) 2013-2021                                                 */
/*    Kathyrn Gray                                                          */
/*    Shaked Flur                                                           */
/*    Stephen Kell                                                          */
/*    Gabriel Kerneis                                                       */
/*    Robert Norton-Wright                                                  */
/*    Christopher Pulte                                                     */
/*    Peter Sewell                                                          */
/*    Alasdair Armstrong                                                    */
/*    Brian Campbell                                                        */
/*    Thomas Bauereiss                                                      */
/*    Anthony Fox                                                           */
/*    Jon French                                                            */
/*    Dominic Mulligan                                                      */
/*    Stephen Kell                                                          */
/*    Mark Wassell                                                          */
/*    Alastair Reid (Arm Ltd)                                               */
/*                                                                          */
/*  All rights reserved.                                                    */
/*                                                                          */
/*  This work was partially supported by EPSRC grant EP/K008528/1 <a        */
/*  href="http://www.cl.cam.ac.uk/users/pes20/rems">REMS: Rigorous          */
/*  Engineering for Mainstream Systems</a>, an ARM iCASE award, EPSRC IAA   */
/*  KTF funding, and donations from Arm.  This project has received         */
/*  funding from the European Research Council (ERC) under the European     */
/*  Union’s Horizon 2020 research and innovation programme (grant           */
/*  agreement No 789108, ELVER).                                            */
/*                                                                          */
/*  This software was developed by SRI International and the University of  */
/*  Cambridge Computer Laboratory (Department of Computer Science and       */
/*  Technology) under DARPA/AFRL contracts FA8650-18-C-7809 ("CIFV")        */
/*  and FA8750-10-C-0237 ("CTSRD").                                         */
/*                                                                          */
/*  SPDX-License-Identifier: BSD-2-Clause                                   */
/*==========================================================================*/

$sail_internal

$ifndef _CONCURRENCY_INTERFACE_ERET
$define _CONCURRENCY_INTERFACE_ERET

$include <concurrency_interface/common.sail>

$ifdef CONCURRENCY_INTERFACE_V2
// This should be called to announce any exception:
// - page fault (and other MMU faults)
// - supervisor/hypevisor calls
// - Any physical interrrupts (if modelled through sail)
outcome sail_take_exception : 'exn -> unit
    with 'exn : Type
= {
    impl emulator(_) = ()
}

// This announce a return from a exception (ERET/IRET)
outcome sail_return_exception : unit -> unit = {
    impl emulator(_) = ()
}

$else // Concurrency Interface v1

outcome sail_take_exception : 'fault -> unit
    with 'fault : Type
= {
    impl emulator(_) = ()
}

outcome sail_return_exception : 'pa -> unit
    with 'pa : Type
= {
    impl emulator(_) = ()
}

outcome sail_system_register_write : unit -> unit
= {
    impl emulator() = ()
}

$endif

$endif
