# F14 waveform evidence: an accepted reduction remains unfinished at the ROB head

## Scope and consistency with the existing report

This seed-0 capture uses the same pinned XiangShan RTL commit, PoC image and reference library as the report, rebuilt with full FST tracing. The emulator binary is therefore different from the original non-tracing executable. The exact command, hashes and comparison are preserved in [run.json](run.json).

The tracing run reproduces the original no-commit watchdog, instruction count (1,541), cycle count (23,239), and subsequent register-difference values. It does not reveal a contradiction with the existing report's finite-watchdog observation. The waveform adds a more specific observation: **the target is accepted by dispatch, receives no issue-queue selection, and remains unfinished at the ROB head**. It is not blocked at the dispatch input by `ready=0`.

The reference value printed after the watchdog is still the result of the harness's additional reference step. It is not a result committed by the DUT. This evidence does not prove a permanent deadlock, a unique RTL root cause, or behavior on a newer DUT revision.

## Target identity and sampling

- Instruction PC: `0x80000410`; instruction bits: `0x06321157` (`vfredusum.vs v2,v3,v4`).
- Observed target: dispatch lane 4, ROB flag `1`, ROB index `0x29` (decimal 41), micro-op index `0`, FU type `0x20000000` (`vredu` in this source version).
- Samples use the falling edge of `TOP.clock`, after evaluation. Sample cycle zero is the first falling edge in this FST file. These indices are not the emulator's printed `cycleCnt`.
- All plotted values come from the actual FST. Two explicitly labelled concatenation rows are derived from the individual observed bits; the uncombined signals remain in the companion JSON.

## 1. Dispatch accepts the target without selecting an issue queue

![F14 dispatch and ROB admission](waveform-dispatch.png)

At sample cycle **8298** (native FST time **16597**), lane 4 has target PC/opcode and `valid=ready=firedVec=1`. The target is therefore accepted by dispatch. At that same sample, **all 19** `uopSelIQ_4_0` through `uopSelIQ_4_18` bits are zero.

The ROB admission signal `canEnqueue_4` is asserted at cycle **8299**. At cycle **8300**, ROB entry 41 becomes valid with PC `0x80000410` and `uopNum=1`. The one-cycle differences reflect observed pipeline timing; enqueue and entry state were not assumed to update in the same sample.

Across cycles **8297–23317**, no valid input to any of the eight vector arithmetic IQ enqueue ports carries ROB `1:0x29`. No valid dequeue from the four arithmetic vector IQs, no valid input to their four execution units, and no vector arithmetic ROB writeback carries that target either. The full-trace inspection evaluated absence with `valid && robIdx_flag==1 && robIdx_value==0x29`, not from payload values on invalid ports. Its [observation summary](observations.json) is included. The broader IQ/execution raw sample files are retained in the original full archive, not in this compact submission; therefore those absence checks cannot be independently repeated from the PNG and included figure samples alone.

- [Dispatch selection](dispatch-selection.json) and [raw samples](dispatch-samples.json).
- [Figure samples](dispatch-figure-samples.json); the 19-bit IQ row is `sum(uopSelIQ_4_j << j)` for `j=0..18`.
- [Vector IQ enqueue / writeback and ROB selection](stall-selection.json) identifies the broader extraction, whose full raw file is archived separately. The included [stall figure samples](stall-figure-samples.json) retain the complete plotted 15,006-sample ROB-head interval.
- [IQ dequeue / execution input selection](execution-selection.json) identifies the broader check; its raw samples remain in the full archive.
- [Initial PC-based discovery](target-discovery.json) records the matching instruction transaction.

## 2. The target, rather than an older instruction, holds the ROB head

![F14 finite interval at the ROB head](waveform-stall.png)

From sample cycle **8312** through **23317**, inclusive (**15,006 observed falling-edge samples**, native times **16625–46635**):

| Observed signal | Value throughout this interval |
|---|---|
| ROB head flag / index | `1 / 0x29` |
| ROB entry 41 PC / valid | `0x80000410 / 1` |
| ROB entry 41 unfinished micro-op count | `1` |
| All eight commit-valid lanes | `0` |
| ROB `io_commits_isCommit` | `1` |
| ROB `blockCommit` | `0` |
| ROB redirect / flush-out / exception valid | `0 / 0 / 0` |
| ROB entry 41 `needFlush` | `0` |

This rules out an older instruction at the head or the observed global commit-block/redirect/exception controls as the reason for this final interval. It supports an unfinished target at the head, without claiming any architectural latency bound.

- [Complete plotted interval](stall-figure-samples.json): all 15,006 samples of the displayed ROB state/control signals and the derived eight-bit commit mask. The formula for that mask is recorded in the JSON.
- [Eight original commit-valid signals](stall-commit-valid-raw.json): a lightweight excerpt retaining each actual `io_commits_commitValid_0` through `io_commits_commitValid_7` signal at every sample from 8312 through 23317. These individual observed values allow independent checking of the plotted derived All commit valid row.
- [Unplotted ROB controls](stall-unplotted-controls-raw.json): the original `io_flushOut_valid` and entry-41 `needFlush` bits at each of the 15,006 samples. The [observation summary](observations.json) records the other full-inspection findings. The underlying wider raw extraction remains in the full archive.

## 3. Earlier redirect checked separately

A redirect occurs at sample cycle **8304**, before the stable-head interval. Its ROB tag is **`1:0x2c`**, while the target is `1:0x29`. The target entry remains valid with the same PC and `uopNum=1` across this event. The transient walk/global-block state ends before the documented final interval. Thus this event was not omitted from the analysis or mistaken for the target's sustained stall.

See [redirect selection](redirect-selection.json) and [raw samples](redirect-samples.json).

## Interpretation boundary

The observations support the specific local chain “dispatch accepts a `vredu` micro-op with no IQ selected → the ROB records an unfinished target → the target reaches the head and no further instruction commits before the watchdog.” This strengthens the missing execution/routing hypothesis in the existing report. A fix-and-retest experiment has not been performed, and the waveform alone does not establish which single source change would repair the path or whether other implementation gaps also exist.

The no-commit interval is finite. The unchanged DUT destination at watchdog time is not evidence of a retired arithmetic result. No new expected-value trace has been synthesized into either waveform figure.

## Archive and compact-submission boundary

The raw FST and wider IQ/execution extractions remain in the original complete evidence package. They are not linked as if present in this submission. [run.json](run.json) records the raw-trace SHA-256 and exact capture command; [observations.json](observations.json) records the full inspection results and artifact hashes, including names of files retained only in the archive. The included figure samples and eight individual commit-valid signals substantiate the plotted stable-head interval; the all-port negative search is a documented extraction result rather than independently complete raw evidence in this smaller bundle.
