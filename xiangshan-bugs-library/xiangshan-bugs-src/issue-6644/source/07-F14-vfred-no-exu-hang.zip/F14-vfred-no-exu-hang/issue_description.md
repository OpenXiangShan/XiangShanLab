# vfredusum.vs is accepted without an IQ selection and triggers the no-commit watchdog

On Kunminghu-v3 **`b9636416b8`, MinimalConfig**, the attached reduction test triggers difftest's no-commit watchdog for seeds 0, 1 and 2. This issue was not reproduced in the latest Kunminghu-v2 version.

## Reproducer and expected behavior

The PoC loads FP32 `{1,2,3,4}` into v3 and zero into v4[0], then executes the target at PC `0x80000410`:

```asm
vsetivli     x0, 4, e32, m1, tu, mu
vfredusum.vs v2, v3, v4
```

If executed correctly, destination element zero is FP32 **10.0 (`0x41200000`)**. The semantics are specified in RISC-V Unprivileged ISA Version 20240411, [§31.14.3, PDF page 365](https://docs.riscv.org/reference/isa/v20240411/_attachments/riscv-unprivileged.pdf#page=365) and [page 366](https://docs.riscv.org/reference/isa/v20240411/_attachments/riscv-unprivileged.pdf#page=366).

![Reduction specification, first page](screenshots/spec-page-365.png)
![Reduction specification, continued](screenshots/spec-page-366.png)

## Observed behavior

All three runs report no commits for **15,000 cycles**, then exit with the watchdog. This threshold belongs to the test harness; it is **not an ISA execution deadline**. After the watchdog, the harness forcibly advances the reference by one instruction. The resulting v2 difference is diagnostic and **does not mean the DUT committed an incorrect reduction result**.

Logs and command/hash records: [seed 0](logs/replay-20260926/seed0.log) ([JSON](logs/replay-20260926/seed0.json)), [seed 1](logs/replay-20260926/seed1.log) ([JSON](logs/replay-20260926/seed1.json)) and [seed 2](logs/replay-20260926/seed2.log) ([JSON](logs/replay-20260926/seed2.json)).

![Verbatim watchdog and diagnostic log excerpts, rendered for readability](screenshots/runtime-difference.png)

## Waveform evidence

The tracing rebuild reproduces the watchdog at `cycleCnt=23239`, after 1,541 committed instructions: [trace log](waveform/run.log), [command/hash record](waveform/run.json). Below, cycles are falling-edge FST sample indices, not DUT cycle counts.

![Dispatch accepts the target without selecting an IQ](waveform/waveform-dispatch.png)

At sample **8298**, the target has `valid=ready=fired=1`, ROB `(flag=1,index=0x29)`, and all 19 IQ-selection bits zero. At 8300, its ROB entry is valid with one unfinished micro-op.

![Finite interval with the unfinished target at the ROB head](waveform/waveform-stall.png)

From **8312 through 23317**, inclusive (**15,006 samples**), the same target occupies the ROB head with one unfinished micro-op and no commits. The observed global commit-block, redirect, flush and exception controls are inactive. An earlier redirect at 8304 concerns a younger ROB entry; the target remains valid. The [analysis](waveform/analysis.md) links samples and extraction summaries; derived rows are labelled.

This supports a routing/execution-path problem. The finite capture proves neither permanent deadlock nor a unique repair.

## Replay

Run [replay.sh](replay.sh) with seeds 0, 1 and 2. Files: [binary](poc/build/f14-vfred-no-exu-hang-riscv64-xs-light-kunminghu-v3.bin), [ELF](poc/build/f14-vfred-no-exu-hang-riscv64-xs-light-kunminghu-v3.elf), [disassembly](poc/build/f14-vfred-no-exu-hang-riscv64-xs-light-kunminghu-v3.txt), [C](poc/main.c) and [assembly](poc/probe.S). This adds a reduction reproducer within the v3 vector WIP context.
