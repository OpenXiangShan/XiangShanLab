/* F14: FP reduction reproducer; the target does not commit before
 * the observed watchdog. */
#include "probe-common.S"

  .align 6
  .globl f14_vfredusum
  .type  f14_vfredusum, @function
f14_vfredusum:
  vl1re64.v v2, (a1)
  vl1re64.v v3, (a2)
  vl1re64.v v4, (a3)
  vsetivli x0, 4, e32, m1, tu, mu
  vfredusum.vs v2, v3, v4
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f14_vfredusum, .-f14_vfredusum
