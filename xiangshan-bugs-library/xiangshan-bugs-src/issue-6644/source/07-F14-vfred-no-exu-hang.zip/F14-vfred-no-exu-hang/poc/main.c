/* F14 -- vfredusum.vs does not commit before the no-commit watchdog.
 * In the traced build, dispatch accepts the target without selecting
 * an IQ. It remains unfinished at the ROB head for the observed
 * interval. A unique RTL root cause is not established.
 */
#include "vt-common.h"

static uint8_t preset[16] __attribute__((aligned(16)));
static uint8_t a[16] __attribute__((aligned(16)));
static uint8_t b[16] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f14_vfredusum(void *o, const void *p, const void *a, const void *b);
static void put32(uint8_t *p, int i, uint32_t x) { for (int k = 0; k < 4; k++) p[4 * i + k] = (uint8_t)(x >> (8 * k)); }

int main(void) {
  if (vt_init("F14") != 0) return 1;
  for (int i = 0; i < 16; i++) preset[i] = (uint8_t)(0xC0 + i);
  put32(a, 0, 0x3F800000); put32(a, 1, 0x40000000); put32(a, 2, 0x40400000); put32(a, 3, 0x40800000); /* 1,2,3,4 */
  memset(b, 0, 16);
  memset(out, 0, 16);
  printf("[F14] start cyc=%lu: vfredusum.vs v2, {1,2,3,4}, 0\n", (unsigned long)cyc());
  f14_vfredusum(out, preset, a, b); VT_FENCE();
  printf("[F14] completed cyc=%lu v2[0]=%08lx expect=41200000 (10.0) %s\n", (unsigned long)cyc(),
         (unsigned long)(bytes_q(out) & 0xFFFFFFFFu),
         (bytes_q(out) & 0xFFFFFFFFu) == 0x41200000u ? "ok" : "BUG");
  return 0;
}
