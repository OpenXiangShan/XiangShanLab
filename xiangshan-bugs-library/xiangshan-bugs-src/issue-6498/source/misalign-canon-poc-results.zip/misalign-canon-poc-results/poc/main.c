#include <klib.h>
#include <riscv.h>

// =============================================================================
// PoC for candidate 0010: a misaligned load/store whose *second* part crosses
// from the canonical lower half into the non-canonical hole is not checked.
//
//   StoreUnit.scala:  io.tlb.req.bits.checkfullva := s0_use_flow_rs || s0_use_flow_vec
//                     (false for the split pieces coming from StoreMisalignBuffer)
//   StoreMisalignBuffer.scala: highAddrStore.vaddr := req.vaddr + N   (VAddrBits=50 wide)
//   TLB.scala: canonical check (pf39/pf48) only under checkfullva
//   PTW: indexes page tables with vpn[2:0] only -> 0x40_0000_0000 walks the
//        same entries as 0xFFFF_FFC0_0000_0000 (Sv39)
//
// Test (S-mode, Sv39):
//   VA 0x0000_003F_FFFF_F000 (last page of the canonical lower half) -> P_LOW
//   VA 0xFFFF_FFC0_0000_0000 (first page of the canonical upper half) -> P_HI
//   `sd` at 0x3F_FFFF_FFFC : bytes 0-3 land in P_LOW, bytes 4-7 have effective
//   address 0x0000_0040_0000_0000 (non-canonical) -> spec: store page fault.
//   Predicted XiangShan behaviour: no fault, bytes 4-7 are written to P_HI[0..3]
//   (the mapping of 0xFFFF_FFC0_0000_0000).
// =============================================================================

#define PGSIZE 4096UL
#define PTE_PPN(pa) ((((uintptr_t)(pa)) >> 12) << 10)
#define SATP_SV39 (8UL << 60)

#define CAUSE_LOAD_MISALIGNED   4
#define CAUSE_LOAD_ACCESS       5
#define CAUSE_STORE_MISALIGNED  6
#define CAUSE_STORE_ACCESS      7
#define CAUSE_LOAD_PAGE_FAULT   13
#define CAUSE_STORE_PAGE_FAULT  15

#define VA_LOW_PAGE   0x0000003FFFFFF000UL   // canonical (Sv39 lower half top page)
#define VA_CTL_PAGE   0x0000003FFFFFE000UL   // canonical control page just below
#define VA_HI_PAGE    0xFFFFFFC000000000UL   // canonical (Sv39 upper half first page)
#define VA_NONCANON   0x0000004000000000UL   // non-canonical alias of VA_HI_PAGE

extern void irq_handler_reg(uintptr_t code, _Context *(*handler)(_Event *, _Context *));
extern int g_config_disable_timer;

static uint8_t pages[8][PGSIZE] __attribute__((aligned(4096)));
#define P_ROOT  ((uint64_t *)pages[0])
#define P_L1A   ((uint64_t *)pages[1])   // for VA_LOW/VA_CTL  (root[255])
#define P_L0A   ((uint64_t *)pages[2])
#define P_L1B   ((uint64_t *)pages[3])   // for VA_HI          (root[256])
#define P_L0B   ((uint64_t *)pages[4])
#define P_LOW   (pages[5])
#define P_HI    (pages[6])
#define P_CTL   (pages[7])

static volatile unsigned long trap_cnt, trap_cause, trap_tval, trap_epc;

static inline int inst_is_compressed(uintptr_t pc) { return ((*(uint8_t *)pc) & 3) != 3; }

static _Context *trap_handler(_Event *ev, _Context *c)
{
    unsigned long tval; asm volatile("csrr %0, stval" : "=r"(tval));
    trap_cnt++;
    trap_cause = c->scause & SCAUSE_MASK;
    trap_tval  = tval;
    trap_epc   = c->sepc;
    c->sepc += inst_is_compressed(c->sepc) ? 2 : 4;   // skip the faulting instruction
    return c;
}

static void build_page_tables(void)
{
    memset(pages, 0, sizeof(pages));
    // identity 1 GiB gigapages for 0x0.., 0x4000_0000.. (uart/clint/plic) and 0x8000_0000.. (PMEM)
    P_ROOT[0] = PTE_PPN(0x00000000UL) | PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D;
    P_ROOT[1] = PTE_PPN(0x40000000UL) | PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D;
    P_ROOT[2] = PTE_PPN(0x80000000UL) | PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D;
    // VA 0x3F_FFFF_F000 / 0x3F_FFFF_E000 : root[255] -> L1A[511] -> L0A[511]/[510]
    P_ROOT[255] = PTE_PPN(P_L1A) | PTE_V;
    P_L1A[511]  = PTE_PPN(P_L0A) | PTE_V;
    P_L0A[511]  = PTE_PPN(P_LOW) | PTE_V | PTE_R | PTE_W | PTE_A | PTE_D;
    P_L0A[510]  = PTE_PPN(P_CTL) | PTE_V | PTE_R | PTE_W | PTE_A | PTE_D;
    // VA 0xFFFF_FFC0_0000_0000 : root[256] -> L1B[0] -> L0B[0]
    P_ROOT[256] = PTE_PPN(P_L1B) | PTE_V;
    P_L1B[0]    = PTE_PPN(P_L0B) | PTE_V;
    P_L0B[0]    = PTE_PPN(P_HI)  | PTE_V | PTE_R | PTE_W | PTE_A | PTE_D;
    asm volatile("fence" ::: "memory");
}

static void fill(uint8_t *p, uint8_t v) { for (unsigned long i = 0; i < PGSIZE; i++) p[i] = v; }

static void dump8(const char *name, const uint8_t *p)
{
    printf("  %s = %02x %02x %02x %02x %02x %02x %02x %02x\n", name,
           p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
}

static void arm(void) { trap_cnt = 0; trap_cause = 0; trap_tval = 0; trap_epc = 0; }

#define SD(addr, val) asm volatile("sd %0, 0(%1)" : : "r"(val), "r"(addr) : "memory")
#define SH(addr, val) asm volatile("sh %0, 0(%1)" : : "r"(val), "r"(addr) : "memory")
#define LD(addr) ({ unsigned long __v; asm volatile("ld %0, 0(%1)" : "=r"(__v) : "r"(addr) : "memory"); __v; })

int main(void)
{
    printf("=== misaligned cross-canonical-boundary PoC (candidate 0010) ===\n");

    g_config_disable_timer = 1;
    _cte_init(NULL);                                    // -> S-mode, medeleg set, stvec installed
    unsigned long ss; asm volatile("csrr %0, sstatus" : "=r"(ss));
    printf("in S-mode, sstatus=%lx\n", ss);
    for (int c = 0; c < 16; c++) irq_handler_reg(c, trap_handler);

    build_page_tables();
    fill(P_LOW, 0x11); fill(P_HI, 0x22); fill(P_CTL, 0x33);

    unsigned long satp = SATP_SV39 | (((uintptr_t)P_ROOT) >> 12);
    asm volatile("csrw satp, %0; sfence.vma" : : "r"(satp) : "memory");
    printf("satp=%lx (Sv39)\n", satp);

    int bad = 0;

    // T0: aligned sd/ld through the canonical mappings work
    arm();
    SD(VA_LOW_PAGE, 0x0102030405060708UL);
    SD(VA_HI_PAGE,  0xA1A2A3A4A5A6A7A8UL);
    unsigned long v0 = LD(VA_LOW_PAGE), v1 = LD(VA_HI_PAGE);
    printf("T0 aligned: low=%lx hi=%lx traps=%lu\n", v0, v1, trap_cnt);
    if (trap_cnt || v0 != 0x0102030405060708UL || v1 != 0xA1A2A3A4A5A6A7A8UL) { printf("  UNEXPECTED\n"); bad |= 8; }
    fill(P_LOW, 0x11); fill(P_HI, 0x22);

    // T1: start address itself non-canonical -> must fault (checks the trap path and the rs-flow check)
    arm();
    SD(VA_NONCANON, 0xDEADBEEFDEADBEEFUL);
    printf("T1 sd @%lx (non-canonical start): traps=%lu cause=%lu tval=%lx\n", VA_NONCANON, trap_cnt, trap_cause, trap_tval);
    if (trap_cnt != 1 || trap_cause != CAUSE_STORE_PAGE_FAULT) { printf("  UNEXPECTED\n"); bad |= 8; }
    dump8("P_HI[0..7]", P_HI);

    // T2: control - misaligned sd crossing two canonical, mapped pages (E FFC -> F 000)
    arm();
    SD(VA_CTL_PAGE + 0xFFC, 0x8877665544332211UL);
    printf("T2 sd @%lx (canonical cross-page): traps=%lu\n", VA_CTL_PAGE + 0xFFC, trap_cnt);
    dump8("P_CTL[0xff8..]", P_CTL + 0xFF8);
    dump8("P_LOW[0..7]   ", P_LOW);
    if (trap_cnt || P_CTL[0xFFC] != 0x11 || P_CTL[0xFFF] != 0x44 || P_LOW[0] != 0x55 || P_LOW[3] != 0x88) { printf("  UNEXPECTED\n"); bad |= 8; }
    fill(P_LOW, 0x11); fill(P_CTL, 0x33);

    // T3: THE CASE - misaligned sd at 0x3F_FFFF_FFFC; bytes 4..7 -> 0x40_0000_0000 (non-canonical)
    arm();
    SD(VA_LOW_PAGE + 0xFFC, 0x8877665544332211UL);
    printf("T3 sd @%lx (crosses into non-canonical): traps=%lu cause=%lu tval=%lx\n",
           VA_LOW_PAGE + 0xFFC, trap_cnt, trap_cause, trap_tval);
    dump8("P_LOW[0xff8..]", P_LOW + 0xFF8);
    dump8("P_HI [0..7]   ", P_HI);
    int hi_written = (P_HI[0] == 0x55 && P_HI[1] == 0x66 && P_HI[2] == 0x77 && P_HI[3] == 0x88);
    if (trap_cnt == 0 && hi_written) {
        printf("  -> BUG: no page fault; high half written to the page mapped at %lx\n", VA_HI_PAGE);
        bad |= 1;
    } else if (trap_cnt == 1 && trap_cause == CAUSE_STORE_PAGE_FAULT && !hi_written) {
        printf("  -> spec-conformant (store page fault)\n");
    } else {
        printf("  -> UNEXPECTED combination\n"); bad |= 8;
    }
    fill(P_LOW, 0x11); fill(P_HI, 0x22);

    // T4: same with a load
    arm();
    P_HI[0] = 0xA0; P_HI[1] = 0xA1; P_HI[2] = 0xA2; P_HI[3] = 0xA3;
    P_LOW[0xFFC] = 0xB0; P_LOW[0xFFD] = 0xB1; P_LOW[0xFFE] = 0xB2; P_LOW[0xFFF] = 0xB3;
    asm volatile("fence" ::: "memory");
    unsigned long lv = LD(VA_LOW_PAGE + 0xFFC);
    printf("T4 ld @%lx (crosses into non-canonical): traps=%lu cause=%lu tval=%lx data=%lx\n",
           VA_LOW_PAGE + 0xFFC, trap_cnt, trap_cause, trap_tval, lv);
    if (trap_cnt == 0 && lv == 0xA3A2A1A0B3B2B1B0UL) {
        printf("  -> BUG: no page fault; high half read from the page mapped at %lx\n", VA_HI_PAGE);
        bad |= 2;
    } else if (trap_cnt == 1 && trap_cause == CAUSE_LOAD_PAGE_FAULT) {
        printf("  -> spec-conformant (load page fault)\n");
    } else {
        printf("  -> UNEXPECTED combination\n"); bad |= 8;
    }

    // T5: 2-byte store straddling by one byte
    arm();
    fill(P_HI, 0x22);
    SH(VA_LOW_PAGE + 0xFFF, 0xCDEF);
    printf("T5 sh @%lx: traps=%lu cause=%lu tval=%lx P_HI[0]=%02x\n",
           VA_LOW_PAGE + 0xFFF, trap_cnt, trap_cause, trap_tval, P_HI[0]);
    if (trap_cnt == 0 && P_HI[0] == 0xCD) bad |= 4;

    asm volatile("csrw satp, zero; sfence.vma" ::: "memory");

    if (bad & 8) { printf("=== UNEXPECTED: test harness problem (code %d) ===\n", bad); return 3; }
    if (bad)     { printf("=== BUG CONFIRMED: misaligned access crossing into the non-canonical hole is not faulted (mask %d) ===\n", bad); return 1; }
    printf("=== PASS ===\n");
    return 0;
}
