
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1

000000008000011a <_end_suffix>:
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <trap_mtvec>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <trap_mtvec>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	651d                	lui	a0,0x7
    800001be:	8005051b          	addiw	a0,a0,-2048 # 6800 <_start-0x7fff9800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid

00000000800001d6 <_end_prefix>:
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_fuzz_main>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_fuzz_main>:
    80000200:	00010197          	auipc	gp,0x10
    80000204:	e4018193          	addi	gp,gp,-448 # 80010040 <d_0_2>
    80000208:	11a1                	addi	gp,gp,-24
    8000020a:	8111b52f          	amomin.d	a0,a7,(gp)

000000008000020e <_l1>:
    8000020e:	00030f17          	auipc	t5,0x30
    80000212:	e42f0f13          	addi	t5,t5,-446 # 80030050 <d_2_3>
    80000216:	012f0423          	sb	s2,8(t5)

000000008000021a <_l2>:
    8000021a:	c0052b73          	csrrs	s6,cycle,a0
    8000021e:	c0052b73          	csrrs	s6,cycle,a0
    80000222:	c0052b73          	csrrs	s6,cycle,a0
    80000226:	c0052b73          	csrrs	s6,cycle,a0
    8000022a:	c0052b73          	csrrs	s6,cycle,a0
    8000022e:	c0052b73          	csrrs	s6,cycle,a0
    80000232:	c0052b73          	csrrs	s6,cycle,a0
    80000236:	c0052b73          	csrrs	s6,cycle,a0
    8000023a:	c0052b73          	csrrs	s6,cycle,a0

000000008000023e <_l3>:
    8000023e:	79e95a63          	bge	s2,t5,800009d2 <_l166>

0000000080000242 <_l4>:
    80000242:	a1259f53          	flt.s	t5,fa1,fs2

0000000080000246 <_l5>:
    80000246:	004f0d4b          	fnmsub.s	fs10,ft10,ft4,ft0,rne

000000008000024a <_l6>:
    8000024a:	28a61c53          	fmax.s	fs8,fa2,fa0

000000008000024e <_l7>:
    8000024e:	41c2553b          	sraw	a0,tp,t3

0000000080000252 <_l8>:
    80000252:	01f7171b          	slliw	a4,a4,0x1f

0000000080000256 <_l9>:
    80000256:	140315f3          	csrrw	a1,sscratch,t1
    8000025a:	140315f3          	csrrw	a1,sscratch,t1
    8000025e:	140315f3          	csrrw	a1,sscratch,t1
    80000262:	140315f3          	csrrw	a1,sscratch,t1
    80000266:	140315f3          	csrrw	a1,sscratch,t1
    8000026a:	140315f3          	csrrw	a1,sscratch,t1
    8000026e:	140315f3          	csrrw	a1,sscratch,t1
    80000272:	140315f3          	csrrw	a1,sscratch,t1
    80000276:	140315f3          	csrrw	a1,sscratch,t1
    8000027a:	140315f3          	csrrw	a1,sscratch,t1
    8000027e:	140315f3          	csrrw	a1,sscratch,t1

0000000080000282 <_l10>:
    80000282:	7411a3f3          	csrrs	t2,mnepc,gp

0000000080000286 <_l11>:
    80000286:	00050e97          	auipc	t4,0x50
    8000028a:	e1ae8e93          	addi	t4,t4,-486 # 800500a0 <d_4_8>
    8000028e:	01ce9803          	lh	a6,28(t4)

0000000080000292 <_l12>:
    80000292:	c07499f3          	csrrw	s3,hpmcounter7,s1
    80000296:	c07499f3          	csrrw	s3,hpmcounter7,s1
    8000029a:	c07499f3          	csrrw	s3,hpmcounter7,s1
    8000029e:	c07499f3          	csrrw	s3,hpmcounter7,s1

00000000800002a2 <_l13>:
    800002a2:	0114bef3          	csrrc	t4,ssp,s1
    800002a6:	0114bef3          	csrrc	t4,ssp,s1
    800002aa:	0114bef3          	csrrc	t4,ssp,s1
    800002ae:	0114bef3          	csrrc	t4,ssp,s1
    800002b2:	0114bef3          	csrrc	t4,ssp,s1
    800002b6:	0114bef3          	csrrc	t4,ssp,s1
    800002ba:	0114bef3          	csrrc	t4,ssp,s1
    800002be:	0114bef3          	csrrc	t4,ssp,s1
    800002c2:	0114bef3          	csrrc	t4,ssp,s1
    800002c6:	0114bef3          	csrrc	t4,ssp,s1
    800002ca:	0114bef3          	csrrc	t4,ssp,s1

00000000800002ce <_l14>:
    800002ce:	6549d763          	bge	s3,s4,8000091c <_l150>

00000000800002d2 <_l15>:
    800002d2:	403d003b          	subw	zero,s10,gp

00000000800002d6 <_l16>:
    800002d6:	00050e97          	auipc	t4,0x50
    800002da:	deae8e93          	addi	t4,t4,-534 # 800500c0 <d_4_10>
    800002de:	1ea1                	addi	t4,t4,-24
    800002e0:	41beb3af          	amoor.d	t2,s11,(t4)

00000000800002e4 <_l17>:
    800002e4:	f14f52f3          	csrrwi	t0,mhartid,30
    800002e8:	8796                	mv	a5,t0
    800002ea:	c016                	sw	t0,0(sp)

00000000800002ec <_l18>:
    800002ec:	355c2af3          	csrrs	s5,mireg4,s8
    800002f0:	355c2af3          	csrrs	s5,mireg4,s8
    800002f4:	355c2af3          	csrrs	s5,mireg4,s8
    800002f8:	355c2af3          	csrrs	s5,mireg4,s8
    800002fc:	355c2af3          	csrrs	s5,mireg4,s8

0000000080000300 <_l19>:
    80000300:	353119f3          	csrrw	s3,mireg3,sp
    80000304:	353119f3          	csrrw	s3,mireg3,sp
    80000308:	353119f3          	csrrw	s3,mireg3,sp
    8000030c:	353119f3          	csrrw	s3,mireg3,sp
    80000310:	353119f3          	csrrw	s3,mireg3,sp
    80000314:	353119f3          	csrrw	s3,mireg3,sp
    80000318:	353119f3          	csrrw	s3,mireg3,sp
    8000031c:	353119f3          	csrrw	s3,mireg3,sp
    80000320:	353119f3          	csrrw	s3,mireg3,sp

0000000080000324 <_l20>:
    80000324:	c0059873          	csrrw	a6,cycle,a1
    80000328:	c0059873          	csrrw	a6,cycle,a1
    8000032c:	c0059873          	csrrw	a6,cycle,a1
    80000330:	c0059873          	csrrw	a6,cycle,a1

0000000080000334 <_l21>:
    80000334:	00040917          	auipc	s2,0x40
    80000338:	d8c90913          	addi	s2,s2,-628 # 800400c0 <d_3_10>
    8000033c:	1971                	addi	s2,s2,-4
    8000033e:	21792f2f          	amoxor.w	t5,s7,(s2)

0000000080000342 <_l22>:
    80000342:	21cda353          	fsgnjx.s	ft6,fs11,ft8

0000000080000346 <_l23>:
    80000346:	02b35893          	srli	a7,t1,0x2b

000000008000034a <_l24>:
    8000034a:	11e60d53          	fmul.s	fs10,fa2,ft10,rne

000000008000034e <_l25>:
    8000034e:	00010397          	auipc	t2,0x10
    80000352:	e0238393          	addi	t2,t2,-510 # 80010150 <d_0_19>
    80000356:	ff73a223          	sw	s7,-28(t2)

000000008000035a <_l26>:
    8000035a:	744cfef3          	csrrci	t4,mnstatus,25
    8000035e:	8876                	mv	a6,t4

0000000080000360 <_l27>:
    80000360:	007d5e1b          	srliw	t3,s10,0x7

0000000080000364 <_l28>:
    80000364:	c00c39f3          	csrrc	s3,cycle,s8
    80000368:	c00c39f3          	csrrc	s3,cycle,s8
    8000036c:	c00c39f3          	csrrc	s3,cycle,s8
    80000370:	c00c39f3          	csrrc	s3,cycle,s8
    80000374:	c00c39f3          	csrrc	s3,cycle,s8
    80000378:	c00c39f3          	csrrc	s3,cycle,s8
    8000037c:	c00c39f3          	csrrc	s3,cycle,s8

0000000080000380 <_l29>:
    80000380:	f141a2f3          	csrrs	t0,mhartid,gp
    80000384:	f141a2f3          	csrrs	t0,mhartid,gp
    80000388:	f141a2f3          	csrrs	t0,mhartid,gp

000000008000038c <_l30>:
    8000038c:	00020a17          	auipc	s4,0x20
    80000390:	cd4a0a13          	addi	s4,s4,-812 # 80020060 <d_1_4>
    80000394:	fe9a1c23          	sh	s1,-8(s4)

0000000080000398 <_l31>:
    80000398:	f117a0f3          	csrrs	ra,mvendorid,a5

000000008000039c <_l32>:
    8000039c:	018e0abb          	addw	s5,t3,s8

00000000800003a0 <_l33>:
    800003a0:	00060b17          	auipc	s6,0x60
    800003a4:	d40b0b13          	addi	s6,s6,-704 # 800600e0 <d_5_12>
    800003a8:	8b5a                	mv	s6,s6
    800003aa:	20cb36af          	amoxor.d	a3,a2,(s6)

00000000800003ae <_l34>:
    800003ae:	00060897          	auipc	a7,0x60
    800003b2:	c7288893          	addi	a7,a7,-910 # 80060020 <d_5_0>
    800003b6:	18d1                	addi	a7,a7,-12
    800003b8:	a148a92f          	amomax.w	s2,s4,(a7)

00000000800003bc <_l35>:
    800003bc:	e0001953          	fclass.s	s2,ft0

00000000800003c0 <_l36>:
    800003c0:	c8221e73          	csrrw	t3,instreth,tp
    800003c4:	c8221e73          	csrrw	t3,instreth,tp
    800003c8:	c8221e73          	csrrw	t3,instreth,tp
    800003cc:	c8221e73          	csrrw	t3,instreth,tp
    800003d0:	c8221e73          	csrrw	t3,instreth,tp
    800003d4:	c8221e73          	csrrw	t3,instreth,tp
    800003d8:	c8221e73          	csrrw	t3,instreth,tp
    800003dc:	c8221e73          	csrrw	t3,instreth,tp
    800003e0:	c8221e73          	csrrw	t3,instreth,tp
    800003e4:	c8221e73          	csrrw	t3,instreth,tp

00000000800003e8 <_l37>:
    800003e8:	741cb673          	csrrc	a2,mnepc,s9
    800003ec:	741cb673          	csrrc	a2,mnepc,s9

00000000800003f0 <_l38>:
    800003f0:	d00509d3          	fcvt.s.w	fs3,a0,rne

00000000800003f4 <_l39>:
    800003f4:	00040e17          	auipc	t3,0x40
    800003f8:	c2ce0e13          	addi	t3,t3,-980 # 80040020 <d_3_0>
    800003fc:	8e72                	mv	t3,t3
    800003fe:	e08e32af          	amomaxu.d	t0,s0,(t3)

0000000080000402 <_l40>:
    80000402:	14493373          	csrrc	t1,sip,s2
    80000406:	14493373          	csrrc	t1,sip,s2

000000008000040a <_l41>:
    8000040a:	355217f3          	csrrw	a5,mireg4,tp
    8000040e:	355217f3          	csrrw	a5,mireg4,tp
    80000412:	355217f3          	csrrw	a5,mireg4,tp
    80000416:	355217f3          	csrrw	a5,mireg4,tp
    8000041a:	355217f3          	csrrw	a5,mireg4,tp
    8000041e:	355217f3          	csrrw	a5,mireg4,tp
    80000422:	355217f3          	csrrw	a5,mireg4,tp
    80000426:	355217f3          	csrrw	a5,mireg4,tp
    8000042a:	355217f3          	csrrw	a5,mireg4,tp
    8000042e:	355217f3          	csrrw	a5,mireg4,tp

0000000080000432 <_l42>:
    80000432:	011d9b73          	csrrw	s6,ssp,s11
    80000436:	011d9b73          	csrrw	s6,ssp,s11
    8000043a:	011d9b73          	csrrw	s6,ssp,s11
    8000043e:	011d9b73          	csrrw	s6,ssp,s11
    80000442:	011d9b73          	csrrw	s6,ssp,s11
    80000446:	011d9b73          	csrrw	s6,ssp,s11
    8000044a:	011d9b73          	csrrw	s6,ssp,s11
    8000044e:	011d9b73          	csrrw	s6,ssp,s11
    80000452:	011d9b73          	csrrw	s6,ssp,s11

0000000080000456 <_l43>:
    80000456:	00030517          	auipc	a0,0x30
    8000045a:	c4a50513          	addi	a0,a0,-950 # 800300a0 <d_2_8>
    8000045e:	ffe004b7          	lui	s1,0xffe00
    80000462:	8d25                	xor	a0,a0,s1
    80000464:	01052c27          	fsw	fa6,24(a0)

0000000080000468 <_l44>:
    80000468:	607df663          	bgeu	s11,t2,80000a74 <_l178>

000000008000046c <_l45>:
    8000046c:	00030417          	auipc	s0,0x30
    80000470:	bb440413          	addi	s0,s0,-1100 # 80030020 <d_2_0>
    80000474:	8422                	mv	s0,s0
    80000476:	08d4382f          	amoswap.d	a6,a3,(s0)

000000008000047a <_l46>:
    8000047a:	d02607d3          	fcvt.s.l	fa5,a2,rne

000000008000047e <_l47>:
    8000047e:	00030d17          	auipc	s10,0x30
    80000482:	bd2d0d13          	addi	s10,s10,-1070 # 80030050 <d_2_3>
    80000486:	8d6a                	mv	s10,s10
    80000488:	a04d392f          	amomax.d	s2,tp,(s10)

000000008000048c <_l48>:
    8000048c:	352096f3          	csrrw	a3,mireg2,ra
    80000490:	352096f3          	csrrw	a3,mireg2,ra

0000000080000494 <_l49>:
    80000494:	c00604d3          	fcvt.w.s	s1,fa2,rne

0000000080000498 <_l50>:
    80000498:	41cb803b          	subw	zero,s7,t3

000000008000049c <_l51>:
    8000049c:	c0250953          	fcvt.l.s	s2,fa0,rne

00000000800004a0 <_l52>:
    800004a0:	00000a97          	auipc	s5,0x0
    800004a4:	096a8a93          	addi	s5,s5,150 # 80000536 <_l65>
    800004a8:	000a8d67          	jalr	s10,s5

00000000800004ac <_l53>:
    800004ac:	0050d83b          	srlw	a6,ra,t0

00000000800004b0 <_l54>:
    800004b0:	21bd0953          	fsgnj.s	fs2,fs10,fs11

00000000800004b4 <_l55>:
    800004b4:	00030e17          	auipc	t3,0x30
    800004b8:	cfce0e13          	addi	t3,t3,-772 # 800301b0 <d_2_25>
    800004bc:	8e72                	mv	t3,t3
    800004be:	100e38af          	lr.d	a7,(t3)

00000000800004c2 <_l56>:
    800004c2:	15175ef3          	csrrwi	t4,sireg,14
    800004c6:	8f76                	mv	t5,t4
    800004c8:	c076                	sw	t4,0(sp)

00000000800004ca <_l57>:
    800004ca:	09b10e53          	fsub.s	ft8,ft2,fs11,rne

00000000800004ce <_l58>:
    800004ce:	002d18f3          	fsrm	a7,s10
    800004d2:	002d18f3          	fsrm	a7,s10
    800004d6:	002d18f3          	fsrm	a7,s10
    800004da:	002d18f3          	fsrm	a7,s10
    800004de:	002d18f3          	fsrm	a7,s10
    800004e2:	002d18f3          	fsrm	a7,s10
    800004e6:	002d18f3          	fsrm	a7,s10
    800004ea:	002d18f3          	fsrm	a7,s10
    800004ee:	002d18f3          	fsrm	a7,s10

00000000800004f2 <_l59>:
    800004f2:	00020a17          	auipc	s4,0x20
    800004f6:	bdea0a13          	addi	s4,s4,-1058 # 800200d0 <d_1_11>
    800004fa:	8a52                	mv	s4,s4
    800004fc:	614a352f          	amoand.d	a0,s4,(s4)

0000000080000500 <_l60>:
    80000500:	a1502ad3          	feq.s	s5,ft0,fs5

0000000080000504 <_l61>:
    80000504:	250d6ef3          	csrrsi	t4,vsiselect,26
    80000508:	82f6                	mv	t0,t4

000000008000050a <_l62>:
    8000050a:	1e411863          	bne	sp,tp,800006fa <_l108>

000000008000050e <_l63>:
    8000050e:	005e98bb          	sllw	a7,t4,t0

0000000080000512 <_l64>:
    80000512:	c0853173          	csrrc	sp,hpmcounter8,a0
    80000516:	c0853173          	csrrc	sp,hpmcounter8,a0
    8000051a:	c0853173          	csrrc	sp,hpmcounter8,a0
    8000051e:	c0853173          	csrrc	sp,hpmcounter8,a0
    80000522:	c0853173          	csrrc	sp,hpmcounter8,a0
    80000526:	c0853173          	csrrc	sp,hpmcounter8,a0
    8000052a:	c0853173          	csrrc	sp,hpmcounter8,a0
    8000052e:	c0853173          	csrrc	sp,hpmcounter8,a0
    80000532:	c0853173          	csrrc	sp,hpmcounter8,a0

0000000080000536 <_l65>:
    80000536:	00030117          	auipc	sp,0x30
    8000053a:	c5a10113          	addi	sp,sp,-934 # 80030190 <d_2_23>
    8000053e:	ec12                	sd	tp,24(sp)

0000000080000540 <_l66>:
    80000540:	50e96563          	bltu	s2,a4,80000a4a <_l175>

0000000080000544 <_l67>:
    80000544:	0d8d6317          	auipc	t1,0xd8d6

0000000080000548 <_l68>:
    80000548:	0ff0000f          	fence

000000008000054c <_l69>:
    8000054c:	296710d3          	fmax.s	ft1,fa4,fs6

0000000080000550 <_l70>:
    80000550:	07add1e3          	bge	s11,s10,80000db2 <_l245>

0000000080000554 <_l71>:
    80000554:	18041a73          	csrrw	s4,satp,s0
    80000558:	18041a73          	csrrw	s4,satp,s0
    8000055c:	18041a73          	csrrw	s4,satp,s0
    80000560:	18041a73          	csrrw	s4,satp,s0
    80000564:	18041a73          	csrrw	s4,satp,s0
    80000568:	18041a73          	csrrw	s4,satp,s0

000000008000056c <_l72>:
    8000056c:	005a06d3          	fadd.s	fa3,fs4,ft5,rne

0000000080000570 <_l73>:
    80000570:	11f685c3          	fmadd.s	fa1,fa3,ft11,ft2,rne

0000000080000574 <_l74>:
    80000574:	0ff0000f          	fence

0000000080000578 <_l75>:
    80000578:	252c3df3          	csrrc	s11,vsireg2,s8
    8000057c:	252c3df3          	csrrc	s11,vsireg2,s8
    80000580:	252c3df3          	csrrc	s11,vsireg2,s8
    80000584:	252c3df3          	csrrc	s11,vsireg2,s8
    80000588:	252c3df3          	csrrc	s11,vsireg2,s8
    8000058c:	252c3df3          	csrrc	s11,vsireg2,s8
    80000590:	252c3df3          	csrrc	s11,vsireg2,s8

0000000080000594 <_l76>:
    80000594:	30005073          	csrwi	mstatus,0
    80000598:	25285ef3          	csrrwi	t4,vsireg2,16

000000008000059c <_l77>:
    8000059c:	18e90ad3          	fdiv.s	fs5,fs2,fa4,rne

00000000800005a0 <_l78>:
    800005a0:	4f400aef          	jal	s5,80000a94 <_l182>

00000000800005a4 <_l79>:
    800005a4:	00060997          	auipc	s3,0x60
    800005a8:	b5c98993          	addi	s3,s3,-1188 # 80060100 <d_5_14>
    800005ac:	89ce                	mv	s3,s3
    800005ae:	00f9b32f          	amoadd.d	t1,a5,(s3)

00000000800005b2 <_l80>:
    800005b2:	c03b3173          	csrrc	sp,hpmcounter3,s6
    800005b6:	c03b3173          	csrrc	sp,hpmcounter3,s6
    800005ba:	c03b3173          	csrrc	sp,hpmcounter3,s6
    800005be:	c03b3173          	csrrc	sp,hpmcounter3,s6
    800005c2:	c03b3173          	csrrc	sp,hpmcounter3,s6
    800005c6:	c03b3173          	csrrc	sp,hpmcounter3,s6

00000000800005ca <_l81>:
    800005ca:	34233673          	csrrc	a2,mcause,t1
    800005ce:	34233673          	csrrc	a2,mcause,t1
    800005d2:	34233673          	csrrc	a2,mcause,t1
    800005d6:	34233673          	csrrc	a2,mcause,t1

00000000800005da <_l82>:
    800005da:	00030b97          	auipc	s7,0x30
    800005de:	b36b8b93          	addi	s7,s7,-1226 # 80030110 <d_2_15>
    800005e2:	0bd1                	addi	s7,s7,20
    800005e4:	086baeaf          	amoswap.w	t4,t1,(s7)

00000000800005e8 <_l83>:
    800005e8:	00000073          	ecall

00000000800005ec <_l84>:
    800005ec:	3216bcf3          	csrrc	s9,mcyclecfg,a3
    800005f0:	3216bcf3          	csrrc	s9,mcyclecfg,a3
    800005f4:	3216bcf3          	csrrc	s9,mcyclecfg,a3
    800005f8:	3216bcf3          	csrrc	s9,mcyclecfg,a3
    800005fc:	3216bcf3          	csrrc	s9,mcyclecfg,a3

0000000080000600 <_l85>:
    80000600:	c05112f3          	csrrw	t0,hpmcounter5,sp
    80000604:	c05112f3          	csrrw	t0,hpmcounter5,sp
    80000608:	c05112f3          	csrrw	t0,hpmcounter5,sp
    8000060c:	c05112f3          	csrrw	t0,hpmcounter5,sp
    80000610:	c05112f3          	csrrw	t0,hpmcounter5,sp

0000000080000614 <_l86>:
    80000614:	9002                	ebreak

0000000080000616 <_l87>:
    80000616:	0000100f          	fence.i

000000008000061a <_l88>:
    8000061a:	0006df13          	srli	t5,a3,0x0

000000008000061e <_l89>:
    8000061e:	08bd03d3          	fsub.s	ft7,fs10,fa1,rne

0000000080000622 <_l90>:
    80000622:	58dd894b          	fnmsub.s	fs2,fs11,fa3,fa1,rne

0000000080000626 <_l91>:
    80000626:	35789ef3          	csrrw	t4,mireg6,a7
    8000062a:	35789ef3          	csrrw	t4,mireg6,a7
    8000062e:	35789ef3          	csrrw	t4,mireg6,a7

0000000080000632 <_l92>:
    80000632:	d03a0453          	fcvt.s.lu	fs0,s4,rne

0000000080000636 <_l93>:
    80000636:	00050c97          	auipc	s9,0x50
    8000063a:	aaac8c93          	addi	s9,s9,-1366 # 800500e0 <d_4_12>
    8000063e:	8ce6                	mv	s9,s9
    80000640:	20ccb72f          	amoxor.d	a4,a2,(s9)

0000000080000644 <_l94>:
    80000644:	21441d53          	fsgnjn.s	fs10,fs0,fs4

0000000080000648 <_l95>:
    80000648:	7f65ec97          	auipc	s9,0x7f65e

000000008000064c <_l96>:
    8000064c:	c04a9773          	csrrw	a4,hpmcounter4,s5
    80000650:	c04a9773          	csrrw	a4,hpmcounter4,s5
    80000654:	c04a9773          	csrrw	a4,hpmcounter4,s5
    80000658:	c04a9773          	csrrw	a4,hpmcounter4,s5

000000008000065c <_l97>:
    8000065c:	00030497          	auipc	s1,0x30
    80000660:	ad448493          	addi	s1,s1,-1324 # 80030130 <d_2_17>
    80000664:	84a6                	mv	s1,s1
    80000666:	6194b1af          	amoand.d	gp,s9,(s1)

000000008000066a <_l98>:
    8000066a:	00040b97          	auipc	s7,0x40
    8000066e:	b56b8b93          	addi	s7,s7,-1194 # 800401c0 <d_3_26>
    80000672:	0ba1                	addi	s7,s7,8
    80000674:	602bb2af          	amoand.d	t0,sp,(s7)

0000000080000678 <_l99>:
    80000678:	1522ae73          	csrrs	t3,sireg2,t0
    8000067c:	1522ae73          	csrrs	t3,sireg2,t0
    80000680:	1522ae73          	csrrs	t3,sireg2,t0

0000000080000684 <_l100>:
    80000684:	34213373          	csrrc	t1,mcause,sp
    80000688:	34213373          	csrrc	t1,mcause,sp
    8000068c:	34213373          	csrrc	t1,mcause,sp
    80000690:	34213373          	csrrc	t1,mcause,sp
    80000694:	34213373          	csrrc	t1,mcause,sp
    80000698:	34213373          	csrrc	t1,mcause,sp
    8000069c:	34213373          	csrrc	t1,mcause,sp
    800006a0:	34213373          	csrrc	t1,mcause,sp

00000000800006a4 <_l101>:
    800006a4:	00040817          	auipc	a6,0x40
    800006a8:	b2c80813          	addi	a6,a6,-1236 # 800401d0 <d_3_27>
    800006ac:	01082803          	lw	a6,16(a6)

00000000800006b0 <_l102>:
    800006b0:	68838e9b          	addiw	t4,t2,1672

00000000800006b4 <_l103>:
    800006b4:	02d39093          	slli	ra,t2,0x2d

00000000800006b8 <_l104>:
    800006b8:	15342773          	csrrs	a4,sireg3,s0
    800006bc:	15342773          	csrrs	a4,sireg3,s0
    800006c0:	15342773          	csrrs	a4,sireg3,s0
    800006c4:	15342773          	csrrs	a4,sireg3,s0
    800006c8:	15342773          	csrrs	a4,sireg3,s0
    800006cc:	15342773          	csrrs	a4,sireg3,s0
    800006d0:	15342773          	csrrs	a4,sireg3,s0
    800006d4:	15342773          	csrrs	a4,sireg3,s0
    800006d8:	15342773          	csrrs	a4,sireg3,s0
    800006dc:	15342773          	csrrs	a4,sireg3,s0
    800006e0:	15342773          	csrrs	a4,sireg3,s0

00000000800006e4 <_l105>:
    800006e4:	256e2673          	csrrs	a2,vsireg5,t3

00000000800006e8 <_l106>:
    800006e8:	20260e53          	fsgnj.s	ft8,fa2,ft2

00000000800006ec <_l107>:
    800006ec:	00030697          	auipc	a3,0x30
    800006f0:	ac468693          	addi	a3,a3,-1340 # 800301b0 <d_2_25>
    800006f4:	86b6                	mv	a3,a3
    800006f6:	21b6aa2f          	amoxor.w	s4,s11,(a3)

00000000800006fa <_l108>:
    800006fa:	9002                	ebreak

00000000800006fc <_l109>:
    800006fc:	00010397          	auipc	t2,0x10
    80000700:	99438393          	addi	t2,t2,-1644 # 80010090 <d_0_7>
    80000704:	839e                	mv	t2,t2
    80000706:	08e3bcaf          	amoswap.d	s9,a4,(t2)

000000008000070a <_l110>:
    8000070a:	00189673          	fsflags	a2,a7

000000008000070e <_l111>:
    8000070e:	257b12f3          	csrrw	t0,vsireg6,s6
    80000712:	257b12f3          	csrrw	t0,vsireg6,s6

0000000080000716 <_l112>:
    80000716:	12c38073          	sfence.vma	t2,a2

000000008000071a <_l113>:
    8000071a:	00030f17          	auipc	t5,0x30
    8000071e:	936f0f13          	addi	t5,t5,-1738 # 80030050 <d_2_3>
    80000722:	8f7a                	mv	t5,t5
    80000724:	61bf2c2f          	amoand.w	s8,s11,(t5)

0000000080000728 <_l114>:
    80000728:	e00316d3          	fclass.s	a3,ft6

000000008000072c <_l115>:
    8000072c:	30005073          	csrwi	mstatus,0
    80000730:	740f53f3          	csrrwi	t2,mnscratch,30
    80000734:	829e                	mv	t0,t2

0000000080000736 <_l116>:
    80000736:	0011baf3          	csrrc	s5,fflags,gp
    8000073a:	0011baf3          	csrrc	s5,fflags,gp
    8000073e:	0011baf3          	csrrc	s5,fflags,gp
    80000742:	0011baf3          	csrrc	s5,fflags,gp
    80000746:	0011baf3          	csrrc	s5,fflags,gp
    8000074a:	0011baf3          	csrrc	s5,fflags,gp
    8000074e:	0011baf3          	csrrc	s5,fflags,gp
    80000752:	0011baf3          	csrrc	s5,fflags,gp
    80000756:	0011baf3          	csrrc	s5,fflags,gp
    8000075a:	0011baf3          	csrrc	s5,fflags,gp

000000008000075e <_l117>:
    8000075e:	35053ef3          	csrrc	t4,miselect,a0
    80000762:	35053ef3          	csrrc	t4,miselect,a0
    80000766:	35053ef3          	csrrc	t4,miselect,a0
    8000076a:	35053ef3          	csrrc	t4,miselect,a0
    8000076e:	35053ef3          	csrrc	t4,miselect,a0

0000000080000772 <_l118>:
    80000772:	f14c9373          	csrrw	t1,mhartid,s9
    80000776:	f14c9373          	csrrw	t1,mhartid,s9
    8000077a:	f14c9373          	csrrw	t1,mhartid,s9
    8000077e:	f14c9373          	csrrw	t1,mhartid,s9
    80000782:	f14c9373          	csrrw	t1,mhartid,s9
    80000786:	f14c9373          	csrrw	t1,mhartid,s9
    8000078a:	f14c9373          	csrrw	t1,mhartid,s9

000000008000078e <_l119>:
    8000078e:	00050297          	auipc	t0,0x50
    80000792:	9f228293          	addi	t0,t0,-1550 # 80050180 <d_4_22>
    80000796:	02c1                	addi	t0,t0,16
    80000798:	ffe006b7          	lui	a3,0xffe00
    8000079c:	00d2c2b3          	xor	t0,t0,a3
    800007a0:	40d2aeaf          	amoor.w	t4,a3,(t0)

00000000800007a4 <_l120>:
    800007a4:	00020717          	auipc	a4,0x20
    800007a8:	9bc70713          	addi	a4,a4,-1604 # 80020160 <d_1_20>
    800007ac:	0741                	addi	a4,a4,16
    800007ae:	60b736af          	amoand.d	a3,a1,(a4)

00000000800007b2 <_l121>:
    800007b2:	00000073          	ecall

00000000800007b6 <_l122>:
    800007b6:	00040817          	auipc	a6,0x40
    800007ba:	90a80813          	addi	a6,a6,-1782 # 800400c0 <d_3_10>
    800007be:	8842                	mv	a6,a6
    800007c0:	21b827af          	amoxor.w	a5,s11,(a6)

00000000800007c4 <_l123>:
    800007c4:	0001941b          	slliw	s0,gp,0x0

00000000800007c8 <_l124>:
    800007c8:	00040e97          	auipc	t4,0x40
    800007cc:	9d8e8e93          	addi	t4,t4,-1576 # 800401a0 <d_3_24>
    800007d0:	ffe00637          	lui	a2,0xffe00
    800007d4:	00ceceb3          	xor	t4,t4,a2
    800007d8:	fe2e9783          	lh	a5,-30(t4)

00000000800007dc <_l125>:
    800007dc:	00000697          	auipc	a3,0x0
    800007e0:	63a68693          	addi	a3,a3,1594 # 80000e16 <_l254>
    800007e4:	14169073          	csrw	sepc,a3
    800007e8:	10200073          	sret

00000000800007ec <_l126>:
    800007ec:	e00a9ed3          	fclass.s	t4,fs5

00000000800007f0 <_l127>:
    800007f0:	00040397          	auipc	t2,0x40
    800007f4:	8e038393          	addi	t2,t2,-1824 # 800400d0 <d_3_11>
    800007f8:	ffe00d37          	lui	s10,0xffe00
    800007fc:	01a3c3b3          	xor	t2,t2,s10
    80000800:	00038903          	lb	s2,0(t2)

0000000080000804 <_l128>:
    80000804:	c01c09d3          	fcvt.wu.s	s3,fs8,rne

0000000080000808 <_l129>:
    80000808:	157beff3          	csrrsi	t6,sireg6,23

000000008000080c <_l130>:
    8000080c:	001c1473          	fsflags	s0,s8
    80000810:	001c1473          	fsflags	s0,s8
    80000814:	001c1473          	fsflags	s0,s8

0000000080000818 <_l131>:
    80000818:	c08ab573          	csrrc	a0,hpmcounter8,s5
    8000081c:	c08ab573          	csrrc	a0,hpmcounter8,s5
    80000820:	c08ab573          	csrrc	a0,hpmcounter8,s5
    80000824:	c08ab573          	csrrc	a0,hpmcounter8,s5

0000000080000828 <_l132>:
    80000828:	a1f6a853          	feq.s	a6,fa3,ft11

000000008000082c <_l133>:
    8000082c:	580b8a53          	fsqrt.s	fs4,fs7,rne

0000000080000830 <_l134>:
    80000830:	14189173          	csrrw	sp,sepc,a7
    80000834:	14189173          	csrrw	sp,sepc,a7

0000000080000838 <_l135>:
    80000838:	00010797          	auipc	a5,0x10
    8000083c:	87878793          	addi	a5,a5,-1928 # 800100b0 <d_0_9>
    80000840:	17e1                	addi	a5,a5,-8
    80000842:	09a7b4af          	amoswap.d	s1,s10,(a5)

0000000080000846 <_l136>:
    80000846:	00040417          	auipc	s0,0x40
    8000084a:	84a40413          	addi	s0,s0,-1974 # 80040090 <d_3_7>
    8000084e:	ff942e23          	sw	s9,-4(s0)

0000000080000852 <_l137>:
    80000852:	d02c0b53          	fcvt.s.l	fs6,s8,rne

0000000080000856 <_l138>:
    80000856:	344bbc73          	csrrc	s8,mip,s7
    8000085a:	344bbc73          	csrrc	s8,mip,s7
    8000085e:	344bbc73          	csrrc	s8,mip,s7
    80000862:	344bbc73          	csrrc	s8,mip,s7
    80000866:	344bbc73          	csrrc	s8,mip,s7
    8000086a:	344bbc73          	csrrc	s8,mip,s7

000000008000086e <_l139>:
    8000086e:	14283973          	csrrc	s2,scause,a6

0000000080000872 <_l140>:
    80000872:	00020e97          	auipc	t4,0x20
    80000876:	94ee8e93          	addi	t4,t4,-1714 # 800201c0 <d_1_26>
    8000087a:	1ec1                	addi	t4,t4,-16
    8000087c:	401ebe2f          	amoor.d	t3,ra,(t4)

0000000080000880 <_l141>:
    80000880:	00010397          	auipc	t2,0x10
    80000884:	8e038393          	addi	t2,t2,-1824 # 80010160 <d_0_20>
    80000888:	13f1                	addi	t2,t2,-4
    8000088a:	4073aaaf          	amoor.w	s5,t2,(t2)

000000008000088e <_l142>:
    8000088e:	00050797          	auipc	a5,0x50
    80000892:	8d278793          	addi	a5,a5,-1838 # 80050160 <d_4_20>
    80000896:	ffe00eb7          	lui	t4,0xffe00
    8000089a:	01d7c7b3          	xor	a5,a5,t4
    8000089e:	ff87b483          	ld	s1,-8(a5)

00000000800008a2 <_l143>:
    800008a2:	39620963          	beq	tp,s6,80000c34 <_l211>

00000000800008a6 <_l144>:
    800008a6:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008aa:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008ae:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008b2:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008b6:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008ba:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008be:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008c2:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008c6:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008ca:	c03a3e73          	csrrc	t3,hpmcounter3,s4
    800008ce:	c03a3e73          	csrrc	t3,hpmcounter3,s4

00000000800008d2 <_l145>:
    800008d2:	d00d06d3          	fcvt.s.w	fa3,s10,rne

00000000800008d6 <_l146>:
    800008d6:	00000617          	auipc	a2,0x0
    800008da:	f1a60613          	addi	a2,a2,-230 # 800007f0 <_l127>
    800008de:	01e61183          	lh	gp,30(a2)

00000000800008e2 <_l147>:
    800008e2:	3448b773          	csrrc	a4,mip,a7
    800008e6:	3448b773          	csrrc	a4,mip,a7
    800008ea:	3448b773          	csrrc	a4,mip,a7
    800008ee:	3448b773          	csrrc	a4,mip,a7
    800008f2:	3448b773          	csrrc	a4,mip,a7
    800008f6:	3448b773          	csrrc	a4,mip,a7
    800008fa:	3448b773          	csrrc	a4,mip,a7
    800008fe:	3448b773          	csrrc	a4,mip,a7
    80000902:	3448b773          	csrrc	a4,mip,a7
    80000906:	3448b773          	csrrc	a4,mip,a7

000000008000090a <_l148>:
    8000090a:	d03788d3          	fcvt.s.lu	fa7,a5,rne

000000008000090e <_l149>:
    8000090e:	0003f497          	auipc	s1,0x3f
    80000912:	78248493          	addi	s1,s1,1922 # 80040090 <d_3_7>
    80000916:	04b1                	addi	s1,s1,12
    80000918:	1904ae2f          	sc.w	t3,a6,(s1)

000000008000091c <_l150>:
    8000091c:	00040497          	auipc	s1,0x40
    80000920:	87448493          	addi	s1,s1,-1932 # 80040190 <d_3_23>
    80000924:	84a6                	mv	s1,s1
    80000926:	ffe00a37          	lui	s4,0xffe00
    8000092a:	0144c4b3          	xor	s1,s1,s4
    8000092e:	a144b0af          	amomax.d	ra,s4,(s1)

0000000080000932 <_l151>:
    80000932:	304394f3          	csrrw	s1,mie,t2
    80000936:	304394f3          	csrrw	s1,mie,t2
    8000093a:	304394f3          	csrrw	s1,mie,t2
    8000093e:	304394f3          	csrrw	s1,mie,t2
    80000942:	304394f3          	csrrw	s1,mie,t2
    80000946:	304394f3          	csrrw	s1,mie,t2
    8000094a:	304394f3          	csrrw	s1,mie,t2
    8000094e:	304394f3          	csrrw	s1,mie,t2
    80000952:	304394f3          	csrrw	s1,mie,t2
    80000956:	304394f3          	csrrw	s1,mie,t2

000000008000095a <_l152>:
    8000095a:	0000fc17          	auipc	s8,0xf
    8000095e:	7e6c0c13          	addi	s8,s8,2022 # 80010140 <d_0_18>
    80000962:	004c1023          	sh	tp,0(s8)

0000000080000966 <_l153>:
    80000966:	0002fe17          	auipc	t3,0x2f
    8000096a:	72ae0e13          	addi	t3,t3,1834 # 80030090 <d_2_7>
    8000096e:	8e72                	mv	t3,t3
    80000970:	08ae242f          	amoswap.w	s0,a0,(t3)

0000000080000974 <_l154>:
    80000974:	a1f30dd3          	fle.s	s11,ft6,ft11

0000000080000978 <_l155>:
    80000978:	d90183cf          	fnmadd.s	ft7,ft3,fa6,fs11,rne

000000008000097c <_l156>:
    8000097c:	256e28f3          	csrrs	a7,vsireg5,t3

0000000080000980 <_l157>:
    80000980:	c03b87d3          	fcvt.lu.s	a5,fs7,rne

0000000080000984 <_l158>:
    80000984:	07daf313          	andi	t1,s5,125

0000000080000988 <_l159>:
    80000988:	0004fe97          	auipc	t4,0x4f
    8000098c:	7d8e8e93          	addi	t4,t4,2008 # 80050160 <d_4_20>
    80000990:	0ec1                	addi	t4,t4,16
    80000992:	216ea52f          	amoxor.w	a0,s6,(t4)

0000000080000996 <_l160>:
    80000996:	f12e7e73          	csrrci	t3,marchid,28
    8000099a:	8cf2                	mv	s9,t3

000000008000099c <_l161>:
    8000099c:	0000f417          	auipc	s0,0xf
    800009a0:	6c440413          	addi	s0,s0,1732 # 80010060 <d_0_4>
    800009a4:	0431                	addi	s0,s0,12
    800009a6:	0144212f          	amoadd.w	sp,s4,(s0)

00000000800009aa <_l162>:
    800009aa:	02800bef          	jal	s7,800009d2 <_l166>

00000000800009ae <_l163>:
    800009ae:	00060417          	auipc	s0,0x60
    800009b2:	80240413          	addi	s0,s0,-2046 # 800601b0 <d_5_25>
    800009b6:	8422                	mv	s0,s0
    800009b8:	e0d426af          	amomaxu.w	a3,a3,(s0)

00000000800009bc <_l164>:
    800009bc:	142b7373          	csrrci	t1,scause,22
    800009c0:	849a                	mv	s1,t1

00000000800009c2 <_l165>:
    800009c2:	00000a17          	auipc	s4,0x0
    800009c6:	17ea0a13          	addi	s4,s4,382 # 80000b40 <_l193>
    800009ca:	141a1073          	csrw	sepc,s4
    800009ce:	10200073          	sret

00000000800009d2 <_l166>:
    800009d2:	30005073          	csrwi	mstatus,0
    800009d6:	30405073          	csrwi	mie,0
    800009da:	f141d2f3          	csrrwi	t0,mhartid,3

00000000800009de <_l167>:
    800009de:	0004fa17          	auipc	s4,0x4f
    800009e2:	772a0a13          	addi	s4,s4,1906 # 80050150 <d_4_19>
    800009e6:	ff6a2823          	sw	s6,-16(s4)

00000000800009ea <_l168>:
    800009ea:	0003fb97          	auipc	s7,0x3f
    800009ee:	776b8b93          	addi	s7,s7,1910 # 80040160 <d_3_20>
    800009f2:	018bb403          	ld	s0,24(s7)

00000000800009f6 <_l169>:
    800009f6:	2576b973          	csrrc	s2,vsireg6,a3
    800009fa:	2576b973          	csrrc	s2,vsireg6,a3
    800009fe:	2576b973          	csrrc	s2,vsireg6,a3
    80000a02:	2576b973          	csrrc	s2,vsireg6,a3
    80000a06:	2576b973          	csrrc	s2,vsireg6,a3

0000000080000a0a <_l170>:
    80000a0a:	74139f73          	csrrw	t5,mnepc,t2
    80000a0e:	74139f73          	csrrw	t5,mnepc,t2

0000000080000a12 <_l171>:
    80000a12:	feebc013          	xori	zero,s7,-18

0000000080000a16 <_l172>:
    80000a16:	23a40f63          	beq	s0,s10,80000c54 <_l215>

0000000080000a1a <_l173>:
    80000a1a:	352624f3          	csrrs	s1,mireg2,a2
    80000a1e:	352624f3          	csrrs	s1,mireg2,a2
    80000a22:	352624f3          	csrrs	s1,mireg2,a2
    80000a26:	352624f3          	csrrs	s1,mireg2,a2
    80000a2a:	352624f3          	csrrs	s1,mireg2,a2
    80000a2e:	352624f3          	csrrs	s1,mireg2,a2
    80000a32:	352624f3          	csrrs	s1,mireg2,a2
    80000a36:	352624f3          	csrrs	s1,mireg2,a2
    80000a3a:	352624f3          	csrrs	s1,mireg2,a2
    80000a3e:	352624f3          	csrrs	s1,mireg2,a2
    80000a42:	352624f3          	csrrs	s1,mireg2,a2

0000000080000a46 <_l174>:
    80000a46:	f00d8dd3          	fmv.w.x	fs11,s11

0000000080000a4a <_l175>:
    80000a4a:	11fe0943          	fmadd.s	fs2,ft8,ft11,ft2,rne

0000000080000a4e <_l176>:
    80000a4e:	25341573          	csrrw	a0,vsireg3,s0
    80000a52:	25341573          	csrrw	a0,vsireg3,s0
    80000a56:	25341573          	csrrw	a0,vsireg3,s0
    80000a5a:	25341573          	csrrw	a0,vsireg3,s0
    80000a5e:	25341573          	csrrw	a0,vsireg3,s0
    80000a62:	25341573          	csrrw	a0,vsireg3,s0

0000000080000a66 <_l177>:
    80000a66:	0003f097          	auipc	ra,0x3f
    80000a6a:	5da08093          	addi	ra,ra,1498 # 80040040 <d_3_2>
    80000a6e:	10e1                	addi	ra,ra,-8
    80000a70:	4050be2f          	amoor.d	t3,t0,(ra)

0000000080000a74 <_l178>:
    80000a74:	00000497          	auipc	s1,0x0
    80000a78:	08448493          	addi	s1,s1,132 # 80000af8 <_l189>
    80000a7c:	01e48903          	lb	s2,30(s1)

0000000080000a80 <_l179>:
    80000a80:	d01684d3          	fcvt.s.wu	fs1,a3,rne

0000000080000a84 <_l180>:
    80000a84:	c0841a73          	csrrw	s4,hpmcounter8,s0
    80000a88:	c0841a73          	csrrw	s4,hpmcounter8,s0
    80000a8c:	c0841a73          	csrrw	s4,hpmcounter8,s0

0000000080000a90 <_l181>:
    80000a90:	c02c81d3          	fcvt.l.s	gp,fs9,rne

0000000080000a94 <_l182>:
    80000a94:	0002fa97          	auipc	s5,0x2f
    80000a98:	5dca8a93          	addi	s5,s5,1500 # 80030070 <d_2_5>
    80000a9c:	8ad6                	mv	s5,s5
    80000a9e:	20eaba2f          	amoxor.d	s4,a4,(s5)

0000000080000aa2 <_l183>:
    80000aa2:	e742a093          	slti	ra,t0,-396

0000000080000aa6 <_l184>:
    80000aa6:	000e149b          	slliw	s1,t3,0x0

0000000080000aaa <_l185>:
    80000aaa:	153331f3          	csrrc	gp,sireg3,t1
    80000aae:	153331f3          	csrrc	gp,sireg3,t1
    80000ab2:	153331f3          	csrrc	gp,sireg3,t1
    80000ab6:	153331f3          	csrrc	gp,sireg3,t1
    80000aba:	153331f3          	csrrc	gp,sireg3,t1
    80000abe:	153331f3          	csrrc	gp,sireg3,t1
    80000ac2:	153331f3          	csrrc	gp,sireg3,t1
    80000ac6:	153331f3          	csrrc	gp,sireg3,t1
    80000aca:	153331f3          	csrrc	gp,sireg3,t1

0000000080000ace <_l186>:
    80000ace:	0001f717          	auipc	a4,0x1f
    80000ad2:	58270713          	addi	a4,a4,1410 # 80020050 <d_1_3>
    80000ad6:	0761                	addi	a4,a4,24
    80000ad8:	602733af          	amoand.d	t2,sp,(a4)

0000000080000adc <_l187>:
    80000adc:	0004fc17          	auipc	s8,0x4f
    80000ae0:	584c0c13          	addi	s8,s8,1412 # 80050060 <d_4_4>
    80000ae4:	0c41                	addi	s8,s8,16
    80000ae6:	c0ec29af          	amominu.w	s3,a4,(s8)

0000000080000aea <_l188>:
    80000aea:	0003f817          	auipc	a6,0x3f
    80000aee:	61680813          	addi	a6,a6,1558 # 80040100 <d_3_14>
    80000af2:	8842                	mv	a6,a6
    80000af4:	e1a83c2f          	amomaxu.d	s8,s10,(a6)

0000000080000af8 <_l189>:
    80000af8:	00000697          	auipc	a3,0x0
    80000afc:	0f268693          	addi	a3,a3,242 # 80000bea <_l203>
    80000b00:	00068667          	jalr	a2,a3

0000000080000b04 <_l190>:
    80000b04:	00c0513b          	srlw	sp,zero,a2

0000000080000b08 <_l191>:
    80000b08:	1575bd73          	csrrc	s10,sireg6,a1
    80000b0c:	1575bd73          	csrrc	s10,sireg6,a1
    80000b10:	1575bd73          	csrrc	s10,sireg6,a1
    80000b14:	1575bd73          	csrrc	s10,sireg6,a1
    80000b18:	1575bd73          	csrrc	s10,sireg6,a1
    80000b1c:	1575bd73          	csrrc	s10,sireg6,a1
    80000b20:	1575bd73          	csrrc	s10,sireg6,a1
    80000b24:	1575bd73          	csrrc	s10,sireg6,a1
    80000b28:	1575bd73          	csrrc	s10,sireg6,a1
    80000b2c:	1575bd73          	csrrc	s10,sireg6,a1

0000000080000b30 <_l192>:
    80000b30:	00000117          	auipc	sp,0x0
    80000b34:	28610113          	addi	sp,sp,646 # 80000db6 <_l246>
    80000b38:	34111073          	csrw	mepc,sp
    80000b3c:	30200073          	mret

0000000080000b40 <_l193>:
    80000b40:	0004f117          	auipc	sp,0x4f
    80000b44:	5e010113          	addi	sp,sp,1504 # 80050120 <d_4_16>
    80000b48:	ffe000b7          	lui	ra,0xffe00
    80000b4c:	00114133          	xor	sp,sp,ra
    80000b50:	fe612227          	fsw	ft6,-28(sp)

0000000080000b54 <_l194>:
    80000b54:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b58:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b5c:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b60:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b64:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b68:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b6c:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b70:	c06932f3          	csrrc	t0,hpmcounter6,s2
    80000b74:	c06932f3          	csrrc	t0,hpmcounter6,s2

0000000080000b78 <_l195>:
    80000b78:	3518a673          	csrrs	a2,mireg,a7
    80000b7c:	3518a673          	csrrs	a2,mireg,a7
    80000b80:	3518a673          	csrrs	a2,mireg,a7
    80000b84:	3518a673          	csrrs	a2,mireg,a7

0000000080000b88 <_l196>:
    80000b88:	011495f3          	csrrw	a1,ssp,s1
    80000b8c:	011495f3          	csrrw	a1,ssp,s1
    80000b90:	011495f3          	csrrw	a1,ssp,s1
    80000b94:	011495f3          	csrrw	a1,ssp,s1
    80000b98:	011495f3          	csrrw	a1,ssp,s1
    80000b9c:	011495f3          	csrrw	a1,ssp,s1
    80000ba0:	011495f3          	csrrw	a1,ssp,s1
    80000ba4:	011495f3          	csrrw	a1,ssp,s1

0000000080000ba8 <_l197>:
    80000ba8:	0005fe97          	auipc	t4,0x5f
    80000bac:	518e8e93          	addi	t4,t4,1304 # 800600c0 <d_5_10>
    80000bb0:	8ef6                	mv	t4,t4
    80000bb2:	21aeb42f          	amoxor.d	s0,s10,(t4)

0000000080000bb6 <_l198>:
    80000bb6:	001333f3          	csrrc	t2,fflags,t1
    80000bba:	001333f3          	csrrc	t2,fflags,t1

0000000080000bbe <_l199>:
    80000bbe:	9002                	ebreak

0000000080000bc0 <_l200>:
    80000bc0:	00000c97          	auipc	s9,0x0
    80000bc4:	17ec8c93          	addi	s9,s9,382 # 80000d3e <_l237>
    80000bc8:	341c9073          	csrw	mepc,s9
    80000bcc:	30200073          	mret

0000000080000bd0 <_l201>:
    80000bd0:	0003f097          	auipc	ra,0x3f
    80000bd4:	58008093          	addi	ra,ra,1408 # 80040150 <d_3_19>
    80000bd8:	0180a283          	lw	t0,24(ra)

0000000080000bdc <_l202>:
    80000bdc:	0002f197          	auipc	gp,0x2f
    80000be0:	5d418193          	addi	gp,gp,1492 # 800301b0 <d_2_25>
    80000be4:	01d1                	addi	gp,gp,20
    80000be6:	0071a82f          	amoadd.w	a6,t2,(gp)

0000000080000bea <_l203>:
    80000bea:	010ad7bb          	srlw	a5,s5,a6

0000000080000bee <_l204>:
    80000bee:	0000100f          	fence.i

0000000080000bf2 <_l205>:
    80000bf2:	bbd93213          	sltiu	tp,s2,-1091

0000000080000bf6 <_l206>:
    80000bf6:	d00004d3          	fcvt.s.w	fs1,zero,rne

0000000080000bfa <_l207>:
    80000bfa:	c007ba73          	csrrc	s4,cycle,a5
    80000bfe:	c007ba73          	csrrc	s4,cycle,a5
    80000c02:	c007ba73          	csrrc	s4,cycle,a5
    80000c06:	c007ba73          	csrrc	s4,cycle,a5
    80000c0a:	c007ba73          	csrrc	s4,cycle,a5
    80000c0e:	c007ba73          	csrrc	s4,cycle,a5
    80000c12:	c007ba73          	csrrc	s4,cycle,a5
    80000c16:	c007ba73          	csrrc	s4,cycle,a5
    80000c1a:	c007ba73          	csrrc	s4,cycle,a5

0000000080000c1e <_l208>:
    80000c1e:	0003f297          	auipc	t0,0x3f
    80000c22:	49228293          	addi	t0,t0,1170 # 800400b0 <d_3_9>
    80000c26:	ff52c203          	lbu	tp,-11(t0)

0000000080000c2a <_l209>:
    80000c2a:	001de2f3          	csrrsi	t0,fflags,27
    80000c2e:	8996                	mv	s3,t0

0000000080000c30 <_l210>:
    80000c30:	410ddc13          	srai	s8,s11,0x10

0000000080000c34 <_l211>:
    80000c34:	0002f417          	auipc	s0,0x2f
    80000c38:	54c40413          	addi	s0,s0,1356 # 80030180 <d_2_22>
    80000c3c:	fed401a3          	sb	a3,-29(s0)

0000000080000c40 <_l212>:
    80000c40:	41a68bbb          	subw	s7,a3,s10

0000000080000c44 <_l213>:
    80000c44:	20661e53          	fsgnjn.s	ft8,fa2,ft6

0000000080000c48 <_l214>:
    80000c48:	00000d17          	auipc	s10,0x0
    80000c4c:	044d0d13          	addi	s10,s10,68 # 80000c8c <_l221>
    80000c50:	000d0667          	jalr	a2,s10

0000000080000c54 <_l215>:
    80000c54:	d00f0753          	fcvt.s.w	fa4,t5,rne

0000000080000c58 <_l216>:
    80000c58:	22564a13          	xori	s4,a2,549

0000000080000c5c <_l217>:
    80000c5c:	0002fb17          	auipc	s6,0x2f
    80000c60:	474b0b13          	addi	s6,s6,1140 # 800300d0 <d_2_11>
    80000c64:	ffcb6983          	lwu	s3,-4(s6)

0000000080000c68 <_l218>:
    80000c68:	0002f517          	auipc	a0,0x2f
    80000c6c:	49850513          	addi	a0,a0,1176 # 80030100 <d_2_14>
    80000c70:	01750c03          	lb	s8,23(a0)

0000000080000c74 <_l219>:
    80000c74:	15329e73          	csrrw	t3,sireg3,t0
    80000c78:	15329e73          	csrrw	t3,sireg3,t0
    80000c7c:	15329e73          	csrrw	t3,sireg3,t0
    80000c80:	15329e73          	csrrw	t3,sireg3,t0
    80000c84:	15329e73          	csrrw	t3,sireg3,t0

0000000080000c88 <_l220>:
    80000c88:	55fe7513          	andi	a0,t3,1375

0000000080000c8c <_l221>:
    80000c8c:	2500a373          	csrrs	t1,vsiselect,ra
    80000c90:	2500a373          	csrrs	t1,vsiselect,ra
    80000c94:	2500a373          	csrrs	t1,vsiselect,ra
    80000c98:	2500a373          	csrrs	t1,vsiselect,ra
    80000c9c:	2500a373          	csrrs	t1,vsiselect,ra
    80000ca0:	2500a373          	csrrs	t1,vsiselect,ra
    80000ca4:	2500a373          	csrrs	t1,vsiselect,ra
    80000ca8:	2500a373          	csrrs	t1,vsiselect,ra

0000000080000cac <_l222>:
    80000cac:	143a19f3          	csrrw	s3,stval,s4
    80000cb0:	143a19f3          	csrrw	s3,stval,s4
    80000cb4:	143a19f3          	csrrw	s3,stval,s4
    80000cb8:	143a19f3          	csrrw	s3,stval,s4
    80000cbc:	143a19f3          	csrrw	s3,stval,s4

0000000080000cc0 <_l223>:
    80000cc0:	3521a7f3          	csrrs	a5,mireg2,gp
    80000cc4:	3521a7f3          	csrrs	a5,mireg2,gp
    80000cc8:	3521a7f3          	csrrs	a5,mireg2,gp

0000000080000ccc <_l224>:
    80000ccc:	c0270853          	fcvt.l.s	a6,fa4,rne

0000000080000cd0 <_l225>:
    80000cd0:	0003f617          	auipc	a2,0x3f
    80000cd4:	3b060613          	addi	a2,a2,944 # 80040080 <d_3_6>
    80000cd8:	01862c03          	lw	s8,24(a2)

0000000080000cdc <_l226>:
    80000cdc:	30005073          	csrwi	mstatus,0
    80000ce0:	f1497373          	csrrci	t1,mhartid,18
    80000ce4:	8e1a                	mv	t3,t1

0000000080000ce6 <_l227>:
    80000ce6:	a1cc1353          	flt.s	t1,fs8,ft8

0000000080000cea <_l228>:
    80000cea:	d054864b          	fnmsub.s	fa2,fs1,ft5,fs10,rne

0000000080000cee <_l229>:
    80000cee:	002eabf3          	csrrs	s7,frm,t4
    80000cf2:	002eabf3          	csrrs	s7,frm,t4
    80000cf6:	002eabf3          	csrrs	s7,frm,t4
    80000cfa:	002eabf3          	csrrs	s7,frm,t4
    80000cfe:	002eabf3          	csrrs	s7,frm,t4
    80000d02:	002eabf3          	csrrs	s7,frm,t4
    80000d06:	002eabf3          	csrrs	s7,frm,t4
    80000d0a:	002eabf3          	csrrs	s7,frm,t4

0000000080000d0e <_l230>:
    80000d0e:	0002f197          	auipc	gp,0x2f
    80000d12:	48218193          	addi	gp,gp,1154 # 80030190 <d_2_23>
    80000d16:	01a1                	addi	gp,gp,8
    80000d18:	1831b7af          	sc.d	a5,gp,(gp)

0000000080000d1c <_l231>:
    80000d1c:	60720647          	fmsub.s	fa2,ft4,ft7,fa2,rne

0000000080000d20 <_l232>:
    80000d20:	d03602d3          	fcvt.s.lu	ft5,a2,rne

0000000080000d24 <_l233>:
    80000d24:	0003f197          	auipc	gp,0x3f
    80000d28:	49c18193          	addi	gp,gp,1180 # 800401c0 <d_3_26>
    80000d2c:	11e1                	addi	gp,gp,-8
    80000d2e:	00d1a52f          	amoadd.w	a0,a3,(gp)

0000000080000d32 <_l234>:
    80000d32:	c81ab373          	csrrc	t1,timeh,s5

0000000080000d36 <_l235>:
    80000d36:	014c003b          	addw	zero,s8,s4

0000000080000d3a <_l236>:
    80000d3a:	155a1173          	csrrw	sp,sireg4,s4

0000000080000d3e <_l237>:
    80000d3e:	25712973          	csrrs	s2,vsireg6,sp
    80000d42:	25712973          	csrrs	s2,vsireg6,sp
    80000d46:	25712973          	csrrs	s2,vsireg6,sp
    80000d4a:	25712973          	csrrs	s2,vsireg6,sp
    80000d4e:	25712973          	csrrs	s2,vsireg6,sp
    80000d52:	25712973          	csrrs	s2,vsireg6,sp
    80000d56:	25712973          	csrrs	s2,vsireg6,sp
    80000d5a:	25712973          	csrrs	s2,vsireg6,sp
    80000d5e:	25712973          	csrrs	s2,vsireg6,sp
    80000d62:	25712973          	csrrs	s2,vsireg6,sp

0000000080000d66 <_l238>:
    80000d66:	353e30f3          	csrrc	ra,mireg3,t3
    80000d6a:	353e30f3          	csrrc	ra,mireg3,t3
    80000d6e:	353e30f3          	csrrc	ra,mireg3,t3

0000000080000d72 <_l239>:
    80000d72:	09fb0953          	fsub.s	fs2,fs6,ft11,rne

0000000080000d76 <_l240>:
    80000d76:	00000617          	auipc	a2,0x0
    80000d7a:	17260613          	addi	a2,a2,370 # 80000ee8 <_good_exit>
    80000d7e:	34161073          	csrw	mepc,a2
    80000d82:	30200073          	mret

0000000080000d86 <_l241>:
    80000d86:	0004f697          	auipc	a3,0x4f
    80000d8a:	30a68693          	addi	a3,a3,778 # 80050090 <d_4_7>
    80000d8e:	00f6c803          	lbu	a6,15(a3)

0000000080000d92 <_l242>:
    80000d92:	7b07b373          	csrrc	t1,dcsr,a5
    80000d96:	7b07b373          	csrrc	t1,dcsr,a5
    80000d9a:	7b07b373          	csrrc	t1,dcsr,a5

0000000080000d9e <_l243>:
    80000d9e:	8efcae93          	slti	t4,s9,-1809

0000000080000da2 <_l244>:
    80000da2:	00000b97          	auipc	s7,0x0
    80000da6:	0e8b8b93          	addi	s7,s7,232 # 80000e8a <_l260>
    80000daa:	041b9073          	csrw	uepc,s7
    80000dae:	00200073          	uret

0000000080000db2 <_l245>:
    80000db2:	c03c83d3          	fcvt.lu.s	t2,fs9,rne

0000000080000db6 <_l246>:
    80000db6:	00fcdd9b          	srliw	s11,s9,0xf

0000000080000dba <_l247>:
    80000dba:	0000100f          	fence.i

0000000080000dbe <_l248>:
    80000dbe:	25309d73          	csrrw	s10,vsireg3,ra
    80000dc2:	25309d73          	csrrw	s10,vsireg3,ra
    80000dc6:	25309d73          	csrrw	s10,vsireg3,ra
    80000dca:	25309d73          	csrrw	s10,vsireg3,ra
    80000dce:	25309d73          	csrrw	s10,vsireg3,ra
    80000dd2:	25309d73          	csrrw	s10,vsireg3,ra
    80000dd6:	25309d73          	csrrw	s10,vsireg3,ra
    80000dda:	25309d73          	csrrw	s10,vsireg3,ra
    80000dde:	25309d73          	csrrw	s10,vsireg3,ra
    80000de2:	25309d73          	csrrw	s10,vsireg3,ra

0000000080000de6 <_l249>:
    80000de6:	0039b2f3          	csrrc	t0,fcsr,s3
    80000dea:	0039b2f3          	csrrc	t0,fcsr,s3
    80000dee:	0039b2f3          	csrrc	t0,fcsr,s3

0000000080000df2 <_l250>:
    80000df2:	0005f717          	auipc	a4,0x5f
    80000df6:	3ce70713          	addi	a4,a4,974 # 800601c0 <d_5_26>
    80000dfa:	1761                	addi	a4,a4,-8
    80000dfc:	01e73e2f          	amoadd.d	t3,t5,(a4)

0000000080000e00 <_l251>:
    80000e00:	0031d73b          	srlw	a4,gp,gp

0000000080000e04 <_l252>:
    80000e04:	58078953          	fsqrt.s	fs2,fa5,rne

0000000080000e08 <_l253>:
    80000e08:	0001f517          	auipc	a0,0x1f
    80000e0c:	3a850513          	addi	a0,a0,936 # 800201b0 <d_1_25>
    80000e10:	0551                	addi	a0,a0,20
    80000e12:	40352baf          	amoor.w	s7,gp,(a0)

0000000080000e16 <_l254>:
    80000e16:	350692f3          	csrrw	t0,miselect,a3

0000000080000e1a <_l255>:
    80000e1a:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e1e:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e22:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e26:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e2a:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e2e:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e32:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e36:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e3a:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e3e:	3571bdf3          	csrrc	s11,mireg6,gp
    80000e42:	3571bdf3          	csrrc	s11,mireg6,gp

0000000080000e46 <_l256>:
    80000e46:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e4a:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e4e:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e52:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e56:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e5a:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e5e:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e62:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e66:	257d33f3          	csrrc	t2,vsireg6,s10
    80000e6a:	257d33f3          	csrrc	t2,vsireg6,s10

0000000080000e6e <_l257>:
    80000e6e:	156b2873          	csrrs	a6,sireg5,s6
    80000e72:	156b2873          	csrrs	a6,sireg5,s6
    80000e76:	156b2873          	csrrs	a6,sireg5,s6

0000000080000e7a <_l258>:
    80000e7a:	c07c34f3          	csrrc	s1,hpmcounter7,s8
    80000e7e:	c07c34f3          	csrrc	s1,hpmcounter7,s8
    80000e82:	c07c34f3          	csrrc	s1,hpmcounter7,s8

0000000080000e86 <_l259>:
    80000e86:	d02a8853          	fcvt.s.l	fa6,s5,rne

0000000080000e8a <_l260>:
    80000e8a:	1573a473          	csrrs	s0,sireg6,t2
    80000e8e:	1573a473          	csrrs	s0,sireg6,t2
    80000e92:	1573a473          	csrrs	s0,sireg6,t2
    80000e96:	1573a473          	csrrs	s0,sireg6,t2
    80000e9a:	1573a473          	csrrs	s0,sireg6,t2
    80000e9e:	1573a473          	csrrs	s0,sireg6,t2
    80000ea2:	1573a473          	csrrs	s0,sireg6,t2
    80000ea6:	1573a473          	csrrs	s0,sireg6,t2
    80000eaa:	1573a473          	csrrs	s0,sireg6,t2
    80000eae:	1573a473          	csrrs	s0,sireg6,t2
    80000eb2:	1573a473          	csrrs	s0,sireg6,t2

0000000080000eb6 <_l261>:
    80000eb6:	00ca843b          	addw	s0,s5,a2

0000000080000eba <_l262>:
    80000eba:	0005fe97          	auipc	t4,0x5f
    80000ebe:	1f6e8e93          	addi	t4,t4,502 # 800600b0 <d_5_9>
    80000ec2:	1ea1                	addi	t4,t4,-24
    80000ec4:	605ea52f          	amoand.w	a0,t0,(t4)

0000000080000ec8 <_l263>:
    80000ec8:	01f981d3          	fadd.s	ft3,fs3,ft11,rne

0000000080000ecc <_l264>:
    80000ecc:	00000397          	auipc	t2,0x0
    80000ed0:	01c38393          	addi	t2,t2,28 # 80000ee8 <_good_exit>
    80000ed4:	34139073          	csrw	mepc,t2
    80000ed8:	30200073          	mret

0000000080000edc <_l265>:
    80000edc:	344cb373          	csrrc	t1,mip,s9
    80000ee0:	344cb373          	csrrc	t1,mip,s9
    80000ee4:	344cb373          	csrrc	t1,mip,s9

0000000080000ee8 <_good_exit>:
    80000ee8:	00002097          	auipc	ra,0x2
    80000eec:	31808093          	addi	ra,ra,792 # 80003200 <csr_output_data>
    80000ef0:	10002173          	csrr	sp,sstatus
    80000ef4:	0420bc23          	sd	sp,88(ra)
    80000ef8:	10402173          	csrr	sp,sie
    80000efc:	0620b823          	sd	sp,112(ra)
    80000f00:	10502173          	csrr	sp,stvec
    80000f04:	0620bc23          	sd	sp,120(ra)
    80000f08:	10602173          	csrr	sp,scounteren
    80000f0c:	0820b023          	sd	sp,128(ra)
    80000f10:	14002173          	csrr	sp,sscratch
    80000f14:	0820b423          	sd	sp,136(ra)
    80000f18:	14102173          	csrr	sp,sepc
    80000f1c:	0820b823          	sd	sp,144(ra)
    80000f20:	14202173          	csrr	sp,scause
    80000f24:	0820bc23          	sd	sp,152(ra)
    80000f28:	14302173          	csrr	sp,stval
    80000f2c:	0a20b023          	sd	sp,160(ra)
    80000f30:	14402173          	csrr	sp,sip
    80000f34:	f7f17113          	andi	sp,sp,-129
    80000f38:	0a20b423          	sd	sp,168(ra)
    80000f3c:	18002173          	csrr	sp,satp
    80000f40:	0a20b823          	sd	sp,176(ra)
    80000f44:	f1402173          	csrr	sp,mhartid
    80000f48:	0a20bc23          	sd	sp,184(ra)
    80000f4c:	30002173          	csrr	sp,mstatus
    80000f50:	0c20b023          	sd	sp,192(ra)
    80000f54:	30202173          	csrr	sp,medeleg
    80000f58:	0c20b423          	sd	sp,200(ra)
    80000f5c:	30302173          	csrr	sp,mideleg
    80000f60:	0c20b823          	sd	sp,208(ra)
    80000f64:	30402173          	csrr	sp,mie
    80000f68:	0c20bc23          	sd	sp,216(ra)
    80000f6c:	30502173          	csrr	sp,mtvec
    80000f70:	0e20b023          	sd	sp,224(ra)
    80000f74:	30602173          	csrr	sp,mcounteren
    80000f78:	0e20b423          	sd	sp,232(ra)
    80000f7c:	34002173          	csrr	sp,mscratch
    80000f80:	0e20b823          	sd	sp,240(ra)
    80000f84:	34102173          	csrr	sp,mepc
    80000f88:	0e20bc23          	sd	sp,248(ra)
    80000f8c:	34202173          	csrr	sp,mcause
    80000f90:	1020b023          	sd	sp,256(ra)
    80000f94:	34302173          	csrr	sp,mtval
    80000f98:	1020b423          	sd	sp,264(ra)
    80000f9c:	34402173          	csrr	sp,mip
    80000fa0:	f7f17113          	andi	sp,sp,-129
    80000fa4:	1020b823          	sd	sp,272(ra)
    80000fa8:	3a002173          	csrr	sp,pmpcfg0
    80000fac:	1020bc23          	sd	sp,280(ra)
    80000fb0:	3b002173          	csrr	sp,pmpaddr0
    80000fb4:	1220bc23          	sd	sp,312(ra)
    80000fb8:	3b102173          	csrr	sp,pmpaddr1
    80000fbc:	1420b023          	sd	sp,320(ra)
    80000fc0:	3b202173          	csrr	sp,pmpaddr2
    80000fc4:	1420b423          	sd	sp,328(ra)
    80000fc8:	3b302173          	csrr	sp,pmpaddr3
    80000fcc:	1420b823          	sd	sp,336(ra)
    80000fd0:	3b402173          	csrr	sp,pmpaddr4
    80000fd4:	1420bc23          	sd	sp,344(ra)
    80000fd8:	3b502173          	csrr	sp,pmpaddr5
    80000fdc:	1620b023          	sd	sp,352(ra)
    80000fe0:	3b602173          	csrr	sp,pmpaddr6
    80000fe4:	1620b423          	sd	sp,360(ra)
    80000fe8:	3b702173          	csrr	sp,pmpaddr7
    80000fec:	1620b823          	sd	sp,368(ra)
    80000ff0:	6519                	lui	a0,0x6
    80000ff2:	30052073          	csrs	mstatus,a0

0000000080000ff6 <fcsrs_dump>:
    80000ff6:	00102173          	frflags	sp
    80000ffa:	0420b023          	sd	sp,64(ra)
    80000ffe:	00202173          	frrm	sp
    80001002:	0420b423          	sd	sp,72(ra)
    80001006:	00302173          	frcsr	sp
    8000100a:	0420b823          	sd	sp,80(ra)

000000008000100e <reg_dump>:
    8000100e:	00002097          	auipc	ra,0x2
    80001012:	ff208093          	addi	ra,ra,-14 # 80003000 <begin_signature>
    80001016:	0000b023          	sd	zero,0(ra)
    8000101a:	0020b823          	sd	sp,16(ra)
    8000101e:	0030bc23          	sd	gp,24(ra)
    80001022:	0240b023          	sd	tp,32(ra)
    80001026:	0250b423          	sd	t0,40(ra)
    8000102a:	0260b823          	sd	t1,48(ra)
    8000102e:	0270bc23          	sd	t2,56(ra)
    80001032:	0480b023          	sd	s0,64(ra)
    80001036:	0490b423          	sd	s1,72(ra)
    8000103a:	04a0b823          	sd	a0,80(ra)
    8000103e:	04b0bc23          	sd	a1,88(ra)
    80001042:	06c0b023          	sd	a2,96(ra)
    80001046:	06d0b423          	sd	a3,104(ra)
    8000104a:	06e0b823          	sd	a4,112(ra)
    8000104e:	06f0bc23          	sd	a5,120(ra)
    80001052:	0900b023          	sd	a6,128(ra)
    80001056:	0910b423          	sd	a7,136(ra)
    8000105a:	0920b823          	sd	s2,144(ra)
    8000105e:	0930bc23          	sd	s3,152(ra)
    80001062:	0b40b023          	sd	s4,160(ra)
    80001066:	0b50b423          	sd	s5,168(ra)
    8000106a:	0b60b823          	sd	s6,176(ra)
    8000106e:	0b70bc23          	sd	s7,184(ra)
    80001072:	0d80b023          	sd	s8,192(ra)
    80001076:	0d90b423          	sd	s9,200(ra)
    8000107a:	0db0bc23          	sd	s11,216(ra)
    8000107e:	0fc0b023          	sd	t3,224(ra)
    80001082:	0fd0b423          	sd	t4,232(ra)
    80001086:	0fe0b823          	sd	t5,240(ra)

000000008000108a <freg_dump>:
    8000108a:	00002097          	auipc	ra,0x2
    8000108e:	07608093          	addi	ra,ra,118 # 80003100 <freg_output_data>
    80001092:	0010a427          	fsw	ft1,8(ra)
    80001096:	0020a827          	fsw	ft2,16(ra)
    8000109a:	0270ac27          	fsw	ft7,56(ra)
    8000109e:	0490a427          	fsw	fs1,72(ra)
    800010a2:	04a0a827          	fsw	fa0,80(ra)
    800010a6:	06c0a027          	fsw	fa2,96(ra)
    800010aa:	06d0a427          	fsw	fa3,104(ra)
    800010ae:	0b50a427          	fsw	fs5,168(ra)
    800010b2:	0b60a827          	fsw	fs6,176(ra)
    800010b6:	0d90a427          	fsw	fs9,200(ra)
    800010ba:	0da0a827          	fsw	fs10,208(ra)
    800010be:	0fc0a027          	fsw	ft8,224(ra)
    800010c2:	0fd0a427          	fsw	ft9,232(ra)
    800010c6:	0fe0a827          	fsw	ft10,240(ra)
    800010ca:	0ff0ac27          	fsw	ft11,248(ra)
    800010ce:	00002097          	auipc	ra,0x2
    800010d2:	03208093          	addi	ra,ra,50 # 80003100 <freg_output_data>
    800010d6:	0000b027          	fsd	ft0,0(ra)
    800010da:	0030bc27          	fsd	ft3,24(ra)
    800010de:	0240b027          	fsd	ft4,32(ra)
    800010e2:	0250b427          	fsd	ft5,40(ra)
    800010e6:	0260b827          	fsd	ft6,48(ra)
    800010ea:	0480b027          	fsd	fs0,64(ra)
    800010ee:	04b0bc27          	fsd	fa1,88(ra)
    800010f2:	06e0b827          	fsd	fa4,112(ra)
    800010f6:	06f0bc27          	fsd	fa5,120(ra)
    800010fa:	0900b027          	fsd	fa6,128(ra)
    800010fe:	0910b427          	fsd	fa7,136(ra)
    80001102:	0920b827          	fsd	fs2,144(ra)
    80001106:	0930bc27          	fsd	fs3,152(ra)
    8000110a:	0b40b027          	fsd	fs4,160(ra)
    8000110e:	0b70bc27          	fsd	fs7,184(ra)
    80001112:	0d80b027          	fsd	fs8,192(ra)
    80001116:	0db0bc27          	fsd	fs11,216(ra)
    8000111a:	4501                	li	a0,0
    8000111c:	0005006b          	.insn	4, 0x0005006b
    80001120:	4185                	li	gp,1
    80001122:	00001f17          	auipc	t5,0x1
    80001126:	ec3f2f23          	sw	gp,-290(t5) # 80002000 <tohost>
    8000112a:	a001                	j	8000112a <freg_dump+0xa0>

000000008000112c <_end_main>:
    8000112c:	00000013          	nop
    80001130:	00000013          	nop
    80001134:	00000013          	nop
    80001138:	00000013          	nop
    8000113c:	00000013          	nop
    80001140:	00000013          	nop
    80001144:	00000013          	nop

Disassembly of section .tohost:

0000000080002000 <tohost>:
	...

0000000080002040 <fromhost>:
	...

Disassembly of section .data:

0000000080003000 <begin_signature>:
	...

0000000080003008 <reg_x1_output>:
	...

0000000080003010 <reg_x2_output>:
	...

0000000080003018 <reg_x3_output>:
	...

0000000080003020 <reg_x4_output>:
	...

0000000080003028 <reg_x5_output>:
	...

0000000080003030 <reg_x6_output>:
	...

0000000080003038 <reg_x7_output>:
	...

0000000080003040 <reg_x8_output>:
	...

0000000080003048 <reg_x9_output>:
	...

0000000080003050 <reg_x10_output>:
	...

0000000080003058 <reg_x11_output>:
	...

0000000080003060 <reg_x12_output>:
	...

0000000080003068 <reg_x13_output>:
	...

0000000080003070 <reg_x14_output>:
	...

0000000080003078 <reg_x15_output>:
	...

0000000080003080 <reg_x16_output>:
	...

0000000080003088 <reg_x17_output>:
	...

0000000080003090 <reg_x18_output>:
	...

0000000080003098 <reg_x19_output>:
	...

00000000800030a0 <reg_x20_output>:
	...

00000000800030a8 <reg_x21_output>:
	...

00000000800030b0 <reg_x22_output>:
	...

00000000800030b8 <reg_x23_output>:
	...

00000000800030c0 <reg_x24_output>:
	...

00000000800030c8 <reg_x25_output>:
	...

00000000800030d0 <reg_x26_output>:
	...

00000000800030d8 <reg_x27_output>:
	...

00000000800030e0 <reg_x28_output>:
	...

00000000800030e8 <reg_x29_output>:
	...

00000000800030f0 <reg_x30_output>:
	...

00000000800030f8 <reg_x31_output>:
	...

0000000080003100 <freg_output_data>:
	...

0000000080003108 <reg_f1_output>:
	...

0000000080003110 <reg_f2_output>:
	...

0000000080003118 <reg_f3_output>:
	...

0000000080003120 <reg_f4_output>:
	...

0000000080003128 <reg_f5_output>:
	...

0000000080003130 <reg_f6_output>:
	...

0000000080003138 <reg_f7_output>:
	...

0000000080003140 <reg_f8_output>:
	...

0000000080003148 <reg_f9_output>:
	...

0000000080003150 <reg_f10_output>:
	...

0000000080003158 <reg_f11_output>:
	...

0000000080003160 <reg_f12_output>:
	...

0000000080003168 <reg_f13_output>:
	...

0000000080003170 <reg_f14_output>:
	...

0000000080003178 <reg_f15_output>:
	...

0000000080003180 <reg_f16_output>:
	...

0000000080003188 <reg_f17_output>:
	...

0000000080003190 <reg_f18_output>:
	...

0000000080003198 <reg_f19_output>:
	...

00000000800031a0 <reg_f20_output>:
	...

00000000800031a8 <reg_f21_output>:
	...

00000000800031b0 <reg_f22_output>:
	...

00000000800031b8 <reg_f23_output>:
	...

00000000800031c0 <reg_f24_output>:
	...

00000000800031c8 <reg_f25_output>:
	...

00000000800031d0 <reg_f26_output>:
	...

00000000800031d8 <reg_f27_output>:
	...

00000000800031e0 <reg_f28_output>:
	...

00000000800031e8 <reg_f29_output>:
	...

00000000800031f0 <reg_f30_output>:
	...

00000000800031f8 <reg_f31_output>:
	...

0000000080003200 <csr_output_data>:
	...

0000000080003208 <uie_output>:
	...

0000000080003210 <utvec_output>:
	...

0000000080003218 <uscratch_output>:
	...

0000000080003220 <uepc_output>:
	...

0000000080003228 <ucause_output>:
	...

0000000080003230 <utval_output>:
	...

0000000080003238 <uip_output>:
	...

0000000080003240 <fflags_output>:
	...

0000000080003248 <frm_output>:
	...

0000000080003250 <fcsr_output>:
	...

0000000080003258 <sstatus_output>:
	...

0000000080003260 <sedeleg_output>:
	...

0000000080003268 <sideleg_output>:
	...

0000000080003270 <sie_output>:
	...

0000000080003278 <stvec_output>:
	...

0000000080003280 <scounteren_output>:
	...

0000000080003288 <sscratch_output>:
	...

0000000080003290 <sepc_output>:
	...

0000000080003298 <scause_output>:
	...

00000000800032a0 <stval_output>:
	...

00000000800032a8 <sip_output>:
	...

00000000800032b0 <satp_output>:
	...

00000000800032b8 <mhartid_output>:
	...

00000000800032c0 <mstatus_output>:
	...

00000000800032c8 <medeleg_output>:
	...

00000000800032d0 <mideleg_output>:
	...

00000000800032d8 <mie_output>:
	...

00000000800032e0 <mtvec_output>:
	...

00000000800032e8 <mcounteren_output>:
	...

00000000800032f0 <mscratch_output>:
	...

00000000800032f8 <mepc_output>:
	...

0000000080003300 <mcause_output>:
	...

0000000080003308 <mtval_output>:
	...

0000000080003310 <mip_output>:
	...

0000000080003318 <pmpcfg0_output>:
	...

0000000080003320 <pmpcfg1_output>:
	...

0000000080003328 <pmpcfg2_output>:
	...

0000000080003330 <pmpcfg3_output>:
	...

0000000080003338 <pmpaddr0_output>:
	...

0000000080003340 <pmpaddr1_output>:
	...

0000000080003348 <pmpaddr2_output>:
	...

0000000080003350 <pmpaddr3_output>:
	...

0000000080003358 <pmpaddr4_output>:
	...

0000000080003360 <pmpaddr5_output>:
	...

0000000080003368 <pmpaddr6_output>:
	...

0000000080003370 <pmpaddr7_output>:
	...

0000000080003378 <pmpaddr8_output>:
	...

0000000080003380 <pmpaddr9_output>:
	...

0000000080003388 <pmpaddr10_output>:
	...

0000000080003390 <pmpaddr11_output>:
	...

0000000080003398 <pmpaddr12_output>:
	...

00000000800033a0 <pmpaddr13_output>:
	...

00000000800033a8 <pmpaddr14_output>:
	...

00000000800033b0 <pmpaddr15_output>:
	...

00000000800033b8 <mcycle_output>:
	...

00000000800033c0 <minstret_output>:
	...

00000000800033c8 <mcycleh_output>:
	...

00000000800033d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	8af4                	.insn	2, 0x8af4
    80010002:	7161                	addi	sp,sp,-432
    80010004:	5f31                	li	t5,-20
    80010006:	b989                	j	8000fc58 <end_signature+0xc878>
    80010008:	562e                	lw	a2,232(sp)
    8001000a:	ffae                	sd	a1,504(sp)
    8001000c:	ac2fd9e3          	bge	t6,sp,8000fade <end_signature+0xc6fe>
    80010010:	a2ac                	fsd	fa1,64(a3)
    80010012:	464a                	lw	a2,144(sp)
    80010014:	4aa6a143          	fmadd.d	ft2,fa3,fa0,fs1,rdn
    80010018:	e255                	bnez	a2,800100bc <d_0_9+0xc>
    8001001a:	c9d9                	beqz	a1,800100b0 <d_0_9>
    8001001c:	3676                	fld	fa2,376(sp)
    8001001e:	b58a                	fsd	ft2,232(sp)

0000000080010020 <d_0_0>:
    80010020:	8cc2a2e3          	.insn	4, 0x8cc2a2e3
    80010024:	2c95                	addiw	s9,s9,5
    80010026:	d3a2148f          	.insn	4, 0xd3a2148f
    8001002a:	2d10                	fld	fa2,24(a0)
    8001002c:	821a                	mv	tp,t1
    8001002e:	8818                	.insn	2, 0x8818

0000000080010030 <d_0_1>:
    80010030:	f651d547          	.insn	4, 0xf651d547
    80010034:	e811                	bnez	s0,80010048 <d_0_2+0x8>
    80010036:	7b26                	ld	s6,104(sp)
    80010038:	d720                	sw	s0,104(a4)
    8001003a:	e10e                	sd	gp,128(sp)
    8001003c:	736fbabb          	.insn	4, 0x736fbabb

0000000080010040 <d_0_2>:
    80010040:	114c                	addi	a1,sp,164
    80010042:	6c91                	lui	s9,0x4
    80010044:	ab10                	fsd	fa2,16(a4)
    80010046:	7ac38593          	addi	a1,t2,1964
    8001004a:	c754                	sw	a3,12(a4)
    8001004c:	1a50                	addi	a2,sp,308
    8001004e:	52de                	lw	t0,244(sp)

0000000080010050 <d_0_3>:
    80010050:	a28c                	fsd	fa1,0(a3)
    80010052:	7cdd                	lui	s9,0xffff7
    80010054:	21e12a73          	csrrs	s4,0x21e,sp
    80010058:	3479                	addiw	s0,s0,-2
    8001005a:	bafc6c23          	.insn	4, 0xbafc6c23
    8001005e:	0562                	slli	a0,a0,0x18

0000000080010060 <d_0_4>:
    80010060:	b475                	j	8000fb0c <end_signature+0xc72c>
    80010062:	50ea                	lw	ra,184(sp)
    80010064:	74cd1fff 244fda00 	.insn	12, 0x85df3cbe244fda0074cd1fff
    8001006c:	85df3cbe 

0000000080010070 <d_0_5>:
    80010070:	d9a7ec93          	ori	s9,a5,-614
    80010074:	7966                	ld	s2,120(sp)
    80010076:	e486                	sd	ra,72(sp)
    80010078:	a094                	fsd	fa3,0(s1)
    8001007a:	2146                	fld	ft2,80(sp)
    8001007c:	4f10                	lw	a2,24(a4)
    8001007e:	aaa0                	fsd	fs0,80(a3)

0000000080010080 <d_0_6>:
    80010080:	9a70ef1b          	.insn	4, 0x9a70ef1b
    80010084:	e4ae                	sd	a1,72(sp)
    80010086:	fa18                	sd	a4,48(a2)
    80010088:	bff5                	j	80010084 <d_0_6+0x4>
    8001008a:	9f5e8db7          	lui	s11,0x9f5e8
    8001008e:	          	.insn	4, 0xccc04acf

0000000080010090 <d_0_7>:
    80010090:	ccc0                	sw	s0,28(s1)
    80010092:	1e3c                	addi	a5,sp,824
    80010094:	88a2                	mv	a7,s0
    80010096:	bf46                	fsd	fa7,440(sp)
    80010098:	66f5                	lui	a3,0x1d
    8001009a:	9aca                	add	s5,s5,s2
    8001009c:	77fd                	lui	a5,0xfffff
    8001009e:	          	.insn	4, 0x5d9fab8b

00000000800100a0 <d_0_8>:
    800100a0:	5d9f f425 6967      	.insn	6, 0x6967f4255d9f
    800100a6:	0de8                	addi	a0,sp,732
    800100a8:	924c                	.insn	2, 0x924c
    800100aa:	12cd                	addi	t0,t0,-13
    800100ac:	167a                	slli	a2,a2,0x3e
    800100ae:	3341                	addiw	t1,t1,-16 # ffffffff8d8d6534 <_end+0xffffffff0d876334>

00000000800100b0 <d_0_9>:
    800100b0:	e818beb3          	.insn	4, 0xe818beb3
    800100b4:	5792                	lw	a5,36(sp)
    800100b6:	9b2c                	.insn	2, 0x9b2c
    800100b8:	9f39                	addw	a4,a4,a4
    800100ba:	54d1                	li	s1,-12
    800100bc:	42c0                	lw	s0,4(a3)
    800100be:	7e4c                	ld	a1,184(a2)

00000000800100c0 <d_0_10>:
    800100c0:	c1b1                	beqz	a1,80010104 <d_0_14+0x4>
    800100c2:	be30                	fsd	fa2,120(a2)
    800100c4:	774e                	ld	a4,240(sp)
    800100c6:	4980abfb          	.insn	4, 0x4980abfb
    800100ca:	79d9                	lui	s3,0xffff6
    800100cc:	1ba4                	addi	s1,sp,504
    800100ce:	7764                	ld	s1,232(a4)

00000000800100d0 <d_0_11>:
    800100d0:	1c1a                	slli	s8,s8,0x26
    800100d2:	7d18                	ld	a4,56(a0)
    800100d4:	87629703          	lh	a4,-1930(t0)
    800100d8:	d0e4                	sw	s1,100(s1)
    800100da:	43b1                	li	t2,12
    800100dc:	ff2d                	bnez	a4,80010056 <d_0_3+0x6>
    800100de:	98a8                	.insn	2, 0x98a8

00000000800100e0 <d_0_12>:
    800100e0:	d7b4                	sw	a3,104(a5)
    800100e2:	159e                	slli	a1,a1,0x27
    800100e4:	12f1                	addi	t0,t0,-4
    800100e6:	1b8a                	slli	s7,s7,0x22
    800100e8:	c182                	sw	zero,192(sp)
    800100ea:	b922                	fsd	fs0,176(sp)
    800100ec:	fda5                	bnez	a1,80010064 <d_0_4+0x4>
    800100ee:	b17d                	j	8000fd9c <end_signature+0xc9bc>

00000000800100f0 <d_0_13>:
    800100f0:	d701b2d7          	.insn	4, 0xd701b2d7
    800100f4:	c7bc5e5b          	.insn	4, 0xc7bc5e5b
    800100f8:	befd                	j	8000fcf6 <end_signature+0xc916>
    800100fa:	efea                	sd	s10,472(sp)
    800100fc:	e3c1                	bnez	a5,8001017c <d_0_21+0xc>
    800100fe:	580a                	lw	a6,160(sp)

0000000080010100 <d_0_14>:
    80010100:	14199cfb          	.insn	4, 0x14199cfb
    80010104:	380d                	addiw	a6,a6,-29
    80010106:	a36c                	fsd	fa1,192(a4)
    80010108:	267c                	fld	fa5,200(a2)
    8001010a:	f27d                	bnez	a2,800100f0 <d_0_13>
    8001010c:	12a2                	slli	t0,t0,0x28
    8001010e:	b590                	fsd	fa2,40(a1)

0000000080010110 <d_0_15>:
    80010110:	2ff9                	addiw	t6,t6,30
    80010112:	077d                	addi	a4,a4,31
    80010114:	b1bc0ddb          	.insn	4, 0xb1bc0ddb
    80010118:	13fd                	addi	t2,t2,-1
    8001011a:	b0e2                	fsd	fs8,96(sp)
    8001011c:	a7bfb33b          	.insn	4, 0xa7bfb33b

0000000080010120 <d_0_16>:
    80010120:	c28d                	beqz	a3,80010142 <d_0_18+0x2>
    80010122:	1f99                	addi	t6,t6,-26
    80010124:	841a                	mv	s0,t1
    80010126:	9f9a                	add	t6,t6,t1
    80010128:	0e0c47e7          	.insn	4, 0x0e0c47e7
    8001012c:	bbba                	fsd	fa4,496(sp)
    8001012e:	cde9                	beqz	a1,80010208 <_end_data0+0x8>

0000000080010130 <d_0_17>:
    80010130:	8582                	jr	a1
    80010132:	291f85fb          	.insn	4, 0x291f85fb
    80010136:	7fe4                	ld	s1,248(a5)
    80010138:	e6f8                	sd	a4,200(a3)
    8001013a:	6bb4                	ld	a3,80(a5)
    8001013c:	9645                	srai	a2,a2,0x31
    8001013e:	79f2                	ld	s3,312(sp)

0000000080010140 <d_0_18>:
    80010140:	5296                	lw	t0,100(sp)
    80010142:	b6a0                	fsd	fs0,104(a3)
    80010144:	687d                	lui	a6,0x1f
    80010146:	2c29                	addiw	s8,s8,10
    80010148:	5b3e                	lw	s6,236(sp)
    8001014a:	a4bd                	j	800103b8 <_end_data0+0x1b8>
    8001014c:	85d164e3          	bltu	sp,t4,8000f994 <end_signature+0xc5b4>

0000000080010150 <d_0_19>:
    80010150:	b1a5                	j	8000fdb8 <end_signature+0xc9d8>
    80010152:	fa40                	sd	s0,176(a2)
    80010154:	0fd7185b          	.insn	4, 0x0fd7185b
    80010158:	97e6                	add	a5,a5,s9
    8001015a:	4fdc                	lw	a5,28(a5)
    8001015c:	5f215267          	.insn	4, 0x5f215267

0000000080010160 <d_0_20>:
    80010160:	0cc2                	slli	s9,s9,0x10
    80010162:	56fd8dbf c17d9cae 	.insn	8, 0xc17d9cae56fd8dbf
    8001016a:	e859                	bnez	s0,80010200 <_end_data0>
    8001016c:	ecba                	sd	a4,88(sp)
    8001016e:	          	.insn	4, 0x9c6671c3

0000000080010170 <d_0_21>:
    80010170:	9c66                	add	s8,s8,s9
    80010172:	d504                	sw	s1,40(a0)
    80010174:	ea1a                	sd	t1,272(sp)
    80010176:	9fe6                	add	t6,t6,s9
    80010178:	725a                	ld	tp,432(sp)
    8001017a:	ce41                	beqz	a2,80010212 <_end_data0+0x12>
    8001017c:	c3a1                	beqz	a5,800101bc <d_0_25+0xc>
    8001017e:	8d4c                	.insn	2, 0x8d4c

0000000080010180 <d_0_22>:
    80010180:	9535                	srai	a0,a0,0x2d
    80010182:	a2ed                	j	8001036c <_end_data0+0x16c>
    80010184:	98f0                	.insn	2, 0x98f0
    80010186:	6e7f d83c 16eb c2ac 	.insn	22, 0xd8febc460b696d0dfd5c03e97478c2ac16ebd83c6e7f
    8001018e:	7478    
    80010196:	   

0000000080010190 <d_0_23>:
    80010190:	03e9                	addi	t2,t2,26
    80010192:	fd5c                	sd	a5,184(a0)
    80010194:	6d0d                	lui	s10,0x3
    80010196:	0b69                	addi	s6,s6,26
    80010198:	bc46                	fsd	fa7,56(sp)
    8001019a:	d8fe                	sw	t6,112(sp)
    8001019c:	e80dd82f          	.insn	4, 0xe80dd82f

00000000800101a0 <d_0_24>:
    800101a0:	ca4d                	beqz	a2,80010252 <_end_data0+0x52>
    800101a2:	b7ba                	fsd	fa4,488(sp)
    800101a4:	4972                	lw	s2,28(sp)
    800101a6:	e2f2                	sd	t3,320(sp)
    800101a8:	80f1                	srli	s1,s1,0x1c
    800101aa:	592cd6d7          	.insn	4, 0x592cd6d7
    800101ae:	c2d5                	beqz	a3,80010252 <_end_data0+0x52>

00000000800101b0 <d_0_25>:
    800101b0:	7d6e338b          	.insn	4, 0x7d6e338b
    800101b4:	b5be                	fsd	fa5,232(sp)
    800101b6:	d3ac                	sw	a1,96(a5)
    800101b8:	c3d0                	sw	a2,4(a5)
    800101ba:	54e8                	lw	a0,108(s1)
    800101bc:	a318                	fsd	fa4,0(a4)
    800101be:	          	auipc	a7,0x32b4

00000000800101c0 <d_0_26>:
    800101c0:	b2b2032b          	.insn	4, 0xb2b2032b
    800101c4:	39688a03          	lb	s4,918(a7) # 832c4554 <_end+0x3264354>
    800101c8:	6bda                	ld	s7,400(sp)
    800101ca:	de41                	beqz	a2,80010162 <d_0_20+0x2>
    800101cc:	9a98                	.insn	2, 0x9a98
    800101ce:	0e9d                	addi	t4,t4,7

00000000800101d0 <d_0_27>:
    800101d0:	ba11                	j	8000fae4 <end_signature+0xc704>
    800101d2:	047c                	addi	a5,sp,524
    800101d4:	8f0c                	.insn	2, 0x8f0c
    800101d6:	5f62                	lw	t5,56(sp)
    800101d8:	d336                	sw	a3,164(sp)
    800101da:	7a61                	lui	s4,0xffff8
    800101dc:	5b31                	li	s6,-20
    800101de:	4ec4                	lw	s1,28(a3)
    800101e0:	56b8                	lw	a4,104(a3)
    800101e2:	1038                	addi	a4,sp,40
    800101e4:	f73a                	sd	a4,424(sp)
    800101e6:	8212                	mv	tp,tp
    800101e8:	8d74                	.insn	2, 0x8d74
    800101ea:	70f4                	ld	a3,224(s1)
    800101ec:	a748                	fsd	fa0,136(a4)
    800101ee:	c61c                	sw	a5,8(a2)
    800101f0:	a4b2                	fsd	fa2,72(sp)
    800101f2:	51d4                	lw	a3,36(a1)
    800101f4:	510e5d4f          	fnmadd.s	fs10,ft8,fa6,fa0,unknown
    800101f8:	5e26                	lw	t3,104(sp)
    800101fa:	88e1b5af          	.insn	4, 0x88e1b5af
    800101fe:	810d                	srli	a0,a0,0x3

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	05a8                	addi	a0,sp,712
    80020002:	a91c                	fsd	fa5,16(a0)
    80020004:	6c5f 1e22 aa50      	.insn	6, 0xaa501e226c5f
    8002000a:	0064                	addi	s1,sp,12
    8002000c:	ce42                	sw	a6,28(sp)
    8002000e:	d2bd                	beqz	a3,8001ff74 <_end_data0+0xfd74>
    80020010:	bb39                	j	8001fd2e <_end_data0+0xfb2e>
    80020012:	f851                	bnez	s0,8001ffa6 <_end_data0+0xfda6>
    80020014:	1a4a                	slli	s4,s4,0x32
    80020016:	5202                	lw	tp,32(sp)
    80020018:	0ee8154b          	.insn	4, 0x0ee8154b
    8002001c:	b379                	j	8001fdaa <_end_data0+0xfbaa>
    8002001e:	          	.insn	4, 0x600289af

0000000080020020 <d_1_0>:
    80020020:	6002                	.insn	2, 0x6002
    80020022:	4502b28f          	.insn	4, 0x4502b28f
    80020026:	4195                	li	gp,5
    80020028:	2fbd                	addiw	t6,t6,15
    8002002a:	d14e                	sw	s3,160(sp)
    8002002c:	7459                	lui	s0,0xffff6
    8002002e:	4311                	li	t1,4

0000000080020030 <d_1_1>:
    80020030:	6a72                	ld	s4,280(sp)
    80020032:	b982                	fsd	ft0,240(sp)
    80020034:	1541                	addi	a0,a0,-16 # 5ff0 <_start-0x7fffa010>
    80020036:	6027a0ab          	.insn	4, 0x6027a0ab
    8002003a:	9069                	srli	s0,s0,0x3a
    8002003c:	26319387          	.insn	4, 0x26319387

0000000080020040 <d_1_2>:
    80020040:	1f32                	slli	t5,t5,0x2c
    80020042:	8928                	.insn	2, 0x8928
    80020044:	9198                	.insn	2, 0x9198
    80020046:	ae1c                	fsd	fa5,24(a2)
    80020048:	e864                	sd	s1,208(s0)
    8002004a:	5b60                	lw	s0,116(a4)
    8002004c:	66c4                	ld	s1,136(a3)
    8002004e:	          	.insn	4, 0xcf5de5cb

0000000080020050 <d_1_3>:
    80020050:	cf5d                	beqz	a4,8002010e <d_1_14+0xe>
    80020052:	3e60                	fld	fs0,248(a2)
    80020054:	8aac                	.insn	2, 0x8aac
    80020056:	89f8bbf7          	.insn	4, 0x89f8bbf7
    8002005a:	45c8                	lw	a0,12(a1)
    8002005c:	b37803bb          	.insn	4, 0xb37803bb

0000000080020060 <d_1_4>:
    80020060:	c89a                	sw	t1,80(sp)
    80020062:	d011                	beqz	s0,8001ff66 <_end_data0+0xfd66>
    80020064:	88ea                	mv	a7,s10
    80020066:	eeec0ed3          	.insn	4, 0xeeec0ed3
    8002006a:	504e                	.insn	2, 0x504e
    8002006c:	a7e9                	j	80020836 <_end_data1+0x636>
    8002006e:	dcd2                	sw	s4,120(sp)

0000000080020070 <d_1_5>:
    80020070:	dcc4ce8f          	.insn	4, 0xdcc4ce8f
    80020074:	d9d6                	sw	s5,240(sp)
    80020076:	8646                	mv	a2,a7
    80020078:	245f c76e 3579      	.insn	6, 0x3579c76e245f
    8002007e:	4c3e                	lw	s8,204(sp)

0000000080020080 <d_1_6>:
    80020080:	c46a                	sw	s10,8(sp)
    80020082:	0130                	addi	a2,sp,136
    80020084:	04057fa3          	.insn	4, 0x04057fa3
    80020088:	5db6                	lw	s11,108(sp)
    8002008a:	08d9                	addi	a7,a7,22
    8002008c:	b678                	fsd	fa4,232(a2)
    8002008e:	8dc6                	mv	s11,a7

0000000080020090 <d_1_7>:
    80020090:	520a                	lw	tp,160(sp)
    80020092:	c332                	sw	a2,132(sp)
    80020094:	71c4                	ld	s1,160(a1)
    80020096:	e04d                	bnez	s0,80020138 <d_1_17+0x8>
    80020098:	d642                	sw	a6,44(sp)
    8002009a:	b460                	fsd	fs0,232(s0)
    8002009c:	7ae6                	ld	s5,120(sp)
    8002009e:	          	.insn	4, 0xd223abdb

00000000800200a0 <d_1_8>:
    800200a0:	66e4d223          	.insn	4, 0x66e4d223
    800200a4:	4a3bf0bf 5698ddd1 	.insn	8, 0x5698ddd14a3bf0bf
    800200ac:	3162                	fld	ft2,56(sp)
    800200ae:	059d                	addi	a1,a1,7

00000000800200b0 <d_1_9>:
    800200b0:	b346                	fsd	fa7,416(sp)
    800200b2:	c926                	sw	s1,144(sp)
    800200b4:	ee88584f          	.insn	4, 0xee88584f
    800200b8:	7a90                	ld	a2,48(a3)
    800200ba:	415d                	li	sp,23
    800200bc:	2ab2                	fld	fs5,264(sp)
    800200be:	b1c5                	j	8001fd9e <_end_data0+0xfb9e>

00000000800200c0 <d_1_10>:
    800200c0:	b714                	fsd	fa3,40(a4)
    800200c2:	4a56                	lw	s4,84(sp)
    800200c4:	0091                	addi	ra,ra,4
    800200c6:	0f34                	addi	a3,sp,920
    800200c8:	f6e5                	bnez	a3,800200b0 <d_1_9>
    800200ca:	b45a                	fsd	fs6,40(sp)
    800200cc:	3269                	addiw	tp,tp,-6 # fffffffffffffffa <_end+0xffffffff7ff9fdfa>
    800200ce:	1a7d                	addi	s4,s4,-1 # ffffffffffff7fff <_end+0xffffffff7ff97dff>

00000000800200d0 <d_1_11>:
    800200d0:	c168                	sw	a0,68(a0)
    800200d2:	7eb4                	ld	a3,120(a3)
    800200d4:	7bd9                	lui	s7,0xffff6
    800200d6:	f96d                	bnez	a0,800200c8 <d_1_10+0x8>
    800200d8:	49a42f23          	sw	s10,1182(s0) # ffffffffffff649e <_end+0xffffffff7ff9629e>
    800200dc:	1265                	addi	tp,tp,-7 # fffffffffffffff9 <_end+0xffffffff7ff9fdf9>
    800200de:	          	.insn	4, 0xbc9a2b33

00000000800200e0 <d_1_12>:
    800200e0:	bc9a                	fsd	ft6,120(sp)
    800200e2:	64f8                	ld	a4,200(s1)
    800200e4:	bf96                	fsd	ft5,504(sp)
    800200e6:	8828                	.insn	2, 0x8828
    800200e8:	a3c25ea3          	.insn	4, 0xa3c25ea3
    800200ec:	ec11                	bnez	s0,80020108 <d_1_14+0x8>
    800200ee:	          	.insn	4, 0x5d016ba3

00000000800200f0 <d_1_13>:
    800200f0:	5d01                	li	s10,-32
    800200f2:	9d491b3f bdef6071 	.insn	8, 0xbdef60719d491b3f
    800200fa:	6f39                	lui	t5,0xe
    800200fc:	89b4                	.insn	2, 0x89b4
    800200fe:	b594                	fsd	fa3,40(a1)

0000000080020100 <d_1_14>:
    80020100:	8728                	.insn	2, 0x8728
    80020102:	493e                	lw	s2,204(sp)
    80020104:	f87a                	sd	t5,48(sp)
    80020106:	4eee                	lw	t4,216(sp)
    80020108:	dad5                	beqz	a3,800200bc <d_1_9+0xc>
    8002010a:	b2b6                	fsd	fa3,352(sp)
    8002010c:	f1c6                	sd	a7,224(sp)
    8002010e:	9402                	jalr	s0

0000000080020110 <d_1_15>:
    80020110:	5a6c                	lw	a1,116(a2)
    80020112:	63acb667          	.insn	4, 0x63acb667
    80020116:	7d02                	ld	s10,32(sp)
    80020118:	b889ddd3          	.insn	4, 0xb889ddd3
    8002011c:	2721                	addiw	a4,a4,8
    8002011e:	2bb6                	fld	fs7,328(sp)

0000000080020120 <d_1_16>:
    80020120:	0655                	addi	a2,a2,21
    80020122:	59995d2f          	.insn	4, 0x59995d2f
    80020126:	c116                	sw	t0,128(sp)
    80020128:	eb5a                	sd	s6,400(sp)
    8002012a:	7da41667          	.insn	4, 0x7da41667
    8002012e:	935f        	.insn	6, 0xbf371fa7935f

0000000080020130 <d_1_17>:
    80020130:	bf371fa7          	.insn	4, 0xbf371fa7
    80020134:	d986cb2b          	.insn	4, 0xd986cb2b
    80020138:	448fd847          	.insn	4, 0x448fd847
    8002013c:	5029                	c.li	zero,-22
    8002013e:	          	.insn	4, 0xccbfcbd7

0000000080020140 <d_1_18>:
    80020140:	d663ccbf 9917c5cd 	.insn	8, 0x9917c5cdd663ccbf
    80020148:	276b002f          	.insn	4, 0x276b002f
    8002014c:	b35e                	fsd	fs7,416(sp)
    8002014e:	d316                	sw	t0,164(sp)

0000000080020150 <d_1_19>:
    80020150:	86c2                	mv	a3,a6
    80020152:	6760                	ld	s0,200(a4)
    80020154:	4add1ceb          	.insn	4, 0x4add1ceb
    80020158:	b804                	fsd	fs1,48(s0)
    8002015a:	5f9c                	lw	a5,56(a5)
    8002015c:	c379                	beqz	a4,80020222 <_end_data1+0x22>
    8002015e:	de01                	beqz	a2,80020076 <d_1_5+0x6>

0000000080020160 <d_1_20>:
    80020160:	f0b8                	sd	a4,96(s1)
    80020162:	124a                	slli	tp,tp,0x32
    80020164:	d66e                	sw	s11,44(sp)
    80020166:	468d                	li	a3,3
    80020168:	7ac44f83          	lbu	t6,1964(s0)
    8002016c:	e2cd                	bnez	a3,8002020e <_end_data1+0xe>
    8002016e:	3b26                	fld	fs6,104(sp)

0000000080020170 <d_1_21>:
    80020170:	3118                	fld	fa4,32(a0)
    80020172:	b0430d8f          	.insn	4, 0xb0430d8f
    80020176:	379edd3b          	.insn	4, 0x379edd3b
    8002017a:	d6f6                	sw	t4,108(sp)
    8002017c:	2301                	sext.w	t1,t1
    8002017e:	706e                	.insn	2, 0x706e

0000000080020180 <d_1_22>:
    80020180:	80e1                	srli	s1,s1,0x18
    80020182:	6389                	lui	t2,0x2
    80020184:	47e630a7          	fsd	ft10,1121(a2)
    80020188:	48d6                	lw	a7,84(sp)
    8002018a:	579d                	li	a5,-25
    8002018c:	fc90                	sd	a2,56(s1)
    8002018e:	dc59                	beqz	s0,8002012c <d_1_16+0xc>

0000000080020190 <d_1_23>:
    80020190:	6998                	ld	a4,16(a1)
    80020192:	9295                	srli	a3,a3,0x25
    80020194:	4242                	lw	tp,16(sp)
    80020196:	8338                	.insn	2, 0x8338
    80020198:	9cf54823          	.insn	4, 0x9cf54823
    8002019c:	dd02                	sw	zero,184(sp)
    8002019e:	d4f5                	beqz	s1,8002018a <d_1_22+0xa>

00000000800201a0 <d_1_24>:
    800201a0:	6d96e0a7          	vsoxseg4ei32.v	v1,(a3),v25,v0.t
    800201a4:	78b0fac7          	fmsub.s	fs5,ft1,fa1,fa5
    800201a8:	9ddf2e0f          	.insn	4, 0x9ddf2e0f
    800201ac:	cc21                	beqz	s0,80020204 <_end_data1+0x4>
    800201ae:	1fde                	slli	t6,t6,0x37

00000000800201b0 <d_1_25>:
    800201b0:	977a                	add	a4,a4,t5
    800201b2:	c6ca382f          	amominu.d.aqrl	a6,a2,(s4)
    800201b6:	dbb6                	sw	a3,244(sp)
    800201b8:	25c6                	fld	fa1,80(sp)
    800201ba:	f0b5                	bnez	s1,8002011e <d_1_15+0xe>
    800201bc:	2fc8                	fld	fa0,152(a5)
    800201be:	dbac                	sw	a1,112(a5)

00000000800201c0 <d_1_26>:
    800201c0:	ecf5                	bnez	s1,800202bc <_end_data1+0xbc>
    800201c2:	3e60e2e3          	bltu	ra,t1,80020da6 <_end_data1+0xba6>
    800201c6:	b758ad43          	.insn	4, 0xb758ad43
    800201ca:	d702                	sw	zero,172(sp)
    800201cc:	5922fc67          	.insn	4, 0x5922fc67

00000000800201d0 <d_1_27>:
    800201d0:	de32                	sw	a2,60(sp)
    800201d2:	c448                	sw	a0,12(s0)
    800201d4:	b6734327          	.insn	4, 0xb6734327
    800201d8:	7a41                	lui	s4,0xffff0
    800201da:	f13653bf a3643adf 	.insn	8, 0xa3643adff13653bf
    800201e2:	e97d                	bnez	a0,800202d8 <_end_data1+0xd8>
    800201e4:	b38a                	fsd	ft2,480(sp)
    800201e6:	4639                	li	a2,14
    800201e8:	d699                	beqz	a3,800200f6 <d_1_13+0x6>
    800201ea:	50aa                	lw	ra,168(sp)
    800201ec:	a40c                	fsd	fa1,8(s0)
    800201ee:	8ee87bd7          	.insn	4, 0x8ee87bd7
    800201f2:	2099                	addiw	ra,ra,6
    800201f4:	e976                	sd	t4,144(sp)
    800201f6:	d29fd6af          	.insn	4, 0xd29fd6af
    800201fa:	1ffa                	slli	t6,t6,0x3e
    800201fc:	a490                	fsd	fa2,8(s1)
    800201fe:	3958                	fld	fa4,176(a0)

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	53cd                	li	t2,-13
    80030002:	f1b8                	sd	a4,96(a1)
    80030004:	e328                	sd	a0,64(a4)
    80030006:	ffd2                	sd	s4,504(sp)
    80030008:	0908                	addi	a0,sp,144
    8003000a:	be70                	fsd	fa2,248(a2)
    8003000c:	f404                	sd	s1,40(s0)
    8003000e:	0b75                	addi	s6,s6,29
    80030010:	d15e3dd3          	.insn	4, 0xd15e3dd3
    80030014:	c7f0                	sw	a2,76(a5)
    80030016:	0076                	c.slli	zero,0x1d
    80030018:	f0f4                	sd	a3,224(s1)
    8003001a:	418dd097          	auipc	ra,0x418dd
    8003001e:	f82d                	bnez	s0,8002ff90 <_end_data1+0xfd90>

0000000080030020 <d_2_0>:
    80030020:	438c                	lw	a1,0(a5)
    80030022:	7cdc                	ld	a5,184(s1)
    80030024:	635a                	ld	t1,400(sp)
    80030026:	1092                	slli	ra,ra,0x24
    80030028:	039e                	slli	t2,t2,0x7
    8003002a:	f524                	sd	s1,104(a0)
    8003002c:	cc04                	sw	s1,24(s0)
    8003002e:	afee                	fsd	fs11,472(sp)

0000000080030030 <d_2_1>:
    80030030:	539e                	lw	t2,228(sp)
    80030032:	532c                	lw	a1,96(a4)
    80030034:	bdac1ee7          	.insn	4, 0xbdac1ee7
    80030038:	1e10ef4b          	.insn	4, 0x1e10ef4b
    8003003c:	d011                	beqz	s0,8002ff40 <_end_data1+0xfd40>
    8003003e:	9860                	.insn	2, 0x9860

0000000080030040 <d_2_2>:
    80030040:	447dcae7          	.insn	4, 0x447dcae7
    80030044:	b38d                	j	8002fda6 <_end_data1+0xfba6>
    80030046:	6cc2                	ld	s9,16(sp)
    80030048:	e23fc5c3          	fmadd.d	fa1,ft11,ft3,ft8,rmm
    8003004c:	a76e                	fsd	fs11,392(sp)
    8003004e:	f362                	sd	s8,416(sp)

0000000080030050 <d_2_3>:
    80030050:	320a                	fld	ft4,160(sp)
    80030052:	8d4e                	mv	s10,s3
    80030054:	b375                	j	8002fe00 <_end_data1+0xfc00>
    80030056:	6401fca3          	.insn	4, 0x6401fca3
    8003005a:	d1a4                	sw	s1,96(a1)
    8003005c:	39eeaf2b          	.insn	4, 0x39eeaf2b

0000000080030060 <d_2_4>:
    80030060:	2d35                	addiw	s10,s10,13 # 300d <_start-0x7fffcff3>
    80030062:	7281                	lui	t0,0xfffe0
    80030064:	de2d                	beqz	a2,8002ffde <_end_data1+0xfdde>
    80030066:	c63a                	sw	a4,12(sp)
    80030068:	f544                	sd	s1,168(a0)
    8003006a:	489a                	lw	a7,132(sp)
    8003006c:	1c3c                	addi	a5,sp,568
    8003006e:	8e4d                	or	a2,a2,a1

0000000080030070 <d_2_5>:
    80030070:	4036                	.insn	2, 0x4036
    80030072:	d2c5                	beqz	a3,80030012 <_random_data2+0x12>
    80030074:	0668996f          	jal	s2,800b90da <_end+0x58eda>
    80030078:	f040                	sd	s0,160(s0)
    8003007a:	fc36                	sd	a3,56(sp)
    8003007c:	effd                	bnez	a5,8003017a <d_2_21+0xa>
    8003007e:	ba60                	fsd	fs0,240(a2)

0000000080030080 <d_2_6>:
    80030080:	2cdd                	addiw	s9,s9,23 # ffffffffffff7017 <_end+0xffffffff7ff96e17>
    80030082:	b7de                	fsd	fs7,488(sp)
    80030084:	c9ee                	sw	s11,208(sp)
    80030086:	094c                	addi	a1,sp,148
    80030088:	f20c                	sd	a1,32(a2)
    8003008a:	9162                	add	sp,sp,s8
    8003008c:	ab15                	j	800305c0 <_end_data2+0x3c0>
    8003008e:	a9ed                	j	80030588 <_end_data2+0x388>

0000000080030090 <d_2_7>:
    80030090:	4dd9                	li	s11,22
    80030092:	45a1                	li	a1,8
    80030094:	0064                	addi	s1,sp,12
    80030096:	a59f 1c5d d041      	.insn	6, 0xd0411c5da59f
    8003009c:	3c99f1e3          	bgeu	s3,s1,80030c5e <_end_data2+0xa5e>

00000000800300a0 <d_2_8>:
    800300a0:	f5c6                	sd	a7,232(sp)
    800300a2:	3bad                	addiw	s7,s7,-21 # ffffffffffff5feb <_end+0xffffffff7ff95deb>
    800300a4:	bb3b1123          	sh	s3,-1118(s6)
    800300a8:	0ffd                	addi	t6,t6,31
    800300aa:	a5f5                	j	80030796 <_end_data2+0x596>
    800300ac:	b1a0                	fsd	fs0,96(a1)
    800300ae:	88e9                	andi	s1,s1,26

00000000800300b0 <d_2_9>:
    800300b0:	4a0e                	lw	s4,192(sp)
    800300b2:	eb7d                	bnez	a4,800301a8 <d_2_24+0x8>
    800300b4:	6ff0                	ld	a2,216(a5)
    800300b6:	fe7a                	sd	t5,312(sp)
    800300b8:	5842                	lw	a6,48(sp)
    800300ba:	285aab3f  	.insn	8, 0xe91e443c285aab3f

00000000800300c0 <d_2_10>:
    800300c0:	e91e                	sd	t2,144(sp)
    800300c2:	51d8                	lw	a4,36(a1)
    800300c4:	8060                	.insn	2, 0x8060
    800300c6:	bc8a                	fsd	ft2,120(sp)
    800300c8:	526c                	lw	a1,100(a2)
    800300ca:	7612                	ld	a2,288(sp)
    800300cc:	b37c                	fsd	fa5,224(a4)
    800300ce:	0648                	addi	a0,sp,772

00000000800300d0 <d_2_11>:
    800300d0:	2178                	fld	fa4,192(a0)
    800300d2:	34da814f          	.insn	4, 0x34da814f
    800300d6:	e576                	sd	t4,136(sp)
    800300d8:	07c9                	addi	a5,a5,18 # fffffffffffff012 <_end+0xffffffff7ff9ee12>
    800300da:	6666                	ld	a2,88(sp)
    800300dc:	e846                	sd	a7,16(sp)
    800300de:	9b62                	add	s6,s6,s8

00000000800300e0 <d_2_12>:
    800300e0:	2bec                	fld	fa1,208(a5)
    800300e2:	df2e                	sw	a1,188(sp)
    800300e4:	d1f2                	sw	t3,224(sp)
    800300e6:	050917e3          	bne	s2,a6,80030934 <_end_data2+0x734>
    800300ea:	7c0dbf43          	.insn	4, 0x7c0dbf43
    800300ee:	a21e                	fsd	ft7,256(sp)

00000000800300f0 <d_2_13>:
    800300f0:	b115                	j	8002fd14 <_end_data1+0xfb14>
    800300f2:	0085                	addi	ra,ra,1 # c190d01b <_end+0x418ace1b>
    800300f4:	ec5e                	sd	s7,24(sp)
    800300f6:	20acd38b          	.insn	4, 0x20acd38b
    800300fa:	495d                	li	s2,23
    800300fc:	ff46                	sd	a7,440(sp)
    800300fe:	f170                	sd	a2,224(a0)

0000000080030100 <d_2_14>:
    80030100:	023a                	slli	tp,tp,0xe
    80030102:	af1d                	j	80030838 <_end_data2+0x638>
    80030104:	538c                	lw	a1,32(a5)
    80030106:	47692e73          	csrrs	t3,0x476,s2
    8003010a:	e51f c18d 9028      	.insn	6, 0x9028c18de51f

0000000080030110 <d_2_15>:
    80030110:	3311                	addiw	t1,t1,-28
    80030112:	5a01                	li	s4,-32
    80030114:	1dcc                	addi	a1,sp,756
    80030116:	f506                	sd	ra,168(sp)
    80030118:	36a4                	fld	fs1,104(a3)
    8003011a:	14b0                	addi	a2,sp,616
    8003011c:	ae90                	fsd	fa2,24(a3)
    8003011e:	1289                	addi	t0,t0,-30 # fffffffffffdffe2 <_end+0xffffffff7ff7fde2>

0000000080030120 <d_2_16>:
    80030120:	fcf8                	sd	a4,248(s1)
    80030122:	f3d0                	sd	a2,160(a5)
    80030124:	1c14bc77          	.insn	4, 0x1c14bc77
    80030128:	75a6                	ld	a1,104(sp)
    8003012a:	32f15c6b          	.insn	4, 0x32f15c6b
    8003012e:	5e39                	li	t3,-18

0000000080030130 <d_2_17>:
    80030130:	981e                	add	a6,a6,t2
    80030132:	1085                	addi	ra,ra,-31
    80030134:	f74d                	bnez	a4,800300de <d_2_11+0xe>
    80030136:	e832                	sd	a2,16(sp)
    80030138:	d5ce                	sw	s3,232(sp)
    8003013a:	4bed                	li	s7,27
    8003013c:	372a                	fld	fa4,168(sp)
    8003013e:	4e4a                	lw	t3,144(sp)

0000000080030140 <d_2_18>:
    80030140:	113d                	addi	sp,sp,-17
    80030142:	5fc2                	lw	t6,48(sp)
    80030144:	7df2                	ld	s11,312(sp)
    80030146:	ad4d                	j	800307f8 <_end_data2+0x5f8>
    80030148:	1f9d                	addi	t6,t6,-25
    8003014a:	65e1                	lui	a1,0x18
    8003014c:	7631                	lui	a2,0xfffec
    8003014e:	94b1                	srai	s1,s1,0x2c

0000000080030150 <d_2_19>:
    80030150:	4afd                	li	s5,31
    80030152:	19b93337          	lui	t1,0x19b93
    80030156:	0c60                	addi	s0,sp,540
    80030158:	3f44                	fld	fs1,184(a4)
    8003015a:	5e98                	lw	a4,56(a3)
    8003015c:	607f 9748   	.insn	22, 0xb8926cccd781123783a172e1059cf01354159748607f
    80030164:	    
    8003016c:	   

0000000080030160 <d_2_20>:
    80030160:	5415                	li	s0,-27
    80030162:	059cf013          	andi	zero,s9,89
    80030166:	72e1                	lui	t0,0xffff8
    80030168:	83a1                	srli	a5,a5,0x8
    8003016a:	d7811237          	lui	tp,0xd7811
    8003016e:	6ccc                	ld	a1,152(s1)

0000000080030170 <d_2_21>:
    80030170:	b892                	fsd	ft4,112(sp)
    80030172:	eb92                	sd	tp,464(sp)
    80030174:	33a4                	fld	fs1,96(a5)
    80030176:	1aae1ee3          	bne	t3,a0,80030b32 <_end_data2+0x932>
    8003017a:	6976                	ld	s2,344(sp)
    8003017c:	4eff 36aa   	.insn	18, 0xeae93f9bd3164f6c94704a8aad0336aa4eff
    80030184:	    
    8003018c:	 

0000000080030180 <d_2_22>:
    80030180:	4a8aad03          	lw	s10,1192(s5)
    80030184:	9470                	.insn	2, 0x9470
    80030186:	4f6c                	lw	a1,92(a4)
    80030188:	d316                	sw	t0,164(sp)
    8003018a:	eae93f9b          	.insn	4, 0xeae93f9b
    8003018e:	  	.insn	8, 0x75ac766bb1f9ca3f

0000000080030190 <d_2_23>:
    80030190:	b1f9                	j	8002fe5e <_end_data1+0xfc5e>
    80030192:	75ac766b          	.insn	4, 0x75ac766b
    80030196:	e0e9                	bnez	s1,80030258 <_end_data2+0x58>
    80030198:	3acd                	addiw	s5,s5,-13
    8003019a:	76af59d7          	vmfgt.vf	v19,v10,ft10
    8003019e:	  	.insn	8, 0xbd2e31475951623f

00000000800301a0 <d_2_24>:
    800301a0:	5951                	li	s2,-12
    800301a2:	bd2e3147          	.insn	4, 0xbd2e3147
    800301a6:	3268                	fld	fa0,224(a2)
    800301a8:	67b6                	ld	a5,328(sp)
    800301aa:	ac8c                	fsd	fa1,24(s1)
    800301ac:	9ebc                	.insn	2, 0x9ebc
    800301ae:	e1d9                	bnez	a1,80030234 <_end_data2+0x34>

00000000800301b0 <d_2_25>:
    800301b0:	16b8                	addi	a4,sp,872
    800301b2:	88a4                	.insn	2, 0x88a4
    800301b4:	fd24                	sd	s1,120(a0)
    800301b6:	62eddacf          	fnmadd.d	fs5,fs11,fa4,fa2,unknown
    800301ba:	9634                	.insn	2, 0x9634
    800301bc:	fe20                	sd	s0,120(a2)
    800301be:	37a8                	fld	fa0,104(a5)

00000000800301c0 <d_2_26>:
    800301c0:	52d0                	lw	a2,36(a3)
    800301c2:	7ffe                	ld	t6,504(sp)
    800301c4:	281c                	fld	fa5,16(s0)
    800301c6:	c269332f          	amominu.d.rl	t1,t1,(s2)
    800301ca:	477c                	lw	a5,76(a4)
    800301cc:	262c                	fld	fa1,72(a2)
    800301ce:	92d6                	add	t0,t0,s5

00000000800301d0 <d_2_27>:
    800301d0:	5b09607b          	.insn	4, 0x5b09607b
    800301d4:	a87bdfa7          	vssseg6e16.v	v31,(s7),t2,v0.t
    800301d8:	a5f0                	fsd	fa2,200(a1)
    800301da:	b07e                	fsd	ft11,32(sp)
    800301dc:	05ff d2f3 828c fc19 	.insn	10, 0xe1a8fc19828cd2f305ff
    800301e4:	e1a8 
    800301e6:	a320                	fsd	fs0,64(a4)
    800301e8:	e2ea                	sd	s10,320(sp)
    800301ea:	734e5cbb          	.insn	4, 0x734e5cbb
    800301ee:	3f5b6eb7          	lui	t4,0x3f5b6
    800301f2:	102b8c6b          	.insn	4, 0x102b8c6b
    800301f6:	1215ac97          	auipc	s9,0x1215a
    800301fa:	bcea                	fsd	fs10,120(sp)
    800301fc:	1f7c                	addi	a5,sp,956
    800301fe:	aab0                	fsd	fa2,80(a3)

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	4fd6                	lw	t6,84(sp)
    80040002:	2aa1                	addiw	s5,s5,8
    80040004:	8268                	.insn	2, 0x8268
    80040006:	05df a3f4 dfcf      	.insn	6, 0xdfcfa3f405df
    8004000c:	72b2                	ld	t0,296(sp)
    8004000e:	98e1                	andi	s1,s1,-8
    80040010:	966d                	srai	a2,a2,0x3b
    80040012:	e8062d33          	.insn	4, 0xe8062d33
    80040016:	5a31                	li	s4,-20
    80040018:	d109                	beqz	a0,8003ff1a <_end_data2+0xfd1a>
    8004001a:	34d2                	fld	fs1,304(sp)
    8004001c:	701d                	c.lui	zero,0xfffe7
    8004001e:	b694                	fsd	fa3,40(a3)

0000000080040020 <d_3_0>:
    80040020:	c54ad80f          	.insn	4, 0xc54ad80f
    80040024:	69a2                	ld	s3,8(sp)
    80040026:	6da1                	lui	s11,0x8
    80040028:	4008                	lw	a0,0(s0)
    8004002a:	72728f17          	auipc	t5,0x72728
    8004002e:	18d4                	addi	a3,sp,116

0000000080040030 <d_3_1>:
    80040030:	4ef2                	lw	t4,28(sp)
    80040032:	6c91                	lui	s9,0x4
    80040034:	1ecb602f          	.insn	4, 0x1ecb602f
    80040038:	1e0a                	slli	t3,t3,0x22
    8004003a:	3b74cc4f          	fnmadd.d	fs8,fs1,fs7,ft7,rmm
    8004003e:	f206                	sd	ra,288(sp)

0000000080040040 <d_3_2>:
    80040040:	d71c243f 372ef749 	.insn	8, 0x372ef749d71c243f
    80040048:	da44                	sw	s1,52(a2)
    8004004a:	52a6                	lw	t0,104(sp)
    8004004c:	b14486fb          	.insn	4, 0xb14486fb

0000000080040050 <d_3_3>:
    80040050:	3120                	fld	fs0,96(a0)
    80040052:	1cb08d0b          	.insn	4, 0x1cb08d0b
    80040056:	ad1d                	j	8004068c <_end_data3+0x48c>
    80040058:	622d                	lui	tp,0xb
    8004005a:	359e                	fld	fa1,480(sp)
    8004005c:	b275                	j	8003fa08 <_end_data2+0xf808>
    8004005e:	c4d2                	sw	s4,72(sp)

0000000080040060 <d_3_4>:
    80040060:	2c2dde13          	.insn	4, 0x2c2dde13
    80040064:	034d                	addi	t1,t1,19 # 19b93013 <_start-0x6646cfed>
    80040066:	a8f4                	fsd	fa3,208(s1)
    80040068:	a33a                	fsd	fa4,384(sp)
    8004006a:	e5ad                	bnez	a1,800400d4 <d_3_11+0x4>
    8004006c:	3e6a                	fld	ft8,184(sp)
    8004006e:	          	.insn	4, 0xe7dea3cb

0000000080040070 <d_3_5>:
    80040070:	e7de                	sd	s7,456(sp)
    80040072:	fbd1                	bnez	a5,80040006 <_random_data3+0x6>
    80040074:	4bd0                	lw	a2,20(a5)
    80040076:	a4f0                	fsd	fa2,200(s1)
    80040078:	e24d34ef          	jal	s1,8001369c <_end_data0+0x349c>
    8004007c:	0d11                	addi	s10,s10,4
    8004007e:	fb36                	sd	a3,432(sp)

0000000080040080 <d_3_6>:
    80040080:	1c8c1afb          	.insn	4, 0x1c8c1afb
    80040084:	206d                	.insn	2, 0x206d
    80040086:	20ae                	fld	ft1,200(sp)
    80040088:	f02a                	sd	a0,32(sp)
    8004008a:	62be                	ld	t0,456(sp)
    8004008c:	ca1d                	beqz	a2,800400c2 <d_3_10+0x2>
    8004008e:	7c92                	ld	s9,288(sp)

0000000080040090 <d_3_7>:
    80040090:	7672                	ld	a2,312(sp)
    80040092:	d665                	beqz	a2,8004007a <d_3_5+0xa>
    80040094:	d9f4                	sw	a3,116(a1)
    80040096:	a35d                	j	8004063c <_end_data3+0x43c>
    80040098:	82dd                	srli	a3,a3,0x17
    8004009a:	fe09ceeb          	.insn	4, 0xfe09ceeb
    8004009e:	1cf0                	addi	a2,sp,636

00000000800400a0 <d_3_8>:
    800400a0:	e561                	bnez	a0,80040168 <d_3_20+0x8>
    800400a2:	e362                	sd	s8,384(sp)
    800400a4:	141c                	addi	a5,sp,544
    800400a6:	b104975b          	.insn	4, 0xb104975b
    800400aa:	bf2e                	fsd	fa1,440(sp)
    800400ac:	718c                	ld	a1,32(a1)
    800400ae:	d2b1                	beqz	a3,8003fff2 <_end_data2+0xfdf2>

00000000800400b0 <d_3_9>:
    800400b0:	54c0                	lw	s0,44(s1)
    800400b2:	4790                	lw	a2,8(a5)
    800400b4:	422e4237          	lui	tp,0x422e4
    800400b8:	2fa8                	fld	fa0,88(a5)
    800400ba:	b515                	j	8003fede <_end_data2+0xfcde>
    800400bc:	ce259c87          	.insn	4, 0xce259c87

00000000800400c0 <d_3_10>:
    800400c0:	f0be55af          	.insn	4, 0xf0be55af
    800400c4:	27aa                	fld	fa5,136(sp)
    800400c6:	1f41                	addi	t5,t5,-16 # f276801a <_end+0x72707e1a>
    800400c8:	18bc                	addi	a5,sp,120
    800400ca:	d2cd                	beqz	a3,8004006c <d_3_4+0xc>
    800400cc:	fdf8                	sd	a4,248(a1)
    800400ce:	22c6                	fld	ft5,80(sp)

00000000800400d0 <d_3_11>:
    800400d0:	6775                	lui	a4,0x1d
    800400d2:	86cc                	.insn	2, 0x86cc
    800400d4:	ab8e                	fsd	ft3,464(sp)
    800400d6:	a36c                	fsd	fa1,192(a4)
    800400d8:	a27c12c7          	fmsub.d	ft5,fs8,ft7,fs4,rtz
    800400dc:	fddc6507          	.insn	4, 0xfddc6507

00000000800400e0 <d_3_12>:
    800400e0:	d5b8                	sw	a4,104(a1)
    800400e2:	d508                	sw	a0,40(a0)
    800400e4:	960a                	add	a2,a2,sp
    800400e6:	62fd                	lui	t0,0x1f
    800400e8:	06b6                	slli	a3,a3,0xd
    800400ea:	e032                	sd	a2,0(sp)
    800400ec:	5516                	lw	a0,100(sp)
    800400ee:	b5f1                	j	8003ffba <_end_data2+0xfdba>

00000000800400f0 <d_3_13>:
    800400f0:	3101                	addiw	sp,sp,-32
    800400f2:	2c34                	fld	fa3,88(s0)
    800400f4:	e91a                	sd	t1,144(sp)
    800400f6:	243d                	addiw	s0,s0,15
    800400f8:	66a2                	ld	a3,8(sp)
    800400fa:	fc15                	bnez	s0,80040036 <d_3_1+0x6>
    800400fc:	c659                	beqz	a2,8004018a <d_3_22+0xa>
    800400fe:	  	.insn	8, 0x2729041385418e3f

0000000080040100 <d_3_14>:
    80040100:	8541                	srai	a0,a0,0x10
    80040102:	27290413          	addi	s0,s2,626
    80040106:	2d89                	addiw	s11,s11,2 # 8002 <_start-0x7fff7ffe>
    80040108:	f10b5c0b          	.insn	4, 0xf10b5c0b
    8004010c:	0c20                	addi	s0,sp,536
    8004010e:	c9f6                	sw	t4,208(sp)

0000000080040110 <d_3_15>:
    80040110:	e8f5                	bnez	s1,80040204 <_end_data3+0x4>
    80040112:	3dbab403          	ld	s0,987(s5)
    80040116:	7c9e                	ld	s9,480(sp)
    80040118:	1488                	addi	a0,sp,608
    8004011a:	b73a                	fsd	fa4,424(sp)
    8004011c:	38fa                	fld	fa7,440(sp)
    8004011e:	41d9                	li	gp,22

0000000080040120 <d_3_16>:
    80040120:	cd1c                	sw	a5,24(a0)
    80040122:	fc65411b          	.insn	4, 0xfc65411b
    80040126:	de82                	sw	zero,124(sp)
    80040128:	7382                	ld	t2,32(sp)
    8004012a:	b8887eeb          	.insn	4, 0xb8887eeb
    8004012e:	48ea                	lw	a7,152(sp)

0000000080040130 <d_3_17>:
    80040130:	aeb6                	fsd	fa3,344(sp)
    80040132:	d1b5                	beqz	a1,80040096 <d_3_7+0x6>
    80040134:	f6ded64b          	.insn	4, 0xf6ded64b
    80040138:	2054                	fld	fa3,128(s0)
    8004013a:	84ee                	mv	s1,s11
    8004013c:	055a9997          	auipc	s3,0x55a9

0000000080040140 <d_3_18>:
    80040140:	df44                	sw	s1,60(a4)
    80040142:	49fc                	lw	a5,84(a1)
    80040144:	f3a9                	bnez	a5,80040086 <d_3_6+0x6>
    80040146:	c5f4                	sw	a3,76(a1)
    80040148:	5898                	lw	a4,48(s1)
    8004014a:	101f 6268 d775      	.insn	6, 0xd7756268101f

0000000080040150 <d_3_19>:
    80040150:	ad89                	j	800407a2 <_end_data3+0x5a2>
    80040152:	a2e557f3          	csrrwi	a5,0xa2e,10
    80040156:	191f 4490 1000      	.insn	6, 0x10004490191f
    8004015c:	08f3e123          	.insn	4, 0x08f3e123

0000000080040160 <d_3_20>:
    80040160:	595e                	lw	s2,244(sp)
    80040162:	cb21                	beqz	a4,800401b2 <d_3_25+0x2>
    80040164:	3bfb0747          	fmsub.d	fa4,fs6,ft11,ft7,rne
    80040168:	0440                	addi	s0,sp,516
    8004016a:	7742                	ld	a4,48(sp)
    8004016c:	2fd1d14b          	.insn	4, 0x2fd1d14b

0000000080040170 <d_3_21>:
    80040170:	3ad8                	fld	fa4,176(a3)
    80040172:	55d4                	lw	a3,44(a1)
    80040174:	51f4                	lw	a3,100(a1)
    80040176:	7688                	ld	a0,40(a3)
    80040178:	47799b93          	.insn	4, 0x47799b93
    8004017c:	a3e5                	j	80040764 <_end_data3+0x564>
    8004017e:	194a                	slli	s2,s2,0x32

0000000080040180 <d_3_22>:
    80040180:	64df b133 b619      	.insn	6, 0xb619b13364df
    80040186:	9731a2ab          	.insn	4, 0x9731a2ab
    8004018a:	3e3a                	fld	ft8,424(sp)
    8004018c:	8545                	srai	a0,a0,0x11
    8004018e:	1b9d                	addi	s7,s7,-25

0000000080040190 <d_3_23>:
    80040190:	c601                	beqz	a2,80040198 <d_3_23+0x8>
    80040192:	b712                	fsd	ft4,424(sp)
    80040194:	50c1                	li	ra,-16
    80040196:	1029                	c.nop	-22
    80040198:	60ec                	ld	a1,192(s1)
    8004019a:	c289                	beqz	a3,8004019c <d_3_23+0xc>
    8004019c:	ad32                	fsd	fa2,152(sp)
    8004019e:	730e                	ld	t1,224(sp)

00000000800401a0 <d_3_24>:
    800401a0:	af56                	fsd	fs5,408(sp)
    800401a2:	e9cc                	sd	a1,144(a1)
    800401a4:	f674                	sd	a3,232(a2)
    800401a6:	38634deb          	.insn	4, 0x38634deb
    800401aa:	05d6f3cf          	.insn	4, 0x05d6f3cf
    800401ae:	b359                	j	8003ff34 <_end_data2+0xfd34>

00000000800401b0 <d_3_25>:
    800401b0:	b0a848cb          	fnmsub.s	fa7,fa6,fa0,fs6,rmm
    800401b4:	9c6c812f          	.insn	4, 0x9c6c812f
    800401b8:	aac8                	fsd	fa0,144(a3)
    800401ba:	0dda                	slli	s11,s11,0x16
    800401bc:	3128                	fld	fa0,96(a0)
    800401be:	0d9c                	addi	a5,sp,720

00000000800401c0 <d_3_26>:
    800401c0:	d8a9                	beqz	s1,80040112 <d_3_15+0x2>
    800401c2:	607071bf 8e5192a6 	.insn	8, 0x8e5192a6607071bf
    800401ca:	dc8b99b3          	.insn	4, 0xdc8b99b3
    800401ce:	d09f        	.insn	6, 0x33d351d6d09f

00000000800401d0 <d_3_27>:
    800401d0:	51d6                	lw	gp,116(sp)
    800401d2:	692a33d3          	.insn	4, 0x692a33d3
    800401d6:	b191                	j	8003fe1a <_end_data2+0xfc1a>
    800401d8:	69fe1703          	lh	a4,1695(t3)
    800401dc:	d368                	sw	a0,100(a4)
    800401de:	fe84                	sd	s1,56(a3)
    800401e0:	dd89                	beqz	a1,800400fa <d_3_13+0xa>
    800401e2:	a1de208b          	.insn	4, 0xa1de208b
    800401e6:	d47aaa0b          	.insn	4, 0xd47aaa0b
    800401ea:	72b5                	lui	t0,0xfffed
    800401ec:	da48                	sw	a0,52(a2)
    800401ee:	c572                	sw	t3,136(sp)
    800401f0:	903e                	c.add	zero,a5
    800401f2:	8049b9fb          	.insn	4, 0x8049b9fb
    800401f6:	5108                	lw	a0,32(a0)
    800401f8:	6cee                	ld	s9,216(sp)
    800401fa:	bc094e37          	lui	t3,0xbc094
    800401fe:	dd3b                	.short	0xdd3b

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	2bb4                	fld	fa3,80(a5)
    80050002:	1534                	addi	a3,sp,680
    80050004:	48ba                	lw	a7,140(sp)
    80050006:	7032                	.insn	2, 0x7032
    80050008:	d6e177d3          	.insn	4, 0xd6e177d3
    8005000c:	43f9                	li	t2,30
    8005000e:	480d                	li	a6,3
    80050010:	9255                	srli	a2,a2,0x35
    80050012:	09a2                	slli	s3,s3,0x8
    80050014:	8b04                	.insn	2, 0x8b04
    80050016:	2d95                	addiw	s11,s11,5
    80050018:	a1f2                	fsd	ft8,192(sp)
    8005001a:	a034                	fsd	fa3,64(s0)
    8005001c:	9b90                	.insn	2, 0x9b90
    8005001e:	4824                	lw	s1,80(s0)

0000000080050020 <d_4_0>:
    80050020:	9cc4                	.insn	2, 0x9cc4
    80050022:	e80495bb          	.insn	4, 0xe80495bb
    80050026:	bda9                	j	8004fe80 <_end_data3+0xfc80>
    80050028:	9346                	add	t1,t1,a7
    8005002a:	ea169977          	.insn	4, 0xea169977
    8005002e:	ea7d                	bnez	a2,80050124 <d_4_16+0x4>

0000000080050030 <d_4_1>:
    80050030:	72d8                	ld	a4,160(a3)
    80050032:	adee                	fsd	fs11,216(sp)
    80050034:	0d467b6f          	jal	s6,800b7108 <_end+0x56f08>
    80050038:	ea4e                	sd	s3,272(sp)
    8005003a:	eb42                	sd	a6,400(sp)
    8005003c:	a7dd                	j	80050822 <_end_data4+0x622>
    8005003e:	0db4                	addi	a3,sp,728

0000000080050040 <d_4_2>:
    80050040:	7f65                	lui	t5,0xffff9
    80050042:	8838                	.insn	2, 0x8838
    80050044:	8ddb8b87          	vloxseg5ei8.v	v23,(s7),v29,v0.t
    80050048:	15d5                	addi	a1,a1,-11 # 17ff5 <_start-0x7ffe800b>
    8005004a:	e5299277          	.insn	4, 0xe5299277
    8005004e:	          	fmsub.d	fa0,fa7,ft8,fs0,rmm

0000000080050050 <d_4_3>:
    80050050:	43c8                	lw	a0,4(a5)
    80050052:	0910                	addi	a2,sp,144
    80050054:	ec214da7          	.insn	4, 0xec214da7
    80050058:	de9a                	sw	t1,124(sp)
    8005005a:	8a9e                	mv	s5,t2
    8005005c:	309f12f3          	csrrw	t0,mvip,t5

0000000080050060 <d_4_4>:
    80050060:	9566                	add	a0,a0,s9
    80050062:	2fc9                	addiw	t6,t6,18
    80050064:	976a                	add	a4,a4,s10
    80050066:	c669                	beqz	a2,80050130 <d_4_17>
    80050068:	f4ad                	bnez	s1,8004ffd2 <_end_data3+0xfdd2>
    8005006a:	0548                	addi	a0,sp,644
    8005006c:	62b77def          	jal	s11,800c7e96 <_end+0x67c96>

0000000080050070 <d_4_5>:
    80050070:	e5b6                	sd	a3,200(sp)
    80050072:	27b65faf          	.insn	4, 0x27b65faf
    80050076:	c19c                	sw	a5,0(a1)
    80050078:	6bce                	ld	s7,208(sp)
    8005007a:	ce95987b          	.insn	4, 0xce95987b
    8005007e:	a546                	fsd	fa7,136(sp)

0000000080050080 <d_4_6>:
    80050080:	3d35                	addiw	s10,s10,-19
    80050082:	ec7a                	sd	t5,24(sp)
    80050084:	1e77dc83          	lhu	s9,487(a5)
    80050088:	0ef9                	addi	t4,t4,30 # 3f5b601e <_start-0x40a49fe2>
    8005008a:	379d                	addiw	a5,a5,-25
    8005008c:	83d809e7          	jalr	s3,-1987(a6) # 1e83d <_start-0x7ffe17c3>

0000000080050090 <d_4_7>:
    80050090:	d432                	sw	a2,40(sp)
    80050092:	8e48                	.insn	2, 0x8e48
    80050094:	8589                	srai	a1,a1,0x2
    80050096:	373cb43f a1c73d58 	.insn	8, 0xa1c73d58373cb43f
    8005009e:	          	.insn	4, 0xb20bbcab

00000000800500a0 <d_4_8>:
    800500a0:	7a0ab20b          	.insn	4, 0x7a0ab20b
    800500a4:	4157dccf          	fnmadd.s	fs9,fa5,fs5,fs0,unknown
    800500a8:	3e78                	fld	fa4,248(a2)
    800500aa:	fd7f                	.insn	2, 0xfd7f
    800500ac:	e341                	bnez	a4,8005012c <d_4_16+0xc>
    800500ae:	6daa                	ld	s11,136(sp)

00000000800500b0 <d_4_9>:
    800500b0:	028c                	addi	a1,sp,320
    800500b2:	6560                	ld	s0,200(a0)
    800500b4:	deb471eb          	.insn	4, 0xdeb471eb
    800500b8:	05d0                	addi	a2,sp,708
    800500ba:	5aad                	li	s5,-21
    800500bc:	9a59                	andi	a2,a2,-10
    800500be:	          	.insn	4, 0x0839cf5b

00000000800500c0 <d_4_10>:
    800500c0:	0839                	addi	a6,a6,14
    800500c2:	e3b1                	bnez	a5,80050106 <d_4_14+0x6>
    800500c4:	45ae                	lw	a1,200(sp)
    800500c6:	03e4                	addi	s1,sp,460
    800500c8:	f1319393          	.insn	4, 0xf1319393
    800500cc:	250c9f3b          	.insn	4, 0x250c9f3b

00000000800500d0 <d_4_11>:
    800500d0:	8658                	.insn	2, 0x8658
    800500d2:	4f6bd167          	.insn	4, 0x4f6bd167
    800500d6:	72e0                	ld	s0,224(a3)
    800500d8:	fb79                	bnez	a4,800500ae <d_4_8+0xe>
    800500da:	c741                	beqz	a4,80050162 <d_4_20+0x2>
    800500dc:	f326                	sd	s1,416(sp)
    800500de:	acf2                	fsd	ft8,88(sp)

00000000800500e0 <d_4_12>:
    800500e0:	6b93a633          	.insn	4, 0x6b93a633
    800500e4:	0c19                	addi	s8,s8,6
    800500e6:	df08                	sw	a0,56(a4)
    800500e8:	be0d                	j	8004fc1a <_end_data3+0xfa1a>
    800500ea:	1838                	addi	a4,sp,56
    800500ec:	79b1                	lui	s3,0xfffec
    800500ee:	ec05                	bnez	s0,80050126 <d_4_16+0x6>

00000000800500f0 <d_4_13>:
    800500f0:	dc40                	sw	s0,60(s0)
    800500f2:	f134                	sd	a3,96(a0)
    800500f4:	f379                	bnez	a4,800500ba <d_4_9+0xa>
    800500f6:	abe9                	j	800506d0 <_end_data4+0x4d0>
    800500f8:	04493267          	.insn	4, 0x04493267
    800500fc:	4295                	li	t0,5
    800500fe:	          	auipc	s4,0x90bff

0000000080050100 <d_4_14>:
    80050100:	d48490bf cfc1b7f2 	.insn	8, 0xcfc1b7f2d48490bf
    80050108:	42ca132b          	.insn	4, 0x42ca132b
    8005010c:	edd4                	sd	a3,152(a1)
    8005010e:	fd6a                	sd	s10,184(sp)

0000000080050110 <d_4_15>:
    80050110:	3935                	addiw	s2,s2,-19
    80050112:	fef2                	sd	t3,376(sp)
    80050114:	90a2                	add	ra,ra,s0
    80050116:	d4e5                	beqz	s1,800500fe <d_4_13+0xe>
    80050118:	5bcd                	li	s7,-13
    8005011a:	65b4                	ld	a3,72(a1)
    8005011c:	cad5                	beqz	a3,800501d0 <d_4_27>
    8005011e:	          	.insn	4, 0xde4f79db

0000000080050120 <d_4_16>:
    80050120:	1631de4f          	.insn	4, 0x1631de4f
    80050124:	927d                	srli	a2,a2,0x3f
    80050126:	4f62                	lw	t5,24(sp)
    80050128:	82c4                	.insn	2, 0x82c4
    8005012a:	fee1                	bnez	a3,80050102 <d_4_14+0x2>
    8005012c:	dd19                	beqz	a0,8005004a <d_4_2+0xa>
    8005012e:	          	fmadd.s	fs4,fs7,fs6,ft3,unknown

0000000080050130 <d_4_17>:
    80050130:	96fd196b          	.insn	4, 0x96fd196b
    80050134:	3255                	addiw	tp,tp,-11 # 422e3ff5 <_start-0x3dd1c00b>
    80050136:	7a3c                	ld	a5,112(a2)
    80050138:	33e4                	fld	fs1,224(a5)
    8005013a:	06a0                	addi	s0,sp,840
    8005013c:	92c9                	srli	a3,a3,0x32
    8005013e:	          	.insn	4, 0xabd0950b

0000000080050140 <d_4_18>:
    80050140:	abd0                	fsd	fa2,144(a5)
    80050142:	b7dd                	j	80050128 <d_4_16+0x8>
    80050144:	010e                	slli	sp,sp,0x3
    80050146:	5256                	lw	tp,116(sp)
    80050148:	a238                	fsd	fa4,64(a2)
    8005014a:	af89                	j	8005089c <_end_data4+0x69c>
    8005014c:	672d                	lui	a4,0xb
    8005014e:	276d                	addiw	a4,a4,27 # b01b <_start-0x7fff4fe5>

0000000080050150 <d_4_19>:
    80050150:	7c39                	lui	s8,0xfffee
    80050152:	d79f 226d a23c      	.insn	6, 0xa23c226dd79f
    80050158:	f778                	sd	a4,232(a4)
    8005015a:	6dc0                	ld	s0,152(a1)
    8005015c:	3b5a                	fld	fs6,432(sp)
    8005015e:	4b72                	lw	s6,28(sp)

0000000080050160 <d_4_20>:
    80050160:	d309                	beqz	a4,80050062 <d_4_4+0x2>
    80050162:	b91d100f          	.insn	4, 0xb91d100f
    80050166:	b465                	j	8004fc0e <_end_data3+0xfa0e>
    80050168:	6849                	lui	a6,0x12
    8005016a:	e8d4                	sd	a3,144(s1)
    8005016c:	406653bf  	.insn	8, 0x10454633406653bf

0000000080050170 <d_4_21>:
    80050170:	10454633          	.insn	4, 0x10454633
    80050174:	0c16                	slli	s8,s8,0x5
    80050176:	68e9                	lui	a7,0x1a
    80050178:	2505                	addiw	a0,a0,1
    8005017a:	3e68221b          	.insn	4, 0x3e68221b
    8005017e:	6c44                	ld	s1,152(s0)

0000000080050180 <d_4_22>:
    80050180:	002aa64f          	fnmadd.s	fa2,fs5,ft2,ft0,rdn
    80050184:	7c10f0d7          	vsetvli	ra,ra,1985
    80050188:	1348                	addi	a0,sp,420
    8005018a:	6be4                	ld	s1,208(a5)
    8005018c:	e1f1533b          	.insn	4, 0xe1f1533b

0000000080050190 <d_4_23>:
    80050190:	dc71c20f          	.insn	4, 0xdc71c20f
    80050194:	de65                	beqz	a2,8005018c <d_4_22+0xc>
    80050196:	1623c773          	.insn	4, 0x1623c773
    8005019a:	ca99                	beqz	a3,800501b0 <d_4_25>
    8005019c:	4b4e                	lw	s6,208(sp)
    8005019e:	7811                	lui	a6,0xfffe4

00000000800501a0 <d_4_24>:
    800501a0:	a7ca                	fsd	fs2,456(sp)
    800501a2:	bed2                	fsd	fs4,376(sp)
    800501a4:	ea5e                	sd	s7,272(sp)
    800501a6:	f178                	sd	a4,224(a0)
    800501a8:	99a8                	.insn	2, 0x99a8
    800501aa:	eb81                	bnez	a5,800501ba <d_4_25+0xa>
    800501ac:	c796                	sw	t0,204(sp)
    800501ae:	8c0a                	mv	s8,sp

00000000800501b0 <d_4_25>:
    800501b0:	0cb67eeb          	.insn	4, 0x0cb67eeb
    800501b4:	6860                	ld	s0,208(s0)
    800501b6:	e280                	sd	s0,0(a3)
    800501b8:	8b1b2d67          	.insn	4, 0x8b1b2d67
    800501bc:	8bc5                	andi	a5,a5,17
    800501be:	fe11                	bnez	a2,800500da <d_4_11+0xa>

00000000800501c0 <d_4_26>:
    800501c0:	4791                	li	a5,4
    800501c2:	9b05                	andi	a4,a4,-31
    800501c4:	2857971b          	.insn	4, 0x2857971b
    800501c8:	5790                	lw	a2,40(a5)
    800501ca:	f73e                	sd	a5,424(sp)
    800501cc:	934c                	.insn	2, 0x934c
    800501ce:	780a                	ld	a6,160(sp)

00000000800501d0 <d_4_27>:
    800501d0:	4eb944cb          	.insn	4, 0x4eb944cb
    800501d4:	da85                	beqz	a3,80050104 <d_4_14+0x4>
    800501d6:	7dd2                	ld	s11,304(sp)
    800501d8:	e5ad                	bnez	a1,80050242 <_end_data4+0x42>
    800501da:	21a8                	fld	fa0,64(a1)
    800501dc:	bed8                	fsd	fa4,184(a3)
    800501de:	7e64                	ld	s1,248(a2)
    800501e0:	dfde                	sw	s7,252(sp)
    800501e2:	f254fa27          	.insn	4, 0xf254fa27
    800501e6:	c791                	beqz	a5,800501f2 <d_4_27+0x22>
    800501e8:	6f34                	ld	a3,88(a4)
    800501ea:	c469                	beqz	s0,800502b4 <_end_data4+0xb4>
    800501ec:	aecd                	j	800505de <_end_data4+0x3de>
    800501ee:	3842                	fld	fa6,48(sp)
    800501f0:	0742                	slli	a4,a4,0x10
    800501f2:	d6ca                	sw	s2,108(sp)
    800501f4:	48bab023          	sd	a1,1152(s5)
    800501f8:	b000                	fsd	fs0,32(s0)
    800501fa:	4986                	lw	s3,64(sp)
    800501fc:	9f10                	.insn	2, 0x9f10
    800501fe:	4f55                	li	t5,21

Disassembly of section .data.random5:

0000000080060000 <_random_data5>:
    80060000:	d690                	sw	a2,40(a3)
    80060002:	527c08c3          	fmadd.d	fa7,fs8,ft7,fa0,rne
    80060006:	00312a43          	fmadd.s	fs4,ft2,ft3,ft0,rdn
    8006000a:	52b2                	lw	t0,44(sp)
    8006000c:	0386                	slli	t2,t2,0x1
    8006000e:	d274                	sw	a3,100(a2)
    80060010:	d081                	beqz	s1,8005ff10 <_end_data4+0xfd10>
    80060012:	f9f4                	sd	a3,240(a1)
    80060014:	0002abe3          	.insn	4, 0x0002abe3
    80060018:	b59a1dfb          	.insn	4, 0xb59a1dfb
    8006001c:	cf25                	beqz	a4,80060094 <d_5_7+0x4>
    8006001e:	f7c8                	sd	a0,168(a5)

0000000080060020 <d_5_0>:
    80060020:	c7f1b0bb          	.insn	4, 0xc7f1b0bb
    80060024:	5360                	lw	s0,100(a4)
    80060026:	a3d4                	fsd	fa3,128(a5)
    80060028:	6505                	lui	a0,0x1
    8006002a:	9759ceef          	jal	t4,7fffc99e <_start-0x3662>
    8006002e:	2cb4                	fld	fa3,88(s1)

0000000080060030 <d_5_1>:
    80060030:	186e0a47          	fmsub.s	fs4,ft8,ft6,ft3,rne
    80060034:	15abb473          	csrrc	s0,0x15a,s7
    80060038:	d710                	sw	a2,40(a4)
    8006003a:	bddd                	j	8005ff30 <_end_data4+0xfd30>
    8006003c:	44272d0b          	.insn	4, 0x44272d0b

0000000080060040 <d_5_2>:
    80060040:	93ac                	.insn	2, 0x93ac
    80060042:	8ecf228f          	.insn	4, 0x8ecf228f
    80060046:	0f12                	slli	t5,t5,0x4
    80060048:	590a                	lw	s2,160(sp)
    8006004a:	f38c                	sd	a1,32(a5)
    8006004c:	5634                	lw	a3,104(a2)
    8006004e:	          	fnmsub.s	fs9,fa3,ft9,ft1

0000000080060050 <d_5_3>:
    80060050:	09d6                	slli	s3,s3,0x15
    80060052:	4e4e                	lw	t3,208(sp)
    80060054:	9b40                	.insn	2, 0x9b40
    80060056:	cf9d                	beqz	a5,80060094 <d_5_7+0x4>
    80060058:	73d9                	lui	t2,0xffff6
    8006005a:	78f8                	ld	a4,240(s1)
    8006005c:	a861                	j	800600f4 <d_5_13+0x4>
    8006005e:	1a00                	addi	s0,sp,304

0000000080060060 <d_5_4>:
    80060060:	4dbb7c93          	andi	s9,s6,1243
    80060064:	0e3819a7          	.insn	4, 0x0e3819a7
    80060068:	368c                	fld	fa1,40(a3)
    8006006a:	170da32b          	.insn	4, 0x170da32b
    8006006e:	          	.insn	4, 0x3d54961b

0000000080060070 <d_5_5>:
    80060070:	3d54                	fld	fa3,184(a0)
    80060072:	569a                	lw	a3,164(sp)
    80060074:	9354                	.insn	2, 0x9354
    80060076:	3211                	addiw	tp,tp,-28 # ffffffffffffffe4 <_end+0xffffffff7ff9fde4>
    80060078:	42672f27          	fsw	ft6,1086(a4)
    8006007c:	ca5a741b          	.insn	4, 0xca5a741b

0000000080060080 <d_5_6>:
    80060080:	a3a6                	fsd	fs1,448(sp)
    80060082:	cc334b3b          	.insn	4, 0xcc334b3b
    80060086:	b99c                	fsd	fa5,48(a1)
    80060088:	77bc                	ld	a5,104(a5)
    8006008a:	1f7a                	slli	t5,t5,0x3e
    8006008c:	ef3d                	bnez	a4,8006010a <d_5_14+0xa>
    8006008e:	52dc                	lw	a5,36(a3)

0000000080060090 <d_5_7>:
    80060090:	fd12                	sd	tp,184(sp)
    80060092:	cfc2                	sw	a6,220(sp)
    80060094:	969a                	add	a3,a3,t1
    80060096:	c520                	sw	s0,72(a0)
    80060098:	4d0d                	li	s10,3
    8006009a:	b32e                	fsd	fa1,416(sp)
    8006009c:	c95a                	sw	s6,144(sp)
    8006009e:	77f8                	ld	a4,232(a5)

00000000800600a0 <d_5_8>:
    800600a0:	fa46                	sd	a7,304(sp)
    800600a2:	b351                	j	8005fe26 <_end_data4+0xfc26>
    800600a4:	e79a                	sd	t1,456(sp)
    800600a6:	4ad8                	lw	a4,20(a3)
    800600a8:	1c7d                	addi	s8,s8,-1 # fffffffffffedfff <_end+0xffffffff7ff8ddff>
    800600aa:	181c                	addi	a5,sp,48
    800600ac:	dabc                	sw	a5,112(a3)
    800600ae:	977e                	add	a4,a4,t6

00000000800600b0 <d_5_9>:
    800600b0:	0b40                	addi	s0,sp,404
    800600b2:	1526e6bf 44173557 	.insn	8, 0x441735571526e6bf
    800600ba:	c5d8                	sw	a4,12(a1)
    800600bc:	27bc                	fld	fa5,72(a5)
    800600be:	943e                	add	s0,s0,a5

00000000800600c0 <d_5_10>:
    800600c0:	7900                	ld	s0,48(a0)
    800600c2:	90d971b7          	lui	gp,0x90d97
    800600c6:	d721                	beqz	a4,8006000e <_random_data5+0xe>
    800600c8:	0977869b          	addiw	a3,a5,151
    800600cc:	abdc                	fsd	fa5,144(a5)
    800600ce:	2732                	fld	fa4,264(sp)

00000000800600d0 <d_5_11>:
    800600d0:	2c48                	fld	fa0,152(s0)
    800600d2:	e5bd                	bnez	a1,80060140 <d_5_18>
    800600d4:	d800                	sw	s0,48(s0)
    800600d6:	4eb8                	lw	a4,88(a3)
    800600d8:	bde9                	j	8005ffb2 <_end_data4+0xfdb2>
    800600da:	c99e                	sw	t2,208(sp)
    800600dc:	3048                	fld	fa0,160(s0)
    800600de:	c631                	beqz	a2,8006012a <d_5_16+0xa>

00000000800600e0 <d_5_12>:
    800600e0:	0ae2                	slli	s5,s5,0x18
    800600e2:	7f02                	ld	t5,32(sp)
    800600e4:	3294                	fld	fa3,32(a3)
    800600e6:	c12d                	beqz	a0,80060148 <d_5_18+0x8>
    800600e8:	75d9                	lui	a1,0xffff6
    800600ea:	4ce0a4bb          	.insn	4, 0x4ce0a4bb
    800600ee:	          	.insn	4, 0xe1fc6487

00000000800600f0 <d_5_13>:
    800600f0:	e1fc                	sd	a5,192(a1)
    800600f2:	37c8                	fld	fa0,168(a5)
    800600f4:	eb86                	sd	ra,464(sp)
    800600f6:	1944                	addi	s1,sp,180
    800600f8:	6f64                	ld	s1,216(a4)
    800600fa:	2c95                	addiw	s9,s9,5 # 4005 <_start-0x7fffbffb>
    800600fc:	e808                	sd	a0,16(s0)
    800600fe:	4442                	lw	s0,16(sp)

0000000080060100 <d_5_14>:
    80060100:	1d6d                	addi	s10,s10,-5
    80060102:	44a4                	lw	s1,72(s1)
    80060104:	bc21                	j	8005fb1c <_end_data4+0xf91c>
    80060106:	e2e2                	sd	s8,320(sp)
    80060108:	7e947a1b          	.insn	4, 0x7e947a1b
    8006010c:	2b2c                	fld	fa1,80(a4)
    8006010e:	cdc8                	sw	a0,28(a1)

0000000080060110 <d_5_15>:
    80060110:	8d9f 6ee5 f489      	.insn	6, 0xf4896ee58d9f
    80060116:	72f1c57b          	.insn	4, 0x72f1c57b
    8006011a:	f1f2                	sd	t3,224(sp)
    8006011c:	283c                	fld	fa5,80(s0)
    8006011e:	          	.insn	4, 0x14191477

0000000080060120 <d_5_16>:
    80060120:	1419                	addi	s0,s0,-26
    80060122:	fabd                	bnez	a3,80060098 <d_5_7+0x8>
    80060124:	70b4                	ld	a3,96(s1)
    80060126:	4f993647          	.insn	4, 0x4f993647
    8006012a:	9624                	.insn	2, 0x9624
    8006012c:	aaf8                	fsd	fa4,208(a3)
    8006012e:	3368                	fld	fa0,224(a4)

0000000080060130 <d_5_17>:
    80060130:	90a5                	srli	s1,s1,0x29
    80060132:	08fa                	slli	a7,a7,0x1e
    80060134:	ac86                	fsd	ft1,88(sp)
    80060136:	f40e                	sd	gp,40(sp)
    80060138:	d8b5                	beqz	s1,800600ac <d_5_8+0xc>
    8006013a:	6e9a                	ld	t4,384(sp)
    8006013c:	3ee6                	fld	ft9,120(sp)
    8006013e:	          	.insn	4, 0xd5222843

0000000080060140 <d_5_18>:
    80060140:	d522                	sw	s0,168(sp)
    80060142:	6e2c                	ld	a1,88(a2)
    80060144:	f12ea173          	csrrs	sp,marchid,t4
    80060148:	cdaa                	sw	a0,216(sp)
    8006014a:	5d01                	li	s10,-32
    8006014c:	52c18253          	.insn	4, 0x52c18253

0000000080060150 <d_5_19>:
    80060150:	dfbd                	beqz	a5,800600ce <d_5_10+0xe>
    80060152:	6592                	ld	a1,256(sp)
    80060154:	e312926b          	.insn	4, 0xe312926b
    80060158:	7222                	ld	tp,40(sp)
    8006015a:	4af6                	lw	s5,92(sp)
    8006015c:	da1d                	beqz	a2,80060092 <d_5_7+0x2>
    8006015e:	          	.insn	4, 0x5222282f

0000000080060160 <d_5_20>:
    80060160:	5222                	lw	tp,40(sp)
    80060162:	da4a                	sw	s2,52(sp)
    80060164:	6725                	lui	a4,0x9
    80060166:	d324                	sw	s1,96(a4)
    80060168:	592c                	lw	a1,112(a0)
    8006016a:	9355                	srli	a4,a4,0x35
    8006016c:	5cf8                	lw	a4,124(s1)
    8006016e:	          	fmadd.s	fa4,ft11,fa3,ft7,unknown

0000000080060170 <d_5_21>:
    80060170:	38df aa59 5e92      	.insn	6, 0x5e92aa5938df
    80060176:	91bc                	.insn	2, 0x91bc
    80060178:	fa06                	sd	ra,304(sp)
    8006017a:	7c92e9fb          	.insn	4, 0x7c92e9fb
    8006017e:	1dd8                	addi	a4,sp,756

0000000080060180 <d_5_22>:
    80060180:	1ac65227          	.insn	4, 0x1ac65227
    80060184:	c2b75fd7          	vfwadd.vf	v31,v11,fa4
    80060188:	ae3a554f          	.insn	4, 0xae3a554f
    8006018c:	d26b5ecf          	fnmadd.d	ft9,fs6,ft6,fs10,unknown

0000000080060190 <d_5_23>:
    80060190:	b16e                	fsd	fs11,160(sp)
    80060192:	c8ea                	sw	s10,80(sp)
    80060194:	b80e                	fsd	ft3,48(sp)
    80060196:	8dd4                	.insn	2, 0x8dd4
    80060198:	5b25                	li	s6,-23
    8006019a:	14b9                	addi	s1,s1,-18
    8006019c:	c299                	beqz	a3,800601a2 <d_5_24+0x2>
    8006019e:	4eb2                	lw	t4,12(sp)

00000000800601a0 <d_5_24>:
    800601a0:	9fc6                	add	t6,t6,a7
    800601a2:	9c2d                	addw	s0,s0,a1
    800601a4:	0475                	addi	s0,s0,29
    800601a6:	ab00                	fsd	fs0,16(a4)
    800601a8:	9fae                	add	t6,t6,a1
    800601aa:	61d17aa7          	.insn	4, 0x61d17aa7
    800601ae:	0169                	addi	sp,sp,26

00000000800601b0 <d_5_25>:
    800601b0:	3ec9                	addiw	t4,t4,-14
    800601b2:	91d0efd3          	.insn	4, 0x91d0efd3
    800601b6:	cffa                	sw	t5,220(sp)
    800601b8:	5f90                	lw	a2,56(a5)
    800601ba:	2a06                	fld	fs4,64(sp)
    800601bc:	9fb4957b          	.insn	4, 0x9fb4957b

00000000800601c0 <d_5_26>:
    800601c0:	921c                	.insn	2, 0x921c
    800601c2:	20be                	fld	ft1,456(sp)
    800601c4:	7dff                	.insn	2, 0x7dff
    800601c6:	8e6c                	.insn	2, 0x8e6c
    800601c8:	acb4                	fsd	fa3,88(s1)
    800601ca:	5b8e                	lw	s7,224(sp)
    800601cc:	5027d437          	lui	s0,0x5027d

00000000800601d0 <d_5_27>:
    800601d0:	17bf9bef          	jal	s7,80159b4a <_end+0xf994a>
    800601d4:	0a1955c3          	fmadd.d	fa1,fs2,ft1,ft1,unknown
    800601d8:	369f ed3e bd50      	.insn	6, 0xbd50ed3e369f
    800601de:	2725                	addiw	a4,a4,9 # 9009 <_start-0x7fff6ff7>
    800601e0:	6eae                	ld	t4,200(sp)
    800601e2:	bde2                	fsd	fs8,248(sp)
    800601e4:	fa19abe3          	.insn	4, 0xfa19abe3
    800601e8:	583a                	lw	a6,172(sp)
    800601ea:	87f1                	srai	a5,a5,0x1c
    800601ec:	6d12                	ld	s10,256(sp)
    800601ee:	69346ff3          	csrrsi	t6,0x693,8
    800601f2:	e6b4                	sd	a3,72(a3)
    800601f4:	890c                	.insn	2, 0x890c
    800601f6:	6960                	ld	s0,208(a0)
    800601f8:	a1d4                	fsd	fa3,128(a1)
    800601fa:	49fe                	lw	s3,220(sp)
    800601fc:	e7a9                	bnez	a5,80060246 <_end+0x46>
    800601fe:	5907                	.short	0x5907

Disassembly of section .riscv.attributes:

0000000000000000 <.riscv.attributes>:
   0:	ee41                	bnez	a2,98 <_start-0x7fffff68>
   2:	0000                	unimp
   4:	7200                	ld	s0,32(a2)
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <_start-0x7fffffec>
   c:	00e4                	addi	s1,sp,76
   e:	0000                	unimp
  10:	7205                	lui	tp,0xfffe1
  12:	3676                	fld	fa2,376(sp)
  14:	6934                	ld	a3,80(a0)
  16:	7032                	.insn	2, 0x7032
  18:	5f31                	li	t5,-20
  1a:	326d                	addiw	tp,tp,-5 # fffffffffffe0ffb <_end+0xffffffff7ff80dfb>
  1c:	3070                	fld	fa2,224(s0)
  1e:	615f 7032 5f31      	.insn	6, 0x5f317032615f
  24:	3266                	fld	ft4,120(sp)
  26:	3270                	fld	fa2,224(a2)
  28:	645f 7032 5f32      	.insn	6, 0x5f327032645f
  2e:	30703263          	.insn	4, 0x30703263
  32:	765f 7031 5f30      	.insn	6, 0x5f307031765f
  38:	3168                	fld	fa0,224(a0)
  3a:	3070                	fld	fa2,224(s0)
  3c:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  42:	316d                	addiw	sp,sp,-5
  44:	3070                	fld	fa2,224(s0)
  46:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  4c:	3170                	fld	fa2,224(a0)
  4e:	3070                	fld	fa2,224(s0)
  50:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  56:	317a                	fld	ft2,440(sp)
  58:	3070                	fld	fa2,224(s0)
  5a:	7a5f 6369 7273      	.insn	6, 0x727363697a5f
  60:	7032                	.insn	2, 0x7032
  62:	5f30                	lw	a2,120(a4)
  64:	697a                	ld	s2,408(sp)
  66:	6566                	ld	a0,88(sp)
  68:	636e                	ld	t1,216(sp)
  6a:	6965                	lui	s2,0x19
  6c:	7032                	.insn	2, 0x7032
  6e:	5f30                	lw	a2,120(a4)
  70:	6d7a                	ld	s10,408(sp)
  72:	756d                	lui	a0,0xffffb
  74:	316c                	fld	fa1,224(a0)
  76:	3070                	fld	fa2,224(s0)
  78:	7a5f 6161 6f6d      	.insn	6, 0x6f6d61617a5f
  7e:	7031                	c.lui	zero,0xfffec
  80:	5f30                	lw	a2,120(a4)
  82:	617a                	ld	sp,408(sp)
  84:	726c                	ld	a1,224(a2)
  86:	70316373          	csrrsi	t1,0x703,2
  8a:	5f30                	lw	a2,120(a4)
  8c:	637a                	ld	t1,408(sp)
  8e:	3161                	addiw	sp,sp,-8
  90:	3070                	fld	fa2,224(s0)
  92:	7a5f 6463 7031      	.insn	6, 0x703164637a5f
  98:	5f30                	lw	a2,120(a4)
  9a:	767a                	ld	a2,440(sp)
  9c:	3365                	addiw	t1,t1,-7 # ffffffffffff9ff9 <_end+0xffffffff7ff99df9>
  9e:	6632                	ld	a2,264(sp)
  a0:	7031                	c.lui	zero,0xfffec
  a2:	5f30                	lw	a2,120(a4)
  a4:	767a                	ld	a2,440(sp)
  a6:	3365                	addiw	t1,t1,-7
  a8:	7832                	ld	a6,296(sp)
  aa:	7031                	c.lui	zero,0xfffec
  ac:	5f30                	lw	a2,120(a4)
  ae:	767a                	ld	a2,440(sp)
  b0:	3665                	addiw	a2,a2,-7 # fffffffffffebff9 <_end+0xffffffff7ff8bdf9>
  b2:	6434                	ld	a3,72(s0)
  b4:	7031                	c.lui	zero,0xfffec
  b6:	5f30                	lw	a2,120(a4)
  b8:	767a                	ld	a2,440(sp)
  ba:	3665                	addiw	a2,a2,-7
  bc:	6634                	ld	a3,72(a2)
  be:	7031                	c.lui	zero,0xfffec
  c0:	5f30                	lw	a2,120(a4)
  c2:	767a                	ld	a2,440(sp)
  c4:	3665                	addiw	a2,a2,-7
  c6:	7834                	ld	a3,112(s0)
  c8:	7031                	c.lui	zero,0xfffec
  ca:	5f30                	lw	a2,120(a4)
  cc:	767a                	ld	a2,440(sp)
  ce:	316c                	fld	fa1,224(a0)
  d0:	3832                	fld	fa6,296(sp)
  d2:	3162                	fld	ft2,56(sp)
  d4:	3070                	fld	fa2,224(s0)
  d6:	7a5f 6c76 3233      	.insn	6, 0x32336c767a5f
  dc:	3162                	fld	ft2,56(sp)
  de:	3070                	fld	fa2,224(s0)
  e0:	7a5f 6c76 3436      	.insn	6, 0x34366c767a5f
  e6:	3162                	fld	ft2,56(sp)
  e8:	3070                	fld	fa2,224(s0)
  ea:	0800                	addi	s0,sp,16
  ec:	0a01                	addi	s4,s4,0 # 10c4f0fe <_start-0x6f3b0f02>
  ee:	0b                	.byte	0x0b
