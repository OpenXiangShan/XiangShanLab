#include <klib.h>

/* Trap state (set by entry.S) */
volatile unsigned long trap_mcause;
volatile unsigned long trap_mepc;
volatile int           trap_taken;

extern void trap_entry(void);

__attribute__((aligned(4096))) static unsigned long root_pt[512];
__attribute__((aligned(4096))) static unsigned long l1_pt[512];
__attribute__((aligned(4096))) static unsigned long l0_pt[512];

#define PTE_V   (1UL << 0)
#define PTE_R   (1UL << 1)
#define PTE_W   (1UL << 2)
#define PTE_X   (1UL << 3)
#define PTE_U   (1UL << 4)
#define PTE_A   (1UL << 6)
#define PTE_D   (1UL << 7)

#define NONLEAF_PTE(pa)     ((((unsigned long)(pa) >> 12) << 10) | PTE_V)
#define LEAF_PTE(ppn, fl)   (((unsigned long)(ppn) << 10) | (fl))

#define SATP_SV39(pa)       ((8UL << 60) | ((unsigned long)(pa) >> 12))

#define MBMC_CSR          0xBC2
#define BITMAP_BASE       0x82000000UL
#define BITMAP_WORD_ADDR  0x82010080UL
#define BITMAP_WORD_VAL   0x20UL          /* bit 5 -> PPN 0x80405 forbidden */
#define ALLOWED_VA        0xC0000UL      /* VPN 192 -> PPN 0x80400 */
#define FORBIDDEN_VA      0xC5000UL      /* VPN 197 -> PPN 0x80405 */

static void setup_page_tables(void)
{
    int i;
    volatile unsigned long *vroot = root_pt;
    volatile unsigned long *vl1   = l1_pt;
    volatile unsigned long *vl0   = l0_pt;

    for (i = 0; i < 512; i++) { vroot[i] = 0; vl1[i] = 0; vl0[i] = 0; }

    vroot[0] = NONLEAF_PTE((unsigned long)l1_pt);
    vl1[0]   = NONLEAF_PTE((unsigned long)l0_pt);
    vl0[0]   = LEAF_PTE(0x80300, PTE_V | PTE_R | PTE_W | PTE_A | PTE_D);

    /* 8 contiguous pages: VPN 192-199 -> PPN 0x80400-0x80407 (one sector) */
    for (i = 0; i < 8; i++)
        vl0[192 + i] = LEAF_PTE(0x80400 + i, PTE_V | PTE_R | PTE_W | PTE_A | PTE_D);

    printf("[*] Page tables: VPN 192-199 -> PPN 0x80400-0x80407\n");
    printf("    L0[192]=0x%lx (allowed)  L0[197]=0x%lx (FORBIDDEN)\n",
           l0_pt[192], l0_pt[197]);
}

static void setup_bitmap(void)
{
    *(volatile unsigned long *)BITMAP_WORD_ADDR = BITMAP_WORD_VAL;
    unsigned long mbmc_val = BITMAP_BASE | (1UL << 2);
    asm volatile("csrw %0, %1" : : "i"(MBMC_CSR), "r"(mbmc_val));
    printf("[*] Bitmap: PPN 0x80405 forbidden (bit 5), MBMC=0x%lx\n", mbmc_val);
}

#define MPRV_LOAD(addr) do { \
    asm volatile( \
        "csrr  t3, mstatus\n\t"                    \
        "li    t4, ~(3 << 11)\n\t"                 \
        "and   t3, t3, t4\n\t"                     \
        "li    t4, (1 << 17)|(1 << 11)\n\t"        \
        "or    t3, t3, t4\n\t"                     \
        "csrw  mstatus, t3\n\t"                    \
        "ld    t3, 0(%0)\n\t"                      \
        "li    t4, (1 << 17)\n\t"                  \
        "csrc  mstatus, t4\n\t"                    \
        : : "r"(addr) : "t3", "t4", "memory" \
    ); \
} while(0)

static int test_mprv(void)
{
    int trap_flag;
    unsigned long trap_cause_val;

    unsigned long satp_val = SATP_SV39((unsigned long)root_pt);

    /* Control: direct access to forbidden page (no sector TLB sharing) */
    printf("\n=== Control: bitmap check WITHOUT sector TLB sharing ===\n");
    asm volatile("csrw satp, %0" : : "r"(satp_val));
    asm volatile("sfence.vma" ::: "memory");
    printf("[*] SATP = 0x%lx, TLB flushed\n", satp_val);

    printf("[*] Direct access: VA 0x%lx (VPN 197, PPN 0x80405, FORBIDDEN)...\n", FORBIDDEN_VA);
    trap_taken = 0;
    MPRV_LOAD(FORBIDDEN_VA);
    trap_flag = trap_taken;
    trap_cause_val = trap_mcause;

    if (!trap_flag) {
        printf("[!] CONTROL FAILED: bitmap not working\n");
        return -1;
    }
    printf("[+] Control OK: faulted (mcause=%ld)\n", trap_cause_val);

    /* Experiment: access allowed page first (fills sector TLB), then forbidden */
    printf("\n=== Experiment: bitmap check WITH sector TLB sharing ===\n");
    asm volatile("sfence.vma" ::: "memory");
    printf("[*] TLB flushed again\n");

    printf("[*] Step 1: VA 0x%lx (VPN 192, PPN 0x80400, allowed)...\n", ALLOWED_VA);
    trap_taken = 0;
    MPRV_LOAD(ALLOWED_VA);
    trap_flag = trap_taken;
    trap_cause_val = trap_mcause;

    if (trap_flag) {
        printf("[!] Step 1 FAULTED: mcause=%ld\n", trap_cause_val);
        return -1;
    }
    printf("[+] Step 1 OK: sector TLB filled\n");

    asm volatile("fence rw, rw" ::: "memory");
    for (volatile int i = 0; i < 100; i++) { }

    printf("[*] Step 2: VA 0x%lx (VPN 197, PPN 0x80405, FORBIDDEN)...\n", FORBIDDEN_VA);
    trap_taken = 0;
    MPRV_LOAD(FORBIDDEN_VA);
    trap_flag = trap_taken;
    trap_cause_val = trap_mcause;

    if (!trap_flag) {
        printf("\n[!!!] BUG CONFIRMED: forbidden page accessed without fault!\n");
        printf("    cfs indexed by PPN[5:3] instead of PPN[2:0]\n");
        return 1;
    }

    printf("[+] Step 2 faulted: mcause=%ld\n", trap_cause_val);
    return 0;
}


int main()
{
    printf("=== XiangShan Sector TLB Bitmap Index Bug PoC ===\n\n");

    unsigned long trap_addr = (unsigned long)trap_entry;
    asm volatile("csrw mtvec, %0" : : "r"(trap_addr));
    asm volatile("csrw medeleg, zero" ::: "memory");
    asm volatile("csrw mideleg, zero" ::: "memory");

    asm volatile(
        "li   t0, -1\n\t"
        "csrw pmpaddr0, t0\n\t"
        "li   t0, 0x1F\n\t"
        "csrw pmpcfg0, t0\n\t"
        ::: "t0", "memory"
    );

    setup_page_tables();
    setup_bitmap();

    int result = test_mprv();

    printf("\n=== RESULT: %s ===\n", result == 1 ? "BUG CONFIRMED" : "PASS");

    return result;
}
