.section .text.init
.globl _start
_start:
  la   t0, trap
  csrw mtvec, t0
  li   t0, 0x600
  csrs mstatus, t0
  li   s0, 0xACE1
  li   s1, 100
  li   s7, 7
loop:
  li   a0, 8                 # A: one fixed vsetvli, nothing else
  vsetvli t1, a0, e32, m2, tu, mu
  csrr t3, vl
  bne  t3, t1, bad
  addi s1, s1, -1
  bnez s1, loop
  li   a0, 0
  .word 0x0005006b
bad:
  li   a0, 2
  .word 0x0005006b
trap:
  li   a0, 1
  .word 0x0005006b
