.section .text.init
.globl _start
_start:
  la   t0, trap
  csrw mtvec, t0
  li   t0, 0x600
  csrs mstatus, t0
  li   s0, 0xACE1
  li   s1, 100
  li   s7, 7
loop:
  slli t0, s0, 13            # C: B plus a second vsetvli under a data-dependent branch
  xor  s0, s0, t0
  srli t0, s0, 7
  xor  s0, s0, t0
  slli t0, s0, 17
  xor  s0, s0, t0
  andi a0, s0, 7
  addi a0, a0, 1
  vsetvli t1, a0, e32, m2, tu, mu
  srli t2, s0, 11
  andi t2, t2, 1
  bnez t2, 2f
  vsetvli t1, a0, e16, m1, tu, mu
2:
  vsetvli t1, a0, e32, m2, tu, mu
  csrr t3, vl
  bne  t3, t1, bad
  addi s1, s1, -1
  bnez s1, loop
  li   a0, 0
  .word 0x0005006b
bad:
  li   a0, 2
  .word 0x0005006b
trap:
  li   a0, 1
  .word 0x0005006b
