#include <am.h>
#include <klib.h>

extern void m_trap_entry(void);
extern void vs_mode_test(void);
extern void do_recovery(void);

volatile unsigned long fault_htinst;
volatile unsigned long fault_mcause;

unsigned long recovery_addr = 0;

#define CSR_HGATP    0x680
#define CSR_VSATP    0x280
#define CSR_HSTATUS  0x600
#define CSR_MTVEC    0x305
#define CSR_MSTATUS  0x300
#define CSR_MEPC     0x341
#define CSR_MCAUSE   0x342
#define CSR_PMPCFG0  0x3A0
#define CSR_PMPADDR0 0x3B0

static inline unsigned long csrr(unsigned long addr) {
  unsigned long val;
  asm volatile("csrr %0, %1" : "=r"(val) : "i"(addr));
  return val;
}

static inline void csrw(unsigned long addr, unsigned long val) {
  asm volatile("csrw %0, %1" : : "i"(addr), "r"(val));
}

__attribute__((aligned(16384)))
uint64_t gpt_root[512];

__attribute__((aligned(16384)))
uint64_t vs_root_pt[512];

static void setup_pmp(void) {
  csrw(CSR_PMPADDR0, -1);
  csrw(CSR_PMPCFG0, 0x1f);
}

static void setup_gstage(void) {
  for (int i = 0; i < 512; i++) gpt_root[i] = 0;
  gpt_root[2] = (2ULL << 28) | 0xDF;
  unsigned long pa = (unsigned long)gpt_root;
  csrw(CSR_HGATP, (8UL << 60) | (pa >> 12));
  printf("[*] hgatp = 0x%lx\n", (8UL << 60) | (pa >> 12));
}

static void setup_vsstage(void) {
  for (int i = 0; i < 512; i++) vs_root_pt[i] = 0;
  vs_root_pt[2] = (2ULL << 28) | 0xCF;
  vs_root_pt[0] = 0x01;
  unsigned long pa = (unsigned long)vs_root_pt;
  csrw(CSR_VSATP, (8UL << 60) | (pa >> 12));
  printf("[*] vsatp = 0x%lx\n", (8UL << 60) | (pa >> 12));
}

int main() {
  printf("[*] PoC: tinst store bit 5 missing for G-stage faults\n");

  setup_pmp();
  csrw(CSR_MTVEC, (unsigned long)m_trap_entry);
  setup_gstage();
  setup_vsstage();

  csrw(CSR_HSTATUS, (1UL << 8));
  recovery_addr = (unsigned long)do_recovery;
  fault_htinst = 0;
  fault_mcause = 0;

  printf("[*] Entering VS-mode...\n");
  csrw(CSR_MSTATUS, (1UL << 11) | (1UL << 39));
  csrw(CSR_MEPC, (unsigned long)vs_mode_test);
  asm volatile("mret");
  printf("[*] ERROR: should not reach here\n");
  _halt(3);
  return 0;
}

void __attribute__((noinline)) do_recovery(void) {
  printf("[*] Back in M-mode after exception\n");
  printf("[*] mcause = 0x%lx (NEMU EX_SGPF=0x17)\n", fault_mcause);
  printf("[*] htinst = 0x%lx\n", fault_htinst);

  if (fault_mcause == 23) {
    printf("[*] Store guest-page fault confirmed\n");
  }

  if (fault_htinst & 0x0020) {
    printf("[*] PASS: htinst bit 5 is SET (0x%lx)\n", fault_htinst);
    _halt(0);
  } else {
    printf("[*] BUG CONFIRMED: htinst = 0x%lx, bit 5 CLEAR\n", fault_htinst);
    _halt(1);
  }
}
