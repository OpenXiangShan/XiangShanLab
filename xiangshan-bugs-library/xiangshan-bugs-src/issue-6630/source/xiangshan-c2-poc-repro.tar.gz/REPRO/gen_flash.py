#!/usr/bin/env python3
# flash 镜像: 1MB; [0..11]=boot stub(addiw/slli/jr -> 0x80000000); [0xFFFE,0xFFFF]=FF FF (RVI 半字)
img = bytearray(1024*1024)
img[0:12] = bytes.fromhex("9b0210009392f20167800200")
img[0xFFFE] = 0xFF
img[0xFFFF] = 0xFF
open("flash.bin","wb").write(img)
print("flash.bin: 1MB, stub=%s tail=%s" % (img[0:12].hex(), img[0xFFF8:0x10000].hex()))
