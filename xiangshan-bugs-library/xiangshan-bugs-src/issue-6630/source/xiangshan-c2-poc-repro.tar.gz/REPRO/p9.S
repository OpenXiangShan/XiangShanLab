# probe9: C2 - cross-8B-boundary fetch at flash tail with planted RVI halfword
# boot @0x80000000 (DRAM); jump to 0x1FFFFFE (flash AXI range tail, %8==6)
#   beat1 [0x1FFFFF8..F] -> flash dev OK, halfword@6 = 0xFFFF (RVI) -> internal resend
#   resend [0x20000000..7] -> unmapped -> AXI4Error DECERR -> denied/corrupt
    .option norvc
    .option norelax
    .section .text
    .globl _start
_start:
    la    t0, handler
    csrw  mtvec, t0
    li    t0, 0x1FFFFFE
    jr    t0
handler:
    csrr  s1, mcause
    csrr  s2, mepc
    csrr  s3, mtval
    la    a0, msg
    jal   ra, puts
    mv    a0, s1
    jal   ra, puthex
    mv    a0, s2
    jal   ra, puthex
    mv    a0, s3
    jal   ra, puthex
    li    a1, 10
    jal   ra, pputc
1:  wfi
    j 1b
puts:
    lbu   a1, 0(a0)
    beqz  a1, 1f
    jal   ra, pputc
    addi  a0, a0, 1
    j     puts
1:  ret
pputc:
    li    t2, 0x40600004
    sw    a1, 0(t2)
    ret
puthex:
    li    t1, 60
2:  srl   a1, a0, t1
    andi  a1, a1, 15
    li    t3, 10
    bltu  a1, t3, 3f
    addi  a1, a1, 87
    j     4f
3:  addi  a1, a1, 48
4:  li    t2, 0x40600004
    sw    a1, 0(t2)
    addi  t1, t1, -4
    bgez  t1, 2b
    li    a1, 32
    li    t2, 0x40600004
    sw    a1, 0(t2)
    ret
.section .rodata
msg: .asciz "C2 mcause mepc mtval:\n"
