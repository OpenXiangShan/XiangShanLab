# 复现包: 取指异常向量 multi-hot → ExceptionType/TrapTvalMod 自检断言失败 → ABORT

## 前提(必读)
复现依赖两件事, 缺一不可:
1. **错误使能桥**: top/Top.scala 的 MMIO OpenNCB `writeNoError` 必须为 false
   (stock=true 会把 AXI 读错误在桥内吞掉, 场景不可达)。见 Top_wne.patch。
   这是唯一的源码改动; 缺陷本体在 stock 的取指异常交付路径上。
2. **断言使能的 emu**: difftest 默认构建(--assert)即可。

## 步骤(kunminghu-v3 tip e4566c29e2)
1. 应用补丁: `git apply Top_wne.patch`  (9d4e201 上行号为 133, tip 上为 142)
2. 构建:
   mill -i xiangshan.test.runMain top.XiangShanSim --target-dir build/rtl \
     --config MinimalConfig --issue E.b --num-cores 1 --target systemverilog \
     --split-verilog --dump-fir --enable-difftest \
     --firtool-opt "-O=release --disable-annotation-unknown --lowering-options=explicitBitcast,disallowLocalVariables,disallowPortDeclSharing,locationInfoStyle=none" \
     --firtool-opt "--default-layer-specialization=enable"
   make -C difftest emu NUM_CORES=1 RTL_SUFFIX=sv OBJCACHE= -j8
   (注意: 需初始化全部子模块, 含 XSCache 内嵌 ZhuJiang)
3. 生成 flash 镜像: python3 gen_flash.py
4. 运行: ./run.sh

## 预期输出(关键行)
Assertion failed at /work/build/rtl/Ftq.sv:4896.
Core 0: ABORT at ... 
Core-0 instrCnt = 9, cycleCnt = 2137, IPC = 0.004212
Assertion failed: ExceptionType receives input that is not one-hot: pf=1, gpf=0, af=1, ill=0, hwe=0

## 原理
p9 跳转 0x1FFFFFE(flash AXI 区间尾部, %8==6 跨 8B beat, %4K==0xFFE 跨页):
- beat1 [0x1FFFFF8,+8) 落 flash 内 OK, 半字@6=0xFFFF -> RVI
- 因同时跨页, entry 不做内部重发, 改报 needResend -> IFU 携半 RVI 续取
  信息重定向页 2 @0x20000000 (越过 flash AXI 区间 -> AXI4Error -> DECERR)
- 续取的取指异常经 ROB->redirect->Ftq 透传时异常向量被污染为 multi-hot
  (pf+af) -> ExceptionType one-hot 断言失败 -> ABORT
- 断言关闭时 multi-hot 经 MuxCase 塌缩(Pf 优先), 架构上 mcause/mtval 错误
  (pre-#6428 版本 A 波形实测 mtval=trapPC 而非 trapPC+2, 并触发 double trap)

## 判据
同拍(cycle 2137, instrCnt=9) ABORT + 上述断言文本 = 复现成功。
若跑满 20000 拍无 ABORT: 检查 (a) 补丁是否生效 (b) NEMU_HOME 是否设置
(c) flash.bin 是否含 tail 两字节。
