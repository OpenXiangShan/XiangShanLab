#!/bin/bash
# 用法: run.sh <emu路径>  (默认 /work/build/verilator-compile/emu)
EMU=${1:-/work/build/verilator-compile/emu}
export NEMU_HOME=/work/nemu-src
bash -c "ulimit -v 209715200 && $EMU -i $PWD/p9.elf -F $PWD/flash.bin -C 20000 --no-diff"
