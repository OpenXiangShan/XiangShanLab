# 独立模型对照：NEMU DiffTest REF

## Spike：不可用

同一 ELF 交给 Spike 时，多条 Zk/向量指令被当作 illegal instruction。Spike 在到达 `0x800010d0` 的 `vse32.v` 之前已经偏离测试的初始化路径。`spike-rerun.json` 记录首陷阱为 `illegal_instruction`，不支撑结论。

## 采用的差分 oracle

| 模型 | 结果 | 记录 |
| --- | --- | --- |
| NEMU（XiangShan `ready-to-run` bundled REF） | 在 DUT 停滞后执行 `0x800010dc` 的 AMO，`a2=0xc0c0c0c0` | `run/stdout.log` |
| XiangShan DUT（`4cf8b8d4ae`） | 不提交；15000 周期后 DiffTest 报告 `a2=0xc6fe9d4ace7be0fa` | `run/stdout.log` |

DiffTest 的原话：

```text
No instruction of core 0 commits for 15000 cycles, maybe get stuck
...
Let REF run one more instruction.
...
a2 different at pc = 0xfffed825b34beec9,
right = 0x00000000c0c0c0c0, wrong = 0xc6fe9d4ace7be0fa
```

`right` 是 NEMU 的值。`wrong` 是 DUT 的值。

## 为什么 NEMU 记录可以作为 oracle

NEMU 不共享 XiangShan 的 Store Queue 或 AtomicsUnit 实现。它执行同一条 AMO，并给出架构结果。DUT 不提交同一条指令。因此差异定位在 DUT 的微架构状态，不在程序或参考模型。

## QEMU

`qemu-system-riscv64 -M virt -bios none -kernel prog.elf` 启动后 30 s 无自检输出。该 ELF 依赖 XiangShan 的 tohost/PMEM 约定。QEMU 记录不作为判定依据。

## 备注

- `prog.elf` 是 Issue 附件中的 seed。原始源码未随附件提供；`disassembly.txt` 是实际执行指令的来源。
- 本包不声称 NEMU 模拟了 vector store 的精确微架构行为。它只提供后续 AMO 的架构结果。
