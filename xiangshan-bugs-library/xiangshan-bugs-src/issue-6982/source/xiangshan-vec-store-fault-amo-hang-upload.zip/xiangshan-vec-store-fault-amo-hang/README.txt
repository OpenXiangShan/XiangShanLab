xiangshan xiangshan-vec-store-fault-amo-hang reproducer
===================================================================================================================================================

Issue: [BUG] A faulting vector store leaves a physical store-queue head that never commits or dequeues, so the next AMO waits forever on the sbuffer flush

Files: 9

Files
-----

TIMELINE.md
    Anchor window timeline (cycle, sample, t and observed signals).
    SHA-256: 792a16453deda3cf8f2d98a563d50c7a582bb95db41c860c988f59f26eee9a4e

comparison.json
    Sanitized DUT-versus-reference comparison record.
    SHA-256: 44814cd2d3705fd97312f1505ba5e0f3f3cc4b4c96a45401202a004f2dba95a7

disassembly.txt
    Full objdump of the reproducer; header names prog.elf.
    SHA-256: 865da5af36a6a6e016d6399c95aad746a6ab0c6854e894a248e5301e5ca4dd95

oracle.md
    Reference-model (Spike) result, renamed from ORACLE.md.
    SHA-256: e37698f8e47e30217f1eda8975adb2119a764030305d500254ddb249cd3e2f77

prog.elf
    Reproducer ELF (binary, unmodified).
    SHA-256: 3808618dc52fcb507293e94172b92315b390958534d7882cc75f675dada10cf7

signals.csv
    Signal samples for the same window as TIMELINE.md.
    SHA-256: 22f863e32dbe021c8bec40cc7a5515003b3da13142fddf4175fa883fee9eb5fa

sim.log
    Simulator log for the recorded run.
    SHA-256: f678259b0ccdc57fc2df825da7966be40f6e1bcb7080f78e3493c72225455ef3

wave.fst
    FST waveform covering the anchor window.
    SHA-256: e4b7354fac6d73a2bfb6a40596deca8b090750baa963915552841a88ae917fed

Reproduction summary
--------------------

- Run the seed ELF on the KMHv3 build with DiffTest against the bundled NEMU reference.
- Execute `vse32.v v15,(ra)` at `0x800010d0` with `ra = 0x5c0`; observe the store access fault (`cause = 7`) and the handler's `mepc += 4` / `mret`.
- Continue through `remw s9,t4,a4` at `0x800010d4` and the illegal `0x014f4d23` at `0x800010d8`, handled and returned from.
- Execute `amoswap.d.aq a2,s6,(t6)` at `0x800010dc`; the DUT does not commit it, and after 15,000 cycles DiffTest lets the reference advance one instruction and reports a register mismatch.

Expected:
  After the precise vector-store fault is handled and `mret` returns, the AMO executes. NEMU, the bundled DiffTest reference, runs the AMO at `0x800010dc` and reports `a2 = 0xc0c0c0c0`. Spike cannot serve as the oracle here: it treats several Zk/vector instructions in this ELF as illegal and diverges before reaching the `vse32.v` at `0x800010d0`.

Observed:
  The DUT deadlocks instead of executing the AMO:

  - traps recorded: `cause 7` at `0x800010d0` (vector store access fault) and `cause 2` at `0x800010d8` (illegal instruction)
  - commit trace: `[20]` exception at `0x800010d0`, `[21]`–`[25]` handler with `mepc += 4` and `mret`, `[26]` commit of `0x800010d4`, `[27]`–`[31]` illegal instruction and handler, then nothing
  - `instrCnt = 334`, `cycleCnt = 17,072`; no commit for 15,000 cycles
  - DiffTest: `No instruction of core 0 commits for 15000 cycles, maybe get stuck`, then after letting the reference run one more instruction, `a2 different at pc = 0xfffed825b34beec9, right = 0x00000000c0c0c0c0, wrong = 0xc6fe9d4ace7be0fa`

Notes
-----

- Full run manifests, code-evidence markdown, waveform analysis JSON, symbol tables, and raw memory images are omitted because their headers contain internal paths.
- Absolute paths in the remaining text files have been replaced by file names; the objdump header now names prog.elf.
