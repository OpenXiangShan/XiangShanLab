# Waveform timeline: xiangshan/xiangshan-vec-store-fault-amo-hang

- 波形：`waveform`
- 采样：clock=`None`，edge=`negedge`，xz_value=`0`
- 锚点：cycle 15000 / sample 0 / t=15000
- 锚点值：atom_state=3、sqempty=0、flush_empty=0、slot3_hasException=1、slot3_committed=0、deq_ptr=3、vec_mb_commit=0、retire_ptr=5、redirect_ptr=5
- X/Z 样本数：atom_state=0、sqempty=0、flush_empty=0、slot3_hasException=0、slot3_committed=0、deq_ptr=0、vec_mb_commit=0、retire_ptr=0、redirect_ptr=0

| cycle | sample | t | atom_state | sqempty | flush_empty | slot3_hasException | slot3_committed | deq_ptr | vec_mb_commit | retire_ptr | redirect_ptr |
|---:|---:|---:|---|---|---|---|---|---|---|---|---|
| 15000 | 0 | 15000 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |
| 15001 | 1 | 15001 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |
| 15002 | 2 | 15002 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |
| 15003 | 3 | 15003 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |
| 15004 | 4 | 15004 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |
| 15005 | 5 | 15005 | 3 | 0 | 0 | 1 | 0 | 3 | 0 | 5 | 5 |

## 说明

- 锚点条件：`[["slot3_hasException", "eq", 1], ["atom_state", "eq", 3], ["deq_ptr", "eq", 3]]`
- 缺陷：faulting vector store leaves a physical SQ head with hasException; the next AMO waits forever on sbuffer flush
- 轨迹起点 cycle：15000；`anchor_cycle = trace_origin + anchor_sample_cycle`。
