# Vector scalar-operand read: vmv.v.x / vadd.vx must take the GPR value.
# a0 = (vadd.vx result << 32) | (vmv.v.x result)
# expected 0x0000000f_00000005 (15 and 5); a zero upper half means the GPR read was lost.
    .option norvc
    .section .text.init
    .globl _start
_start:
    la      t0, trap
    csrw    mtvec, t0
    li      t0, 0x6600              # mstatus.FS=3, VS=3
    csrw    mstatus, t0
    csrw    fcsr, zero

    vsetvli t0, zero, e32, m1, ta, ma
    li      t0, 5
    vmv.v.x v8, t0                  # v8 = 5
    la      t1, out_v
    vse32.v v8, (t1)                # out_v[0] = v8

    vadd.vi v16, v8, 5              # v16 = v8 + 5 (immediate source)
    li      t0, 5
    vadd.vx v24, v16, t0            # v24 = v16 + t0 (GPR source)
    la      t2, out_v2
    vse32.v v24, (t2)

    la      t1, out_v
    lw      s0, 0(t1)               # vmv.v.x result
    la      t2, out_v2
    lw      s1, 0(t2)               # vadd.vx result
    slli    a0, s1, 32
    or      a0, a0, s0
    j       done

trap:
    csrr    a0, mcause
    ori     a0, a0, 0x80            # unexpected trap marker
done:
    la      t0, tohost
    slli    t1, a0, 1
    ori     t1, t1, 1
    sd      t1, 0(t0)
    .word   0x0005006b
9:  j       9b

    .section .data
    .align  6
out_v:  .dword 0, 0
out_v2: .dword 0, 0

    .section .tohost,"aw",@progbits
    .align  6
    .globl  tohost
tohost:   .dword 0
    .globl  fromhost
fromhost: .dword 0
