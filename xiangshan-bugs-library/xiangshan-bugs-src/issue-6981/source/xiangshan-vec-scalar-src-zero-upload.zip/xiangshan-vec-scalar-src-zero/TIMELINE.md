# Waveform timeline: xiangshan-vec-scalar-src-zero

- 波形：`wave.fst`
- 采样：clock=`TOP.SimTop.cpu.clock`，one sample per cycle，xz_value=`None`（X/Z 用 mask 检查）
- 锚点：cycle 1014 / sample 1013 / t=1014
- 锚点值：gpRen=1、vpRen=0、fuType=0x8000000、opcode=0xf06、uopIdx=0、data_src_0=0
- X/Z 样本数：gpRen=0、vpRen=0、fuType=0、opcode=0、uopIdx=0、data_src_0=0

The only GPR-reading vector uop (fuType=0x8000000 vmove, gpRen=1, vpRen=0) receives data_src_0=0 although t0=5.

| cycle | sample | t | gpRen | vpRen | fuType | opcode | uopIdx | data_src_0 |
| ---: | ---: | ---: | --- | --- | --- | --- | --- | --- |
| 1008 | 1007 | 1008 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1009 | 1008 | 1009 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1010 | 1009 | 1010 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1011 | 1010 | 1011 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1012 | 1011 | 1012 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1013 | 1012 | 1013 | 0 | 0 | 0xb25fc1bb | 0xda0 | 2 | 0x960ddbf4a4660f0ffd42163a4ac32ed2 |
| 1014 | 1013 | 1014 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1015 | 1014 | 1015 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1016 | 1015 | 1016 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1017 | 1016 | 1017 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1018 | 1017 | 1018 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1019 | 1018 | 1019 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
| 1020 | 1019 | 1020 | 1 | 0 | 0x8000000 | 0xf06 | 0 | 0 |
