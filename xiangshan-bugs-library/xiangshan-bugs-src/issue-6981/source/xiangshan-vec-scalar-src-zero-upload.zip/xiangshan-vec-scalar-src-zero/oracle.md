# ORACLE — 独立模型对照

## Spike

spike`
sha256：`ca7e66673a48d876e3b291e437ea47921fd067378b841c02f541ff1d493970c5`

```console
$ spike --isa=RV64GCV -m0x80000000:0x10000000 -l --log-commits prog.elf
...
core   0: 3 0x0000000080000084 (0x00136313) ori     t1, t1, 1
core   0: 3 0x0000000080000084 (0x00136313) x6  0x0000001e0000000b
core   0: 0x0000000080000088 (0x0062b023) sd      t1, 0(t0)
core   0: 3 0x0000000080000088 (0x0062b023) mem 0x0000000080000100 0x0000001e0000000b
core   0: 0x000000008000008c (0x0005006b) unknown
core   0: exception trap_illegal_instruction, epc 0x000000008000008c
core   0:           tval 0x000000000005006b
*** FAILED *** (tohost = 5)
```

- `tohost = 0x1e0000000b = (0xF00000005 << 1) | 1` ⇒ `a0 = 0x0000000F_00000005`
- 即 `v8 = 5`、`v24 = 15`，与规范一致。
- 这是 **value-only** 缺陷：唯一的陷阱是程序末尾的 `.word 0x0005006b` 退出标记
  （Spike 视为非法指令），不是缺陷证据。`(tohost = 5)` 是 Spike 的进程退出码，
  `tohost >> 1 = 0xF00000005` 才是程序写出的 `a0`。

## 差分对照

| 目标 | 版本 | a0 |
| --- | --- | --- |
| Spike | RV64GCV | `0x0000000F_00000005` |
| KMHv2 | `fe2288cb09` | `0x0000000F_00000005` |
| KMHv3 | `6705b63685` | `0x00000005_00000000` |
| KMHv3 HEAD | `a0c2a26cbe` | 出口标记 PC `0x8000008c` = bad（`headcheck/`） |
| Spike（headcheck ELF） | RV64GCV | 出口标记 PC `0x80000074` = good |

KMHv2 用同一份 ELF、同一个出口约定通过，所以不是测试或环境问题。
