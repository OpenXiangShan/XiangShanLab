xiangshan xiangshan-vec-scalar-src-zero reproducer
===========================================================================================================

Issue: [BUG] Vector instructions drop the scalar GPR source, so `vmv.v.x` and `vadd.vx` read 0 instead of `t0 = 5`

Files: 12

Files
-----

TIMELINE.md
    Anchor window timeline (cycle, sample, t and observed signals).
    SHA-256: 1c79881cdcd27f259c202c56033856d2f40f303cb83b5899f4baee029a161f09

comparison.json
    Sanitized DUT-versus-reference comparison record.
    SHA-256: 864a5b7e4a67bfc97d1d544451f8c47e52215785610ac138b74c16969cdfa8db

disassembly.txt
    Full objdump of the reproducer; header names prog.elf.
    SHA-256: c0b78541c2bbbe19ab9008f9eaefcfacc6991c32ecd6be4b3c96077d54c8e6ba

event.json
    Recorded exit event of the DUT run.
    SHA-256: ba7861696d73068b047e6762d3ccb40227db10ce092d8978c9a36bb733a8d46a

link.ld
    Linker script for the reproducer.
    SHA-256: 79873d2e080bc19b4e3a547ea90551e925a6a52b83b7f3fbc39e9f7256a2d23c

oracle.md
    Reference-model (Spike) result, renamed from ORACLE.md.
    SHA-256: a778b399ad98bb253865248b5cbbb68b0ff100f71a0979e22798fe5c129634cb

prog.S
    Reproducer assembly source.
    SHA-256: d438638f5c84c57df44d9f605f6efdc605d7ae0f5fb1759bc315864133ec3031

prog.elf
    Reproducer ELF (binary, unmodified).
    SHA-256: 58c40e8d7537c38c6bfec4bcd04388cdac9553cde90e2fc017ea5fe9dc578759

signals.csv
    Signal samples for the same window as TIMELINE.md.
    SHA-256: fa08e4b65bad96652a6551216b4a6ee26f3fc97b62b7ea5e51355ed61d75f0ae

sim.log
    Simulator log for the recorded run.
    SHA-256: e0f49fdc040757d05cdde005570e1ff6b9a759b8fa1f2352ed32f3020f57293b

wave.fst
    FST waveform covering the anchor window.
    SHA-256: 07b700d5cce5b6f7772c166a0d677399c1a3b89f3c354780b07a49261b8f7e97

Reproduction summary
--------------------

- Assemble the program with `-march=rv64gcv -mabi=lp64d -nostdlib -Wl,--no-relax` and run it on the KMHv3 build with the same image and link base (`0x80000000`).
- Set `t0 = 5`, execute `vmv.v.x v8,t0`, store `v8`, and execute `vadd.vi v16,v8,5` as the immediate-source control.
- Execute `vadd.vx v24,v16,t0`, store `v24`, and exit with `a0 = (v24 << 32) | v8`.
- Run the same ELF on KMHv3, KMHv2, and Spike, and compare `a0`.

Expected:
  Spike (RV64GCV) and KMHv2 (`fe2288cb09`) both produce `a0 = 0x0000000F00000005`:

  - `v8 = 5` from `vmv.v.x`
  - `v16 = 10` from `vadd.vi`
  - `v24 = 15` from `vadd.vx`

Observed:
  The DUT loses the scalar source and exits with `a0 = 0x0000000500000000`:

  - `v8 = 0` (the `vmv.v.x` result is zero, not 5)
  - `v16 = 5` (immediate source is correct)
  - `v24 = 5` (`vadd.vx` added 0, not 5)
  - exit event PC `0x8000008c`, instruction `0x0005006b`, `a0 = 0x0000000500000000`, 1,032 cycles, 38 instructions
  - the only uop with `gpRen = 1` is the `vmove` uop at the anchor, and it carries `vpRen = 0` and `data_src_0 = 0`

Notes
-----

- Full run manifests, code-evidence markdown, waveform analysis JSON, symbol tables, and raw memory images are omitted because their headers contain internal paths.
- Absolute paths in the remaining text files have been replaced by file names; the objdump header now names prog.elf.
