#!/usr/bin/env python3
"""Filter the original VCD to one PTW scope and verify selected event equivalence.
No simulation, resampling, timestamp renumbering, or value reconstruction occurs.
"""
import argparse
import hashlib
import json
from pathlib import Path

SCOPE = 'TOP.SimTop.cpu.l_soc.core_with_l2.core.memBlock.inner_ptw.ptw.ptw'
PROBES = (11789, 11790, 11809)
KEYS = ('io_req_valid', 'io_req_ready', 'io_req_bits_stage1Hit', 'stage1Hit',
        'pte_valid', 'pageFault', 'level', 'full_gvpn_reg', 'full_gvpn',
        'gvpn_gpf', 'guestFault', 'io_hptw_req_valid', 'io_hptw_req_ready',
        'io_hptw_req_bits_gvpn', 'io_resp_valid', 'io_resp_ready',
        'io_resp_bits_h_resp_gpf')

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def header(f):
    scopes, declarations, signals, metadata = [], [], {}, []
    for line in f:
        q = line.split()
        if not q:
            continue
        if q[0] == '$scope':
            scopes.append(q[2])
        elif q[0] == '$upscope':
            scopes.pop()
        elif q[0] == '$var' and '.'.join(scopes) == SCOPE:
            declarations.append(line)
            signals[q[4]] = {'code': q[3], 'width': int(q[2])}
        elif q[0] in ('$version', '$date', '$timescale'):
            metadata.append(line)
            while '$end' not in metadata[-1]:
                metadata.append(next(f))
        elif q[0] == '$enddefinitions':
            return declarations, signals, metadata
    raise ValueError('missing VCD enddefinitions')

def code_of(line):
    s = line.strip()
    if not s:
        return None
    if s[0] in 'bBrR':
        return s.split()[-1]
    if s[0] in '01xXzZ':
        return s[1:]
    return None

def read_events(path, keep, names):
    events, selected, state, t = [], {}, {}, None
    with path.open() as f:
        for line in f:
            if line.lstrip().startswith('$enddefinitions'):
                break
        for line in f:
            s = line.strip()
            if not s:
                continue
            if s[0] == '#':
                if t in PROBES:
                    selected[t] = {name: state.get(data['code']) for name, data in names.items() if name in KEYS}
                t = int(s[1:])
            else:
                code = code_of(line)
                if code in keep:
                    raw = s[1:].split()[0] if s[0] in 'bBrR' else s[0]
                    events.append((t, code, raw))
                    state[code] = int(raw, 2) if set(raw) <= set('01') else raw
        if t in PROBES:
            selected[t] = {name: state.get(data['code']) for name, data in names.items() if name in KEYS}
    return events, selected

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source', type=Path)
    ap.add_argument('output', type=Path)
    args = ap.parse_args()
    if args.source.resolve() == args.output.resolve():
        raise ValueError('output must differ from source')
    with args.source.open() as src:
        declarations, signals, metadata = header(src)
        if not set(KEYS).issubset(signals):
            raise ValueError('missing required signals: '+repr(set(KEYS)-set(signals)))
        keep = {s['code'] for s in signals.values()}
        with args.output.open('w') as dst:
            dst.writelines(metadata)
            dst.write('$comment Filtered direct PTW scope; all retained raw values and timestamps are unchanged. Existing simulation evidence only. $end\n')
            for name in SCOPE.split('.'):
                dst.write('$scope module '+name+' $end\n')
            dst.writelines(declarations)
            for _ in SCOPE.split('.'):
                dst.write('$upscope $end\n')
            dst.write('$enddefinitions $end\n')
            for line in src:
                s = line.lstrip()
                if s.startswith('#') or s.startswith('$') or code_of(line) in keep:
                    dst.write(line)
    original, snapshots = read_events(args.source, keep, signals)
    filtered, filtered_snapshots = read_events(args.output, keep, signals)
    assert original == filtered, 'filtered value/timestamp stream differs'
    assert snapshots == filtered_snapshots
    req, hreq, resp = (snapshots[t] for t in PROBES)
    assert req['io_req_valid'] == req['io_req_ready'] == req['io_req_bits_stage1Hit'] == 1
    assert hreq['io_hptw_req_valid'] == hreq['io_hptw_req_ready'] == 1
    assert hreq['io_hptw_req_bits_gvpn'] == 0x20000000
    assert resp['io_resp_valid'] == resp['io_resp_ready'] == 1
    assert resp['io_resp_bits_h_resp_gpf'] == 0
    for state in snapshots.values():
        assert state['pte_valid'] == state['pageFault'] == 1
        assert state['gvpn_gpf'] == state['guestFault'] == 0
    report = {
        'source_file': args.source.name, 'source_bytes': args.source.stat().st_size,
        'source_sha256': sha256(args.source),
        'focused_file': args.output.name, 'focused_bytes': args.output.stat().st_size,
        'focused_sha256': sha256(args.output), 'scope': SCOPE,
        'declared_signals': len(declarations), 'unique_value_codes': len(keep),
        'selected_value_events': len(original), 'event_stream_identical': True,
        'first_selected_timestamp': original[0][0], 'last_selected_timestamp': original[-1][0],
        'timescale': ''.join(metadata),
        'note': 'Original VCD timestamps and 1ps declaration are retained; sample labels must not be assumed to represent physical picoseconds or independently observed clock edges. No new simulation.',
        'handshake_snapshots': snapshots,
    }
    args.output.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    args.output.with_suffix('.signals.json').write_text(json.dumps(signals,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    main()
