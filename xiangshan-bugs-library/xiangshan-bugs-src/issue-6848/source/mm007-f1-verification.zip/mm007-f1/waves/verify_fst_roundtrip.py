#!/usr/bin/env python3
"""Compare PTW signal histories after FST roundtrip, independent of VCD codes."""
import argparse, json
from pathlib import Path
from collections import defaultdict
from filter_ptw_vcd import header, code_of, sha256, SCOPE, KEYS, PROBES

def histories(path):
    with path.open() as f:
        declarations, signals, meta = header(f)
        codes = defaultdict(list)
        widths = {}
        for name, info in signals.items():
            codes[info['code']].append(name)
            widths[info['code']] = info['width']
        events = {name: [] for name in signals}
        raw_count = 0
        t = None
        for line in f:
            s = line.strip()
            if not s: continue
            if s[0] == '#': t=int(s[1:]); continue
            code = code_of(line)
            if code not in codes: continue
            raw_count += 1
            raw = s[1:].split()[0] if s[0] in 'bBrR' else s[0]
            pad = raw[0].lower() if raw[0].lower() in 'xz' else '0'
            value = raw.lower().rjust(widths[code],pad)
            for name in codes[code]:
                if not events[name] or events[name][-1][1]!=value:
                    events[name].append((t,value))
        return signals, events, raw_count

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source',type=Path)
    ap.add_argument('roundtrip',type=Path)
    ap.add_argument('fst',type=Path)
    ap.add_argument('--output',type=Path,default=Path('fst_roundtrip_validation.json'))
    a=ap.parse_args()
    s0,e0,c0=histories(a.source); s1,e1,c1=histories(a.roundtrip)
    assert set(s0)==set(s1), 'signal names changed'
    for name in s0:
        assert s0[name]['width']==s1[name]['width'], 'width changed: '+name
        assert e0[name]==e1[name], 'history changed: '+name
    snapshots={}
    for t in PROBES:
        snapshots[t]={}
        for name in KEYS:
            vals=[v for et,v in e1[name] if et<=t]
            snapshots[t][name]=int(vals[-1],2) if set(vals[-1])<=set('01') else vals[-1]
    assert snapshots[11789]['io_req_valid']==snapshots[11789]['io_req_ready']==snapshots[11789]['io_req_bits_stage1Hit']==1
    assert snapshots[11790]['io_hptw_req_valid']==snapshots[11790]['io_hptw_req_ready']==1
    assert snapshots[11790]['io_hptw_req_bits_gvpn']==0x20000000
    assert snapshots[11809]['io_resp_valid']==snapshots[11809]['io_resp_ready']==1
    assert snapshots[11809]['io_resp_bits_h_resp_gpf']==0
    for row in snapshots.values():
        assert row['pte_valid']==row['pageFault']==1
        assert row['gvpn_gpf']==row['guestFault']==0
    report={'scope':SCOPE,'source_file':a.source.name,'source_sha256':sha256(a.source),
      'fst_file':a.fst.name,'fst_bytes':a.fst.stat().st_size,'fst_sha256':sha256(a.fst),
      'roundtrip_vcd_sha256':sha256(a.roundtrip),'signals_compared':len(s0),
      'source_unique_codes':len({i['code'] for i in s0.values()}),
      'source_value_events':c0,'roundtrip_value_events':c1,
      'all_signal_widths_and_histories_identical':True,
      'normalization':'Mapped VCD codes to signal names; normalized binary padding and consecutive redundant assignments. Timestamp/value histories for every selected variable are identical.',
      'handshake_snapshots':snapshots,
      'converter':'GTKWave 3.3.129, lts commit 73c1d6b8b204e40e06a9403a3fc74a1244c048a4',
      'command':f'vcd2fst {a.source.name} {a.fst.name} -c; fst2vcd {a.fst.name} -o {a.roundtrip.name}',
      'no_simulation':True}
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='handshake_snapshots'},indent=2))
if __name__=='__main__': main()
