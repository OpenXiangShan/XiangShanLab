MM007-F1 waveform package (FST)

Delivered waveforms:
  w4_alias_full.fst : complete existing positive-case window, 6,189,422 bytes
  w4_alias_ptw.fst  : focused PTW scope, 4,068 bytes

No new simulation was run. Both files were converted with official GTKWave
vcd2fst from the existing w4_alias.vcd (168,809,831 bytes). The source already
uses VCD format. The complete file preserves the whole original window;
the focused file retains all 713 direct PTW signal declarations in:
  TOP.SimTop.cpu.l_soc.core_with_l2.core.memBlock.inner_ptw.ptw.ptw

Open either file in GTKWave, for example:
  gtkwave w4_alias_ptw.fst
  gtkwave w4_alias_full.fst

Useful original timestamp labels:
  11789: io_req_valid=1, io_req_ready=1, io_req_bits_stage1Hit=1
  11790: io_hptw_req_valid=1, io_hptw_req_ready=1,
         io_hptw_req_bits_gvpn=0x20000000 (GPA=2^41)
  11809: io_resp_valid=1, io_resp_ready=1, io_resp_bits_h_resp_gpf=0
At all three: pte_valid=1, pageFault=1, level=2,
  full_gvpn_reg=0x20000000, gvpn_gpf=0, guestFault=0.

Original timestamps and the original 1ps timescale declaration are retained.
These sample labels must not be assumed to be independent clock-edge
measurements or physical timing. Payload bits alone, for example the
stage1Hit bit at t=11659, do not prove request acceptance.

Verification:
  1. The focused VCD retained 649 unique codes/985 selected value events,
     compared exactly to the original before conversion.
  2. Both FST files were independently decoded with fst2vcd.
  3. All 713 PTW signal widths and complete timestamp/value histories were
     compared by signal name with the corresponding original VCD. All
     matched, with 985 input and 985 decoded PTW value events in each case.
  4. The three handshakes and fault-gating states above were asserted.
The full FST comparison covered the PTW scope, not every CPU signal.
FST may renumber VCD identifiers and reorder different signals at the same
timestamp; comparison normalizes identifier names and binary zero-padding.

Validation metadata:
  w4_alias_ptw.validation.json       : original VCD filtering and source hash
  fst_roundtrip_validation.json     : focused FST roundtrip checks
  fst_full_roundtrip_validation.json: full FST roundtrip PTW checks
  w4_alias_ptw.signals.json          : all retained PTW signals and widths
  CONVERTER_INFO.txt                : tool version, source commit and commands

To decode FST using an installed GTKWave utility:
  fst2vcd w4_alias_ptw.fst -o focused_decoded.vcd
  fst2vcd w4_alias_full.fst -o full_decoded.vcd

The filter/verification scripts are supplied for reproducibility. Full
verification against the original requires the source VCD identified by
its SHA-256 in the metadata; it is intentionally not duplicated in this
compact package.

The focused PTW scope does not contain the final memory-bus physical address
or architectural load-commit data. Use the full waveform, program and logs
to review those parts of the claim. No claim is made that the final bus PA
was separately extracted in this packaging task.
