MM007-F1 issue and verification package

ISSUE_TITLE.txt and ISSUE.md are the English title/body in the current official XiangShan bug-report format. They have not been posted to GitHub.

No duplicate of the same mechanism was found in the issue/PR search on 2026-11-03. See DUPLICATE_CHECK.txt. The official latest-default-branch reproduction checkbox is intentionally unchecked: these are existing kunminghu-v2 fe2288cb results. The human AI-review checkbox is also left for the submitting person.

Quick evidence review, without running a simulation:
1. From the extracted mm007-f1 directory: sha256sum -c CHECKSUMS.sha256
2. Read ISSUE.md and analysis/REVIEW.txt.
3. Read logs/r10_alias_nodiff.log (first 18 lines) and logs/r12_alias_diff.log.
4. Open waves/w4_alias_ptw.fst in GTKWave; use waves/w4_alias_full.fst for all signals from the positive capture.
5. Review timestamps 11789 / 11790 / 11809 and analysis/existing_wave_review.json.

The original waveforms were VCD. The full positive capture is converted to FST, and the focused FST retains the selected PTW scope for quick inspection. Conversion is checked by reading FST back. These are not new runs or waveforms reconstructed from text. Large source VCDs and unrelated waveform windows are excluded to keep the package small. The original 1 ps timescale is retained; the capture's timestamp convention should not be reinterpreted as an independently measured physical clock period.

Contents:
  src/       Original positive and control programs and linker script
  bin/       Existing positive/control BIN, ELF and disassembly
  logs/      Full original positive, difftest, control and waveform-run logs
  waves/     Complete positive FST, focused PTW FST, conversion/validation records
  analysis/  Corrected review, evidence excerpts, wave analysis, source traces
  source/    Fixed-revision Scala, generated PTW RTL and RAM-model source
  metadata/  Versions/hashes, official template, static-only current-v2 excerpt
  tools/     Optional rebuild/run commands and waveform filter/validation

Important corrections to preserved original material:
- 2^41 >> 2 = 0x8000000000, not 0x80000000.
- The truncated Sv39x4 root index is 0, not 1024.
- DUT scause=0xd in the positive difftest mismatch is a prior trap CSR, not a new fault on the positive load.
- The no-diff program prints DONE and spins to the cycle limit; it has no GOOD TRAP assertion.
- With an insufficient MODE-change fence, the new-mode GPF is not the sole permitted reference result. The bug argument is the third mapping that is neither the old Bare result nor the new Sv39x4 result.

Optional workload rebuild (does not overwrite archived binaries):
  CROSS_COMPILE=/path/to/riscv64-unknown-linux-gnu- bash tools/build.sh

Optional future reproduction (not executed during package preparation):
  EMU=/absolute/path/to/emu bash tools/run.sh nodiff
  EMU=/absolute/path/to/emu NEMU=/absolute/path/to/riscv64-nemu-interpreter-so bash tools/run.sh diff

run.sh uses timeout and, when a user systemd session is available, a 100 GiB memory limit. Future logs go to a new reruns/ directory. Do not interpret a cycle-limit exit as a test pass. No full hardware repository, emulator, or NEMU binary is included; identify those with metadata/versions.json and analysis/engine_hashes.txt.
