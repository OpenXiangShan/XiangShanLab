OUTPUT_ARCH(riscv)
ENTRY(_start)

SECTIONS
{
  . = 0x80000000;
  .text : { *(.text.init) *(.text*) }

  . = 0x80003000;
  .results : { *(.results) }

  . = 0x80020000;
  .magic : { *(.magic) }

  . = 0x80030000;
  .inrange : { *(.inrange) }

  . = 0x80050000;
  .groot : { *(.groot) }

  . = 0x80054000;
  .gl1_0 : { *(.gl1_0) }

  . = 0x80055000;
  .gl1_2 : { *(.gl1_2) }

  . = 0x80056000;
  .gl1_1024 : { *(.gl1_1024) }

  . = 0x80057000;
  .gl0_1024 : { *(.gl0_1024) }

  . = 0x80058000;
  .gl0_0 : { *(.gl0_0) }

  . = 0x80060000;
  .vsroot : { *(.vsroot) }

  . = 0x80061000;
  .vsl1 : { *(.vsl1) }

  . = 0x80062000;
  .vsl0 : { *(.vsl0) }

  /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) *(.riscv.attributes) }
}
