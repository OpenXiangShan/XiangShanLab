# MM007:F1 supplementary PoC -- PageCache onlyStage1 alias reused under allStage
#
#   The PageTableCache tags allStage and onlyStage1 requests with the same
#   `h = onlyStage1` label (PageTableCache.scala:379-381), and canRefill() for
#   onlyStage1 does NOT test isStage1Gpf (MMUBundle.scala:845-847).  So a 4KB
#   stage-1 leaf with PPN = 2^29 is cached with v=1 while hgatp=Bare, and the
#   same entry is a legal `stage1Hit` source once hgatp=Sv39x4 is enabled.
#
#   VA 0x1_4000_0000 (T)  -> 3-level VS walk -> 4KB leaf, PPN=2^29 (GPA 2^41)
#   VA 0x1_4000_1000 (T2) -> same table, next entry, never translated first
#   VA 0x8000_0000        -> root[2] = 0   (stage-1 page fault, V=0 residue)
#   G-stage maps GPA[41:30] (root index 1024) and GPA 0 to PA 0x8002_0000,
#   so a missing gpf check shows up as data 0xDEAD000012345678 instead of a trap.
#
#   phases: see PHASE comments.  HS commands (ecall) switch hgatp / hfence.
.option norvc

.equ UART_BASE,  0x310b0000

# ---------------------------------------------------------------- macros
.macro PHASE id, va
  li    t0, \id
  sd    t0, 0(s2)
  li    a1, 0xBAD
  li    a0, \va
  ld    a1, 0(a0)
  li    t0, 40
  li    t2, \id
  mul   t2, t2, t0
  li    t1, 0x100
  add   t1, t1, t2
  add   t1, t1, s2
  sd    a1, 24(t1)
  rdcycle t0
  sd    t0, 32(t1)
.endm

.macro CMD id, code
  li    t0, \id
  sd    t0, 0(s2)
  li    t0, \code
  sd    t0, 8(s2)
  ecall
  li    t0, 0
  sd    t0, 8(s2)
.endm

.macro DONE id
  li    t0, \id
  sd    t0, 0(s2)
  li    t0, 9
  sd    t0, 8(s2)
  ecall
1:
  j     1b
.endm

# ---------------------------------------------------------------- M mode
.section .text.init, "ax"
.globl _start
_start:
  li    sp, 0x80010000
  la    t0, m_trap
  csrw  mtvec, t0

  li    t0, -1
  csrw  pmpaddr0, t0
  li    t0, 0x1f
  csrw  pmpcfg0, t0

  li    t0, 0x00f0b700
  csrw  medeleg, t0
  li    t0, 7
  csrw  mcounteren, t0

  li    t0, 0x80003000
  li    t1, 0x80004000
1:
  sd    zero, 0(t0)
  addi  t0, t0, 8
  blt   t0, t1, 1b

  la    s1, banner
  jal   ra, puts_

  li    t0, 0x888
  csrw  mstatus, t0
  la    t0, hs_entry
  csrw  mepc, t0
  mret

# ---------------------------------------------------------------- HS mode
  .align 2
hs_entry:
  la    t0, hs_trap
  csrw  stvec, t0
  li    t0, 7
  csrw  hcounteren, t0

  li    t0, 0x8000000000080060   # vsatp: Sv39, root PA 0x80060000
  csrw  vsatp, t0
  li    t0, 0x0000000000000000   # hgatp: Bare (mode=0), vmid=0
  csrw  hgatp, t0
  sfence.vma x0, x0
  hfence.gvma x0, x0

  li    t0, 0x200000080          # hstatus: VSXL=2, SPV=1
  csrw  hstatus, t0
  li    t0, 0x100                # sstatus.SPP = 1
  csrw  sstatus, t0

  la    t0, vs_entry
  li    t1, 0x80000000
  sub   t0, t0, t1
  li    t1, 0x100000000
  add   t0, t0, t1
  csrw  sepc, t0
  sret

# ---------------------------------------------------------------- VS mode
  .align 2
vs_entry:
  li    s2, 0x100003000
  fence

  PHASE  0, 0x140000000          # hgatp=Bare: T, builds onlyStage1 alias (v=1)
  CMD    1, 1                    # -> Sv39x4 (vmid 0) + hfence.gvma <other va>,x0
  PHASE  2, 0x100003000          # warm DTLB (result page) under allStage
  PHASE  3, 0xC0030000           # warm DTLB (in-range page) under allStage
  PHASE  4, 0x140008000          # control: T2 never translated -> cold allStage walk
  PHASE  5, 0x80000000           # stage-1 page fault -> pte_valid=1/pageFault=1
  PHASE  6, 0x140000000          # POSITIVE: T via alias, right after V=0 walk
  PHASE  7, 0x140000000          # POSITIVE repeat
  CMD    8, 2                    # hfence.gvma x0,x0 (full)
  PHASE  9, 0x140000000          # is the alias still there after full hfence?
  PHASE 10, 0x80000000           # stage-1 page fault again
  PHASE 11, 0x140000000          # POSITIVE #2
  PHASE 12, 0x40000000           # sanity: 1GB leaf -> GPA 2^41 (full walk)
  DONE  13

# ---------------------------------------------------------------- M trap
  .align 2
m_trap:
  csrr  s5, mcause
  la    s1, rep_m
  jal   ra, puts_
  mv    a0, s5
  jal   ra, puthex_
  la    s1, rep_nl
  jal   ra, puts_
1:
  j     1b

# ---------------------------------------------------------------- HS trap
  .align 2
hs_trap:
  li    t6, 0x80003900
  sd    t0, 0(t6)
  sd    t1, 8(t6)
  sd    t2, 16(t6)
  sd    t3, 24(t6)
  sd    t4, 32(t6)
  sd    t5, 40(t6)
  sd    a0, 48(t6)
  sd    a1, 56(t6)
  sd    s2, 64(t6)
  sd    s3, 72(t6)

  li    t0, 0x80003000
  ld    t1, 0(t0)
  li    t2, 40
  mul   t1, t1, t2
  addi  t1, t1, 0x100
  add   t1, t1, t0
  csrr  t2, scause
  sd    t2, 0(t1)
  csrr  t3, stval
  sd    t3, 8(t1)
  csrr  t4, htval
  sd    t4, 16(t1)

  li    t3, 10                   # ecall from VS ?
  bne   t2, t3, 3f
  ld    t3, 8(t0)                # command word
  li    t4, 1
  beq   t3, t4, 1f
  li    t4, 2
  beq   t3, t4, 2f
  li    t4, 9
  beq   t3, t4, hs_report
  j     3f
1:                               # cmd 1: hgatp=Sv39x4, targeted hfence.gvma
  li    t3, 0x8000000000080050
  csrw  hgatp, t3
  li    t3, 0x1000               # different VA -> target alias survives
  hfence.gvma t3, zero
  j     3f
2:                               # cmd 2: full hfence.gvma
  hfence.gvma x0, x0
  j     3f
3:
  csrr  t3, sepc
  addi  t3, t3, 4
  csrw  sepc, t3

  li    t6, 0x80003900
  ld    t0, 0(t6)
  ld    t1, 8(t6)
  ld    t2, 16(t6)
  ld    t3, 24(t6)
  ld    t4, 32(t6)
  ld    t5, 40(t6)
  ld    a0, 48(t6)
  ld    a1, 56(t6)
  ld    s2, 64(t6)
  ld    s3, 72(t6)
  sret

# ---------------------------------------------------------------- report
hs_report:
  li    sp, 0x80010000
  li    s3, 0
  li    s4, 14
1:
  li    t0, 40
  mul   t0, s3, t0
  li    t1, 0x80003000
  addi  t0, t0, 0x100
  add   t0, t0, t1
  mv    s5, t0

  la    s1, rep_p
  jal   ra, puts_
  mv    a0, s3
  jal   ra, puthex_
  la    s1, rep_c
  jal   ra, puts_
  ld    a0, 0(s5)
  jal   ra, puthex_
  la    s1, rep_t
  jal   ra, puts_
  ld    a0, 8(s5)
  jal   ra, puthex_
  la    s1, rep_h
  jal   ra, puts_
  ld    a0, 16(s5)
  jal   ra, puthex_
  la    s1, rep_d
  jal   ra, puts_
  ld    a0, 24(s5)
  jal   ra, puthex_
  la    s1, rep_k
  jal   ra, puts_
  ld    a0, 32(s5)
  jal   ra, puthex_
  la    s1, rep_nl
  jal   ra, puts_
  addi  s3, s3, 1
  blt   s3, s4, 1b

  la    s1, rep_done
  jal   ra, puts_
2:
  j     2b

# ---------------------------------------------------------------- helpers
putc_:
  li    t5, UART_BASE
1:
  lbu   t4, 0x14(t5)
  andi  t4, t4, 0x20
  beqz  t4, 1b
  sb    t6, 0(t5)
  ret

puts_:
  addi  sp, sp, -16
  sd    ra, 0(sp)
1:
  lbu   t6, 0(s1)
  beqz  t6, 2f
  jal   ra, putc_
  addi  s1, s1, 1
  j     1b
2:
  ld    ra, 0(sp)
  addi  sp, sp, 16
  ret

puthex_:
  addi  sp, sp, -16
  sd    ra, 0(sp)
  mv    a1, a0
  li    a2, 60
1:
  srl   a3, a1, a2
  andi  a3, a3, 0xf
  li    a4, 10
  bltu  a3, a4, 2f
  addi  t6, a3, 87
  j     3f
2:
  addi  t6, a3, 48
3:
  jal   ra, putc_
  addi  a2, a2, -4
  bge   a2, x0, 1b
  ld    ra, 0(sp)
  addi  sp, sp, 16
  ret

# ---------------------------------------------------------------- rodata
.section .rodata
banner:
  .asciz "MM007F1B START\n"
rep_p:
  .asciz "P"
rep_c:
  .asciz " C="
rep_t:
  .asciz " T="
rep_h:
  .asciz " H="
rep_d:
  .asciz " D="
rep_k:
  .asciz " K="
rep_m:
  .asciz "MTRAP="
rep_nl:
  .asciz "\n"
rep_done:
  .asciz "MM007F1B DONE\n"

# ---------------------------------------------------------------- payload
.section .magic, "aw"
  .quad 0xDEAD000012345678
  .quad 0x5555AAAA5555AAAA

.section .inrange, "aw"
  .quad 0x1111222233334444
  .quad 0x777788889999AAAA

# ---------------------------------------------------------------- G-stage
.section .groot, "aw"
  .quad 0x0000000020015001      # [0]    -> l1 @ 0x80054000 (GPA 0)
  .quad 0
  .quad 0x0000000020015401      # [2]    -> l1 @ 0x80055000 (GPA 0x80000000)
  .rept 1021
  .quad 0
  .endr
  .quad 0x0000000020015801      # [1024] -> l1 @ 0x80056000 (GPA[41:30] = 1024)
  .rept 1023
  .quad 0
  .endr

.section .gl1_0, "aw"
  .quad 0x0000000020016001      # -> l0 @ 0x80058000
  .rept 511
  .quad 0
  .endr

.section .gl1_2, "aw"
  .quad 0x00000000200000DF      # 2MB leaf: GPA 0x80000000 -> PA 0x80000000
  .rept 511
  .quad 0
  .endr

.section .gl1_1024, "aw"
  .quad 0x0000000020015C01      # -> l0 @ 0x80057000
  .rept 511
  .quad 0
  .endr

.section .gl0_1024, "aw"
  .quad 0x00000000200080DF      # 4KB leaf -> PA 0x80020000 (magic page)
  .quad 0x00000000200080DF
  .rept 510
  .quad 0
  .endr

.section .gl0_0, "aw"
  .quad 0x00000000200080DF
  .rept 511
  .quad 0
  .endr

# ---------------------------------------------------------------- VS-stage
.section .vsroot, "aw"
  .quad 0
  .quad 0x00000080000000CF      # [1] VA 0x40000000 -> GPA 2^41 (fuel for the sanity walk)
  .quad 0                       # [2] VA 0x80000000 -> stage-1 page fault
  .quad 0x00000000200000CF      # [3] VA 0xC0000000 -> GPA 0x80000000
  .quad 0x00000000200000CF      # [4] VA 0x1_00000000 -> GPA 0x80000000
  .quad 0x0000000020018401      # [5] VA 0x1_40000000 -> l1 @ 0x80061000
  .rept 506
  .quad 0
  .endr

.section .vsl1, "aw"
  .quad 0x0000000020018801      # [0] -> l0 @ 0x80062000
  .rept 511
  .quad 0
  .endr

.section .vsl0, "aw"
  .quad 0x00000080000000CF      # [0] 4KB leaf PPN=2^29 -> GPA 2^41 (T)
  .rept 7
  .quad 0
  .endr
  .quad 0x00000080000000CF      # [8] 4KB leaf PPN=2^29 -> GPA 2^41 (T2, other set)
  .rept 503
  .quad 0
  .endr
