#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
PREFIX=${CROSS_COMPILE:-riscv64-unknown-linux-gnu-}
mkdir -p "$HERE/build"
for name in mm007f1b mm007f1; do
  "${PREFIX}gcc" -x assembler -march=rv64imac_zicsr_zifencei_h -mabi=lp64 -nostdlib -ffreestanding -fno-pic -fno-builtin -c -o "$HERE/build/$name.o" "$HERE/src/$name.S"
  "${PREFIX}ld" -T "$HERE/src/link.ld" -o "$HERE/build/$name.elf" "$HERE/build/$name.o"
  "${PREFIX}objcopy" -O binary "$HERE/build/$name.elf" "$HERE/build/$name.bin"
  "${PREFIX}objdump" -d "$HERE/build/$name.elf" > "$HERE/build/$name.dis"
  sha256sum "$HERE/build/$name.bin" "$HERE/bin/$name.bin"
  if ! cmp -s "$HERE/build/$name.bin" "$HERE/bin/$name.bin"; then
    printf 'Rebuilt %s differs from the archived image; check toolchain and layout before comparing results.\n' "$name" >&2
    exit 1
  fi
done
