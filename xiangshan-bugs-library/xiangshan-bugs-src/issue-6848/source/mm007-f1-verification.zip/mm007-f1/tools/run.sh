#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
: "${EMU:?Set EMU to the intended emulator path}"
mode=${1:-}
case "$mode" in
  nodiff) args=(--no-diff) ;;
  diff) : "${NEMU:?Set NEMU to the intended reference shared object}"; args=("--diff=$NEMU") ;;
  *) printf 'Usage: EMU=/path/to/emu [NEMU=/path/to/ref.so] bash tools/run.sh nodiff|diff\n' >&2; exit 2 ;;
esac
mkdir -p "$HERE/reruns"
out=$(mktemp -d "$HERE/reruns/${mode}.XXXXXX")
cmd=("$EMU" "--image=$HERE/bin/mm007f1b.bin" "${args[@]}" --max-cycles=300000)
if command -v systemd-run >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
  launcher=(systemd-run --user --scope -q -p MemoryMax=100G -p MemorySwapMax=0 -p RuntimeMaxSec=1800 --)
else
  launcher=(timeout 1800)
fi
printf '%q ' "${launcher[@]}" "${cmd[@]}" > "$out/command.txt"
printf '\n' >> "$out/command.txt"
set +e
"${launcher[@]}" "${cmd[@]}" > "$out/emu.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out/exit_code.txt"
printf 'Run directory: %s\nExit status: %s\n' "$out" "$rc"
exit "$rc"
