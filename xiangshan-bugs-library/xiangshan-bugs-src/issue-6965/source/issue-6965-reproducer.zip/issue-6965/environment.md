- Hardware
  - CPU: 2 × AMD EPYC 7543 32-Core Processor (128 hardware threads total)
  - Memory: approximately 247 GiB
  - Storage: approximately 3.6 TiB filesystem capacity
- Software
  - Operating system: Ubuntu 26.04.1 LTS (x86_64)
  - gcc version: gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
  - clang version used for the emulator: Ubuntu clang 21.1.8 (6ubuntu1), confirmed from the emulator's ELF compiler information
  - RISC-V compiler: riscv64-unknown-elf-gcc (14.2.0+19) 14.2.0
  - Java: OpenJDK 21.0.13.0.3
  - Mill: 0.12.3
  - Verilator: 5.038
- Repo
  - XiangShan commit: `7a1bbc60873e61307c0c8cbe7c7242392f9c07bb` (`kunminghu-v2`)
  - DiffTest submodule: `3729300ae233816d332d057f170472ebe35147b0`
  - NEMU reference: bundled `riscv64-nemu-interpreter-so` from the `ready-to-run` submodule at `c5a45bc861b64db88e7048a62f6ed350c75639cf`; the NEMU source commit is not recorded separately in the available provenance
  - SPIKE: not used
  - Local source changes: CSR/uarch coverage instrumentation; the exact recorded XiangShan and DiffTest patches are included in the archive
- Build & Run
  - Configuration: `DefaultConfig`, one core, VLEN=128; AXI (`EnableCHI=false`)
  - Emulator SHA-256: `072820a6065816db80c9f6a8104eeecbbf25883a8ff64d7752c7b53847c682ad`
  - NEMU reference SHA-256: `f0c3361bb8f3e186ad55567918a7e8b93c28341366e02ba354229e825cfb8d0f`

Recorded emulator build command (after applying the supplied instrumentation patches):

```bash
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export NOOP_HOME="$PWD"
make emu CONFIG=DefaultConfig CC=clang CXX=clang++ -j60 \
  SIM_ARGS='--csr-state-cover --uarch-state-cover' \
  PGO_CFLAGS=-fPIE PGO_LDFLAGS=-pie EMU_COMPILE_FILTER=-j60
```
