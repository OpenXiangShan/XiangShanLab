.option norvc
.section .text.init
.globl _start
_start:
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x1f
    csrw pmpcfg0, t0          # PMP open (allow)
    csrw medeleg, x0
    la t0, trap_handler
    csrw mtvec, t0
    li t0, 0x20000400
    csrw pmpaddr0, t0         # TOR upper = 0x80010000, covers all of this code
    li t0, 0xe3ab             # pmp0: L=1, A=TOR, R=W=1, X=0
    csrw pmpcfg0, t0          # lock no-exec over the code; next fetch must fault
    nop                       # fetch here is from the locked no-exec region
    nop
    .4byte 0x0000006b
1:  j 1b
trap_handler:
    .4byte 0x0000006b
2:  j 2b
