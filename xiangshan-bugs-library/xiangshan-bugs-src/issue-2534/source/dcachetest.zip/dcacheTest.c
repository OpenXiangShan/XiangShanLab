#include <stdio.h>
#include <stdint.h> 
#include <string.h>
#include <unistd.h>
#include <klib.h>

int j=0;
char __attribute__((aligned(4096))) buffer[4 * 1024 * 1024];
char __attribute__((aligned(4096))) address[4096];
#define C_VAL 2
#define D_VAL 1
#define S_VAL 10
static void evict(void *addr) {
  size_t start =
      (((size_t)(buffer) >> 14) << 14) + 0x4000 + ((size_t)addr & 0x3fff);
#define S 14
  for (int s = 0; s < S_VAL; s += 1) {
    for (int d = 0; d < D_VAL; d++) {
      for (int c = 0; c < C_VAL; c++) {
        maccess((void *)(start + ((s + c) << S)));
      }
    }
  }
}


int main(void)
{
    memset(address, 1, 4096);
  memset(buffer, 2, sizeof(buffer));
    uint64_t   start=0, end=0, diff=0;
    printf("data cache test \n");

   for(int i=0; i<5; i++)
    {  

        evict(address);
	asm volatile("csrr %0, mcycle" : "=r"(start));
	maccess(address);
	asm volatile("csrr %0, mcycle" : "=r"(end));
        diff = end - start;
        printf("iteration=%d, read from ram, cycles = %lu\n", i, diff);   
        maccess(address);
	asm volatile("csrr %0, mcycle" : "=r"(start));
	maccess(address);
        asm volatile("csrr %0, mcycle" : "=r"(end));
        diff = end - start;
	printf("iteration=%d, read from data cache, cycles = %lu\n", i, diff);   
        evict(address);
	asm volatile("csrr %0, mcycle" : "=r"(start));
        maccess(address);
        asm volatile("csrr %0, mcycle" : "=r"(end));
        diff = end - start;
	printf("iteration=%d, flush and then read from ram, cycles = %lu\n", i, diff); 
	asm volatile("csrr %0, mcycle" : "=r"(start));
        maccess(address);
        asm volatile("csrr %0, mcycle" : "=r"(end));
        diff = end - start;
	printf("iteration=%d, read from data cache after flush, cycles = %lu\n\n", i, diff);          
    }
    return 0;
}
