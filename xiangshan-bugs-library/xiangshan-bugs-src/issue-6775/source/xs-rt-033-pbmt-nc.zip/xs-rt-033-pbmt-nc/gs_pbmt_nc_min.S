.option norvc
.option norelax

.section .text.init
.globl _start
_start:
  la    t0, trap_handler
  csrw  mtvec, t0
  csrw  satp, zero
  csrw  vsatp, zero

  li    t0, -1
  csrw  pmpaddr0, t0
  li    t0, 0x1f
  csrw  pmpcfg0, t0

  la    t6, nc_data
  li    t5, 0x1111222233334444
  sd    t5, 0(t6)

  # G-stage root[0] -> L1, GPA 0x20000000 -> L0.
  la    t0, g_root
  la    t1, g_l1
  srli  t2, t1, 12
  slli  t2, t2, 10
  ori   t2, t2, 1
  sd    t2, 0(t0)

  la    t0, g_l1
  li    t3, 0x100
  slli  t3, t3, 3
  add   t0, t0, t3
  la    t1, g_l0
  srli  t2, t1, 12
  slli  t2, t2, 10
  ori   t2, t2, 1
  sd    t2, 0(t0)

  # G-stage leaf: U|A|D|W|R|V, PBMT=NC, maps to nc_data.
  la    t1, g_l0
  la    t2, nc_data
  srli  t2, t2, 12
  slli  t2, t2, 10
  ori   t2, t2, 0x00d7
  li    t3, 1
  slli  t3, t3, 61
  or    t2, t2, t3
  sd    t2, 0(t1)

  li    t0, 1
  slli  t0, t0, 62
  csrs  0x30a, t0
  la    t0, g_root
  srli  t0, t0, 12
  li    t1, 8
  slli  t1, t1, 60
  or    t0, t0, t1
  csrw  hgatp, t0
  hfence.gvma x0, x0
  sfence.vma  x0, x0
  fence rw, rw

  li    t0, 3
  slli  t0, t0, 11
  csrc  mstatus, t0
  li    t0, 1
  slli  t0, t0, 11
  csrs  mstatus, t0
  li    t0, 1
  slli  t0, t0, 39
  csrs  mstatus, t0

  li    t4, 0x20000000
  li    t0, 1
  slli  t0, t0, 17
  csrs  mstatus, t0
  ld    s2, 0(t4)
  li    t0, 1
  slli  t0, t0, 17
  csrc  mstatus, t0

  la    t0, rec_value
  sd    s2, 0(t0)
  la    t0, trap_count
  ld    t1, 0(t0)
  bnez  t1, bad
  li    t0, 0x1111222233334444
  bne   s2, t0, bad

  li    a1, 'P'
  jal   ra, putc
  j     report
bad:
  li    a1, 'F'
  jal   ra, putc
report:
  li    a1, ' '
  jal   ra, putc
  la    t0, rec_value
  ld    a2, 0(t0)
  jal   ra, print_hex
  li    a1, ' '
  jal   ra, putc
  la    t0, trap_count
  ld    a2, 0(t0)
  jal   ra, print_hex
  li    a1, ' '
  jal   ra, putc
  la    t0, trap_cause
  ld    a2, 0(t0)
  jal   ra, print_hex
  li    a1, 10
  jal   ra, putc

  li    a0, 0
  .word 0x0000006b

.balign 4
trap_handler:
  csrr  s0, mcause
  la    s1, trap_cause
  sd    s0, 0(s1)
  csrr  s0, mtval
  la    s1, trap_tval
  sd    s0, 0(s1)
  csrr  s0, mepc
  la    s1, trap_epc
  sd    s0, 0(s1)
  addi  s0, s0, 4
  csrw  mepc, s0
  la    s1, trap_count
  ld    s0, 0(s1)
  addi  s0, s0, 1
  sd    s0, 0(s1)
  li    s0, 1
  slli  s0, s0, 17
  csrc  mstatus, s0
  li    s0, 1
  slli  s0, s0, 39
  csrc  mstatus, s0
  mret

putc:
  li    t0, 0x310b0000
  sb    a1, 0(t0)
1:
  lbu   t1, 0x14(t0)
  andi  t1, t1, 0x20
  beqz  t1, 1b
  ret

print_hex:
  li    t2, 16
  li    t3, 0x310b0000
1:
  srli  t4, a2, 60
  li    t5, 10
  blt   t4, t5, 2f
  addi  t4, t4, 0x57
  j     3f
2:
  addi  t4, t4, 0x30
3:
  sb    t4, 0(t3)
4:
  lbu   t5, 0x14(t3)
  andi  t5, t5, 0x20
  beqz  t5, 4b
  slli  a2, a2, 4
  addi  t2, t2, -1
  bnez  t2, 1b
  ret

.section .data
.balign 8
trap_count:
  .dword 0
trap_cause:
  .dword 0
trap_epc:
  .dword 0
trap_tval:
  .dword 0
rec_value:
  .dword 0

.balign 16384
g_root:
  .zero 16384
.balign 4096
g_l1:
  .zero 4096
.balign 4096
g_l0:
  .zero 4096
.balign 4096
nc_data:
  .zero 4096
