# PBMT=NC guest load returns zero because NC replay reuses a stale TLB physical address

### Before start

- [x] I have read the RISC-V ISA Manual and the XiangShan documents, and I believe this is a XiangShan RTL issue.
- [x] I have searched previous issues and PRs and did not find an open report of this exact failure. The nearest reports are #6060 (CBO store access fault on PBMT=NC), #6094 (NC request parallelism), #6683 (PMA non-cacheable DRAM issued as CHI Device), #6393 (PBMT.NC instruction-fetch exception PC), #6521 (preserve exceptions on NC load return), #4704 (NCMM difftest skip), #3504 (PBMT priority), and #6082 (HFENCE.GVMA VS PageCache flush). None uses a stale TLB PADDR during NC replay.
- [x] I have reproduced the issue on the clean Hunt V2 release `v2-a4eeaabb-6a1cdd2e8eb1` (source `a4eeaabb4c12349259094a8b55f3ba1c03a9d993`). Two runs in GitLab pipeline 993 both reproduced the same signature. Not rechecked against a newer default-branch tip.
- [x] This report was prepared with AI assistance. The assertion, image hash, source anchors, and failure signature were checked against the farm evidence and two fresh runs of the attached image.

### Branch

kunminghu-v2

Hunt release `v2-a4eeaabb-6a1cdd2e8eb1`, source `a4eeaabb4c12349259094a8b55f3ba1c03a9d993` (clean, Commit SHA `a4eeaabb4c`). The failure was also reproduced locally on the same source with the aligned V2 emu/NEMU.

### Describe the bug

A guest load through a G-stage leaf whose PTE has `PBMT=NC` returns zero instead of the value stored at the translated physical address. NC changes only cacheability; it must not change the address or the returned data.

`gs_pbmt_nc_min.S` sets up the failing access in M-mode:

1. Build a G-stage page table mapping GPA `0x20000000` to the physical page containing `nc_data`.
2. Set the leaf PTE flags to `U|A|D|W|R|V` and `PBMT=NC` (`PBMT=1`).
3. Set `hgatp`, `satp=0`, `vsatp=0`, and `MPRV=1 + MPP=S + MPV=1`, so the following load is performed as a guest access.
4. Store `0x1111222233334444` to `nc_data`, then execute `ld s2, 0(t4)` with `t4 = 0x20000000`.

Expected: `s2 = 0x1111222233334444`.

Actual: the DUT returns zero. With difftest enabled:

```
s2 different at pc = 0xfffe80dcd178bd42, right = 0x1111222233334444, wrong = 0x0000000000000000
Core 0: ABORT at pc = 0xfffe80dcd178bd42
```

The same image under `--no-diff` prints the program's own failure line:

```
F 0000000000000000 0000000000000000 0000000000000000
HIT GOOD TRAP at pc = 0x800001e8
```

The control run proves that fetch, page-table setup, and the UART path execute. The architectural data is wrong only on the NC load path. NEMU returns the expected value, so this is a DUT disagreement, not a reference-model failure.

### Expected behavior

For a guest load through a G-stage leaf with `PBMT=NC`, the load must return the data at the translated physical address. The NC replay path must preserve the PADDR carried by the NC request; it must not replace it with a stale TLB response from a different access.

After the fix, the same image should print:

```
P 1111222233334444 0000000000000000 0000000000000000
HIT GOOD TRAP
```

and difftest should complete without `s2 different`.

The failure is silent: no guest exception is raised, so the guest observes a corrupted value and may make incorrect control-flow or data decisions.

### Environment

- Published Hunt V2 Verilator emu, not rebuilt for this report. emu sha256 `aa6823b15aa71b43df193ef493071340336f1fef64dcecb043772f6a5a52e880`.
- Hunt V2 NEMU sha256 `9a55ad96f49309d6b3620cd0632cce87cec62651b9e43c686cdf8f4aaf9f447e`.
- Workload toolchain: riscv64-unknown-linux-gnu-gcc (GCC) 12.0.1 20220505 (prerelease), `-march=rv64gcv -mabi=lp64d`; GNU objcopy 2.38.
- Image `case.bin` sha256 `5add227676ad6a5ad8ae2568e104a2467e3e32af791e4ffe6df5fea034032e20`.
- Source `gs_pbmt_nc_min.S` sha256 `f14f9dd0e18bb2daaea76053f136079ef360fa2a372d8673c53cb54a2fbf0496`.
- Linker script `link.ld` sha256 `d88f07d13f5ff39e307e272ed23143957f1c84fa9444ad7a2fe420565aba1384`.
- Farm evidence: run `run-20261026-161337-d595d2`, finding `bug-d7c19202ec`, key `rtl-loadunit-nc-replay-stale-paddr`.
- Hunt case: `XS-RT-033`, validation `b48b5496-68cf-47f9-892b-e5abd5daea19`, GitLab pipeline 993. Two runs with Seed=0 both reproduced.

### To Reproduce

`link.ld` places `.text.init` at `0x80000000`. `gs_pbmt_nc_min.S` is self-contained and uses the UART at `0x310b0000` for its report.

```
riscv64-unknown-linux-gnu-gcc -nostdlib -nostartfiles -static -fno-pic -fno-pie -no-pie \
  -mcmodel=medany -march=rv64gcv -mabi=lp64d -Wl,--build-id=none \
  -T link.ld gs_pbmt_nc_min.S -o case.elf
riscv64-unknown-linux-gnu-objcopy -O binary case.elf case.bin

./build/emu -b 0 -e 0 -s 0 -i case.bin --max-instr=100000 --no-diff
./build/emu -b 0 -e 0 -s 0 -i case.bin --max-instr=100000 --diff=<V2-release-nemu>
```

`case.bin` in this folder is the image that produced the log above. The difftest run aborts at `s2 different`; the no-diff run prints `F 0000000000000000 ...`.

### Additional context

Not XS-RT-017 (cross-page HLV guest-page fault), XS-RT-018 (address-specific HFENCE.GVMA), or XS-RT-020 (PMA non-cacheable DRAM issued as CHI Device). This case uses a G-stage PTE PBMT attribute, not PMA, and the failing access is an ordinary load, not a CBO, instruction fetch, or fence.

GitHub searches for the exact code identifiers `nc_ldin`, `s1_paddr_dup_lsu`, and `shiftDataToHigh` returned no issues or PRs. #6521 is about preserving bus exceptions on NC load return; this report is about preserving the translated PADDR. #4704 is about difftest synchronization for NCMM, not the returned address.

### Possible cause

Reading of `a4eeaabb4c`, not confirmed by editing the RTL:

- `mem/pipeline/LoadUnit.scala:795-797` selects `io.lsq.nc_ldin.bits.paddr` for the NC source in S0.
- `mem/pipeline/LoadUnit.scala:338-340` includes `nc_idx` in `s0_tlb_no_query`, so this NC replay does not issue a fresh TLB lookup.
- `mem/pipeline/LoadUnit.scala:944` unconditionally captures `io.tlb.resp.bits.paddr(0)` into `s1_paddr_dup_lsu`.
- `mem/pipeline/LoadUnit.scala:1014` assigns `s1_out.paddr := s1_paddr_dup_lsu`, overwriting the PADDR selected for the NC request.
- `mem/pipeline/LoadUnit.scala:1753` calls `shiftDataToHigh(s2_out.paddr, s2_out.data)`, so the NC data is aligned using the stale TLB PADDR and the guest observes zero.

The NC replay path needs to keep the PADDR from `io.lsq.nc_ldin.bits.paddr` (for example, select PADDR by source in S1 or preserve `s1_in.paddr` for NC/fast replay). An assertion that an NC request's S1 PADDR equals `io.lsq.nc_ldin.bits.paddr` would prevent the same regression.
