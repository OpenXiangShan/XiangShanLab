.option norvc
.include "xs_print.inc"

.section .text.init
.globl _start
_start:
    la      sp, xs_stack_top
    la      t0, trap_handler
    csrw    mtvec, t0

    li      s0, 0x40070000

    li      t1, 0x1
    sw      t1, 0x00(s0)
    li      t1, 0x2
    sw      t1, 0x04(s0)
    li      t1, 0x12345678
    sw      t1, 0x10(s0)

    li      t2, 0
    .rept 1600
    addi    t2, t2, -1
    .endr

    lw      s1, 0x00(s0)
    lw      s2, 0x04(s0)
    lw      s3, 0x10(s0)
    ld      s4, 0x00(s0)

    PRINT_STR m_tag
    PRINT_HEX s1
    PRINT_HEX s2
    PRINT_HEX s3
    PRINT_HEX s4

    li      t1, 0xaaaa5555
    sw      t1, 0x00(s0)
    li      t2, 0
    .rept 1400
    addi    t2, t2, -1
    .endr
    lwu     s5, 0x10(s0)
    lwu     s8, 0x04(s0)
    PRINT_HEX s5
    PRINT_HEX s8

    li      t0, 0x1
    bne     s1, t0, fail
    li      t0, 0x2
    bne     s2, t0, fail
    li      t0, 0x12345678
    bne     s3, t0, fail
    li      t0, 0x2
    slli    t0, t0, 32
    addi    t0, t0, 1
    bne     s4, t0, fail
    li      t0, 0x12345678
    bne     s5, t0, fail
    li      t0, 0x2
    bne     s8, t0, fail
    PRINT_STR m_pass
    j       done
fail:
    PRINT_STR m_fail
done:
    li      a0, 0
    .word   0x0000006b

    .balign 256
trap_handler:
    csrr    s6, mcause
    csrr    s7, mepc
    PRINT_STR m_trap
    PRINT_HEX s6
    PRINT_HEX s7
    addi    s7, s7, 4
    csrw    mepc, s7
    mret

.section .data
m_tag:  .asciz "B1054E2C\n"
m_pass: .asciz "SELFCHECK PASS\n"
m_fail: .asciz "SELFCHECK FAIL\n"
m_trap: .asciz "TRAP\n"

.section .bss
.balign 16
xs_stack:
    .zero 4096
xs_stack_top:
