
OUTPUT_ARCH(riscv)
ENTRY(_start)

SECTIONS {
  . = 0x80000000;
  .text : {
    *(.text.init)
    *(.text)
    *(.text*)
  }
  . = ALIGN(0x10);
  .data : {
    *(.data)
    *(.data*)
    *(.sdata*)
    *(.sdata2*)
    *(.region_0*)
    *(.mem_region*)
    *(.tohost*)
    *(.fromhost*)
  }
  . = ALIGN(0x10);
  .bss : {
    *(.bss)
    *(.bss*)
    *(.sbss*)
    *(.sbss2*)
  }
  . = ALIGN(0x10);
  .riscv.attributes : { *(.riscv.attributes) }
  
  . = 0x80010000;
  .pmp_probe : { *(.pmp_probe) }
  
  . = 0x80020000;
  .pagetable : { *(.pagetable) }
  /DISCARD/ : { *(.comment) *(.note*) }
}
