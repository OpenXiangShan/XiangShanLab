.macro PRINT_STR lbl
    la a0, \lbl
    call xs_print_str
.endm

.macro PRINT_HEX reg
    mv t0, \reg
    call xs_print_hex
.endm

.section .text
xs_print_str:
    li t1, 0x40600000
1:  lbu t2, 0(a0)
    beqz t2, 3f
2:  lw t3, 8(t1)
    andi t3, t3, 8
    bnez t3, 2b
    sb t2, 4(t1)
    addi a0, a0, 1
    j 1b
3:  ret

xs_print_hex:
    mv a3, t0
    la a0, xs_pbuf
    li t2, 60
    li t3, 16
1:  srl t4, a3, t2
    andi t4, t4, 0xf
    li t5, 10
    blt t4, t5, 2f
    addi t4, t4, 87
    j 3f
2:  addi t4, t4, 48
3:  sb t4, 0(a0)
    addi a0, a0, 1
    addi t2, t2, -4
    addi t3, t3, -1
    bnez t3, 1b
    li t4, 10
    sb t4, 0(a0)
    sb x0, 1(a0)
    la a0, xs_pbuf
    j xs_print_str

.section .data
.align 4
xs_pbuf: .zero 32
