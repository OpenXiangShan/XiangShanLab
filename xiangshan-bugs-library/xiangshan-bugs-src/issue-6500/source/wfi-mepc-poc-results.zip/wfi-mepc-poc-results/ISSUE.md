# Title

[Bug] Interrupt that wakes a WFI is not taken on the following instruction when that instruction is a load/store/CSR/fence: it executes first, mepc != WFI+4

# Before start

- [x] I have read the RISC-V ISA Manual and XiangShan Documents, and I believe this is a XiangShan RTL issue.
- [x] I have searched previous issues and PRs and did not find anything relevant.
- [x] I have reproduced the issue using the latest commit on the default branch.
- [x] If this report was generated with AI assistance, I have verified the correctness of its content.

# Branch

kunminghu-v2 (same logic on kunminghu-v3)

# Describe the bug

When a `wfi` at the ROB head is woken by an enabled interrupt, the ROB only clears `hasWFI` (`Rob.scala`, `when(RegNext(RegNext(io.csr.wfiEvent)) ...) hasWFI := false.B`) and lets commit continue. The interrupt itself is taken through the normal path, which requires the head entry to be interrupt-safe:

```scala
// Rob.scala (2e148b4 L575 / L1157-1167; v2 HEAD 5d393413 L575 / L1157-1167; v3 HEAD 14af5521 L608 / L1174-1187)
val intrEnable = intrBitSetReg && !hasWaitForward && deqPtrEntry.interrupt_safe && !deqHasFlushed
...
val allow_interrupts = !CommitType.isLoadStore(...) && !FuType.isFence(...) && !FuType.isCsr(...) &&
                       !FuType.isVset(...) && !FuType.isAMO(...)
robEntries(...).interrupt_safe := allow_interrupts
```

So if the instruction right after `wfi` is a load, store, CSR access, fence, vset or AMO, it is committed (and its side effects happen) before the interrupt is taken on the first interrupt-safe instruction after it. `mepc` then points past the intervening instruction(s), and the intervening instructions have executed *before* the interrupt handler.

Spec (`machine.adoc`, 3.3.3 WFI, `norm:wfi_mepc_val`): "If an enabled interrupt is present or later becomes present while the hart is stalled, the interrupt trap will be taken on the following instruction, i.e., execution resumes in the trap handler and `mepc` = `pc` + 4." The NOTE explains the intent: the following instruction takes the trap so that returning from the handler executes the code after WFI — i.e. the code after WFI observes the handler's effects. Resuming "for any reason" is permitted, but when an enabled interrupt *is* present the trap must be on the following instruction.

Spike takes pending interrupts at the start of every instruction step (`execute.cc:248 take_pending_interrupt()`), so after a `wfi` the trap is always on the next instruction with `epc = wfi + 4`, whatever that instruction is.

# Expected behavior

`wfi ; ld a0, flag ; ...` with a timer interrupt arriving during the WFI: trap taken with `mepc = &ld`, the handler runs (and e.g. sets `flag`), then the `ld` executes and sees the updated `flag`.

Actual (XiangShan): `ld` commits first and reads the *old* `flag`; the trap is taken on the following instruction, `mepc = &ld + 2` (compressed `ld`) — see the measured table. Same for `sd` (+6), `csrr` (+8), `fence` (+8), and three consecutive `ld` (+10).

Consequence for software: any "wait for event" loop of the form `do { wfi } while (!flag)` where `flag` is set by the ISR reads the stale value, goes back to `wfi`, and — for a one-shot event — sleeps until some unrelated interrupt arrives. Patterns like `wfi ; csrc mie, ...` / `wfi ; csrc mstatus, MIE` mask the source before the handler ever runs, so the interrupt is silently deferred.

# Environment

- XiangShan branch: kunminghu-v2, commit `2e148b4` (2026-03-16, v3.2.2-alpha-1084-g2e148b41d), DefaultConfig (`--issue E.b`). Cited lines checked unchanged on kunminghu-v2 HEAD `5d393413` (2026-09-02) and kunminghu-v3 HEAD `14af5521` (2026-09-05).
- NEMU `67da68a2` (ready-to-run e79a631), Spike `611a62b7` (ready-to-run) / upstream `3e7bf30d` for the semantics above; difftest `7b5fc3bb2`, utility `fcb82239`. (difftest does not compare the interrupt take-point, so it does not flag this.)

# To Reproduce

Attached `csr-misc-poc` (nexus-am, M-mode); section **[C]** is the relevant one (sections [A]/[B] test other things). For each trial it arms CLINT `mtimecmp = mtime + delay`, enables `mie.MTIE`, executes `wfi ; <insn> ; 8×nop`, and the M-mode handler records `mepc`/`mcause` and sets a flag in memory; `<insn>` varies over the interrupt-safe and non-interrupt-safe classes, and the `ld` variant loads that flag.

```
make ARCH=riscv64-xs
./build/emu -i csr-misc-poc-riscv64-xs.bin --no-diff
```

Output (2e148b4):

```
[C] wfi;nop    delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+4   OK: mepc = wfi+4
[C] wfi;ld     delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+6   ld-after-wfi read flag=0 (stale: load ran before handler)  VIOLATION
[C] wfi;sd     delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+6   VIOLATION
[C] wfi;csrr   delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+8   VIOLATION
[C] wfi;fence  delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+8   VIOLATION
[C] wfi;ld x3  delay= 4..64  traps=1 cause=0x8000000000000007  mepc-wfi=+10  ld-after-wfi read flag=0 (stale)  VIOLATION
```

(Offsets are byte offsets from the `wfi`: `ld`/`sd` here are 2-byte compressed, so +6 = the instruction after the `ld`; `csrr`/`fence` are 4 bytes, +8 likewise; three `ld` → +10.) The `nop` control (interrupt-safe) always gives `mepc = wfi + 4`, for every delay, so timing of the interrupt is not the factor — only the class of the following instruction is.

Minimal sequence (M-mode, timer armed to fire shortly):

```
csrs mie, MTIE
wfi
ld   a0, 0(a1)      # a1 -> flag written by the handler
nop                 # <- XiangShan takes the interrupt here (mepc = this nop), a0 = old flag
```

# Additional context

Suggested fix: when the WFI is resumed by an interrupt (`wfiEvent` caused by a pending enabled interrupt), take the interrupt immediately at the WFI's commit with `mepc = pc_wfi + 4` (i.e. WFI completes, then the trap is entered before the next instruction can commit), or mark the entry following a WFI as interrupt-safe for that purpose. The generic `interrupt_safe = false` protection for loads/stores (MMIO already sent) is not needed here because nothing after the WFI has been issued while the WFI blocks commit.

Files: `backend/rob/Rob.scala` (`hasWFI`, `intrEnable`, `interrupt_safe`).
