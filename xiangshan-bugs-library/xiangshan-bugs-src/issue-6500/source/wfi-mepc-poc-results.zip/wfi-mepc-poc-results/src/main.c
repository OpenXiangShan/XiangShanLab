#include <klib.h>

// =============================================================================
// Quick dynamic checks for three detector candidates (M-mode, XiangShan emu)
//
//  [A] 0002/0855/1309  mstatus.MPP / mnstatus.MNPP written with reserved 0b10
//                      -> must NOT become 2 (WARL). Expect: value unchanged.
//  [B] 0398            csrw minstret, X ; csrr -> spec (norm:mcycle_minstret_wr,
//                      "Any CSR write takes effect after the writing instruction
//                      has otherwise completed") says the read must return X.
//  [C] 0568            wfi ; <insn> : interrupt that wakes the WFI must be taken
//                      on the instruction *immediately following* WFI
//                      (norm:wfi_mepc_val, mepc = pc_wfi + 4). We vary <insn>
//                      between interrupt-safe (nop) and not-interrupt-safe in
//                      XiangShan's ROB (ld / sd / csrr / fence) and also check
//                      whether the load after WFI observes the handler's write.
// =============================================================================

#define S_(x) #x
#define S(x) S_(x)
#define CSRR(csr) ({ unsigned long __v; asm volatile("csrr %0, " S(csr) : "=r"(__v) : : "memory"); __v; })
#define CSRW(csr, v) asm volatile("csrw " S(csr) ", %0" : : "r"(v) : "memory")
#define CSRS(csr, v) asm volatile("csrs " S(csr) ", %0" : : "r"(v) : "memory")
#define CSRC(csr, v) asm volatile("csrc " S(csr) ", %0" : : "r"(v) : "memory")

#define CSR_MSTATUS       0x300
#define CSR_MIE           0x304
#define CSR_MTVEC         0x305
#define CSR_MCOUNTINHIBIT 0x320
#define CSR_MSCRATCH      0x340
#define CSR_MIP           0x344
#define CSR_MNSTATUS      0x744
#define CSR_MINSTRET      0xb02

#define MSTATUS_MIE  (1UL << 3)
#define MIE_MTIE     (1UL << 7)
#define MPP_SHIFT    11
#define MPP_MASK     (3UL << MPP_SHIFT)

#define CLINT_BASE   0x38000000UL
#define MTIME        (*(volatile unsigned long *)(CLINT_BASE + 0xbff8))
#define MTIMECMP     (*(volatile unsigned long *)(CLINT_BASE + 0x4000))

// ---------------------------------------------------------------------------
// [A] MPP / MNPP WARL
// ---------------------------------------------------------------------------
static int test_mpp(void)
{
    int bad = 0;
    unsigned long ms = CSRR(CSR_MSTATUS);
    for (int want = 0; want < 4; want++) {
        unsigned long w = (ms & ~MPP_MASK) | ((unsigned long)want << MPP_SHIFT);
        CSRW(CSR_MSTATUS, w);
        unsigned long got = (CSRR(CSR_MSTATUS) & MPP_MASK) >> MPP_SHIFT;
        printf("[A] mstatus.MPP  write %d -> read %lu%s\n", want, got,
               (want == 2) ? (got == 2 ? "   <-- reserved value stored (BUG)" : "   (write ignored, WARL ok)") : "");
        if (want == 2 && got == 2) bad = 1;
    }
    CSRW(CSR_MSTATUS, ms);

    unsigned long mn = CSRR(CSR_MNSTATUS);
    for (int want = 0; want < 4; want++) {
        unsigned long w = (mn & ~MPP_MASK) | ((unsigned long)want << MPP_SHIFT);
        CSRW(CSR_MNSTATUS, w);
        unsigned long got = (CSRR(CSR_MNSTATUS) & MPP_MASK) >> MPP_SHIFT;
        printf("[A] mnstatus.MNPP write %d -> read %lu%s\n", want, got,
               (want == 2) ? (got == 2 ? "   <-- reserved value stored (BUG)" : "   (write ignored, WARL ok)") : "");
        if (want == 2 && got == 2) bad = 1;
    }
    CSRW(CSR_MNSTATUS, mn);
    return bad;
}

// ---------------------------------------------------------------------------
// [B] minstret write / read-back
// ---------------------------------------------------------------------------
static int test_minstret(void)
{
    int bad = 0;
    unsigned long x = 0x1000, r0, r1, r2, r3;

    asm volatile("csrw minstret, %1\n\t"
                 "csrr %0, minstret\n\t" : "=r"(r0) : "r"(x) : "memory");
    asm volatile("csrw minstret, %1\n\t"
                 "nop\n\t"
                 "csrr %0, minstret\n\t" : "=r"(r1) : "r"(x) : "memory");
    asm volatile("csrw minstret, %1\n\t"
                 "nop\n\t" "nop\n\t" "nop\n\t"
                 "csrr %0, minstret\n\t" : "=r"(r2) : "r"(x) : "memory");
    CSRS(CSR_MCOUNTINHIBIT, 4);          // IR=1: no increments at all
    asm volatile("csrw minstret, %1\n\t"
                 "csrr %0, minstret\n\t" : "=r"(r3) : "r"(x) : "memory");
    CSRC(CSR_MCOUNTINHIBIT, 4);

    printf("[B] csrw minstret,0x%lx ; csrr            -> 0x%lx (X%+ld)   spec: X\n", x, r0, (long)(r0 - x));
    printf("[B] csrw minstret,0x%lx ; nop ; csrr      -> 0x%lx (X%+ld)   spec: X+1\n", x, r1, (long)(r1 - x));
    printf("[B] csrw minstret,0x%lx ; 3x nop ; csrr   -> 0x%lx (X%+ld)   spec: X+3\n", x, r2, (long)(r2 - x));
    printf("[B] IR=1: csrw minstret,0x%lx ; csrr      -> 0x%lx (X%+ld)   spec: X\n", x, r3, (long)(r3 - x));
    if (r0 != x) { printf("[B] -> writing instruction itself was counted on top of the written value (BUG)\n"); bad = 1; }
    if (r1 != x + 1 || r2 != x + 3) bad |= 2;
    return bad;
}

// ---------------------------------------------------------------------------
// [C] WFI + mepc
// ---------------------------------------------------------------------------
// save area: [0] t1 [1] t2 [2] mepc [3] mcause [4] flag [5] trap count
static volatile unsigned long sa[8] __attribute__((aligned(64)));

asm(
    ".section .text\n"
    ".align 4\n"
    ".global m_trap_entry\n"
    "m_trap_entry:\n"
    "  csrrw t0, mscratch, t0\n"        // t0 = &sa, mscratch = saved t0
    "  sd    t1, 0(t0)\n"
    "  sd    t2, 8(t0)\n"
    "  csrr  t1, mepc\n"
    "  sd    t1, 16(t0)\n"
    "  csrr  t1, mcause\n"
    "  sd    t1, 24(t0)\n"
    "  li    t1, 1\n"
    "  sd    t1, 32(t0)\n"              // flag := 1 (handler ran)
    "  ld    t1, 40(t0)\n"
    "  addi  t1, t1, 1\n"
    "  sd    t1, 40(t0)\n"
    "  li    t1, 0x80\n"
    "  csrc  mie, t1\n"                 // MTIE := 0 so we do not re-trap
    "  ld    t1, 0(t0)\n"
    "  ld    t2, 8(t0)\n"
    "  csrrw t0, mscratch, t0\n"
    "  mret\n"
);
extern void m_trap_entry(void);

struct wfi_res { long off; unsigned long cause; unsigned long flag_seen; unsigned long ntrap; };

#define WFI_TRIAL(name, INSNS)                                                           \
static struct wfi_res name(unsigned long delay)                                          \
{                                                                                        \
    struct wfi_res r;                                                                    \
    unsigned long v = 0xdead, wfi_pc, spill;                                             \
    sa[2] = 0; sa[3] = 0; sa[4] = 0; sa[5] = 0;                                          \
    MTIMECMP = MTIME + delay;                                                            \
    asm volatile(                                                                        \
        "csrs mie, %[mtie]\n\t"                                                          \
        "1: wfi\n\t"                                                                     \
        INSNS                                                                            \
        "nop\n\t" "nop\n\t" "nop\n\t" "nop\n\t" "nop\n\t" "nop\n\t" "nop\n\t" "nop\n\t"  \
        "la %[w], 1b\n\t"                                                                \
        : [v] "+&r"(v), [w] "=&r"(wfi_pc), [sp2] "=&r"(spill)                            \
        : [sa] "r"(sa), [mtie] "r"(MIE_MTIE)                                             \
        : "memory");                                                                     \
    CSRC(CSR_MIE, MIE_MTIE);                                                             \
    MTIMECMP = ~0UL;                                                                     \
    r.off = (long)(sa[2] - wfi_pc); r.cause = sa[3]; r.flag_seen = v; r.ntrap = sa[5];    \
    (void)spill;                                                                         \
    return r;                                                                            \
}

// <insn> after the WFI:
WFI_TRIAL(trial_nop,   "nop\n\t")                                        // interrupt_safe = 1
WFI_TRIAL(trial_ld,    "ld %[v], 32(%[sa])\n\t")                         // load  (interrupt_safe = 0) reads flag
WFI_TRIAL(trial_sd,    "sd %[v], 48(%[sa])\n\t")                         // store (interrupt_safe = 0)
WFI_TRIAL(trial_csrr,  "csrr %[sp2], mscratch\n\t")                      // CSR   (interrupt_safe = 0)
WFI_TRIAL(trial_fence, "fence\n\t")                                      // fence (interrupt_safe = 0)
WFI_TRIAL(trial_ld3,   "ld %[v], 32(%[sa])\n\t" "ld %[sp2], 32(%[sa])\n\t" "ld %[sp2], 32(%[sa])\n\t")

static int run_wfi(const char *name, struct wfi_res (*fn)(unsigned long), long expect_off_xs, int is_ld)
{
    int bad = 0;
    // sweep the timer delay so the interrupt arrives while the hart is stalled in WFI
    unsigned long delays[] = { 4, 8, 16, 32, 64 };
    for (unsigned i = 0; i < sizeof(delays) / sizeof(delays[0]); i++) {
        struct wfi_res r = fn(delays[i]);
        const char *verdict;
        if (r.ntrap != 1)            verdict = "no/multiple trap";
        else if (r.off < 0)          verdict = "fired before WFI (increase delay)";
        else if (r.off == 0)         verdict = "taken on the WFI itself";
        else if (r.off == 4)         verdict = "OK: mepc = wfi+4";
        else                         verdict = "VIOLATION: mepc != wfi+4";
        printf("[C] wfi;%-6s delay=%2lu  traps=%lu cause=0x%lx  mepc-wfi=%+ld%s%s  %s\n",
               name, delays[i], r.ntrap, r.cause, r.off,
               is_ld ? "  ld-after-wfi read flag=" : "",
               is_ld ? (r.flag_seen ? "1" : "0 (stale: load ran before handler)") : "",
               verdict);
        if (r.ntrap == 1 && r.off > 4) bad = 1;
        if (r.ntrap == 1 && r.off > 0 && r.off != 4 && r.off != expect_off_xs) bad |= 4;
    }
    return bad;
}

int main(void)
{
    printf("=== csr-misc-poc: MPP/MNPP WARL, minstret write, WFI mepc ===\n");
    int bad_a = test_mpp();
    int bad_b = test_minstret();

    // WFI setup: own M-mode trap vector, MIE=1, timer interrupt only
    CSRW(CSR_MSCRATCH, (unsigned long)sa);
    CSRW(CSR_MTVEC, (unsigned long)m_trap_entry);
    CSRW(CSR_MIE, 0);
    MTIMECMP = ~0UL;
    CSRS(CSR_MSTATUS, MSTATUS_MIE);
    printf("[C] mtime=%lu mie=%lx mip=%lx mstatus=%lx\n", MTIME, CSRR(CSR_MIE), CSRR(CSR_MIP), CSRR(CSR_MSTATUS));

    int bad_c = 0;
    bad_c |= run_wfi("nop",   trial_nop,   4,  0);
    bad_c |= run_wfi("ld",    trial_ld,    8,  1);
    bad_c |= run_wfi("sd",    trial_sd,    8,  0);
    bad_c |= run_wfi("csrr",  trial_csrr,  8,  0);
    bad_c |= run_wfi("fence", trial_fence, 8,  0);
    bad_c |= run_wfi("ld x3", trial_ld3,   16, 1);
    CSRC(CSR_MSTATUS, MSTATUS_MIE);

    printf("=== summary: [A] MPP/MNPP reserved-value stored: %s | [B] minstret write counted on top: %s | [C] WFI mepc != wfi+4: %s ===\n",
           bad_a ? "YES (bug)" : "no", (bad_b & 1) ? "YES (bug)" : "no", (bad_c & 1) ? "YES (bug)" : "no");
    return (bad_a | bad_b | bad_c) ? 1 : 0;
}
