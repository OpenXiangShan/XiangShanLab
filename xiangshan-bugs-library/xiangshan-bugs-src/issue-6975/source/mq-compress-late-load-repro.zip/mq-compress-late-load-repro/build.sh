#!/bin/sh
# Rebuild repro.bin and control.bin (LLVM clang + llvm-objcopy; set LLVM=/path/to/llvm/bin if they are not on PATH).
set -e
B=${LLVM:+$LLVM/}
build() {  # build OUT [-D...]
  out=$1; shift
  ${B}clang --target=riscv64-unknown-elf -march=rv64gc -mabi=lp64d -mno-relax -DCTL_NOBLK -DLBLK -DLM=4 -I . "$@" \
    -c repro.S -o "$out.o"
  ${B}llvm-objcopy -O binary --only-section=.text.init "$out.o" "$out.bin" && rm -f "$out.o"
}
build repro
build control -DCTL_NOST
sha256sum -c SHA256SUMS
