// Reproducer: a load accepted as a MissQueue compress follower after its MSHR's last GrantData beat never wakes up.
// kunminghu-v3, DefaultConfig.  Flat binary loaded at 0x80000000, M-mode, no paging.  Build (LLVM):
//   clang --target=riscv64-unknown-elf -march=rv64gc -mabi=lp64d -mno-relax -DCTL_NOBLK -DLBLK -DLM=4 -I . \
//         -c repro.S -o x.o && llvm-objcopy -O binary --only-section=.text.init x.o x.bin
//   (add -DCTL_NOST for the control).  attempts.inc holds one line: ATTEMPT 0, 38, 21 (attempt 0, N = 38, K = 21).
//
// One attempt (B = cold line, B' = B^0x14000 is in the same DCache set):
//   S1:  sd B+0                 store miss -> MSHR e is allocated for B
//   N dependent addi            delay the next stores
//   S2:  sd B+8                 its sbuffer write to MainPipe (E2) reaches MissQueue port 0 after e's last beat and
//                               merges into e (stores may merge until the refill is written)
//   L':  ld B'+16  [LM addi]    cold load in B's set: its refill holds MainPipe for that set, which delays E2 and e's
//                               refill request by a few cycles
//   L:   ld B+32   [N + K addi] reaches MissQueue (load port) in the same cycle as E2 -> compress follower of E2,
//                               handled = 1, id = e -> waits in LoadQueueReplay (C_DM) for a beat/hint that has passed
//   add s3, s3, a1; fence; exit.  On correct hardware the program exits with the trap instruction (a0 = 0).
// Variant -DCTL_NOST: no S2.  L is alone at MissQueue, is not merged (handled = 0), replays and hits: the program exits.
// Other -D options in this file (CTL_COVER, CTL_LATE, store blocker without -DLBLK) are not needed here.

#define CSR_SPFCTL     0x5c1
#define CSR_SMBLOCKCTL 0x5c3
#define CSR_SRNCTL     0x5c4
#define BASE   0x80400000
#define STEP   0x8040            // 32 KiB + 64 B: every attempt its own cold line, a new L1 set each time
#ifdef CTL_NOBLK
#define E3XOR  0x4000            // another L1 set
#else
#define E3XOR  0x14000           // same hashed L1 set as B (bits 14 and 16 cancel), different block
#endif
#define PXOR   0x1000            // another set
#define QUIET  16
#ifdef CTL_COVER
#define LOFF 0
#else
#define LOFF 32
#endif
#ifdef CTL_LATE
#define KEXTRA 400
#else
#define KEXTRA 0
#endif

.macro EXIT code
  li a0, \code
  .insn r 0x6b, 0, 0, x0, a0, x0
1:
  j 1b
.endm

.macro ATTEMPT j, n, k
attempt_\j:
  fence rw, rw
  li s0, BASE + \j * STEP
  li s1, (BASE + \j * STEP) ^ E3XOR
  li s4, (BASE + \j * STEP) ^ PXOR
  sd zero, 16(s1)
  sd zero, 16(s4)
  fence rw, rw
  .rept QUIET
  nop
  .endr
  li t1, 0x5a5a5a5a
  sd t1, 0(s0)
  li t2, 0
  .rept \n
  addi t2, t2, 1
  .endr
  srli t3, t2, 63                  // = 0, depends on the chain (not a zero idiom like andi/sub)
  add t0, s4, t3
  sd t1, 16(t0)
  add t4, s1, t3
  sd t1, 16(t4)
#ifndef CTL_NOST
  add t5, s0, t3
  sd t1, 8(t5)
#endif
#ifdef LBLK
  li a3, (BASE + \j * STEP) ^ 0x14000   // B' = B^0x14000: same hashed L1 set as B, never written (cold)
  li a4, 0
  .rept LM
  addi a4, a4, 1
  .endr
  srli a4, a4, 63
  add a3, a3, a4
  ld a5, 16(a3)                          // L': load miss -> MSHR e'; e''s refill in MainPipe s0..s3 is the blocker
#endif
  srli t6, t2, 63
  .rept \k + KEXTRA
  addi t6, t6, 1
  .endr
  srli t6, t6, 63
  add a2, s0, t6
attempt_\j\()_L:
  ld a1, LOFF(a2)
  add s3, s3, a1
.endm

  .section .text.init
  .option norvc
  .globl _start
_start:
  lla t0, m_trap
  csrw mtvec, t0
  li t0, -1
  csrw pmpaddr0, t0
  li t0, 0x1f
  csrw pmpcfg0, t0
  csrwi CSR_SPFCTL, 0              // every L1D / L2 / L1I prefetcher off (CSRCustom.scala SpfctlBundle)
  csrci CSR_SRNCTL, 1              // FUSION_ENABLE = 0: keep the addi chains one cycle per instruction
  csrr t0, CSR_SMBLOCKCTL
  li t1, 0x3ff
  and t0, t0, t1                   // keep bits 9:0 (misalign, uncache, error, softpf, ldld, threshold)
  li t1, (1 << 10)
  or t0, t0, t1                    // SBUFFER_TIMEOUT = 1: an sbuffer line is evicted right after it is written
  csrw CSR_SMBLOCKCTL, t0
  li s3, 0
#include "attempts.inc"
  fence rw, rw
exit_ok:
  EXIT 0

  .align 2
m_trap:
exit_trap:
  csrr a1, mcause
  csrr a2, mepc
  EXIT 1
