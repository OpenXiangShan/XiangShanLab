# MissQueue: compress lets a load merge after the GrantData has arrived, load waits forever in LoadQueueReplay

kunminghu-v3 (tested on 8b15f0652), DefaultConfig, single core, default memory model (no DRAMsim3). Flat binaries,
loaded at 0x80000000.

| File | Content |
|---|---|
| `repro.S`, `attempts.inc` | Source of both images (comments at the top describe the flow) |
| `repro.bin` | Store and load to the same line reach MissQueue in the same cycle, after the line's GrantData has arrived |
| `control.bin` | Same program without that store (`-DCTL_NOST`) |
| `build.sh` | Rebuilds both images with LLVM and checks them against `SHA256SUMS` |

Run:

```bash
./build/emu -i repro.bin   --no-diff -C 12000   # EXCEEDING CYCLE/INSTR LIMIT, instrCnt = 126 (same at -C 200000)
./build/emu -i control.bin --no-diff -C 12000   # HIT GOOD TRAP after about 8590 cycles
```

On correct hardware both images end with HIT GOOD TRAP. The case needs one-cycle alignment; with DRAMsim3 memory
timing these images do not align.
