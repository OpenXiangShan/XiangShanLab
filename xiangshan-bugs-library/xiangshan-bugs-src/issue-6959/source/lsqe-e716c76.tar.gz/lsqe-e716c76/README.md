# How to run

Images for XiangShan emu (`-i`), kunminghu-v3 `e716c76582`, DefaultConfig, 1 core. The emu used for these results is sha256 `3bab894900786e010866ab7c2d05ed6dfa86b868600b9d4455226156439f949c`. Difftest uses CI `riscv64-nemu-interpreter-so`, sha256 `9188e7dda30709962f0bfbc1dd87cea73d88a18c92c30892f93ed529c22def43`.

```
./build/emu -i bin/X.bin --no-diff -C 40000
./build/emu -i bin/X.bin --diff ready-to-run/riscv64-nemu-interpreter-so -C 40000
```

Each program exits with `.word 0x6b`. With `--no-diff`, emu prints `HIT GOOD TRAP` for every `a0`, so read the exit PC. Difftest reports a register mismatch on the failing images.

| Image | `--no-diff` exit PC | Difftest |
|---|---|---|
| `fence_sq_fresh_pf.bin` | `0x80000104` (`a0` = 1, old instruction) | `a0` different, right = 1, wrong = 0 |
| `fence_sq_fresh_pf_fencew.bin` | `0x80000102` (`a0` = 0) | pass |
| `fence_sq_fresh_pf_count.bin` | `0x80000164` (`a0` = 19, 9/16) | |
| `fence_sq_fresh_count.bin` | `0x800000c6` (`a0` = 0) | |
| `fence_sq_fresh_pf_fencew_count.bin` | `0x8000011c` (`a0` = 0) | |
| `sfence_sq_pf_s_first.bin` | `0x80000b1c` (old translation) | `a2` different, right = `0xb001`, wrong = `0xa001` |
| `sfence_sq_pf_fencew_s.bin` | `0x8000020c` (0/16) | pass |
| `sfence_sq_s.bin` | `0x800001ac` (0/16) | |
| `sfence_sq_pf_s.bin` | `0x80000424` (`a0` = 700, 4/16) | |
