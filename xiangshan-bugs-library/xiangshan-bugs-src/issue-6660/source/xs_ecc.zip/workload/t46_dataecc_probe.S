# EXPECT: 0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0,0,0,0,0,0,0,0
# NCHECK: 8
  .include "common_xs.S"
  .text
  .globl test
test:
  li s1, 0x80300000              # A
  li t0, 0xaaaaaaaaaaaaaaaa
  sd t0, 0(s1)
  fence
  li s3, 0x38022000              # L1D ctrl unit
  li t0, 0xff
  li t1, 32
  addi t2, s3, 0x18              # data masks: one 64-bit register per bank, from 0x18
1:
  sd t0, 0(t2)
  addi t2, t2, 8
  addi t1, t1, -1
  bnez t1, 1b
  li t0, 0xffffffffb             # ese=1, persist=1, comp=data, all banks
  sd t0, 0(s3)
  fence
  ld s4, 0(s1)                   # load A: with data injection active the returned data should be corrupted
  ld t1, 0(s3)
  sd zero, 0(s3)
  fence
  sd s4, 0(a3)
  sd t1, 8(a3)
  ret
  .data
  .align 4
old_vd: .space 16
src1:   .space 16
src2:   .space 16
result: .space 16
  .data
  .align 4
expected: .byte 0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0,0,0,0,0,0,0,0
ncheck: .byte 8
