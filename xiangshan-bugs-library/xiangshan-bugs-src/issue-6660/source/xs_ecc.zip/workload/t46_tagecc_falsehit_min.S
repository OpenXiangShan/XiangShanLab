# EXPECT: 0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0,0,0,0,0,0,0,0
# NCHECK: 8
  .include "common_xs.S"
  .text
  .globl test
test:
  li s1, 0x80300000              # A
  li s2, 0x80300000 + 0x1000     # B: same set when the index is vaddr[11:6] (MinimalConfig); tag differs in bit 0
  li t0, 0xaaaaaaaaaaaaaaaa
  sd t0, 0(s1)                   # A: dirty in L1D (L2 keeps the zero copy from the allocation)
  li t0, 0xbbbbbbbbbbbbbbbb
  sd t0, 0(s2)
  fence                          # drain the store buffer into L1D
  cbo.flush (s2)                 # B written back and evicted: cache holds only A
  fence
  li s3, 0x38022000              # L1D ctrl unit: ctrl @0, delay @8, tagMask @0x10
  li t0, 1
  sd t0, 0x10(s3)                # tag mask (bits of the physical tag = paddr[47:12])
  li t0, 0xffffffff3             # ese=1, persist=1, comp=tag, all 32 banks (bits 35:4)
  sd t0, 0(s3)
  fence
  ld s4, 0(s2)                   # load B: must miss and return bb..; with the bug the flipped tag of A matches
  ld t1, 0(s3)                   # read back ctrl (diagnostic, result[8..15])
  sd zero, 0(s3)                 # disarm
  fence
  sd s4, 0(a3)
  sd t1, 8(a3)
  ret
  .data
  .align 4
old_vd: .space 16
src1:   .space 16
src2:   .space 16
result: .space 16
  .data
  .align 4
expected: .byte 0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0xbb,0,0,0,0,0,0,0,0
ncheck: .byte 8
