# 波形缺口：模块级 `hardwareError` 注入

本包没有架构级波形。

原因：

- 缺陷是 `AtomicsUnit` 内部 `exceptionVec[19]` 的状态残留。
- 触发条件是 TileLink DCache 响应的 `tl_corrupt=1`。该响应由模块级 harness 注入，不是程序能产生的访存。
- Spike/QEMU 不模拟该注入，也没有可对照的架构轨迹。
- 全核波形无法稳定注入 `tl_corrupt`；本次没有全核注入模型。

替代证据：

- `run/run.log` 同时记录原版与修复版的 op A/op B 写回值。
- `tb_atomics.cpp` 是确定性的定向 harness；op B 的 DCache 请求数为 0。
- `AtomicsUnit_fixed.sv` 与 `make_fixed.py` 给出唯一的状态清零改动。
- `CODE-EVIDENCE.md` 给出 `exceptionVec` 的写入/清除路径。

该缺口不影响“残留位存在”与“清零修复有效”的结论。它限制的是全核异常优先级组合的覆盖。
