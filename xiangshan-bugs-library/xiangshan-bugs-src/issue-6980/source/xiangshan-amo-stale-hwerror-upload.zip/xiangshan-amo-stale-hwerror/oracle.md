# 独立模型对照：固定 `hardwareError` 的 RTL 变体

## Spike：不适用

`hardwareError` 由 TileLink 响应的 `tl_corrupt` 位触发。Spike 和 QEMU 不模拟 XiangShan 的 `AtomicsUnit` 状态机，也不接受外部注入的 TileLink 损坏响应。把该用例交给 Spike 不能观察 `exceptionVec[19]`。

因此本包不使用 Spike 首陷阱作为 oracle。

## 采用的差分 oracle

| 目标 | 结果 | 记录 |
| --- | --- | --- |
| 原版生成 RTL（`c4cfd2b78`） | op B `bit6=1 bit19=1` | `run/run.log` |
| 修复 RTL（`resetFSM()` 清 `exceptionVec`） | op B `bit6=1 bit19=0` | `run/run.log`、`run/local-run.log` |

修复 RTL 只插入一处状态清零：

```systemverilog
if (_GEN_16 | _GEN_14 & ~_io_in_ready_T_1)
  exceptionVec_19 <= 1'h0;
```

`_GEN_16` 是 `s_finish2` 的写回 fire。`_GEN_14` 是第一次写回 fire。`_io_in_ready_T_1` 标识 AMOCAS.Q（它继续到 `s_finish2`）。该条件等价于在 `resetFSM()` 完成时清 `hardwareError`，同时保留 AMOCAS.Q 第二次写回期间的值。

## 程序自身的期望

`tb_atomics.cpp` 在操作 A 后检查 `bit19=1`，在操作 B 后检查：

```cpp
if (!b.b6) fail("op B missing storeAddrMisaligned bit6");
if (b.b19 != kExpectStale)
  fail(std::string("op B bit19 mismatch, expected ") + (kExpectStale ? "1" : "0"));
```

原版 `kExpectStale=true`，修复版 `kExpectStale=false`。两个版本都要求操作 B 的 DCache 请求数为 0。这确认操作 B 确实走了早退路径。

## 备注

- 这是模块级验证，不是全核验证。它证明 `AtomicsUnit` 的状态清除缺陷，不证明所有全核异常优先级组合。
- 原版 `AtomicsUnit.sv` 不在包内。`run.sh` 从用户提供的生成 RTL 重建原版和修复版。
- Issue 附件 `atomics_stale_hwerr_repro.zip` 提供原版和修复版可执行文件。
