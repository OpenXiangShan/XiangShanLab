xiangshan xiangshan-amo-stale-hwerror reproducer
====================================================================================================================================================

Issue: [BUG] `AtomicsUnit` retains a stale `hardwareError` bit from a previous AMO and reports it on a misaligned atomic that never accessed corrupted data

Files: 10

Files
-----

AtomicsUnit_fixed.sv
    Fixed RTL variant (exceptionVec cleared in resetFSM).
    SHA-256: 2d7e81f47d9b1e44a919b10e17aa2a2e610e136e6cf8e1742e366d83a156decd

comparison.json
    Sanitized DUT-versus-reference comparison record.
    SHA-256: 239b2b03286a6347145493ed0ee4addeef53f6ee10f59a87066fe10872703ffe

difftest_stub.sv
    Stub for the missing LR/SC event sink.
    SHA-256: 0ad7f0f721de39c166a2b00ef8d1587270e434d1bd5833bf4781f41f8294d84d

make_fixed.py
    Script that inserts the exceptionVec[19] clear into the generated RTL.
    SHA-256: c73fdd066871d26cd31a2370210a7e82fb8476f149413ec2dda787ae9f230a9e

oracle.md
    Reference-model (Spike) result, renamed from ORACLE.md.
    SHA-256: af9dbd8436d79810842a5d233584d4f38e5c7d7c467af89dc09c8a5e8e0cb0c8

run.log
    Module run log for both the original and the fixed RTL.
    SHA-256: 1e4f981b5e7b7d5871921c1e716d6459f0b68f0c3c7143016cec8ff66b4e9531

run.sh
    Build/run script for the original and fixed RTL variants.
    SHA-256: 7921cc7744b2ee6fb492361d6fe344e71eec4c0d266c3260d6b38b0e172cec9d

tb_atomics.cpp
    Directed C++ harness that drives the module.
    SHA-256: e7ce4a4b96d776ae03029f3b29b3a259cdcf7cbd69afe5695ebb59138c4bed41

waveform-note.md
    Why no architectural waveform exists for this module-level case.
    SHA-256: 2b7b626ef96d9600b90d4e369d17bd86fabc926e59fe5a7fbee0fdcc2e466c7d

Reproduction summary
--------------------

- Build the harness against the generated `AtomicsUnit.sv` at the affected commit (`run.sh` takes the generated file as its argument), or run the prebuilt original and fixed executables from the issue attachment.
- Run operation A: `amoswap.d` to `0x1000`, with the DCache response driven as `tl_corrupt = 1`, `tl_denied = 0`. Observe the writeback `bit6 = 0`, `bit19 = 1`.
- Run operation B: `amoswap.d` to `0x2003`. Confirm the operation issues zero DCache requests and observe the writeback `bit6 = 1`, `bit19 = 1`.
- Run the same harness against the fixed RTL variant, in which `resetFSM()` clears `exceptionVec`. Observe operation B's writeback `bit6 = 1`, `bit19 = 0`.

Expected:
  Operation B's exception vector contains only its own `storeAddrMisaligned` bit:

  - operation A writeback: `bit6 = 0`, `bit19 = 1`
  - operation B writeback: `bit6 = 1`, `bit19 = 0`
  - operation B issues zero DCache requests in both variants

Observed:
  The original RTL carries the stale bit onto operation B:

  - operation A, cycle 13: writeback `bit6 = 0`, `bit19 = 1`
  - operation B, cycle 17: writeback `bit6 = 1`, `bit19 = 1`; DCache requests issued by operation B: 0
  - the same harness against the fixed RTL: operation B writeback `bit6 = 1`, `bit19 = 0`
  - the run log records both variants: `PASS[original]: opA bit19=1; opB bit6=1 bit19=1; opB dcache requests=0` and `PASS[fixed]: opA bit19=1; opB bit6=1 bit19=0; opB dcache requests=0`

Notes
-----

- This is a module-level RTL harness reproducer: no architectural ELF or waveform is included. run.log records both the original and the fixed RTL variants.
- The original generated AtomicsUnit.sv is not redistributed; run.sh rebuilds it from a user-supplied file generated at the affected commit.
- Full run manifests, code-evidence markdown, waveform analysis JSON, symbol tables, and raw memory images are omitted because their headers contain internal paths.
- Absolute paths in the remaining text files have been replaced by file names.
