xiangshan widening-int reproducer
=================================

Issue: [BUG] Widening integer multiply and multiply-accumulate read the 2*LMUL source incorrectly

Files
-----

prog.elf
    Reproducer ELF.
    SHA-256: c5c5b72e9954cdb82cd58b96135f4b19bfaa94715dec508db60aeb2191710176

prog.c
    Reproducer source.
    SHA-256: a7f5c2a48c119f191c0e6d5b6f4103c7e1d87ea32a2c438f9fb5d6b0a4bf3db5

disassembly.txt
    Full objdump of prog.elf.
    SHA-256: 84ba2dcc5cb0dab379a101ca9528f093003d91e0aa545885aaf6bf774e97ba53

sim.log
    Difftest log of the failing run.
    SHA-256: 05823a646ca6e5ce59786e22fdab8d14fb4b964a6e6fd6946cc916b64f08698b

README.txt
    This file (not hashed; self-reference).
    SHA-256: not applicable

Archive entries: 5 (4 payload files plus this README.txt)

Reproduction summary
--------------------

- Build the bare-metal image from `prog.c` with `-march=rv64gcv_zicsr_zifencei_zvbb_zvkb -mabi=lp64 -mcmodel=medany -O2 -static -no-pie`.
- The program configures SEW=8, LMUL=m1, fills both 2*LMUL source groups (`v1`/`v2` and their upper registers), and executes `vwmul.vv` at the probe.
- Run the image on the DUT with difftest enabled and RAM size 128 MB.
- Run the same ELF on the Spike difftest reference and compare the 2*LMUL destination group.

Expected:
  For the `vwmul.vv` SEW=8 operands, `v5_low` and `v5_high` must be `0x0000000000000000`.

Observed:
  The DUT leaves the upper destination half at all ones:
  
  ```text
   v5_low  different at pc = 0xfffe10d5004db516, right = 0x0000000000000000, wrong = 0xffffffffffffffff
  v5_high different at pc = 0xfffe10d5004db516, right = 0x0000000000000000, wrong = 0xffffffffffffffff
  Core 0: ABORT at pc = 0xfffe10d5004db516
  ```

Notes
-----

- This bundle was produced from a difftest-only run; no waveform was captured.
- Full run manifests, code-evidence notes, and raw logs containing internal paths are omitted.
- Absolute paths in the remaining text files have been replaced by file names.
