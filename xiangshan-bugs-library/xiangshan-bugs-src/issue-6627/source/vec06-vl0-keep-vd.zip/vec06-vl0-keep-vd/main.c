#include <klib.h>
#include <stdint.h>

/*
 * VEC-06: live MergeUnit agnosticMask includes Fill(vlenb,vta)&tailMask.
 * vl=0 ⇒ whole-register tail; vta=1 writes 0xFF over old vd.
 * Setup uses vle, never vmv.v.x.
 */

#define MSTATUS_VS (3UL << 9)
#define MSTATUS_FS (3UL << 13)

int main(void) {
  uint64_t mstatus, vl;
  uint8_t oldm[16], a[16], b[16], out[16];
  int i;

  printf("vec06-vl0-keep-vd start\n");
  asm volatile("csrr %0, mstatus" : "=r"(mstatus));
  mstatus |= MSTATUS_VS | MSTATUS_FS;
  asm volatile("csrw mstatus, %0" :: "r"(mstatus) : "memory");

  for (i = 0; i < 16; i++) {
    oldm[i] = 5;
    a[i] = 7;
    b[i] = 9;
  }

  asm volatile("vsetvli %0, %1, e8, m1, ta, mu" : "=r"(vl) : "r"(16UL));
  asm volatile("vle8.v v1, (%0)" :: "r"(oldm) : "memory");
  asm volatile("vle8.v v2, (%0)" :: "r"(a) : "memory");
  asm volatile("vle8.v v3, (%0)" :: "r"(b) : "memory");

  /* vsetvli rd, x0 is VLMAX, not 0. vsetivli uimm=0 is the vl=0 encoding. */
  asm volatile("vsetivli %0, 0, e8, m1, ta, mu" : "=r"(vl));
  asm volatile("vadd.vv v1, v2, v3");
  asm volatile("vse8.v v1, (%0)" :: "r"(out) : "memory");

  printf("vl0=%lu out0=%u out15=%u\n", vl, out[0], out[15]);

  if (vl != 0) {
    printf("FAIL vec06 could not set vl=0\n");
    return 1;
  }
  for (i = 0; i < 16; i++) {
    if (out[i] != 5) {
      printf("FAIL vec06 vl=0 vta=1 overwrote old vd\n");
      return 1;
    }
  }

  printf("vec06-vl0-keep-vd pass\n");
  return 0;
}
