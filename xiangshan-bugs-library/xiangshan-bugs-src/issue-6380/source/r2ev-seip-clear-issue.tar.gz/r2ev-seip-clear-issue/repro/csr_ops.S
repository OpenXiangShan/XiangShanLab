.section .text
.option norvc
.align 4

.globl read_stopi
read_stopi:
  csrr a0, 0xdb0
  ret

.globl read_sip
read_sip:
  csrr a0, sip
  ret

.globl read_mip
read_mip:
  csrr a0, mip
  ret

.globl write_mvip
write_mvip:
  csrw 0x309, a0
  ret

.globl read_mvip
read_mvip:
  csrr a0, 0x309
  ret

.globl write_mvien
write_mvien:
  csrw 0x308, a0
  ret

.globl read_mvien
read_mvien:
  csrr a0, 0x308
  ret

.globl write_mideleg
write_mideleg:
  csrw mideleg, a0
  ret

.globl read_mideleg
read_mideleg:
  csrr a0, mideleg
  ret

.globl write_sie
write_sie:
  csrw sie, a0
  ret

.globl read_sie
read_sie:
  csrr a0, sie
  ret

.globl write_siselect
write_siselect:
  csrw 0x150, a0
  ret

.globl read_siselect
read_siselect:
  csrr a0, 0x150
  ret

.globl write_sireg
write_sireg:
  csrw 0x151, a0
  ret

.globl read_sireg
read_sireg:
  csrr a0, 0x151
  ret

.globl read_sstatus
read_sstatus:
  csrr a0, sstatus
  ret

.globl write_sstatus
write_sstatus:
  csrw sstatus, a0
  ret

.globl read_mstatus
read_mstatus:
  csrr a0, mstatus
  ret

.globl write_mstatus
write_mstatus:
  csrw mstatus, a0
  ret

.globl enter_s_mode
enter_s_mode:
  /* a0 = entry point in S mode; returns via ecall service */
  addi sp, sp, -16
  sd ra, 8(sp)
  csrr t0, mstatus
  li t1, 0x1800
  not t1, t1
  and t0, t0, t1
  li t1, 0x800
  or t0, t0, t1
  csrw mstatus, t0
  csrw mepc, a0
  mret

.globl m_mode_resume
m_mode_resume:
  ld ra, 8(sp)
  addi sp, sp, 16
  ret
