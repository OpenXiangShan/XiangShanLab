.section .text
.option norvc
.align 4

.macro SAVE_FRAME
  addi sp, sp, -256
  sd ra, 8(sp)
  sd t0, 40(sp)
  sd t1, 48(sp)
  sd t2, 56(sp)
  sd a0, 80(sp)
  sd a1, 88(sp)
  sd a2, 96(sp)
.endm

.macro RESTORE_FRAME
  ld ra, 8(sp)
  ld t0, 40(sp)
  ld t1, 48(sp)
  ld t2, 56(sp)
  ld a0, 80(sp)
  ld a1, 88(sp)
  ld a2, 96(sp)
  addi sp, sp, 256
.endm

.globl m_trap_vector
.align 4
m_trap_vector:
  SAVE_FRAME
  csrr a0, mcause
  csrr a1, mepc
  csrr a2, mtval
  csrr a3, mstatus
  call m_trap_adjust
  csrw mepc, a0
  RESTORE_FRAME
  mret

.globl s_trap_vector
.align 4
s_trap_vector:
  SAVE_FRAME
  csrr a0, scause
  csrr a1, sepc
  csrr a2, stval
  call s_trap_adjust
  csrw sepc, a0
  RESTORE_FRAME
  sret
