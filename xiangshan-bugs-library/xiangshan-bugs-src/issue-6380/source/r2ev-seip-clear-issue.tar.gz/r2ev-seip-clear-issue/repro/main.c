/* C010 隔离重生成:(1,0) 注入-清除序列 */
#include <am.h>
#include <klib.h>
#include <stdint.h>
extern void _halt(int);
extern uintptr_t read_stopi(void);
extern uintptr_t read_sip(void);
extern void write_mvip(uintptr_t);
extern uintptr_t read_mvip(void);
extern void write_mvien(uintptr_t);
extern void write_mideleg(uintptr_t);
extern void write_sie(uintptr_t);
extern void write_sstatus(uintptr_t);
extern void enter_s_mode(void (*entry)(void));
extern char m_mode_resume[];

#define BIT9 (1UL<<9)
#define EX_S_ECALL 9UL

static volatile uintptr_t r_sip, r_stopi;
static volatile int g_m_service;
uintptr_t m_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval, uintptr_t status) {
  if (!(cause & (1UL<<63)) && (cause & 0xff) == EX_S_ECALL && g_m_service == 1) {
    g_m_service = 0;
    return (uintptr_t)m_mode_resume;
  }
  return epc + 4;
}
uintptr_t s_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval) { return epc + 4; }

static void s_body(void) {
  write_sie(BIT9);
  write_sstatus(0);
  r_sip = read_sip();
  r_stopi = read_stopi();
  g_m_service = 1;
  asm volatile("ecall");
  for(;;);
}

int main(void) {
  extern void m_trap_vector(void); extern void s_trap_vector(void);
  asm volatile("csrw mtvec, %0" :: "r"(m_trap_vector));
  asm volatile("csrw stvec, %0" :: "r"(s_trap_vector));
  asm volatile("csrw 0x30c, %0" :: "r"((1UL<<59)|(1UL<<60)|(1UL<<58)));
  asm volatile("csrw pmpaddr0, %0" :: "r"(0x3fffffffffffffUL));
  asm volatile("csrw pmpcfg0, %0" :: "r"(0x1fUL));
  printf("=== C010 隔离重生成(注入-清除序列) ===\n");

  /* 阶段1:注入 */
  write_mideleg(BIT9); write_mvien(0); write_mvip(BIT9);
  g_m_service=0;
  enter_s_mode(s_body);
  uintptr_t first_stopi=r_stopi, first_sip=r_sip;
  printf("[SEQ] after inject: stopi=0x%lx sip=0x%lx\n", first_stopi, first_sip);

  /* 阶段2:清除 */
  write_mvip(0);
  printf("[SEQ] after clear mvip: mvip_rb=0x%lx\n", read_mvip());
  g_m_service=0;
  enter_s_mode(s_body);
  uintptr_t second_stopi=r_stopi, second_sip=r_sip;
  printf("[SEQ] after clear: stopi=0x%lx sip=0x%lx\n", second_stopi, second_sip);

  int ok = 1;
  if (!(first_stopi!=0 && ((first_stopi>>16)&0xfff)==9)) { printf("[COV] FEAT001-C010 FAIL first not SEI: 0x%lx\n",first_stopi); ok=0; }
  if (!(second_stopi==0 || ((second_stopi>>16)&0xfff)!=9)) { printf("[COV] FEAT001-C010 FAIL clear not effective: second=0x%lx\n",second_stopi); ok=0; }
  if (ok) printf("[COV] FEAT001-C010 PASS inject->clear seq\n");
  _halt(ok?0:1);
  return 0;
}
