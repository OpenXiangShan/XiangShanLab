/* H1: injected-SEI clear ineffectiveness => S-mode handler livelock probe
 * Setup: mideleg[9]=1, mvien[9]=0, mvip[9]=1 (M injects SEI, delegated to S,
 *        no APLIC/IMSIC SEI pending). sie.SEIE=1, sstatus.SIE=1.
 * Handler: M clears mvip.SEIP (write 0, read back), then sret.
 * If the clear is architecturally effective: no re-trap, main loop survives.
 * If not (the bug): sip.SEIP stays 1 -> immediate re-trap after sret ->
 * main loop starves (livelock); bounded by wall-clock timeout on the host.
 */
#include <am.h>
#include <klib.h>
#include <stdint.h>
extern void _halt(int);
extern uintptr_t read_sip(void);
extern void write_mvip(uintptr_t);
extern uintptr_t read_mvip(void);
extern void write_mvien(uintptr_t);
extern void write_mideleg(uintptr_t);
extern void write_sie(uintptr_t);
extern void write_sstatus(uintptr_t);
extern void enter_s_mode(void (*entry)(void));
extern char m_mode_resume[];

#define BIT9 (1UL<<9)
#define EX_S_ECALL 9UL

static volatile uintptr_t g_count;
static volatile int g_m_service;
static volatile int g_cleared;

uintptr_t m_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval, uintptr_t status) {
  if (!(cause & (1UL<<63)) && (cause & 0xff) == EX_S_ECALL && g_m_service == 1) {
    g_m_service = 0;
    return (uintptr_t)m_mode_resume;
  }
  return epc + 4;
}

uintptr_t s_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval) {
  if (cause & (1UL<<63)) {
    g_count++;
    if (g_count <= 5) {
      uintptr_t sip0 = read_sip();
      printf("[H1] handler entry #%lu: cause=0x%lx sip(before clear)=0x%lx\n",
             (unsigned long)g_count, (unsigned long)cause, (unsigned long)sip0);
      write_mvip(0);
      uintptr_t rb = read_mvip();
      uintptr_t sip1 = read_sip();
      printf("[H1]   M wrote mvip=0: mvip_rb=0x%lx sip(after clear)=0x%lx\n",
             (unsigned long)rb, (unsigned long)sip1);
      if (sip1 == 0) g_cleared = 1;
    }
    if ((g_count % 1000000UL) == 0) {
      printf("[H1] still re-trapping: count=%lu (livelock)\n", (unsigned long)g_count);
      if (g_count >= 3000000UL) {
        printf("[H1] CONFIRMED: clear ineffective, S-mode starved after %lu handler entries\n",
               (unsigned long)g_count);
        _halt(1);
      }
    }
    return epc; /* sret -> SIE=1; if sip.SEIP still 1, immediately re-traps */
  }
  return epc + 4;
}

static void s_body(void) {
  printf("[H1] entered S-mode\n");
  write_sie(BIT9);
  printf("[H1] sie.SEIE=1 done, enabling sstatus.SIE (main may starve from here)\n");
  write_sstatus(0x2); /* sstatus.SIE=1 */
  for (volatile unsigned long i = 0; ; i++) {
    if (g_cleared) {
      printf("[H1] survived: clear effective, main loop running\n");
      _halt(0);
    }
    if ((i & 0xFFFFFUL) == 0) printf("[H1] main alive tick %lu\n", (i >> 20));
  }
}

int main(void) {
  extern void m_trap_vector(void); extern void s_trap_vector(void);
  asm volatile("csrw mtvec, %0" :: "r"(m_trap_vector));
  asm volatile("csrw stvec, %0" :: "r"(s_trap_vector));
  asm volatile("csrw 0x30c, %0" :: "r"((1UL<<59)|(1UL<<60)|(1UL<<58)));
  asm volatile("csrw pmpaddr0, %0" :: "r"(0x3fffffffffffffUL));
  asm volatile("csrw pmpcfg0, %0" :: "r"(0x1fUL));
  printf("=== H1: injected-SEI clear => livelock probe (e12436c7c) ===\n");

  write_mideleg(BIT9); write_mvien(0); write_mvip(BIT9);
  g_m_service = 1;
  enter_s_mode(s_body);
  for(;;);
  return 0;
}
