/* H2 (v2): can S-mode clear the injected SEI by writing sip.SEIP directly?
 * Trap-free variant: sie=0, SIE=0; poll sip, csrc sip.SEIP, re-read.
 * Decisive for the S-side alias write path without the trap storm.
 */
#include <am.h>
#include <klib.h>
#include <stdint.h>
extern void _halt(int);
extern uintptr_t read_sip(void);
extern void write_mvip(uintptr_t);
extern uintptr_t read_mvip(void);
extern void write_mvien(uintptr_t);
extern void write_mideleg(uintptr_t);
extern void write_sie(uintptr_t);
extern void write_sstatus(uintptr_t);
extern void enter_s_mode(void (*entry)(void));
extern char m_mode_resume[];

#define BIT9 (1UL<<9)
#define EX_S_ECALL 9UL

static volatile int g_m_service;

uintptr_t m_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval, uintptr_t status) {
  if (!(cause & (1UL<<63)) && (cause & 0xff) == EX_S_ECALL && g_m_service == 1) {
    g_m_service = 0;
    return (uintptr_t)m_mode_resume;
  }
  return epc + 4;
}

uintptr_t s_trap_adjust(uintptr_t cause, uintptr_t epc, uintptr_t tval) { return epc + 4; }

static void s_body(void) {
  uintptr_t s0 = read_sip();
  printf("[H2v2] entered S-mode: sip(before)=0x%lx\n", (unsigned long)s0);
  asm volatile("csrc sip, %0" :: "r"(BIT9));
  uintptr_t s1 = read_sip();
  printf("[H2v2] csrc sip,0x200 -> sip(after)=0x%lx  => S-side clear %s\n",
         (unsigned long)s1, (s1 == 0) ? "EFFECTIVE" : "INEFFECTIVE");
  /* extra: try explicit csrrw as well */
  asm volatile("csrw sip, %0" :: "r"(0));
  uintptr_t s2 = read_sip();
  printf("[H2v2] csrw sip,0     -> sip(after)=0x%lx\n", (unsigned long)s2);
  _halt((s1 == 0) ? 0 : 1);
}

int main(void) {
  extern void m_trap_vector(void); extern void s_trap_vector(void);
  asm volatile("csrw mtvec, %0" :: "r"(m_trap_vector));
  asm volatile("csrw stvec, %0" :: "r"(s_trap_vector));
  asm volatile("csrw 0x30c, %0" :: "r"((1UL<<59)|(1UL<<60)|(1UL<<58)));
  asm volatile("csrw pmpaddr0, %0" :: "r"(0x3fffffffffffffUL));
  asm volatile("csrw pmpcfg0, %0" :: "r"(0x1fUL));
  printf("=== H2v2: S-side clear via sip.SEIP write, trap-free (e12436c7c) ===\n");

  write_mideleg(BIT9); write_mvien(0); write_mvip(BIT9);
  g_m_service = 1;
  enter_s_mode(s_body);
  for(;;);
  return 0;
}
