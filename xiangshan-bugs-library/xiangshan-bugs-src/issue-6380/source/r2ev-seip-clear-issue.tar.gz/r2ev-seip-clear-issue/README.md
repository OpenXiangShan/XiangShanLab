# Reproduction package: injected SEI cannot be cleared (kunminghu-v2 @ e12436c7c)

DUT: XiangShan kunminghu-v2, commit e12436c7cba86b195deec24981976d78bc263661
(emu built with `make emu`; run below assumes the emu binary is in PATH as `./emu`)

## repro/ — minimal CSR sequence (main evidence)

M-mode injects an SEI (mideleg[9]=1, mvien[9]=0, mvip[9]=1; no APLIC/IMSIC SEI
pending), enters S-mode and reads sip/stopi; back in M-mode it writes mvip=0
(reads back 0), re-enters S-mode and reads sip/stopi again.

Run:

    ./emu -i repro/repro-c010.bin --no-diff

Expected (bug) output:

    [SEQ] after inject: stopi=0x900ff sip=0x200
    [SEQ] after clear mvip: mvip_rb=0x0
    [SEQ] after clear: stopi=0x900ff sip=0x200
    [COV] FEAT001-C010 FAIL clear not effective: second=0x900ff

Source: repro/main.c (+ csr_ops.S, trap.S, Makefile; nexus-am app,
ARCH=riscv64-xs). Binary: repro/repro-c010.bin.

## h1-livelock/ — architectural consequence: S-mode handler livelock

Same injection, then sie.SEIE=1 and sstatus.SIE=1 so the SEI traps to S-mode.
The handler clears mvip.SEIP (M-side write, reads back 0) and sret's. Because
sip.SEIP is still 1, the hart immediately re-enters the handler forever; the
interrupted main loop makes zero progress.

Run (terminate after ~60 s, e.g. `timeout 60`):

    timeout 60 ./emu -i h1-livelock/livelock-h1.bin --no-diff

Observed: handler entries #1..5 each print `mvip_rb=0x0 sip(after
clear)=0x200`, then silence (re-trap loop; handler prints are capped); no
main-loop "alive" ticks ever appear; no GOOD/BAD TRAP — killed by the
wall-clock timeout. See logs/r2ev-h1-livelock-e12436c7c-20260818.log.gz.

## h2v2-sip-write/ — boundary probe: S-side clear path is also broken

Trap-free (sie=0, sstatus.SIE=0). S-mode executes `csrc sip, 0x200` and
`csrw sip, 0`, then re-reads sip.

    ./emu -i h2v2-sip-write/livelock-h2v2.bin --no-diff

Observed:

    [H2v2] entered S-mode: sip(before)=0x200
    [H2v2] csrc sip,0x200 -> sip(after)=0x200  => S-side clear INEFFECTIVE
    [H2v2] csrw sip,0     -> sip(after)=0x200

## logs/

Full emu logs of the three runs above (gunzip to view).

## Notes

- All three programs are nexus-am apps (ARCH=riscv64-xs). h1-livelock/main.c
  and h2v2-sip-write/main.c build with the same Makefile/csr_ops.S/trap.S as
  repro/ (copy them alongside; only NAME in the Makefile matters).
- stopi=0x900ff decodes to IID=9, IPRIO=0xff. The IPRIO value reflects the
  injected-SEI priority-number-256 fix (#6010) present on this commit; this
  report concerns only the clear path.
