.option norelax
.option norvc

.equ TDATA1_TRIG, 0x6000000000000014

.section .text.init, "ax"
_start:
    la      t0, m_trap
    csrw    mtvec, t0
    la      t0, s_trap
    csrw    stvec, t0
    li      t0, -1
    csrw    pmpaddr0, t0
    li      t0, 0x1f
    csrw    pmpcfg0, t0
    li      t0, 0x0
    csrw    medeleg, t0
    csrw    tselect, x0
    la      t0, bp_target
    csrw    tdata2, t0
    li      t0, TDATA1_TRIG
    csrw    tdata1, t0
    li      t0, 0x1800
    csrc    mstatus, t0
    li      t0, 0x0800
    csrs    mstatus, t0
    la      t0, s_entry
    csrw    mepc, t0
    mret
.balign 64
s_entry:
    csrci   sstatus, 2
bp_target:
    addi    x5, x5, 1
    j       after
after:
    j       after

.balign 64
m_trap:
    addi    x7, x7, 1
    j       m_trap
.balign 64
s_trap:
    addi    x8, x8, 1
    j       s_trap
