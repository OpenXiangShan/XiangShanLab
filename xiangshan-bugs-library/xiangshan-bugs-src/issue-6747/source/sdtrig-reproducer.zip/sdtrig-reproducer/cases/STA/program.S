.option norelax
.option norvc

.equ TDATA1_TRIG, 0x6000000000000042

.section .text.init, "ax"
_start:
    la      t0, m_trap
    csrw    mtvec, t0
    la      s2, data_word
    li      s3, 0x55aa55aa55aa55aa
    csrw    tselect, x0
    csrw    tdata2, s2
    li      t0, TDATA1_TRIG
    csrw    tdata1, t0
    csrsi   mstatus, 8
    sd      s3, 0(s2)
    addi    x5, x5, 1
    j       after
after:
    j       after
.balign 64
m_trap:
    addi    x7, x7, 1
    j       m_trap
.balign 64
s_trap:
    addi    x8, x8, 1
    j       s_trap

.section .data
.balign 8
data_word:
    .dword 0x1122334455667788
