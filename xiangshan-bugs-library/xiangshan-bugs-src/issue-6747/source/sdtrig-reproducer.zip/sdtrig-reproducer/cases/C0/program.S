.option norelax
.option norvc

.equ TDATA1_BP, 0x6000000000000044

.section .text.init, "ax"
_start:
    la      t0, m_trap
    csrw    mtvec, t0
    csrsi   mstatus, 8
    csrw    tselect, x0
    la      t0, bp_target
    csrw    tdata2, t0
    li      t0, TDATA1_BP
    csrw    tdata1, t0
bp_target:
    addi    x5, x5, 1
    addi    x6, x6, 1
    j       after
after:
    j       after

.balign 64
m_trap:
    addi    x7, x7, 1
    j       m_trap
