# Execute breakpoint reproducer

Four minimal reproducers and five controls for Kunminghu v2 and v3.
Experiments completed on October 18, 2026.

- `cases/`: sources, ELF files, images and disassembly.
- `logs/v2/`, `logs/v3/`: original logs.
- `environment.json`: versions, parameters and binary hashes.

Run the four main cases:

```bash
XS_EMU=/path/to/emu XS_REF=/path/to/riscv64-spike-so bash replay.sh
```

Append `C0 HS0 LDA LDB STA` to run the controls. New output goes into `replay.*`.
Main cases stop on a Difftest mismatch. Triggering controls have a handler-step
offset in `t2`/`pc`; use exception records and `mepc/sepc` to identify the breakpoint.
