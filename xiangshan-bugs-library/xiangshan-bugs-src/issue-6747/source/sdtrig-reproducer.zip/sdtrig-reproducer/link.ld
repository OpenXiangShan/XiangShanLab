OUTPUT_ARCH("riscv")
ENTRY(_start)

SECTIONS
{
  . = 0x80000000;

  .text : {
    *(.text.init)
    *(.text .text.*)
  }

  .rodata : {
    *(.rodata .rodata.*)
  }

  .data : {
    *(.data .data.*)
  }

  .bss (NOLOAD) : {
    *(.bss .bss.*)
    *(COMMON)
  }

  . = ALIGN(8);
  .tohost : {
    *(.tohost)
  }

  /DISCARD/ : {
    *(.comment)
    *(.eh_frame)
    *(.riscv.attributes)
  }
}
