#!/usr/bin/env bash
# Re-run the packaged images. Keep all output; return codes are recorded, not treated as test verdicts.
set -eu
: "${XS_EMU:?Set XS_EMU to the XiangShan emu executable}"
: "${XS_REF:?Set XS_REF to the Spike reference shared library}"
PKG="$(cd "$(dirname "$0")" && pwd)"
EMU="$(realpath "$XS_EMU")"
REF="$(realpath "$XS_REF")"
test -x "$EMU"
test -f "$REF"
cd "$PKG"
sha256sum -c SHA256SUMS
OUT="$(mktemp -d "$PKG/replay.XXXXXX")"
sha256sum "$EMU" "$REF" > "$OUT/models.sha256"
printf 'Output: %s\n' "$OUT"
if [ "$#" -eq 0 ]; then set -- A-n0 B-n0 SA-n0 SB-n0; fi
for case_name in "$@"; do
    test -f "$PKG/cases/$case_name/program.img"
    mkdir "$OUT/$case_name"
    cd "$OUT/$case_name"
    set +e
    timeout 60s "$EMU" -b 0 -e 0 -I 2000 --ram-size 2GB \
        -i "$PKG/cases/$case_name/program.img" --diff "$REF" > dut.log 2>&1
    rc=$?
    set -e
    printf '%s\n' "$rc" > rc.txt
    printf '%s: rc=%s\n' "$case_name" "$rc"
done
