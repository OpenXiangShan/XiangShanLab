/* Address-specific hfence.gvma, matching VMID, onlyStage2 Sv39x4.
 * s0 = fill (old)
 * s1 = after leaf rewrite + addr-specific fence
 * s2 = after root nonleaf retarget + same fence
 */
.section .text.init
.globl _start
_start:
        la      t0, trap
        csrw    mtvec, t0
        csrw    satp, zero
        csrw    0x280, zero
        li      t0, -1
        csrw    0x3b0, t0
        li      t0, 0x1f
        csrw    0x3a0, t0

        la      a0, page_old
        la      a1, page_old
        jal     ra, install_leaf

        la      t0, g_root
        srli    t0, t0, 12
        li      t1, 8
        slli    t1, t1, 60
        or      t0, t0, t1
        li      t1, 1
        slli    t1, t1, 44
        or      t0, t0, t1
        csrw    0x680, t0
        hfence.gvma zero, zero

        li      t1, (3 << 11)
        csrc    mstatus, t1
        li      t1, (1 << 39) | (1 << 17) | (1 << 11)
        csrs    mstatus, t1

        la      a0, page_old
        ld      s0, 0(a0)
        li      t1, (1 << 17)
        csrc    mstatus, t1

        la      a1, page_new
        jal     ra, update_leaf
        la      a2, page_old
        srli    a2, a2, 2
        li      a1, 1
        hfence.gvma a2, a1
        li      t1, (1 << 17)
        csrs    mstatus, t1
        ld      s1, 0(a0)
        li      t1, (1 << 17)
        csrc    mstatus, t1

        jal     ra, retarget_root
        la      a2, page_old
        srli    a2, a2, 2
        li      a1, 1
        hfence.gvma a2, a1
        li      t1, (1 << 17)
        csrs    mstatus, t1
        ld      s2, 0(a0)

        li      t0, 0
        li      t1, 0x1111111111111111
        bne     s0, t1, 1f
        ori     t0, t0, 1
1:
        li      t1, 0x2222222222222222
        bne     s1, t1, 2f
        ori     t0, t0, 2
2:
        li      t1, 0x3333333333333333
        bne     s2, t1, 3f
        ori     t0, t0, 4
3:
        slli    t0, t0, 3
        la      t1, exits
        add     t1, t1, t0
        jr      t1

install_leaf:
        srli    t0, a0, 12
        andi    t1, t0, 0x1ff
        srli    t2, t0, 9
        andi    t2, t2, 0x1ff
        srli    t3, t0, 18
        andi    t3, t3, 0x7ff
        la      t4, g_l1
        srli    t5, t4, 12
        slli    t5, t5, 10
        ori     t5, t5, 1
        la      t6, g_root
        slli    t3, t3, 3
        add     t6, t6, t3
        sd      t5, 0(t6)
        mv      s10, t6
        la      t4, g_l0
        srli    t5, t4, 12
        slli    t5, t5, 10
        ori     t5, t5, 1
        la      t6, g_l1
        slli    t2, t2, 3
        add     t6, t6, t2
        sd      t5, 0(t6)
        mv      s9, t2
        srli    t5, a1, 12
        slli    t5, t5, 10
        ori     t5, t5, 0xdf
        la      t6, g_l0
        slli    t1, t1, 3
        add     t6, t6, t1
        sd      t5, 0(t6)
        mv      s11, t6
        ret

update_leaf:
        srli    t5, a1, 12
        slli    t5, t5, 10
        ori     t5, t5, 0xdf
        sd      t5, 0(s11)
        ret

retarget_root:
        la      t4, g_l0b
        srli    t5, t4, 12
        slli    t5, t5, 10
        ori     t5, t5, 1
        la      t6, g_l1b
        add     t6, t6, s9
        sd      t5, 0(t6)
        la      a1, page_third
        srli    t5, a1, 12
        slli    t5, t5, 10
        ori     t5, t5, 0xdf
        la      t6, g_l0b
        sub     t1, s11, t6
        /* s11-g_l0 is the byte offset; g_l0b has same offset */
        la      t4, g_l0
        sub     t1, s11, t4
        la      t6, g_l0b
        add     t6, t6, t1
        sd      t5, 0(t6)
        la      t4, g_l1b
        srli    t5, t4, 12
        slli    t5, t5, 10
        ori     t5, t5, 1
        sd      t5, 0(s10)
        ret

trap:
        csrr    t0, mcause
        andi    t0, t0, 31
        slli    t0, t0, 3
        la      t1, trap_exits
        add     t1, t1, t0
        jr      t1

        .option push
        .option norvc
.align 3
exits:
.rept 8
        li      a0, 0
        .word   0x0000006b
.endr
.align 3
trap_exits:
.rept 32
        li      a0, 0
        .word   0x0000006b
.endr
        .option pop

.section .data
.align 14
g_root:
        .zero 16384
.align 12
g_l1:
        .zero 4096
.align 12
g_l0:
        .zero 4096
.align 12
g_l1b:
        .zero 4096
.align 12
g_l0b:
        .zero 4096
.align 12
page_old:
        .dword 0x1111111111111111
        .zero 4088
.align 12
page_new:
        .dword 0x2222222222222222
        .zero 4088
.align 12
page_third:
        .dword 0x3333333333333333
        .zero 4088
