/* Reproducer: mtval is not written on a load access fault raised by a vector strided load (XiangShan kunminghu-v3).
 * Plain riscv-tests env-p program (riscv_test.h from riscv-tests/env/p; link.ld from the same env).
 * Build: riscv64-unknown-elf-gcc -march=rv64gcv -mabi=lp64 -static -mcmodel=medany -nostdlib -nostartfiles \
 *          -I env -I env/p -T env/link.ld mtval_vlse_u.S -o mtval_vlse_u.elf
 * Run:   ./build/emu -i mtval_vlse_u.elf --diff ./ready-to-run/riscv64-nemu-interpreter-so -C 20000
 * Expected on a correct core: no difftest divergence; the program reaches RVTEST_PASS.
 * XiangShan: difftest aborts right after the fault with
 *          mtval different ..., right = <address of target>, wrong = <reset content of mtval>              */
#include "riscv_test.h"

RVTEST_RV64M                    /* start the body in M-mode */
RVTEST_CODE_BEGIN
        li      t0, MSTATUS_VS
        csrs    mstatus, t0             /* enable the vector unit */
        li      t0, -1
        csrw    pmpaddr0, t0            /* pmp0: NAPOT over the whole address space ...            */
        li      t0, 0x1c
        csrw    pmpcfg0, t0             /* ... A=NAPOT, X only: in U-mode fetch is allowed, loads/stores fault */
        la      s2, target              /* the address the vector load will fault on */
        li      t4, 4                   /* stride */
        li      s5, 0                   /* receives mcause */
        li      s6, 0                   /* receives mtval  */
        li      t0, MSTATUS_MPP
        csrc    mstatus, t0             /* MPP = U */
        la      t0, umode
        csrw    mepc, t0
        mret
        .align 2
umode:
        vsetivli t0, 4, e32, m1, tu, mu
        vlse32.v v3, (s2), t4           /* -> load access fault (mcause 5); mtval must be s2 */
        nop
        li      TESTNUM, 2
        li      t0, 5
        bne     s5, t0, fail            /* wrong cause */
        li      TESTNUM, 3
        bne     s6, s2, fail            /* mtval != faulting address   <-- XiangShan takes this branch */
        RVTEST_PASS
fail:
        RVTEST_FAIL
RVTEST_CODE_END

        .global mtvec_handler
mtvec_handler:                          /* env-p trap_vector jumps here for non-ecall traps */
        csrr    s5, mcause
        csrr    s6, mtval
        li      t0, 0x1f
        csrw    pmpcfg0, t0             /* re-open R/W/X */
        csrr    t0, mepc
        addi    t0, t0, 4               /* skip the faulting 4-byte instruction */
        csrw    mepc, t0
        mret

        .data
RVTEST_DATA_BEGIN
        .align 6
target: .word 0x11111111, 0x22222222, 0x33333333, 0x44444444
RVTEST_DATA_END
