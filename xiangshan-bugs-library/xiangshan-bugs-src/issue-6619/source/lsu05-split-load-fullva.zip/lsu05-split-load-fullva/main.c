#include <klib.h>
#include <klib-macros.h>
#include <stdint.h>

/*
 * Candidate A reproducer:
 *
 * In Sv48, 0x0000_7fff_ffff_fffd is canonical but the high split of an
 * unaligned e32 access reaches 0x0000_8000_0000_0000, which is not a canonical
 * Sv48 virtual address. A correct implementation must raise load/store page
 * fault or address-misaligned fault before returning alias data or committing
 * an alias store. The latest reproduced architectural failure is the
 * load-alias variant: LoadMisalignBuffer reissues split loads through LoadUnit
 * without making the split high vaddr itself pass the TLB full-VA canonicality
 * precheck, so the high split can be translated through the widened VAddrBits
 * path if the page table maps the corresponding VPN.
 */

#define TEST_NAME "lsu05-split-load-fullva"

#define VARIANT_VECTOR_ALIAS   1
#define VARIANT_SCALAR_CONTROL 2
#define VARIANT_SCALAR_ALIAS   3
#define VARIANT_LOAD_CONTROL   4
#define VARIANT_LOAD_ALIAS     5

#ifndef TEST_VARIANT
#define TEST_VARIANT VARIANT_LOAD_ALIAS
#endif

#if TEST_VARIANT == VARIANT_VECTOR_ALIAS
#define VARIANT_NAME "vector-alias"
#elif TEST_VARIANT == VARIANT_SCALAR_CONTROL
#define VARIANT_NAME "scalar-control"
#elif TEST_VARIANT == VARIANT_SCALAR_ALIAS
#define VARIANT_NAME "scalar-alias"
#elif TEST_VARIANT == VARIANT_LOAD_CONTROL
#define VARIANT_NAME "load-control"
#elif TEST_VARIANT == VARIANT_LOAD_ALIAS
#define VARIANT_NAME "load-alias"
#else
#error "unsupported TEST_VARIANT"
#endif

#define ROOT_PA        0x82000000UL
#define PT0_PA         0x82004000UL
#define PT1_PA         0x82005000UL
#define PT2_PA         0x82006000UL
#define PT3_PA         0x82007000UL
#define PT4_PA         0x82008000UL
#define PT5_PA         0x82009000UL
#define PT6_PA         0x8200a000UL

#define LOW_LEAF_PA    0x82100000UL
#define BAD_ALIAS_PA   0x82200000UL

#define LAST_POS_PAGE  0x00007ffffffff000UL
#define STORE_VA       0x00007ffffffffffdUL
#define HIGH_SPLIT_VA  0x0000800000000000UL
#define NEG_ALIAS_VA   0xffff800000000000UL

#define SCALAR_CONTROL_VA      0x0000000082300ffdUL
#define SCALAR_CONTROL_LOW_PA  0x82300ffcUL
#define SCALAR_CONTROL_HIGH_PA 0x82301000UL
#define SCALAR_CONTROL_LOW_EXPECT  0xb2c3d444u
#define SCALAR_CONTROL_HIGH_EXPECT 0x556677a1u
#define LOAD_CONTROL_EXPECT        0x88112233u

#define SATP_MODE_SV48 (9UL << 60)
#define SATP_PPN_MASK  0x00000fffffffffffUL

#define PTE_V          (1UL << 0)
#define PTE_R          (1UL << 1)
#define PTE_W          (1UL << 2)
#define PTE_X          (1UL << 3)
#define PTE_A          (1UL << 6)
#define PTE_D          (1UL << 7)
#define PTE_RWXAD      (PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D)

#define CSR_MSTATUS    0x300
#define CSR_MEDELEG    0x302
#define CSR_MIDELEG    0x303
#define CSR_MIE        0x304
#define CSR_MTVEC      0x305
#define CSR_SATP       0x180
#define CSR_MENVCFG    0x30a

#define MSTATUS_MPP_MASK (3UL << 11)
#define MSTATUS_MPP_S    (1UL << 11)
#define MSTATUS_MIE      (1UL << 3)
#define MSTATUS_SIE      (1UL << 1)
#define MSTATUS_MPRV     (1UL << 17)
#define MSTATUS_MPV      (1UL << 39)
#define MSTATUS_FS       (3UL << 13)
#define MSTATUS_VS       (3UL << 9)

#define STORE_PAGE_FAULT 15UL
#define STORE_ADDR_MISALIGNED 6UL
#define LOAD_PAGE_FAULT 13UL
#define LOAD_ADDR_MISALIGNED 4UL

#define CSR_STRINGIFY_IMPL(x) #x
#define CSR_STRINGIFY(x) CSR_STRINGIFY_IMPL(x)
#define read_csr(csr)                                           \
    ({                                                          \
        uint64_t value;                                         \
        asm volatile("csrr %0, " CSR_STRINGIFY(csr) : "=r"(value)); \
        value;                                                  \
    })

#define write_csr(csr, value)                                          \
    do {                                                               \
        uint64_t csr_value = (uint64_t)(value);                        \
        asm volatile("csrw " CSR_STRINGIFY(csr) ", %0" :: "r"(csr_value)); \
    } while (0)

static volatile uint32_t trap_count;
static volatile uint64_t last_mcause;
static volatile uint64_t last_mtval;
static volatile uint64_t last_mepc;
static volatile uint64_t ecall_mcause;
static volatile uint64_t m_continue;
static volatile uint64_t trap_resume;
static volatile uint32_t reached_after_vector_store;
static volatile uint32_t alias_marker_before;
static volatile uint32_t alias_marker_after;
static volatile uint32_t loaded_value;

static const uint32_t values[1] __attribute__((used, aligned(4))) = { 0xa1b2c3d4u };

__asm__(
".globl trap_handler\n"
".align 2\n"
"trap_handler:\n"
"  csrr t0, mcause\n"
"  li   t1, 9\n"
"  beq  t0, t1, .Lback_to_m\n"
"  li   t1, 10\n"
"  beq  t0, t1, .Lback_to_m\n"
"  li   t1, 11\n"
"  beq  t0, t1, .Lback_to_m\n"
"  la   t1, last_mcause\n"
"  sd   t0, 0(t1)\n"
"  csrr t0, mtval\n"
"  la   t1, last_mtval\n"
"  sd   t0, 0(t1)\n"
"  csrr t0, mepc\n"
"  la   t1, last_mepc\n"
"  sd   t0, 0(t1)\n"
"  la   t1, trap_count\n"
"  lw   t0, 0(t1)\n"
"  addi t0, t0, 1\n"
"  sw   t0, 0(t1)\n"
"  la   t1, trap_resume\n"
"  ld   t0, 0(t1)\n"
"  bnez t0, .Lresume\n"
"  la   t1, m_continue\n"
"  ld   t0, 0(t1)\n"
"  csrw mepc, t0\n"
"  li   t0, 0x20000\n"
"  csrc mstatus, t0\n"
"  li   t0, 0x1800\n"
"  csrs mstatus, t0\n"
"  mret\n"
".Lresume:\n"
"  csrw mepc, t0\n"
"  mret\n"
".Lback_to_m:\n"
"  la   t1, ecall_mcause\n"
"  sd   t0, 0(t1)\n"
"  la   t1, m_continue\n"
"  ld   t0, 0(t1)\n"
"  csrw mepc, t0\n"
"  li   t0, 0x20000\n"
"  csrc mstatus, t0\n"
"  li   t0, 0x1800\n"
"  csrs mstatus, t0\n"
"  mret\n"
);
extern char trap_handler[];

__asm__(
".globl s_mode_vector_store_entry\n"
".align 2\n"
"s_mode_vector_store_entry:\n"
"  la   a0, values\n"
"  li   a1, 0x00007ffffffffffd\n"
"  li   a2, 4\n"
"  csrwi vcsr, 0\n"
"  vsetivli zero, 1, e32, m1, ta, ma\n"
"  vle32.v v0, (a0)\n"
"  vsse32.v v0, (a1), a2\n"
"  fence rw, rw\n"
"  li   t0, 0x1\n"
"  la   t1, reached_after_vector_store\n"
"  sw   t0, 0(t1)\n"
"  ecall\n"
);
extern char s_mode_vector_store_entry[];

__asm__(
".globl s_mode_scalar_store_entry\n"
".align 2\n"
"s_mode_scalar_store_entry:\n"
#if TEST_VARIANT == VARIANT_SCALAR_CONTROL
"  li   a0, 0x0000000082300ffd\n"
#else
"  li   a0, 0x00007ffffffffffd\n"
#endif
"  li   a1, 0xa1b2c3d4\n"
"  sw   a1, 0(a0)\n"
"  fence rw, rw\n"
"  li   t0, 0x1\n"
"  la   t1, reached_after_vector_store\n"
"  sw   t0, 0(t1)\n"
"  ecall\n"
);
extern char s_mode_scalar_store_entry[];

__asm__(
".globl s_mode_load_entry\n"
".align 2\n"
"s_mode_load_entry:\n"
#if TEST_VARIANT == VARIANT_LOAD_CONTROL
"  li   a0, 0x0000000082300ffd\n"
#else
"  li   a0, 0x00007ffffffffffd\n"
#endif
"  lw   a1, 0(a0)\n"
"  la   t1, loaded_value\n"
"  sw   a1, 0(t1)\n"
"  fence rw, rw\n"
"  li   t0, 0x1\n"
"  la   t1, reached_after_vector_store\n"
"  sw   t0, 0(t1)\n"
"  ecall\n"
);
extern char s_mode_load_entry[];

static inline uint64_t pte_table(uint64_t pa) {
  return (pa >> 2) | PTE_V;
}

static inline uint64_t pte_leaf(uint64_t pa) {
  return (pa >> 2) | PTE_RWXAD;
}

static void clear_table(volatile uint64_t *table, uint32_t entries) {
  for (uint32_t i = 0; i < entries; i++) table[i] = 0;
}

static void build_page_tables(void) {
  volatile uint64_t *root = (volatile uint64_t *)ROOT_PA;
  volatile uint64_t *pt0 = (volatile uint64_t *)PT0_PA;
  volatile uint64_t *pt1 = (volatile uint64_t *)PT1_PA;
  volatile uint64_t *pt2 = (volatile uint64_t *)PT2_PA;
  volatile uint64_t *pt3 = (volatile uint64_t *)PT3_PA;
  volatile uint64_t *pt4 = (volatile uint64_t *)PT4_PA;
  volatile uint64_t *pt5 = (volatile uint64_t *)PT5_PA;
  volatile uint64_t *pt6 = (volatile uint64_t *)PT6_PA;

  clear_table((volatile uint64_t *)ROOT_PA, 512);
  clear_table((volatile uint64_t *)PT0_PA, 512);
  clear_table((volatile uint64_t *)PT1_PA, 512);
  clear_table((volatile uint64_t *)PT2_PA, 512);
  clear_table((volatile uint64_t *)PT3_PA, 512);
  clear_table((volatile uint64_t *)PT4_PA, 512);
  clear_table((volatile uint64_t *)PT5_PA, 512);
  clear_table((volatile uint64_t *)PT6_PA, 512);

  /*
   * Keep the AM image and helper data executable/writable after entering
   * S-mode: root[0] -> pt0, pt0[2] is a 1GiB identity leaf for
   * 0x80000000..0xbfffffff.
   */
  root[0] = pte_table(PT0_PA);
  pt0[2] = pte_leaf(0x80000000UL);

  /* 0x0000_7fff_ffff_f000 -> LOW_LEAF_PA. */
  root[255] = pte_table(PT1_PA);
  pt1[511] = pte_table(PT2_PA);
  pt2[511] = pte_table(PT3_PA);
  pt3[511] = pte_leaf(LOW_LEAF_PA);

  /*
   * Canonical negative-half alias with the same Sv48 VPN[3:0] used if the DUT
   * skips the non-canonical check for 0x0000_8000_0000_0000.
   */
  root[256] = pte_table(PT4_PA);
  pt4[0] = pte_table(PT5_PA);
  pt5[0] = pte_table(PT6_PA);
  pt6[0] = pte_leaf(BAD_ALIAS_PA);

  asm volatile("fence rw, rw" ::: "memory");
}

static void enable_vector_state_mmode(void) {
  uint64_t bits = MSTATUS_FS | MSTATUS_VS;
  asm volatile("csrs mstatus, %0\n\t"
               "csrwi vcsr, 0"
               :
               : "r"(bits)
               : "memory");
}

static int enable_sv48(void) {
  write_csr(CSR_SATP, SATP_MODE_SV48 | ((ROOT_PA >> 12) & SATP_PPN_MASK));
  asm volatile("sfence.vma" ::: "memory");
  return (read_csr(CSR_SATP) >> 60) == 9;
}

static void disable_translation_mmode(void) {
  uint64_t mstatus = read_csr(CSR_MSTATUS);
  mstatus &= ~(MSTATUS_MIE | MSTATUS_SIE | MSTATUS_MPRV | MSTATUS_MPV);
  write_csr(CSR_MSTATUS, mstatus);
  asm volatile("csrw " CSR_STRINGIFY(CSR_SATP) ", zero" ::: "memory");
  asm volatile("sfence.vma\n\tfence rw, rw" ::: "memory");
}

static void enter_s_mode(uint64_t entry) {
  uint64_t mstatus = read_csr(CSR_MSTATUS);
  mstatus = (mstatus & ~MSTATUS_MPP_MASK) | MSTATUS_MPP_S;
  mstatus &= ~(MSTATUS_MIE | MSTATUS_SIE | MSTATUS_MPRV);
  mstatus &= ~MSTATUS_MPV;
  mstatus |= MSTATUS_FS | MSTATUS_VS;
  write_csr(CSR_MSTATUS, mstatus);
  asm volatile(
      "la t0, 1f\n\t"
      "sd t0, m_continue, t1\n\t"
      "csrw mepc, %0\n\t"
      "mret\n\t"
      "1:\n\t"
      :: "r"(entry)
      : "t0", "t1", "t2", "t3", "t4", "t5", "t6",
        "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7",
        "memory");
}

int main(void) {
  putstr(TEST_NAME " start " VARIANT_NAME "\n");

  build_page_tables();

  write_csr(0x3b0, -1L);     /* pmpaddr0: full-range NAPOT */
  write_csr(0x3a0, 0x1fUL);  /* pmpcfg0: RWX */
  write_csr(CSR_MENVCFG, read_csr(CSR_MENVCFG) & ~(3UL << 32));
  write_csr(CSR_MIE, 0);
  write_csr(CSR_MEDELEG, 0);
  write_csr(CSR_MIDELEG, 0);
  write_csr(CSR_MTVEC, (uint64_t)trap_handler);
  enable_vector_state_mmode();

  if (!enable_sv48()) {
    putstr(TEST_NAME " fail unsupported-sv48\n");
    return 1;
  }

  trap_count = 0;
  last_mcause = last_mtval = last_mepc = 0;
  ecall_mcause = 0;
  reached_after_vector_store = 0;
  loaded_value = 0;
  trap_resume = 0;
  *(volatile uint32_t *)LOW_LEAF_PA = 0x11223344u;
  *(volatile uint32_t *)BAD_ALIAS_PA = 0x55667788u;
#if TEST_VARIANT == VARIANT_SCALAR_CONTROL || TEST_VARIANT == VARIANT_LOAD_CONTROL
  *(volatile uint32_t *)SCALAR_CONTROL_LOW_PA = 0x11223344u;
  *(volatile uint32_t *)SCALAR_CONTROL_HIGH_PA = 0x55667788u;
#endif

#if TEST_VARIANT == VARIANT_VECTOR_ALIAS
  enter_s_mode((uint64_t)s_mode_vector_store_entry);
#elif TEST_VARIANT == VARIANT_SCALAR_CONTROL || TEST_VARIANT == VARIANT_SCALAR_ALIAS
  enter_s_mode((uint64_t)s_mode_scalar_store_entry);
#else
  enter_s_mode((uint64_t)s_mode_load_entry);
#endif
  disable_translation_mmode();
  alias_marker_before = *(volatile uint32_t *)LOW_LEAF_PA;
  alias_marker_after = *(volatile uint32_t *)BAD_ALIAS_PA;

#if TEST_VARIANT == VARIANT_VECTOR_ALIAS
  if (trap_count == 1 &&
      last_mcause == STORE_PAGE_FAULT &&
      (last_mtval == 0 || last_mtval == HIGH_SPLIT_VA) &&
      ecall_mcause == 0 &&
      reached_after_vector_store == 0 &&
      alias_marker_after == 0x55667788u) {
    putstr(TEST_NAME " pass " VARIANT_NAME "\n");
    return 0;
  }

  if (alias_marker_after != 0x55667788u) {
    putstr(TEST_NAME " fail canonical-bypass alias-corrupted\n");
  } else if (ecall_mcause != 0 || reached_after_vector_store != 0) {
    putstr(TEST_NAME " fail canonical-bypass no-page-fault\n");
  } else {
    putstr(TEST_NAME " fail canonical-bypass wrong-trap\n");
  }
  return 1;
#elif TEST_VARIANT == VARIANT_SCALAR_CONTROL
  uint32_t control_low = *(volatile uint32_t *)SCALAR_CONTROL_LOW_PA;
  uint32_t control_high = *(volatile uint32_t *)SCALAR_CONTROL_HIGH_PA;

  if (trap_count == 0 &&
      ecall_mcause != 0 &&
      reached_after_vector_store != 0 &&
      control_low == SCALAR_CONTROL_LOW_EXPECT &&
      control_high == SCALAR_CONTROL_HIGH_EXPECT &&
      alias_marker_after == 0x55667788u) {
    putstr(TEST_NAME " pass " VARIANT_NAME "\n");
    return 0;
  }

  if (trap_count != 0) {
    putstr(TEST_NAME " fail scalar-control unexpected-trap\n");
  } else if (control_low != SCALAR_CONTROL_LOW_EXPECT || control_high != SCALAR_CONTROL_HIGH_EXPECT) {
    putstr(TEST_NAME " fail scalar-control wrong-data\n");
  } else {
    putstr(TEST_NAME " fail scalar-control no-ecall\n");
  }
  return 1;
#elif TEST_VARIANT == VARIANT_SCALAR_ALIAS
  if (trap_count == 1 &&
      (last_mcause == STORE_PAGE_FAULT || last_mcause == STORE_ADDR_MISALIGNED) &&
      ecall_mcause == 0 &&
      reached_after_vector_store == 0 &&
      alias_marker_after == 0x55667788u) {
    putstr(TEST_NAME " pass " VARIANT_NAME "\n");
    return 0;
  }

  if (alias_marker_after != 0x55667788u) {
    putstr(TEST_NAME " fail scalar-alias alias-corrupted\n");
  } else if (ecall_mcause != 0 || reached_after_vector_store != 0) {
    putstr(TEST_NAME " fail scalar-alias no-trap\n");
  } else {
    putstr(TEST_NAME " fail scalar-alias wrong-trap\n");
  }
  return 1;
#elif TEST_VARIANT == VARIANT_LOAD_CONTROL
  if (trap_count == 0 &&
      ecall_mcause != 0 &&
      reached_after_vector_store != 0 &&
      loaded_value == LOAD_CONTROL_EXPECT &&
      alias_marker_after == 0x55667788u) {
    putstr(TEST_NAME " pass " VARIANT_NAME "\n");
    return 0;
  }

  if (trap_count != 0) {
    putstr(TEST_NAME " fail load-control unexpected-trap\n");
  } else if (loaded_value != LOAD_CONTROL_EXPECT) {
    putstr(TEST_NAME " fail load-control wrong-data\n");
  } else {
    putstr(TEST_NAME " fail load-control no-ecall\n");
  }
  return 1;
#else
  if (trap_count == 1 &&
      (last_mcause == LOAD_PAGE_FAULT || last_mcause == LOAD_ADDR_MISALIGNED) &&
      ecall_mcause == 0 &&
      reached_after_vector_store == 0 &&
      loaded_value == 0 &&
      alias_marker_after == 0x55667788u) {
    putstr(TEST_NAME " pass " VARIANT_NAME "\n");
    return 0;
  }

  if (loaded_value != 0 || reached_after_vector_store != 0 || ecall_mcause != 0) {
    putstr(TEST_NAME " fail load-alias canonical-bypass\n");
  } else {
    putstr(TEST_NAME " fail load-alias wrong-trap\n");
  }
  return 1;
#endif
}
