#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path


RAS_POP = 1
PROBE0 = 0x80020000
PROBE1 = 0x80020040


def clean_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_int(bits, base=2):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, base)


def hx(value):
    return None if value is None else hex(value)


def read_symbols(objdump_path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\w+\s+.*\s([A-Za-z_][A-Za-z0-9_]*)$")
    with objdump_path.open("r", errors="replace") as f:
        for raw in f:
            match = sym_re.match(raw.strip())
            if match:
                addr, name = match.groups()
                symbols[name] = int(addr, 16)
    required = [
        "_start",
        "secret0_call",
        "secret1_call",
        "secret0_ret_site",
        "secret1_ret_site",
        "secret0_gadget",
        "secret1_gadget",
        "victim_context_entry",
        "victim_actual_ret",
        "common_after",
        "measure_probe0",
        "measure_probe1",
        "hit_loop",
        "miss_loop",
        "wrong_path_sink",
        "result_delta0",
        "result_delta1",
    ]
    missing = [name for name in required if name not in symbols]
    if missing:
        raise RuntimeError(f"missing objdump symbols: {missing}")
    return symbols


def read_header(path):
    scope = []
    vars_seen = []
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
            elif line.startswith("$upscope"):
                if scope:
                    scope.pop()
            elif line.startswith("$var "):
                match = var_re.match(line)
                if not match:
                    continue
                width, code, name = match.groups()
                name = clean_name(name)
                vars_seen.append({
                    "width": int(width),
                    "code": code,
                    "name": name,
                    "full": ".".join(scope + [name]),
                })
    return vars_seen


def choose_by_suffix(vars_seen, suffix):
    matches = [
        var for var in vars_seen
        if var["full"].endswith(suffix)
        or (var["name"] == suffix.split(".")[-1] and suffix in var["full"])
    ]
    if not matches:
        return None
    return sorted(matches, key=lambda var: (len(var["full"]), var["full"]))[0]


def choose_signals(vars_seen):
    wanted = {
        "csr_valid": "_backend_io_frontendCsrCtrl_distribute_csr_w_valid",
        "csr_addr": "_backend_io_frontendCsrCtrl_distribute_csr_w_bits_addr",
        "csr_data": "_backend_io_frontendCsrCtrl_distribute_csr_w_bits_data",
        "ras_enable": "csrMod._sbpctl_regOut_RAS_ENABLE",
        "uras_s1_fire": "uras.io_stageCtrl_s1_fire",
        "uras_action": "uras.io_specIn_attribute_rasAction",
        "uras_ret": "uras.io_specOut_retTarget_addr",
        "uras_can_use": "uras.io_specOut_isCanUse",
        "ras_spec_fire": "RasStack.io_spec_fire",
        "ras_spec_pop_valid": "RasStack.io_spec_popValid",
        "ras_spec_pop_addr": "RasStack.io_spec_popAddr_addr",
        "ftq_wen": "io_frontend_fromFtq_wen",
        "ftq_start": "io_frontend_fromFtq_startPc_addr",
        "ftq_idx": "io_frontend_fromFtq_ftqIdx",
        "redirect_valid": "io_frontend_toFtq_redirect_valid",
        "redirect_pc": "io_frontend_toFtq_redirect_bits_pc",
        "redirect_target": "io_frontend_toFtq_redirect_bits_target",
        "redirect_action": "io_frontend_toFtq_redirect_bits_attribute_rasAction",
        "tl_a_valid": "auto_memBlock_inner_dcache_client_out_a_valid",
        "tl_a_address": "auto_memBlock_inner_dcache_client_out_a_bits_address",
        "tl_a_opcode": "auto_memBlock_inner_dcache_client_out_a_bits_opcode",
    }
    for pipe in range(3):
        wanted[f"ld{pipe}_s1_vaddr_valid"] = f"_memBlock_io_mem_to_ooo_lsTopdownInfo_{pipe}_s1_vaddr_valid"
        wanted[f"ld{pipe}_s1_vaddr"] = f"_memBlock_io_mem_to_ooo_lsTopdownInfo_{pipe}_s1_vaddr_bits"
        wanted[f"ld{pipe}_s2_paddr_valid"] = f"_memBlock_io_mem_to_ooo_lsTopdownInfo_{pipe}_s2_paddr_valid"
        wanted[f"ld{pipe}_s2_paddr"] = f"_memBlock_io_mem_to_ooo_lsTopdownInfo_{pipe}_s2_paddr_bits"
    for slot in range(8):
        wanted[f"decode{slot}_valid"] = f"inner_ctrlBlock._decode_io_out_{slot}_valid"
        wanted[f"decode{slot}_pc"] = f"inner_ctrlBlock._decode_io_out_{slot}_bits_debug_pc"
        wanted[f"dispatch{slot}_valid"] = f"inner_ctrlBlock._dispatch_io_enqRob_req_{slot}_valid"
        wanted[f"dispatch{slot}_pc"] = f"inner_ctrlBlock._dispatch_io_enqRob_req_{slot}_bits_debug_pc"
    for slot in range(8):
        endpoint = "commit" if slot == 0 else f"commit_{slot}"
        wanted[f"commit{slot}_valid"] = f"endpoint.{endpoint}.io_valid"
        wanted[f"commit{slot}_bits_valid"] = f"endpoint.{endpoint}.io_bits_valid"
        wanted[f"commit{slot}_pc"] = f"endpoint.{endpoint}.io_bits_pc"
    for slot in range(3):
        endpoint = "store" if slot == 0 else f"store_{slot}"
        wanted[f"store{slot}_valid"] = f"endpoint.{endpoint}.io_valid"
        wanted[f"store{slot}_bits_valid"] = f"endpoint.{endpoint}.io_bits_valid"
        wanted[f"store{slot}_addr"] = f"endpoint.{endpoint}.io_bits_addr"
        wanted[f"store{slot}_data"] = f"endpoint.{endpoint}.io_bits_data"
        wanted[f"store{slot}_pc"] = f"endpoint.{endpoint}.io_bits_pc"

    selected = {}
    missing = {}
    for key, suffix in wanted.items():
        sig = choose_by_suffix(vars_seen, suffix)
        if sig is None:
            missing[key] = suffix
        else:
            selected[key] = sig
    return selected, missing


def parse_wave(path, selected, symbols):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)
    values = {key: None for key in selected}
    events = []
    current_time = None
    in_body = False

    ret0_pruned = symbols["secret0_ret_site"] >> 1
    ret1_pruned = symbols["secret1_ret_site"] >> 1
    gadget0_pruned = symbols["secret0_gadget"] >> 1
    gadget1_pruned = symbols["secret1_gadget"] >> 1
    gadget0 = symbols["secret0_gadget"]
    gadget1 = symbols["secret1_gadget"]
    common_after = symbols["common_after"]
    victim_ret = symbols["victim_actual_ret"]
    result_delta0 = symbols["result_delta0"]
    result_delta1 = symbols["result_delta1"]
    ras_disable_time = None
    csr_disable_time = None

    def ret_site_name_pruned(value):
        if value == ret0_pruned:
            return "secret0_ret_site"
        if value == ret1_pruned:
            return "secret1_ret_site"
        return None

    def gadget_name_pruned(value):
        if value == gadget0_pruned:
            return "secret0_gadget"
        if value == gadget1_pruned:
            return "secret1_gadget"
        return None

    def gadget_name_pc(value):
        if value == gadget0:
            return "secret0_gadget"
        if value == gadget1:
            return "secret1_gadget"
        return None

    def probe_name(addr):
        if addr == PROBE0:
            return "probe0"
        if addr == PROBE1:
            return "probe1"
        return None

    def pc_label(value):
        labels = {
            symbols["measure_probe0"]: "measure_probe0",
            symbols["measure_probe1"]: "measure_probe1",
            symbols["hit_loop"]: "hit_loop",
            symbols["miss_loop"]: "miss_loop",
        }
        return labels.get(value)

    def result_name(addr):
        if addr == result_delta0:
            return "result_delta0"
        if addr == result_delta1:
            return "result_delta1"
        return None

    def after_disable():
        return ras_disable_time is not None and current_time is not None and current_time > ras_disable_time

    def emit_current():
        nonlocal csr_disable_time, ras_disable_time
        if current_time is None:
            return
        if (
            values.get("csr_valid") == 1
            and values.get("csr_addr") == 0x5C0
            and values.get("csr_data") == 0x3F
        ):
            if csr_disable_time is None:
                csr_disable_time = current_time
            events.append({"type": "csr_disable_write", "time": current_time})
        if values.get("ras_enable") == 0 and csr_disable_time is not None and ras_disable_time is None:
            ras_disable_time = current_time
            events.append({"type": "ras_disabled", "time": current_time})

        if not after_disable():
            return

        if values.get("uras_s1_fire") == 1 and values.get("uras_action") == RAS_POP and values.get("uras_can_use") == 1:
            events.append({
                "type": "disabled_uras_pop_any",
                "time": current_time,
                "ret_pruned": values.get("uras_ret"),
                "can_use": values.get("uras_can_use"),
                "ret_site": ret_site_name_pruned(values.get("uras_ret")),
                "gadget": gadget_name_pruned(values.get("uras_ret")),
            })
            ret_site = ret_site_name_pruned(values.get("uras_ret"))
            if ret_site:
                events.append({
                    "type": "disabled_uras_predicts_ret_site",
                    "time": current_time,
                    "ret_site": ret_site,
                    "ret_pruned": values.get("uras_ret"),
                })

        if values.get("ras_spec_fire") == 1 and values.get("ras_spec_pop_valid") == 1:
            events.append({
                "type": "disabled_ras_spec_pop_any",
                "time": current_time,
                "pop_addr_pruned": values.get("ras_spec_pop_addr"),
                "ret_site": ret_site_name_pruned(values.get("ras_spec_pop_addr")),
                "gadget": gadget_name_pruned(values.get("ras_spec_pop_addr")),
            })
            ret_site = ret_site_name_pruned(values.get("ras_spec_pop_addr"))
            if ret_site:
                events.append({
                    "type": "disabled_ras_spec_pop_to_ret_site",
                    "time": current_time,
                    "ret_site": ret_site,
                    "pop_addr_pruned": values.get("ras_spec_pop_addr"),
                })

        if values.get("ftq_wen") == 1:
            start = values.get("ftq_start")
            if start is not None and (symbols["_start"] >> 1) <= start <= (symbols["wrong_path_sink"] >> 1):
                events.append({
                    "type": "post_disable_ftq_fetch_any_poc_block",
                    "time": current_time,
                    "start_pruned": start,
                    "ftq_idx": values.get("ftq_idx"),
                    "ret_site": ret_site_name_pruned(start),
                    "gadget": gadget_name_pruned(start),
                })
            ret_site = ret_site_name_pruned(values.get("ftq_start"))
            if ret_site:
                events.append({
                    "type": "post_disable_ftq_fetch_ret_site",
                    "time": current_time,
                    "ret_site": ret_site,
                    "start_pruned": values.get("ftq_start"),
                    "ftq_idx": values.get("ftq_idx"),
                })
            gadget = gadget_name_pruned(values.get("ftq_start"))
            if gadget:
                events.append({
                    "type": "post_disable_ftq_fetch_gadget",
                    "time": current_time,
                    "gadget": gadget,
                    "start_pruned": values.get("ftq_start"),
                    "ftq_idx": values.get("ftq_idx"),
                })

        if (
            values.get("redirect_valid") == 1
            and values.get("redirect_pc") is not None
            and symbols["_start"] <= values.get("redirect_pc") <= symbols["wrong_path_sink"]
        ):
            events.append({
                "type": "post_disable_redirect_any_poc_block",
                "time": current_time,
                "pc": values.get("redirect_pc"),
                "target": values.get("redirect_target"),
                "action": values.get("redirect_action"),
            })

        if (
            values.get("redirect_valid") == 1
            and values.get("redirect_action") == RAS_POP
            and symbols["victim_context_entry"] <= values.get("redirect_pc") <= victim_ret
            and values.get("redirect_target") == common_after
        ):
            events.append({
                "type": "victim_ret_redirect_to_common_after",
                "time": current_time,
                "pc": values.get("redirect_pc"),
                "target": values.get("redirect_target"),
            })

        for slot in range(8):
            if values.get(f"decode{slot}_valid") == 1:
                pc = values.get(f"decode{slot}_pc")
                label = pc_label(pc)
                if label:
                    events.append({
                        "type": "post_disable_decode_label",
                        "time": current_time,
                        "slot": slot,
                        "label": label,
                        "pc": pc,
                    })
                gadget = gadget_name_pc(pc)
                if gadget:
                    events.append({
                        "type": "post_disable_decode_gadget",
                        "time": current_time,
                        "slot": slot,
                        "gadget": gadget,
                        "pc": pc,
                    })
            if values.get(f"dispatch{slot}_valid") == 1:
                pc = values.get(f"dispatch{slot}_pc")
                label = pc_label(pc)
                if label:
                    events.append({
                        "type": "post_disable_dispatch_label",
                        "time": current_time,
                        "slot": slot,
                        "label": label,
                        "pc": pc,
                    })
                gadget = gadget_name_pc(pc)
                if gadget:
                    events.append({
                        "type": "post_disable_dispatch_gadget",
                        "time": current_time,
                        "slot": slot,
                        "gadget": gadget,
                        "pc": pc,
                    })

        for slot in range(8):
            pc = values.get(f"commit{slot}_pc")
            label = pc_label(pc)
            if (
                values.get(f"commit{slot}_valid") == 1
                and values.get(f"commit{slot}_bits_valid") in (None, 1)
                and label
            ):
                events.append({
                    "type": "post_disable_commit_label",
                    "time": current_time,
                    "slot": slot,
                    "label": label,
                    "pc": pc,
                })

        for slot in range(3):
            addr = values.get(f"store{slot}_addr")
            result = result_name(addr)
            if (
                values.get(f"store{slot}_valid") == 1
                and values.get(f"store{slot}_bits_valid") in (None, 1)
                and result
            ):
                events.append({
                    "type": "post_disable_result_delta_store",
                    "time": current_time,
                    "slot": slot,
                    "result": result,
                    "addr": addr,
                    "data": values.get(f"store{slot}_data"),
                    "pc": values.get(f"store{slot}_pc"),
                })

        for pipe in range(3):
            if values.get(f"ld{pipe}_s1_vaddr_valid") == 1:
                probe = probe_name(values.get(f"ld{pipe}_s1_vaddr"))
                if probe:
                    events.append({
                        "type": "post_disable_probe_load_s1",
                        "time": current_time,
                        "pipe": pipe,
                        "probe": probe,
                        "addr": values.get(f"ld{pipe}_s1_vaddr"),
                    })
            if values.get(f"ld{pipe}_s2_paddr_valid") == 1:
                probe = probe_name(values.get(f"ld{pipe}_s2_paddr"))
                if probe:
                    events.append({
                        "type": "post_disable_probe_load_s2",
                        "time": current_time,
                        "pipe": pipe,
                        "probe": probe,
                        "addr": values.get(f"ld{pipe}_s2_paddr"),
                    })

        if values.get("tl_a_valid") == 1:
            probe = probe_name(values.get("tl_a_address"))
            if probe:
                events.append({
                    "type": "post_disable_dcache_probe_request",
                    "time": current_time,
                    "probe": probe,
                    "addr": values.get("tl_a_address"),
                    "opcode": values.get("tl_a_opcode"),
                })

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            first = line[0]
            if first == "#":
                emit_current()
                current_time = int(line[1:])
            elif first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bBhH":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_int(parts[0][1:], 16 if first in "hH" else 2)
                        for key in keys:
                            values[key] = value
        emit_current()

    return events, csr_disable_time, ras_disable_time


def event_out(event):
    out = dict(event)
    for key in ("ret_pruned", "pop_addr_pruned", "start_pruned", "pc", "target", "addr", "data"):
        if key in out:
            out[key] = hx(out[key])
    return out


def main(argv):
    if len(argv) != 5:
        print("usage: monitor_ras_disable_sidechannel.py <wave.vcd> <objdump> <secret_bit> <out.json>", file=sys.stderr)
        return 2
    wave = Path(argv[1])
    objdump = Path(argv[2])
    secret_bit = int(argv[3])
    out = Path(argv[4])

    expected_ret_site = f"secret{secret_bit}_ret_site"
    expected_gadget = f"secret{secret_bit}_gadget"
    expected_probe = f"probe{secret_bit}"
    symbols = read_symbols(objdump)
    selected, missing = choose_signals(read_header(wave))
    events, csr_time, ras_time = parse_wave(wave, selected, symbols)

    by_type = {}
    for event in events:
        by_type.setdefault(event["type"], []).append(event)

    predictions = [
        e for e in by_type.get("disabled_uras_predicts_ret_site", [])
        + by_type.get("disabled_ras_spec_pop_to_ret_site", [])
        if e.get("ret_site") == expected_ret_site
    ]
    first_prediction_time = min((e["time"] for e in predictions), default=None)

    def after_prediction(event):
        return first_prediction_time is not None and event["time"] >= first_prediction_time

    ret_fetches = [
        e for e in by_type.get("post_disable_ftq_fetch_ret_site", [])
        if e.get("ret_site") == expected_ret_site and after_prediction(e)
    ]
    fetches = [e for e in by_type.get("post_disable_ftq_fetch_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    wrong_fetches = [
        e for e in by_type.get("post_disable_ftq_fetch_ret_site", [])
        if e.get("ret_site") != expected_ret_site and after_prediction(e)
    ]
    redirects = by_type.get("victim_ret_redirect_to_common_after", [])
    decodes = [e for e in by_type.get("post_disable_decode_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    dispatches = [e for e in by_type.get("post_disable_dispatch_gadget", []) if e.get("gadget") == expected_gadget and after_prediction(e)]
    probe_loads = [
        e for e in by_type.get("post_disable_probe_load_s1", []) + by_type.get("post_disable_probe_load_s2", [])
        if e.get("probe") == expected_probe and after_prediction(e)
    ]
    dcache_requests = [
        e for e in by_type.get("post_disable_dcache_probe_request", [])
        if e.get("probe") == expected_probe and after_prediction(e)
    ]
    label_decodes = [e for e in by_type.get("post_disable_decode_label", []) if after_prediction(e)]
    label_dispatches = [e for e in by_type.get("post_disable_dispatch_label", []) if after_prediction(e)]
    label_commits = [e for e in by_type.get("post_disable_commit_label", []) if after_prediction(e)]
    result_stores = [e for e in by_type.get("post_disable_result_delta_store", []) if after_prediction(e)]
    delta0_stores = [e for e in result_stores if e.get("result") == "result_delta0"]
    delta1_stores = [e for e in result_stores if e.get("result") == "result_delta1"]
    delta0 = delta0_stores[0].get("data") if delta0_stores else None
    delta1 = delta1_stores[0].get("data") if delta1_stores else None
    selected_delta = delta0 if secret_bit == 0 else delta1
    other_delta = delta1 if secret_bit == 0 else delta0
    selected_probe_faster = (
        selected_delta is not None
        and other_delta is not None
        and selected_delta < other_delta
    )
    hit_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") == "hit_loop"
    ]
    miss_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") == "miss_loop"
    ]
    measure_events = [
        e for e in label_decodes + label_dispatches + label_commits
        if e.get("label") in ("measure_probe0", "measure_probe1")
    ]

    result = {
        "wave": str(wave),
        "secret_bit": secret_bit,
        "expected_ret_site": expected_ret_site,
        "expected_gadget": expected_gadget,
        "expected_probe": expected_probe,
        "symbols": {
            key: hx(symbols[key])
            for key in sorted(symbols)
            if key in {
                "secret0_call", "secret1_call", "secret0_gadget", "secret1_gadget",
                "secret0_ret_site", "secret1_ret_site",
                "victim_context_entry", "victim_actual_ret", "common_after",
                "measure_probe0", "measure_probe1", "hit_loop", "miss_loop",
                "result_delta0", "result_delta1",
            }
        },
        "probe_addresses": {"probe0": hx(PROBE0), "probe1": hx(PROBE1)},
        "selected_signal_count": len(selected),
        "missing_signal_count": len(missing),
        "missing_signals": missing,
        "csr_disable_write_time": csr_time,
        "ras_disable_time": ras_time,
        "first_prediction_time": first_prediction_time,
        "rdcycle": {
            "delta0_cycles": delta0,
            "delta1_cycles": delta1,
            "selected_delta_cycles": selected_delta,
            "other_delta_cycles": other_delta,
            "selected_probe_faster": selected_probe_faster,
        },
        "predicate": {
            "csr_disable_seen": csr_time is not None,
            "ras_enable_zero_seen": ras_time is not None,
            "disabled_ras_prediction_to_expected_ret_site": bool(predictions),
            "victim_return_redirected_to_common_after": bool(redirects),
            "expected_ret_site_ftq_fetch_after_prediction": bool(ret_fetches),
            "expected_gadget_ftq_fetch_after_disable": bool(fetches),
            "unexpected_ret_site_ftq_fetch_after_prediction": bool(wrong_fetches),
            "expected_gadget_decode_after_disable": bool(decodes),
            "expected_gadget_dispatch_after_disable": bool(dispatches),
            "expected_probe_load_after_prediction": bool(probe_loads),
            "expected_dcache_probe_request_after_prediction": bool(dcache_requests),
            "measure_probe_code_seen_after_prediction": bool(measure_events),
            "rdcycle_delta0_observed": bool(delta0_stores),
            "rdcycle_delta1_observed": bool(delta1_stores),
            "selected_probe_faster_than_other": selected_probe_faster,
            "hit_loop_seen": bool(hit_events),
            "miss_loop_seen": bool(miss_events),
            "icache_ftq_sidechannel_success": bool(csr_time is not None and ras_time is not None and predictions and redirects and ret_fetches),
            "dcache_sidechannel_success": bool(csr_time is not None and ras_time is not None and predictions and redirects and probe_loads),
            "timing_sidechannel_success": bool(selected_probe_faster or hit_events),
            "success": bool(
                csr_time is not None
                and ras_time is not None
                and predictions
                and redirects
                and ret_fetches
                and (selected_probe_faster or hit_events)
            ),
        },
        "events": {
            key: [event_out(e) for e in value[:24]]
            for key, value in sorted(by_type.items())
        },
    }
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["predicate"], indent=2, sort_keys=True))
    return 0 if result["predicate"]["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
