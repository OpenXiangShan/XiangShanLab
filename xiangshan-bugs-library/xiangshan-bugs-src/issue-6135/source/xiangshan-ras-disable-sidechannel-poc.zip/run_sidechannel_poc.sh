#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"
CYCLES="${CYCLES:-14000}"
WAVE_BEGIN="${WAVE_BEGIN:-7800}"
WAVE_END="${WAVE_END:-11200}"
SECRETS="${SECRETS:-0 1}"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in $SECRETS; do
  prefix="ras_disable_sidechannel_secret${secret}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  wave="${prefix}_${WAVE_BEGIN}_${WAVE_END}.vcd"
  run_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.run.log"
  monitor_json="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
  monitor_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

  echo "[build] SECRET_BIT=${secret} -> ${elf}"
  "$RISCV_GCC" \
    -DSECRET_BIT="${secret}" \
    -march=rv64gc_zicsr_zifencei -mabi=lp64d -mcmodel=medany \
    -nostdlib -nostartfiles -static -fno-pic \
    -T link.ld \
    -Wl,--no-relax \
    -o "$elf" \
    ras_disable_sidechannel.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d -t "$elf" > "$objdump"

  echo "[run] SECRET_BIT=${secret} ${EMU}"
  "$EMU" \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    -i "$bin" \
    --no-diff \
    --dump-wave-full \
    --wave-path="$wave" \
    --force-dump-result \
    > "$run_log" 2>&1

  echo "[parse] ${wave}"
  python3 ./monitor_ras_disable_sidechannel.py "$wave" "$objdump" "$secret" "$monitor_json" > "$monitor_log"
  cat "$monitor_log"
done

python3 - <<'PY'
import json
import os
from pathlib import Path

wave_begin = os.environ.get("WAVE_BEGIN", "7800")
wave_end = os.environ.get("WAVE_END", "11200")
secrets = set(os.environ.get("SECRETS", "0 1").split())
results = []
def first_time(events, name, **filters):
    for event in events.get(name, []):
        if all(event.get(key) == value for key, value in filters.items()):
            return event.get("time")
    return None

for path in sorted(Path(".").glob(f"ras_disable_sidechannel_secret*_{wave_begin}_{wave_end}.monitor.json")):
    with path.open() as f:
        data = json.load(f)
    if str(data["secret_bit"]) not in secrets:
        continue
    events = data.get("events", {})
    expected_ret_site = data.get("expected_ret_site")
    expected_gadget = data["expected_gadget"]
    expected_probe = data["expected_probe"]
    results.append({
        "file": str(path),
        "secret_bit": data["secret_bit"],
        "expected_ret_site": expected_ret_site,
        "expected_gadget": expected_gadget,
        "expected_probe": expected_probe,
        "csr_disable_write_time": data.get("csr_disable_write_time"),
        "ras_disable_time": data.get("ras_disable_time"),
        "first_prediction_time": data.get("first_prediction_time"),
        "key_event_times": {
            "ret_site_ftq_fetch": first_time(events, "post_disable_ftq_fetch_ret_site", ret_site=expected_ret_site),
            "gadget_ftq_fetch": first_time(events, "post_disable_ftq_fetch_gadget", gadget=expected_gadget),
            "gadget_decode": first_time(events, "post_disable_decode_gadget", gadget=expected_gadget),
            "gadget_dispatch": first_time(events, "post_disable_dispatch_gadget", gadget=expected_gadget),
            "probe_load_s1": first_time(events, "post_disable_probe_load_s1", probe=expected_probe),
            "dcache_probe_request": first_time(events, "post_disable_dcache_probe_request", probe=expected_probe),
            "redirect_to_common_after": first_time(events, "victim_ret_redirect_to_common_after"),
            "result_delta0_store": first_time(events, "post_disable_result_delta_store", result="result_delta0"),
            "result_delta1_store": first_time(events, "post_disable_result_delta_store", result="result_delta1"),
            "hit_loop_commit": first_time(events, "post_disable_commit_label", label="hit_loop"),
        },
        "rdcycle": data.get("rdcycle"),
        "predicate": data["predicate"],
    })
Path(f"SUMMARY_{wave_begin}_{wave_end}.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
print(json.dumps(results, indent=2, sort_keys=True))
if not all(item["predicate"].get("success") for item in results):
    raise SystemExit("one or more sidechannel predicates failed")
PY
