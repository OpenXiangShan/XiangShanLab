package xiangshan.backend.fu.NewCSR

import chisel3._
import chisel3.util.Decoupled
import chiseltest._
import chiseltest.simulator.VerilatorFlags
import org.chipsalliance.cde.config.Parameters
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import top.DefaultConfig
import xiangshan.{CSROpType, XSCoreParamsKey, XSTileKey}

class DebugSpecStopcountTest extends AnyFlatSpec with ChiselScalatestTester with Matchers {

  implicit val config: Parameters = (new DefaultConfig).alterPartial {
    case XSCoreParamsKey => (new DefaultConfig)(XSTileKey).head.copy()
  }

  private val AddrDcsr = "h7B0".U
  private val AddrMinstret = "hB02".U
  private val AddrInstret = "hC02".U
  private val StopcountBit = BigInt(1) << 10

  private def stepUntil(dut: StopcountHarness, hint: String, maxCycles: Int = 40)(cond: => Boolean): Unit = {
    var cycles = 0
    while (!cond && cycles < maxCycles) {
      dut.clock.step()
      cycles += 1
    }
    withClue(hint) {
      cond shouldBe true
    }
  }

  private def csrWrite(dut: StopcountHarness, addr: UInt, wdata: BigInt): Unit = {
    dut.io.in.valid.poke(true.B)
    dut.io.in.bits.wen.poke(true.B)
    dut.io.in.bits.ren.poke(false.B)
    dut.io.in.bits.addr.poke(addr)
    dut.io.in.bits.wdata.poke(wdata.U)
    stepUntil(dut, s"CSR write $addr not accepted") {
      dut.io.in.ready.peek().litToBoolean
    }
    dut.clock.step()
    dut.clock.step() 
    dut.io.in.valid.poke(false.B)
    dut.io.in.bits.wen.poke(false.B)
  }

  private def csrRead(dut: StopcountHarness, addr: UInt): BigInt = {
    dut.io.out.ready.poke(false.B)
    dut.io.in.valid.poke(true.B)
    dut.io.in.bits.wen.poke(false.B)
    dut.io.in.bits.ren.poke(true.B)
    dut.io.in.bits.addr.poke(addr)
    stepUntil(dut, s"CSR read $addr not accepted") {
      dut.io.in.ready.peek().litToBoolean
    }
    dut.clock.step()
    dut.io.in.valid.poke(false.B)
    dut.io.in.bits.ren.poke(false.B)
    stepUntil(dut, s"CSR read $addr got no response") {
      dut.io.out.valid.peek().litToBoolean
    }
    val data = dut.io.out.bits.rData.peek().litValue
    dut.io.out.ready.poke(true.B)
    dut.clock.step()
    data
  }

  private def enterDebugMode(dut: StopcountHarness): Unit = {
    dut.io.debugIP.poke(true.B)
    stepUntil(dut, "debug interrupt did not become pending") {
      dut.io.interrupt.peek().litToBoolean
    }
    dut.clock.step() 
    dut.io.trapValid.poke(true.B)
    dut.io.trapIsInterrupt.poke(true.B)
    dut.clock.step()
    dut.clock.step()
    dut.io.trapValid.poke(false.B)
    dut.io.trapIsInterrupt.poke(false.B)
    stepUntil(dut, "did not enter Debug Mode") {
      dut.io.debugMode.peek().litToBoolean
    }
    dut.io.debugIP.poke(false.B)
  }

  private def retire(dut: StopcountHarness, n: Int, cycles: Int = 4): Unit = {
    dut.io.instNumValid.poke(true.B)
    dut.io.instNumBits.poke(n.U)
    dut.clock.step(cycles)
    dut.io.instNumValid.poke(false.B)
    dut.io.instNumBits.poke(0.U)
    dut.clock.step()
  }

  private def dret(dut: StopcountHarness): Unit = {
    dut.io.in.valid.poke(true.B)
    dut.io.in.bits.wen.poke(false.B)
    dut.io.in.bits.ren.poke(false.B)
    dut.io.in.bits.dret.poke(true.B)
    stepUntil(dut, "dret not accepted") {
      dut.io.in.ready.peek().litToBoolean
    }
    dut.clock.step()
    dut.io.in.valid.poke(false.B)
    dut.io.in.bits.dret.poke(false.B)
    stepUntil(dut, "did not leave Debug Mode") {
      !dut.io.debugMode.peek().litToBoolean
    }
    dut.clock.step(2) 
  }

  behavior of "D1 stopcount vs minstret"

  it should "keep minstret counting under stopcount=1, break the instret shadow, and jump on dret (spec: freeze the counter itself)" in {
    test(new StopcountHarness()(config)).withAnnotations(Seq(VerilatorFlags(Seq()))) { dut =>
      dut.io.out.ready.poke(true.B)
      dut.io.in.valid.poke(false.B)
      dut.io.in.bits.wen.poke(false.B)
      dut.io.in.bits.ren.poke(false.B)
      dut.io.in.bits.op.poke(CSROpType.getCSROp(CSROpType.wrt))
      dut.io.in.bits.addr.poke(0.U)
      dut.io.in.bits.src.poke(0.U)
      dut.io.in.bits.wdata.poke(0.U)
      dut.io.in.bits.mnret.poke(false.B)
      dut.io.in.bits.mret.poke(false.B)
      dut.io.in.bits.sret.poke(false.B)
      dut.io.in.bits.dret.poke(false.B)
      dut.io.in.bits.redirectFlush.poke(false.B)
      dut.clock.step(5)

      enterDebugMode(dut)

      val dcsr = csrRead(dut, AddrDcsr)
      csrWrite(dut, AddrDcsr, dcsr | StopcountBit)
      val dcsrReadback = csrRead(dut, AddrDcsr)
      withClue("dcsr.stopcount is RW and must read back 1 after being set") {
        (dcsrReadback & StopcountBit) shouldBe StopcountBit
      }
      dut.clock.step(2) 
      val minstret0 = csrRead(dut, AddrMinstret)
      val instret0 = csrRead(dut, AddrInstret)
      withClue("before retiring, instret must still equal minstret") {
        instret0 shouldBe minstret0
      }

 
      retire(dut, n = 5)

      val minstretDbg = csrRead(dut, AddrMinstret)
      val instretDbg = csrRead(dut, AddrInstret)
      withClue("BUG: minstret keeps counting in Debug Mode under stopcount=1 (spec: frozen)") {
        (minstretDbg > minstret0) shouldBe true
      }
      withClue("the unprivileged instret shadow is frozen at the stopcount rising-edge snapshot") {
        instretDbg shouldBe instret0
      }
      withClue("BUG: instret != minstret at the same instant — the read-only-shadow invariant is broken") {
        (instretDbg != minstretDbg) shouldBe true
      }


      dret(dut)

      val minstretPost = csrRead(dut, AddrMinstret)
      val instretPost = csrRead(dut, AddrInstret)
      withClue("no retirement happened after the in-Debug read, so minstret is unchanged") {
        minstretPost shouldBe minstretDbg
      }
      withClue("BUG: on dret the instret shadow snaps to the advanced minstret") {
        instretPost shouldBe minstretPost
      }
      withClue("BUG: instret jumps forward across the debug session instead of staying frozen") {
        (instretPost > instretDbg) shouldBe true
      }
    }
  }
}

class StopcountHarness(implicit p: Parameters) extends Module {
  val io = IO(new Bundle {
    val in = Flipped(Decoupled(new NewCSRInput))
    val out = Decoupled(new NewCSROutput)
    val debugIP = Input(Bool())
    val trapValid = Input(Bool())
    val trapIsInterrupt = Input(Bool())
    val instNumValid = Input(Bool())
    val instNumBits = Input(UInt(7.W))
    val debugMode = Output(Bool())
    val interrupt = Output(Bool())
  })

  val dut = Module(new NewCSR)

  dut.io.fromTop.hartId := 0.U
  dut.io.fromTop.clintTime.valid := false.B
  dut.io.fromTop.clintTime.bits := 0.U
  dut.io.fromTop.l2FlushDone := false.B
  dut.io.fromTop.criticalErrorState := false.B
  dut.platformIRP := 0.U.asTypeOf(dut.platformIRP)
  dut.platformIRP.debugIP := io.debugIP
  dut.nonMaskableIRP := 0.U.asTypeOf(dut.nonMaskableIRP)
  dut.fromAIA := 0.U.asTypeOf(dut.fromAIA)
  dut.io.trapInst.valid := false.B
  dut.io.trapInst.bits := 0.U
  dut.io.fromMem := 0.U.asTypeOf(dut.io.fromMem)
  dut.io.fromRob := 0.U.asTypeOf(dut.io.fromRob)
  dut.io.fromRob.trap.valid := io.trapValid
  dut.io.fromRob.trap.bits.isInterrupt := io.trapIsInterrupt
  dut.io.fromRob.commit.instNum.valid := io.instNumValid
  dut.io.fromRob.commit.instNum.bits := io.instNumBits
  dut.io.fromVecExcpMod.busy := false.B
  dut.io.perf := 0.U.asTypeOf(dut.io.perf)
  dut.io.fetchMalTval := 0.U
  dut.io.oldPrivSate := 0.U.asTypeOf(dut.io.oldPrivSate)
  dut.io.oldSatpMode := 0.U
  dut.io.oldVsatpMode := 0.U

  dut.io.in <> io.in
  io.out <> dut.io.out
  io.debugMode := dut.io.status.debugMode
  io.interrupt := dut.io.status.interrupt
}
