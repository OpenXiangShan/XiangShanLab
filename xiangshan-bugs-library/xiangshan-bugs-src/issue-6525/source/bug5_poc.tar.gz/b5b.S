# b5b.S — BUG-5 retest binary B (KILL variant), DefaultConfig emu (v2 geometry)
# Same as b5a.S except the stream loop: a mcycle-parity branch skips the loads
# on ~half the iterations. When the branch is MISPREDICTED (predicted not-taken,
# actually taken), the two loads issue on the wrong path and are killed by the
# redirect — exactly the BUG-5 condition.
# Per-iteration retired instruction count is EXACTLY 10 on BOTH paths.
# Expected signatures (stride = 256B = 4 blocks):
#   A          : s0_valid ~= 2N, learned stride 256B  (stride_8)
#   B bug      : killed loads also train -> s0_valid ~= 2N, stride_8
#   B gated    : only retired loads train -> s0_valid ~= N, stride 512B (stride_9)
# Software counters: s11 = iterations that skipped the loads.

    .option norvc
    .section .text
    .globl _start

_start:
    la      sp, stack_top
    la      t0, trap_handler
    csrw    mtvec, t0
    li      t0, -1
    csrw    pmpaddr0, t0
    li      t0, 0x1F
    csrw    pmpcfg0, t0
    csrw    satp, zero
    csrw    mie, zero

    # NOTE: no spfctl readback (difftest DUT/NEMU custom-CSR mismatch)
    lla     s8, buf

    # ========= stream: 400 iters, ~50% loads killed via bitmap mispredict =====
    # skip decision = fixed pseudo-random byte bitmap (data-dependent: the BPU
    # cannot learn it from history, unlike mcycle parity which collapsed to
    # taken-always in the v1 run). ~200 skips of 400.
    # not-taken path: add lbu bnez slli add ld ld j | addi blt       = 10
    # taken    path: add lbu bnez nop nop nop nop addi s11 addi blt   = 10
    lla     s7, skip_bitmap
    li      s9, 400
    li      s10, 0
    li      s11, 0
.ph2:
    add     t3, s7, s10
    lbu     t3, 0(t3)
    bnez    t3, .ph2k
    slli    t3, s10, 8
    add     t3, t3, s8
    ld      t1, 0(t3)
    ld      t1, 128(t3)
    j       .ph2x
.ph2k:
    nop
    nop
    nop
    nop
    addi    s11, s11, 1
.ph2x:
    addi    s10, s10, 1
    blt     s10, s9, .ph2

    # ---- tertiary probes: stride-pf zone vs cold reference ----
    lla     a0, msg_pz
    jal     puts
    li      t5, 8
    lla     t6, buf
    li      t4, 400
    slli    t4, t4, 8
    add     t6, t6, t4
    addi    t6, t6, 1024
.pz:
    addi    a0, t6, 0
    jal     ra, probe
    jal     puthex16
    lla     a0, msg_sp
    jal     puts
    addi    t6, t6, 64
    addi    t5, t5, -1
    bnez    t5, .pz
    li      t4, 128*1024
    add     a0, s8, t4
    jal     ra, probe
    jal     puthex16

    # ---- self-report: SKIP, INSTR, CYC ----
    lla     a0, msg_skip
    jal     puts
    addi    a0, s11, 0
    jal     puthex16
    lla     a0, msg_instr
    jal     puts
    csrr    a0, 0xB02
    jal     ra, puthex16
    lla     a0, msg_cyc
    jal     puts
    csrr    a0, 0xB00
    jal     ra, puthex16
    lla     a0, msg_nl
    jal     puts

    csrw    mtvec, x0
    jalr    x0, 0(x0)

# ---- probe: a0 = addr -> a0 = mcycle delta (CSR-write dependency chain) ----
probe:
    csrr    t3, 0xB00
    ld      t4, 0(a0)
    csrw    mscratch, t4
    csrr    t4, 0xB00
    sub     a0, t4, t3
    ret

    .align 2
trap_handler:
    csrr    s4, mcause
    csrr    s5, mepc
    addi    s5, s5, 4
    csrw    mepc, s5
    mret

puts:
    lbu     a1, 0(a0)
    beqz    a1, .Lpd
    li      t2, 0x40600004
    sw      a1, 0(t2)
    addi    a0, a0, 1
    j       puts
.Lpd:
    ret
puthex16:
    li      t1, 64
.Lph:
    addi    t1, t1, -4
    srl     a1, a0, t1
    andi    a1, a1, 15
    li      t2, 10
    blt     a1, t2, .Lph1
    addi    a1, a1, 55
    j       .Lph2
.Lph1:
    addi    a1, a1, 48
.Lph2:
    li      t2, 0x40600004
    sw      a1, 0(t2)
    bnez    t1, .Lph
    ret

    .data
msg_sp:   .asciz " "
msg_pz:   .asciz "\nPFZONE="
msg_skip: .asciz " SKIP="
msg_instr: .asciz " INSTR="
msg_cyc:  .asciz " CYC="
msg_nl:   .asciz "\n"
    .balign 4
skip_bitmap:
.word 0x00010001
    .word 0x00010101
    .word 0x01000100
    .word 0x00010100
    .word 0x00010001
    .word 0x00010101
    .word 0x00000001
    .word 0x00010001
    .word 0x00000100
    .word 0x01000101
    .word 0x00010100
    .word 0x00010001
    .word 0x01000101
    .word 0x01010101
    .word 0x01000000
    .word 0x01010100
    .word 0x00010001
    .word 0x01000001
    .word 0x01000000
    .word 0x00010101
    .word 0x00010100
    .word 0x00000101
    .word 0x00000001
    .word 0x01000001
    .word 0x01010000
    .word 0x00000100
    .word 0x00010100
    .word 0x01010000
    .word 0x01010101
    .word 0x00000001
    .word 0x01000100
    .word 0x00000000
    .word 0x00010001
    .word 0x00010001
    .word 0x00010001
    .word 0x01000000
    .word 0x00010100
    .word 0x00000001
    .word 0x01010100
    .word 0x01000001
    .word 0x00010000
    .word 0x01010101
    .word 0x01010001
    .word 0x01010001
    .word 0x00010001
    .word 0x01010000
    .word 0x01010000
    .word 0x00010101
    .word 0x00000100
    .word 0x00010000
    .word 0x01010100
    .word 0x01000000
    .word 0x01000101
    .word 0x01010000
    .word 0x00000100
    .word 0x00000001
    .word 0x00010100
    .word 0x01000101
    .word 0x00000101
    .word 0x00000101
    .word 0x00010101
    .word 0x01010101
    .word 0x01000100
    .word 0x00010100
    .word 0x01000100
    .word 0x01000000
    .word 0x00010101
    .word 0x01010100
    .word 0x01000101
    .word 0x01000100
    .word 0x01000000
    .word 0x00010000
    .word 0x01010100
    .word 0x01000000
    .word 0x01000100
    .word 0x00000000
    .word 0x01000001
    .word 0x00000101
    .word 0x01010100
    .word 0x01010001
    .word 0x00010000
    .word 0x01010001
    .word 0x01010001
    .word 0x00000000
    .word 0x00000100
    .word 0x00000100
    .word 0x00010001
    .word 0x00000100
    .word 0x00010101
    .word 0x01010000
    .word 0x01000101
    .word 0x00010100
    .word 0x00000000
    .word 0x01010100
    .word 0x00000000
    .word 0x00010001
    .word 0x01000101
    .word 0x01000100
    .word 0x01000001
    .word 0x00000001
    .bss
    .balign 4096
buf:        .space 144*1024
    .align 4
stack_top:  .space 4096
