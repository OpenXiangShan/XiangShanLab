# b5a.S — BUG-5 retest binary A (ALL-RETIRE positive control), DefaultConfig emu
# v2 geometry: 2 loads/iter, pc1 @ buf+256i, pc2 @ buf+256i+128 -> per-PC stride
# 256B (4 blocks; stride of 0/1 blocks is REJECTED by StrideMetaBundle.update,
# L1StridePrefetcher.scala:108, so 64B/iter was a degenerate design — fixed).
# pf distance = stride << l1_stride_ratio(=2) = 1KB beyond the training load.
# Verdict = perf counters (stride_meta_array s0_valid, StrideMonitor sent,
# stride_j histogram) + mispredict nail + PFZONE probes (tertiary).
# Both binaries retire EXACTLY 10 instructions per iteration (nop padded).

    .option norvc
    .section .text
    .globl _start

_start:
    la      sp, stack_top
    la      t0, trap_handler
    csrw    mtvec, t0
    li      t0, -1
    csrw    pmpaddr0, t0
    li      t0, 0x1F
    csrw    pmpcfg0, t0
    csrw    satp, zero
    csrw    mie, zero

    # NOTE: no spfctl readback — DUT/NEMU disagree on custom-CSR bit layout and
    #       difftest aborts on a0. Stride enable (bit16) reset=true is asserted
    # from CSRCustom.scala + RTL pre-check instead; perf dump proves it live.

    lla     s8, buf

    # ========= stream: 400 iters x 2 loads (pc1 @ +256i, pc2 @ +128), all retire
    # per-iter retired: slli add ld ld nop nop nop nop addi blt = 10
    li      s9, 400
    li      s10, 0
.ph1:
    slli    t3, s10, 8
    add     t3, t3, s8
    ld      t1, 0(t3)
    ld      t1, 128(t3)
    nop
    nop
    nop
    nop
    addi    s10, s10, 1
    blt     s10, s9, .ph1

    # ---- tertiary probes: stride-pf zone (last+1KB band) vs cold reference ----
    lla     a0, msg_pz
    jal     puts
    li      t5, 8
    lla     t6, buf
    li      t4, 400
    slli    t4, t4, 8
    add     t6, t6, t4          # t6 = buf + 400*256 = one past last load
    addi    t6, t6, 1024        # + stride<<ratio: the pf target zone
.pz:
    addi    a0, t6, 0
    jal     ra, probe
    jal     puthex16
    lla     a0, msg_sp
    jal     puts
    addi    t6, t6, 64
    addi    t5, t5, -1
    bnez    t5, .pz
    li      t4, 128*1024
    add     a0, s8, t4
    jal     ra, probe
    jal     puthex16

    # ---- self-report: SKIP, INSTR (minstret), CYC (mcycle) ----
    lla     a0, msg_skip
    jal     puts
    li      a0, 0
    jal     puthex16
    lla     a0, msg_instr
    jal     puts
    csrr    a0, 0xB02
    jal     ra, puthex16
    lla     a0, msg_cyc
    jal     puts
    csrr    a0, 0xB00
    jal     ra, puthex16
    lla     a0, msg_nl
    jal     puts

    # ---- forced double-trap exit for counter dump ----
    csrw    mtvec, x0
    jalr    x0, 0(x0)

# ---- probe: a0 = addr -> a0 = mcycle delta (CSR-write dependency chain, v2) ----
probe:
    csrr    t3, 0xB00
    ld      t4, 0(a0)
    csrw    mscratch, t4
    csrr    t4, 0xB00
    sub     a0, t4, t3
    ret

# ---- trap handler (safety net) ----
    .align 2
trap_handler:
    csrr    s4, mcause
    csrr    s5, mepc
    addi    s5, s5, 4
    csrw    mepc, s5
    mret

puts:
    lbu     a1, 0(a0)
    beqz    a1, .Lpd
    li      t2, 0x40600004
    sw      a1, 0(t2)
    addi    a0, a0, 1
    j       puts
.Lpd:
    ret
puthex16:
    li      t1, 64
.Lph:
    addi    t1, t1, -4
    srl     a1, a0, t1
    andi    a1, a1, 15
    li      t2, 10
    blt     a1, t2, .Lph1
    addi    a1, a1, 55
    j       .Lph2
.Lph1:
    addi    a1, a1, 48
.Lph2:
    li      t2, 0x40600004
    sw      a1, 0(t2)
    bnez    t1, .Lph
    ret

    .data
msg_sp:   .asciz " "
msg_pz:   .asciz "\nPFZONE="
msg_skip: .asciz " SKIP="
msg_instr: .asciz " INSTR="
msg_cyc:  .asciz " CYC="
msg_nl:   .asciz "\n"
    .bss
    .balign 4096
buf:        .space 144*1024
    .align 4
stack_top:  .space 4096
