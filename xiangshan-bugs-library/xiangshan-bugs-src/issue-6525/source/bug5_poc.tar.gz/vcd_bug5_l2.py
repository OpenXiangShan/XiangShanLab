#!/usr/bin/env python3
# vcd_bug5_l2.py — L2-side waveform analysis (final):
#   VBOP/PBOP train_buf enq fires attributed by line index (vaddr>>6) to
#   never-retired (skipped-iteration) loads; reqsource split
#   (0x2=CPULoadData demand vs 0xa=Prefetch2L2SMS core-SMS prefetch).
# usage: vcd_bug5_l2.py analyze <vcd>
import sys, re, json
meta = json.load(open('/tmp/b5b_skips.json'))
SKIPS_LINE = {int(x,16)>>6 for x in meta['sk_vaddr']}
path = sys.argv[2]
scope=[]; id2names={}
with open(path,'r',errors='ignore') as f:
    for line in f:
        s=line.strip()
        if s.startswith('$scope'): scope.append(s.split()[2])
        elif s.startswith('$upscope'):
            if scope: scope.pop()
        elif s.startswith('$var'):
            m=re.match(r'\$var\s+\S+\s+(\d+)\s+(\S+)\s+(\S+)',s)
            if m: id2names.setdefault(m.group(2),[]).append('.'.join(scope+[m.group(3)]))
        elif s.startswith('$enddefinitions'): break
def find(frag,suffix):
    for c,ns in id2names.items():
        for n in ns:
            if frag in n and n.endswith('.'+suffix): return c
sig={'vb_v':find('prefetcher.vbop_train_buf','io_enq_valid'),
     'vb_va':find('prefetcher.vbop_train_buf','io_enq_bits_vaddr'),
     'vb_rdy':find('prefetcher.vbop_train_buf','io_enq_ready'),
     'pb_v':find('prefetcher.pbop_train_buf','io_enq_valid'),
     'pb_va':find('prefetcher.pbop_train_buf','io_enq_bits_vaddr'),
     'pb_rdy':find('prefetcher.pbop_train_buf','io_enq_ready'),
     'rs':find('prefetcher.vbop_train_buf','io_enq_bits_reqsource')}
state={}; pend={}; cyc=0; vb=[]; pb=[]
watch={c for c in sig.values() if c}
with open(path,'r',errors='ignore') as f:
    ind=False
    for line in f:
        s=line.strip()
        if not s: continue
        if s[0]=='#':
            if ind and pend:
                for c,v in pend.items(): state[c]=v
                pend={}
            if ind:
                if state.get(sig['vb_v'])==1 and state.get(sig['vb_rdy'],1)==1:
                    vb.append((cyc,state.get(sig['vb_va'],-1),state.get(sig['rs'],-1)))
                if state.get(sig['pb_v'])==1 and state.get(sig['pb_rdy'],1)==1:
                    pb.append((cyc,state.get(sig['pb_va'],-1)))
            if ind: cyc=int(s[1:])
            continue
        if not ind:
            if s.startswith('$enddefinitions'): ind=True
            continue
        if s[0] in '01xzXZ':
            c,v=s[1:],s[0]
            if c in watch: pend[c]= 1 if v=='1' else 0
        elif s[0] in 'bB':
            p=s[1:].split(' ')
            if len(p)==2 and p[1] in watch:
                try: pend[p[1]]=int(p[0],2)
                except: pend[p[1]]=-1
vb_sk=[(t,va,rs) for t,va,rs in vb if va in SKIPS_LINE]
pb_sk=[t for t,va in pb if va in SKIPS_LINE]
from collections import Counter
print(f"VBOP train_buf enq fires: {len(vb)} | from NEVER-RETIRED loads: {len(vb_sk)}")
print(f"PBOP train_buf enq fires: {len(pb)} | from NEVER-RETIRED loads: {len(pb_sk)}")
print("reqsource(all):", dict(Counter(hex(r) for _,_,r in vb)))
print("reqsource(never-retired):", dict(Counter(hex(r) for _,_,r in vb_sk)))
for t,va,rs in vb_sk[:14]:
    print(f"  c={t} line=0x{va:x} base_va=0x{va<<6:x} reqsource=0x{rs:x}")
