#!/usr/bin/env python3
# vcd_bug5.py — b5b waveform analysis (v2): kill timing of prefetch-train fires
# usage: vcd_bug5.py list <vcd> | analyze <vcd>
import sys, re, json

meta = json.load(open('/tmp/b5b_skips.json'))
SKIPS = set(int(x, 16) for x in meta['sk_vaddr'])

def main():
    mode, path = sys.argv[1], sys.argv[2]

    scope, id2names = [], {}
    with open(path, 'r', errors='ignore') as f:
        for line in f:
            s = line.strip()
            if s.startswith('$scope'):
                scope.append(s.split()[2])
            elif s.startswith('$upscope'):
                if scope: scope.pop()
            elif s.startswith('$var'):
                m = re.match(r'\$var\s+\S+\s+(\d+)\s+(\S+)\s+(\S+)', s)
                if m:
                    full = '.'.join(scope + [m.group(3)])
                    id2names.setdefault(m.group(2), []).append(full)
            elif s.startswith('$enddefinitions'):
                break

    def find_unit_signal(unit, suffix):
        for c, names in id2names.items():
            for n in names:
                if n.endswith(f'.{suffix}') and f'{unit}.s2' in n:
                    return c
        return None

    units = {}
    for u in ['inner_LoadUnit_0', 'inner_LoadUnit_1', 'inner_LoadUnit_2']:
        d = {}
        for kind, suffix in [('train_v','io_prefetchTrain_valid'), ('train_va','io_prefetchTrain_bits_vaddr'),
                             ('train_pc','io_prefetchTrain_bits_pc'), ('fp','fire_probe'),
                             ('redir','io_redirect_valid')]:
            d[kind] = find_unit_signal(u, suffix)
        units[u] = d

    def find_scope_signal(scope_frag, suffix):
        for c, names in id2names.items():
            for n in names:
                if scope_frag in n and n.endswith(f'.{suffix}'):
                    return c
        return None
    meta_v = find_scope_signal('stride_meta_array', 'io_train_req_valid')
    meta_va = find_scope_signal('stride_meta_array', 'io_train_req_bits_vaddr')
    mem_redir = None
    for c, names in id2names.items():
        for n in names:
            if n.endswith('.memBlock.io_redirect_valid'):
                mem_redir = c; break

    if mode == 'list':
        for u, d in units.items():
            for k, c in d.items():
                print(f"{u}\t{k}\t{'FOUND' if c else '-'}\t{(id2names[c][0] if c else '')}")
        print('META_v', 'FOUND' if meta_v else '-', id2names.get(meta_v,[''])[0] if meta_v else '')
        print('memRedir', 'FOUND' if mem_redir else '-')
        return

    watch = {}
    for u, d in units.items():
        for k, c in d.items():
            if c: watch[c] = (u, k)
    if meta_v: watch[meta_v] = ('META', 'v')
    if meta_va: watch[meta_va] = ('META', 'va')
    if mem_redir: watch[mem_redir] = ('MEM', 'redir')

    state, pend, cur_cycle = {}, {}, 0
    trains, meta_fires, redir_pulses = [], [], []

    def process(t):
        for u, d in units.items():
            tv, fp = d.get('train_v'), d.get('fp')
            if tv and state.get(tv) == 1:
                va = state.get(d['train_va']) if d.get('train_va') else -1
                pc = state.get(d['train_pc']) if d.get('train_pc') else -1
                kill = (state.get(fp) == 0) if fp is not None else None
                skip = (va in SKIPS)   # strict: both load addrs of skipped iters are in SK; no -128 expansion
                trains.append(dict(cyc=t, unit=u, va=va, pc=pc, kill=kill, skip=skip))
            r = d.get('redir')
            if r and state.get(r) == 1:
                redir_pulses.append((t, u))
        if meta_v and state.get(meta_v) == 1:
            meta_fires.append((t, state.get(meta_va, -1)))
        if mem_redir and state.get(mem_redir) == 1:
            redir_pulses.append((t, 'MEM'))

    with open(path, 'r', errors='ignore') as f:
        in_dump = False
        for line in f:
            s = line.strip()
            if not s: continue
            if s[0] == '#':
                if in_dump and pend:
                    for c, v in pend.items(): state[c] = v
                    pend = {}
                if in_dump:
                    process(cur_cycle)
                cur_cycle = int(s[1:])
                continue
            if not in_dump:
                if s.startswith('$enddefinitions'): in_dump = True
                continue
            if s[0] in '01xzXZ':
                c, v = s[1:], s[0]
                if c in watch: pend[c] = 1 if v == '1' else 0
            elif s[0] in 'bB':
                p = s[1:].split(' ')
                if len(p) == 2 and p[1] in watch:
                    try: pend[p[1]] = int(p[0], 2)
                    except ValueError: pend[p[1]] = -1
    if pend:
        for c, v in pend.items(): state[c] = v
        process(cur_cycle)

    n_same = sum(1 for e in trains if e['kill'])
    n_skip = sum(1 for e in trains if e['skip'])
    n_esc = sum(1 for e in trains if (e['kill'] is False))
    print(f"== trace cycles: first={trains[0]['cyc'] if trains else '-'} last={trains[-1]['cyc'] if trains else '-'} ==")
    print(f"TRAIN fires offered at load-unit S2 : {len(trains)}")
    print(f"  kill==1 same cycle (one-line fix would suppress): {n_same}")
    print(f"  kill==0 at fire (timing escape or retired): {n_esc}")
    print(f"  from SKIPPED-iteration vaddr (load never retires): {n_skip}")
    print(f"META stride-table accepted fires: {len(meta_fires)}")
    late = []
    for e in trains:
        if e['kill'] is False:
            later = [t for (t, uu) in redir_pulses if uu == e['unit'] and e['cyc'] < t <= e['cyc'] + 15]
            if later:
                late.append((e['cyc'], e['unit'], hex(e['va']), later[0], e['skip']))
    print(f"  of the OFFERED trains, those followed by unit redirect <=15cyc: {len(late)}")
    print("-- first TRAIN events --")
    for e in trains[:14]:
        print(f"  c={e['cyc']} {e['unit']} va=0x{e['va']:x} pc=0x{e['pc']:x} kill@fire={e['kill']} skip={e['skip']}")
    print("-- skip-attributed events --")
    for e in [x for x in trains if x['skip']][:10]:
        print(f"  c={e['cyc']} {e['unit']} va=0x{e['va']:x} kill@fire={e['kill']}")
    print("-- timing-escape examples (fire, unit, va, redirect@, skip) --")
    for x in late[:10]:
        print("  ", x)
    print("-- meta (table) fires first 8 --")
    for t, va in meta_fires[:8]:
        print(f"  c={t} va=0x{va:x}")

main()
