  .section .text.init
  .globl _start
_start:
  li sp, 0x80100000
  la t0, trap
  csrw mtvec, t0
  csrw mie, zero
  csrci mstatus, 8
  .rept 64
  addi x30, x30, 1
  .endr
  li a0, 1000
  li a1, 7
  div a2, a0, a1
  .rept 300
  addi x31, x31, 1
  .endr
1:
  j 1b
trap:
  j trap
