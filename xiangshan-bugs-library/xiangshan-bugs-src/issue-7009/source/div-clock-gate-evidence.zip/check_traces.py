"""Check the recorded integer-divider clock-gating traces. Python 3."""
from pathlib import Path

BASE = Path(__file__).resolve().parent


def read_vcd(text):
    scopes, names, changes = [], {}, {}
    for line in text.splitlines():
        parts = line.split()
        if line.startswith("$scope "):
            scopes.append(parts[2])
        elif line.startswith("$upscope "):
            scopes.pop()
        elif line.startswith("$var "):
            names[parts[3]] = ".".join(scopes[1:] + [parts[4]])
        elif line.startswith("#"):
            now = int(line[1:])
            changes[now] = {}
        elif line.startswith(("0", "1", "b")):
            if line.startswith("b"):
                value, code = parts[0][1:], parts[1]
            else:
                value, code = line[0], line[1:]
            changes[now][names[code]] = int(value, 2)
    snapshots, values = {}, {}
    for now, updates in changes.items():
        values.update(updates)
        snapshots[now] = values.copy()
    return snapshots


def check(condition, detail):
    if not condition:
        raise SystemExit("Failed: " + detail)


def compare(normal, flushed):
    state = "Div.divDataModule.state"
    gate = "ClockGate_2.EN"
    output = "Div.io_out_valid"
    check(normal[8313][output] == normal[8313]["Div.io_out_ready"] == 1, "normal handshake")
    check(normal[8314][state] == 1 and normal[8315][gate] == 0, "normal gate closure")
    check(flushed[8346]["Div.divDataModule.io_kill_r"] == 1 and flushed[8346][state] == 8,
          "flush during iteration")
    check(8347 in flushed and max(flushed) == 9201, "recorded idle interval")
    for t, v in flushed.items():
        if t >= 8347:
            check((v[state], v["Div.io_in_valid"], v[output], v[gate]) == (1, 0, 0, 1),
                  f"expected idle divider with enabled gate at {t}")
    print("Normal:  handshake at 8313, idle at 8314, gate closes at 8315.")
    print("Flushed: kill at 8346, idle with gate enabled from 8347 through 9201.")


if __name__ == "__main__":
    compare(read_vcd((BASE / "normal.vcd").read_text()),
            read_vcd((BASE / "flushed.vcd").read_text()))
