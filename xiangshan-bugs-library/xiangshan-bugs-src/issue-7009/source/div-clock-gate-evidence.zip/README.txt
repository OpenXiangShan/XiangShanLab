These VCDs contain ten signals exported from the original Verilator FSTs.
Open the VCDs in GTKWave. Times below are the original trace timestamps,
in the source file's 1 ps timescale. The dump records one sample per step.

flushed.vcd   kill_iter4.fst          8200 .. 9201
normal.vcd    normal_gap_full.fst        0 .. 12005

Under exus_7, compare Div.divDataModule.state, Div.divDataModule.io_kill_r,
Div.io_out_valid, uncer_en_reg_2, and ClockGate_2.EN. The divider uses
one-hot state encoding (idle = 0x01, iterate = 0x08, finish = 0x40).

Flushed: at 8346 kill_r rises. At 8347 the state returns to idle.
ClockGate_2.EN stays high through 9201 and io_in_valid stays low.
Normal: at 8313 out_valid and out_ready are high. At 8314 the state is
idle and uncer_en_reg_2 is low. At 8315 ClockGate_2.EN falls.

perf-excerpts.txt contains the original divider counter lines from each
trace run. The runs have different lengths. clock_gate_en_div counts
enabled cycles. The flushed run prints its counters at 9205, after its
last waveform sample at 9201. Power was not measured.

Quick check: python3 check_traces.py
This reads both recorded waveforms. The normal control program is provided
as source and a flat binary under control/. An example normal control run
with a trace-enabled emulator is:

    /path/to/emu -i control/normal_gap.bin --no-diff -C 12000 --dump-wave --wave-path control.fst

The flushed case is supplied as a captured waveform.
