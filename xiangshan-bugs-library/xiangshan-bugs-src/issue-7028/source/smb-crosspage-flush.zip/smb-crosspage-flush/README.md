# smb-crosspage-flush reproduction

Bare-metal images for the XiangShan emu (kunminghu-v2, KunminghuV2Config, 1 core), loaded at 0x80000000.

- `src/rt.S`: minimal runtime (M-mode runner, trap handler, the test stub, final readback). `src/smbs2_*.S`: case files (defines, case table, page tables); each includes `rt.S`.
- `bin/`: the four images. `build.sh` rebuilds them with `riscv64-linux-gnu-gcc` 14.2.0 and checks `SHA256SUMS`.

Run:

```bash
./build/emu -i bin/smbs2_ncbr.bin --no-diff -C 3000000
./build/emu -i bin/smbs2_ncbr.bin -C 3000000
```

The last UART line has three fields: `p` = PA 0x80048FF8 (last dword of the lower page), `q` = PA 0x80049000 (the physical page after the lower page, never mapped), `r` = PA 0x8004A000 (the translated upper page). Correct result: `p4433221111111111 q2222222222222222 r3333333388776655`.
