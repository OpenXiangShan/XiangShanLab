#!/bin/sh
# Rebuild the four bare-metal images (load address 0x80000000) from src/ and check them against SHA256SUMS.
# Compiler used: riscv64-linux-gnu-gcc 14.2.0 (Debian 14.2.0-19).
set -e
cd "$(dirname "$0")"
mkdir -p bin
for t in smbs2_ncbr smbs2_nc48br smbs2_ncnb smbs2_cbr; do
  riscv64-linux-gnu-gcc -march=rv64gcv_h_zicboz -mabi=lp64d -nostdlib -static -no-pie -fno-pic -Isrc \
    -Wl,-N -Wl,-Ttext=0x80000000 -Wl,--build-id=none -o "bin/$t.elf" "src/$t.S"
  riscv64-linux-gnu-objcopy -O binary "bin/$t.elf" "bin/$t.bin"
  rm "bin/$t.elf"
done
sha256sum -c SHA256SUMS
