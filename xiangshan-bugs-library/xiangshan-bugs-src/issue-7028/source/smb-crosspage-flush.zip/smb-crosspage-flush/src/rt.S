# Minimal bare-metal runtime: an M-mode runner over case_table (8 dwords per case: mode (1 M, 2 S; 0 = end), stub,
#   t0, t1, satp, pad...), a trap handler, the test stub, and a final memory readback printed on the UART.
#define CODE      0x80000000
#define UART_TX   0x40600004


    .option norvc
    .option norelax
    .text
    .globl _start
_start:
    lla   t0, mtrap
    csrw  mtvec, t0
    li    t0, -1
    csrw  pmpaddr0, t0
    li    t0, 0x1f
    csrw  pmpcfg0, t0
    csrsi 0x744, 8              # mnstatus.NMIE = 1 (XiangShan Smrnmi)
    li    t0, 1 << 42
    csrc  mstatus, t0           # mstatus.MDT = 0 (no-op where Smdbltrp is absent)
    csrw  medeleg, zero
    csrw  mideleg, zero
    csrw  0x602, zero           # hedeleg
    csrw  0x603, zero           # hideleg
    csrw  mie, zero
    li    t0, 1 << 9
    csrs  mstatus, t0               # mstatus.VS = Initial
    csrs  0x200, t0                 # vsstatus.VS = Initial
#ifdef SMB_PBMT
    li    t0, 1
    slli  t0, t0, 62
    csrs  0x30a, t0                 # menvcfg.PBMTE: the older stores go to a PBMT=NC page (slow SQ drain)
#endif
    li    t0, 1 << 15
    csrw  medeleg, t0               # store page fault -> S
    lla   t0, RT_STRAP
    csrw  stvec, t0
    li    s11, 0

runner:
    lla   t2, case_table
    slli  t3, s11, 6
    add   t2, t2, t3
    ld    a0, 0(t2)             # mode
    beqz  a0, done
    ld    a1, 8(t2)             # stub
    ld    t0, 16(t2)
    ld    t1, 24(t2)
    ld    a2, 32(t2)            # satp
    ld    a3, 40(t2)            # vsatp
    ld    a4, 48(t2)            # hgatp
    csrw  satp, a2
    csrw  vsatp, a3
    csrw  hgatp, a4
    sfence.vma x0, x0
    hfence.gvma x0, x0
    hfence.vvma x0, x0
    li    t3, 1
    beq   a0, t3, run_m
    li    t3, (3 << 11) | (1 << 39)
    csrc  mstatus, t3           # MPP = U, MPV = 0
    li    t3, 1 << 11           # MPP = S
    li    t4, 3
    bne   a0, t4, 1f
    li    t4, 1 << 39           # MPV = 1 (VS)
    or    t3, t3, t4
1:  csrs  mstatus, t3
    csrw  mepc, a1
    mret
run_m:
    jr    a1

    .balign 64
mtrap:
    csrr  s1, mcause
    csrr  s2, mepc
    csrr  s3, mtval
    csrr  s4, 0x34b             # mtval2
    csrr  s5, 0x34a             # mtinst
rt_extra:
    csrr  s6, vstart
    csrr  s7, vl
    csrr  s8, mstatus
    li    a1, 'K'
    jal   putch
    mv    a1, s11
    jal   puthex
    li    a1, 'c'
    jal   putch
    mv    a1, s1
    jal   puthex
    li    a1, 'e'
    jal   putch
    mv    a1, s2
    jal   puthex
    li    a1, 't'
    jal   putch
    mv    a1, s3
    jal   puthex
    li    a1, 'g'
    jal   putch
    mv    a1, s4
    jal   puthex
    li    a1, 'i'
    jal   putch
    mv    a1, s5
    jal   puthex
    li    a1, 'v'
    jal   putch
    mv    a1, s6
    jal   puthex
    li    a1, 'l'
    jal   putch
    mv    a1, s7
    jal   puthex
    li    a1, 's'
    jal   putch
    mv    a1, s8
    jal   puthex
    fence rw, rw                    
    li    a1, 'p'
    jal   putch
    li    t0, MC_P1 + 0xFF8
    ld    a1, 0(t0)                 # low page, last dword (low 4 bytes of the cross-page store land at +0xFFC)
    jal   puthex
    li    a1, 'q'
    jal   putch
    li    t0, MC_P2
    ld    a1, 0(t0)                 # PA-next page of the low page (sentinel; the SQ fallback paddrHigh = low PA + 8 lands here)
    jal   puthex
    li    a1, 'r'
    jal   putch
    li    t0, MC_P3
    ld    a1, 0(t0)                 # the real high page
    jal   puthex
    li    a1, '\n'
    jal   putch
    addi  s11, s11, 1
    j     runner

done:
    li    a1, 'E'
    jal   putch
    li    a1, '\n'
    jal   putch
    li    a0, 0
    .insn r 0x6b, 0, 0, x0, a0, x0

putch:                          # a1 -> UART
    li    t5, UART_TX
    sb    a1, 0(t5)
    ret
puthex:                         # a1 -> 16 hex digits + ' '
    mv    t6, ra
    mv    a2, a1
    li    a3, 60
1:  srl   a1, a2, a3
    andi  a1, a1, 15
    li    a4, 10
    blt   a1, a4, 2f
    addi  a1, a1, 'a' - 10
    j     3f
2:  addi  a1, a1, '0'
3:  jal   putch
    addi  a3, a3, -4
    bgez  a3, 1b
    li    a1, ' '
    jal   putch
    mv    ra, t6
    ret

    .balign 16
stub_smbs:                          # SMB_CLOG older sd to cold lines at t1 (64 B apart), then a misaligned cross-page
    mv    a3, t1                    # sd at t0 (low page -> MC_P1, high page -> MC_P3, not PA-contiguous), then a tail:                    # cross-page sd at t0 (low page -> MC_P1, high page -> MC_P3, not PA-contiguous); then
    li    a2, SMB_CLOG              # SMB_TAIL 2 = 40 x (48 addi + one taken forward branch), 3 = 2000 addi (no redirect).
    beqz  a2, 2f                    # Then fence (drain) and ecall.
1:  sd    a2, 0(a3)
    addi  a3, a3, 64
    addi  a2, a2, -1
    bnez  a2, 1b
2:  li    a4, 0x8877665544332211
    sd    a4, 0(t0)
#if SMB_TAIL == 1
    li    a5, 0xACE1
    li    a6, 400
3:  andi  t3, a5, 1
    srli  a5, a5, 1
    beqz  t3, 4f
    li    t4, 0xB400
    xor   a5, a5, t4
4:  andi  t4, a5, 1
    beqz  t4, 5f
    addi  s0, s0, 1
5:  addi  a6, a6, -1
    bnez  a6, 3b
#elif SMB_TAIL == 2
    .rept 40                        
    .rept 48
    addi  s0, s0, 1
    .endr
    beq   x0, x0, 6f
    addi  s1, s1, 1
6:
    .endr
#elif SMB_TAIL == 3
    .rept 2000                      
    addi  s0, s0, 1
    .endr
#else
    .rept 1200
    addi  s0, s0, 1
    .endr
#endif
    fence rw, rw
    ecall
    .balign 4
strap_fence:                        # S trap handler: drain, then ecall
    fence rw, rw
    ecall

