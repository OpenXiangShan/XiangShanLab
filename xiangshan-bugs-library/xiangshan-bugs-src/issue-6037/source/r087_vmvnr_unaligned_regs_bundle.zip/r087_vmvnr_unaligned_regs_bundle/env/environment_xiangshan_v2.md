# Environment: r087_vmvnr_unaligned_regs

Repository:

```text
/nfs/home/nanyunhao/XiangShan_V2
```

Branch:

```text
kunminghu-v2
```

Commit:

```text
f3cc750109cc2a0ff6c12a920221f1a5a324bc75
```

EMU:

```text
/nfs/home/nanyunhao/XiangShan_V2/build/emu
emu compiled at May  8 2026, 14:44:21
```

NEMU REF:

```text
ref/riscv64-nemu-interpreter-so
```

V2 wave:

```text
/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r087_vmvnr_unaligned_regs/r087_vmvnr_unaligned_regs.fst
```

Checksums:

```text
2836a2ada959de4ec828abd8006fa8cd0ef61e2317166741f93d402904328755  bin/r087_vmvnr_unaligned_regs.bin
02418c458b90676ce1c2ba5fd372c1300191165a90320832f886b80e7926c694  bin/r087_vmvnr_unaligned_regs.elf
da4920bd2aef8d2f9b59b9c24885d2fdd12d3dd20d24b13244cee235d85b96a3  ref/riscv64-nemu-interpreter-so
446d7b80db216d004aa1c363c46aee61e003d80e0712efc3a1c0ddc3e9560a5b  wave/r087_vmvnr_unaligned_regs.fst
```

