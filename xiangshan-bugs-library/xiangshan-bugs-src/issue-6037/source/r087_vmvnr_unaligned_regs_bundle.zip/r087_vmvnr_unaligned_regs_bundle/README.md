# r087_vmvnr_unaligned_regs bundle

This bundle captures the `vmv<nr>r.v` register-alignment illegal-instruction mismatch.

## Key Failure

Instruction sequence:

```asm
vsetivli zero, 4, e32, m1, ta, ma
vmv2r.v v3, v5
```

NEMU REF reports illegal instruction:

```text
mcause right = 0x2
mepc   right = 0x800000c4
mtval  right = 0x9e50b1d7
```

DUT does not trap:

```text
mcause wrong = 0x0
mepc   wrong = 0x0
mtval  wrong = 0x0
```

Failure point:

```text
Core 0: ABORT at pc = 0x8000012c
Core-0 instrCnt = 57, cycleCnt = 8359
```

## Wave

V2 wave file:

```text
/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r087_vmvnr_unaligned_regs/r087_vmvnr_unaligned_regs.fst
```

Bundle hard link:

```text
wave/r087_vmvnr_unaligned_regs.fst
```

## Reproduce

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/emu \
  -b 0 -e 10000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r087_vmvnr_unaligned_regs_bundle/bin/r087_vmvnr_unaligned_regs.elf \
  --diff /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r087_vmvnr_unaligned_regs_bundle/ref/riscv64-nemu-interpreter-so \
  -C 10000 \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r087_vmvnr_unaligned_regs/r087_vmvnr_unaligned_regs.fst
```

## Contents

- `BUG_REPORT.md`: issue-format summary.
- `src/r087_vmvnr_unaligned_regs.S`: source testcase.
- `bin/r087_vmvnr_unaligned_regs.{elf,bin}`: testcase artifacts.
- `logs/r087_vmvnr_unaligned_regs.log`: original batch log.
- `logs/r087_vmvnr_unaligned_regs.wave.log`: V2 wave run log.
- `logs/r087_error_excerpt.txt`: compact mismatch excerpt.
- `instr/r087_vmvnr_unaligned_regs.objdump.txt`: disassembly.
- `instr/r087_commit_*_nemu.txt`: commit traces.
- `wave/r087_vmvnr_unaligned_regs.fst`: waveform.
- `ref/riscv64-nemu-interpreter-so`: NEMU REF used by the run.
- `summary/failing_case.tsv`: summary row for this case.

