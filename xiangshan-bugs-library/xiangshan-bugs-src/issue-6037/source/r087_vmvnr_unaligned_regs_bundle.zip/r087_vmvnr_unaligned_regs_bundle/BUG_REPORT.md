# Bug Report: `r087_vmvnr_unaligned_regs`

## Branch

`master (kunminghu-v2)`

## Describe the Bug

The reserved `vmv<nr>r.v` register-alignment case does not raise illegal instruction in DUT.

Instruction sequence:

```asm
vsetivli zero, 4, e32, m1, ta, ma
vmv2r.v v3, v5
```

For `vmv2r.v`, source and destination register numbers must be aligned for a two-register group. This testcase uses unaligned registers.

NEMU REF traps:

```text
mcause = 0x2
mepc   = 0x800000c4
mtval  = 0x9e50b1d7
```

DUT does not trap:

```text
mcause = 0x0
mepc   = 0x0
mtval  = 0x0
```

Key mismatch:

```text
mepc different at pc = 0x008000012c, right = 0x00000000800000c4, wrong = 0x0000000000000000
mtval different at pc = 0x008000012c, right = 0x000000009e50b1d7, wrong = 0x0000000000000000
mcause different at pc = 0x008000012c, right = 0x0000000000000002, wrong = 0x0000000000000000
Core 0: ABORT at pc = 0x8000012c
```

## Expected Behavior

`vmv2r.v v3, v5` should raise illegal instruction.

## Actual Behavior

DUT executes past the instruction without taking the illegal-instruction exception, then diverges from NEMU REF.

## Environment

Reference model:

```text
ref/riscv64-nemu-interpreter-so
```

V2 waveform:

```text
/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r087_vmvnr_unaligned_regs/r087_vmvnr_unaligned_regs.fst
```

## To Reproduce

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/emu \
  -b 0 -e 10000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r087_vmvnr_unaligned_regs_bundle/bin/r087_vmvnr_unaligned_regs.elf \
  --diff /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r087_vmvnr_unaligned_regs_bundle/ref/riscv64-nemu-interpreter-so \
  -C 10000 \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r087_vmvnr_unaligned_regs/r087_vmvnr_unaligned_regs.fst
```

## Attached Evidence

- `logs/r087_vmvnr_unaligned_regs.log`
- `logs/r087_vmvnr_unaligned_regs.wave.log`
- `logs/r087_error_excerpt.txt`
- `instr/r087_vmvnr_unaligned_regs.objdump.txt`
- `instr/r087_commit_group_trace_nemu.txt`
- `instr/r087_commit_instr_trace_nemu.txt`
- `src/r087_vmvnr_unaligned_regs.S`
- `bin/r087_vmvnr_unaligned_regs.{elf,bin}`
- `wave/r087_vmvnr_unaligned_regs.fst`
- `summary/failing_case.tsv`

