// Spike reference for candidate 0364: S-mode ecall delegated via medeleg while
// mnstatus.NMIE = 0 (Spike resets NMIE to 0 per norm:mnstatus_nmie_reset).
// Markers written to a0:
//   0x5A5A  S-mode handler (stvec) reached      <- expected per spec
//   0x600D  S-mode code resumed after the ecall
//   0x0BAD  M-mode handler (mtvec) reached      <- would mean the trap went to M
.section .text
.globl _start
_start:
    li   t0, -1
    csrw pmpaddr0, t0
    li   t0, 0x1f
    csrw pmpcfg0, t0
    la   t0, m_trap
    csrw mtvec, t0
    la   t0, s_trap
    csrw stvec, t0
    li   t0, 1 << 9              # delegate ecall-from-S
    csrw medeleg, t0
    csrr a1, mnstatus            # a1 = mnstatus (expect NMIE bit3 = 0)
    li   t0, 1 << 11
    csrs mstatus, t0             # MPP = S
    li   t0, 1 << 12
    csrc mstatus, t0
    la   t0, s_entry
    csrw mepc, t0
    mret

.align 4
s_entry:
    ecall
    li   a0, 0x600D
    j    done

.align 4
s_trap:
    csrr a2, scause
    csrr t0, sepc
    addi t0, t0, 4
    csrw sepc, t0
    li   a0, 0x5A5A
    sret

.align 4
m_trap:
    csrr a2, mcause
    li   a0, 0x0BAD
    j    done

done:
    j    done
