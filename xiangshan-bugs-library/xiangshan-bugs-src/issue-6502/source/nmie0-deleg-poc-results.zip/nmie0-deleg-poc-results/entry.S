.globl m_trap_entry
.align 4
m_trap_entry:
    # Reached via the (undelegated) S-mode ebreak in phase 1: resume M-mode
    # right after the entry `mret`.
    la   t0, return_to_mmode
    ld   t0, 0(t0)
    csrw 0x341, t0            # mepc
    csrr t1, 0x300            # mstatus
    li   t3, 0x1800           # MPP = M
    or   t1, t1, t3
    csrw 0x300, t1
    mret

.globl s_trap_entry
.align 4
s_trap_entry:
    # S-mode handler for the delegated ecall.
    la   t0, s_trap_count
    ld   t1, 0(t0)
    addi t1, t1, 1
    sd   t1, 0(t0)
    csrr t1, 0x142            # scause
    la   t0, s_scause
    sd   t1, 0(t0)
    csrr t1, 0x141            # sepc
    la   t0, s_sepc
    sd   t1, 0(t0)
    addi t1, t1, 4
    csrw 0x141, t1
    sret

.globl s_entry
.align 4
s_entry:
    ecall                     # cause 9, delegated -> stvec
    la   t0, phase
    ld   t0, 0(t0)
    li   t1, 2
    beq  t0, t1, 1f
    ebreak                    # phase 1: cause 3 not delegated -> mtvec -> back to M
1:
    la   sp, s_stack_top      # phase 2: stay in S-mode, report from here
    call s_report_and_park
2:  j 2b

.section .bss
.align 4
s_stack:
    .space 4096
s_stack_top:
