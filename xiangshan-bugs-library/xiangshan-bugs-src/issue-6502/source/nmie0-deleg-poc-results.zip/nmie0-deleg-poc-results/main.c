#include <klib.h>

// Candidate 0364: with mnstatus.NMIE = 0, an exception raised in S-mode and
// delegated through medeleg must still be delivered to the S-mode handler
// (stvec). Smrnmi only says NMIE=0 disables *interrupts*; the "unexpected trap
// -> critical error" rule (Smdbltrp) applies to traps taken while *executing in
// M-mode*. XiangShan gates trapEntryHSEvent.valid with mnstatus.NMIE and
// flags any trap with NMIE=0 as csr_dbltrp_inMN (critical error, commit
// blocked forever).
//
// Phase 1 (control): NMIE=1, S-mode ecall -> S handler -> back to M. Must work.
// Phase 2 (test)   : NMIE=0, S-mode ecall -> expected S handler, then S-mode
//                    code prints the verdict itself (never returns to M).
//                    On the buggy core the hart stops right at the ecall.

#define CSR_MSTATUS  0x300
#define CSR_MEDELEG  0x302
#define CSR_MTVEC    0x305
#define CSR_MEPC     0x341
#define CSR_STVEC    0x105
#define CSR_MNSTATUS 0x744
#define CSR_PMPCFG0  0x3a0
#define CSR_PMPADDR0 0x3b0

#define MSTATUS_MPP_MASK (3UL << 11)
#define MSTATUS_MPP_S    (1UL << 11)
#define MSTATUS_MIE      (1UL << 3)
#define MNSTATUS_NMIE    (1UL << 3)

volatile unsigned long s_trap_count, s_scause, s_sepc, phase;
volatile unsigned long return_to_mmode;

extern void m_trap_entry(void);
extern void s_trap_entry(void);
extern void s_entry(void);

static inline unsigned long rd_mnstatus(void)
{
    unsigned long v;
    asm volatile("csrr %0, %1" : "=r"(v) : "i"(CSR_MNSTATUS));
    return v;
}

static void enter_smode(void)
{
    unsigned long mstatus;
    asm volatile("csrr %0, %1" : "=r"(mstatus) : "i"(CSR_MSTATUS));
    mstatus = (mstatus & ~MSTATUS_MPP_MASK) | MSTATUS_MPP_S;
    mstatus &= ~MSTATUS_MIE;
    asm volatile("csrw %0, %1" :: "i"(CSR_MSTATUS), "r"(mstatus) : "memory");
    asm volatile("csrw %0, %1" :: "i"(CSR_MEPC), "r"((unsigned long)s_entry) : "memory");
    asm volatile("la %0, 1f" : "=r"(return_to_mmode));
    asm volatile("mret\n1:" ::: "memory");
}

// Called from S-mode (phase 2 only): report and park.
void s_report_and_park(void)
{
    printf("[phase2] S handler reached: count=%lu scause=%lu sepc=%lx  mnstatus.NMIE was 0\n",
           s_trap_count, s_scause, s_sepc);
    printf("[phase2] RESULT: delegated exception delivered to stvec with NMIE=0 (spec/Spike behaviour)\n");
    printf("=== NO BUG: hart handled the delegated trap normally ===\n");
    for (;;)
        asm volatile("wfi");
}

int main(void)
{
    // PMP: allow everything so S-mode can fetch/load/store (NAPOT, RWX).
    asm volatile("csrw %0, %1" :: "i"(CSR_PMPADDR0), "r"(-1UL) : "memory");
    asm volatile("csrw %0, %1" :: "i"(CSR_PMPCFG0), "r"(0x1fUL) : "memory");

    asm volatile("csrw %0, %1" :: "i"(CSR_MTVEC), "r"((unsigned long)m_trap_entry) : "memory");
    asm volatile("csrw %0, %1" :: "i"(CSR_STVEC), "r"((unsigned long)s_trap_entry) : "memory");
    // delegate "environment call from S-mode" (cause 9) to S-mode
    asm volatile("csrw %0, %1" :: "i"(CSR_MEDELEG), "r"(1UL << 9) : "memory");

    printf("=== 0364: delegated S-mode exception while mnstatus.NMIE=0 ===\n");
    unsigned long mn = rd_mnstatus();
    printf("mnstatus at reset = 0x%lx (NMIE=%lu)\n", mn, (mn >> 3) & 1);

    if (mn & MNSTATUS_NMIE) {
        // Core resets with NMIE=1 (pre-#6100): run a control pass first, then
        // clear NMIE by software (allowed on those builds) for the real test.
        // ---- Phase 1: control, NMIE = 1 ----
        phase = 1;
        s_trap_count = 0;
        enter_smode();
        printf("[phase1] NMIE=1: S ecall -> S handler count=%lu scause=%lu, then ebreak -> M: %s\n",
               s_trap_count, s_scause, (s_trap_count == 1 && s_scause == 9) ? "OK" : "UNEXPECTED");

        asm volatile("csrc %0, %1" :: "i"(CSR_MNSTATUS), "r"(MNSTATUS_NMIE) : "memory");
        mn = rd_mnstatus();
        printf("[phase2] after csrc mnstatus.NMIE: mnstatus=0x%lx NMIE=%lu\n", mn, (mn >> 3) & 1);
        if (mn & MNSTATUS_NMIE) {
            printf("[phase2] NMIE cannot be cleared by software on this build and it reset to 1 "
                   "-> NMIE=0 only reachable via RNMI entry; cannot test here\n");
            return 0;
        }
    } else {
        // Core resets with NMIE=0 (spec reset value, kunminghu-v2 >= #6100 / v3):
        // this *is* the state under test; firmware simply has not written
        // mnstatus.NMIE=1 yet. Go straight to phase 2 (no control pass, since
        // NMIE cannot be cleared again once set).
        printf("[phase2] NMIE=0 is the reset state on this core; testing directly\n");
    }

    // ---- Phase 2: NMIE = 0 ----
    phase = 2;
    s_trap_count = 0;
    printf("[phase2] entering S-mode and executing a delegated ecall with NMIE=0 ...\n");
    printf("[phase2] (if nothing is printed after this line, the hart stopped = critical error)\n");
    enter_smode();
    // not reached: phase 2 never returns to M-mode
    printf("[phase2] unexpected return to M-mode\n");
    return 1;
}
