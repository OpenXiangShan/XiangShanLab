# Title

[Bug] Any trap taken while mnstatus.NMIE=0 is treated as an M-mode double trap (critical error), including exceptions raised in S/U-mode and delegated via medeleg

# Before start

- [x] I have read the RISC-V ISA Manual and XiangShan Documents, and I believe this is a XiangShan RTL issue.
- [x] I have searched previous issues and PRs and did not find anything relevant.
- [x] I have reproduced the issue using the latest commit on the default branch.
- [x] If this report was generated with AI assistance, I have verified the correctness of its content.

# Branch

kunminghu-v2 (same logic on kunminghu-v3)

# Describe the bug

`NewCSR` gates every trap-entry event with `mnstatus.NMIE` and flags any trap that occurs while `NMIE=0` as a critical error, regardless of the privilege mode the trap comes from:

```scala
// NewCSR.scala (kunminghu-v2 HEAD 5d393413 L801-804; v3 HEAD 14af5521 L836-839)
trapEntryMEvent .valid := hasTrap && entryPrivState.isModeM  && ... && mnstatus.regOut.NMIE
trapEntryHSEvent.valid := hasTrap && entryPrivState.isModeHS && ... && mnstatus.regOut.NMIE
trapEntryVSEvent.valid := hasTrap && entryPrivState.isModeVS && ... && mnstatus.regOut.NMIE
// L1519 / v3 L1624
val criticalErrors = Seq(("csr_dbltrp_inMN", !mnstatus.regOut.NMIE && hasTrap && !(entryDebugMode || debugMode)))
```

`criticalErrorState` then blocks ROB commit forever (`Rob.scala`: `blockCommit ... || criticalErrorState`), so the hart stops.

The spec only allows this for traps taken **while executing in M-mode**:

- `smrnmi.adoc`, `norm:mnstatus_nmie_disable`: "When NMIE=0, *all interrupts* are disabled." — nothing about exceptions.
- `machine.adoc`, `norm:trap_unexp_mnstatus_nmie_0`: "a trap that occurs when executing in M-mode with mnstatus.nmie set to 0 is an *unexpected trap*"; only an unexpected trap with Smrnmi implemented and NMIE=0 enters the critical-error state (`norm:trap_unexp_hndl_no_rnmi`).
- An exception raised in S/U-mode with the corresponding `medeleg` bit set is delegated to the S-mode handler unconditionally (3.1.8); it is never "taken into M-mode", so neither the MDT nor the NMIE double-trap rules apply. An S/U-mode exception that is *not* delegated goes to M-mode with MDT=0 → "delivered as expected" (`norm:trap_exp`).

Spike agrees: `processor_t::take_trap` decides delegation from `medeleg`/`hsdeleg` without looking at `nmie` (`processor.cc:431-475`); `nmie` is only used to mask interrupts (`:323`) and, for M-mode-bound traps, to choose the RNMI vector / critical error (`:510-518`). Verified with the attached bare-metal test on Spike `3e7bf30d` (`--isa=rv64gc_smrnmi_smdbltrp`, NMIE=0 at reset): S-mode `ecall` with `medeleg[9]=1` enters `stvec`, `scause=9`, `sret` resumes.

**Reachability.** On 2e148b4 `NMIE` resets to 1 and software may clear it (`MachineLevel.scala:416-421`, guard commented out), so `csrc mnstatus, 8` + `mret` to S-mode is enough. Since #6100 (`ed11f636b`, 2026-07-10, also on v3) `NMIE` resets to **0** and cannot be cleared — which is the spec reset value, but it also means NMIE=0 is now simply the state of the hart until firmware executes `csrs mnstatus, NMIE`. Upstream OpenSBI does that when it detects Smrnmi (`sbi_hart.c:507`), so a normal Linux boot is not affected; any firmware/bare-metal that does not know Smrnmi, a DT without `smrnmi`, or an RNMI handler that returns with `mret` instead of `mnret`, will hit the first S/U-mode `ecall`/page fault → hart stops. The M-mode part of the rule (trap in M-mode with NMIE=0 → critical error) is correct and should stay.

Note that NEMU has the same deviation (`src/isa/riscv64/system/intr.c:114`: any trap with `!mnstatus->nmie` → critical error, before the delegation check), so difftest cannot catch this.

# Expected behavior

With `mnstatus.NMIE=0`, `medeleg[9]=1`, `stvec=S_handler`: an `ecall` executed in S-mode traps to `S_handler` with `scause=9`, `sepc=pc_of_ecall`, and `sret` returns normally (Spike behaviour, spec 3.1.8 / Smrnmi / Smdbltrp).

Actual: no trap entry is generated, `criticalErrorState` is set, commit is blocked, the hart never executes another instruction.

# Environment

- XiangShan branch: kunminghu-v2, commit `2e148b4` (2026-03-16, v3.2.2-alpha-1084-g2e148b41d), DefaultConfig (`--issue E.b`). Cited lines checked unchanged on kunminghu-v2 HEAD `5d393413` (2026-09-02) and kunminghu-v3 HEAD `14af5521` (2026-09-05); the intervening NMIE-related commits (#5730, #5806, #6075, #6100, #6224, #6256, #6258) do not touch the gating.
- NEMU `67da68a2` (ready-to-run e79a631) — shares the bug; Spike `3e7bf30d` (upstream riscv-isa-sim, used as reference for the bare-metal test); difftest `7b5fc3bb2`, utility `fcb82239`.

# To Reproduce

Attached `nmie0-deleg-poc` (nexus-am, M-mode start). It programs PMP allow-all, `mtvec`, `stvec`, `medeleg = 1<<9`, then:

- If `NMIE` reads 1 at reset (2e148b4): phase 1 control — `mret` to S, `ecall` → S handler → `ebreak` → back to M (works); then `csrc mnstatus, 8`.
- If `NMIE` reads 0 at reset (v2 ≥ #6100 / v3): the reset state is already the state under test; nothing is written to `mnstatus`.
- Phase 2: `mret` to S-mode, `ecall`. The S-mode code prints the verdict itself (it can never return to M with NMIE=0).

```
make ARCH=riscv64-xs
./build/emu -i nmie0-deleg-poc-riscv64-xs.bin --no-diff -C 400000
```

Output on 2e148b4 (nothing after the last line; emu spins until the cycle cap):

```
=== 0364: delegated S-mode exception while mnstatus.NMIE=0 ===
mnstatus at start = 0x8 (NMIE=1)
[phase1] NMIE=1: S ecall -> S handler count=1 scause=9, then ebreak -> M: OK
[phase2] after csrc mnstatus.NMIE: mnstatus=0x0 NMIE=0
[phase2] entering S-mode and executing a delegated ecall with NMIE=0 ...
[phase2] (if nothing is printed after this line, the hart stopped = critical error)
```

Expected (what Spike does; `spike_ref_test.S` + `cmds.txt` in the attachment): pc enters `stvec`, priv=S, `scause=9`, `sret` returns, execution continues.

Minimal sequence (S-mode, `medeleg[9]=1`, `mnstatus.NMIE=0`):

```
# M-mode
li t0, 1<<9 ; csrw medeleg, t0
la t0, s_handler ; csrw stvec, t0
# (NMIE is 0 out of reset on current v2/v3; on 2e148b4: csrc mnstatus, 8)
li t0, 1<<11 ; csrs mstatus, t0 ; li t0, 1<<12 ; csrc mstatus, t0   # MPP = S
la t0, s_code ; csrw mepc, t0 ; mret
s_code:
ecall            # expected: s_handler, scause=9. XiangShan: critical error, hart stops
```

# Additional context

Suggested fix: qualify the double-trap classification by the *origin* mode. `csr_dbltrp_inMN` should be `!NMIE && hasTrap && privState.isModeM` (trap taken while executing in M-mode), and `trapEntryHSEvent/VSEvent.valid` should not be gated by `NMIE` at all (interrupts are already masked when NMIE=0, so only exceptions reach them). For S/U → M exceptions with NMIE=0 the MDT rule applies as usual (`norm:trap_exp`). NEMU needs the same change for difftest to be able to check this.

Files: `NewCSR.scala` (trap entry valids, `criticalErrors`), `TrapHandleModule.scala` (`dbltrpToMN`).
