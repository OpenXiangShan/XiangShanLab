// PtwCache: stage1 cf of an l0 hit taken from the check stage (kunminghu-v2).
// The l0-hit response takes stage1.entry(i).cf from l0cfs, which follows the request currently in the check stage.
// When the next request has entered the check stage, the response carries that request's bitmap vector. With bitmap
// checking on, the L2TLB marks sibling lanes valid by cf equality (ptwResp_to_sector_4kptwResp), so the L1 DTLB can
// receive a lane whose bitmap check did not pass.
//   S0 = VA 0x8060_0000 + i pages -> PA 0x8030_0000 + i pages, S1 = VA 0x8060_8000 + i pages -> PA 0x8030_8000 + i pages
//   (adjacent leaf sectors, different page-cache sets); the bitmap denies page 5 of each (PA 0x8030_5000, 0x8030_d000).
//   prefix: ld S0 p0 (load DTLB walk, only S0 p0 checked), sd S1 p2 (store DTLB walk, only S1 p2 checked)
//   pair:   sd S0 p0 (store DTLB miss) and ld S1 p2 (load DTLB miss) in the same cycle: both addresses depend on one divide
//           result; -DSKEW=n delays the load address by n dependent adds (n < 0: the store address by -n); -DLDST puts the
//           load first in program order
//   targets: sd S0 p5 (store DTLB), ld S1 p5 (load DTLB): both must raise access faults (bitmap bit 1)
// Variants: -DCTL_SEP fence between the two pair accesses; -DCTL_DIRECT no prefix and no pair; -DNODENY bitmap all zero.
// Exit: a0 = code, then the custom trap instruction (.insn r 0x6b, rs1 = a0); identify the code by the trap PC (README.md).
//   a0 = 2*st_ok + ld_ok, where *_ok = the target access did NOT fault (= the denied page was accessed).
//   91 prefix load value wrong, 92 target load value wrong, 97/98 unexpected trap. Correct result: 0 (3 with -DNODENY).
// mbmc (CSR 0xbc2): BMA = 0x1_0000_0000, BME = 1, CMODE = 0. Bitmap word for PPN p at BMA + (p >> 6) * 8, bit p & 63,
// bit 1 = denied.

#define PT_ROOT   0x80010000
#define PT_L1     0x80011000
#define PT_L0     0x80012000
#define VS0       0x80600000
#define VS1       0x80608000
#define PS0       0x80300000
#define PS1       0x80308000
#define BWORD     0x100010060          /* BMA + (0x80305 >> 6) * 8 = BMA + 0x200c * 8 (0x8030d: same word) */
#define DENY      ((1 << 5) | (1 << 13))  /* PPN 0x80305 -> bit 5, 0x8030d -> bit 13 */
#define MBMC_ON   0x100000004          /* BMA = 0x1_0000_0000, BME = 1, CMODE = 0 */
#define SENT      0x5a5a000000000000
#define LEAF      0xc7                 /* V R W A D */
#ifndef SKEW
#define SKEW 0
#endif

.macro EXIT code
  li a0, \code
  .insn r 0x6b, 0, 0, x0, a0, x0
1:
  j 1b
.endm

  .section .text.init
  .option norvc
  .globl _start
_start:
  la t0, m_trap
  csrw mtvec, t0
  li t0, -1
  csrw pmpaddr0, t0
  li t0, 0x1f                          // NAPOT RWX over everything
  csrw pmpcfg0, t0
  csrsi 0x744, 8                       // mnstatus.NMIE = 1
  csrwi 0x5c1, 0                       // L1 prefetchers off
  li t0, PT_ROOT                       // zero PT_ROOT, PT_L1, PT_L0
  li t1, 1536
0:
  sd zero, 0(t0)
  addi t0, t0, 8
  addi t1, t1, -1
  bnez t1, 0b
  li s0, PT_ROOT
  li t1, ((PT_L1 >> 12) << 10) | 0x01  // VA 0x8000_0000..0xBFFF_FFFF -> PT_L1
  sd t1, 16(s0)
  li t0, PT_L1
  li t1, ((0x80000000 >> 12) << 10) | 0xcf   // 2 MiB identity leaf 0 (code, tables): D A X W R V
  sd t1, 0(t0)
  li t1, ((PT_L0 >> 12) << 10) | 0x01  // 2 MiB slot 3 (VA 0x8060_0000) -> PT_L0; the data PAs have no other mapping
  sd t1, 24(t0)
  li t0, PT_L0                         // 16 leaves: S0 p0..7, S1 p0..7
  li t1, ((PS0 >> 12) << 10) | LEAF
  li t2, 1 << 10                       // PPN + 1
  li t3, 16
1:
  sd t1, 0(t0)
  add t1, t1, t2
  addi t0, t0, 8
  addi t3, t3, -1
  bnez t3, 1b
  li t0, PS0                           // sentinel SENT | pa at offset 0 of each data page
  li t1, SENT | PS0
  li t2, 0x1000
  li t3, 16
2:
  sd t1, 0(t0)
  add t0, t0, t2
  add t1, t1, t2
  addi t3, t3, -1
  bnez t3, 2b
  li t0, BWORD
#ifdef NODENY
  sd zero, 0(t0)
#else
  li t1, DENY
  sd t1, 0(t0)
#endif
  fence rw, rw
  li t0, MBMC_ON
  csrw 0xbc2, t0
  srli t0, s0, 12
  li t1, 8
  slli t1, t1, 60                      // Sv39
  or t0, t0, t1
  csrw satp, t0
  sfence.vma
  li t0, 0x1800
  csrc mstatus, t0
  li t0, 0x0800                        // MPP = S
  csrs mstatus, t0
  la t0, s_entry
  csrw mepc, t0
  mret

  .balign 64
s_entry:
  li s1, VS0                           // S0 p0
  li s2, VS1 + 0x2000                  // S1 p2
  li s3, VS0 + 0x5000                  // target S0 p5 (store)
  li s4, VS1 + 0x5000                  // target S1 p5 (load)
  li s5, 0x7fffffffffff0000            // divide chain operands (fixed latency)
  li s6, 3
  li s10, 0                            // store target faulted
  li s11, 0                            // load target faulted
#ifndef CTL_DIRECT
  ld a1, 0(s1)                         // prefix: S0 p0 through the load DTLB
  fence rw, rw
  li t0, SENT | PS0
  beq a1, t0, 3f
  EXIT 91
3:
  sd t0, 0(s2)                         // prefix: S1 p2 through the store DTLB (value irrelevant)
  fence rw, rw
  mv a4, s1                            // pair bases, pre-adjusted for the +1 delay adds (addi rd, rd, 0 would be a
  mv a5, s2                            // move and could be eliminated at rename)
#if SKEW > 0
  addi a5, a5, -(SKEW)
#elif SKEW < 0
  addi a4, a4, SKEW
#endif
  li t1, 1                             // pair: both addresses wait for the same divide result (t1 & 0 = 0)
  .rept 3
  or t1, t1, s5
  divu t1, t1, s6
  .endr
  andi t1, t1, 0
  mv t2, t1                            // store address delay chain
  mv t3, t1                            // load address delay chain
#if SKEW > 0
  .rept SKEW
  addi t3, t3, 1
  .endr
#elif SKEW < 0
  .rept -(SKEW)
  addi t2, t2, 1
  .endr
#endif
  add t2, t2, a4                       // S0 p0
  add t3, t3, a5                       // S1 p2
  li t4, 0x77
#ifdef LDST
  ld a2, 0(t3)
#ifdef CTL_SEP
  fence rw, rw
#endif
  sd t4, 0(t2)
#else
  sd t4, 0(t2)
#ifdef CTL_SEP
  fence rw, rw
#endif
  ld a2, 0(t3)
#endif
  fence rw, rw
#endif
  .globl tgt_st
tgt_st:
  sd t4, 0(s3)                         // denied S0 p5 through the store DTLB
  fence rw, rw
  li a3, 0
  .globl tgt_ld
tgt_ld:
  ld a3, 0(s4)                         // denied S1 p5 through the load DTLB
  fence rw, rw
  bnez s11, 4f                         // load target did not fault: it must have read the denied page
  li t0, SENT | (PS1 + 0x5000)
  beq a3, t0, 4f
  EXIT 92
4:
  li t0, 1
  sub t1, t0, s10                      // st_ok
  sub t2, t0, s11                      // ld_ok
  slli t1, t1, 1
  or t1, t1, t2
  .irp code, 0, 1, 2, 3
  li t0, \code
  bne t1, t0, 9f
  EXIT \code
9:
  .endr
  EXIT 99

  .balign 64
m_trap:                                // S-mode faults are not delegated
  csrr t0, mcause
  csrr t1, mepc
  li t2, 5                             // load access fault
  beq t0, t2, 5f
  li t2, 7                             // store/AMO access fault
  beq t0, t2, 5f
  EXIT 98
5:
  la t2, tgt_st
  bne t1, t2, 6f
  li s10, 1
  j 7f
6:
  la t2, tgt_ld
  bne t1, t2, 8f
  li s11, 1
  j 7f
8:
  EXIT 97
7:
  addi t1, t1, 4
  csrw mepc, t1
  mret
