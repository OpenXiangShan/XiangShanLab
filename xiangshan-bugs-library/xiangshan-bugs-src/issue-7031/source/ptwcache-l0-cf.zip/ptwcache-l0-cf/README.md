# PtwCache stage1 `cf` from the check stage: reproduction

## Files

| File | Content |
|---|---|
| `repro.S` | Test program. Bare metal, loaded at 0x80000000. M-mode builds an Sv39 page table and the bitmap, sets `mbmc` (BME = 1, CMODE = 0), and S-mode runs the test. The header comment describes the layout. |
| `repro_ld.bin` | `repro.S -DSKEW=0`. Store and load of the pair become ready in the same cycle. |
| `repro_st.bin` | `repro.S -DSKEW=1`. The load address of the pair is ready one `addi` later. |
| `control.bin` | `repro.S -DCTL_SEP`. As `repro_ld.bin`, with a fence between the store and the load of the pair. |
| `build.sh` | Rebuilds the three images and checks `SHA256SUMS`. Needs `clang-19`, `riscv64-linux-gnu-ld` and `llvm-objcopy-19` (override with `CLANG`, `RVLD`, `OBJCOPY`). |

Layout: S0 = VA 0x80600000 + i pages -> PA 0x80300000 + i pages, S1 = VA 0x80608000 + i pages -> PA 0x80308000 + i pages (i = 0..7). The bitmap (base 0x1_0000_0000) denies PA 0x80305000 and 0x8030d000 (page 5 of each sector).

Sequence: ld S0 page 0; sd S1 page 2; then the pair sd S0 page 0 and ld S1 page 2; then the targets sd S0 page 5 and ld S1 page 5. Both targets must raise access faults. The M-mode handler records a fault on a target and skips the instruction.

## Run

```bash
./build/emu -i repro_ld.bin --no-diff -C 200000
./build/emu -i repro_st.bin --no-diff -C 200000
./build/emu -i control.bin  --no-diff -C 200000
```

With difftest, the reference must implement the bitmap check: build NEMU master with `riscv64-xs-ref_defconfig` plus `CONFIG_RV_MBMC=y`, then

```bash
./build/emu -i repro_ld.bin --diff <nemu-mbmc>/build/riscv64-nemu-interpreter-so -C 400000
```

The two repro images stop at the target access (the reference raises the access fault, the DUT does not); `control.bin` runs to `HIT GOOD TRAP`.

## Reading the result

The program ends with `li a0, CODE` and the trap instruction (`.insn r 0x6b, 0, 0, x0, a0, x0`). The v2 emu prints code 0 as `HIT GOOD TRAP`, 1 as `HIT BAD TRAP`, 2 as `ABORT` and 3 as `EXCEEDING CYCLE/INSTR LIMIT`. Use the trap PC to tell a program exit from an emu stop.

CODE = 2 * st_ok + ld_ok, where st_ok = 1 if the store to S0 page 5 did not fault, and ld_ok = 1 if the load from S1 page 5 did not fault (it must then return the word at PA 0x8030d000, otherwise the code is 92). Other codes: 91 = the first load returned a wrong value, 97 / 98 = unexpected trap, 99 = no code matched. The correct result is 0.

| CODE | trap PC in `repro_ld.bin` | trap PC in `repro_st.bin` | trap PC in `control.bin` |
|---|---|---|---|
| 0 | 0x80000298 | 0x800002a0 | 0x8000029c |
| 1 | 0x800002ac | 0x800002b4 | 0x800002b0 |
| 2 | 0x800002c0 | 0x800002c8 | 0x800002c4 |
| 3 | 0x800002d4 | 0x800002dc | 0x800002d8 |

Other codes: run `riscv64-linux-gnu-objdump -D -b binary -m riscv:rv64 --adjust-vma=0x80000000 <image>` and read the `li a0` just before the trap PC.
