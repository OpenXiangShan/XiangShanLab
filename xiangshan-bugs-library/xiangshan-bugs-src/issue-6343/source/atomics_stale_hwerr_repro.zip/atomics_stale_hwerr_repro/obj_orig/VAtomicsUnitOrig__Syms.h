// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VATOMICSUNITORIG__SYMS_H_
#define VERILATED_VATOMICSUNITORIG__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "VAtomicsUnitOrig.h"

// INCLUDE MODULE CLASSES
#include "VAtomicsUnitOrig___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) VAtomicsUnitOrig__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    VAtomicsUnitOrig* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    VAtomicsUnitOrig___024root     TOP;

    // CONSTRUCTORS
    VAtomicsUnitOrig__Syms(VerilatedContext* contextp, const char* namep, VAtomicsUnitOrig* modelp);
    ~VAtomicsUnitOrig__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
