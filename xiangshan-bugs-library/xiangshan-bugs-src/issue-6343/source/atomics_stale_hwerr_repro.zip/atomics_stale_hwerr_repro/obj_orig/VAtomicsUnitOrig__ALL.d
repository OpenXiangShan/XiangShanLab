VAtomicsUnitOrig__ALL.o: VAtomicsUnitOrig__ALL.cpp VAtomicsUnitOrig.cpp \
  VAtomicsUnitOrig__pch.h /usr/local/share/verilator/include/verilated.h \
  /usr/local/share/verilator/include/verilated_config.h \
  /usr/local/share/verilator/include/verilatedos.h \
  /usr/local/share/verilator/include/verilated_types.h \
  /usr/local/share/verilator/include/verilated_funcs.h \
  VAtomicsUnitOrig__Syms.h VAtomicsUnitOrig.h \
  VAtomicsUnitOrig___024root.h VAtomicsUnitOrig___024root__0.cpp \
  VAtomicsUnitOrig__ConstPool__0__Slow.cpp \
  VAtomicsUnitOrig___024root__Slow.cpp \
  VAtomicsUnitOrig___024root__0__Slow.cpp \
  VAtomicsUnitOrig__Syms__Slow.cpp
