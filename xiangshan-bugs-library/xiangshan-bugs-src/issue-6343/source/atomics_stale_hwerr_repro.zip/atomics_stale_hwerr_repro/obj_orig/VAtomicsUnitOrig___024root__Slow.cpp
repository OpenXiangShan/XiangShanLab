// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VAtomicsUnitOrig.h for the primary calling header

#include "VAtomicsUnitOrig__pch.h"

void VAtomicsUnitOrig___024root___ctor_var_reset(VAtomicsUnitOrig___024root* vlSelf);

VAtomicsUnitOrig___024root::VAtomicsUnitOrig___024root(VAtomicsUnitOrig__Syms* symsp, const char* namep)
 {
    vlSymsp = symsp;
    vlNamep = strdup(namep);
    // Reset structure values
    VAtomicsUnitOrig___024root___ctor_var_reset(this);
}

void VAtomicsUnitOrig___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

VAtomicsUnitOrig___024root::~VAtomicsUnitOrig___024root() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}
