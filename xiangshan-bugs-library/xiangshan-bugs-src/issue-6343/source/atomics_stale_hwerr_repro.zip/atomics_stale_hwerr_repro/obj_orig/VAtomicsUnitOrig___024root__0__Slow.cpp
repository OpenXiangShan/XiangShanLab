// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VAtomicsUnitOrig.h for the primary calling header

#include "VAtomicsUnitOrig__pch.h"

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_static(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_static\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__clock__0 = vlSelfRef.clock;
    vlSelfRef.__Vtrigprevexpr___TOP__reset__0 = vlSelfRef.reset;
}

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_initial(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_initial\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_final(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_final\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitOrig___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool VAtomicsUnitOrig___024root___eval_phase__stl(VAtomicsUnitOrig___024root* vlSelf);

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_settle(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_settle\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            VAtomicsUnitOrig___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/home/lhf/project/xiangshan/xs-env/XiangShan/build/rtl/AtomicsUnit.sv", 58, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = VAtomicsUnitOrig___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_triggers_vec__stl(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_triggers_vec__stl\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
}

VL_ATTR_COLD bool VAtomicsUnitOrig___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitOrig___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(VAtomicsUnitOrig___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool VAtomicsUnitOrig___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

extern const VlUnpacked<CData/*4:0*/, 512> VAtomicsUnitOrig__ConstPool__TABLE_heef4d9af_0;

VL_ATTR_COLD void VAtomicsUnitOrig___024root___stl_sequent__TOP__0(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___stl_sequent__TOP__0\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    QData/*63:0*/ AtomicsUnit__DOT___rs2_T;
    AtomicsUnit__DOT___rs2_T = 0;
    CData/*4:0*/ AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60;
    AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60 = 0;
    SData/*10:0*/ AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6;
    AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6 = 0;
    SData/*8:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    vlSelfRef.io_out_bits_uop_exceptionVec_5 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_5;
    vlSelfRef.io_out_bits_uop_exceptionVec_7 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_7;
    vlSelfRef.io_out_bits_uop_exceptionVec_13 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_13;
    vlSelfRef.io_out_bits_uop_exceptionVec_15 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_15;
    vlSelfRef.io_out_bits_uop_exceptionVec_21 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_21;
    vlSelfRef.io_out_bits_uop_exceptionVec_23 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_23;
    vlSelfRef.io_dcache_req_bits_vaddr = (0x0003ffffffffffc0ULL 
                                          & vlSelfRef.AtomicsUnit__DOT__rs1);
    vlSelfRef.io_dcache_req_bits_addr = (0x0000ffffffffffc0ULL 
                                         & vlSelfRef.AtomicsUnit__DOT__paddr);
    vlSelfRef.io_dcache_req_bits_word_idx = (7U & (IData)(
                                                          (vlSelfRef.AtomicsUnit__DOT__paddr 
                                                           >> 3U)));
    vlSelfRef.io_dtlb_req_bits_fullva = vlSelfRef.AtomicsUnit__DOT__rs1;
    vlSelfRef.io_exceptionInfo_bits_vaddr = vlSelfRef.AtomicsUnit__DOT__rs1;
    vlSelfRef.io_out_bits_uop_exceptionVec_3 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_3;
    vlSelfRef.io_out_bits_uop_exceptionVec_4 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_4;
    vlSelfRef.io_out_bits_uop_exceptionVec_6 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_6;
    vlSelfRef.io_out_bits_uop_exceptionVec_19 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_19;
    vlSelfRef.io_out_bits_uop_trigger = vlSelfRef.AtomicsUnit__DOT__trigger;
    vlSelfRef.io_out_bits_uop_rfWen = vlSelfRef.AtomicsUnit__DOT__uop_rfWen;
    vlSelfRef.io_out_bits_uop_robIdx_flag = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_flag;
    vlSelfRef.io_dtlb_req_bits_debug_robIdx_flag = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_flag;
    vlSelfRef.io_out_bits_uop_robIdx_value = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_value;
    vlSelfRef.io_dtlb_req_bits_debug_robIdx_value = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_value;
    vlSelfRef.io_out_bits_debug_isMMIO = vlSelfRef.AtomicsUnit__DOT__is_mmio;
    vlSelfRef.io_feedbackSlow_valid = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG_1;
    vlSelfRef.io_feedbackSlow_bits_sqIdx_flag = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_flag;
    vlSelfRef.io_feedbackSlow_bits_sqIdx_value = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_value;
    vlSelfRef.io_exceptionInfo_valid = vlSelfRef.AtomicsUnit__DOT__atom_override_xtval;
    vlSelfRef.io_exceptionInfo_bits_gpaddr = vlSelfRef.AtomicsUnit__DOT__gpaddr;
    vlSelfRef.io_exceptionInfo_bits_isForVSnonLeafPTE 
        = vlSelfRef.AtomicsUnit__DOT__isForVSnonLeafPTE;
    if ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
        vlSelfRef.io_out_bits_data = (((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[3U])) 
                                       << 0x00000020U) 
                                      | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[2U])));
        vlSelfRef.io_out_bits_uop_pdest = vlSelfRef.AtomicsUnit__DOT__pdest2;
    } else {
        vlSelfRef.io_out_bits_data = (((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[1U])) 
                                       << 0x00000020U) 
                                      | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[0U])));
        vlSelfRef.io_out_bits_uop_pdest = vlSelfRef.AtomicsUnit__DOT__pdest1;
    }
    vlSelfRef.AtomicsUnit__DOT___GEN_6 = ((IData)(vlSelfRef.io_dcache_resp_valid) 
                                          & (5U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)));
    if ((0U == (7U & (IData)(vlSelfRef.AtomicsUnit__DOT__paddr)))) {
        vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[0U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[2U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[3U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U];
    } else {
        vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[2U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[3U] = 0U;
    }
    vlSelfRef.AtomicsUnit__DOT___GEN_20 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (0U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_21 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (1U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_22 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (2U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_23 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (3U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.io_dcache_req_bits_amo_cmp[0U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[1U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(
                                                               (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                >> 0x00000020U))
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(
                                                                 (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                  >> 0x00000020U)))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[2U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(vlSelfRef.AtomicsUnit__DOT__rd_h))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[3U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(
                                                               (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                >> 0x00000020U))
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(
                                                                 (vlSelfRef.AtomicsUnit__DOT__rd_h 
                                                                  >> 0x00000020U)))));
    vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError 
        = ((IData)(vlSelfRef.io_csrCtrl_cache_error_enable) 
           & ((IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied) 
              | (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt)));
    AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6 
        = (0x000007ffU & (((IData)(0x000fU) << (7U 
                                                & (IData)(vlSelfRef.AtomicsUnit__DOT__paddr))) 
                          & (- (IData)((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))));
    AtomicsUnit__DOT___rs2_T = ((0x0bU == (0x0000000fU 
                                           & ((IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType) 
                                              >> 2U)))
                                 ? vlSelfRef.AtomicsUnit__DOT__rs2_l
                                 : vlSelfRef.AtomicsUnit__DOT__rd_l);
    vlSelfRef.AtomicsUnit__DOT__addrAligned = (((2U 
                                                 == 
                                                 (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))) 
                                                & (0U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1)))) 
                                               | (((3U 
                                                    == 
                                                    (3U 
                                                     & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))) 
                                                   & (0U 
                                                      == 
                                                      (7U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1)))) 
                                                  | ((~ 
                                                      (0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                     & (0U 
                                                        == 
                                                        (0x0000000fU 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1))))));
    vlSelfRef.io_in_ready = ((0U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                             | ((~ ((IData)(vlSelfRef.AtomicsUnit__DOT__pdest2Valid) 
                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__pdest1Valid))) 
                                & (0x002cU == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))));
    vlSelfRef.io_out_valid = ((IData)(vlSelfRef.AtomicsUnit__DOT__out_valid) 
                              & ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))
                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__pdest2Valid)
                                  : (IData)(vlSelfRef.AtomicsUnit__DOT__pdest1Valid)));
    __Vtableidx1 = vlSelfRef.AtomicsUnit__DOT__uop_fuOpType;
    AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60 
        = VAtomicsUnitOrig__ConstPool__TABLE_heef4d9af_0
        [__Vtableidx1];
    vlSelfRef.AtomicsUnit__DOT__triggerAction = ((((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                   & (1U 
                                                      == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                  | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                      & (1U 
                                                         == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                     | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                         & (1U 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                        | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                           & (1U 
                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action))))))
                                                  ? 1U
                                                  : 
                                                 (0x0000000fU 
                                                  & (- (IData)(
                                                               (1U 
                                                                & (~ 
                                                                   ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_triggerCanRaiseBpExp) 
                                                                    & (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                                        & (0U 
                                                                           == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                                       | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                                           & (0U 
                                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                                          | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                                              & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                                             | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                                                & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action)))))))))))));
    vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1 
        = ((IData)(vlSelfRef.io_pmpResp_mmio) | ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)) 
                                                 | ((IData)(vlSelfRef.io_pmpResp_ld) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)))));
    vlSelfRef.io_dtlb_req_valid = (1U == (IData)(vlSelfRef.AtomicsUnit__DOT__state));
    vlSelfRef.AtomicsUnit__DOT__isSc = ((6U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                        | (7U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)));
    vlSelfRef.AtomicsUnit__DOT__isLr = ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                        | (3U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)));
    vlSelfRef.io_dtlb_req_bits_vaddr = (0x0003ffffffffffffULL 
                                        & vlSelfRef.AtomicsUnit__DOT__rs1);
    vlSelfRef.io_dcache_req_bits_amo_mask = (0x0000ffffU 
                                             & ((- (IData)(
                                                           (1U 
                                                            & (~ 
                                                               (0U 
                                                                != 
                                                                (3U 
                                                                 & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))))) 
                                                | ((0x00000700U 
                                                    & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6)) 
                                                   | (0x000000ffU 
                                                      & ((IData)(AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6) 
                                                         | (- (IData)(
                                                                      (3U 
                                                                       == 
                                                                       (3U 
                                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))))))));
    vlSelfRef.io_dcache_req_bits_amo_data[0U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(AtomicsUnit__DOT___rs2_T))));
    vlSelfRef.io_dcache_req_bits_amo_data[1U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(
                                                                (AtomicsUnit__DOT___rs2_T 
                                                                 >> 0x00000020U))
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(
                                                                  (AtomicsUnit__DOT___rs2_T 
                                                                   >> 0x00000020U)))));
    vlSelfRef.io_dcache_req_bits_amo_data[2U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(vlSelfRef.AtomicsUnit__DOT__rs2_h))));
    vlSelfRef.io_dcache_req_bits_amo_data[3U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(
                                                                (AtomicsUnit__DOT___rs2_T 
                                                                 >> 0x00000020U))
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(
                                                                  (vlSelfRef.AtomicsUnit__DOT__rs2_h 
                                                                   >> 0x00000020U)))));
    vlSelfRef.AtomicsUnit__DOT___GEN = ((IData)(vlSelfRef.io_in_valid) 
                                        & (IData)(vlSelfRef.io_in_ready));
    vlSelfRef.AtomicsUnit__DOT___GEN_16 = ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                           & (IData)(vlSelfRef.io_out_valid));
    vlSelfRef.AtomicsUnit__DOT___GEN_14 = ((7U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                           & (IData)(vlSelfRef.io_out_valid));
    vlSelfRef.io_dcache_req_bits_cmd = (((0x00000010U 
                                          & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60)) 
                                         | (0x0000000fU 
                                            & (((8U 
                                                 & ((0xfffffff8U 
                                                     & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60)) 
                                                    | ((0x000fU 
                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                       << 3U))) 
                                                | (7U 
                                                   & ((IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60) 
                                                      | ((6U 
                                                          & (- (IData)(
                                                                       (3U 
                                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                         | ((- (IData)(
                                                                       (7U 
                                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                            | ((0x000bU 
                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                               << 2U)))))) 
                                               | ((9U 
                                                   & (- (IData)(
                                                                (0x0013U 
                                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                  | ((0x0bU 
                                                      & (- (IData)(
                                                                   (0x0017U 
                                                                    == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                     | ((0x0aU 
                                                         & (- (IData)(
                                                                      (0x001bU 
                                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                        | ((0x0cU 
                                                            & (- (IData)(
                                                                         (0x001fU 
                                                                          == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                           | ((0x0dU 
                                                               & (- (IData)(
                                                                            (0x0023U 
                                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                              | ((- (IData)(
                                                                            (0x002bU 
                                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                                 | (0x0eU 
                                                                    & (- (IData)(
                                                                                (0x0027U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))))))))))) 
                                        | ((0x18U & 
                                            (- (IData)(
                                                       (0x002cU 
                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                           | (0x1bU 
                                              & (- (IData)(
                                                           (0x002fU 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))));
    vlSelfRef.AtomicsUnit__DOT___GEN_10 = (1U & ((0U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)) 
                                                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__addrAligned)) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_12 = ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_15) 
                                           | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_13) 
                                              | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_23) 
                                                 | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_21) 
                                                    | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_7) 
                                                       | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_5) 
                                                          | ((IData)(vlSelfRef.io_pmpResp_st) 
                                                             | (IData)(vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1))))))));
    vlSelfRef.io_flush_sbuffer_valid = ((~ (IData)(vlSelfRef.io_flush_sbuffer_empty)) 
                                        & ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                           | ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                              | (3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__state)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_5 = ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                          & ((IData)(vlSelfRef.io_dtlb_resp_valid) 
                                             & (IData)(vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req)));
    vlSelfRef.io_dtlb_req_bits_cmd = (4U | (1U & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2)))));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2)))));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_0 = ((0U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN));
    vlSelfRef.AtomicsUnit__DOT___GEN_2 = (IData)(((0U 
                                                   == 
                                                   (0x01c0U 
                                                    & (IData)(vlSelfRef.io_in_bits_uop_fuOpType))) 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN)));
    vlSelfRef.AtomicsUnit__DOT___GEN_15 = (1U & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_14)) 
                                                 | (0x002cU 
                                                    == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))));
    vlSelfRef.io_dcache_req_valid = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                     & ((6U == (IData)(vlSelfRef.io_dcache_req_bits_cmd))
                                         ? (~ (IData)(vlSelfRef.io_dcache_block_lr))
                                         : (IData)(vlSelfRef.AtomicsUnit__DOT__data_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN_18 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12)
                                            ? 7U : 
                                           ((IData)(vlSelfRef.io_flush_sbuffer_empty)
                                             ? 4U : 3U));
    vlSelfRef.AtomicsUnit__DOT___GEN_8 = ((~ (IData)(vlSelfRef.io_dtlb_resp_bits_miss)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_5));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_0 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_1 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_2 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_store)))))));
    vlSelfRef.AtomicsUnit__DOT___GEN_9 = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & ((IData)(vlSelfRef.io_dcache_req_ready) 
                                             & (IData)(vlSelfRef.io_dcache_req_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN_11 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10) 
                                           & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_8));
    vlSelfRef.AtomicsUnit__DOT___GEN_13 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                           | (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12));
}

VL_ATTR_COLD void VAtomicsUnitOrig___024root___eval_stl(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_stl\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
        VAtomicsUnitOrig___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD bool VAtomicsUnitOrig___024root___eval_phase__stl(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___eval_phase__stl\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    VAtomicsUnitOrig___024root___eval_triggers_vec__stl(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        VAtomicsUnitOrig___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = VAtomicsUnitOrig___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        VAtomicsUnitOrig___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

bool VAtomicsUnitOrig___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitOrig___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(VAtomicsUnitOrig___024root___trigger_anySet__ico(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

bool VAtomicsUnitOrig___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitOrig___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(VAtomicsUnitOrig___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge clock)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @(posedge reset)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void VAtomicsUnitOrig___024root___ctor_var_reset(VAtomicsUnitOrig___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitOrig___024root___ctor_var_reset\n"); );
    VAtomicsUnitOrig__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->clock = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5452235342940299466ull);
    vlSelf->reset = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9928399931838511862ull);
    vlSelf->io_hartId = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 1501888617334228259ull);
    vlSelf->io_in_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6344920612308262331ull);
    vlSelf->io_in_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18313148353544833281ull);
    vlSelf->io_in_bits_uop_fuOpType = VL_SCOPED_RAND_RESET_I(9, __VscopeHash, 7501082331318511572ull);
    vlSelf->io_in_bits_uop_rfWen = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13893361311952746055ull);
    vlSelf->io_in_bits_uop_pdest = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 13643725455943288119ull);
    vlSelf->io_in_bits_uop_robIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14962740668669132858ull);
    vlSelf->io_in_bits_uop_robIdx_value = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 15060079473648522824ull);
    vlSelf->io_in_bits_uop_sqIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12218900219989616634ull);
    vlSelf->io_in_bits_uop_sqIdx_value = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 5647301904686609775ull);
    vlSelf->io_in_bits_src_0 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 4012224840891776218ull);
    vlSelf->io_storeDataIn_0_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5509298758036248569ull);
    vlSelf->io_storeDataIn_0_bits_uop_fuOpType = VL_SCOPED_RAND_RESET_I(9, __VscopeHash, 18098222995877284095ull);
    vlSelf->io_storeDataIn_0_bits_data = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 15041042674678806228ull);
    vlSelf->io_storeDataIn_1_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13367037517791872609ull);
    vlSelf->io_storeDataIn_1_bits_uop_fuOpType = VL_SCOPED_RAND_RESET_I(9, __VscopeHash, 13922457549250768493ull);
    vlSelf->io_storeDataIn_1_bits_data = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 7216512380728633ull);
    vlSelf->io_out_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1069148654264965181ull);
    vlSelf->io_out_bits_uop_exceptionVec_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6650300662026694377ull);
    vlSelf->io_out_bits_uop_exceptionVec_4 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13679570943426384197ull);
    vlSelf->io_out_bits_uop_exceptionVec_5 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11970108181857690551ull);
    vlSelf->io_out_bits_uop_exceptionVec_6 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9644394597103550835ull);
    vlSelf->io_out_bits_uop_exceptionVec_7 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 275864447524712837ull);
    vlSelf->io_out_bits_uop_exceptionVec_13 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8626916207326380122ull);
    vlSelf->io_out_bits_uop_exceptionVec_15 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13694844347940515028ull);
    vlSelf->io_out_bits_uop_exceptionVec_19 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 205513737666952899ull);
    vlSelf->io_out_bits_uop_exceptionVec_21 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13423365373233947780ull);
    vlSelf->io_out_bits_uop_exceptionVec_23 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 44549440138555526ull);
    vlSelf->io_out_bits_uop_trigger = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 14638409130538828202ull);
    vlSelf->io_out_bits_uop_rfWen = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7504842548322119507ull);
    vlSelf->io_out_bits_uop_pdest = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 17200023638449453615ull);
    vlSelf->io_out_bits_uop_robIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 670159657865298467ull);
    vlSelf->io_out_bits_uop_robIdx_value = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6937645939644400532ull);
    vlSelf->io_out_bits_data = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 7066942887072140498ull);
    vlSelf->io_out_bits_debug_isMMIO = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9137858647366476391ull);
    vlSelf->io_dcache_req_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15099630829140320079ull);
    vlSelf->io_dcache_req_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8471155454697199326ull);
    vlSelf->io_dcache_req_bits_cmd = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 7819912732351082022ull);
    vlSelf->io_dcache_req_bits_vaddr = VL_SCOPED_RAND_RESET_Q(50, __VscopeHash, 679510506317777581ull);
    vlSelf->io_dcache_req_bits_addr = VL_SCOPED_RAND_RESET_Q(48, __VscopeHash, 7171136029580204782ull);
    vlSelf->io_dcache_req_bits_word_idx = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 7873103851021624480ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->io_dcache_req_bits_amo_data, __VscopeHash, 13900235642135565194ull);
    vlSelf->io_dcache_req_bits_amo_mask = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 7224740895863588123ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->io_dcache_req_bits_amo_cmp, __VscopeHash, 11471205840613118177ull);
    vlSelf->io_dcache_resp_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17005129488179421142ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->io_dcache_resp_bits_data, __VscopeHash, 10998592609809042685ull);
    vlSelf->io_dcache_resp_bits_miss = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17089331991069175936ull);
    vlSelf->io_dcache_resp_bits_replay = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 757097500221597784ull);
    vlSelf->io_dcache_resp_bits_tl_error_tl_denied = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8969546689133795030ull);
    vlSelf->io_dcache_resp_bits_tl_error_tl_corrupt = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12611990164579421427ull);
    vlSelf->io_dcache_resp_bits_id = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 4514683747574171956ull);
    vlSelf->io_dcache_block_lr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14707933252347445607ull);
    vlSelf->io_dtlb_req_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11550882207605805329ull);
    vlSelf->io_dtlb_req_bits_vaddr = VL_SCOPED_RAND_RESET_Q(50, __VscopeHash, 4281793266071895489ull);
    vlSelf->io_dtlb_req_bits_fullva = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 13068474221467726095ull);
    vlSelf->io_dtlb_req_bits_cmd = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 15943987310723557641ull);
    vlSelf->io_dtlb_req_bits_debug_robIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17443205565831610556ull);
    vlSelf->io_dtlb_req_bits_debug_robIdx_value = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 17991037650537816554ull);
    vlSelf->io_dtlb_resp_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13233522869024183652ull);
    vlSelf->io_dtlb_resp_bits_paddr_0 = VL_SCOPED_RAND_RESET_Q(48, __VscopeHash, 4456769289879756131ull);
    vlSelf->io_dtlb_resp_bits_gpaddr_0 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 15061274488980253524ull);
    vlSelf->io_dtlb_resp_bits_fullva = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 10387974667313278413ull);
    vlSelf->io_dtlb_resp_bits_pbmt_0 = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 14416111402466964168ull);
    vlSelf->io_dtlb_resp_bits_miss = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3050164913220292064ull);
    vlSelf->io_dtlb_resp_bits_isForVSnonLeafPTE = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18393934337217744534ull);
    vlSelf->io_dtlb_resp_bits_excp_0_gpf_ld = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9234437995118148107ull);
    vlSelf->io_dtlb_resp_bits_excp_0_gpf_st = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16651032356864484484ull);
    vlSelf->io_dtlb_resp_bits_excp_0_pf_ld = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16148027764304041062ull);
    vlSelf->io_dtlb_resp_bits_excp_0_pf_st = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14656025691905116906ull);
    vlSelf->io_dtlb_resp_bits_excp_0_af_ld = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8767205015537721782ull);
    vlSelf->io_dtlb_resp_bits_excp_0_af_st = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10148272222864000689ull);
    vlSelf->io_pmpResp_ld = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12224669286535958641ull);
    vlSelf->io_pmpResp_st = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13910718979076417105ull);
    vlSelf->io_pmpResp_mmio = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6483827000780782950ull);
    vlSelf->io_flush_sbuffer_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8396003222108953076ull);
    vlSelf->io_flush_sbuffer_empty = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13636376695605417976ull);
    vlSelf->io_feedbackSlow_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18414633081583692467ull);
    vlSelf->io_feedbackSlow_bits_sqIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4148155923492640511ull);
    vlSelf->io_feedbackSlow_bits_sqIdx_value = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 9624961233050838358ull);
    vlSelf->io_redirect_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11671968275382918116ull);
    vlSelf->io_exceptionInfo_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15563395894000638013ull);
    vlSelf->io_exceptionInfo_bits_vaddr = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 9988521089589657657ull);
    vlSelf->io_exceptionInfo_bits_gpaddr = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 5713353196244140075ull);
    vlSelf->io_exceptionInfo_bits_isForVSnonLeafPTE = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15521418862654303486ull);
    vlSelf->io_csrCtrl_cache_error_enable = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5001072976802528001ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3969412040561707389ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_addr = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 5325387019303731257ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 12078768146973975206ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12271974306043370079ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 364686620457461364ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8706857948916501689ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10868589332730370017ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15921333549956464728ull);
    vlSelf->io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 4094030705852081009ull);
    vlSelf->io_csrCtrl_mem_trigger_tEnableVec_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 509519514667129831ull);
    vlSelf->io_csrCtrl_mem_trigger_tEnableVec_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6788200904259237848ull);
    vlSelf->io_csrCtrl_mem_trigger_tEnableVec_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6471912242896546188ull);
    vlSelf->io_csrCtrl_mem_trigger_tEnableVec_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10350509051957370648ull);
    vlSelf->io_csrCtrl_mem_trigger_debugMode = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10757253974425810366ull);
    vlSelf->io_csrCtrl_mem_trigger_triggerCanRaiseBpExp = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9677944259180386781ull);
    vlSelf->AtomicsUnit__DOT__state = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 16462058111080898869ull);
    vlSelf->AtomicsUnit__DOT__out_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11768415780457302364ull);
    vlSelf->AtomicsUnit__DOT__data_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4922747610507568810ull);
    vlSelf->AtomicsUnit__DOT__uop_fuOpType = VL_SCOPED_RAND_RESET_I(9, __VscopeHash, 7195146409854384130ull);
    vlSelf->AtomicsUnit__DOT__uop_rfWen = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9104757763838376748ull);
    vlSelf->AtomicsUnit__DOT__uop_robIdx_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5064895663060156613ull);
    vlSelf->AtomicsUnit__DOT__uop_robIdx_value = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6256218272064978414ull);
    vlSelf->AtomicsUnit__DOT__isLr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3947480237590660677ull);
    vlSelf->AtomicsUnit__DOT__isSc = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 961691471855442437ull);
    vlSelf->AtomicsUnit__DOT__pdest1 = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 2483575140598044324ull);
    vlSelf->AtomicsUnit__DOT__pdest2 = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6536663451337997372ull);
    vlSelf->AtomicsUnit__DOT__pdest1Valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2105013435408269081ull);
    vlSelf->AtomicsUnit__DOT__pdest2Valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6614977868035327925ull);
    vlSelf->AtomicsUnit__DOT__rs1 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 4082473216150855746ull);
    vlSelf->AtomicsUnit__DOT__rs2_l = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 8923143991714348579ull);
    vlSelf->AtomicsUnit__DOT__rs2_h = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 3667792270720847226ull);
    vlSelf->AtomicsUnit__DOT__rd_l = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 15471587184689526891ull);
    vlSelf->AtomicsUnit__DOT__rd_h = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 6369553931448949573ull);
    vlSelf->AtomicsUnit__DOT__stdCnt = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 2466850650423584323ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3495314501952889919ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_4 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14800591404303852404ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_5 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12311723045678814015ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_6 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18162781005887375283ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_7 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16395934831304194345ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_13 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3854471087372767152ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_15 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12516014421564218507ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_19 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10809363535563442486ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_21 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15358973384657690272ull);
    vlSelf->AtomicsUnit__DOT__exceptionVec_23 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10511743804290986457ull);
    vlSelf->AtomicsUnit__DOT__trigger = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 9850124901884368637ull);
    vlSelf->AtomicsUnit__DOT__atom_override_xtval = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7694692706129364605ull);
    vlSelf->AtomicsUnit__DOT__have_sent_first_tlb_req = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9314425111030216267ull);
    vlSelf->AtomicsUnit__DOT__paddr = VL_SCOPED_RAND_RESET_Q(48, __VscopeHash, 2625727847440446838ull);
    vlSelf->AtomicsUnit__DOT__gpaddr = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 11062403126460062246ull);
    vlSelf->AtomicsUnit__DOT__is_mmio = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13138454487945689355ull);
    vlSelf->AtomicsUnit__DOT__isForVSnonLeafPTE = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7601869616324088505ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->AtomicsUnit__DOT__resp_data, __VscopeHash, 8085761698750506701ull);
    vlSelf->AtomicsUnit__DOT___GEN = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14580981423995673691ull);
    vlSelf->AtomicsUnit__DOT___GEN_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1913919194006081711ull);
    vlSelf->AtomicsUnit__DOT___GEN_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8053435958050490761ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_matchType = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 10029225110002207677ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_select = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 716834223089217892ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_timing = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12292241180372950605ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_action = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 3483158464109512461ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_chain = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12451483324007025016ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17425969977129523580ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_load = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9873867065825497156ull);
    vlSelf->AtomicsUnit__DOT__tdata_0_tdata2 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 17735495359998021679ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_matchType = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 7208996604983178056ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_select = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6747201571181359098ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_timing = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13358974895758471485ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_action = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 12489826276172156277ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_chain = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 206921423010109935ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4410861659989644670ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_load = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11407779921241515008ull);
    vlSelf->AtomicsUnit__DOT__tdata_1_tdata2 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 9761210763207127676ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_matchType = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 8477447563522288871ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_select = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3079148164963087233ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_timing = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4292687677846778500ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_action = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 16745397573009560678ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_chain = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11598791650315064166ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10309026149762665895ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_load = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12125484154255682325ull);
    vlSelf->AtomicsUnit__DOT__tdata_2_tdata2 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 2025519562375830308ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_matchType = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 16177523192594311716ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_select = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5494703627866031307ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_timing = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17839185417602900182ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_action = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 8880320760396688806ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_chain = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2009622237633715292ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12991722311433897418ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_load = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17316079508069505038ull);
    vlSelf->AtomicsUnit__DOT__tdata_3_tdata2 = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 13912673515680371094ull);
    vlSelf->AtomicsUnit__DOT__tEnableVec_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15961914753142502353ull);
    vlSelf->AtomicsUnit__DOT__tEnableVec_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18236434153334637401ull);
    vlSelf->AtomicsUnit__DOT__tEnableVec_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7608359859332970520ull);
    vlSelf->AtomicsUnit__DOT__tEnableVec_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9600604837643954878ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerCanFireVec_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1627174055533575457ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerCanFireVec_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10932691942531992216ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerCanFireVec_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9615957560129775808ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerCanFireVec_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16743146181976874161ull);
    vlSelf->AtomicsUnit__DOT___GEN_5 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15972394286187853694ull);
    vlSelf->AtomicsUnit__DOT__pbmtReg = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 12083380230706434095ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->AtomicsUnit__DOT__dcache_resp_data, __VscopeHash, 12270436877164871645ull);
    vlSelf->AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6044443073205343741ull);
    vlSelf->AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7007029354223079293ull);
    vlSelf->AtomicsUnit__DOT___GEN_6 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2619741843887233356ull);
    vlSelf->AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15642478416344098443ull);
    vlSelf->AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16849395774817996272ull);
    vlSelf->AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_flag = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14307713342368071559ull);
    vlSelf->AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_value = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 5421338901100953735ull);
    vlSelf->AtomicsUnit__DOT___GEN_8 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2947833499132647100ull);
    vlSelf->AtomicsUnit__DOT___GEN_9 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5005347321071182367ull);
    vlSelf->AtomicsUnit__DOT__canTriggerCacheError = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16634437449598382519ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerHitVec_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16307293374474864409ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerHitVec_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17574487913663628925ull);
    vlSelf->AtomicsUnit__DOT__backendTriggerHitVec_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11750132618804491829ull);
    vlSelf->AtomicsUnit__DOT__triggerAction = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 5739769397334064247ull);
    vlSelf->AtomicsUnit__DOT__addrAligned = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4349104941346291672ull);
    vlSelf->AtomicsUnit__DOT___GEN_10 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11793642964520144216ull);
    vlSelf->AtomicsUnit__DOT___GEN_11 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10130010576837357895ull);
    vlSelf->AtomicsUnit__DOT___GEN_12 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2940193224285036347ull);
    vlSelf->AtomicsUnit__DOT___GEN_13 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 262952280230888043ull);
    vlSelf->AtomicsUnit__DOT___GEN_14 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5416988095827455915ull);
    vlSelf->AtomicsUnit__DOT___GEN_15 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1245944739034071728ull);
    vlSelf->AtomicsUnit__DOT___GEN_16 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6096519941958869533ull);
    vlSelf->AtomicsUnit__DOT___GEN_18 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 1815405716122495435ull);
    vlSelf->AtomicsUnit__DOT___exceptionVec_7_T_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1661595469760368688ull);
    VL_SCOPED_RAND_RESET_W(128, vlSelf->AtomicsUnit__DOT__rdataSel, __VscopeHash, 16812366338340609535ull);
    vlSelf->AtomicsUnit__DOT___GEN_20 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18018098644808131162ull);
    vlSelf->AtomicsUnit__DOT___GEN_21 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15741961223639637930ull);
    vlSelf->AtomicsUnit__DOT___GEN_22 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6996532801583180192ull);
    vlSelf->AtomicsUnit__DOT___GEN_23 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6494086865402381947ull);
    vlSelf->__VdfgRegularize_h6e95ff9d_0_3 = 0;
    vlSelf->__VdfgRegularize_h6e95ff9d_0_4 = 0;
    vlSelf->__VdfgRegularize_h6e95ff9d_0_5 = 0;
    vlSelf->__Vdly__AtomicsUnit__DOT__tdata_2_timing = 0;
    vlSelf->__Vdly__AtomicsUnit__DOT__tdata_1_timing = 0;
    vlSelf->__Vdly__AtomicsUnit__DOT__tdata_0_timing = 0;
    vlSelf->__Vdly__AtomicsUnit__DOT__tdata_3_timing = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VicoTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__clock__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__reset__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
}
