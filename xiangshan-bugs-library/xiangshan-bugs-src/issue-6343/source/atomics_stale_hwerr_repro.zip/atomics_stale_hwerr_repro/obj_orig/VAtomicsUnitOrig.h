// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary model header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef VERILATED_VATOMICSUNITORIG_H_
#define VERILATED_VATOMICSUNITORIG_H_  // guard

#include "verilated.h"

class VAtomicsUnitOrig__Syms;
class VAtomicsUnitOrig___024root;

// This class is the main interface to the Verilated model
class alignas(VL_CACHE_LINE_BYTES) VAtomicsUnitOrig VL_NOT_FINAL : public VerilatedModel {
  private:
    // Symbol table holding complete model state (owned by this class)
    VAtomicsUnitOrig__Syms* const vlSymsp;

  public:

    // CONSTEXPR CAPABILITIES
    // Verilated with --trace?
    static constexpr bool traceCapable = false;

    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(&clock,0,0);
    VL_IN8(&reset,0,0);
    VL_IN8(&io_hartId,5,0);
    VL_OUT8(&io_in_ready,0,0);
    VL_IN8(&io_in_valid,0,0);
    VL_IN8(&io_in_bits_uop_rfWen,0,0);
    VL_IN8(&io_in_bits_uop_pdest,7,0);
    VL_IN8(&io_in_bits_uop_robIdx_flag,0,0);
    VL_IN8(&io_in_bits_uop_robIdx_value,7,0);
    VL_IN8(&io_in_bits_uop_sqIdx_flag,0,0);
    VL_IN8(&io_in_bits_uop_sqIdx_value,5,0);
    VL_IN8(&io_storeDataIn_0_valid,0,0);
    VL_IN8(&io_storeDataIn_1_valid,0,0);
    VL_OUT8(&io_out_valid,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_3,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_4,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_5,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_6,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_7,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_13,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_15,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_19,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_21,0,0);
    VL_OUT8(&io_out_bits_uop_exceptionVec_23,0,0);
    VL_OUT8(&io_out_bits_uop_trigger,3,0);
    VL_OUT8(&io_out_bits_uop_rfWen,0,0);
    VL_OUT8(&io_out_bits_uop_pdest,7,0);
    VL_OUT8(&io_out_bits_uop_robIdx_flag,0,0);
    VL_OUT8(&io_out_bits_uop_robIdx_value,7,0);
    VL_OUT8(&io_out_bits_debug_isMMIO,0,0);
    VL_IN8(&io_dcache_req_ready,0,0);
    VL_OUT8(&io_dcache_req_valid,0,0);
    VL_OUT8(&io_dcache_req_bits_cmd,4,0);
    VL_OUT8(&io_dcache_req_bits_word_idx,2,0);
    VL_IN8(&io_dcache_resp_valid,0,0);
    VL_IN8(&io_dcache_resp_bits_miss,0,0);
    VL_IN8(&io_dcache_resp_bits_replay,0,0);
    VL_IN8(&io_dcache_resp_bits_tl_error_tl_denied,0,0);
    VL_IN8(&io_dcache_resp_bits_tl_error_tl_corrupt,0,0);
    VL_IN8(&io_dcache_resp_bits_id,5,0);
    VL_IN8(&io_dcache_block_lr,0,0);
    VL_OUT8(&io_dtlb_req_valid,0,0);
    VL_OUT8(&io_dtlb_req_bits_cmd,2,0);
    VL_OUT8(&io_dtlb_req_bits_debug_robIdx_flag,0,0);
    VL_OUT8(&io_dtlb_req_bits_debug_robIdx_value,7,0);
    VL_IN8(&io_dtlb_resp_valid,0,0);
    VL_IN8(&io_dtlb_resp_bits_pbmt_0,1,0);
    VL_IN8(&io_dtlb_resp_bits_miss,0,0);
    VL_IN8(&io_dtlb_resp_bits_isForVSnonLeafPTE,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_gpf_ld,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_gpf_st,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_pf_ld,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_pf_st,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_af_ld,0,0);
    VL_IN8(&io_dtlb_resp_bits_excp_0_af_st,0,0);
    VL_IN8(&io_pmpResp_ld,0,0);
    VL_IN8(&io_pmpResp_st,0,0);
    VL_IN8(&io_pmpResp_mmio,0,0);
    VL_OUT8(&io_flush_sbuffer_valid,0,0);
    VL_IN8(&io_flush_sbuffer_empty,0,0);
    VL_OUT8(&io_feedbackSlow_valid,0,0);
    VL_OUT8(&io_feedbackSlow_bits_sqIdx_flag,0,0);
    VL_OUT8(&io_feedbackSlow_bits_sqIdx_value,5,0);
    VL_IN8(&io_redirect_valid,0,0);
    VL_OUT8(&io_exceptionInfo_valid,0,0);
    VL_OUT8(&io_exceptionInfo_bits_isForVSnonLeafPTE,0,0);
    VL_IN8(&io_csrCtrl_cache_error_enable,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_valid,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_addr,1,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType,1,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action,3,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tEnableVec_0,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tEnableVec_1,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tEnableVec_2,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_tEnableVec_3,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_debugMode,0,0);
    VL_IN8(&io_csrCtrl_mem_trigger_triggerCanRaiseBpExp,0,0);
    VL_IN16(&io_in_bits_uop_fuOpType,8,0);
    VL_IN16(&io_storeDataIn_0_bits_uop_fuOpType,8,0);
    VL_IN16(&io_storeDataIn_1_bits_uop_fuOpType,8,0);
    VL_OUT16(&io_dcache_req_bits_amo_mask,15,0);
    VL_OUTW(&io_dcache_req_bits_amo_data,127,0,4);
    VL_OUTW(&io_dcache_req_bits_amo_cmp,127,0,4);
    VL_INW(&io_dcache_resp_bits_data,127,0,4);
    VL_IN64(&io_in_bits_src_0,63,0);
    VL_IN64(&io_storeDataIn_0_bits_data,63,0);
    VL_IN64(&io_storeDataIn_1_bits_data,63,0);
    VL_OUT64(&io_out_bits_data,63,0);
    VL_OUT64(&io_dcache_req_bits_vaddr,49,0);
    VL_OUT64(&io_dcache_req_bits_addr,47,0);
    VL_OUT64(&io_dtlb_req_bits_vaddr,49,0);
    VL_OUT64(&io_dtlb_req_bits_fullva,63,0);
    VL_IN64(&io_dtlb_resp_bits_paddr_0,47,0);
    VL_IN64(&io_dtlb_resp_bits_gpaddr_0,63,0);
    VL_IN64(&io_dtlb_resp_bits_fullva,63,0);
    VL_OUT64(&io_exceptionInfo_bits_vaddr,63,0);
    VL_OUT64(&io_exceptionInfo_bits_gpaddr,63,0);
    VL_IN64(&io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2,63,0);

    // CELLS
    // Public to allow access to /* verilator public */ items.
    // Otherwise the application code can consider these internals.

    // Root instance pointer to allow access to model internals,
    // including inlined /* verilator public_flat_* */ items.
    VAtomicsUnitOrig___024root* const rootp;

    // CONSTRUCTORS
    /// Construct the model; called by application code
    /// If contextp is null, then the model will use the default global context
    /// If name is "", then makes a wrapper with a
    /// single model invisible with respect to DPI scope names.
    explicit VAtomicsUnitOrig(VerilatedContext* contextp, const char* name = "TOP");
    explicit VAtomicsUnitOrig(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    virtual ~VAtomicsUnitOrig();
  private:
    VL_UNCOPYABLE(VAtomicsUnitOrig);  ///< Copying not allowed

  public:
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval() { eval_step(); }
    /// Evaluate when calling multiple units/models per time step.
    void eval_step();
    /// Evaluate at end of a timestep for tracing, when using eval_step().
    /// Application must call after all eval() and before time changes.
    void eval_end_step() {}
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    /// Are there scheduled events to handle?
    bool eventsPending();
    /// Returns time at next time slot. Aborts if !eventsPending()
    uint64_t nextTimeSlot();
    /// Trace signals in the model; called by application code
    void trace(VerilatedTraceBaseC* tfp, int levels, int options = 0) { contextp()->trace(tfp, levels, options); }
    /// Retrieve name of this model instance (as passed to constructor).
    const char* name() const;

    // Abstract methods from VerilatedModel
    const char* hierName() const override final;
    const char* modelName() const override final;
    unsigned threads() const override final;
    /// Prepare for cloning the model at the process level (e.g. fork in Linux)
    /// Release necessary resources. Called before cloning.
    void prepareClone() const;
    /// Re-init after cloning the model at the process level (e.g. fork in Linux)
    /// Re-allocate necessary resources. Called after cloning.
    void atClone() const;
  private:
    // Internal functions - trace registration
    void traceBaseModel(VerilatedTraceBaseC* tfp, int levels, int options);
};

#endif  // guard
