$ErrorActionPreference = "Stop"
wsl.exe -d Ubuntu-22.04 -- bash -lc "cd /home/lhf/project/xiangshan/xs-env/XiangShan/atomics_stale_hwerr_repro && ./build_and_run.sh"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
