// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See VAtomicsUnitFixed.h for the primary calling header

#ifndef VERILATED_VATOMICSUNITFIXED___024ROOT_H_
#define VERILATED_VATOMICSUNITFIXED___024ROOT_H_  // guard

#include "verilated.h"


class VAtomicsUnitFixed__Syms;

class alignas(VL_CACHE_LINE_BYTES) VAtomicsUnitFixed___024root final {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clock,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(io_hartId,5,0);
        VL_OUT8(io_in_ready,0,0);
        VL_IN8(io_in_valid,0,0);
        VL_IN8(io_in_bits_uop_rfWen,0,0);
        VL_IN8(io_in_bits_uop_pdest,7,0);
        VL_IN8(io_in_bits_uop_robIdx_flag,0,0);
        VL_IN8(io_in_bits_uop_robIdx_value,7,0);
        VL_IN8(io_in_bits_uop_sqIdx_flag,0,0);
        VL_IN8(io_in_bits_uop_sqIdx_value,5,0);
        VL_IN8(io_storeDataIn_0_valid,0,0);
        VL_IN8(io_storeDataIn_1_valid,0,0);
        VL_OUT8(io_out_valid,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_3,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_4,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_5,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_6,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_7,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_13,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_15,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_19,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_21,0,0);
        VL_OUT8(io_out_bits_uop_exceptionVec_23,0,0);
        VL_OUT8(io_out_bits_uop_trigger,3,0);
        VL_OUT8(io_out_bits_uop_rfWen,0,0);
        VL_OUT8(io_out_bits_uop_pdest,7,0);
        VL_OUT8(io_out_bits_uop_robIdx_flag,0,0);
        VL_OUT8(io_out_bits_uop_robIdx_value,7,0);
        VL_OUT8(io_out_bits_debug_isMMIO,0,0);
        VL_IN8(io_dcache_req_ready,0,0);
        VL_OUT8(io_dcache_req_valid,0,0);
        VL_OUT8(io_dcache_req_bits_cmd,4,0);
        VL_OUT8(io_dcache_req_bits_word_idx,2,0);
        VL_IN8(io_dcache_resp_valid,0,0);
        VL_IN8(io_dcache_resp_bits_miss,0,0);
        VL_IN8(io_dcache_resp_bits_replay,0,0);
        VL_IN8(io_dcache_resp_bits_tl_error_tl_denied,0,0);
        VL_IN8(io_dcache_resp_bits_tl_error_tl_corrupt,0,0);
        VL_IN8(io_dcache_resp_bits_id,5,0);
        VL_IN8(io_dcache_block_lr,0,0);
        VL_OUT8(io_dtlb_req_valid,0,0);
        VL_OUT8(io_dtlb_req_bits_cmd,2,0);
        VL_OUT8(io_dtlb_req_bits_debug_robIdx_flag,0,0);
        VL_OUT8(io_dtlb_req_bits_debug_robIdx_value,7,0);
        VL_IN8(io_dtlb_resp_valid,0,0);
        VL_IN8(io_dtlb_resp_bits_pbmt_0,1,0);
        VL_IN8(io_dtlb_resp_bits_miss,0,0);
        VL_IN8(io_dtlb_resp_bits_isForVSnonLeafPTE,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_gpf_ld,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_gpf_st,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_pf_ld,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_pf_st,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_af_ld,0,0);
        VL_IN8(io_dtlb_resp_bits_excp_0_af_st,0,0);
        VL_IN8(io_pmpResp_ld,0,0);
        VL_IN8(io_pmpResp_st,0,0);
        VL_IN8(io_pmpResp_mmio,0,0);
        VL_OUT8(io_flush_sbuffer_valid,0,0);
        VL_IN8(io_flush_sbuffer_empty,0,0);
        VL_OUT8(io_feedbackSlow_valid,0,0);
        VL_OUT8(io_feedbackSlow_bits_sqIdx_flag,0,0);
        VL_OUT8(io_feedbackSlow_bits_sqIdx_value,5,0);
        VL_IN8(io_redirect_valid,0,0);
    };
    struct {
        VL_OUT8(io_exceptionInfo_valid,0,0);
        VL_OUT8(io_exceptionInfo_bits_isForVSnonLeafPTE,0,0);
        VL_IN8(io_csrCtrl_cache_error_enable,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_valid,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_addr,1,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType,1,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action,3,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tEnableVec_0,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tEnableVec_1,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tEnableVec_2,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_tEnableVec_3,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_debugMode,0,0);
        VL_IN8(io_csrCtrl_mem_trigger_triggerCanRaiseBpExp,0,0);
        CData/*3:0*/ AtomicsUnit__DOT__state;
        CData/*0:0*/ AtomicsUnit__DOT__out_valid;
        CData/*0:0*/ AtomicsUnit__DOT__data_valid;
        CData/*0:0*/ AtomicsUnit__DOT__uop_rfWen;
        CData/*0:0*/ AtomicsUnit__DOT__uop_robIdx_flag;
        CData/*7:0*/ AtomicsUnit__DOT__uop_robIdx_value;
        CData/*0:0*/ AtomicsUnit__DOT__isLr;
        CData/*0:0*/ AtomicsUnit__DOT__isSc;
        CData/*7:0*/ AtomicsUnit__DOT__pdest1;
        CData/*7:0*/ AtomicsUnit__DOT__pdest2;
        CData/*0:0*/ AtomicsUnit__DOT__pdest1Valid;
        CData/*0:0*/ AtomicsUnit__DOT__pdest2Valid;
        CData/*2:0*/ AtomicsUnit__DOT__stdCnt;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_3;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_4;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_5;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_6;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_7;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_13;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_15;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_19;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_21;
        CData/*0:0*/ AtomicsUnit__DOT__exceptionVec_23;
        CData/*3:0*/ AtomicsUnit__DOT__trigger;
        CData/*0:0*/ AtomicsUnit__DOT__atom_override_xtval;
        CData/*0:0*/ AtomicsUnit__DOT__have_sent_first_tlb_req;
        CData/*0:0*/ AtomicsUnit__DOT__is_mmio;
        CData/*0:0*/ AtomicsUnit__DOT__isForVSnonLeafPTE;
        CData/*0:0*/ AtomicsUnit__DOT___GEN;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_0;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_2;
        CData/*1:0*/ AtomicsUnit__DOT__tdata_0_matchType;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_0_select;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_0_timing;
        CData/*3:0*/ AtomicsUnit__DOT__tdata_0_action;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_0_chain;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_0_store;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_0_load;
        CData/*1:0*/ AtomicsUnit__DOT__tdata_1_matchType;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_1_select;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_1_timing;
        CData/*3:0*/ AtomicsUnit__DOT__tdata_1_action;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_1_chain;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_1_store;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_1_load;
        CData/*1:0*/ AtomicsUnit__DOT__tdata_2_matchType;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_2_select;
    };
    struct {
        CData/*0:0*/ AtomicsUnit__DOT__tdata_2_timing;
        CData/*3:0*/ AtomicsUnit__DOT__tdata_2_action;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_2_chain;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_2_store;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_2_load;
        CData/*1:0*/ AtomicsUnit__DOT__tdata_3_matchType;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_3_select;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_3_timing;
        CData/*3:0*/ AtomicsUnit__DOT__tdata_3_action;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_3_chain;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_3_store;
        CData/*0:0*/ AtomicsUnit__DOT__tdata_3_load;
        CData/*0:0*/ AtomicsUnit__DOT__tEnableVec_0;
        CData/*0:0*/ AtomicsUnit__DOT__tEnableVec_1;
        CData/*0:0*/ AtomicsUnit__DOT__tEnableVec_2;
        CData/*0:0*/ AtomicsUnit__DOT__tEnableVec_3;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerCanFireVec_0;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerCanFireVec_1;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerCanFireVec_2;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerCanFireVec_3;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_5;
        CData/*1:0*/ AtomicsUnit__DOT__pbmtReg;
        CData/*0:0*/ AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied;
        CData/*0:0*/ AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_6;
        CData/*0:0*/ AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG;
        CData/*0:0*/ AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG_1;
        CData/*0:0*/ AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_flag;
        CData/*5:0*/ AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_value;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_8;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_9;
        CData/*0:0*/ AtomicsUnit__DOT__canTriggerCacheError;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerHitVec_0;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerHitVec_1;
        CData/*0:0*/ AtomicsUnit__DOT__backendTriggerHitVec_2;
        CData/*3:0*/ AtomicsUnit__DOT__triggerAction;
        CData/*0:0*/ AtomicsUnit__DOT__addrAligned;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_10;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_11;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_12;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_13;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_14;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_15;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_16;
        CData/*3:0*/ AtomicsUnit__DOT___GEN_18;
        CData/*0:0*/ AtomicsUnit__DOT___exceptionVec_7_T_1;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_20;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_21;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_22;
        CData/*0:0*/ AtomicsUnit__DOT___GEN_23;
        CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_3;
        CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_4;
        CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_5;
        CData/*0:0*/ __Vdly__AtomicsUnit__DOT__tdata_2_timing;
        CData/*0:0*/ __Vdly__AtomicsUnit__DOT__tdata_1_timing;
        CData/*0:0*/ __Vdly__AtomicsUnit__DOT__tdata_0_timing;
        CData/*0:0*/ __Vdly__AtomicsUnit__DOT__tdata_3_timing;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VstlPhaseResult;
        CData/*0:0*/ __VicoFirstIteration;
        CData/*0:0*/ __VicoPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clock__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__reset__0;
        CData/*0:0*/ __VactPhaseResult;
    };
    struct {
        CData/*0:0*/ __VnbaPhaseResult;
        VL_IN16(io_in_bits_uop_fuOpType,8,0);
        VL_IN16(io_storeDataIn_0_bits_uop_fuOpType,8,0);
        VL_IN16(io_storeDataIn_1_bits_uop_fuOpType,8,0);
        VL_OUT16(io_dcache_req_bits_amo_mask,15,0);
        SData/*8:0*/ AtomicsUnit__DOT__uop_fuOpType;
        VL_OUTW(io_dcache_req_bits_amo_data,127,0,4);
        VL_OUTW(io_dcache_req_bits_amo_cmp,127,0,4);
        VL_INW(io_dcache_resp_bits_data,127,0,4);
        VlWide<4>/*127:0*/ AtomicsUnit__DOT__resp_data;
        VlWide<4>/*127:0*/ AtomicsUnit__DOT__dcache_resp_data;
        VlWide<4>/*127:0*/ AtomicsUnit__DOT__rdataSel;
        IData/*31:0*/ __VactIterCount;
        VL_IN64(io_in_bits_src_0,63,0);
        VL_IN64(io_storeDataIn_0_bits_data,63,0);
        VL_IN64(io_storeDataIn_1_bits_data,63,0);
        VL_OUT64(io_out_bits_data,63,0);
        VL_OUT64(io_dcache_req_bits_vaddr,49,0);
        VL_OUT64(io_dcache_req_bits_addr,47,0);
        VL_OUT64(io_dtlb_req_bits_vaddr,49,0);
        VL_OUT64(io_dtlb_req_bits_fullva,63,0);
        VL_IN64(io_dtlb_resp_bits_paddr_0,47,0);
        VL_IN64(io_dtlb_resp_bits_gpaddr_0,63,0);
        VL_IN64(io_dtlb_resp_bits_fullva,63,0);
        VL_OUT64(io_exceptionInfo_bits_vaddr,63,0);
        VL_OUT64(io_exceptionInfo_bits_gpaddr,63,0);
        VL_IN64(io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2,63,0);
        QData/*63:0*/ AtomicsUnit__DOT__rs1;
        QData/*63:0*/ AtomicsUnit__DOT__rs2_l;
        QData/*63:0*/ AtomicsUnit__DOT__rs2_h;
        QData/*63:0*/ AtomicsUnit__DOT__rd_l;
        QData/*63:0*/ AtomicsUnit__DOT__rd_h;
        QData/*47:0*/ AtomicsUnit__DOT__paddr;
        QData/*63:0*/ AtomicsUnit__DOT__gpaddr;
        QData/*63:0*/ AtomicsUnit__DOT__tdata_0_tdata2;
        QData/*63:0*/ AtomicsUnit__DOT__tdata_1_tdata2;
        QData/*63:0*/ AtomicsUnit__DOT__tdata_2_tdata2;
        QData/*63:0*/ AtomicsUnit__DOT__tdata_3_tdata2;
        VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VicoTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VnbaTriggered;
    };

    // INTERNAL VARIABLES
    VAtomicsUnitFixed__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    VAtomicsUnitFixed___024root(VAtomicsUnitFixed__Syms* symsp, const char* namep);
    ~VAtomicsUnitFixed___024root();
    VL_UNCOPYABLE(VAtomicsUnitFixed___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
