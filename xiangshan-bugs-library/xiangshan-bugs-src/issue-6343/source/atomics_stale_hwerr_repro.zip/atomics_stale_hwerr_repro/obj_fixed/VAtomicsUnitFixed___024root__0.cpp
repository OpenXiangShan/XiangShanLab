// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VAtomicsUnitFixed.h for the primary calling header

#include "VAtomicsUnitFixed__pch.h"

void VAtomicsUnitFixed___024root___eval_triggers_vec__ico(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_triggers_vec__ico\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VicoTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VicoTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VicoFirstIteration)));
}

bool VAtomicsUnitFixed___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void VAtomicsUnitFixed___024root___ico_sequent__TOP__0(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___ico_sequent__TOP__0\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.AtomicsUnit__DOT___GEN_6 = ((IData)(vlSelfRef.io_dcache_resp_valid) 
                                          & (5U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)));
    vlSelfRef.AtomicsUnit__DOT___GEN_20 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (0U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_21 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (1U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_22 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (2U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.AtomicsUnit__DOT___GEN_23 = ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid) 
                                           & (3U == (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr)));
    vlSelfRef.io_flush_sbuffer_valid = ((~ (IData)(vlSelfRef.io_flush_sbuffer_empty)) 
                                        & ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                           | ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                              | (3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__state)))));
    vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError 
        = ((IData)(vlSelfRef.io_csrCtrl_cache_error_enable) 
           & ((IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied) 
              | (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt)));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_0 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_1 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_2 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_store)))))));
    vlSelfRef.io_dcache_req_valid = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                     & ((6U == (IData)(vlSelfRef.io_dcache_req_bits_cmd))
                                         ? (~ (IData)(vlSelfRef.io_dcache_block_lr))
                                         : (IData)(vlSelfRef.AtomicsUnit__DOT__data_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN = ((IData)(vlSelfRef.io_in_valid) 
                                        & (IData)(vlSelfRef.io_in_ready));
    vlSelfRef.AtomicsUnit__DOT___GEN_5 = ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                          & ((IData)(vlSelfRef.io_dtlb_resp_valid) 
                                             & (IData)(vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req)));
    vlSelfRef.AtomicsUnit__DOT__triggerAction = ((((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                   & (1U 
                                                      == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                  | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                      & (1U 
                                                         == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                     | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                         & (1U 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                        | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                           & (1U 
                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action))))))
                                                  ? 1U
                                                  : 
                                                 (0x0000000fU 
                                                  & (- (IData)(
                                                               (1U 
                                                                & (~ 
                                                                   ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_triggerCanRaiseBpExp) 
                                                                    & (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                                        & (0U 
                                                                           == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                                       | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                                           & (0U 
                                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                                          | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                                              & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                                             | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                                                & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action)))))))))))));
    vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1 
        = ((IData)(vlSelfRef.io_pmpResp_mmio) | ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)) 
                                                 | ((IData)(vlSelfRef.io_pmpResp_ld) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_9 = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & ((IData)(vlSelfRef.io_dcache_req_ready) 
                                             & (IData)(vlSelfRef.io_dcache_req_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN_0 = ((0U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN));
    vlSelfRef.AtomicsUnit__DOT___GEN_2 = (IData)(((0U 
                                                   == 
                                                   (0x01c0U 
                                                    & (IData)(vlSelfRef.io_in_bits_uop_fuOpType))) 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN)));
    vlSelfRef.AtomicsUnit__DOT___GEN_8 = ((~ (IData)(vlSelfRef.io_dtlb_resp_bits_miss)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_5));
    vlSelfRef.AtomicsUnit__DOT___GEN_10 = (1U & ((0U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)) 
                                                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__addrAligned)) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_12 = ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_15) 
                                           | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_13) 
                                              | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_23) 
                                                 | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_21) 
                                                    | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_7) 
                                                       | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_5) 
                                                          | ((IData)(vlSelfRef.io_pmpResp_st) 
                                                             | (IData)(vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1))))))));
    vlSelfRef.AtomicsUnit__DOT___GEN_11 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10) 
                                           & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_8));
    vlSelfRef.AtomicsUnit__DOT___GEN_18 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12)
                                            ? 7U : 
                                           ((IData)(vlSelfRef.io_flush_sbuffer_empty)
                                             ? 4U : 3U));
    vlSelfRef.AtomicsUnit__DOT___GEN_13 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                           | (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12));
}

void VAtomicsUnitFixed___024root___eval_ico(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_ico\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VicoTriggered[0U])) {
        VAtomicsUnitFixed___024root___ico_sequent__TOP__0(vlSelf);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitFixed___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool VAtomicsUnitFixed___024root___eval_phase__ico(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_phase__ico\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    VAtomicsUnitFixed___024root___eval_triggers_vec__ico(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        VAtomicsUnitFixed___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = VAtomicsUnitFixed___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        VAtomicsUnitFixed___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void VAtomicsUnitFixed___024root___eval_triggers_vec__act(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_triggers_vec__act\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    ((((IData)(vlSelfRef.reset) 
                                                       & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__reset__0))) 
                                                      << 1U) 
                                                     | ((IData)(vlSelfRef.clock) 
                                                        & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__clock__0))))));
    vlSelfRef.__Vtrigprevexpr___TOP__clock__0 = vlSelfRef.clock;
    vlSelfRef.__Vtrigprevexpr___TOP__reset__0 = vlSelfRef.reset;
}

bool VAtomicsUnitFixed___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void VAtomicsUnitFixed___024root___nba_sequent__TOP__0(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_sequent__TOP__0\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_0_timing 
        = vlSelfRef.AtomicsUnit__DOT__tdata_0_timing;
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_3_timing 
        = vlSelfRef.AtomicsUnit__DOT__tdata_3_timing;
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_2_timing 
        = vlSelfRef.AtomicsUnit__DOT__tdata_2_timing;
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_1_timing 
        = vlSelfRef.AtomicsUnit__DOT__tdata_1_timing;
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_0_timing 
        = ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_20)) 
           & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_timing));
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_3_timing 
        = ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_23)) 
           & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_timing));
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_2_timing 
        = ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_22)) 
           & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_timing));
    vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_1_timing 
        = ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_21)) 
           & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_timing));
    if (vlSelfRef.io_in_valid) {
        vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_flag 
            = vlSelfRef.io_in_bits_uop_sqIdx_flag;
        vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_value 
            = vlSelfRef.io_in_bits_uop_sqIdx_value;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_2) {
        vlSelfRef.AtomicsUnit__DOT__pdest1 = vlSelfRef.io_in_bits_uop_pdest;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
        vlSelfRef.AtomicsUnit__DOT__uop_rfWen = vlSelfRef.io_in_bits_uop_rfWen;
        vlSelfRef.AtomicsUnit__DOT__uop_robIdx_flag 
            = vlSelfRef.io_in_bits_uop_robIdx_flag;
        vlSelfRef.AtomicsUnit__DOT__uop_robIdx_value 
            = vlSelfRef.io_in_bits_uop_robIdx_value;
    }
    if ((1U & (~ (((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN)) 
                   | (0U == (7U & ((IData)(vlSelfRef.io_in_bits_uop_fuOpType) 
                                   >> 6U)))) | (2U 
                                                != 
                                                (7U 
                                                 & ((IData)(vlSelfRef.io_in_bits_uop_fuOpType) 
                                                    >> 6U))))))) {
        vlSelfRef.AtomicsUnit__DOT__pdest2 = vlSelfRef.io_in_bits_uop_pdest;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_22) {
        vlSelfRef.AtomicsUnit__DOT__tdata_2_load = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load;
        vlSelfRef.AtomicsUnit__DOT__tdata_2_select 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select;
        vlSelfRef.AtomicsUnit__DOT__tdata_2_store = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store;
        vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2;
        vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType;
        vlSelfRef.AtomicsUnit__DOT__tdata_2_action 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_21) {
        vlSelfRef.AtomicsUnit__DOT__tdata_1_load = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load;
        vlSelfRef.AtomicsUnit__DOT__tdata_1_select 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select;
        vlSelfRef.AtomicsUnit__DOT__tdata_1_store = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store;
        vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType;
        vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2;
        vlSelfRef.AtomicsUnit__DOT__tdata_1_action 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_20) {
        vlSelfRef.AtomicsUnit__DOT__tdata_0_select 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select;
        vlSelfRef.AtomicsUnit__DOT__tdata_0_store = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store;
        vlSelfRef.AtomicsUnit__DOT__tdata_0_load = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load;
        vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2;
        vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType;
        vlSelfRef.AtomicsUnit__DOT__tdata_0_action 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_5) {
        vlSelfRef.AtomicsUnit__DOT__isForVSnonLeafPTE 
            = vlSelfRef.io_dtlb_resp_bits_isForVSnonLeafPTE;
        vlSelfRef.AtomicsUnit__DOT__gpaddr = vlSelfRef.io_dtlb_resp_bits_gpaddr_0;
        vlSelfRef.AtomicsUnit__DOT__paddr = vlSelfRef.io_dtlb_resp_bits_paddr_0;
    }
    if (((IData)(vlSelfRef.io_storeDataIn_1_valid) 
         & (0x00c0U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_1_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rs2_h = vlSelfRef.io_storeDataIn_1_bits_data;
    } else if (((IData)(vlSelfRef.io_storeDataIn_0_valid) 
                & (0x00c0U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_0_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rs2_h = vlSelfRef.io_storeDataIn_0_bits_data;
    }
    if (((IData)(vlSelfRef.io_storeDataIn_1_valid) 
         & (0x0080U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_1_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rd_h = vlSelfRef.io_storeDataIn_1_bits_data;
    } else if (((IData)(vlSelfRef.io_storeDataIn_0_valid) 
                & (0x0080U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_0_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rd_h = vlSelfRef.io_storeDataIn_0_bits_data;
    }
    if (((IData)(vlSelfRef.io_storeDataIn_1_valid) 
         & (0x0040U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_1_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rs2_l = vlSelfRef.io_storeDataIn_1_bits_data;
    } else if (((IData)(vlSelfRef.io_storeDataIn_0_valid) 
                & (0x0040U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_0_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rs2_l = vlSelfRef.io_storeDataIn_0_bits_data;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_23) {
        vlSelfRef.AtomicsUnit__DOT__tdata_3_action 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action;
    }
    if (((IData)(vlSelfRef.io_storeDataIn_1_valid) 
         & (0U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_1_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rd_l = vlSelfRef.io_storeDataIn_1_bits_data;
    } else if (((IData)(vlSelfRef.io_storeDataIn_0_valid) 
                & (0U == (0x01c0U & (IData)(vlSelfRef.io_storeDataIn_0_bits_uop_fuOpType))))) {
        vlSelfRef.AtomicsUnit__DOT__rd_l = vlSelfRef.io_storeDataIn_0_bits_data;
    }
    if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
        vlSelfRef.AtomicsUnit__DOT__is_mmio = ((2U 
                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)) 
                                               | ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)) 
                                                  & (IData)(vlSelfRef.io_pmpResp_mmio)));
    }
    if ((6U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
        if (vlSelfRef.AtomicsUnit__DOT__isSc) {
            vlSelfRef.AtomicsUnit__DOT__resp_data[0U] 
                = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[0U];
            vlSelfRef.AtomicsUnit__DOT__resp_data[1U] 
                = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U];
            vlSelfRef.AtomicsUnit__DOT__resp_data[2U] 
                = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U];
            vlSelfRef.AtomicsUnit__DOT__resp_data[3U] 
                = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U];
        } else {
            vlSelfRef.AtomicsUnit__DOT__resp_data[0U] 
                = ((((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                      ? vlSelfRef.AtomicsUnit__DOT__rdataSel[0U]
                      : 0U) | ((3U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                ? (IData)((((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__rdataSel[1U])) 
                                            << 0x00000020U) 
                                           | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__rdataSel[0U]))))
                                : 0U)) | ((0U != (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                           ? 0U : vlSelfRef.AtomicsUnit__DOT__rdataSel[0U]));
            vlSelfRef.AtomicsUnit__DOT__resp_data[1U] 
                = ((((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                      ? (- (IData)((vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] 
                                    >> 0x0000001fU)))
                      : 0U) | ((3U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                ? (IData)(((((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__rdataSel[1U])) 
                                             << 0x00000020U) 
                                            | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__rdataSel[0U]))) 
                                           >> 0x00000020U))
                                : 0U)) | ((0U != (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                           ? 0U : vlSelfRef.AtomicsUnit__DOT__rdataSel[1U]));
            vlSelfRef.AtomicsUnit__DOT__resp_data[2U] 
                = ((((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                      ? (- (IData)((vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] 
                                    >> 0x0000001fU)))
                      : 0U) | ((3U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                ? (IData)((- (QData)((IData)(
                                                             (vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] 
                                                              >> 0x0000001fU)))))
                                : 0U)) | ((0U != (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                           ? 0U : vlSelfRef.AtomicsUnit__DOT__rdataSel[2U]));
            vlSelfRef.AtomicsUnit__DOT__resp_data[3U] 
                = ((((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                      ? (- (IData)((vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] 
                                    >> 0x0000001fU)))
                      : 0U) | ((3U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                ? (IData)(((- (QData)((IData)(
                                                              (vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] 
                                                               >> 0x0000001fU)))) 
                                           >> 0x00000020U))
                                : 0U)) | ((0U != (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                           ? 0U : vlSelfRef.AtomicsUnit__DOT__rdataSel[3U]));
        }
    }
    vlSelfRef.io_feedbackSlow_bits_sqIdx_flag = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_flag;
    vlSelfRef.io_feedbackSlow_bits_sqIdx_value = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_bits_sqIdx_r_value;
    vlSelfRef.io_out_bits_uop_rfWen = vlSelfRef.AtomicsUnit__DOT__uop_rfWen;
    vlSelfRef.io_out_bits_uop_robIdx_flag = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_flag;
    vlSelfRef.io_dtlb_req_bits_debug_robIdx_flag = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_flag;
    vlSelfRef.io_out_bits_uop_robIdx_value = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_value;
    vlSelfRef.io_dtlb_req_bits_debug_robIdx_value = vlSelfRef.AtomicsUnit__DOT__uop_robIdx_value;
    vlSelfRef.io_exceptionInfo_bits_isForVSnonLeafPTE 
        = vlSelfRef.AtomicsUnit__DOT__isForVSnonLeafPTE;
    vlSelfRef.io_exceptionInfo_bits_gpaddr = vlSelfRef.AtomicsUnit__DOT__gpaddr;
    vlSelfRef.io_dcache_req_bits_addr = (0x0000ffffffffffc0ULL 
                                         & vlSelfRef.AtomicsUnit__DOT__paddr);
    vlSelfRef.io_dcache_req_bits_word_idx = (7U & (IData)(
                                                          (vlSelfRef.AtomicsUnit__DOT__paddr 
                                                           >> 3U)));
    vlSelfRef.io_out_bits_debug_isMMIO = vlSelfRef.AtomicsUnit__DOT__is_mmio;
    if (((IData)(vlSelfRef.io_dtlb_resp_valid) & (~ (IData)(vlSelfRef.io_dtlb_resp_bits_miss)))) {
        vlSelfRef.AtomicsUnit__DOT__pbmtReg = vlSelfRef.io_dtlb_resp_bits_pbmt_0;
    }
    if ((1U & (~ ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_6)) 
                  | (IData)(vlSelfRef.io_dcache_resp_bits_miss))))) {
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[0U] 
            = vlSelfRef.io_dcache_resp_bits_data[0U];
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U] 
            = vlSelfRef.io_dcache_resp_bits_data[1U];
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U] 
            = vlSelfRef.io_dcache_resp_bits_data[2U];
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U] 
            = vlSelfRef.io_dcache_resp_bits_data[3U];
    }
    if ((0U == (7U & (IData)(vlSelfRef.AtomicsUnit__DOT__paddr)))) {
        vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[0U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[2U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[3U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U];
    } else {
        vlSelfRef.AtomicsUnit__DOT__rdataSel[0U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[1U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[1U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[2U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[2U] = vlSelfRef.AtomicsUnit__DOT__dcache_resp_data[3U];
        vlSelfRef.AtomicsUnit__DOT__rdataSel[3U] = 0U;
    }
}

void VAtomicsUnitFixed___024root___nba_sequent__TOP__1(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_sequent__TOP__1\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __Vdly__AtomicsUnit__DOT__data_valid;
    __Vdly__AtomicsUnit__DOT__data_valid = 0;
    CData/*2:0*/ __Vdly__AtomicsUnit__DOT__stdCnt;
    __Vdly__AtomicsUnit__DOT__stdCnt = 0;
    CData/*0:0*/ __Vdly__AtomicsUnit__DOT__exceptionVec_5;
    __Vdly__AtomicsUnit__DOT__exceptionVec_5 = 0;
    CData/*3:0*/ __Vdly__AtomicsUnit__DOT__state;
    __Vdly__AtomicsUnit__DOT__state = 0;
    CData/*0:0*/ __Vdly__AtomicsUnit__DOT__exceptionVec_7;
    __Vdly__AtomicsUnit__DOT__exceptionVec_7 = 0;
    // Body
    __Vdly__AtomicsUnit__DOT__exceptionVec_5 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_5;
    __Vdly__AtomicsUnit__DOT__exceptionVec_7 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_7;
    __Vdly__AtomicsUnit__DOT__stdCnt = vlSelfRef.AtomicsUnit__DOT__stdCnt;
    __Vdly__AtomicsUnit__DOT__data_valid = vlSelfRef.AtomicsUnit__DOT__data_valid;
    __Vdly__AtomicsUnit__DOT__state = vlSelfRef.AtomicsUnit__DOT__state;
    vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                                   | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_0)) 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req))));
    vlSelfRef.AtomicsUnit__DOT__pdest1Valid = ((1U 
                                                & (~ (IData)(vlSelfRef.reset))) 
                                               && (((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16)) 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_15)) 
                                                   & ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_2) 
                                                      | (IData)(vlSelfRef.AtomicsUnit__DOT__pdest1Valid))));
    vlSelfRef.AtomicsUnit__DOT__pdest2Valid = ((1U 
                                                & (~ (IData)(vlSelfRef.reset))) 
                                               && (((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16)) 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_15)) 
                                                   & ((((IData)(vlSelfRef.AtomicsUnit__DOT___GEN) 
                                                        & (0x0080U 
                                                           == 
                                                           (0x01c0U 
                                                            & (IData)(vlSelfRef.io_in_bits_uop_fuOpType)))) 
                                                       & (0U 
                                                          != 
                                                          (7U 
                                                           & ((IData)(vlSelfRef.io_in_bits_uop_fuOpType) 
                                                              >> 6U)))) 
                                                      | (IData)(vlSelfRef.AtomicsUnit__DOT__pdest2Valid))));
    vlSelfRef.AtomicsUnit__DOT__atom_override_xtval 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (
                                                   (~ (IData)(vlSelfRef.io_redirect_valid)) 
                                                   & ((2U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__state))
                                                       ? 
                                                      ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_13) 
                                                       | (IData)(vlSelfRef.AtomicsUnit__DOT__atom_override_xtval))
                                                       : 
                                                      ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                                       | (IData)(vlSelfRef.AtomicsUnit__DOT__atom_override_xtval)))));
    if (vlSelfRef.reset) {
        __Vdly__AtomicsUnit__DOT__exceptionVec_5 = 0U;
        __Vdly__AtomicsUnit__DOT__exceptionVec_7 = 0U;
        __Vdly__AtomicsUnit__DOT__data_valid = 0U;
        __Vdly__AtomicsUnit__DOT__stdCnt = 0U;
        __Vdly__AtomicsUnit__DOT__state = 0U;
        vlSelfRef.AtomicsUnit__DOT__trigger = 0x0fU;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_3 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_23 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_21 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_13 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_15 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_6 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_4 = 0U;
        vlSelfRef.AtomicsUnit__DOT__exceptionVec_19 = 0U;
    } else {
        __Vdly__AtomicsUnit__DOT__data_valid = (((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16)) 
                                                 & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_15)) 
                                                & ((IData)(vlSelfRef.AtomicsUnit__DOT__data_valid)
                                                    ? (IData)(vlSelfRef.AtomicsUnit__DOT__data_valid)
                                                    : 
                                                   ((0U 
                                                     != (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                                    & ((((0x002cU 
                                                          == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                         & (4U 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__stdCnt))) 
                                                        | (((0x002eU 
                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                            | (0x002fU 
                                                               == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))) 
                                                           & (2U 
                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__stdCnt)))) 
                                                       | ((0x0bU 
                                                           != 
                                                           (0x0000000fU 
                                                            & ((IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType) 
                                                               >> 2U))) 
                                                          & (1U 
                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__stdCnt)))))));
        __Vdly__AtomicsUnit__DOT__stdCnt = ((1U & ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16) 
                                                   | (~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_15))))
                                             ? 0U : 
                                            (7U & ((IData)(vlSelfRef.AtomicsUnit__DOT__stdCnt) 
                                                   + 
                                                   (3U 
                                                    & ((IData)(vlSelfRef.io_storeDataIn_0_valid) 
                                                       + (IData)(vlSelfRef.io_storeDataIn_1_valid))))));
        if (vlSelfRef.AtomicsUnit__DOT___GEN_16) {
            __Vdly__AtomicsUnit__DOT__state = 0U;
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_14) {
            __Vdly__AtomicsUnit__DOT__state = ((0x002cU 
                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                               << 3U);
        } else if ((6U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
            __Vdly__AtomicsUnit__DOT__state = 7U;
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_6) {
            if (vlSelfRef.io_dcache_resp_bits_miss) {
                if (vlSelfRef.io_dcache_resp_bits_replay) {
                    __Vdly__AtomicsUnit__DOT__state = 4U;
                } else if (vlSelfRef.AtomicsUnit__DOT___GEN_9) {
                    __Vdly__AtomicsUnit__DOT__state = 5U;
                } else if ((3U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
                    if (vlSelfRef.io_flush_sbuffer_empty) {
                        __Vdly__AtomicsUnit__DOT__state = 4U;
                    } else if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
                        __Vdly__AtomicsUnit__DOT__state 
                            = (3U | ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12) 
                                     << 2U));
                    } else if (vlSelfRef.AtomicsUnit__DOT___GEN_8) {
                        __Vdly__AtomicsUnit__DOT__state 
                            = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10)
                                ? 7U : 2U);
                    } else if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
                        __Vdly__AtomicsUnit__DOT__state = 1U;
                    }
                } else if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
                    __Vdly__AtomicsUnit__DOT__state 
                        = vlSelfRef.AtomicsUnit__DOT___GEN_18;
                } else if (vlSelfRef.AtomicsUnit__DOT___GEN_8) {
                    __Vdly__AtomicsUnit__DOT__state 
                        = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10)
                            ? 7U : 2U);
                } else if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
                    __Vdly__AtomicsUnit__DOT__state = 1U;
                }
            } else {
                __Vdly__AtomicsUnit__DOT__state = 6U;
            }
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_9) {
            __Vdly__AtomicsUnit__DOT__state = 5U;
        } else if ((3U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
            if (vlSelfRef.io_flush_sbuffer_empty) {
                __Vdly__AtomicsUnit__DOT__state = 4U;
            } else if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
                __Vdly__AtomicsUnit__DOT__state = (3U 
                                                   | ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12) 
                                                      << 2U));
            } else if (vlSelfRef.AtomicsUnit__DOT___GEN_8) {
                __Vdly__AtomicsUnit__DOT__state = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10)
                                                    ? 7U
                                                    : 2U);
            } else if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
                __Vdly__AtomicsUnit__DOT__state = 1U;
            }
        } else if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
            __Vdly__AtomicsUnit__DOT__state = vlSelfRef.AtomicsUnit__DOT___GEN_18;
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_8) {
            __Vdly__AtomicsUnit__DOT__state = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10)
                                                ? 7U
                                                : 2U);
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
            __Vdly__AtomicsUnit__DOT__state = 1U;
        }
        if (vlSelfRef.AtomicsUnit__DOT___GEN_5) {
            vlSelfRef.AtomicsUnit__DOT__trigger = vlSelfRef.AtomicsUnit__DOT__triggerAction;
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_3 
                = (0U == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction));
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_23 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_gpf_st;
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_21 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_gpf_ld;
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_13 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_pf_ld;
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_15 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_pf_st;
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_6 
                = (1U & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__addrAligned)) 
                         & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))));
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_4 
                = ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__addrAligned)) 
                   & (IData)(vlSelfRef.AtomicsUnit__DOT__isLr));
        }
        if (((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16) 
             | ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_14) 
                & (0x002cU != (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) {
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_19 = 0U;
        }
        if ((6U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
            __Vdly__AtomicsUnit__DOT__exceptionVec_5 
                = (((IData)(vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError) 
                    & (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                   & (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied));
            __Vdly__AtomicsUnit__DOT__exceptionVec_7 
                = (((IData)(vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError) 
                    & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))) 
                   & (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied));
            vlSelfRef.AtomicsUnit__DOT__exceptionVec_19 
                = (((IData)(vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError) 
                    & (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt)) 
                   & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied)));
        } else if ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
            __Vdly__AtomicsUnit__DOT__exceptionVec_5 
                = ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_5) 
                   | ((IData)(vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1) 
                      & (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)));
            __Vdly__AtomicsUnit__DOT__exceptionVec_7 
                = (((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_7) 
                    | (IData)(vlSelfRef.io_pmpResp_st)) 
                   | ((IData)(vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1) 
                      & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))));
        } else if (vlSelfRef.AtomicsUnit__DOT___GEN_5) {
            __Vdly__AtomicsUnit__DOT__exceptionVec_5 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_af_ld;
            __Vdly__AtomicsUnit__DOT__exceptionVec_7 
                = vlSelfRef.io_dtlb_resp_bits_excp_0_af_st;
        }
    }
    vlSelfRef.AtomicsUnit__DOT__out_valid = ((1U & 
                                              (~ (IData)(vlSelfRef.reset))) 
                                             && ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_16)) 
                                                 & ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_14)
                                                     ? 
                                                    (0x002cU 
                                                     == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))
                                                     : 
                                                    ((6U 
                                                      == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                                     | ((2U 
                                                         == (IData)(vlSelfRef.AtomicsUnit__DOT__state))
                                                         ? 
                                                        ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_13) 
                                                         | (IData)(vlSelfRef.AtomicsUnit__DOT__out_valid))
                                                         : 
                                                        ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                                         | (IData)(vlSelfRef.AtomicsUnit__DOT__out_valid)))))));
    vlSelfRef.AtomicsUnit__DOT__tEnableVec_2 = ((1U 
                                                 & (~ (IData)(vlSelfRef.reset))) 
                                                && (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_2));
    vlSelfRef.AtomicsUnit__DOT__tEnableVec_1 = ((1U 
                                                 & (~ (IData)(vlSelfRef.reset))) 
                                                && (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_1));
    vlSelfRef.AtomicsUnit__DOT__tEnableVec_0 = ((1U 
                                                 & (~ (IData)(vlSelfRef.reset))) 
                                                && (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_0));
    vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG_1 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (IData)(vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_0) 
                                                   & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_chain))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (
                                                   (((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_chain) 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_0)) 
                                                      | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_chain))) 
                                                     & ((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_chain) 
                                                          & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain))) 
                                                         & ((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_timing) 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_timing))) 
                                                        | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_chain)))) 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_1)) 
                                                   & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (
                                                   (((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain) 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_1)) 
                                                      | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain))) 
                                                     & ((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain) 
                                                          & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain))) 
                                                         & ((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_timing) 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_timing))) 
                                                        | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_chain)))) 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_2)) 
                                                   & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (
                                                   (((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain) 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_2)) 
                                                      | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain))) 
                                                     & ((((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain) 
                                                          & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_chain))) 
                                                         & ((IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_timing) 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_timing))) 
                                                        | (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_chain)))) 
                                                    & (((((((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_select)) 
                                                            & (~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode))) 
                                                           & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))) 
                                                          & ((3U 
                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType))
                                                              ? 
                                                             ((0x0003ffffffffffffULL 
                                                               & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                              < 
                                                              (0x0003ffffffffffffULL 
                                                               & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2))
                                                              : 
                                                             ((2U 
                                                               == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType))
                                                               ? 
                                                              ((0x0003ffffffffffffULL 
                                                                & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                               >= 
                                                               (0x0003ffffffffffffULL 
                                                                & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2))
                                                               : 
                                                              ((0U 
                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType)) 
                                                               & ((0x0003ffffffffffffULL 
                                                                   & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                                  == 
                                                                  (0x0003ffffffffffffULL 
                                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2)))))) 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_3)) 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_store)) 
                                                       | ((((((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_select)) 
                                                              & (~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode))) 
                                                             & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc))) 
                                                            & ((3U 
                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType))
                                                                ? 
                                                               ((0x0003ffffffffffffULL 
                                                                 & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                                < 
                                                                (0x0003ffffffffffffULL 
                                                                 & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2))
                                                                : 
                                                               ((2U 
                                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType))
                                                                 ? 
                                                                ((0x0003ffffffffffffULL 
                                                                  & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                                 >= 
                                                                 (0x0003ffffffffffffULL 
                                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2))
                                                                 : 
                                                                ((0U 
                                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType)) 
                                                                 & ((0x0003ffffffffffffULL 
                                                                     & vlSelfRef.AtomicsUnit__DOT__rs1) 
                                                                    == 
                                                                    (0x0003ffffffffffffULL 
                                                                     & vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2)))))) 
                                                           & (IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_3)) 
                                                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_load)))) 
                                                   & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_chain))));
    vlSelfRef.AtomicsUnit__DOT__exceptionVec_5 = __Vdly__AtomicsUnit__DOT__exceptionVec_5;
    vlSelfRef.AtomicsUnit__DOT__exceptionVec_7 = __Vdly__AtomicsUnit__DOT__exceptionVec_7;
    vlSelfRef.AtomicsUnit__DOT__stdCnt = __Vdly__AtomicsUnit__DOT__stdCnt;
    vlSelfRef.AtomicsUnit__DOT__data_valid = __Vdly__AtomicsUnit__DOT__data_valid;
    vlSelfRef.AtomicsUnit__DOT__state = __Vdly__AtomicsUnit__DOT__state;
    vlSelfRef.io_exceptionInfo_valid = vlSelfRef.AtomicsUnit__DOT__atom_override_xtval;
    vlSelfRef.io_out_bits_uop_exceptionVec_5 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_5;
    vlSelfRef.io_out_bits_uop_exceptionVec_7 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_7;
    vlSelfRef.io_out_bits_uop_trigger = vlSelfRef.AtomicsUnit__DOT__trigger;
    vlSelfRef.io_out_bits_uop_exceptionVec_3 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_3;
    vlSelfRef.io_feedbackSlow_valid = vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG_1;
    vlSelfRef.AtomicsUnit__DOT__io_feedbackSlow_valid_last_REG 
        = ((1U & (~ (IData)(vlSelfRef.reset))) && (IData)(vlSelfRef.io_in_valid));
    vlSelfRef.io_out_bits_uop_exceptionVec_23 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_23;
    vlSelfRef.io_out_bits_uop_exceptionVec_21 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_21;
    vlSelfRef.io_out_bits_uop_exceptionVec_13 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_13;
    vlSelfRef.io_out_bits_uop_exceptionVec_15 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_15;
    vlSelfRef.io_out_bits_uop_exceptionVec_6 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_6;
    vlSelfRef.io_out_bits_uop_exceptionVec_4 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_4;
    vlSelfRef.AtomicsUnit__DOT__tEnableVec_3 = ((1U 
                                                 & (~ (IData)(vlSelfRef.reset))) 
                                                && (IData)(vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_3));
    vlSelfRef.io_out_bits_uop_exceptionVec_19 = vlSelfRef.AtomicsUnit__DOT__exceptionVec_19;
    vlSelfRef.io_out_valid = ((IData)(vlSelfRef.AtomicsUnit__DOT__out_valid) 
                              & ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))
                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__pdest2Valid)
                                  : (IData)(vlSelfRef.AtomicsUnit__DOT__pdest1Valid)));
    vlSelfRef.io_dtlb_req_valid = (1U == (IData)(vlSelfRef.AtomicsUnit__DOT__state));
    vlSelfRef.AtomicsUnit__DOT___GEN_16 = ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                           & (IData)(vlSelfRef.io_out_valid));
    vlSelfRef.AtomicsUnit__DOT___GEN_14 = ((7U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                           & (IData)(vlSelfRef.io_out_valid));
    vlSelfRef.io_flush_sbuffer_valid = ((~ (IData)(vlSelfRef.io_flush_sbuffer_empty)) 
                                        & ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                           | ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                              | (3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__state)))));
}

extern const VlUnpacked<CData/*4:0*/, 512> VAtomicsUnitFixed__ConstPool__TABLE_heef4d9af_0;

void VAtomicsUnitFixed___024root___nba_sequent__TOP__2(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_sequent__TOP__2\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    QData/*63:0*/ AtomicsUnit__DOT___rs2_T;
    AtomicsUnit__DOT___rs2_T = 0;
    CData/*4:0*/ AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60;
    AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60 = 0;
    SData/*10:0*/ AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6;
    AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6 = 0;
    SData/*8:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1 
        = ((IData)(vlSelfRef.io_pmpResp_mmio) | ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)) 
                                                 | ((IData)(vlSelfRef.io_pmpResp_ld) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__pbmtReg)))));
    vlSelfRef.AtomicsUnit__DOT__tdata_0_timing = vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_0_timing;
    vlSelfRef.AtomicsUnit__DOT__tdata_1_timing = vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_1_timing;
    vlSelfRef.AtomicsUnit__DOT__tdata_3_timing = vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_3_timing;
    vlSelfRef.AtomicsUnit__DOT__tdata_2_timing = vlSelfRef.__Vdly__AtomicsUnit__DOT__tdata_2_timing;
    if (vlSelfRef.AtomicsUnit__DOT___GEN_20) {
        vlSelfRef.AtomicsUnit__DOT__tdata_0_chain = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_21) {
        vlSelfRef.AtomicsUnit__DOT__tdata_1_chain = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_23) {
        vlSelfRef.AtomicsUnit__DOT__tdata_3_chain = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain;
        vlSelfRef.AtomicsUnit__DOT__tdata_3_select 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select;
        vlSelfRef.AtomicsUnit__DOT__tdata_3_matchType 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType;
        vlSelfRef.AtomicsUnit__DOT__tdata_3_tdata2 
            = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2;
        vlSelfRef.AtomicsUnit__DOT__tdata_3_store = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store;
        vlSelfRef.AtomicsUnit__DOT__tdata_3_load = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_22) {
        vlSelfRef.AtomicsUnit__DOT__tdata_2_chain = vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_5) {
        vlSelfRef.AtomicsUnit__DOT__rs1 = vlSelfRef.io_dtlb_resp_bits_fullva;
    } else if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
        vlSelfRef.AtomicsUnit__DOT__rs1 = vlSelfRef.io_in_bits_src_0;
    }
    if ((1U & (~ ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_6)) 
                  | (IData)(vlSelfRef.io_dcache_resp_bits_miss))))) {
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt 
            = vlSelfRef.io_dcache_resp_bits_tl_error_tl_corrupt;
        vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied 
            = vlSelfRef.io_dcache_resp_bits_tl_error_tl_denied;
    }
    if (vlSelfRef.AtomicsUnit__DOT___GEN_0) {
        vlSelfRef.AtomicsUnit__DOT__uop_fuOpType = vlSelfRef.io_in_bits_uop_fuOpType;
    }
    vlSelfRef.io_dcache_req_bits_vaddr = (0x0003ffffffffffc0ULL 
                                          & vlSelfRef.AtomicsUnit__DOT__rs1);
    vlSelfRef.io_dtlb_req_bits_fullva = vlSelfRef.AtomicsUnit__DOT__rs1;
    vlSelfRef.io_exceptionInfo_bits_vaddr = vlSelfRef.AtomicsUnit__DOT__rs1;
    vlSelfRef.io_dtlb_req_bits_vaddr = (0x0003ffffffffffffULL 
                                        & vlSelfRef.AtomicsUnit__DOT__rs1);
    vlSelfRef.AtomicsUnit__DOT__canTriggerCacheError 
        = ((IData)(vlSelfRef.io_csrCtrl_cache_error_enable) 
           & ((IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_denied) 
              | (IData)(vlSelfRef.AtomicsUnit__DOT__dcache_resp_tl_error_tl_corrupt)));
    vlSelfRef.io_dcache_req_bits_amo_cmp[0U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[1U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(
                                                               (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                >> 0x00000020U))
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(
                                                                 (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                  >> 0x00000020U)))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[2U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(vlSelfRef.AtomicsUnit__DOT__rd_h))));
    vlSelfRef.io_dcache_req_bits_amo_cmp[3U] = (((2U 
                                                  == 
                                                  (3U 
                                                   & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                  ? (IData)(vlSelfRef.AtomicsUnit__DOT__rd_l)
                                                  : 0U) 
                                                | (((3U 
                                                     == 
                                                     (3U 
                                                      & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                     ? (IData)(
                                                               (vlSelfRef.AtomicsUnit__DOT__rd_l 
                                                                >> 0x00000020U))
                                                     : 0U) 
                                                   | ((0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                       ? 0U
                                                       : (IData)(
                                                                 (vlSelfRef.AtomicsUnit__DOT__rd_h 
                                                                  >> 0x00000020U)))));
    AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6 
        = (0x000007ffU & (((IData)(0x000fU) << (7U 
                                                & (IData)(vlSelfRef.AtomicsUnit__DOT__paddr))) 
                          & (- (IData)((2U == (3U & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))));
    AtomicsUnit__DOT___rs2_T = ((0x0bU == (0x0000000fU 
                                           & ((IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType) 
                                              >> 2U)))
                                 ? vlSelfRef.AtomicsUnit__DOT__rs2_l
                                 : vlSelfRef.AtomicsUnit__DOT__rd_l);
    vlSelfRef.AtomicsUnit__DOT__addrAligned = (((2U 
                                                 == 
                                                 (3U 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))) 
                                                & (0U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1)))) 
                                               | (((3U 
                                                    == 
                                                    (3U 
                                                     & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))) 
                                                   & (0U 
                                                      == 
                                                      (7U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1)))) 
                                                  | ((~ 
                                                      (0U 
                                                       != 
                                                       (3U 
                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                     & (0U 
                                                        == 
                                                        (0x0000000fU 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__rs1))))));
    __Vtableidx1 = vlSelfRef.AtomicsUnit__DOT__uop_fuOpType;
    AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60 
        = VAtomicsUnitFixed__ConstPool__TABLE_heef4d9af_0
        [__Vtableidx1];
    vlSelfRef.AtomicsUnit__DOT__isSc = ((6U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                        | (7U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)));
    vlSelfRef.AtomicsUnit__DOT__isLr = ((2U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                        | (3U == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_0_tdata2)))));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_1_tdata2)))));
    vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5 = ((3U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType))
                                                 ? 
                                                (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                 < 
                                                 (0x0003ffffffffffffULL 
                                                  & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2))
                                                 : 
                                                ((2U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType))
                                                  ? 
                                                 (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                  >= 
                                                  (0x0003ffffffffffffULL 
                                                   & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2))
                                                  : 
                                                 ((0U 
                                                   == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_matchType)) 
                                                  & (vlSelfRef.io_dtlb_req_bits_vaddr 
                                                     == 
                                                     (0x0003ffffffffffffULL 
                                                      & vlSelfRef.AtomicsUnit__DOT__tdata_2_tdata2)))));
    vlSelfRef.io_dcache_req_bits_amo_mask = (0x0000ffffU 
                                             & ((- (IData)(
                                                           (1U 
                                                            & (~ 
                                                               (0U 
                                                                != 
                                                                (3U 
                                                                 & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))))) 
                                                | ((0x00000700U 
                                                    & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6)) 
                                                   | (0x000000ffU 
                                                      & ((IData)(AtomicsUnit__DOT___io_dcache_req_bits_amo_mask_T_6) 
                                                         | (- (IData)(
                                                                      (3U 
                                                                       == 
                                                                       (3U 
                                                                        & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))))))));
    vlSelfRef.io_dcache_req_bits_amo_data[0U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(AtomicsUnit__DOT___rs2_T))));
    vlSelfRef.io_dcache_req_bits_amo_data[1U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(
                                                                (AtomicsUnit__DOT___rs2_T 
                                                                 >> 0x00000020U))
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(
                                                                  (AtomicsUnit__DOT___rs2_T 
                                                                   >> 0x00000020U)))));
    vlSelfRef.io_dcache_req_bits_amo_data[2U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(vlSelfRef.AtomicsUnit__DOT__rs2_h))));
    vlSelfRef.io_dcache_req_bits_amo_data[3U] = (((2U 
                                                   == 
                                                   (3U 
                                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                   ? (IData)(AtomicsUnit__DOT___rs2_T)
                                                   : 0U) 
                                                 | (((3U 
                                                      == 
                                                      (3U 
                                                       & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                      ? (IData)(
                                                                (AtomicsUnit__DOT___rs2_T 
                                                                 >> 0x00000020U))
                                                      : 0U) 
                                                    | ((0U 
                                                        != 
                                                        (3U 
                                                         & (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))
                                                        ? 0U
                                                        : (IData)(
                                                                  (vlSelfRef.AtomicsUnit__DOT__rs2_h 
                                                                   >> 0x00000020U)))));
    vlSelfRef.io_dcache_req_bits_cmd = (((0x00000010U 
                                          & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60)) 
                                         | (0x0000000fU 
                                            & (((8U 
                                                 & ((0xfffffff8U 
                                                     & (IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60)) 
                                                    | ((0x000fU 
                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                       << 3U))) 
                                                | (7U 
                                                   & ((IData)(AtomicsUnit__DOT___io_dcache_req_bits_cmd_T_60) 
                                                      | ((6U 
                                                          & (- (IData)(
                                                                       (3U 
                                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                         | ((- (IData)(
                                                                       (7U 
                                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                            | ((0x000bU 
                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)) 
                                                               << 2U)))))) 
                                               | ((9U 
                                                   & (- (IData)(
                                                                (0x0013U 
                                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                  | ((0x0bU 
                                                      & (- (IData)(
                                                                   (0x0017U 
                                                                    == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                     | ((0x0aU 
                                                         & (- (IData)(
                                                                      (0x001bU 
                                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                        | ((0x0cU 
                                                            & (- (IData)(
                                                                         (0x001fU 
                                                                          == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                           | ((0x0dU 
                                                               & (- (IData)(
                                                                            (0x0023U 
                                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                                              | ((- (IData)(
                                                                            (0x002bU 
                                                                             == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))) 
                                                                 | (0x0eU 
                                                                    & (- (IData)(
                                                                                (0x0027U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))))))))))) 
                                        | ((0x18U & 
                                            (- (IData)(
                                                       (0x002cU 
                                                        == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))))) 
                                           | (0x1bU 
                                              & (- (IData)(
                                                           (0x002fU 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType)))))));
    vlSelfRef.io_dtlb_req_bits_cmd = (4U | (1U & (~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr))));
}

void VAtomicsUnitFixed___024root___nba_comb__TOP__0(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_comb__TOP__0\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.AtomicsUnit__DOT__triggerAction = ((((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                   & (1U 
                                                      == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                  | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                      & (1U 
                                                         == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                     | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                         & (1U 
                                                            == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                        | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                           & (1U 
                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action))))))
                                                  ? 1U
                                                  : 
                                                 (0x0000000fU 
                                                  & (- (IData)(
                                                               (1U 
                                                                & (~ 
                                                                   ((IData)(vlSelfRef.io_csrCtrl_mem_trigger_triggerCanRaiseBpExp) 
                                                                    & (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_3) 
                                                                        & (0U 
                                                                           == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_3_action))) 
                                                                       | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_2) 
                                                                           & (0U 
                                                                              == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_action))) 
                                                                          | (((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_1) 
                                                                              & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_action))) 
                                                                             | ((IData)(vlSelfRef.AtomicsUnit__DOT__backendTriggerCanFireVec_0) 
                                                                                & (0U 
                                                                                == (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_action)))))))))))));
    if ((8U == (IData)(vlSelfRef.AtomicsUnit__DOT__state))) {
        vlSelfRef.io_out_bits_data = (((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[3U])) 
                                       << 0x00000020U) 
                                      | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[2U])));
        vlSelfRef.io_out_bits_uop_pdest = vlSelfRef.AtomicsUnit__DOT__pdest2;
    } else {
        vlSelfRef.io_out_bits_data = (((QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[1U])) 
                                       << 0x00000020U) 
                                      | (QData)((IData)(vlSelfRef.AtomicsUnit__DOT__resp_data[0U])));
        vlSelfRef.io_out_bits_uop_pdest = vlSelfRef.AtomicsUnit__DOT__pdest1;
    }
    vlSelfRef.AtomicsUnit__DOT___GEN_12 = ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_15) 
                                           | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_13) 
                                              | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_23) 
                                                 | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_21) 
                                                    | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_7) 
                                                       | ((IData)(vlSelfRef.AtomicsUnit__DOT__exceptionVec_5) 
                                                          | ((IData)(vlSelfRef.io_pmpResp_st) 
                                                             | (IData)(vlSelfRef.AtomicsUnit__DOT___exceptionVec_7_T_1))))))));
    vlSelfRef.AtomicsUnit__DOT___GEN_15 = (1U & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_14)) 
                                                 | (0x002cU 
                                                    == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))));
    vlSelfRef.io_in_ready = ((0U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                             | ((~ ((IData)(vlSelfRef.AtomicsUnit__DOT__pdest2Valid) 
                                    & (IData)(vlSelfRef.AtomicsUnit__DOT__pdest1Valid))) 
                                & (0x002cU == (IData)(vlSelfRef.AtomicsUnit__DOT__uop_fuOpType))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_0 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_3) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_0) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_0_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_1 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_4) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_1) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_1_store)))))));
    vlSelfRef.AtomicsUnit__DOT__backendTriggerHitVec_2 
        = ((~ (IData)(vlSelfRef.io_csrCtrl_mem_trigger_debugMode)) 
           & ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_select)) 
              & (((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isSc)) 
                  & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                     & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                        & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_load)))) 
                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__isLr)) 
                    & ((IData)(vlSelfRef.__VdfgRegularize_h6e95ff9d_0_5) 
                       & ((IData)(vlSelfRef.AtomicsUnit__DOT__tEnableVec_2) 
                          & (IData)(vlSelfRef.AtomicsUnit__DOT__tdata_2_store)))))));
    vlSelfRef.io_dcache_req_valid = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                     & ((6U == (IData)(vlSelfRef.io_dcache_req_bits_cmd))
                                         ? (~ (IData)(vlSelfRef.io_dcache_block_lr))
                                         : (IData)(vlSelfRef.AtomicsUnit__DOT__data_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN_10 = (1U & ((0U 
                                                  == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)) 
                                                 | ((~ (IData)(vlSelfRef.AtomicsUnit__DOT__addrAligned)) 
                                                    | (1U 
                                                       == (IData)(vlSelfRef.AtomicsUnit__DOT__triggerAction)))));
    vlSelfRef.AtomicsUnit__DOT___GEN_18 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12)
                                            ? 7U : 
                                           ((IData)(vlSelfRef.io_flush_sbuffer_empty)
                                             ? 4U : 3U));
    vlSelfRef.AtomicsUnit__DOT___GEN = ((IData)(vlSelfRef.io_in_valid) 
                                        & (IData)(vlSelfRef.io_in_ready));
    vlSelfRef.AtomicsUnit__DOT___GEN_9 = ((4U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & ((IData)(vlSelfRef.io_dcache_req_ready) 
                                             & (IData)(vlSelfRef.io_dcache_req_valid)));
    vlSelfRef.AtomicsUnit__DOT___GEN_0 = ((0U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN));
    vlSelfRef.AtomicsUnit__DOT___GEN_2 = (IData)(((0U 
                                                   == 
                                                   (0x01c0U 
                                                    & (IData)(vlSelfRef.io_in_bits_uop_fuOpType))) 
                                                  & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN)));
}

void VAtomicsUnitFixed___024root___nba_sequent__TOP__3(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_sequent__TOP__3\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.AtomicsUnit__DOT___GEN_5 = ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                          & ((IData)(vlSelfRef.io_dtlb_resp_valid) 
                                             & (IData)(vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req)));
    vlSelfRef.AtomicsUnit__DOT___GEN_6 = ((IData)(vlSelfRef.io_dcache_resp_valid) 
                                          & (5U == (IData)(vlSelfRef.AtomicsUnit__DOT__state)));
    vlSelfRef.AtomicsUnit__DOT___GEN_8 = ((~ (IData)(vlSelfRef.io_dtlb_resp_bits_miss)) 
                                          & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_5));
}

void VAtomicsUnitFixed___024root___nba_comb__TOP__1(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___nba_comb__TOP__1\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.AtomicsUnit__DOT___GEN_11 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10) 
                                           & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_8));
    vlSelfRef.AtomicsUnit__DOT___GEN_13 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                           | (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12));
}

void VAtomicsUnitFixed___024root___eval_nba(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_nba\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered[0U])) {
        VAtomicsUnitFixed___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        VAtomicsUnitFixed___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered[0U])) {
        VAtomicsUnitFixed___024root___nba_sequent__TOP__2(vlSelf);
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        VAtomicsUnitFixed___024root___nba_comb__TOP__0(vlSelf);
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        vlSelfRef.AtomicsUnit__DOT___GEN_5 = ((IData)(vlSelfRef.io_dtlb_req_valid) 
                                              & ((IData)(vlSelfRef.io_dtlb_resp_valid) 
                                                 & (IData)(vlSelfRef.AtomicsUnit__DOT__have_sent_first_tlb_req)));
        vlSelfRef.AtomicsUnit__DOT___GEN_6 = ((IData)(vlSelfRef.io_dcache_resp_valid) 
                                              & (5U 
                                                 == (IData)(vlSelfRef.AtomicsUnit__DOT__state)));
        vlSelfRef.AtomicsUnit__DOT___GEN_8 = ((~ (IData)(vlSelfRef.io_dtlb_resp_bits_miss)) 
                                              & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_5));
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        vlSelfRef.AtomicsUnit__DOT___GEN_11 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_10) 
                                               & (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_8));
        vlSelfRef.AtomicsUnit__DOT___GEN_13 = ((IData)(vlSelfRef.AtomicsUnit__DOT___GEN_11) 
                                               | (IData)(vlSelfRef.AtomicsUnit__DOT___GEN_12));
    }
}

void VAtomicsUnitFixed___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VAtomicsUnitFixed___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool VAtomicsUnitFixed___024root___eval_phase__act(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_phase__act\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VAtomicsUnitFixed___024root___eval_triggers_vec__act(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        VAtomicsUnitFixed___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    VAtomicsUnitFixed___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    return (0U);
}

void VAtomicsUnitFixed___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool VAtomicsUnitFixed___024root___eval_phase__nba(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_phase__nba\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = VAtomicsUnitFixed___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        VAtomicsUnitFixed___024root___eval_nba(vlSelf);
        VAtomicsUnitFixed___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void VAtomicsUnitFixed___024root___eval(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VicoIterCount = 0U;
    vlSelfRef.__VicoFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            VAtomicsUnitFixed___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/home/lhf/project/xiangshan/xs-env/XiangShan/atomics_stale_hwerr_repro/AtomicsUnit_fixed.sv", 58, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = VAtomicsUnitFixed___024root___eval_phase__ico(vlSelf);
        vlSelfRef.__VicoFirstIteration = 0U;
    } while (vlSelfRef.__VicoPhaseResult);
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            VAtomicsUnitFixed___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/home/lhf/project/xiangshan/xs-env/XiangShan/atomics_stale_hwerr_repro/AtomicsUnit_fixed.sv", 58, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 10000 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                VAtomicsUnitFixed___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                VL_FATAL_MT("/home/lhf/project/xiangshan/xs-env/XiangShan/atomics_stale_hwerr_repro/AtomicsUnit_fixed.sv", 58, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 10000 tries");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactPhaseResult = VAtomicsUnitFixed___024root___eval_phase__act(vlSelf);
        } while (vlSelfRef.__VactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = VAtomicsUnitFixed___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

#ifdef VL_DEBUG
void VAtomicsUnitFixed___024root___eval_debug_assertions(VAtomicsUnitFixed___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VAtomicsUnitFixed___024root___eval_debug_assertions\n"); );
    VAtomicsUnitFixed__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.clock & 0xfeU)))) {
        Verilated::overWidthError("clock");
    }
    if (VL_UNLIKELY(((vlSelfRef.reset & 0xfeU)))) {
        Verilated::overWidthError("reset");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_hartId & 0xc0U)))) {
        Verilated::overWidthError("io_hartId");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_valid & 0xfeU)))) {
        Verilated::overWidthError("io_in_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_bits_uop_fuOpType 
                      & 0xfe00U)))) {
        Verilated::overWidthError("io_in_bits_uop_fuOpType");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_bits_uop_rfWen 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_in_bits_uop_rfWen");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_bits_uop_robIdx_flag 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_in_bits_uop_robIdx_flag");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_bits_uop_sqIdx_flag 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_in_bits_uop_sqIdx_flag");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_in_bits_uop_sqIdx_value 
                      & 0xc0U)))) {
        Verilated::overWidthError("io_in_bits_uop_sqIdx_value");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_storeDataIn_0_valid 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_storeDataIn_0_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_storeDataIn_0_bits_uop_fuOpType 
                      & 0xfe00U)))) {
        Verilated::overWidthError("io_storeDataIn_0_bits_uop_fuOpType");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_storeDataIn_1_valid 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_storeDataIn_1_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_storeDataIn_1_bits_uop_fuOpType 
                      & 0xfe00U)))) {
        Verilated::overWidthError("io_storeDataIn_1_bits_uop_fuOpType");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_req_ready 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_req_ready");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_valid 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_resp_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_bits_miss 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_resp_bits_miss");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_bits_replay 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_resp_bits_replay");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_bits_tl_error_tl_denied 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_resp_bits_tl_error_tl_denied");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_bits_tl_error_tl_corrupt 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_resp_bits_tl_error_tl_corrupt");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_resp_bits_id 
                      & 0xc0U)))) {
        Verilated::overWidthError("io_dcache_resp_bits_id");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dcache_block_lr 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dcache_block_lr");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_valid 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_paddr_0 
                      & 0ULL)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_paddr_0");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_pbmt_0 
                      & 0xfcU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_pbmt_0");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_miss 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_miss");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_isForVSnonLeafPTE 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_isForVSnonLeafPTE");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_gpf_ld 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_gpf_ld");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_gpf_st 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_gpf_st");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_pf_ld 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_pf_ld");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_pf_st 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_pf_st");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_af_ld 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_af_ld");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_dtlb_resp_bits_excp_0_af_st 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_dtlb_resp_bits_excp_0_af_st");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_pmpResp_ld & 0xfeU)))) {
        Verilated::overWidthError("io_pmpResp_ld");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_pmpResp_st & 0xfeU)))) {
        Verilated::overWidthError("io_pmpResp_st");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_pmpResp_mmio & 0xfeU)))) {
        Verilated::overWidthError("io_pmpResp_mmio");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_flush_sbuffer_empty 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_flush_sbuffer_empty");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_redirect_valid & 0xfeU)))) {
        Verilated::overWidthError("io_redirect_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_cache_error_enable 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_cache_error_enable");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_valid 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_valid");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_addr 
                      & 0xfcU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_addr");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType 
                      & 0xfcU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action 
                      & 0xf0U)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_0 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tEnableVec_0");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_1 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tEnableVec_1");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_2 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tEnableVec_2");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_tEnableVec_3 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_tEnableVec_3");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_debugMode 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_debugMode");
    }
    if (VL_UNLIKELY(((vlSelfRef.io_csrCtrl_mem_trigger_triggerCanRaiseBpExp 
                      & 0xfeU)))) {
        Verilated::overWidthError("io_csrCtrl_mem_trigger_triggerCanRaiseBpExp");
    }
}
#endif  // VL_DEBUG
