// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VAtomicsUnitFixed.h for the primary calling header

#include "VAtomicsUnitFixed__pch.h"

void VAtomicsUnitFixed___024root___ctor_var_reset(VAtomicsUnitFixed___024root* vlSelf);

VAtomicsUnitFixed___024root::VAtomicsUnitFixed___024root(VAtomicsUnitFixed__Syms* symsp, const char* namep)
 {
    vlSymsp = symsp;
    vlNamep = strdup(namep);
    // Reset structure values
    VAtomicsUnitFixed___024root___ctor_var_reset(this);
}

void VAtomicsUnitFixed___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

VAtomicsUnitFixed___024root::~VAtomicsUnitFixed___024root() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}
