// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "VAtomicsUnitFixed__pch.h"

//============================================================
// Constructors

VAtomicsUnitFixed::VAtomicsUnitFixed(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new VAtomicsUnitFixed__Syms(contextp(), _vcname__, this)}
    , clock{vlSymsp->TOP.clock}
    , reset{vlSymsp->TOP.reset}
    , io_hartId{vlSymsp->TOP.io_hartId}
    , io_in_ready{vlSymsp->TOP.io_in_ready}
    , io_in_valid{vlSymsp->TOP.io_in_valid}
    , io_in_bits_uop_rfWen{vlSymsp->TOP.io_in_bits_uop_rfWen}
    , io_in_bits_uop_pdest{vlSymsp->TOP.io_in_bits_uop_pdest}
    , io_in_bits_uop_robIdx_flag{vlSymsp->TOP.io_in_bits_uop_robIdx_flag}
    , io_in_bits_uop_robIdx_value{vlSymsp->TOP.io_in_bits_uop_robIdx_value}
    , io_in_bits_uop_sqIdx_flag{vlSymsp->TOP.io_in_bits_uop_sqIdx_flag}
    , io_in_bits_uop_sqIdx_value{vlSymsp->TOP.io_in_bits_uop_sqIdx_value}
    , io_storeDataIn_0_valid{vlSymsp->TOP.io_storeDataIn_0_valid}
    , io_storeDataIn_1_valid{vlSymsp->TOP.io_storeDataIn_1_valid}
    , io_out_valid{vlSymsp->TOP.io_out_valid}
    , io_out_bits_uop_exceptionVec_3{vlSymsp->TOP.io_out_bits_uop_exceptionVec_3}
    , io_out_bits_uop_exceptionVec_4{vlSymsp->TOP.io_out_bits_uop_exceptionVec_4}
    , io_out_bits_uop_exceptionVec_5{vlSymsp->TOP.io_out_bits_uop_exceptionVec_5}
    , io_out_bits_uop_exceptionVec_6{vlSymsp->TOP.io_out_bits_uop_exceptionVec_6}
    , io_out_bits_uop_exceptionVec_7{vlSymsp->TOP.io_out_bits_uop_exceptionVec_7}
    , io_out_bits_uop_exceptionVec_13{vlSymsp->TOP.io_out_bits_uop_exceptionVec_13}
    , io_out_bits_uop_exceptionVec_15{vlSymsp->TOP.io_out_bits_uop_exceptionVec_15}
    , io_out_bits_uop_exceptionVec_19{vlSymsp->TOP.io_out_bits_uop_exceptionVec_19}
    , io_out_bits_uop_exceptionVec_21{vlSymsp->TOP.io_out_bits_uop_exceptionVec_21}
    , io_out_bits_uop_exceptionVec_23{vlSymsp->TOP.io_out_bits_uop_exceptionVec_23}
    , io_out_bits_uop_trigger{vlSymsp->TOP.io_out_bits_uop_trigger}
    , io_out_bits_uop_rfWen{vlSymsp->TOP.io_out_bits_uop_rfWen}
    , io_out_bits_uop_pdest{vlSymsp->TOP.io_out_bits_uop_pdest}
    , io_out_bits_uop_robIdx_flag{vlSymsp->TOP.io_out_bits_uop_robIdx_flag}
    , io_out_bits_uop_robIdx_value{vlSymsp->TOP.io_out_bits_uop_robIdx_value}
    , io_out_bits_debug_isMMIO{vlSymsp->TOP.io_out_bits_debug_isMMIO}
    , io_dcache_req_ready{vlSymsp->TOP.io_dcache_req_ready}
    , io_dcache_req_valid{vlSymsp->TOP.io_dcache_req_valid}
    , io_dcache_req_bits_cmd{vlSymsp->TOP.io_dcache_req_bits_cmd}
    , io_dcache_req_bits_word_idx{vlSymsp->TOP.io_dcache_req_bits_word_idx}
    , io_dcache_resp_valid{vlSymsp->TOP.io_dcache_resp_valid}
    , io_dcache_resp_bits_miss{vlSymsp->TOP.io_dcache_resp_bits_miss}
    , io_dcache_resp_bits_replay{vlSymsp->TOP.io_dcache_resp_bits_replay}
    , io_dcache_resp_bits_tl_error_tl_denied{vlSymsp->TOP.io_dcache_resp_bits_tl_error_tl_denied}
    , io_dcache_resp_bits_tl_error_tl_corrupt{vlSymsp->TOP.io_dcache_resp_bits_tl_error_tl_corrupt}
    , io_dcache_resp_bits_id{vlSymsp->TOP.io_dcache_resp_bits_id}
    , io_dcache_block_lr{vlSymsp->TOP.io_dcache_block_lr}
    , io_dtlb_req_valid{vlSymsp->TOP.io_dtlb_req_valid}
    , io_dtlb_req_bits_cmd{vlSymsp->TOP.io_dtlb_req_bits_cmd}
    , io_dtlb_req_bits_debug_robIdx_flag{vlSymsp->TOP.io_dtlb_req_bits_debug_robIdx_flag}
    , io_dtlb_req_bits_debug_robIdx_value{vlSymsp->TOP.io_dtlb_req_bits_debug_robIdx_value}
    , io_dtlb_resp_valid{vlSymsp->TOP.io_dtlb_resp_valid}
    , io_dtlb_resp_bits_pbmt_0{vlSymsp->TOP.io_dtlb_resp_bits_pbmt_0}
    , io_dtlb_resp_bits_miss{vlSymsp->TOP.io_dtlb_resp_bits_miss}
    , io_dtlb_resp_bits_isForVSnonLeafPTE{vlSymsp->TOP.io_dtlb_resp_bits_isForVSnonLeafPTE}
    , io_dtlb_resp_bits_excp_0_gpf_ld{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_gpf_ld}
    , io_dtlb_resp_bits_excp_0_gpf_st{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_gpf_st}
    , io_dtlb_resp_bits_excp_0_pf_ld{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_pf_ld}
    , io_dtlb_resp_bits_excp_0_pf_st{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_pf_st}
    , io_dtlb_resp_bits_excp_0_af_ld{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_af_ld}
    , io_dtlb_resp_bits_excp_0_af_st{vlSymsp->TOP.io_dtlb_resp_bits_excp_0_af_st}
    , io_pmpResp_ld{vlSymsp->TOP.io_pmpResp_ld}
    , io_pmpResp_st{vlSymsp->TOP.io_pmpResp_st}
    , io_pmpResp_mmio{vlSymsp->TOP.io_pmpResp_mmio}
    , io_flush_sbuffer_valid{vlSymsp->TOP.io_flush_sbuffer_valid}
    , io_flush_sbuffer_empty{vlSymsp->TOP.io_flush_sbuffer_empty}
    , io_feedbackSlow_valid{vlSymsp->TOP.io_feedbackSlow_valid}
    , io_feedbackSlow_bits_sqIdx_flag{vlSymsp->TOP.io_feedbackSlow_bits_sqIdx_flag}
    , io_feedbackSlow_bits_sqIdx_value{vlSymsp->TOP.io_feedbackSlow_bits_sqIdx_value}
    , io_redirect_valid{vlSymsp->TOP.io_redirect_valid}
    , io_exceptionInfo_valid{vlSymsp->TOP.io_exceptionInfo_valid}
    , io_exceptionInfo_bits_isForVSnonLeafPTE{vlSymsp->TOP.io_exceptionInfo_bits_isForVSnonLeafPTE}
    , io_csrCtrl_cache_error_enable{vlSymsp->TOP.io_csrCtrl_cache_error_enable}
    , io_csrCtrl_mem_trigger_tUpdate_valid{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_valid}
    , io_csrCtrl_mem_trigger_tUpdate_bits_addr{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_addr}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_matchType}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_select}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_action}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_chain}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_store}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_load}
    , io_csrCtrl_mem_trigger_tEnableVec_0{vlSymsp->TOP.io_csrCtrl_mem_trigger_tEnableVec_0}
    , io_csrCtrl_mem_trigger_tEnableVec_1{vlSymsp->TOP.io_csrCtrl_mem_trigger_tEnableVec_1}
    , io_csrCtrl_mem_trigger_tEnableVec_2{vlSymsp->TOP.io_csrCtrl_mem_trigger_tEnableVec_2}
    , io_csrCtrl_mem_trigger_tEnableVec_3{vlSymsp->TOP.io_csrCtrl_mem_trigger_tEnableVec_3}
    , io_csrCtrl_mem_trigger_debugMode{vlSymsp->TOP.io_csrCtrl_mem_trigger_debugMode}
    , io_csrCtrl_mem_trigger_triggerCanRaiseBpExp{vlSymsp->TOP.io_csrCtrl_mem_trigger_triggerCanRaiseBpExp}
    , io_in_bits_uop_fuOpType{vlSymsp->TOP.io_in_bits_uop_fuOpType}
    , io_storeDataIn_0_bits_uop_fuOpType{vlSymsp->TOP.io_storeDataIn_0_bits_uop_fuOpType}
    , io_storeDataIn_1_bits_uop_fuOpType{vlSymsp->TOP.io_storeDataIn_1_bits_uop_fuOpType}
    , io_dcache_req_bits_amo_mask{vlSymsp->TOP.io_dcache_req_bits_amo_mask}
    , io_dcache_req_bits_amo_data{vlSymsp->TOP.io_dcache_req_bits_amo_data}
    , io_dcache_req_bits_amo_cmp{vlSymsp->TOP.io_dcache_req_bits_amo_cmp}
    , io_dcache_resp_bits_data{vlSymsp->TOP.io_dcache_resp_bits_data}
    , io_in_bits_src_0{vlSymsp->TOP.io_in_bits_src_0}
    , io_storeDataIn_0_bits_data{vlSymsp->TOP.io_storeDataIn_0_bits_data}
    , io_storeDataIn_1_bits_data{vlSymsp->TOP.io_storeDataIn_1_bits_data}
    , io_out_bits_data{vlSymsp->TOP.io_out_bits_data}
    , io_dcache_req_bits_vaddr{vlSymsp->TOP.io_dcache_req_bits_vaddr}
    , io_dcache_req_bits_addr{vlSymsp->TOP.io_dcache_req_bits_addr}
    , io_dtlb_req_bits_vaddr{vlSymsp->TOP.io_dtlb_req_bits_vaddr}
    , io_dtlb_req_bits_fullva{vlSymsp->TOP.io_dtlb_req_bits_fullva}
    , io_dtlb_resp_bits_paddr_0{vlSymsp->TOP.io_dtlb_resp_bits_paddr_0}
    , io_dtlb_resp_bits_gpaddr_0{vlSymsp->TOP.io_dtlb_resp_bits_gpaddr_0}
    , io_dtlb_resp_bits_fullva{vlSymsp->TOP.io_dtlb_resp_bits_fullva}
    , io_exceptionInfo_bits_vaddr{vlSymsp->TOP.io_exceptionInfo_bits_vaddr}
    , io_exceptionInfo_bits_gpaddr{vlSymsp->TOP.io_exceptionInfo_bits_gpaddr}
    , io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2{vlSymsp->TOP.io_csrCtrl_mem_trigger_tUpdate_bits_tdata_tdata2}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

VAtomicsUnitFixed::VAtomicsUnitFixed(const char* _vcname__)
    : VAtomicsUnitFixed(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

VAtomicsUnitFixed::~VAtomicsUnitFixed() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void VAtomicsUnitFixed___024root___eval_debug_assertions(VAtomicsUnitFixed___024root* vlSelf);
#endif  // VL_DEBUG
void VAtomicsUnitFixed___024root___eval_static(VAtomicsUnitFixed___024root* vlSelf);
void VAtomicsUnitFixed___024root___eval_initial(VAtomicsUnitFixed___024root* vlSelf);
void VAtomicsUnitFixed___024root___eval_settle(VAtomicsUnitFixed___024root* vlSelf);
void VAtomicsUnitFixed___024root___eval(VAtomicsUnitFixed___024root* vlSelf);

void VAtomicsUnitFixed::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate VAtomicsUnitFixed::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    VAtomicsUnitFixed___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        VAtomicsUnitFixed___024root___eval_static(&(vlSymsp->TOP));
        VAtomicsUnitFixed___024root___eval_initial(&(vlSymsp->TOP));
        VAtomicsUnitFixed___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    VAtomicsUnitFixed___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool VAtomicsUnitFixed::eventsPending() { return false; }

uint64_t VAtomicsUnitFixed::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* VAtomicsUnitFixed::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void VAtomicsUnitFixed___024root___eval_final(VAtomicsUnitFixed___024root* vlSelf);

VL_ATTR_COLD void VAtomicsUnitFixed::final() {
    contextp()->executingFinal(true);
    VAtomicsUnitFixed___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* VAtomicsUnitFixed::hierName() const { return vlSymsp->name(); }
const char* VAtomicsUnitFixed::modelName() const { return "VAtomicsUnitFixed"; }
unsigned VAtomicsUnitFixed::threads() const { return 1; }
void VAtomicsUnitFixed::prepareClone() const { contextp()->prepareClone(); }
void VAtomicsUnitFixed::atClone() const {
    contextp()->threadPoolpOnClone();
}
