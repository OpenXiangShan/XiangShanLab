// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VATOMICSUNITFIXED__SYMS_H_
#define VERILATED_VATOMICSUNITFIXED__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "VAtomicsUnitFixed.h"

// INCLUDE MODULE CLASSES
#include "VAtomicsUnitFixed___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) VAtomicsUnitFixed__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    VAtomicsUnitFixed* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    VAtomicsUnitFixed___024root    TOP;

    // CONSTRUCTORS
    VAtomicsUnitFixed__Syms(VerilatedContext* contextp, const char* namep, VAtomicsUnitFixed* modelp);
    ~VAtomicsUnitFixed__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
