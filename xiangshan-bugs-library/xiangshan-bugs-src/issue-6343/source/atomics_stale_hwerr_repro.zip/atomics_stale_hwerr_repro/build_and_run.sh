#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd -- "$HERE/.." && pwd)"
RTL="$ROOT/build/rtl/AtomicsUnit.sv"
cd "$HERE"
python3 make_fixed.py
rm -rf obj_orig obj_fixed
: > build.log
build_one() {
  local rtl="$1" mdir="$2" prefix="$3" cflags="$4"
  echo "=== BUILD $prefix ===" | tee -a build.log
  verilator --cc --exe --build -j 4 --top-module AtomicsUnit \
    --prefix "$prefix" --Mdir "$mdir" -DSYNTHESIS \
    -Wno-fatal -Wno-WIDTH -Wno-UNOPTFLAT -Wno-CASEINCOMPLETE -Wno-LATCH \
    -CFLAGS "$cflags" "$rtl" difftest_stub.sv tb_atomics.cpp 2>&1 | tee -a build.log
}
build_one "$RTL" obj_orig VAtomicsUnitOrig "-std=c++17"
build_one "$HERE/AtomicsUnit_fixed.sv" obj_fixed VAtomicsUnitFixed "-std=c++17 -DFIXED"
{
  echo "=== RUN original ==="
  ./obj_orig/VAtomicsUnitOrig
  echo "=== RUN fixed ==="
  ./obj_fixed/VAtomicsUnitFixed
} 2>&1 | tee run.log
