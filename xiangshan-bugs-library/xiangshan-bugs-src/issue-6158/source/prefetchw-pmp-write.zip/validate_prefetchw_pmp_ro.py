#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


LSU_PREFETCH_W = 0x0A
TLB_READ = 0
TLB_WRITE = 1
M_PFR = 2
M_PFW = 3


REQUIRED_TARGETS = {
    "ldin_valid": ("inner_LoadUnit_0", "io_ldin_valid"),
    "ldin_fuop": ("inner_LoadUnit_0", "io_ldin_bits_fuOpType"),
    "tlb_valid": ("inner_LoadUnit_0.s0", "io_tlbReq_valid"),
    "tlb_is_prefetch": ("inner_LoadUnit_0.s0", "io_tlbReq_bits_isPrefetch"),
    "s0_req_valid": ("inner_LoadUnit_0.s0", "io_dcacheReq_valid"),
    "s0_req_cmd": ("inner_LoadUnit_0.s0", "io_dcacheReq_bits_cmd"),
    "s0_req_vaddr": ("inner_LoadUnit_0.s0", "io_dcacheReq_bits_vaddr"),
    "top_req_valid": ("inner_LoadUnit_0", "io_dcache_req_valid"),
    "top_req_ready": ("inner_LoadUnit_0", "io_dcache_req_ready"),
    "top_req_cmd": ("inner_LoadUnit_0", "io_dcache_req_bits_cmd"),
    "top_req_vaddr": ("inner_LoadUnit_0", "io_dcache_req_bits_vaddr"),
}

OPTIONAL_TARGETS = {
    "tlb_cmd": ("inner_LoadUnit_0.s0", "io_tlbReq_bits_cmd"),
    "s2_pipein_valid": ("inner_LoadUnit_0.s2", "io_pipeIn_valid"),
    "s2_pipein_fuop": ("inner_LoadUnit_0.s2", "io_pipeIn_bits_uop_fuOpType"),
    "s2_pipein_vaddr": ("inner_LoadUnit_0.s2", "io_pipeIn_bits_vaddr"),
    "s2_pipeout_valid": ("inner_LoadUnit_0.s2", "io_pipeOut_valid"),
    "s2_pipeout_fuop": ("inner_LoadUnit_0.s2", "io_pipeOut_bits_uop_fuOpType"),
    "s2_pipeout_vaddr": ("inner_LoadUnit_0.s2", "io_pipeOut_bits_vaddr"),
    "s2_pmp_ld": ("inner_LoadUnit_0.s2", "io_pmp_ld"),
    "s2_pmp_mmio": ("inner_LoadUnit_0.s2", "io_pmp_mmio"),
    "s2_pmp_unaccessable": ("inner_LoadUnit_0.s2", "pmpUnaccessable"),
    "s2_dcache_kill": ("inner_LoadUnit_0.s2", "io_dcacheKill"),
    "top_s2_kill": ("inner_LoadUnit_0", "io_dcache_s2_kill"),
}


def clean_leaf(name):
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_int(bits):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, 2)


def header_signals(vcd):
    scope = []
    signals = []
    var_re = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")
    with vcd.open("r", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
            elif line.startswith("$upscope"):
                if scope:
                    scope.pop()
            else:
                match = var_re.match(line)
                if match:
                    code, leaf = match.groups()
                    leaf = clean_leaf(leaf)
                    full_scope = ".".join(scope)
                    signals.append((code, full_scope, leaf, ".".join(scope + [leaf])))
    return signals


def select_targets(vcd):
    selected = {}
    targets = {**REQUIRED_TARGETS, **OPTIONAL_TARGETS}
    for code, scope, leaf, full_name in header_signals(vcd):
        for key, (scope_suffix, target_leaf) in targets.items():
            if key not in selected and scope.endswith(scope_suffix) and leaf == target_leaf:
                selected[key] = {"code": code, "full_name": full_name}
    missing_required = sorted(set(REQUIRED_TARGETS) - set(selected))
    missing_optional = sorted(set(OPTIONAL_TARGETS) - set(selected))
    return selected, missing_required, missing_optional


def addr_matches(value, target_addr, line_size):
    if value is None:
        return False
    if target_addr is None:
        return True
    mask = ~(line_size - 1)
    return (value & mask) == (target_addr & mask)


def scan_events(vcd, selected, min_time, target_addr, line_size):
    code_to_keys = {}
    for key, meta in selected.items():
        code_to_keys.setdefault(meta["code"], []).append(key)

    values = {key: None for key in selected}
    issue_events = []
    accepted_events = []
    s2_pipein_events = []
    s2_pipeout_events = []
    now = None

    def value(key):
        return values.get(key)

    def snapshot(keys):
        return {key: value(key) for key in keys if key in selected}

    def sample():
        if now is None or now < min_time:
            return
        if (
            value("ldin_valid") == 1
            and value("ldin_fuop") == LSU_PREFETCH_W
            and value("s0_req_valid") == 1
            and addr_matches(value("s0_req_vaddr"), target_addr, line_size)
        ):
            issue_events.append(
                {
                    "time": now,
                    **snapshot(
                        [
                            "ldin_valid",
                            "ldin_fuop",
                            "tlb_valid",
                            "tlb_cmd",
                            "tlb_is_prefetch",
                            "s0_req_valid",
                            "s0_req_cmd",
                            "s0_req_vaddr",
                        ]
                    ),
                }
            )
        if (
            value("top_req_valid") == 1
            and value("top_req_ready") == 1
            and addr_matches(value("top_req_vaddr"), target_addr, line_size)
        ):
            accepted_events.append(
                {
                    "time": now,
                    **snapshot(
                        [
                            "top_req_valid",
                            "top_req_ready",
                            "top_req_cmd",
                            "top_req_vaddr",
                        ]
                    ),
                }
            )
        if (
            value("s2_pipein_valid") == 1
            and value("s2_pipein_fuop") == LSU_PREFETCH_W
            and addr_matches(value("s2_pipein_vaddr"), target_addr, line_size)
        ):
            s2_pipein_events.append(
                {
                    "time": now,
                    **snapshot(
                        [
                            "s2_pipein_valid",
                            "s2_pipein_fuop",
                            "s2_pipein_vaddr",
                            "s2_pmp_ld",
                            "s2_pmp_mmio",
                            "s2_pmp_unaccessable",
                            "s2_dcache_kill",
                            "top_s2_kill",
                        ]
                    ),
                }
            )
        if (
            value("s2_pipeout_valid") == 1
            and value("s2_pipeout_fuop") == LSU_PREFETCH_W
            and addr_matches(value("s2_pipeout_vaddr"), target_addr, line_size)
        ):
            s2_pipeout_events.append(
                {
                    "time": now,
                    **snapshot(
                        [
                            "s2_pipeout_valid",
                            "s2_pipeout_fuop",
                            "s2_pipeout_vaddr",
                            "s2_pmp_ld",
                            "s2_pmp_mmio",
                            "s2_pmp_unaccessable",
                            "s2_dcache_kill",
                            "top_s2_kill",
                        ]
                    ),
                }
            )

    with vcd.open("r", errors="replace") as handle:
        in_body = False
        for raw in handle:
            line = raw.strip()
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            if not line:
                continue
            if line.startswith("#"):
                sample()
                now = int(line[1:])
                continue
            if line[0] in "01xz":
                code = line[1:]
                if code in code_to_keys:
                    val = None if line[0] in "xz" else int(line[0])
                    for key in code_to_keys[code]:
                        values[key] = val
            elif line[0] in "bB":
                payload = line[1:].split()
                if len(payload) == 2:
                    bits, code = payload
                    if code in code_to_keys:
                        val = parse_int(bits)
                        for key in code_to_keys[code]:
                            values[key] = val
        sample()
    return issue_events, accepted_events, s2_pipein_events, s2_pipeout_events


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("--target-addr", type=lambda x: int(x, 0), default=None)
    parser.add_argument("--line-size", type=int, default=64)
    parser.add_argument("--min-time", type=int, default=0)
    parser.add_argument("--json-out", type=Path, required=True)
    args = parser.parse_args()

    if args.line_size <= 0 or args.line_size & (args.line_size - 1):
        raise SystemExit("--line-size must be a power of two")

    selected, missing_required, missing_optional = select_targets(args.vcd)
    if missing_required:
        result = {
            "predicate_result": "inconclusive",
            "reason": "missing required VCD signals",
            "missing_required_signals": missing_required,
            "missing_optional_signals": missing_optional,
            "selected_signals": {key: meta["full_name"] for key, meta in selected.items()},
        }
        args.json_out.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))
        raise SystemExit(2)

    issue_events, accepted_events, s2_pipein_events, s2_pipeout_events = scan_events(
        args.vcd, selected, args.min_time, args.target_addr, args.line_size
    )
    bad_issues = [
        event
        for event in issue_events
        if event["tlb_valid"] == 1
        and event.get("tlb_cmd") in (TLB_READ, None)
        and event["tlb_is_prefetch"] == 1
        and event["s0_req_cmd"] == M_PFR
    ]
    accepted_bad = [
        event
        for event in accepted_events
        if event["top_req_cmd"] == M_PFR
    ]
    s2_not_blocked = [
        event
        for event in s2_pipein_events
        if event.get("s2_pmp_ld") == 0
        and event.get("s2_pmp_unaccessable") == 0
        and event.get("s2_dcache_kill") == 0
    ]
    write_intent_events = [
        event
        for event in issue_events + accepted_events
        if event.get("tlb_cmd") == TLB_WRITE or event.get("s0_req_cmd") == M_PFW or event.get("top_req_cmd") == M_PFW
    ]

    reproduced = bool(bad_issues and accepted_bad and s2_not_blocked)
    result = {
        "predicate_result": "reproduced" if reproduced else "not_reproduced",
        "success_predicate": (
            "prefetch.w targeting a locked PMP read-only page is issued as DCache M_PFR "
            "and accepted by DCache instead of carrying write intent M_PFW"
        ),
        "tlb_cmd_note": (
            "tlb_cmd is optional because this build can constant-fold it out of VCD; "
            "NewLoadUnit.scala hardwires io.tlbReq.bits.cmd := TlbCmd.read."
        ),
        "target_addr": None if args.target_addr is None else hex(args.target_addr),
        "line_size": args.line_size,
        "issue_event_count": len(issue_events),
        "bad_issue_event_count": len(bad_issues),
        "accepted_event_count": len(accepted_events),
        "accepted_bad_event_count": len(accepted_bad),
        "s2_pipein_event_count": len(s2_pipein_events),
        "s2_pipeout_event_count": len(s2_pipeout_events),
        "s2_not_blocked_event_count": len(s2_not_blocked),
        "write_intent_event_count": len(write_intent_events),
        "first_bad_issue": bad_issues[0] if bad_issues else None,
        "first_accepted_bad": accepted_bad[0] if accepted_bad else None,
        "first_s2_not_blocked": s2_not_blocked[0] if s2_not_blocked else None,
        "first_s2_pipein": s2_pipein_events[0] if s2_pipein_events else None,
        "first_s2_pipeout": s2_pipeout_events[0] if s2_pipeout_events else None,
        "first_issue_events": issue_events[:8],
        "first_accepted_events": accepted_events[:8],
        "first_s2_pipein_events": s2_pipein_events[:8],
        "first_s2_pipeout_events": s2_pipeout_events[:8],
        "missing_optional_signals": missing_optional,
        "selected_signals": {key: meta["full_name"] for key, meta in selected.items()},
        "security_interpretation": (
            "The PMP page is locked read-only. A write-intent prefetch should be checked as a write "
            "and suppressed on this page; the observed read/M_PFR request can create a DCache side effect "
            "that the PMP W bit should have prevented."
        ),
    }
    args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if reproduced else 1)


if __name__ == "__main__":
    main()
