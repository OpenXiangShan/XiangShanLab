#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
RISCV_PREFIX=${RISCV_PREFIX:-/opt/riscv/bin/riscv64-unknown-elf}
if [[ -z "${XIANGSHAN_HOME:-}" ]]; then
  for candidate in \
    "$SCRIPT_DIR/../../../../XiangShan" \
    "$SCRIPT_DIR/../XiangShan" \
    "$PWD/XiangShan" \
    "$PWD"; do
    if [[ -x "$candidate/build/verilator-compile/emu" || -x "$candidate/build/emu" ]]; then
      XIANGSHAN_HOME=$(cd "$candidate" && pwd)
      break
    fi
  done
fi
XIANGSHAN_HOME=${XIANGSHAN_HOME:-/path/to/XiangShan}
if [[ -z "${EMU:-}" ]]; then
  if [[ -x "$XIANGSHAN_HOME/build/verilator-compile/emu" ]]; then
    EMU="$XIANGSHAN_HOME/build/verilator-compile/emu"
  else
    EMU="$XIANGSHAN_HOME/build/emu"
  fi
fi
CYCLES=${CYCLES:-3000}
WAVE_BEGIN=${WAVE_BEGIN:-900}
WAVE_END=${WAVE_END:-1900}

cd "$SCRIPT_DIR"

"${RISCV_PREFIX}-gcc" \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr_zicbop -mabi=lp64d \
  -T link.ld \
  -o prefetchw_pmp_ro.elf prefetchw_pmp_ro.S

"${RISCV_PREFIX}-objcopy" -O binary prefetchw_pmp_ro.elf prefetchw_pmp_ro.bin
"${RISCV_PREFIX}-objdump" -d prefetchw_pmp_ro.elf > prefetchw_pmp_ro.objdump
"${RISCV_PREFIX}-nm" prefetchw_pmp_ro.elf > prefetchw_pmp_ro.nm

TARGET_ADDR=$("${RISCV_PREFIX}-nm" prefetchw_pmp_ro.elf | awk '$3 == "target_page" { print "0x" $1 }')

"$EMU" \
  -i prefetchw_pmp_ro.bin \
  --no-diff \
  -C "$CYCLES" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  --dump-wave \
  --wave-path "prefetchw_pmp_ro_${WAVE_BEGIN}_${WAVE_END}.vcd" \
  > "prefetchw_pmp_ro_${WAVE_BEGIN}_${WAVE_END}.run.log" 2>&1

python3 validate_prefetchw_pmp_ro.py \
  "prefetchw_pmp_ro_${WAVE_BEGIN}_${WAVE_END}.vcd" \
  --target-addr "$TARGET_ADDR" \
  --min-time "$WAVE_BEGIN" \
  --json-out "prefetchw_pmp_ro_${WAVE_BEGIN}_${WAVE_END}.monitor.json" \
  > "prefetchw_pmp_ro_${WAVE_BEGIN}_${WAVE_END}.monitor.log"
