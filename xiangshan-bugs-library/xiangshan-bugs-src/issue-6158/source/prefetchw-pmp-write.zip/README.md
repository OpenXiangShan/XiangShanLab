# XiangShan `prefetch.w` PMP Write-Intent Bypass

This is a focused security-impact PoC for the run
`runs/xiangshan_hunt_range_3001_3505/3278`.

The program installs PMP entry 0 as a locked read-only 4 KiB NAPOT page and
then executes `prefetch.w 0(s0)` into that page. The intended behavior is that
`prefetch.w` carries write intent into TLB/PMP/PMA and DCache as `M_PFW`; on a
locked read-only PMP page it should be suppressed. The buggy behavior is that
NewLoadUnit sends the request as `TlbCmd.read` and `M_PFR`, so the request is
accepted as a read prefetch.

Run:

```sh
XIANGSHAN_HOME=/path/to/XiangShan bash run_poc.sh
```

The monitor succeeds when it observes the target `prefetch.w` issue with
`s0_req_cmd=2` (`M_PFR`), a top-level DCache `valid && ready` request with
`top_req_cmd=2` to the locked read-only page, and the same target request at S2
pipe-in with `pmp_ld=0`, `pmpUnaccessable=0`, and `dcacheKill=0`. `tlb_cmd` is
optional in the monitor because this build can constant-fold the hardwired
`io.tlbReq.bits.cmd := TlbCmd.read` signal out of the VCD.
