# F05: waveform corroboration of a zero scalar operand

**Status: corroborates the reported wrong result.** This is one supplementary seed-0 trace of freshly rebuilt, FST-enabled RTL at XiangShan `b9636416b81d266f3a3d4d1e46d4e66e6a574bcd`, using the unchanged packaged image and reference. The trace emulator is a different binary; exact hashes and invocation are recorded in [run.json](run.json). Its two vector register differences equal the original run's differences.

![Actual sampled waveform](waveform-evidence.png)

## Observed chain

Cycle numbers below are **falling-edge sample indices from the first falling edge in this FST**, not the DUT's printed `cycleCnt`. Sampling is post-evaluation. A valid/write-enable high at sample c describes the interface held before the following rising edge. Unqualified data while valid is low is not an instruction result.

| Sample | Actual observation |
|---|---|
| 6087 | ROB enqueue lane 3 is valid and `canAccept=1`: PC `0x8000050c`, instruction `0x5e034157` (`vmv.v.x v2,t1`), full ROB pointer `(flag=1,value=8)`, vector physical destination `0x30` (48). |
| 6087 | Producer `li t1,90` at PC `0x80000508`, instruction `0x05a00313`, is valid on lane 2 with ROB `(1,7)` and integer physical destination `0x1a` (26). |
| 6091 | Integer writeback port 3 has `wen=1,pdest=0x1a,data=0x5a`. The scalar producer therefore supplies nonzero data before the vector execution. |
| 6094 | Vector EXU input is valid for ROB `(1,8)`, `uopIdx=0`, `pdest=0x30`; integer operand select `gpRen_0=1`, but both the input operand and post-bypass operand 0 are 128-bit zero. |
| 6095 | VMove input/output valid are high, its raw vector result is zero, and EXU output valid has ROB `(1,8)` with `toVpRf.wen=1,pdest=0x30,data=0`. |
| 6096–6097 | Actual vector RF write port 0 presents `wen=1,addr=0x30,data=0` at 6096. Physical vector register 48 reads zero at 6097. |
| 6098–6099 | Difftest commit lane 2 reports the scalar producer at 6098 (`rfwen=1,wdest=6,wpdest=0x1a`). Commit lane 0 reports the target at 6099 (`vecwen=1,wdest=2,wpdest=0x30`). The architectural comparison subsequently reports both halves of v2 as zero instead of repeated `0x5a`. |

There is a real flush at sample 6093 with pointer `(flag=1,value=0xb)` and level 0. This is later than the target's pointer `(1,8)`; the target subsequently executes and commits. The evidence does **not** assume a flush-free window. Full flush samples are retained in `commit-samples.json`.

## Relationship to the report and source

The waveform directly strengthens the original input-path hypothesis: a nonzero scalar producer is written before the correlated vector operation, while the vector input and result are zero. It is consistent with `Backend.scala:469–470` and the missing integer read-port configuration at `Parameters.scala:488–522`; see the pinned [Backend source](https://github.com/OpenXiangShan/XiangShan/blob/b9636416b81d266f3a3d4d1e46d4e66e6a574bcd/src/main/scala/xiangshan/backend/Backend.scala#L469-L470) and [read-port configuration](https://github.com/OpenXiangShan/XiangShan/blob/b9636416b81d266f3a3d4d1e46d4e66e6a574bcd/src/main/scala/xiangshan/Parameters.scala#L488-L522). It does not prove that changing line 470 alone is a sufficient fix. No repaired RTL was tested.

The waveform covers the first `vmv.v.x` failing operation. The separate `vadd.vx` and `vmv.s.x` self-check results in the original report remain log-based supplementary evidence; this trace does not independently cover them.

## Reproducibility and signal identities

- The original raw FST is retained separately in the complete 20260926 evidence archive. This submission contains extracted samples and the figure; the original trace SHA-256 and replay command are in [run.json](run.json).
- `selection.json` and `samples.json`: exact plotted paths, widths, sample indices, FST timestamps and hexadecimal values. Each panel has its own stated zoom window; all panels share the same trace origin.
- `locate-`, `execute-`, `writeback-`, and `commit-selection.json` / `*-samples.json`: wider supporting samples including producer identity, write enables, complete ROB flags/values, commit fields and flush.
- The image abbreviates only long inactive random bus labels; companion JSON preserves every full value.
- Extraction uses the user-provided wavekit `FstReader`, with `TOP.clock` and `sample_on_posedge=False`. Native timestamps are not interpreted as a physical clock frequency.

Key hierarchy prefixes are `TOP.SimTop.cpu.l_soc.core_with_l2.core.backend.inner_ctrlBlock.rob`, `...backend.inner_intRegion`, and `...backend.inner_vecRegion.issuePipes.exu`. The actual vector RF endpoint is `...backend.inner_vecRegion.vfRegFile`; no generic integer/FP commit-data field is used as a vector result.
