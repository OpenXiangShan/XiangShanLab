# vmv.v.x broadcasts zero despite a nonzero scalar operand

Tested on Kunminghu-v3 `b9636416b8`, `MinimalConfig`, single core, VLEN=128. This issue was not reproduced in the latest Kunminghu-v2 version.

With SEW=8, LMUL=1 and VL=16, `vmv.v.x v2,t1` at PC `0x8000050c` produces an all-zero vector after `t1` is explicitly loaded with `0x5a`:

```asm
vsetivli x0, 16, e8, m1, ta, ma
li       t1, 0x5a
vmv.v.x  v2, t1
```

Both 64-bit halves of `v2` should be `0x5a5a5a5a5a5a5a5a`; both are `0x0000000000000000`. All 16 bytes are active, so tail policy cannot explain this result.

## Evidence

All three seeds reproduce the mismatch: [seed 0 log](logs/replay-20260926/seed0.log) / [metadata](logs/replay-20260926/seed0.json), [seed 1 log](logs/replay-20260926/seed1.log) / [metadata](logs/replay-20260926/seed1.json), [seed 2 log](logs/replay-20260926/seed2.log) / [metadata](logs/replay-20260926/seed2.json).

![Difftest log excerpts](screenshots/runtime-difference.png)

For the matched instruction, the waveform shows the scalar producer writing `0x5a`, but the selected vector operand and RF write are zero; the target commits.

![Scalar producer, vector operand and writeback](waveform/waveform-evidence.png)

Traced replay at the same DUT revision: [full log](waveform/run.log), [metadata](waveform/run.json), [waveform analysis](waveform/analysis.md).

A seed-0 no-reference self-check also stores incorrect results and completes ([log](logs/no-diff-comparison-20260926/seed0.log), [metadata](logs/no-diff-comparison-20260926/seed0.json), [screenshot](screenshots/no-diff-difference.png)). `GOOD TRAP` means completion, not correctness. Its later `vadd.vx`/`vmv.s.x` cases are outside the three-seed coverage.

## Specification and replay

RISC-V Unprivileged ISA **20240411**, §31.11.16, specifies the scalar broadcast: [official PDF, page 344](https://docs.riscv.org/reference/isa/v20240411/_attachments/riscv-unprivileged.pdf#page=344).

![Specification excerpt](screenshots/spec-page-344.png)

[C test](poc/main.c) · [assembly](poc/probe.S) · [BIN](poc/build/f05-vx-scalar-read-as-zero-riscv64-xs-light-kunminghu-v3.bin) · [ELF](poc/build/f05-vx-scalar-read-as-zero-riscv64-xs-light-kunminghu-v3.elf) · [disassembly](poc/build/f05-vx-scalar-read-as-zero-riscv64-xs-light-kunminghu-v3.txt) · [replay script](replay.sh)

Run `bash replay.sh 0` (then `1` and `2`), with `XS_EMU` and `XS_REF` pointing to the pinned models.

Related: [#6543](https://github.com/OpenXiangShan/XiangShan/issues/6543) reports `vdiv.vx` failing to retire with an unwritten zero divisor; this case produces a nonzero scalar and commits a wrong result. Shared operand-read causes remain possible.
