/* F05: v2 is loaded from a1; t1 is set to 0x5a immediately before
 * vmv.v.x. The resulting v2 is stored through a0. */
#include "probe-common.S"

  .align 6
  .globl f05_vmv_v_x
  .type  f05_vmv_v_x, @function
f05_vmv_v_x:
  vl1re64.v v2, (a1)
  vsetivli x0, 16, e8, m1, ta, ma
  li t1, 0x5A
  vmv.v.x v2, t1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f05_vmv_v_x, .-f05_vmv_v_x

  .align 6
  .globl f05_vadd_vx
  .type  f05_vadd_vx, @function
f05_vadd_vx:
  vl1re64.v v2, (a1)
  vl1re64.v v3, (a1)
  vsetivli x0, 16, e8, m1, ta, ma
  li t1, 0x5A
  vadd.vx v2, v3, t1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f05_vadd_vx, .-f05_vadd_vx

  .align 6
  .globl f05_vmv_s_x
  .type  f05_vmv_s_x, @function
f05_vmv_s_x:
  vl1re64.v v2, (a1)
  vsetivli x0, 2, e64, m1, tu, mu
  li t1, 0x5A
  vmv.s.x v2, t1
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  ret
  .size f05_vmv_s_x, .-f05_vmv_s_x
