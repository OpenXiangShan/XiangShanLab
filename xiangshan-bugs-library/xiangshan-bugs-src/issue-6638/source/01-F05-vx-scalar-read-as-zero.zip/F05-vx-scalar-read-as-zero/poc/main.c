/* F05 -- vmv.v.x broadcasts zero despite a nonzero GP scalar source.
 * The traced run shows a producer write of 0x5a, followed by a zero
 * selected vector operand and RF write. The precise RTL root cause
 * has not been confirmed by a fix and retest.
 */
#include "vt-common.h"

static uint8_t data[16] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f05_vmv_v_x(void *o, const void *d);
extern void f05_vadd_vx(void *o, const void *d);
extern void f05_vmv_s_x(void *o, const void *d);

static int bugs;
static void report(const char *name, uint64_t e0, uint64_t e1) {
  uint64_t r0 = out_q(out, 0), r1 = out_q(out, 1);
  int ok = (r0 == e0 && r1 == e1);
  if (!ok) bugs++;
  printf("[F05] %-9s v2=%016lx_%016lx expect=%016lx_%016lx %s\n", name,
         (unsigned long)r1, (unsigned long)r0, (unsigned long)e1, (unsigned long)e0,
         ok ? "ok" : "BUG: scalar read as 0");
}

int main(void) {
  vt_fill_arena(data, sizeof(data)); /* 0x10..0x1F */
  if (vt_init("F05") != 0) return 1;
  printf("[F05] start cyc=%lu\n", (unsigned long)cyc());

  memset(out, 0, 16); f05_vmv_v_x(out, data); VT_FENCE();
  report("vmv.v.x", 0x5A5A5A5A5A5A5A5AUL, 0x5A5A5A5A5A5A5A5AUL);

  memset(out, 0, 16); f05_vadd_vx(out, data); VT_FENCE();
  report("vadd.vx", bytes_q(data) + 0x5A5A5A5A5A5A5A5AUL /* no carries: 0x10+0x5A < 0x100 */, bytes_q(data + 8) + 0x5A5A5A5A5A5A5A5AUL);

  memset(out, 0, 16); f05_vmv_s_x(out, data); VT_FENCE();
  report("vmv.s.x", 0x5AUL, bytes_q(data + 8));

  printf("[F05] done bugs=%d verdict=%s\n", bugs, bugs ? "GP_SCALAR_READ_AS_ZERO" : "clean");
  return 0;
}
