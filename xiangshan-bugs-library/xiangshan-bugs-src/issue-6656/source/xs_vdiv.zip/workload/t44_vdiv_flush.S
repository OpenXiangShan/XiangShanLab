# EXPECT: 0x14,0x10,0x0b,0x08,0x08,0x06,0x06,0x05,0x05,0x04,0x04,0x04,0x04,0x03,0x03,0x03
# NCHECK: 16
  .include "common_xs.S"
  .text
  .globl test
test:
  vsetivli x0, 16, e8, m1, ta, ma
  vle8.v v1, (a1)          # dividends 100..
  vle8.v v2, (a2)          # divisors 5..20
  la t0, flag
  ld t0, 0(t0)             # 0: the forward branch below is taken, first prediction is not-taken
  beqz t0, 1f
  vdivu.vv v4, v1, v2      # speculative shadow: canceled by the redirect
  vdivu.vv v5, v2, v1
1:
  vdivu.vv v3, v1, v2      # if the VFEX1 writeback port stays reserved, this never issues
  vse8.v v3, (a3)
  ret
  .data
  .align 4
old_vd: .byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
src1:   .byte 100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100
src2:   .byte 5,6,9,12,12,16,16,20,20,25,25,25,25,33,33,33
flag:   .dword 0
result: .space 16
  .data
  .align 4
expected: .byte 0x14,0x10,0x0b,0x08,0x08,0x06,0x06,0x05,0x05,0x04,0x04,0x04,0x04,0x03,0x03,0x03
ncheck: .byte 16
