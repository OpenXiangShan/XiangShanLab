#include <klib.h>
#include <stdint.h>

/*
 * CSR-011: RISC-V TOR lock of pmpaddr_i / pmaaddr_i is via the *next*
 * entry (i+1) being locked TOR. TLPMA gen_mmpma_mapping uses cfg(i-1).
 * Hardware index 0/1 are reversed OFF pads, so programming cfg1=TOR+L
 * must freeze addr0 without stealing DRAM.
 */

#define MMPMA_BASE 0x38021000UL
#define MMPMA_CFG0 (MMPMA_BASE + 0x0000)
#define MMPMA_ADDR0 (MMPMA_BASE + 0x0400)
#define PMP_L      (1UL << 7)
#define PMP_A_TOR  (1UL << 3)
#define PMP_R      (1UL << 0)

int main(void) {
  volatile uint64_t *cfg0 = (volatile uint64_t *)MMPMA_CFG0;
  volatile uint64_t *addr0 = (volatile uint64_t *)MMPMA_ADDR0;
  uint64_t old_cfg, old_addr, new_addr, rd_addr;

  printf("csr011-mmpma-tor-neighbor start\n");

  old_cfg = *cfg0;
  old_addr = *addr0;
  printf("cfg0=0x%lx addr0=0x%lx\n", old_cfg, old_addr);

  /* Entry 1 (bits 15:8): locked TOR+R. Entry 0 A stays OFF. */
  *cfg0 = (old_cfg & ~0xFF00UL) | (((PMP_L | PMP_A_TOR | PMP_R) << 8));
  new_addr = old_addr ^ 0x12345UL;
  *addr0 = new_addr;
  rd_addr = *addr0;

  printf("cfg0_after=0x%lx old=0x%lx wrote=0x%lx read=0x%lx\n",
         *cfg0, old_addr, new_addr, rd_addr);

  /* Restore before judging, so a later panic is not leftover PMA. */
  *addr0 = old_addr;
  *cfg0 = old_cfg;

  /* Spec: cfg1 locked TOR freezes addr0. Grain masking of a successful
     write still counts as a change. */
  if (rd_addr != old_addr) {
    printf("FAIL csr011 TOR next-lock did not freeze MMPMA addr0\n");
    return 1;
  }

  printf("csr011-mmpma-tor-neighbor pass\n");
  return 0;
}
