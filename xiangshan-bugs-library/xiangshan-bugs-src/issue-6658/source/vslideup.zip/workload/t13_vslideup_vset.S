# EXPECT: 0x01,0x02,0x03,0x04,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c
# NCHECK: 16
  .include "common_xs.S"
  .text
  .globl test
test:
  vsetivli x0, 16, e8, m1, ta, ma
  vle8.v v1, (a1)
  vle8.v v2, (a2)
  vle8.v v3, (a0)
  vsetivli x0, 16, e8, m1, ta, ma   # re-set vl right before vmacc
  vslideup.vi v3, v2, 4
  vse8.v v3, (a3)
  ret
  .data
  .align 4
old_vd: .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
src1:   .byte 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2
src2:   .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
result: .space 16
  .data
  .align 4
expected: .byte 0x01,0x02,0x03,0x04,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c
ncheck: .byte 16
