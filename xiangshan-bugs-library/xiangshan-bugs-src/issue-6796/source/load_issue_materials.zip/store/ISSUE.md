### Before start

- [ ] I have read the [RISC-V ISA Manual](https://github.com/riscv/riscv-isa-manual) and [XiangShan Documents](https://docs.xiangshan.cc/zh-cn/latest), and I believe this is a XiangShan RTL issue.
- [ ] I have searched previous issues and PRs and did not find anything relevant.
- [ ] I have reproduced the issue using the latest commit on the default branch.
- [ ] If this report was generated with AI assistance (otherwise leave unchecked), I have verified the correctness of its content.

These are submitter attestations and remain unchecked for the author's final review. This report reproduces the issue on the recorded `kunminghu-v2` commit; it does not claim reproduction on the latest commit of the current default branch, `kunminghu-v3`.

### Branch

kunminghu-v2

### Describe the bug

Reproducer and evidence attachment: `store_issue_materials.zip`. File paths below are relative to the attachment's `store/` directory.

Clearing `smblockctl` (`0x5c3`) bit 8 disables the hardware misaligned-store path, but a cacheable scalar store crossing a 16-byte boundary still has its misalignment exception cleared. The store commits without entering the misalignment buffer and remains allocated in the StoreQueue (SQ) with `datavalid=1` and `addrvalid=0`. Subsequent loads enter forwarding-failure replay and stop making progress.

With bit 8 enabled, the same store is split correctly, leaves the SQ, and the waiting loads complete. The problem is conditional on software clearing bit 8; its reset value is 1.

### Expected behavior

The access should either complete with the correct stored bytes or raise a permitted store-address-misaligned/store-access-fault exception. Disabling hardware misalignment handling should not leave a committed, non-exceptional store without a completion path. The reproducer accepts either permitted exception through a distinct exit path.

### Environment

- Hardware
  - CPU: Intel(R) Xeon(R) 6960P; 288 logical CPUs.
  - Memory (GB): 2430.02 GB (2263.14 GiB), host total.
  - Storage (GB): 1887.42 GB (1757.80 GiB), capacity of the filesystem containing the source checkout.
- Software
  - Operating system: Ubuntu 26.04 LTS, kernel `7.0.0-38-generic`.
  - gcc version: host GCC 15.2.0; the probe compiler is `riscv64-unknown-linux-gnu-gcc (g6afcc4f6d) 16.1.0`.
  - clang version: not found on the collector's PATH; not used for the probe rebuild.
  - java version: historical build log records OpenJDK `21.0.10-internal`; current collector reports Temurin OpenJDK `21.0.11`.
  - mill version: checkout pins `0.12.3` in `.mill-version`; no executable was on the collector's PATH, and no Mill bootstrap was run.
  - Verilator: historical build log records `5.048`, conda-forge build 1; not on the collector's current PATH.
- Repo
  - XiangShan commit id: `fe2288cb09361b65afa26be3f403520c4b496dbf`, a detached checkout of the reported `kunminghu-v2` revision; working tree clean.
  - difftest commit id: `3729300ae233816d332d057f170472ebe35147b0`; working tree clean.
  - NEMU commit id (if difftest failed with NEMU): not applicable to the primary `--no-diff` reproducer. Supplementary differential runs used a reference binary with SHA256 `3e9d63c31d2cd68ec68d55fa9df56ec990ce9a9fd3a8e59709ecb92f21176c40`; its source commit was not recorded.
  - SPIKE commit id (if difftest failed with SPIKE): not applicable; SPIKE was not used.
- Build & Run
  - Build command: the existing simulator build script contains `make emu CONFIG=DefaultConfig NUM_CORES=1 EMU_THREADS=16 EMU_TRACE=1 FIRTOOL=/home/haoran/.cache/llvm-firtool/1.62.1/bin/firtool -j32`. That full RTL/emu build was not rerun during the audit. The exact image is identified by SHA256 `8378454e8d10cf24903ab5778498ccbb00697226ec341dbaec814ec270fe4cb9`.
  - Workload build: the attached helper supports `--rebuild --tool-prefix /home/haoran/.local/opt/riscv/bin/riscv64-unknown-linux-gnu-`; it uses the supplied assembly/linker script and requires byte-identical images. Exact compiler/linker flags are documented in `../common/REPRO_README.md`.
  - Run command (if applicable): the complete command is in **To Reproduce**; it forwards `-i IMAGE --no-diff --max-cycles 30000` through the resource-limited wrapper.

Configuration: `DefaultConfig`, one core, M mode, Bare translation, cacheable DRAM, scalar accesses. The host/tool record was collected at `2026-10-28T11:40:16.102646+00:00`; current host tool versions are distinguished from the historical simulator build. See `../common/HOST_ENVIRONMENT.md`, its JSON source, and `../common/build_provenance.json` in the attachment.

### To Reproduce

1. Extract `store_issue_materials.zip` and enter its `store/` directory. The archive contains the workload sources, binaries, disassembly, symbols, original logs and manifest.

2. Verify the archived evidence without starting the simulator:

   ```bash
   python3 ../common/repro.py --group store --verify-only
   ```

3. Replay on the recorded B200 setup:

```bash
python3 ../common/repro.py --group store \
  --runner /home/haoran/kunminghu_v2_arch_audit_handoff_20261020/function_audit_20261021/run_emu_limited.sh
```

The runner argument is an executable wrapper that accepts emulator arguments. The tested B200 runner path is recorded in `../common/environment.json`. Sources, linker script, prebuilt binaries, disassembly, original logs, and the run manifest are included under `repro/`.

Each probe writes and reads back the full CSR value, preserves unrelated bits, and waits for 128 loop iterations. The target store and first byte-readback round have no fence between them. A fence separates the first and second readback rounds. Every byte load is checked for exceptions.

| Probe | bit 8 | Address | Recorded result |
|---|---:|---|---|
| `store_disabled` | 0 | `0x80002009` | Reaches the 30,000-cycle limit with 307 retired instructions; no self-check exit |
| `store_enabled` | 1 | `0x80002009` | Both readback rounds succeed; actual success exit at `0x8000011c`, 449 retired instructions, 8,875 cycles |
| `store_within` | 0 | `0x80002004` | Same successful readback exit, 449 instructions, 8,875 cycles |
| `store_aligned` | 0 | `0x80002008` | Same successful readback exit, 449 instructions, 8,875 cycles |

The four probes have identical `.text` bytes. `store_disabled.bin` differs from `store_enabled.bin` at only one byte: file offset `0x1009`, `0x01` to `0x00`, selecting bit 8. The other controls change the address parameter. The successful controls reach the data-check success exit, not the separately labeled accepted-exception exit. The custom exit instruction was calibrated with explicit successful and failing programs.

An emulator return code of 0 at the cycle limit is **not** a passing self-check. The disabled probe's retirement count is consistent with stopping before the first readback load retires, using independently checked instruction counts and boot overhead. The original larger test separately remains at 1,281 retired instructions in both 50,000- and 200,000-cycle runs. The timeout's printed final PC is not used as retirement evidence.

### Additional context

**Waveform evidence and root cause**


The retained waveform pair uses QUIET variants of the original test, separately from the probes above. In both captures, the final surviving store at timestamp 9352 has ROB `(0,0x6b)`, SQ `(0,20)`, and virtual/physical address `0x80002009`. It is valid, has a TLB hit, and has no kill, redirect, or store exception. This is not an earlier killed attempt.

| Event | bit 8 cleared | bit 8 enabled |
|---|---|---|
| Misalignment-buffer enqueue | Not valid | `valid && ready` |
| SQ address state | `addrvalid=0`; allocated, committed, and data-valid through timestamp 11000 | Final split sets address validity; SQ completes and is released |
| Target SBuffer transfer | None in the 8800–11000 capture | At 9363, two `valid && ready` transfers at `0x80002008` / `0x80002010`, masks `0xfe00` / `0x1`; exactly the intended eight bytes |
| Subsequent loads | Four requests issue, then enter C_FF replay waiting on SQ20 and remain blocked through 11000 | Initially encounter the same C_FF, but resume after the ready pointer advances past SQ20 |

The corresponding source locations are included, with original line numbers, in source_excerpts.txt (`evidence/source_excerpts.txt`):

- `src/main/scala/xiangshan/mem/pipeline/StoreUnit.scala:404,501` clears the final misalignment exception for this cacheable case; lines 431–436 gate misalignment-buffer handling with `hd_misalign_st_enable`.
- `StoreUnit.scala:418` and `src/main/scala/xiangshan/mem/lsqueue/StoreQueue.scala:523–526` leave the initial SQ address invalid for a cross-16B misaligned store, relying on split completion to establish validity.
- `StoreQueue.scala:570–578` cannot repair this through S2 replenishment: although `replenish_updateAddrValid=1`, it only ORs `hasException` into `addrvalid`, and this transaction has no exception.
- `StoreQueue.scala:728–731,754` and `LoadQueueReplay.scala:309,350–352,706` explain the forwarding-failure wait on the older unaligned store. In the enabled control, `stDataReadySqPtr` advances from 20 to 21 at 9365, replay unblocks at 9366, and the same load ROBs write back at 9371/9372. `stDataReadyVec[20]` remains zero; pointer advancement is the release mechanism.

Thus the observed chain is: disabled split handling + cleared exception → invalid SQ address → store cannot drain → forwarding-failure replay cannot be released.

**Checks against false positives and impact boundary**

The independent probes remove UART and reference-model behavior, verify CSR readback, and use identical instruction bytes across controls. Final-transaction identities, TLB/kill/redirect signals, SBuffer handshake conditions, and subsequent queue transitions agree. The waveform parser checks timestamp completeness and required signals; the selected signals have no missing or unknown samples.

The original differential-test timeout makes the reference model execute an extra instruction. Its register difference is not evidence that a DUT load returned zero. The evidence here is the no-diff lack of progress together with the SQ/replay chain and working controls.

The store data remains in the SQ. This report does not claim permanent data loss or immediate whole-core deadlock: a separate arithmetic/jump probe can still retire. Finite simulations also do not prove that no later interrupt, flush, or reset could recover the core. The demonstrated impact is an uncompleted store and persistent blocking of subsequent memory operations in the tested program.

**Evidence and related issue**

- Reproducer source (`repro/src/store_disabled.S`), run manifest (`repro/manifest.json`), and original logs under `repro/logs/`.
- Waveform event summary (`evidence/wave_chain.json`), full derived events (`evidence/wave_chain_detail.json`), and raw-waveform provenance (`evidence/wave_provenance.json`).
- Original-test log excerpts (`evidence/legacy_log_excerpts.txt`) and full logs under `evidence/legacy_logs/`.
- Detailed store audit (`../common/audit/audit_store_chain.md`) and combined audit (`../common/audit/AUDIT_REPORT.md`).

Related: the load-side issue (`../load/ISSUE.md`), where clearing bit 9 permits a cross-16B load to commit incorrect data without an exception. Both have the same disabled-handler/cleared-exception pattern, but use different control bits and execution paths and require separate regression coverage.

**AI assistance disclosure**

OpenAI Codex (GPT-6 family) assisted with the issue draft, reproduction probes, evidence collection, and audit. The submitter remains responsible for the final review of the technical content, the attached materials, and all checklist attestations.
