.option norvc
.section .text.init,"ax"
.globl _start
_start:
 li a0,51
 .word 0x0005006b
 j .
