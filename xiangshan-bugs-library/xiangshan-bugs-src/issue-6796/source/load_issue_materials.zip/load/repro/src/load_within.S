
.option norvc
.option norelax
.section .text.init,"ax"
.globl _start
_start:
  la t0, trap_handler
  csrw mtvec, t0
  li t0, -1
  csrw pmpaddr0, t0
  li t0, 0x1f
  csrw pmpcfg0, t0
  li s0, 0
  li s1, 0
  li s2, 0
  li s3, 0
  la s7, parameters
  ld s6, 0(s7)
  li s4, 0x80002000
  add s4, s4, s6

  # Independent oracle: reconstruct the requested 64-bit value from byte loads.
  mv t0, s4
  li t1, 0
  li t2, 8
  li s10, 0
oracle_bytes:
  lbu t3, 0(t0)
  sll t3, t3, t1
  or s10, s10, t3
  addi t0, t0, 1
  addi t1, t1, 8
  addi t2, t2, -1
  bnez t2, oracle_bytes
  bnez s0, unexpected_trap
  li s8, 0
  li s11, 0
  addi s7, s7, 8
load_phase:
  fence rw, rw
  li s0, 0
  ld t2, 0(s7)
  csrr t0, 0x5c3
  li t1, -513
  and t0, t0, t1
  or t0, t0, t2
  csrw 0x5c3, t0
  csrr t1, 0x5c3
  bnez s0, csr_failure
  bne t0, t1, csr_readback_failure
  li t5, 128
load_settle:
  addi t5, t5, -1
  bnez t5, load_settle
  li s0, 0
  li t3, 0x0bad0bad
measured_load:
  ld t3, 0(s4)
  beqz s0, check_load_value
  li t0, 4
  beq s1, t0, accepted_load_trap
  li t0, 5
  bne s1, t0, unexpected_trap
accepted_load_trap:
  beqz s2, load_trap_value_ok
  bne s2, s4, unexpected_trap
load_trap_value_ok:
  li t0, 1
  sll t0, t0, s11
  or s8, s8, t0
  j next_load_phase
check_load_value:
  beq t3, s10, next_load_phase
  li t0, 1
  sll t0, t0, s11
  or s3, s3, t0
next_load_phase:
  addi s7, s7, 8
  addi s11, s11, 1
  li t0, 3
  bltu s11, t0, load_phase
  mv a0, s3
  beqz s3, load_good
  li t0, 2
  bne s3, t0, load_bad
  bnez s8, load_bad
load_middle_only_bad:
  .word 0x0005006b
load_good:
  .word 0x0005006b
load_bad:
  .word 0x0005006b

csr_failure:
  li a0, 97
  .word 0x0005006b
csr_readback_failure:
  li a0, 98
  .word 0x0005006b
unexpected_trap:
  li a0, 99
  .word 0x0005006b
trap_handler:
  csrr s1, mcause
  csrr s2, mtval
  csrr t6, mepc
  li s0, 1
  addi t6, t6, 4
  csrw mepc, t6
  mret
.section .blka,"aw"
  .quad 0x1122334455667788
  .quad 0x99aabbccddeeff00
  .quad 0x0f1e2d3c4b5a6978
  .quad 0xa5a5a5a55a5a5a5a

.section .config,"a"
parameters:
 .quad 4
 .quad 512
 .quad 0
 .quad 512
