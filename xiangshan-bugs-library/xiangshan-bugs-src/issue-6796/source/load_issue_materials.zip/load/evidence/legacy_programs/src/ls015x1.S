# LS015:X1 whole-core PoC  (Kunminghu V2, fe2288cb09)
#
# Claim: with smblockctl(0x5C3).HD_MISALIGN_LD_ENABLE (bit 9) cleared,
# a *cacheable* scalar load that crosses a 16B boundary is flagged
# loadAddrMisaligned in S0, which kills the DCache data-array read in S1
# (io.dcache.s1_kill / s1_kill_data_read), but in S2 LoadUnit.scala:1350
# rewrites s2_real_exceptionVec(loadAddrMisaligned) to
# "(isMisalign||isFrm) && actually_pbmt_nc && ..." == 0 for cacheable,
# and s2_mis_align is gated by the CSR (LoadUnit.scala:1246).
# => s2_real_exception=0, s2_safe_wakeup=1, s3 writes the killed data back
#    to the GPR, no trap, no misalign-buffer entry.
#
# M-mode, Bare translation, DRAM at 0x8000_0000 (PMA cacheable).
# Observation is purely in-program: every measurement prints
#   <tag> A=<addr> F=<trap flag> C=<mcause> V=<loaded GPR value> T=<mtval>
# over UART16550 @ 0x310b_0000.
#
# Single-variable knob: -DCSR_MODE=0 / 1 selects ONLY the value written to
# bit 9 of 0x5C3 (same RMW sequence, same instruction stream otherwise).
#   CSR_MODE=1 : bit9 = 1 (reset value; hardware misalign handling on) -> oracle
#   CSR_MODE=0 : bit9 = 0 (DUT condition)

.option norvc
.equ UART_BASE, 0x310b0000
.equ BLKA,      0x80002000
.equ BLKB,      0x80003000
.equ TRAPSTATE, 0x80004000
.equ STACK,     0x80004800

#ifndef CSR_MODE
#define CSR_MODE 0
#endif

# --------------------------------------------------------------- measure
# tag, load-mnemonic, base, byte-offset
.macro MEAS tag, insn, base, off
  li    t0, TRAPSTATE
  sd    x0, 0(t0)              # trap flag
  sd    x0, 8(t0)              # mcause
  sd    x0, 16(t0)             # mtval
  li    t3, 0x0BAD0BAD         # poison: survives only if the load traps
  li    a1, \base
  addi  a1, a1, \off
  \insn t3, 0(a1)
  mv    a0, t3
  li    a2, \tag
  jal   ra, report
.endm

# ---------------------------------------------------------------- text
.section .text.init, "ax"
.globl _start
_start:
  li    sp, STACK

  la    t0, trap_handler
  csrw  mtvec, t0

  li    t0, -1
  csrw  pmpaddr0, t0
  li    t0, 0x1f
  csrw  pmpcfg0, t0

  li    t0, TRAPSTATE
  sd    x0, 0(t0)
  sd    x0, 8(t0)
  sd    x0, 16(t0)

  la    s1, banner
  jal   ra, puts_
  li    t6, '0'
  addi  t6, t6, CSR_MODE
  jal   ra, putc_
  la    s1, nl
  jal   ra, puts_

  # -------- reset / initial value of smblockctl
  la    s1, s_csr
  jal   ra, puts_
  csrr  a0, 0x5c3
  jal   ra, puthex_
  la    s1, nl
  jal   ra, puts_

  # -------- phase A: cross-16B cacheable ld with CSR at its current value
  #          (for CSR_MODE=1 this is the environment positive control and it
  #           also warms the 16B line in L1D)
  MEAS  0x41, ld, BLKA, 9      # 'A'  expect 0x7899aabbccddeeff

  # -------- phase B: RMW on bit 9 only (single variable)
  fence
  csrr  t1, 0x5c3
#if CSR_MODE == 0
  li    t2, -513               # ~(1<<9)
  and   t1, t1, t2
#else
  li    t2, 0x200
  or    t1, t1, t2
#endif
  csrw  0x5c3, t1

  la    s1, s_csr2
  jal   ra, puts_
  csrr  a0, 0x5c3
  jal   ra, puthex_
  la    s1, nl
  jal   ra, puts_

  # cover MemBlock DelayN(2) + GatedValidRegNext before the trigger load
  csrr  t4, 0x5c3
  li    t5, 64
1:
  addi  t5, t5, -1
  xor   t4, t4, t5
  bnez  t5, 1b

  # -------- phase C: same cross-16B ld, line now preheated in L1D
  MEAS  0x43, ld, BLKA, 9      # 'C'  expect 0x7899aabbccddeeff

  # -------- phase D: cold 16B line, same cross-16B ld
  MEAS  0x44, ld, BLKB, 9      # 'D'  expect 0xe0a1b2c3d4e5f607

  # -------- phase E: controls, same CSR value
  MEAS  0x45, ld, BLKB, 4      # 'E'  inside 16B, misaligned: 0xe5f60718c0ffee11
  MEAS  0x46, ld, BLKB, 0      # 'F'  aligned:               0xc0ffee1122334455
  MEAS  0x47, lw, BLKB, 13     # 'G'  cross-16B lw:           0xffffffffe0a1b2c3
  MEAS  0x48, lh, BLKB, 15     # 'H'  cross-16B lh:           0xffffffffffffe0a1
  MEAS  0x49, ld, BLKA, 15     # 'I'  cross-16B ld @+15:      0x1e2d3c4b5a697899
  # 'J' cross-16B load in the UART/MMIO window (PMA non-cacheable):
  #     must still raise loadAddrMisaligned (STATIC_CHECK G13), i.e. trap.
  MEAS  0x4a, ld, UART_BASE, 9

  la    s1, s_end
  jal   ra, puts_
  csrr  a0, mcause
  jal   ra, puthex_
  la    s1, s_mepc
  jal   ra, puts_
  csrr  a0, mepc
  jal   ra, puthex_
  la    s1, nl
  jal   ra, puts_
1:
  j     1b

# ------------------------------------------------------- M trap entry
# Records the fault and resumes at mepc+4 so the sweep keeps running.
# Clobbers only t0/t1/t2/t6 (never t3, which holds the measurement).
  .align 2
trap_handler:
  csrr  t0, mcause
  csrr  t1, mtval
  csrr  t2, mepc
  li    t6, TRAPSTATE
  li    t0, 1
  sd    t0, 0(t6)
  csrr  t0, mcause
  sd    t0, 8(t6)
  sd    t1, 16(t6)
  addi  t2, t2, 4
  csrw  mepc, t2
  mret

# ---------------------------------------------------------- report
# prints "<tag> A=<addr> F=<flag> C=<mcause> V=<value> T=<mtval>"
#ifdef QUIET
# Wave build only: identical instruction stream for the measurements, but the
# UART dump is replaced by a fixed 100-iteration delay so that a short cycle
# window covers the whole sweep and each phase stays visually separated.
report:
  li    t0, 100
1:
  addi  t0, t0, -1
  bnez  t0, 1b
  ret
#else
report:
  addi  sp, sp, -40
  sd    ra, 0(sp)
  sd    a0, 8(sp)
  sd    a1, 16(sp)
  sd    a2, 24(sp)
  mv    t6, a2
  jal   ra, putc_
  la    s1, s_a
  jal   ra, puts_
  ld    a0, 16(sp)
  jal   ra, puthex_
  la    s1, s_f
  jal   ra, puts_
  li    t0, TRAPSTATE
  ld    a0, 0(t0)
  jal   ra, puthex_
  la    s1, s_c
  jal   ra, puts_
  li    t0, TRAPSTATE
  ld    a0, 8(t0)
  jal   ra, puthex_
  la    s1, s_v
  jal   ra, puts_
  ld    a0, 8(sp)
  jal   ra, puthex_
  la    s1, s_t
  jal   ra, puts_
  li    t0, TRAPSTATE
  ld    a0, 16(t0)
  jal   ra, puthex_
  la    s1, nl
  jal   ra, puts_
  ld    ra, 0(sp)
  ld    a0, 8(sp)
  ld    a1, 16(sp)
  ld    a2, 24(sp)
  addi  sp, sp, 40
  ret
#endif

# ---------------------------------------------------------- helpers
#ifdef QUIET
putc_:
  ret
#else
putc_:
  li    t5, UART_BASE
1:
  lbu   t4, 0x14(t5)
  andi  t4, t4, 0x20
  beqz  t4, 1b
  sb    t6, 0(t5)
  ret
#endif

puts_:
  addi  sp, sp, -16
  sd    ra, 0(sp)
1:
  lbu   t6, 0(s1)
  beqz  t6, 2f
  jal   ra, putc_
  addi  s1, s1, 1
  j     1b
2:
  ld    ra, 0(sp)
  addi  sp, sp, 16
  ret

puthex_:
  addi  sp, sp, -32
  sd    ra, 0(sp)
  sd    s3, 8(sp)
  sd    s4, 16(sp)
  li    s3, 60
1:
  srl   s4, a0, s3
  andi  s4, s4, 0xf
  li    t0, 10
  bltu  s4, t0, 2f
  addi  t6, s4, 87
  j     3f
2:
  addi  t6, s4, 48
3:
  jal   ra, putc_
  addi  s3, s3, -4
  bge   s3, x0, 1b
  ld    ra, 0(sp)
  ld    s3, 8(sp)
  ld    s4, 16(sp)
  addi  sp, sp, 32
  ret

.section .rodata
banner:
  .asciz "LS015X1 START CSR_MODE="
s_csr:
  .asciz "BEFORE 5c3="
s_csr2:
  .asciz "AFTER  5c3="
s_a:
  .asciz " A="
s_f:
  .asciz " F="
s_c:
  .asciz " C="
s_v:
  .asciz " V="
s_t:
  .asciz " T="
s_end:
  .asciz "END mcause="
s_mepc:
  .asciz " mepc="
nl:
  .asciz "\n"

# ---------------------------------------------------------- payload
.section .blka, "aw"
  .quad 0x1122334455667788
  .quad 0x99AABBCCDDEEFF00
  .quad 0x0F1E2D3C4B5A6978
  .quad 0xA5A5A5A55A5A5A5A

.section .blkb, "aw"
  .quad 0xC0FFEE1122334455
  .quad 0xA1B2C3D4E5F60718
  .quad 0x13579BDF2468ACE0
  .quad 0xDEADBEEFCAFEBABE

.section .data, "aw"
  .space 0x1000
