OUTPUT_ARCH(riscv)
ENTRY(_start)

SECTIONS
{
  . = 0x80000000;
  .text : { *(.text.init) *(.text*) *(.rodata*) }

  . = 0x80002000;
  .blka : { *(.blka) }

  . = 0x80003000;
  .blkb : { *(.blkb) }

  . = 0x80004000;
  .data : { *(.data) }

  /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) *(.riscv.attributes) }
}
