# Reproducing the calibrated load and store probes

The package contains the exact probe sources, binaries, disassembly, symbol tables and logs from the audited 2026-10-28 runs. `repro.py` is a new packaging helper: its archive verification has been exercised against those logs; creating this helper does not constitute a new hardware simulation run.

Use Python 3.8 or newer. Commands below start in the package root. They also work from an issue directory by replacing `common/repro.py` with `../common/repro.py`.

## Verify the archived evidence without running the simulator

```sh
python3 common/repro.py --group all --verify-only
```

This checks every selected image, extracted `.text`, and original log against the per-issue manifest; verifies identical instruction bytes and exact configuration-byte differences within each group; checks the calibrated `a0` exit encoding; and classifies the actual archived terminal marker, exit PC and return code. It does not rebuild or run anything, and it does not claim that the archived log PC at a cycle limit is a retired instruction.

## Replay on the tested B200 setup

```sh
python3 common/repro.py --group load \
  --runner /home/haoran/kunminghu_v2_arch_audit_handoff_20261020/function_audit_20261021/run_emu_limited.sh

python3 common/repro.py --group store \
  --runner /home/haoran/kunminghu_v2_arch_audit_handoff_20261020/function_audit_20261021/run_emu_limited.sh
```

The helper invokes only the supplied wrapper, using `-i IMAGE --no-diff --max-cycles 30000`. There is no direct-emulator fallback. Use the tested wrapper or an equivalent wrapper that applies resource and wall-time limits and forwards the simulator return code. The tested wrapper enforces a 100 GiB memory cap, no swap, and a 1,800-second runtime limit. Check available server resources before starting a new run. A different wrapper or emulator is a new environment, not automatically the one identified in `environment.json`.

Each group first runs explicit success/failure exit calibration, then the controls and target probe. New output goes to a unique `reruns/repro-*` directory. `--output-dir /absolute/new/path` selects a different, previously nonexistent destination. Original evidence is never overwritten. The result records commands, image/log hashes, process return codes, observed terminal markers, counts and interpretations. The helper stops if calibration or any expected signature differs. Such a difference needs inspection: it may indicate a corrected implementation, environment variation or an execution problem.

## Optional byte-identical rebuild before replay

```sh
python3 common/repro.py --group load --rebuild \
  --tool-prefix /home/haoran/.local/opt/riscv/bin/riscv64-unknown-linux-gnu- \
  --runner /home/haoran/kunminghu_v2_arch_audit_handoff_20261020/function_audit_20261021/run_emu_limited.sh
```

`--rebuild` requires GNU `gcc`, `ld` and `objcopy` with the supplied prefix. It uses the original flags (`rv64imac_zicsr_zifencei`, LP64, no standard library, non-PIC, no linker relaxation) and the supplied linker script. New objects, ELF files and raw images go into the new result directory; both image and `.text` hashes must match the archived binaries before replay. The packaging helper's rebuild/replay paths were not used to generate the archived evidence. `--verify-only` cannot be combined with `--rebuild`.

## Interpretation of the expected results

| Probe | Required observed signature | Meaning |
|---|---|---|
| `exit_good` / `exit_bad` | GOOD / BAD at `0x80000004`, rc 0 / 1 | The custom exit carries `a0`; failures are observable. |
| `load_aba` | ABORT at `load_middle_only_bad = 0x8000012c`, rc 1 | Program failure code 2: only the middle, bit9-disabled phase returned the wrong value, and none of the three phases raised an exception. |
| `load_enabled`, `load_within` | GOOD at `load_good = 0x80000130`, rc 0 | No incorrect returned value; this exit also permits legal load exceptions. The ABA-specific exit supplies the stronger no-exception evidence. |
| `store_enabled`, `store_within`, `store_aligned` | GOOD at `store_good + 4 = 0x8000011c`, rc 0 | Both byte-readback rounds completed correctly. This is separate from the accepted store-exception exit. |
| `store_disabled` | Cycle limit at 30,000 cycles, 307 retired instructions, rc 0 | Matches the bounded non-completion signature. This rc is not a successful self-check, and the reported limit PC is not retirement evidence. |

The load `ABORT` string is the simulator's name for custom exit code 2; the dedicated exit label and preceding calibration distinguish this self-check failure from an assertion failure. The store classification confirms the archived finite-run signature only. Its causal diagnosis also relies on the final valid store transaction, SQ state and load replay evidence included with the store issue. Neither the helper nor a finite cycle limit establishes permanent data loss or unconditional core deadlock.
