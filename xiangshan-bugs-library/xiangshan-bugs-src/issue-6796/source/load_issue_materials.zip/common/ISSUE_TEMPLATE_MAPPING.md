# XiangShan bug report form mapping

The two English `ISSUE.md` files follow the field order and English labels in the official [XiangShan Bug report form](https://github.com/OpenXiangShan/XiangShan/blob/kunminghu-v3/.github/ISSUE_TEMPLATE/1-bug_report.yaml), retrieved on 2026-10-28. Template Git blob: `8990125b39006a2813b228d0763fc09ecb6e500a`. The contribution guidance was also read: [CONTRIBUTING.md](https://github.com/OpenXiangShan/XiangShan/blob/kunminghu-v3/CONTRIBUTING.md), Git blob `6ab5016bb8d8706469c93293a7698240b973e067`.

The template is obtained from the current default branch, `kunminghu-v3`; the reported and tested branch is `kunminghu-v2`. These are different facts.

| GitHub form field | Material supplied |
|---|---|
| Before start | The four English checkbox statements, left unchecked for the submitter to confirm. The recorded verification has not reproduced either issue on the latest default-branch commit. |
| Branch | `kunminghu-v2` |
| Describe the bug | Concrete trigger, observed behavior and comparison results. Original logs are supplied as attachments instead of pasted in full. |
| Expected behavior | Correct completion or the permitted architectural exception. |
| Environment | Hardware, Software, Repo, and Build & Run groups, plus the exact recorded emulator identity. The host collection timestamp is distinguished from the existing simulator build. |
| To Reproduce | Numbered steps, source/binary locations and the calibrated no-diff runner command. |
| Additional context | Causal evidence, false-positive exclusions, scope, related report and AI-assistance disclosure. |

When opening the GitHub Bug report form, use the corresponding `TITLE.txt` as the title and paste each `###` section's content into its matching field. Attach the corresponding issue ZIP in the reproduction field. Replace the companion-report reference with the actual issue link after both reports exist.

The checked status of the required form attestations must reflect what the submitter has actually completed. In particular, the latest-default-branch reproduction box cannot be checked based on the recorded v2 evidence. This template conversion did not perform a latest-v3 reproduction or a comprehensive duplicate issue/PR search, and it does not attest that the submitter has manually reviewed the AI-assisted report.

The project accepts AI-assisted bug reports and asks for the model/framework and scope of assistance in Additional context. These reports disclose assistance with test generation, evidence analysis and drafting. The submitter remains responsible for the content and final review.
