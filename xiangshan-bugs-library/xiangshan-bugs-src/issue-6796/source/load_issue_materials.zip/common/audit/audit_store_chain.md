# Final store transaction and replay chain

The two retained store waveforms cover timestamps 8800–11000 with 2,201 unique consecutive rows and no missing required fields or unknown sampled values. They are post-positive-edge snapshots. Handshake conditions and later state changes are used together; a combinational output and a same-row register value are not assumed to have been accepted simultaneously.

| Raw waveform | SHA256 |
|---|---|
| Disabled | 827b477af1de497acdd979e589d8047ec4f7850a450865adc85385a0c94e748a |
| Enabled | 6cb1269774b0fc208fc6b8e15d61947096155a33e3aef214a0f070cae9018844 |

These are quiet variants. Their transaction behavior can corroborate the ordinary test, but their timestamps are not the retirement times of the UART variant.

## Final surviving transaction

At 9352, both variants have a valid S1 store in `inner_StoreUnit_1`, with TLB hit, kill=0 and redirect=0. ROB is `(0,0x6b)`, SQ is `(0,0x14)`, virtual and physical address are `0x80002009`, and store exception bits 6/7/15/23 are zero.

| Observation | bit8=0 | bit8=1 |
|---|---:|---:|
| 9352 misalignment buffer enqueue valid and ready | 0 | 1 |
| 9352 initial SQ updateAddrValid | 0 | 0 |
| 9353 same-transaction S2 valid | 1 | 1 |
| 9353 S2 misalignment handling | 0 | 1 |
| 9353 S2 exception / kill | 0 / 0 | 0 / 0 |

The enabled variant issues split pieces through `inner_StoreUnit_0` at 9356 and 9359. Both have the same ROB/SQ identity and valid TLB-hit, non-killed behavior. The final piece asserts address update at 9359; SQ address validity is set at 9360.

In the disabled case, S2 replenishment updateAddrValid is also 1 at 9353. However, that SQ path only ORs `hasException` into the old address-valid bit; `hasException=0`, so it cannot repair the entry.

## SQ and store buffer

Disabled: SQ20 is allocated at 9348, data-valid at 9357 and committed at 9360. It remains allocated, committed, data-valid, address-invalid and incomplete through 11000. No target-address SBuffer valid-and-ready condition occurs in the capture window. The entry has not been discarded.

Enabled: address validity is set at 9360, committed at 9362, and both SBuffer ports have valid-and-ready at 9363:

| Port | Address | Mask | Target bytes |
|---|---|---|---|
| 0 | 0x80002008 | 0xfe00 | 0x80002009–0x8000200f: be ba fe ca ef be ad |
| 1 | 0x80002010 | 0x1 | 0x80002010: de |

These bytes are exactly the little-endian representation of `0xdeadbeefcafebabe`. SQ completion is observed at 9364 and release at 9365.

## Subsequent loads

The disabled variant issues three DCache requests at 9354 and one at 9355, at addresses `0x80002010`, `0x80002008`, `0x80002000` and `0x80002018`. At S2, all four report forwarding failure with invalid-data SQ index 20, replay cause bit 2 set and safe wakeup clear. Their ROB IDs are `(0,0x71)`, `(0,0x70)`, `(0,0x6f)` and `(0,0x72)`.

Replay slots 7/8/9/10 are allocated at 9358/9359 with cause mask `0x4`, blockSqIdx `(0,20)` and blocking=1. They stay blocked through 11000, with ready pointer 20 and no subsequent load writeback.

The enabled variant first has the same transient forwarding failures. It recovers when the ready pointer advances from 20 to 21 at 9365. Blocking clears at 9366; requests reissue at 9368/9369; the same four ROB transactions write back at 9371/9372; replay entries are released at 9372/9373. The per-entry ready bit for SQ20 remains zero due to unaligned-entry gating; recovery uses pointer advancement.

The source conditions in StoreQueue and LoadQueueReplay match these transitions. Older allocated unaligned stores conservatively cause forwarding failure, including for different addresses. The uncompleted SQ entry prevents the pointer from passing it. This is the observed causal blockage; it is not evidence that all DCache requests were suppressed by LoadQueueRAW.

The supplementary 50k/200k runs provide longer-window corroboration. No claim is made of permanent loss of the retained data or recovery being impossible after external interruption, flush or reset.
