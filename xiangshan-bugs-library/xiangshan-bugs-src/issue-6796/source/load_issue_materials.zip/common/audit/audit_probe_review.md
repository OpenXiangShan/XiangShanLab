# Calibrated probe interpretation

The packaged programs are the corrected v2 probes, not the initial experimental exit implementation. The primary runs use `--no-diff --max-cycles 30000`; no NEMU comparison determines their outcome.

The custom instruction `0x0005006b` reads `a0`. In the tested DecodeUnit/ROB implementation, the committed trap's value supplies the exit code. The initial experimental `0x0000006b` read x0 and was therefore unsuitable for distinguishing failure; none of those initial logs is used as primary success evidence here.

| Program | Exit marker | Actual exit PC | Retired instructions | Cycle count | Process rc |
|---|---|---|---:|---:|---:|
| exit_good | GOOD | 0x80000004 | 7 | 8260 | 0 |
| exit_bad | BAD | 0x80000004 | 7 | 8263 | 1 |
| load_enabled | GOOD | 0x80000130 | 924 | 9249 | 0 |
| load_aba | ABORT, deliberate code 2 | 0x8000012c | 930 | 9285 | 1 |
| load_within | GOOD | 0x80000130 | 924 | 9215 | 0 |
| store_enabled | GOOD | 0x8000011c | 449 | 8875 | 0 |
| store_disabled | Cycle limit; no test exit | Not a commit location | 307 | 30000 | 0 |
| store_within | GOOD | 0x8000011c | 449 | 8875 | 0 |
| store_aligned | GOOD | 0x8000011c | 449 | 8875 | 0 |

`load_middle_only_bad` is reachable only with error mask `s3=2` and exception mask `s8=0`. The single measured load PC is `0x800000c8`; its phases enable, disable and re-enable bit9. The dedicated exit proves only the middle phase returns incorrect data and all three execute without exceptions. The expected word is assembled from eight byte loads, and the trap handler preserves the measurement registers.

The harness names code 2 `ABORT`. In this run that marker is a committed self-check exit at the dedicated label; it is not an assertion diagnostic or a differential mismatch. The generic `load_good` path, by contrast, permits a correct result or an allowed exception. Do not infer absence of exceptions solely from the enabled/within GOOD markers.

The store success exit is `store_good+4` at `0x8000011c`. The legal-store-exception success exit is distinct, at `0x800000c4`. Each of eight byte readbacks checks both the value and the exception flag; the complete successful path performs a readback before and after the subsequent fence. Thus the three recorded control exits establish actual successful writes/readbacks.

The disabled store has not reached any self-check exit. Its rc=0 means the cycle limit was reached, not that the test passed. The 307-instruction count is consistent with 301 instructions before the first byte readback plus the six startup instructions calibrated by the minimal exit programs. This is corroborating localization, not a replacement for the waveform/commit evidence. Initialization includes a fence; there is no fence between the target store and its first readback.

Group instruction bytes are identical. Load ABA versus enabled changes only byte offset `0x1011` from 2 to 0. Store disabled versus enabled changes only offset `0x1009` from 1 to 0. Address-shape controls additionally change offset `0x1000`. Full CSR readback and 128 settling-loop iterations precede the measured access.

The probe success criteria allow `mtval=0` for permitted exceptions. Store probes check the target eight bytes; the supplementary original controls additionally check the surrounding 32-byte region. The latter supplements neighboring-byte coverage without changing the primary failure criterion.
