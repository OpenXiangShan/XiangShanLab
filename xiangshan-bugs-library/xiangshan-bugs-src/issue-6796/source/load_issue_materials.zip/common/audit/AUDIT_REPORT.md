# Causal audit of the misaligned load and store failures

The 2026-10-28 runs support two defects in Kunminghu V2 commit `fe2288cb09361b65afa26be3f403520c4b496dbf`, using emulator SHA256 `8378454e8d10cf24903ab5778498ccbb00697226ec341dbaec814ec270fe4cb9`.

Clearing `smblockctl` (`0x5c3`) bit9 can cause a cacheable scalar load crossing a 16-byte boundary to commit incorrect data without an exception. Clearing bit8 can leave a cacheable cross-boundary store in the SQ with an invalid address, blocking subsequent loads on forwarding-failure replay. Both bits reset to 1; these are conditional failures after software disables the corresponding hardware handling.

Both paths clear the final cacheable misalignment exception even when the CSR has disabled the hardware misalignment path. The load then permits ordinary writeback despite the cancelled cache read. The store cannot establish the address-valid state normally supplied by its split-access path.

## Independent program-level evidence

The calibrated v2 probes use no UART, stack or NEMU. They preserve other CSR bits, verify the full CSR readback and wait through 128 loop iterations. Within each group, the instruction bytes are identical; variants differ only in the parameter area. The load oracle reconstructs the expected value using eight byte loads.

| Probe | Recorded result | Meaning |
|---|---|---|
| `load_aba` | Custom exit at `0x8000012c`, code 2, 930 retired instructions | This label is reachable only when the error mask is 2 and the trap mask is 0: only the middle disabled phase fails, while both enabled phases succeed without exceptions. |
| `load_enabled`, `load_within` | GOOD exit at `0x80000130` | The generic success path accepts correct data or an allowed exception. These markers alone do not prove absence of exceptions; the ABA-specific exit does. |
| `store_enabled`, `store_within`, `store_aligned` | GOOD exit at `0x8000011c`, 449 retired instructions | All eight target bytes compare correctly both before and after the subsequent fence, without a readback exception. The legal-store-trap exit has a different PC. |
| `store_disabled` | 30,000-cycle limit, 307 retired instructions, no test completion | The retired count is consistent with stopping before the first byte readback. There is no fence between the target store and this first readback. |

The load ABA and fully enabled binaries differ only at file offset `0x1011` (`0x02` to `0x00`, bit9). The disabled/enabled store binaries differ only at `0x1009` (`0x01` to `0x00`, bit8). The nine original binary, text-section and log hashes were independently checked against the run manifest.

The special exit instruction is `0x0005006b`, which reads `a0`. Explicit code-0 and code-51 programs calibrate GOOD and BAD exits. Code 2 is named `ABORT` by the harness; for `load_aba` it is a deliberate self-check result at the dedicated label, not an assertion failure or a NEMU comparison. See [probe review](audit_probe_review.md).

## Load causal chain

The supplementary differential commit trace records `ld@0x80000140` writing zero to `t3`, followed by `mv@0x80000144` writing zero to `a0`. The expected value from the byte layout is `0x7899aabbccddeeff`; the load has no skip/delayed flag. Its actual commit evidence is separate from the quiet waveform variant.

For the quiet variant, the final load transaction has ROB `(0,0x0f)` and address `0x80002009`:

- At timestamp 9618 with bit9=0, S1 is valid, the TLB hits, and kill/redirect are absent. The misalignment condition cancels the DCache read.
- At 9619, the original S2 exception is set, but the final misalignment exception and final exception are cleared. Hardware misalignment handling is disabled, safe wakeup is enabled, and the DCache response is not valid.
- At 9620, the same transaction has writeback `valid && ready` and register-write enable, without entering the misalignment buffer.
- With bit9=1, the corresponding transaction retains hardware misalignment handling, suppresses ordinary safe wakeup and enters the misalignment buffer.

`LoadUnit.scala:1246–1247` gates hardware handling; `:1350` clears the final cacheable misalignment exception; `:1363–1368` determines the final exception and wakeup. The replay/response checks at `:1316–1323` still use the original exception and do not protect this final-exception gap. Source excerpts accompany the load issue.

The sampled quiet-variant writeback word is `0x800000`, whereas the supplementary UART/differential variant commits zero. The defect is incorrect data, not a guaranteed constant-zero result. Architectural evidence comes from the commit trace and the ABA self-check, not from treating one waveform sample as a commit.

## Store causal chain

At timestamp 9352, the final surviving transaction in both quiet variants is ROB `(0,0x6b)`, SQ `(0,0x14)`, address `0x80002009`. It is valid, TLB-hit, not killed or redirected, and has no store exception. This excludes the earlier killed attempt used in an initial extraction.

With bit8=0, the transaction does not enter the misalignment buffer. SQ20 becomes data-valid and committed, but remains allocated and address-invalid through timestamp 11000. There is no target-address SBuffer handshake in the captured interval.

With bit8=1, the same transaction is split. The final half establishes address validity. At 9363, the SBuffer interfaces accept the two pieces at `0x80002008` and `0x80002010`, with masks `0xfe00` and `0x1`; these cover the exact eight target bytes. The SQ entry then completes and is released.

Four subsequent loads do issue requests. In the disabled case they enter C_FF replay, blocked on SQ20. In the enabled case they initially experience the same transient forwarding failure, but `stDataReadySqPtr` advances from 20 to 21 at 9365, replay unblocks at 9366, requests reissue at 9368/9369 and the same ROB transactions write back at 9371/9372. `stDataReadyVec[20]` remains zero in both variants; pointer advancement is the recovery condition.

The S2 replenishment interface does assert `updateAddrValid` in the disabled case. However, `StoreQueue.scala:570–578` only ORs `hasException` into address validity there; this transaction has no exception. That path cannot repair the missing valid bit. The subsequent failure mechanism is StoreQueue forwarding failure followed by LoadQueueReplay C_FF waiting, not total suppression of requests by LoadQueueRAW. See [the detailed store chain](audit_store_chain.md).

## False-positive checks and corrections

| Alternative explanation | Evidence and interpretation |
|---|---|
| Stale images or logs | 27 original test images were rebuilt identically; the 17 supplementary run logs match their manifest. The new v2 results have separately verified hashes. |
| Wrong endianness, expected constant or instruction layout | Host-side byte oracles, actual disassembly and the in-program byte oracle agree. Per-group instructions are identical. |
| UART, stack or ABI corruption | The primary probes use none of these. The supplementary load already commits incorrect data before reporting it. |
| NEMU modelling or skip behavior | The primary probes use `--no-diff`; the supplementary offending load is not skipped. |
| CSR ignored or insufficient propagation time | Full readback checks and settling loops precede measurement; the on/off/on load test recovers in its final enabled phase. |
| TLB miss, redirect or wrong-path attempt | Final waveform transactions are tracked by ROB/SQ IDs with TLB hit, kill=0 and redirect=0. |
| Store differential register mismatch proves a zero readback | It does not. The no-commit timeout checker advances REF before reporting failure. One supplementary store timeout has no register mismatch at all. |
| Printed final PC proves a retired instruction | It does not. A stale trap-PC fallback can be printed. Actual commit records and real committed custom exits are used instead. |
| Load error was discovered later in UART | The printed `0x80000444` is the stale trap-PC fallback, not evidence of delayed comparison at UART. |
| Store stopped at a deliberate park or at the later fence | The ordinary trace stops before the first readback; the independent probe also fails before the post-store fence. Pure-jump probes can still retire. |
| Different legal misalignment exception policy | Correct completion or an address-misaligned/access-fault exception is allowed. MMIO cause 4/5 differences are excluded from these findings. |
| All updateAddrValid signals stayed low | Incorrect: S2 replenishment is asserted but cannot restore validity without an exception. |

The [RISC-V load/store alignment rules](https://docs.riscv.org/reference/isa/v20260120/unpriv/rv32.html) allow an execution environment to complete misaligned accesses correctly or raise the permitted exceptions. Non-atomicity does not explain a wrong read of stable data without competing writes in these single-core tests.

## Evidence quality and scope

Four raw VCDs are retained on B200 with recorded hashes. The independent parser yields 2,201 unique consecutive timestamps per waveform, no required missing signals and no unknown sampled values. These are post-positive-edge snapshots; sampled `valid && ready`, transaction identity and subsequent state changes are interpreted together. The initial fixed waveform annotations and defective EOF/duplicate-timestamp parser are excluded. The parser's initial missing-scope result and the first probes' incorrect x0-based exit encoding are also excluded; only the corrected v2 evidence supports the conclusions.

The source tree and difftest submodule were clean. Relevant Scala, generated RTL and recorded Verilator input sizes/timestamps agree with the waveform behavior. The audit rebuilt test programs, but did not perform a fresh full RTL generation/link or a second-simulator validation. Conclusions are bounded to the recorded emulator and tested single-core M-mode Bare cacheable scalar accesses, not a statement about current upstream or physical silicon.

The store result demonstrates an unresolved SQ/replay blockage and lack of progress in the tested programs, including unchanged retirement counts at 50k and 200k cycles. It is not a formal proof of permanent unrecoverability under interrupts, flushes or reset. The SQ retains the data; permanent data loss and unconditional immediate whole-core deadlock are not claimed.
