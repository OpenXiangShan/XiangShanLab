#!/usr/bin/env python3
"""Verify the archived probes or replay them through a supplied limited runner."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

GROUPS = {
    'load': ['load_enabled', 'load_aba', 'load_within'],
    'store': ['store_enabled', 'store_disabled', 'store_within', 'store_aligned'],
}
CALIBRATION = ['exit_good', 'exit_bad']
EXPECTED_DIFFS = {
    'load_enabled': {},
    'load_aba': {0x1011: (2, 0)},
    'load_within': {0x1000: (9, 4), 0x1011: (2, 0)},
    'store_enabled': {},
    'store_disabled': {0x1009: (1, 0)},
    'store_within': {0x1000: (9, 4), 0x1009: (1, 0)},
    'store_aligned': {0x1000: (9, 8), 0x1009: (1, 0)},
}
ANSI = re.compile(r'\x1b\[[0-9;]*m')
EXIT = re.compile(r'Core 0:\s*(HIT GOOD TRAP|HIT BAD TRAP|ABORT|EXCEEDING CYCLE/INSTR LIMIT) at pc = (0x[0-9a-fA-F]+)')
COUNTS = re.compile(r'Core-0 instrCnt = ([\d,]+), cycleCnt = ([\d,]+)')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_symbols(path):
    symbols = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        fields = line.split()
        if len(fields) == 3:
            symbols[fields[2]] = int(fields[0], 16)
    return symbols


def parse_log(path):
    text = ANSI.sub('', path.read_text(encoding='utf-8', errors='replace'))
    exits, counts = EXIT.findall(text), COUNTS.findall(text)
    diagnostics = re.findall(r'^.*(?:assertion[^\n]*(?:failed|triggered)|Assertion failed|Assertion failure|DIFFTEST FAIL|different at pc).*$', text, re.MULTILINE | re.IGNORECASE)
    require(len(exits) == 1, f'{path.name}: expected one terminal marker, found {len(exits)}')
    require(len(counts) == 1, f'{path.name}: expected one retirement/cycle summary')
    return {
        'marker': exits[0][0], 'reported_pc': exits[0][1].lower(),
        'instr_count': int(counts[0][0].replace(',', '')),
        'cycle_count': int(counts[0][1].replace(',', '')),
        'diagnostics': diagnostics,
    }


def classify(name, observed, rc, symbols):
    pc = int(observed['reported_pc'], 16)
    marker = observed['marker']
    ok = not observed['diagnostics']
    if name in CALIBRATION:
        expected = ('HIT GOOD TRAP', 0) if name == 'exit_good' else ('HIT BAD TRAP', 1)
        ok &= (marker, rc, pc) == (expected[0], expected[1], symbols['_start'] + 4)
        note = 'Explicit custom-exit calibration.'
    elif name == 'load_aba':
        ok &= marker == 'ABORT' and rc == 1 and pc == symbols['load_middle_only_bad']
        note = ('Expected failure signature: the dedicated exit requires error mask 2 and exception mask 0. '
                'Code 2 is printed as ABORT; this is the program self-check, not a NEMU result.')
    elif name.startswith('load_'):
        ok &= marker == 'HIT GOOD TRAP' and rc == 0 and pc == symbols['load_good']
        note = 'Control accepts correct values or permitted load exceptions; GOOD alone does not prove no exception.'
    elif name == 'store_disabled':
        ok &= (marker == 'EXCEEDING CYCLE/INSTR LIMIT' and rc == 0
               and observed['cycle_count'] == 30000 and observed['instr_count'] == 307)
        note = ('Matches the archived bounded non-completion signature. rc=0 is not a successful self-check; '
                'the reported limit PC is not a retirement trace. Root-cause confirmation also uses the SQ/replay evidence.')
    else:
        ok &= marker == 'HIT GOOD TRAP' and rc == 0 and pc == symbols['store_good'] + 4
        note = 'Control completed both byte-readback rounds; the permitted store-exception exit has a different PC.'
    return {'expected_signature': bool(ok), 'interpretation': note}


def verify_group(root, group):
    base = root / group / 'repro'
    manifest = json.loads((base / 'manifest.json').read_text(encoding='utf-8-sig'))
    runs = {r['name']: r for r in manifest['runs']}
    names = CALIBRATION + GROUPS[group]
    observations = []
    for name in names:
        build = manifest['builds'][name]
        paths = {'bin': base / 'bins' / (name + '.bin'),
                 'text': base / 'build' / (name + '.text.bin'),
                 'log': base / 'logs' / (name + '.log')}
        for key, expected in [('bin', build['sha256']), ('text', build['text_sha256']), ('log', runs[name]['log_sha256'])]:
            require(sha(paths[key]) == expected, f'{group}/{name}: {key} SHA256 mismatch')
        symbols = read_symbols(base / 'build' / (name + '.sym'))
        text = paths['text'].read_bytes()
        words = [text[i:i+4] for i in range(0, len(text), 4)]
        require(bytes.fromhex('6b000500') in words, f'{name}: missing a0 custom-exit instruction')
        require(bytes.fromhex('6b000000') not in words, f'{name}: obsolete x0 custom-exit instruction')
        item = {'name': name, 'rc': runs[name]['rc'], **parse_log(paths['log'])}
        item.update(classify(name, item, item['rc'], symbols))
        require(item['expected_signature'], f'{group}/{name}: archived outcome does not match its stated evidence')
        observations.append(item)
    enabled = (base / 'bins' / (group + '_enabled.bin')).read_bytes()
    group_texts = {sha(base / 'build' / (name + '.text.bin')) for name in GROUPS[group]}
    require(len(group_texts) == 1, f'{group}: variant instruction bytes differ')
    for name in GROUPS[group]:
        other = (base / 'bins' / (name + '.bin')).read_bytes()
        require(len(other) == len(enabled), f'{name}: image length differs')
        diffs = {i: (a, b) for i, (a, b) in enumerate(zip(enabled, other)) if a != b}
        require(diffs == EXPECTED_DIFFS[name], f'{name}: unexpected parameter/image differences')
    return base, manifest, observations


def rebuild(base, manifest, names, tool_prefix, destination):
    destination.mkdir()
    bins = {}
    for name in names:
        obj, elf = destination / (name + '.o'), destination / (name + '.elf')
        binary, text = destination / (name + '.bin'), destination / (name + '.text.bin')
        commands = [
            [tool_prefix + 'gcc', '-march=rv64imac_zicsr_zifencei', '-mabi=lp64', '-nostdlib', '-ffreestanding', '-fno-pic', '-c', str(base / 'src' / (name + '.S')), '-o', str(obj)],
            [tool_prefix + 'ld', '--no-relax', '-T', str(base / 'src' / 'link.ld'), '-o', str(elf), str(obj)],
            [tool_prefix + 'objcopy', '-O', 'binary', str(elf), str(binary)],
            [tool_prefix + 'objcopy', '-O', 'binary', '-j', '.text', str(elf), str(text)],
        ]
        with (destination / (name + '.build.log')).open('wb') as log:
            for cmd in commands:
                subprocess.run(cmd, check=True, stdout=log, stderr=subprocess.STDOUT)
        (destination / (name + '.commands.json')).write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8')
        require(sha(binary) == manifest['builds'][name]['sha256'], f'{name}: rebuilt image differs from archived image')
        require(sha(text) == manifest['builds'][name]['text_sha256'], f'{name}: rebuilt .text differs')
        bins[name] = binary
    return bins


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', choices=['load', 'store', 'all'], default='all')
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--verify-only', action='store_true', help='Check archived hashes, byte differences and outcome classification; do not execute a toolchain or simulator.')
    parser.add_argument('--runner', type=Path, help='Absolute path to a compatible resource-limited simulator wrapper; one executable, no shell command string.')
    parser.add_argument('--rebuild', action='store_true', help='Rebuild probe images in a new result directory and require byte-identical outputs before replay.')
    parser.add_argument('--tool-prefix', default='riscv64-unknown-linux-gnu-')
    parser.add_argument('--output-dir', type=Path, help='New directory for results; must not already exist.')
    args = parser.parse_args()
    groups = list(GROUPS) if args.group == 'all' else [args.group]
    root = args.root.resolve()
    require(not (args.verify_only and args.rebuild), '--verify-only cannot be combined with --rebuild')
    verified = {group: verify_group(root, group) for group in groups}
    print(json.dumps({'mode': 'archive_verification', 'groups': {g: v[2] for g, v in verified.items()}}, indent=2))
    if args.verify_only:
        print('ARCHIVE_VERIFIED: no simulator or toolchain was executed.')
        return 0
    require(args.runner is not None, 'Replay requires --runner pointing to a resource-limited wrapper.')
    require(args.runner.is_absolute() and args.runner.is_file(), '--runner must be an existing absolute file path')
    require(os.access(args.runner, os.X_OK), '--runner must be executable')
    if args.output_dir:
        output = args.output_dir.resolve()
        output.mkdir(parents=True, exist_ok=False)
    else:
        parent = root / 'reruns'
        parent.mkdir(exist_ok=True)
        output = Path(tempfile.mkdtemp(prefix='repro-', dir=parent))
    result = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'runner': str(args.runner), 'runner_sha256': sha(args.runner),
              'rebuild': args.rebuild, 'runs': [], 'all_expected_signatures': False}
    result_path = output / 'result.json'
    def save():
        result_path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    save()
    try:
        for group, (base, manifest, _) in verified.items():
            names = CALIBRATION + GROUPS[group]
            directory = output / group
            directory.mkdir()
            bins = rebuild(base, manifest, names, args.tool_prefix, directory / 'build') if args.rebuild else {n: base / 'bins' / (n + '.bin') for n in names}
            for name in names:
                log_path = directory / (name + '.log')
                command = [str(args.runner), '-i', str(bins[name]), '--no-diff', '--max-cycles', '30000']
                item = {'group': group, 'name': name, 'command': command, 'image_sha256': sha(bins[name]),
                        'log': str(log_path), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
                result['runs'].append(item)
                save()
                with log_path.open('wb') as log:
                    proc = subprocess.run(command, cwd=directory, stdout=log, stderr=subprocess.STDOUT)
                item.update(rc=proc.returncode, log_sha256=sha(log_path), **parse_log(log_path))
                item.update(classify(name, item, proc.returncode, read_symbols(base / 'build' / (name + '.sym'))))
                save()
                print(f"{group}/{name}: expected_signature={item['expected_signature']}; {item['marker']}; instr={item['instr_count']}; cycles={item['cycle_count']}", flush=True)
                require(item['expected_signature'], f'{group}/{name}: outcome differs from the archived signature; inspect the new log before drawing a conclusion')
        result['all_expected_signatures'] = True
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
    except Exception as exc:
        result['error'] = str(exc)
        save()
        raise
    print(f'Replay results: {result_path}')
    print('Expected signatures matched. Bounded store non-completion alone is not a proof of permanent deadlock.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        sys.exit(1)
