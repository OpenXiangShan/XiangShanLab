# Host environment and recorded simulator build

Read-only collection time: `2026-10-28T11:40:16.102646+00:00`. This record fills the hardware/software/repository fields of the XiangShan bug report form. It does not represent a new simulator run or a new full RTL build.

| Field | Collected value |
|---|---|
| CPU | Intel(R) Xeon(R) 6960P; 288 logical CPUs |
| Host memory | 2430.02 GB / 2263.14 GiB |
| Source filesystem capacity | 1887.42 GB / 1757.80 GiB |
| Operating system | Ubuntu 26.04 LTS |
| Kernel | 7.0.0-38-generic |
| Current host GCC | 15.2.0 |
| Probe cross compiler | riscv64-unknown-linux-gnu-gcc (g6afcc4f6d) 16.1.0 |
| Current host Java | Temurin OpenJDK 21.0.11 |
| Clang / Verilator / Mill on current PATH | Not found |
| Repository Mill pin | 0.12.3; launcher was not executed |
| XiangShan | fe2288cb09361b65afa26be3f403520c4b496dbf, detached, clean |
| difftest | 3729300ae233816d332d057f170472ebe35147b0, clean |
| Existing emulator SHA256 | 8378454e8d10cf24903ab5778498ccbb00697226ec341dbaec814ec270fe4cb9 |

The existing `build_emu.log` begins with build start `2026-10-16T10:38:14+00:00`, the recorded XiangShan commit, Java `21.0.10-internal` and Verilator `5.048` (conda-forge build 1). These historical versions are distinct from the current shell's PATH. The log prefix and the existing build script are preserved in [HOST_ENVIRONMENT.json](HOST_ENVIRONMENT.json).

The existing build script contains:

```bash
make emu CONFIG=DefaultConfig NUM_CORES=1 EMU_THREADS=16 EMU_TRACE=1 FIRTOOL=/home/haoran/.cache/llvm-firtool/1.62.1/bin/firtool -j32
```

This is a provenance record of the existing script, not a claim that the command was executed during this audit. The audit rebuilt the test programs and used the recorded emulator. The image hash matches the earlier run manifest. The original build script selects its own PATH and JAVA_HOME, which explains why the current login shell need not expose the same tool versions.

Primary probes use `--no-diff`; NEMU and SPIKE commit IDs are therefore not applicable to that reproduction. Supplementary NEMU logs retain their reference binary SHA256, without an invented source commit.

The official environment collector was inspected. Its relevant fields were gathered with read-only commands into this task directory; the upstream script was not run over the existing checkout's report directory. The collected JSON contains no credentials or environment-variable dump.
