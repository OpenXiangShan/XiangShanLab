# LoadUnit: clearing smblockctl.bit9 allows cross-16-byte misaligned loads to retire incorrect data without an exception

This archive contains the complete load issue material from the 2026-10-28 verification and causal audit.

- [Issue body](load/ISSUE.md) and [title](load/TITLE.txt).
- [load/repro/manifest.json](load/repro/manifest.json) records the original probes, binary hashes, commands and log hashes.
- [Evidence index](EVIDENCE_INDEX.md) maps the claims to supplied files.
- [Reproduction instructions](common/REPRO_README.md) describe the new helper and its result interpretation.
- [Official form mapping](common/ISSUE_TEMPLATE_MAPPING.md) explains the seven issue fields and the unchecked submitter attestations. The recorded v2 evidence is not a latest-default-branch reproduction.
- [Collected environment](common/HOST_ENVIRONMENT.md) distinguishes current host metadata from the recorded simulator build.
- [Causal audit](common/audit/AUDIT_REPORT.md) documents the mechanism, exclusions and limits.
- The [related store issue draft](store/ISSUE.md) is included for context only. Its complete reproducer and evidence are in the separate store archive or the combined archive.

From this extracted directory, verify the archived evidence without starting a simulator:

```bash
sha256sum -c SHA256SUMS
python3 common/repro.py --group load --verify-only
```

Reproduce on the original B200 environment using its existing resource-limited runner:

```bash
python3 common/repro.py --group load --runner /home/haoran/kunminghu_v2_arch_audit_handoff_20261020/function_audit_20261021/run_emu_limited.sh
```

The emulator is external to this archive. Version and hashes are recorded in [environment.json](common/environment.json). Raw VCDs remain on B200; exact paths and hashes are in [load wave provenance](load/evidence/wave_provenance.json). Packaging and offline checks are not new simulator runs. No issue has been published.
