# Evidence index

All paths are relative to this package. Files under `repro/` are the calibrated v2 probes. Their logs are original bytes; excerpt files are separately identified, ANSI-stripped, line-numbered views. The per-group `manifest.json` is a projection of [the complete original manifest](common/probe_manifest_original.json), preserving the recorded commands, hashes, return codes and times.

| Claim | Evidence |
|---|---|
| Tested source revision, emulator identity and configuration | [common/environment.json](common/environment.json), [common/build_provenance.json](common/build_provenance.json) |
| Load on/off/on: only the disabled middle phase fails, with no trap | [load_aba.S](load/repro/src/load_aba.S), [load_aba.dis](load/repro/build/load_aba.dis), [load_aba.log](load/repro/logs/load_aba.log), [load manifest](load/repro/manifest.json) |
| A real architectural load writes an incorrect value in the supplementary differential run | [csr0_diff.log](load/evidence/legacy_logs/csr0_diff.log), [numbered log excerpts](load/evidence/legacy_log_excerpts.txt); the load's committed PC is `0x80000140` |
| Hardware misalignment handling is disabled while the final load exception is cleared | [load source excerpts](load/evidence/source_excerpts.txt), [load waveform events](load/evidence/wave_chain.json), [load raw-wave provenance](load/evidence/wave_provenance.json) |
| The result is not inferred from a final printed PC or a timeout-induced REF register value | [causal audit](common/audit/AUDIT_REPORT.md), [probe review](common/audit/audit_probe_review.md), supplementary original logs |
| True success/failure exits are calibrated | `exit_good` and `exit_bad` sources, disassemblies and logs in each `repro/` directory; custom instruction `0x0005006b` reads `a0` |
| Waveform extraction is complete for the required signals | [wave integrity checks](common/audit/audit_wave_integrity.json), each raw-wave provenance file |

For individual issue archives, the sibling issue draft is supplied only as related context; its complete reproducer and evidence are in its own archive. The combined archive includes every path above.

The original raw VCDs are retained on B200 and are not included in the small issue attachments. Waveform events are post-positive-edge snapshots: transaction IDs, sampled `valid && ready` and subsequent state transitions are used together. A sampled writeback data word is not substituted for an architectural commit record.
