.option norvc
.section .text.init
.globl _start

.equ CSR_MSTATUS, 0x300
.equ CSR_MTVEC,   0x305
.equ CSR_MSCRATCH,0x340
.equ CSR_MEPC,    0x341
.equ CSR_MCAUSE,  0x342
.equ CSR_MTVAL,   0x343
.equ CSR_MTINST,  0x34a
.equ CSR_MTVAL2,  0x34b
.equ CSR_PMPCFG0, 0x3a0
.equ CSR_PMPADDR0,0x3b0
.equ CSR_HSTATUS, 0x600
.equ CSR_HTVAL,   0x643
.equ CSR_HTINST,  0x64a
.equ CSR_VSATP,   0x280
.equ CSR_HGATP,   0x680
.equ CSR_MNSTATUS,0x744
.equ MSTATUS_GVA, 38
.equ MSTATUS_MPV, 39
.equ MSTATUS_MDT, 42
.equ HSTATUS_SPVP, 8

.equ VA_LO, 0xffc
.equ VA_HI, 0x1000
.equ MTVAL2_HI, 0x10000000
.equ MTVAL2_LO, 0x200403ff
.equ MTVAL2_MIX, 0x100003ff

_start:
  la sp, __stack_top
  li t0, 1
  slli t0, t0, 3
  csrs CSR_MNSTATUS, t0
  li t0, 1
  slli t0, t0, MSTATUS_MDT
  csrc CSR_MSTATUS, t0
  li t0, -1
  csrw CSR_PMPADDR0, zero
  csrw (CSR_PMPADDR0+1), t0
  li t0, 0x0f00
  csrw CSR_PMPCFG0, t0
  la t0, m_handler
  csrw CSR_MTVEC, t0
  csrw CSR_MSCRATCH, zero
  csrw CSR_MTVAL, zero
  csrw CSR_MTVAL2, zero
  csrw CSR_MTINST, zero
  csrw CSR_HTVAL, zero
  csrw CSR_HTINST, zero
  li t0, 1
  slli t0, t0, 33
  csrs CSR_HSTATUS, t0
  li t0, 1
  slli t0, t0, HSTATUS_SPVP
  csrc CSR_HSTATUS, t0
  call build
  call write_atp
  .insn r 0x73, 0, 0x11, x0, x0, x0
  .insn r 0x73, 0, 0x31, x0, x0, x0
  li t0, 0x11111111
  li t1, 0x80100ffc
  sw t0, 0(t1)
  la t0, aligned_fail
  csrw CSR_MSCRATCH, t0
  li a1, VA_LO
aligned:
  .insn i 0x73, 4, a0, a1, 0x681
  li t0, 0x11111111
  bne a0, t0, bad_aligned
  la t0, after_probe
  csrw CSR_MSCRATCH, t0
  li a1, VA_HI
probe:
  .insn i 0x73, 4, a0, a1, 0x681
  li a0, 8
  .word 0x0000006b
after_probe:
  csrr t0, CSR_MCAUSE
  li t1, 21
  bne t0, t1, probe_bad_cause
  csrr t0, CSR_MTVAL
  li t1, VA_HI
  bne t0, t1, probe_bad_tval
  csrr t0, CSR_MTVAL2
  li t1, MTVAL2_HI
  bne t0, t1, probe_bad_tval2
  la t0, after_ld
  csrw CSR_MSCRATCH, t0
  li a1, VA_LO
hlv:
  .insn i 0x73, 4, a0, a1, 0x6c0
  li a0, 1
  .word 0x0000006b

after_ld:
  csrr t0, CSR_MCAUSE
  li t1, 21
  bne t0, t1, bad_cause
  csrr t0, CSR_MEPC
  la t1, hlv
  bne t0, t1, bad_mepc
  csrr t0, CSR_MTVAL
  li t1, VA_HI
  beq t0, t1, ld_tval_ok
  li t1, VA_LO
  beq t0, t1, bad_tval_lo
  j bad_tval_other
ld_tval_ok:
  csrr t0, CSR_MTVAL2
  li t1, MTVAL2_HI
  beq t0, t1, ld_tval2_ok
  li t1, MTVAL2_LO
  beq t0, t1, bad_tval2_lo
  li t1, MTVAL2_MIX
  beq t0, t1, bad_tval2_mix
  j bad_tval2_other
ld_tval2_ok:
  csrr t0, CSR_MTINST
  bnez t0, bad_inst
  csrr t0, CSR_HTVAL
  bnez t0, bad_htval
  csrr t0, CSR_MSTATUS
  srli t1, t0, MSTATUS_GVA
  andi t1, t1, 1
  beqz t1, bad_gva
  srli t1, t0, MSTATUS_MPV
  andi t1, t1, 1
  bnez t1, bad_mpv
  la t0, after_st
  csrw CSR_MSCRATCH, t0
  li a1, VA_LO
  li a2, 0x55
hsv:
  .insn r 0x73, 4, 0x37, x0, a1, a2
  li a0, 2
  .word 0x0000006b

after_st:
  csrr t0, CSR_MCAUSE
  li t1, 23
  bne t0, t1, bad_scause
  csrr t0, CSR_MEPC
  la t1, hsv
  bne t0, t1, bad_smepc
  csrr t0, CSR_MTVAL
  li t1, VA_HI
  bne t0, t1, bad_stval
  csrr t0, CSR_MTVAL2
  li t1, MTVAL2_HI
  bne t0, t1, bad_stval2
  csrr t0, CSR_MTINST
  bnez t0, bad_sinst
  li a0, 0
  .word 0x0000006b

aligned_fail:
  j bad_cause
probe_bad_cause:
  j bad_cause
probe_bad_tval:
  li a0, 51
  .word 0x0000006b
probe_bad_tval2:
  li a0, 52
  .word 0x0000006b
bad_aligned:
  li a0, 7
  .word 0x0000006b
bad_cause:
  csrr t0, CSR_MCAUSE
  andi t0, t0, 63
  slli t0, t0, 2
  la t1, cause_tab
  add t0, t0, t1
  jr t0
.align 2
cause_tab:
  jal x0, c0
  jal x0, c1
  jal x0, c2
  jal x0, c3
  jal x0, c4
  jal x0, c5
  jal x0, c6
  jal x0, c7
  jal x0, c8
  jal x0, c9
  jal x0, c10
  jal x0, c11
  jal x0, c12
  jal x0, c13
  jal x0, c14
  jal x0, c15
  jal x0, c16
  jal x0, c17
  jal x0, c18
  jal x0, c19
  jal x0, c20
  jal x0, c21
  jal x0, c22
  jal x0, c23
  jal x0, c24
  jal x0, c25
  jal x0, c26
  jal x0, c27
  jal x0, c28
  jal x0, c29
  jal x0, c30
  jal x0, c31
c0: .word 0x0000006b
c1: .word 0x0000006b
c2: .word 0x0000006b
c3: .word 0x0000006b
c4: .word 0x0000006b
c5: .word 0x0000006b
c6: .word 0x0000006b
c7: .word 0x0000006b
c8: .word 0x0000006b
c9: .word 0x0000006b
c10: .word 0x0000006b
c11: .word 0x0000006b
c12: .word 0x0000006b
c13:
  csrr t0, CSR_MTVAL
  li t1, VA_HI
  beq t0, t1, c13_hi
  li t1, VA_LO
  beq t0, t1, c13_lo
  j c13_other
c13_hi: .word 0x0000006b
c13_lo:
  li a0, 1
  .insn i 0x6b, 0, x0, a0, 0
c13_other: .word 0x0000006b
c14: .word 0x0000006b
c15: .word 0x0000006b
c16: .word 0x0000006b
c17: .word 0x0000006b
c18: .word 0x0000006b
c19: .word 0x0000006b
c20: .word 0x0000006b
c21: .word 0x0000006b
c22: .word 0x0000006b
c23: .word 0x0000006b
c24: .word 0x0000006b
c25: .word 0x0000006b
c26: .word 0x0000006b
c27: .word 0x0000006b
c28: .word 0x0000006b
c29: .word 0x0000006b
c30: .word 0x0000006b
c31: .word 0x0000006b
bad_mepc:
  li a0, 12
  .word 0x0000006b
bad_tval_lo:
  li a0, 13
  .word 0x0000006b
bad_tval_other:
  li a0, 14
  .word 0x0000006b
bad_tval2_lo:
  li a0, 15
  .word 0x0000006b
bad_tval2_mix:
  li a0, 16
  .word 0x0000006b
bad_tval2_other:
  li a0, 17
  .word 0x0000006b
bad_inst:
  li a0, 18
  .word 0x0000006b
bad_htval:
  li a0, 19
  .word 0x0000006b
bad_gva:
  li a0, 20
  .word 0x0000006b
bad_mpv:
  li a0, 21
  .word 0x0000006b
bad_scause:
  li a0, 31
  .word 0x0000006b
bad_smepc:
  li a0, 32
  .word 0x0000006b
bad_stval:
  li a0, 33
  .word 0x0000006b
bad_stval2:
  li a0, 34
  .word 0x0000006b
bad_sinst:
  li a0, 35
  .word 0x0000006b

m_handler:
  csrr t0, CSR_MSCRATCH
  beqz t0, die
  csrw CSR_MEPC, t0
  csrw CSR_MSCRATCH, zero
  mret
die:
  csrr a0, CSR_MCAUSE
  addi a0, a0, 90
  .word 0x0000006b

build:
  la t0, s1_l1
  srli t1, t0, 2
  ori t1, t1, 1
  la t0, s1_root
  sd t1, 0(t0)
  la t0, s1_l0
  srli t1, t0, 2
  ori t1, t1, 1
  la t0, s1_l1
  sd t1, 0(t0)
  li t1, 0x80100000
  srli t1, t1, 2
  ori t1, t1, 0xcf
  la t0, s1_l0
  sd t1, 0(t0)
  li t1, 0x40000000
  srli t1, t1, 2
  ori t1, t1, 0xcf
  la t0, s1_l0
  sd t1, 8(t0)
  ret

write_atp:
  la t0, s1_root
  srli t0, t0, 12
  li t1, 8
  slli t1, t1, 60
  or t0, t0, t1
  csrw CSR_VSATP, t0
  la t0, g_root
  li t1, 2048
1:
  sd zero, 0(t0)
  addi t0, t0, 8
  addi t1, t1, -1
  bnez t1, 1b
  li t2, 0x80000000
  srli t1, t2, 2
  ori t1, t1, 0xdf
  la t0, g_root
  sd t1, 16(t0)
  la t0, g_root
  srli t0, t0, 12
  li t1, 8
  slli t1, t1, 60
  or t0, t0, t1
  csrw CSR_HGATP, t0
  ret

.section .data
.align 12
s1_l0: .zero 4096
.align 12
s1_l1: .zero 4096
.align 12
s1_root: .zero 4096
.align 14
g_root: .zero 16384
