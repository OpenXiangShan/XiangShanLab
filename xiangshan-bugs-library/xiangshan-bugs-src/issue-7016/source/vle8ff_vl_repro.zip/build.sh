#!/bin/sh
# Build every variant of the report.  usage: ./build.sh [toolchain prefix, default riscv64-unknown-elf-]
#   OFF    index of the first element that lies on the second page
#   P0/P1  leaf PTE flags of the first / second page (0x00 = invalid, 0x01 = non-leaf pointer,
#          0xd7 = V R W U A D, 0xc7 = V R W A D)
#   HREAD  1: the trap handler also reads vl
P=${1:-riscv64-unknown-elf-}
b() { n=$1; shift
      ${P}gcc -march=rv64gcv -mabi=lp64d -mcmodel=medany -nostdlib -nostartfiles -static "$@" \
          -T link.ld fof_repro.S -o $n.elf && ${P}objcopy -O binary $n.elf $n.bin; }
b u_inv15     -DOFF=15 -DP0=0xd7 -DP1=0x00 -DHREAD=1
b u_inv8      -DOFF=8  -DP0=0xd7 -DP1=0x00 -DHREAD=1
b u_inv1      -DOFF=1  -DP0=0xd7 -DP1=0x00 -DHREAD=1
b u_ptr15     -DOFF=15 -DP0=0xd7 -DP1=0x01 -DHREAD=1
b u_inv15_nr  -DOFF=15 -DP0=0xd7 -DP1=0x00 -DHREAD=0
b ctl_u_ok    -DOFF=15 -DP0=0xd7 -DP1=0xc7 -DHREAD=1
b ctl_inv_inv -DOFF=15 -DP0=0x00 -DP1=0x00 -DHREAD=1
b ctl_u_u     -DOFF=15 -DP0=0xd7 -DP1=0xd7 -DHREAD=1
b ctl_ok_inv  -DOFF=15 -DP0=0xc7 -DP1=0x00 -DHREAD=1
