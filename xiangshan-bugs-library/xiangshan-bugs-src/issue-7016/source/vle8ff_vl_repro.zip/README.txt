vle8ff.v modifies vl when element 0 page-faults and a later element of the same access faults too

fof_repro.S   the workload (M-mode sets up Sv39 and enters S-mode; S-mode runs vle8ff.v; the M-mode
              handler records mcause, mtval, vstart and vl; the results are printed on the UART)
link.ld       linker script (.text at 0x80000000)
build.sh      builds every variant (see the header for OFF, P0, P1 and HREAD)
run.sh        runs every variant on a XiangShan tree, without and with the NEMU difftest
bin/          the prebuilt binaries
logs/<branch>/<variant>.nodiff.log, <variant>.diff.log
              emu output (perf-counter dump removed)

Expected: whenever the trap is taken, V=0 and H=S=0x10.
