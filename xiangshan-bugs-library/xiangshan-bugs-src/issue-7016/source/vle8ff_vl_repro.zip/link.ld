ENTRY(_start)
SECTIONS { . = 0x80000000; .text : { *(.text.init) *(.text*) } . = ALIGN(4096); .data : { *(.data*) } }
