#!/bin/sh
# Run every variant on a XiangShan tree, without and with the NEMU difftest.  usage: ./run.sh <XiangShan dir>
X=$(cd "$1" && pwd); W=$(pwd)
for v in u_inv15 u_inv8 u_inv1 u_ptr15 u_inv15_nr ctl_u_ok ctl_inv_inv ctl_u_u ctl_ok_inv; do
  (cd "$X" && ./build/emu -i "$W/$v.bin" -I 300000 --no-diff) > $v.nodiff.log 2>&1
  (cd "$X" && ./build/emu -i "$W/$v.bin" -I 300000 \
       --diff ./ready-to-run/riscv64-nemu-interpreter-so) > $v.diff.log 2>&1
  printf '%-12s %s| difftest: %s\n' $v "$(grep -a '^[CTVHSX]=' $v.nodiff.log | tr '\n' ' ')" \
      "$(grep -a -o 'vl different.*\|HIT GOOD TRAP\|ABORT' $v.diff.log | head -1)"
done
