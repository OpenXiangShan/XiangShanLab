# XiangShan: vle8ff.v (S-mode, Sv39) whose element 0 page-faults while a later element of the same
# 16-byte access, on the next page, page-faults too.  RVV 1.0, unit-stride fault-only-first: "If
# element 0 raises an exception, vl is not modified, and the trap is taken."
# Printed on the UART (0x40600004):  C=<mcause> T=<mtval> V=<vstart> of the trap,
#                                    H=<vl read in the M-mode handler, ffff..ff if not read>,
#                                    S=<vl read in S-mode after mret>   (V must be 0, H and S 16 = 0x10)
# Build: -DOFF=n  element n is the first on page 1 (base = page1 - n)
#        -DP0=f -DP1=f  leaf PTE flags of page 0 / page 1 (0 = invalid)
#        -DHREAD=0|1    read vl inside the handler
.section .text.init
.globl _start
_start:
    la    t0, mtrap
    csrw  mtvec, t0
    li    t0, (3 << 9)            # mstatus.VS = Dirty
    csrs  mstatus, t0
    li    t0, (1 << 18)           # mstatus.SUM = 0: an S-mode access to a U page faults
    csrc  mstatus, t0
    la    t0, pt_root             # root[2]: 1 GiB identity map of 0x80000000 (RWX A D)
    li    t1, (0x80000000 >> 12) << 10
    ori   t1, t1, 0xcf
    sd    t1, 16(t0)
    la    t1, pt_l1               # root[1] -> l1 (VA 0x40000000)
    srli  t1, t1, 12
    slli  t1, t1, 10
    ori   t1, t1, 1
    sd    t1, 8(t0)
    la    t0, pt_l1               # l1[0] -> l0
    la    t1, pt_l0
    srli  t1, t1, 12
    slli  t1, t1, 10
    ori   t1, t1, 1
    sd    t1, 0(t0)
    la    t0, pt_l0               # l0[0] -> page0 (P0), l0[1] -> page1 (P1)
    la    t1, page0
    srli  t1, t1, 12
    slli  t1, t1, 10
    ori   t1, t1, P0
    sd    t1, 0(t0)
    la    t1, page1
    srli  t1, t1, 12
    slli  t1, t1, 10
    ori   t1, t1, P1
    sd    t1, 8(t0)
    fence
    la    t0, pt_root
    srli  t0, t0, 12
    li    t1, 8
    slli  t1, t1, 60
    or    t0, t0, t1
    csrw  satp, t0
    sfence.vma
    li    t0, -1                  # PMP: S-mode may access everything
    csrw  pmpaddr0, t0
    li    t0, 0x1f
    csrw  pmpcfg0, t0
    li    t0, (3 << 11)           # mret to S-mode
    csrc  mstatus, t0
    li    t0, (1 << 11)
    csrs  mstatus, t0
    la    t0, s_entry
    csrw  mepc, t0
    mret

s_entry:
    li    a0, 32                  # AVL = 2 * VLMAX, so vl = VLMAX = 16
    vsetvli t3, a0, e8, m1, tu, mu
    li    a1, 0x40001000 - OFF    # element 0 on page 0, element OFF on page 1
    li    s2, -1
    li    s4, -1
    li    s5, -1
    li    s6, -1
    vle8ff.v v8, (a1)
    csrr  s3, vl                  # vl after the handler's mret
    ecall                         # report from M-mode

.balign 4
mtrap:
    csrr  t0, mcause
    li    t1, 13
    beq   t0, t1, on_pf
    li    t1, 9
    beq   t0, t1, report
    li    a1, 'X'                 # unexpected cause: print X<cause>
    mv    a0, t0
    j     print_one
on_pf:
    csrr  s4, mcause
    csrr  s5, mtval
    csrr  s6, vstart
#if HREAD
    csrr  s2, vl
#endif
    csrr  t0, mepc
    addi  t0, t0, 4
    csrw  mepc, t0
    mret
report:
    li    a1, 'C'
    mv    a0, s4
    jal   ra, putkv
    li    a1, 'T'
    mv    a0, s5
    jal   ra, putkv
    li    a1, 'V'
    mv    a0, s6
    jal   ra, putkv
    li    a1, 'H'
    mv    a0, s2
    jal   ra, putkv
    li    a1, 'S'
    mv    a0, s3
print_one:
    jal   ra, putkv
    .word 0x0000006b
1:  j     1b

putkv:                            # print "<a1>=<a0 in hex>\n"
    li    t3, 0x40600000
    sb    a1, 4(t3)
    li    t5, '='
    sb    t5, 4(t3)
    li    t4, 60
2:  srl   t5, a0, t4
    andi  t5, t5, 0xf
    li    t6, 10
    blt   t5, t6, 3f
    addi  t5, t5, 'a' - 10
    j     4f
3:  addi  t5, t5, '0'
4:  sb    t5, 4(t3)
    addi  t4, t4, -4
    bgez  t4, 2b
    li    t5, 10
    sb    t5, 4(t3)
    ret

.section .data
.balign 4096
pt_root: .zero 4096
pt_l1:   .zero 4096
pt_l0:   .zero 4096
page0:   .zero 4096
page1:   .zero 4096
