#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

SECRET_BIT="${SECRET_BIT:-1}"
PREFIX="${PREFIX:-ras_enable_secret${SECRET_BIT}}"
CYCLES="${CYCLES:-18000}"
WAVE_BEGIN="${WAVE_BEGIN:-8000}"
WAVE_END="${WAVE_END:-15000}"
DELAY_ITERS="${DELAY_ITERS:-768}"
TRAIN_ITERS="${TRAIN_ITERS:-128}"
KEEP_VCD="${KEEP_VCD:-0}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
VCD="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
FST="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.fst"
RUN_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.run.log"
MONITOR_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
MONITOR_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

echo "[build] SECRET_BIT=$SECRET_BIT -> $ELF"
"$RISCV_GCC" \
  -nostdlib -nostartfiles \
  -march=rv64gc_zicsr -mabi=lp64 \
  -DSECRET_BIT="$SECRET_BIT" \
  -DDELAY_ITERS="$DELAY_ITERS" \
  -DTRAIN_ITERS="$TRAIN_ITERS" \
  -T linker.ld \
  -Wl,--no-relax \
  -o "$ELF" \
  ras_enable_secret_fetch.S
"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -d -t "$ELF" > "$OBJDUMP"

echo "[run] $EMU"
"$EMU" \
  -C "$CYCLES" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  -i "$BIN" \
  --no-diff \
  --dump-wave-full \
  --wave-path="$VCD" \
  --force-dump-result \
  > "$RUN_LOG" 2>&1

echo "[convert] $VCD -> $FST"
vcd2fst -p "$VCD" "$FST"
if [[ "$KEEP_VCD" != "1" ]]; then
  rm -f "$VCD"
fi

echo "[parse] $FST"
set +e
python3 ./monitor_ras_enable_secret_fetch.py \
  "$FST" "$OBJDUMP" "$MONITOR_JSON" \
  --secret-bit "$SECRET_BIT" \
  > "$MONITOR_LOG"
parse_status=$?
set -e

cat "$MONITOR_LOG"
exit "$parse_status"
