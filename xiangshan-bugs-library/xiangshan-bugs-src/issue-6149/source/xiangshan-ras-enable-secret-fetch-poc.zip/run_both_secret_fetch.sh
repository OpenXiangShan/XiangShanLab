#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

SECRET_BIT=0 PREFIX=ras_enable_secret0 ./run_secret_fetch.sh
SECRET_BIT=1 PREFIX=ras_enable_secret1 ./run_secret_fetch.sh

python3 ./summarize_pair.py
