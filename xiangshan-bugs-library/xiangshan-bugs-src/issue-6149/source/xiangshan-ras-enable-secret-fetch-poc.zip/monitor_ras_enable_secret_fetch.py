#!/usr/bin/env python3
import argparse
import json
import re
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path


RAS_POP = 1


def clean_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_int(bits, base=2):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, base)


def hx(value):
    return None if value is None else hex(value)


@contextmanager
def wave_lines(path):
    if path.suffix == ".fst":
        proc = subprocess.Popen(
            ["fst2vcd", str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
        )
        try:
            yield proc.stdout
        finally:
            if proc.stdout is not None:
                proc.stdout.close()
            stderr = proc.stderr.read() if proc.stderr is not None else ""
            rc = proc.wait()
            if rc not in (0, -13):
                raise RuntimeError(f"fst2vcd failed with code {rc}: {stderr}")
    else:
        with path.open("r", errors="replace") as f:
            yield f


def read_symbols(objdump_path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\w+\s+.*\s([A-Za-z_][A-Za-z0-9_]*)$")
    with objdump_path.open("r", errors="replace") as f:
        for raw in f:
            match = sym_re.match(raw.strip())
            if match:
                addr, name = match.groups()
                symbols[name] = int(addr, 16)
    required = [
        "_start",
        "disable_ras",
        "after_secret_load",
        "poison0_site",
        "poison1_site",
        "poison_common",
        "train_ret_loop",
        "train_return",
        "attack_disable_ras",
        "ret_probe",
        "ret_trigger",
        "safe_return",
        "gadget0",
        "gadget1",
    ]
    missing = [name for name in required if name not in symbols]
    if missing:
        raise RuntimeError(f"missing objdump symbols: {missing}")
    return symbols


def read_header(path):
    scope = []
    vars_seen = []
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    with wave_lines(path) as lines:
        for raw in lines:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
            elif line.startswith("$upscope"):
                if scope:
                    scope.pop()
            elif line.startswith("$var "):
                match = var_re.match(line)
                if not match:
                    continue
                width, code, name = match.groups()
                name = clean_name(name)
                vars_seen.append({
                    "width": int(width),
                    "code": code,
                    "name": name,
                    "full": ".".join(scope + [name]),
                })
    return vars_seen


def choose_by_suffix(vars_seen, suffix):
    matches = [
        var for var in vars_seen
        if var["full"].endswith(suffix)
        or (var["name"] == suffix.split(".")[-1] and suffix in var["full"])
    ]
    if not matches:
        return None
    return sorted(matches, key=lambda var: (len(var["full"]), var["full"]))[0]


def choose_signals(vars_seen):
    wanted = {
        "csr_ras_enable": "_sbpctl_regOut_RAS_ENABLE",
        "s1_fire": "frontend.inner_bpu.s1_fire",
        "s1_prediction_taken": "frontend.inner_bpu.s1_prediction_taken",
        "s1_prediction_action": "frontend.inner_bpu.s1_prediction_attribute_rasAction",
        "s1_prediction_target": "frontend.inner_bpu.s1_prediction_target_addr",
        "uras_can": "frontend.inner_bpu._uras_io_specOut_isCanUse",
        "uras_target": "frontend.inner_bpu._uras_io_specOut_retTarget_addr",
        "s3_valid": "frontend.inner_bpu.s3_valid",
        "s3_taken": "frontend.inner_bpu.s3_taken",
        "s3_use_ras": "frontend.inner_bpu.s3_useRas",
        "s3_prediction_target": "frontend.inner_bpu.s3_prediction_target_addr",
        "ras_top": "frontend.inner_bpu._ras_io_topRetAddr_addr",
        "ftq_wen": "io_frontend_fromFtq_wen",
        "ftq_start": "io_frontend_fromFtq_startPc_addr",
        "ftq_idx": "io_frontend_fromFtq_ftqIdx",
    }
    selected = {}
    missing = {}
    for key, suffix in wanted.items():
        sig = choose_by_suffix(vars_seen, suffix)
        if sig is None:
            missing[key] = suffix
        else:
            selected[key] = sig
    return selected, missing


def parse_wave(path, selected, symbols):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)
    values = {key: None for key in selected}
    events = []
    current_time = None
    in_body = False
    first_disabled_time = None
    last_disabled_transition_time = None
    previous_csr_ras_enable = None
    disabled_samples = 0

    gadget0 = symbols["gadget0"] >> 1
    gadget1 = symbols["gadget1"] >> 1
    gadgets = {
        gadget0: "gadget0",
        gadget1: "gadget1",
    }
    interesting_targets = {
        symbols[name] >> 1: name
        for name in (
            "after_secret_load",
            "poison0_site",
            "poison1_site",
            "poison_common",
            "ret_probe",
            "ret_trigger",
            "safe_return",
            "attack_disable_ras",
            "gadget0",
            "gadget1",
        )
    }

    def truthy(value):
        return value not in (None, 0)

    def event_target(value):
        return gadgets.get(value)

    def symbol_target(value):
        return interesting_targets.get(value)

    def emit_current():
        nonlocal first_disabled_time, last_disabled_transition_time, previous_csr_ras_enable, disabled_samples
        if current_time is None:
            return

        csr_value = values.get("csr_ras_enable")
        csr_disabled = csr_value == 0
        if previous_csr_ras_enable == 1 and csr_value == 0:
            last_disabled_transition_time = current_time
        if csr_value in (0, 1):
            previous_csr_ras_enable = csr_value
        if csr_disabled:
            disabled_samples += 1
            if first_disabled_time is None:
                first_disabled_time = current_time

        s1_target = values.get("s1_prediction_target")
        uras_target = values.get("uras_target")
        s1_uras_selected = (
            csr_disabled
            and truthy(values.get("s1_fire"))
            and truthy(values.get("s1_prediction_taken"))
            and values.get("s1_prediction_action") == RAS_POP
            and truthy(values.get("uras_can"))
            and s1_target is not None
            and s1_target == uras_target
            and event_target(s1_target) is not None
        )
        if s1_uras_selected:
            events.append({
                "type": "s1_disabled_uras_prediction",
                "time": current_time,
                "target": s1_target,
                "target_name": event_target(s1_target),
                "uras_target": uras_target,
                "csr_ras_enable": values.get("csr_ras_enable"),
                "s1_action": values.get("s1_prediction_action"),
            })
        elif (
            csr_disabled
            and truthy(values.get("s1_fire"))
            and truthy(values.get("s1_prediction_taken"))
            and values.get("s1_prediction_action") == RAS_POP
        ):
            events.append({
                "type": "s1_disabled_return_prediction_any",
                "time": current_time,
                "target": s1_target,
                "target_name": event_target(s1_target),
                "uras_can": values.get("uras_can"),
                "uras_target": uras_target,
                "csr_ras_enable": values.get("csr_ras_enable"),
            })

        s3_target = values.get("s3_prediction_target")
        ras_top = values.get("ras_top")
        s3_ras_selected = (
            csr_disabled
            and truthy(values.get("s3_valid"))
            and truthy(values.get("s3_taken"))
            and truthy(values.get("s3_use_ras"))
            and s3_target is not None
            and s3_target == ras_top
            and event_target(s3_target) is not None
        )
        if s3_ras_selected:
            events.append({
                "type": "s3_disabled_ras_prediction",
                "time": current_time,
                "target": s3_target,
                "target_name": event_target(s3_target),
                "ras_top": ras_top,
                "csr_ras_enable": values.get("csr_ras_enable"),
            })
        elif (
            csr_disabled
            and truthy(values.get("s3_valid"))
            and truthy(values.get("s3_taken"))
            and truthy(values.get("s3_use_ras"))
        ):
            events.append({
                "type": "s3_disabled_return_prediction_any",
                "time": current_time,
                "target": s3_target,
                "target_name": event_target(s3_target),
                "ras_top": ras_top,
                "csr_ras_enable": values.get("csr_ras_enable"),
            })

        ftq_start = values.get("ftq_start")
        if values.get("ftq_wen") == 1 and event_target(ftq_start) is not None:
            events.append({
                "type": "ftq_fetch_gadget",
                "time": current_time,
                "start": ftq_start,
                "target_name": event_target(ftq_start),
                "ftq_idx": values.get("ftq_idx"),
                "csr_ras_enable": values.get("csr_ras_enable"),
            })
        if values.get("ftq_wen") == 1 and symbol_target(ftq_start) is not None:
            events.append({
                "type": "ftq_fetch_symbol",
                "time": current_time,
                "start": ftq_start,
                "target_name": symbol_target(ftq_start),
                "ftq_idx": values.get("ftq_idx"),
                "csr_ras_enable": values.get("csr_ras_enable"),
            })

    with wave_lines(path) as lines:
        for raw in lines:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            first = line[0]
            if first == "#":
                emit_current()
                current_time = int(line[1:])
            elif first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bBhH":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_int(parts[0][1:], 16 if first in "hH" else 2)
                        for key in keys:
                            values[key] = value
        emit_current()

    return events, {
        "first_disabled_time": first_disabled_time,
        "last_disabled_transition_time": last_disabled_transition_time,
        "disabled_samples": disabled_samples,
    }


def event_out(event):
    out = dict(event)
    for key in ("target", "uras_target", "ras_top", "start"):
        if key in out:
            out[key] = hx(out[key])
    return out


def summarize(events, symbols, secret_bit, wave_stats):
    expected = "gadget1" if secret_bit else "gadget0"
    opposite = "gadget0" if secret_bit else "gadget1"

    predictions = [
        e for e in events
        if e["type"] in {"s1_disabled_uras_prediction", "s3_disabled_ras_prediction"}
    ]
    attack_phase_fetches = [
        e for e in events
        if e["type"] == "ftq_fetch_symbol" and e["target_name"] == "ret_probe"
    ]
    attack_phase_start = wave_stats.get("last_disabled_transition_time")
    if attack_phase_start is None and attack_phase_fetches:
        attack_phase_start = attack_phase_fetches[0]["time"]

    def in_attack_phase(event):
        return attack_phase_start is None or event["time"] >= attack_phase_start

    expected_predictions = [
        e for e in predictions
        if e["target_name"] == expected and in_attack_phase(e)
    ]
    raw_opposite_predictions = [
        e for e in predictions
        if e["target_name"] == opposite and in_attack_phase(e)
    ]
    first_expected_pred_time = expected_predictions[0]["time"] if expected_predictions else None
    opposite_predictions = [
        e for e in raw_opposite_predictions
        if first_expected_pred_time is None or e["time"] >= first_expected_pred_time
    ]

    ftq_fetches = [e for e in events if e["type"] == "ftq_fetch_gadget"]
    expected_fetches = [
        e for e in ftq_fetches
        if e["target_name"] == expected and in_attack_phase(e)
    ]
    opposite_fetches = [
        e for e in ftq_fetches
        if e["target_name"] == opposite and in_attack_phase(e)
    ]
    post_expected_fetches = [
        e for e in expected_fetches
        if first_expected_pred_time is not None and e["time"] >= first_expected_pred_time
    ]
    post_opposite_fetches = [
        e for e in opposite_fetches
        if first_expected_pred_time is not None and e["time"] >= first_expected_pred_time
    ]

    return {
        "predicate": {
            "secret_bit": secret_bit,
            "expected_gadget": expected,
            "opposite_gadget": opposite,
            "csr_ras_disabled_seen": wave_stats["first_disabled_time"] is not None,
            "disabled_samples": wave_stats["disabled_samples"],
            "attack_phase_start": attack_phase_start,
            "last_disabled_transition_time": wave_stats.get("last_disabled_transition_time"),
            "disabled_prediction_to_expected_gadget": bool(expected_predictions),
            "disabled_prediction_to_opposite_gadget": bool(opposite_predictions),
            "ftq_fetch_expected_after_prediction": bool(post_expected_fetches),
            "ftq_fetch_opposite_after_prediction": bool(post_opposite_fetches),
            "success": bool(
                wave_stats["first_disabled_time"] is not None
                and expected_predictions
                and post_expected_fetches
            ),
        },
        "events": {
            "first_disabled_time": wave_stats["first_disabled_time"],
            "last_disabled_transition_time": wave_stats.get("last_disabled_transition_time"),
            "attack_phase_fetches": [event_out(e) for e in attack_phase_fetches[:20]],
            "expected_predictions": [event_out(e) for e in expected_predictions[:20]],
            "opposite_predictions": [event_out(e) for e in opposite_predictions[:20]],
            "opposite_predictions_before_expected": [
                event_out(e) for e in raw_opposite_predictions
                if first_expected_pred_time is not None and e["time"] < first_expected_pred_time
            ][:20],
            "expected_fetches": [event_out(e) for e in expected_fetches[:20]],
            "post_expected_fetches": [event_out(e) for e in post_expected_fetches[:20]],
            "opposite_fetches": [event_out(e) for e in opposite_fetches[:20]],
            "post_opposite_fetches": [event_out(e) for e in post_opposite_fetches[:20]],
            "all_disabled_predictions": [event_out(e) for e in predictions[:40]],
            "all_disabled_return_predictions": [
                event_out(e) for e in events
                if e["type"] in {
                    "s1_disabled_return_prediction_any",
                    "s3_disabled_return_prediction_any",
                    "s1_disabled_uras_prediction",
                    "s3_disabled_ras_prediction",
                }
            ][:80],
            "all_gadget_fetches": [event_out(e) for e in ftq_fetches[:40]],
            "all_symbol_fetches": [
                event_out(e) for e in events
                if e["type"] == "ftq_fetch_symbol"
            ][:80],
        },
        "symbols": {
            name: hx(symbols[name])
            for name in [
                "_start",
                "disable_ras",
                "after_secret_load",
                "poison0_site",
                "poison1_site",
                "poison_common",
                "train_ret_loop",
                "train_return",
                "attack_disable_ras",
                "ret_probe",
                "ret_trigger",
                "safe_return",
                "gadget0",
                "gadget1",
            ]
        },
        "pruned_targets": {
            "gadget0": hx(symbols["gadget0"] >> 1),
            "gadget1": hx(symbols["gadget1"] >> 1),
        },
    }


def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument("wave", type=Path)
    parser.add_argument("objdump", type=Path)
    parser.add_argument("out_json", type=Path)
    parser.add_argument("--secret-bit", type=int, choices=[0, 1], required=True)
    args = parser.parse_args(argv[1:])

    symbols = read_symbols(args.objdump)
    selected, missing = choose_signals(read_header(args.wave))
    events, wave_stats = parse_wave(args.wave, selected, symbols)
    summary = summarize(events, symbols, args.secret_bit, wave_stats)
    result = {
        "wave": str(args.wave),
        "objdump": str(args.objdump),
        "selected_signal_count": len(selected),
        "missing_signal_count": len(missing),
        "missing_signals": missing,
        **summary,
    }
    args.out_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["predicate"], indent=2, sort_keys=True))
    return 0 if result["predicate"]["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
