#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def load(path):
    with path.open() as f:
        return json.load(f)


def first_event(result, section):
    events = result["events"].get(section, [])
    return events[0] if events else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--secret0", type=Path, default=None)
    parser.add_argument("--secret1", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=Path("pair_summary.json"))
    args = parser.parse_args()

    secret0 = args.secret0 or sorted(Path(".").glob("ras_enable_secret0_*.monitor.json"))[-1]
    secret1 = args.secret1 or sorted(Path(".").glob("ras_enable_secret1_*.monitor.json"))[-1]

    res0 = load(secret0)
    res1 = load(secret1)
    pred0 = res0["predicate"]
    pred1 = res1["predicate"]
    exp0 = first_event(res0, "expected_predictions")
    exp1 = first_event(res1, "expected_predictions")
    fetch0 = first_event(res0, "post_expected_fetches")
    fetch1 = first_event(res1, "post_expected_fetches")

    summary = {
        "secret0_json": str(secret0),
        "secret1_json": str(secret1),
        "secret0_success": pred0["success"],
        "secret1_success": pred1["success"],
        "secret0_expected_gadget": pred0["expected_gadget"],
        "secret1_expected_gadget": pred1["expected_gadget"],
        "secret0_first_expected_prediction": exp0,
        "secret1_first_expected_prediction": exp1,
        "secret0_first_post_prediction_fetch": fetch0,
        "secret1_first_post_prediction_fetch": fetch1,
        "both_runs_ras_disabled": pred0["csr_ras_disabled_seen"] and pred1["csr_ras_disabled_seen"],
        "both_runs_success": pred0["success"] and pred1["success"],
        "prediction_targets_differ": bool(exp0 and exp1 and exp0.get("target_name") != exp1.get("target_name")),
        "post_prediction_fetch_targets_differ": bool(
            fetch0 and fetch1 and fetch0.get("target_name") != fetch1.get("target_name")
        ),
    }
    summary["secret_dependent_wrong_path_fetch"] = (
        summary["both_runs_ras_disabled"]
        and summary["both_runs_success"]
        and summary["prediction_targets_differ"]
        and summary["post_prediction_fetch_targets_differ"]
        and summary["secret0_expected_gadget"] == "gadget0"
        and summary["secret1_expected_gadget"] == "gadget1"
    )

    args.out.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if summary["secret_dependent_wrong_path_fetch"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
