# Cross-Page Instruction Page Fault Reports Wrong mepc and mtval

## Bug Description

The supplied reproducer enters S-mode at the end of a mapped Sv39 page so that a 32-bit instruction crosses into an unmapped next page. The correct first trap is an instruction page fault with `mepc` at the instruction start and `mtval` at the inaccessible second-page portion. The tested DUT reports `mepc` advanced to the second page and `mtval` advanced by two bytes.

Affected version: `v3.2.2-alpha-1931-g96c3f568f` (`96c3f568f943a096ffd3d712dc6f462ac4b1ba33`).

The important point is not the exception class: both sides report an instruction page fault. The bug is that the architectural recovery metadata points at the wrong part of the instruction stream.

## RISC-V Specification Requirement

RISC-V Privileged Architecture, Section 3.1.14 Machine Exception Program Counter (mepc) and Section 3.1.16 Machine Trap Value (mtval). For variable-length instructions, mepc identifies the beginning of the instruction, while mtval may identify the portion of the instruction that faulted.

For the cross-page instruction fault, mcause should be instruction page fault, mepc should remain 0x40000ffe, and mtval should identify the inaccessible portion at 0x40001000.

![specification evidence 1](./images/spec_01.png)

![specification evidence 2](./images/spec_02.png)

![specification evidence 3](./images/spec_03.png)

![specification evidence 4](./images/spec_04.png)


## Steps to Reproduce

1. Use the supplied `poc/program.elf` artifact in the XiangShan replay environment.
2. Run the built image with XiangShan as DUT using the same replay/no-diff mode represented by `logs/`.
3. Compare the architecture-visible trap or CSR state around the highlighted instruction sequence.

Minimal source excerpt:

```asm
.equ CROSS_VA, 0x0000000040000ffe

li   t0, CROSS_VA
csrw mepc, t0
mret

/* 32-bit instruction starts at 0x40000ffe and crosses into the next page. */
cross_page_insn:
  .4byte 0x00000013
```

## Expected Result

mcause = 12, mepc = 0x40000ffe, and mtval = 0x40001000.

## Actual Result

The replay comparison reports:

```text
mepc different  right = 0x0000000040000ffe, wrong = 0x0000000040001000
mtval different right = 0x0000000040001000, wrong = 0x0000000040001002
```

Here `right` is the reference model and `wrong` is the XiangShan DUT. The DUT has moved both recovery fields forward into the second page.

Trace context before the mismatch:

![Trace context before mismatch](images/trace_context.png)

Difftest trace screenshot:

![Difftest trace screenshot](images/difftest_trace.png)

## Evidence Interpretation

The log shows `mret` entering `0x40000ffe`, followed by an instruction page fault on bytes that cross into `0x40001000`. The reference keeps `mepc` at the beginning of the instruction and uses `mtval` for the faulting portion. XiangShan instead reports `mepc = 0x40001000` and `mtval = 0x40001002`, which would mislead any handler that uses `mepc` to resume after mapping the missing page.

This issue is stably reproducible on v3; it was not reproducible on v2 after testing.

The fix should report cross-page instruction faults with `mepc` set to the original instruction start and `mtval` set to the actual faulting portion, without letting internal second-page fetch bookkeeping become the architectural recovery PC.
