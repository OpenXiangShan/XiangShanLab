#include <klib.h>

// =============================================================================
// Candidate 0398: semantics of an explicit write to minstret.
//
//   norm:mcycle_minstret_wr  "Any CSR write takes effect after the writing
//   instruction has otherwise completed."  => after `csrw minstret, X` the
//   counter is X; the next `csrr minstret` must return X (spike: the write
//   "takes precedence over the increment", NEMU/XS ref: see #5129 comment).
//
// XiangShan (MachineLevel.scala Minstret): when(w.wen){reg := wdata}
// .elsewhen(robCommit.instNum.valid){reg := reg + instNum}. The CSR write is
// applied in the execute stage; the writing instruction's own retirement is
// added on top of X afterwards (X+1). We also characterise the lag between
// retirement and the value visible to csrr.
// =============================================================================

#define S_(x) #x
#define S(x) S_(x)
#define CSRR(csr) ({ unsigned long __v; asm volatile("csrr %0, " S(csr) : "=r"(__v) : : "memory"); __v; })
#define CSRS(csr, v) asm volatile("csrs " S(csr) ", %0" : : "r"(v) : "memory")
#define CSRC(csr, v) asm volatile("csrc " S(csr) ", %0" : : "r"(v) : "memory")
#define CSR_MCOUNTINHIBIT 0x320

#define REP4(x) x x x x
#define REP16(x) REP4(x) REP4(x) REP4(x) REP4(x)
#define REP64(x) REP16(x) REP16(x) REP16(x) REP16(x)

#define ADDI "addi t3, t3, 1\n\t"
#define NOP4 "nop\n\t"          // 4-byte nop: .option norvc below

static int bad = 0;

#define CASE(desc, expect_delta, INSNS)                                             \
    do {                                                                            \
        unsigned long x = 0x100000, r;                                              \
        asm volatile(".option push\n\t.option norvc\n\t"                            \
                     "csrw minstret, %1\n\t" INSNS "csrr %0, minstret\n\t"           \
                     ".option pop\n\t"                                              \
                     : "=r"(r) : "r"(x) : "memory", "t3");                          \
        long d = (long)(r - x);                                                     \
        printf("%-44s -> X%+ld   (spec: X%+d)%s\n", desc, d, expect_delta,          \
               d == expect_delta ? "" : "   <-- MISMATCH");                         \
        if (d != expect_delta) bad = 1;                                             \
    } while (0)

int main(void)
{
    printf("=== minstret explicit-write semantics (candidate 0398) ===\n");
    printf("mcountinhibit=%lx\n", CSRR(CSR_MCOUNTINHIBIT));

    // 1. the reported case
    CASE("csrw minstret,X ; csrr",                       0, "");
    CASE("csrw minstret,X ; csrr  (again)",              0, "");

    // 2. how many retired instructions between write and read are visible?
    CASE("csrw ; 1x addi ; csrr",                        1, ADDI);
    CASE("csrw ; 2x addi ; csrr",                        2, ADDI ADDI);
    CASE("csrw ; 4x addi ; csrr",                        4, REP4(ADDI));
    CASE("csrw ; 16x addi ; csrr",                      16, REP16(ADDI));
    CASE("csrw ; 64x addi ; csrr",                      64, REP64(ADDI));
    CASE("csrw ; 4x nop(4B) ; csrr",                     4, REP4(NOP4));
    CASE("csrw ; 64x nop(4B) ; csrr",                   64, REP64(NOP4));
    CASE("csrw ; csrr ; csrr   (2nd read)",              1, "csrr t3, minstret\n\t");
    CASE("csrw ; fence ; csrr",                          1, "fence\n\t");
    CASE("csrw ; csrw mscratch ; csrr",                  1, "csrw mscratch, t3\n\t");

    // 3. no write involved: two reads separated by N instructions
    {
        unsigned long a, b;
        asm volatile(".option push\n\t.option norvc\n\t"
                     "csrr %0, minstret\n\t" "csrr %1, minstret\n\t" ".option pop\n\t"
                     : "=r"(a), "=r"(b) : : "memory");
        printf("csrr ; csrr                                  -> delta %ld   (spec: 1)%s\n", (long)(b - a), (b - a) == 1 ? "" : "   <-- MISMATCH");
        asm volatile(".option push\n\t.option norvc\n\t"
                     "csrr %0, minstret\n\t" REP16(ADDI) "csrr %1, minstret\n\t" ".option pop\n\t"
                     : "=r"(a), "=r"(b) : : "memory", "t3");
        printf("csrr ; 16x addi ; csrr                       -> delta %ld   (spec: 17)%s\n", (long)(b - a), (b - a) == 17 ? "" : "   <-- MISMATCH");
        asm volatile(".option push\n\t.option norvc\n\t"
                     "csrr %0, minstret\n\t" REP64(ADDI) "csrr %1, minstret\n\t" ".option pop\n\t"
                     : "=r"(a), "=r"(b) : : "memory", "t3");
        printf("csrr ; 64x addi ; csrr                       -> delta %ld   (spec: 65)%s\n", (long)(b - a), (b - a) == 65 ? "" : "   <-- MISMATCH");
    }

    // 4. with IR inhibited the write is exact
    CSRS(CSR_MCOUNTINHIBIT, 4);
    CASE("IR=1: csrw minstret,X ; csrr",                 0, "");
    CASE("IR=1: csrw ; 4x addi ; csrr",                  0, REP4(ADDI));
    CSRC(CSR_MCOUNTINHIBIT, 4);

    printf(bad ? "=== DEVIATION: minstret write/read does not follow norm:mcycle_minstret_wr ===\n"
               : "=== PASS ===\n");
    return bad;
}
