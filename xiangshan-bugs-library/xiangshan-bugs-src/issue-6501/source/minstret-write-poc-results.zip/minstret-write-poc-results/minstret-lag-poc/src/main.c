#include <klib.h>

// minstret short-window accuracy: where does the +168 come from, and how far
// behind retirement is the value seen by csrr?

#define REP4(x) x x x x
#define REP16(x) REP4(x) REP4(x) REP4(x) REP4(x)
#define REP64(x) REP16(x) REP16(x) REP16(x) REP16(x)
#define REP256(x) REP64(x) REP64(x) REP64(x) REP64(x)
#define ADDI  "addi t3, t3, 1\n\t"
#define F1 "fence\n\t"
#define F3 "fence\n\tfence\n\tfence\n\t"

#define MEASURE(desc, expect, INSNS)                                                 \
    do {                                                                             \
        unsigned long a, b;                                                          \
        asm volatile(".option push\n\t.option norvc\n\t"                             \
                     "csrr %0, minstret\n\t" INSNS "csrr %1, minstret\n\t"           \
                     ".option pop\n\t"                                               \
                     : "=&r"(a), "=&r"(b) : : "memory", "t3", "t4");                 \
        long d = (long)(b - a);                                                      \
        printf("%-44s -> %-6ld (exact %-6ld) %+ld\n", desc, d, (long)(expect), d - (long)(expect)); \
    } while (0)

int main(void)
{
    printf("=== minstret short-window accuracy ===\n");
    MEASURE("A1 csrr ; 3 fence ; csrr",                 4,   F3);
    MEASURE("A2 csrr ; 3 fence ; csrr  (again)",        4,   F3);
    MEASURE("A3 csrr ; 3 fence ; csrr  (again)",        4,   F3);
    MEASURE("B1 csrr ; 1 fence ; csrr",                 2,   F1);
    MEASURE("B2 csrr ; 1 fence ; csrr  (again)",        2,   F1);
    MEASURE("C  csrr ; 3 fence ; 3 fence ; csrr",       7,   F3 F3);
    MEASURE("D1 csrr ; 256 addi ; csrr",                257, REP256(ADDI));
    MEASURE("D2 csrr ; 1024 addi ; csrr",               1025, REP256(ADDI) REP256(ADDI) REP256(ADDI) REP256(ADDI));
    MEASURE("E  csrr ; 3 fence ; 256 addi ; 3 fence ; csrr", 263, F3 REP256(ADDI) F3);
    MEASURE("F  csrr ; 256 addi ; 3 fence ; csrr",      260, REP256(ADDI) F3);
    // two measurements back to back with NO printf in between
    {
        unsigned long a, b, c, d;
        asm volatile(".option push\n\t.option norvc\n\t"
                     "csrr %0, minstret\n\t" F3 "csrr %1, minstret\n\t"
                     "csrr %2, minstret\n\t" F3 "csrr %3, minstret\n\t"
                     ".option pop\n\t"
                     : "=&r"(a), "=&r"(b), "=&r"(c), "=&r"(d) : : "memory");
        printf("G  [csrr;3 fence;csrr] x2, no printf between  -> %ld then %ld (exact 4, 4)\n", (long)(b - a), (long)(d - c));
    }
    return 0;
}
