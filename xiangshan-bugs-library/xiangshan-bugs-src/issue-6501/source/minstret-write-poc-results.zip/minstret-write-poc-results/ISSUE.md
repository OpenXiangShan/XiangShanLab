# Title

[Bug] minstret: an explicit CSR write is bumped by the writing instruction's own retirement (`csrw minstret, X ; csrr` reads X+1); reads also lag retirement by ~3 cycles

# Before start

- [x] I have read the RISC-V ISA Manual and XiangShan Documents, and I believe this is a XiangShan RTL issue.
- [x] I have searched previous issues and PRs and did not find anything relevant.
- [x] I have reproduced the issue using the latest commit on the default branch.
- [x] If this report was generated with AI assistance, I have verified the correctness of its content.

# Branch

kunminghu-v2 (same logic on kunminghu-v3)

# Describe the bug

```scala
// MachineLevel.scala, minstret (2e148b4 L340-347; v2 HEAD 5d393413 L353-360; v3 HEAD 14af5521 L366-375)
when(w.wen) {
  reg := w.wdata
}.elsewhen(!this.mcountinhibit.IR && robCommit.instNum.valid) {
  reg := reg.ALL.asUInt + robCommit.instNum.bits
}
```

The write is applied in the cycle the CSR functional unit executes it. The retirement count of that same `csrw` arrives later (`Rob` `RegEnable(trueCommitCnt)` → `CtrlBlock` `RegNext(retiredInstr)` → `csrIn.perf.retiredInstr`, ≥2 cycles after commit) and is added on top of the written value, so the writing instruction counts itself. The spec requires the opposite:

- `machine.adoc` `norm:mcycle_minstret_wr`: "Any CSR write takes effect after the writing instruction has otherwise completed." — i.e. after a `csrw minstret, X`, the next instruction observes exactly `X`.

Spike implements this literally: `wide_counter_csr_t::bump()` skips the increment for the instruction that wrote the counter (`csrs.cc:1315-1327`, "The ISA mandates that explicit writes to instret take precedence over the instret, so simply skip the increment"). NEMU has the same X+1 behaviour as XiangShan, and difftest does not compare `minstret`, so this is invisible to difftest.

A second, related effect: because the retire count reaches the register only ~3 cycles after commit and a `csrr` (noSpecExec, dispatched once the ROB is empty) can execute inside that window, a read returns a value that misses the last few cycles of retirement. With ROB compression that is not "a few instructions": two consecutive `csrr minstret` return the *same* value (delta 0 instead of 1), and `csrr ; 3×fence ; csrr` returns +164..+189 — the tail of the preceding instruction stream landing late. Totals are conserved (it is lag, not loss), but a short-window `rdinstret` measurement is off by up to ~190 instructions in either direction.

# Expected behavior

- `csrw minstret, X ; csrr t0, minstret` → `t0 == X` (Spike). XiangShan: `X+1`.
- `csrw minstret, X ; 4×addi ; csrr` → `X+4`. XiangShan: `X+1`.
- `csrr a ; csrr b` → `b - a == 1`. XiangShan: `0`.

# Environment

- XiangShan branch: kunminghu-v2, commit `2e148b4` (2026-03-16, v3.2.2-alpha-1084-g2e148b41d), DefaultConfig (`--issue E.b`). Cited lines checked unchanged on kunminghu-v2 HEAD `5d393413` (2026-09-02) and kunminghu-v3 HEAD `14af5521` (2026-09-05).
- NEMU `67da68a2` (ready-to-run e79a631) — same X+1; Spike `611a62b7` (ready-to-run) / upstream `3e7bf30d` — X; difftest `7b5fc3bb2`, utility `fcb82239`.

# To Reproduce

Attached `minstret-write-poc` and `minstret-lag-poc` (nexus-am, M-mode, `mcountinhibit = 0`, all sequences emitted with `.option norvc` so instruction counts are exact).

```
make ARCH=riscv64-xs
./build/emu -i minstret-write-poc-riscv64-xs.bin --no-diff
./build/emu -i minstret-lag-poc-riscv64-xs.bin   --no-diff
```

`minstret-write-poc` output (2e148b4):

```
csrw minstret,X ; csrr                       -> X+1   (spec: X+0)   <-- MISMATCH
csrw ; 1x addi ; csrr                        -> X+1   (spec: X+1)
csrw ; 2x addi ; csrr                        -> X+1   (spec: X+2)   <-- MISMATCH
csrw ; 4x addi ; csrr                        -> X+1   (spec: X+4)   <-- MISMATCH
csrw ; 16x addi ; csrr                       -> X+1   (spec: X+16)  <-- MISMATCH
csrw ; 64x addi ; csrr                       -> X+8   (spec: X+64)  <-- MISMATCH
csrw ; fence ; csrr                          -> X+2   (spec: X+1)   <-- MISMATCH
csrr ; csrr                                  -> delta 0   (spec: 1)  <-- MISMATCH
csrr ; 64x addi ; csrr                       -> delta 31  (spec: 65) <-- MISMATCH
IR=1: csrw minstret,X ; csrr                 -> X+0   (spec: X+0)     (inhibited: no self-bump, as expected)
```

`minstret-lag-poc` (each line preceded by a `printf`, whose tail retires late):

```
A1 csrr ; 3 fence ; csrr                     -> 168   (exact 4)    +164
B1 csrr ; 1 fence ; csrr                     -> 191   (exact 2)    +189
D1 csrr ; 256 addi ; csrr                    -> 387   (exact 257)  +130
D2 csrr ; 1024 addi ; csrr                   -> 1125  (exact 1025) +100
E  csrr ; 3 fence ; 256 addi ; 3 fence ; csrr -> 452  (exact 263)  +189
G  [csrr;3 fence;csrr] x2, no printf between -> 193 then 5 (exact 4, 4)
```

Line G shows the mechanism: the first window absorbs ~189 late-arriving retirements from before the first `csrr`; the second window, with nothing pending, reads 5 (4 + the self-count of the intervening `csrr`).

Minimal sequence:

```
li   t0, 0x1000
csrw minstret, t0
csrr t1, minstret      # t1 == 0x1001 on XiangShan, 0x1000 per spec / Spike
```

# Additional context

Suggested fix: make the write take effect after the writer's own retirement — e.g. remember that the current `robCommit.instNum` batch contains the writing `csrw` and subtract/skip its contribution (Spike's `written` flag), or apply the write at commit time. For the read side, a `csrr minstret/mcycle/instret` should not execute until the retire-count pipeline has drained (~3 cycles after the ROB becomes empty), or the pending `instNum` should be forwarded into the read value.

The same structure exists for `mcycle` (`when(w.wen) reg := wdata .elsewhen(...) reg := reg + 1`) and `mhpmcounter3-31`; only `minstret` has been measured here.

Files: `backend/fu/NewCSR/MachineLevel.scala` (`minstret`), `backend/rob/Rob.scala` (`retireCounter`), `backend/CtrlBlock.scala` (`RegNext(retiredInstr)`).
