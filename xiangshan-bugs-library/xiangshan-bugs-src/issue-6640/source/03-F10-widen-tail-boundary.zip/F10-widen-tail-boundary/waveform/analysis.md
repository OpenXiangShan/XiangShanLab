# F10 waveform evidence: correct widened products are truncated by the merge boundary

## Capture and agreement with the issue

This is a new seed-0 trace of the unchanged PoC and reference library on the same pinned DUT source, `b9636416b81d266f3a3d4d1e46d4e66e6a574bcd`, `MinimalConfig`. The emulator was rebuilt with FST tracing; it is a different binary from the earlier non-tracing emulator. [run.json](run.json) records the exact command, hashes and runtime stamp (`dirty=0`). The final differential mismatch is identical to the report: `v2_high` is `0xcfcecdcccbcac9c8`, expected `0x0000000050000005`. The run exits on this mismatch, not on a watchdog.

The waveform corroborates both the reported result and the proposed merge-boundary mechanism. It does not establish a unique repair or independence from all related implementation defects.

![F10: raw multiply, merge boundary and actual vector write port](waveform.png)

This figure is rendered from real FST samples using wavekit. The raw FST is retained in the original full evidence archive (`issue-packages-20260926`), outside this submission package. [Figure selection](waveform-selection.json) and [figure samples](waveform-samples.json) retain exact signal paths. The broader [detail samples](detail-samples.json) retain identification, configuration, valid controls, flush and commit signals; [mapping samples](mapping-samples.json) retain the destination map and the actual merge old-value bytes.

All cycles below count falling-edge samples from the first falling edge in this FST, including reset. They are not the simulator's printed `cycleCnt`. Values while the associated valid/write-enable is zero are not executed results. A write-port observation is the stable request before the next rising edge.

## Instruction and pipeline association

| FST cycle | Valid observation |
| --- | --- |
| 6138 | ROB enqueue slots 6 and 7 both carry PC `0x80000718`, instruction `0xee42a157`, ROB `(flag=0,value=25)`; `io_enq_canAccept=1`. |
| 6148 | `issuePipes.exu.in_uop_valid=1`: same ROB, uop 0, pdest `0x33`, fuType `0x800000`, opcode `0x786`, SEW encoding 2, VL 2, vta 0. |
| 6149 | Same pipe and ROB, uop 1, pdest `0x34`, opcode `0xd86`; same VL/SEW/vta. |
| 6151 | EX2 context and Vimac result valid for uop 0 / pdest `0x33`. Correct raw products enter the incorrect merge boundary. |
| 6152 | Vector register write port 0: wen 1, address `0x33`, data `0xcfcecdcccbcac9c8_0000000000070e15`. EX2 simultaneously releases uop 1. |
| 6153 | Write port 0: wen 1, address `0x34`, unchanged old v3 value `0xdfdedddcdbdad9d8_d7d6d5d4d3d2d1d0`. |
| 6154 | ROB commit slot 0 has isCommit 1, commitValid 1 and ROB `(0,25)`. |
| 6155 | `rename.rat.diffRatBuffer.io_diffRat_vecRat_2` becomes `0x33`; v3 maps to `0x34`. This is a later committed mapping, not an unshifted same-cycle comparison with execution. |

The EXU flush input stays zero over the extracted window, cycles 6136–6159.

## Raw arithmetic versus merge

At cycle **6151**, with EX2 and Vimac output valid:

| Exact suffix under `inner_vecRegion.issuePipes.exu` | Observed |
| --- | --- |
| `_Vimac_out_ex_2_bits_data_vec_normal[127:0]` | `0x0000000050000005_0000000000070e15` |
| `ex_2_bits_ctrl_uopIdx[2:0]` | 0 |
| `ex_2_bits_data_vl[7:0]` | 2 |
| `ex_2_bits_ctrl_vtype_vsew[2:0]` | 2 (SEW=32) |
| `eewOHEx_2[3:0]` | `0x4` (32-bit width, not the 64-bit destination width) |
| `mgus_2.in_ctrl_vta` | 0 |
| `mgus_2.in_data_end[4:0]` | 8 bytes |
| `mgus_2.out_activeEn[15:0]` | `0x00ff` |
| `ex_2_bits_data_src_2[127:0]` (merge oldVd) | `0xcfcecdcccbcac9c8_c7c6c5c4c3c2c1c0` |
| `out_uop_bits_toVpRf_data[127:0]` | `0xcfcecdcccbcac9c8_0000000000070e15` |

Both products are already correct before merge. Only bytes 0–7 are enabled; bytes 8–15 come from oldVd under tail-undisturbed handling, although they contain active widened element 1. At cycle 6152, uop 1 has end=0, activeEn=0 and preserves old v3, consistent with that entire extra destination register being outside VL=2. The report's specific failure is within uop 0's active v2 result.

## Source interpretation and limits

At the pinned revision, `VecFuConfig.scala:200–205` excludes `vimac` from `needWidenOut`. `Exu.scala:112–126` uses available FU widening indicators to select EEW, and lines 137–168 use that width to generate byte boundaries. The trace observes `eewOHEx_2=4` and end=8; it does not contain a separately named `isWidenEx` signal. Thus “widening indication absent” is a source-supported explanation of the measured boundary, not an invented waveform row.

`VecRegionModule.scala:337–339` connects the sampled `_vpWbDataPath_out_wb0_0_{wen,pdest,data}` values to the actual vector register-file write controls. The trace follows the correct raw arithmetic through merge, write request, ROB retirement and v2 destination mapping. The generic text commit `data` field is not used as a vector value.

This trace covers the integer `vwmul.vv` case only. No waveform conclusion is made for the subsequent `vfwmul.vv` test or a hypothetical fixed RTL. No conflict with the current issue's scoped observations was found.
