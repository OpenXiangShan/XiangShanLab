/* F10 -- widening multiplication checks. The reported vwmul.vv e32
 * case leaves its second active e64 result at the old destination
 * value. A later vfwmul.vv self-check is outside the report's waveform
 * coverage and is not used to infer a root cause here.
 */
#include "vt-common.h"

static uint8_t preset[32] __attribute__((aligned(16)));
static uint8_t a[16] __attribute__((aligned(16)));
static uint8_t b[16] __attribute__((aligned(16)));
static uint8_t out[32] __attribute__((aligned(16)));
extern void f10_vwmul_e32(void *o, const void *p, const void *a, const void *b);
extern void f10_vfwmul_e16(void *o, const void *p, const void *a, const void *b);
static void put32(uint8_t *p, int i, uint32_t v) { for (int k = 0; k < 4; k++) p[4 * i + k] = (uint8_t)(v >> (8 * k)); }
static void put16(uint8_t *p, int i, uint16_t v) { p[2 * i] = (uint8_t)v; p[2 * i + 1] = (uint8_t)(v >> 8); }
static uint32_t get32(const uint8_t *p, int i) { return (uint32_t)(bytes_q(p + 4 * i) & 0xFFFFFFFFu); }

int main(void) {
  int bugs = 0;
  for (int i = 0; i < 32; i++) preset[i] = (uint8_t)(0xC0 + i);
  if (vt_init("F10") != 0) return 1;
  printf("[F10] start cyc=%lu\n", (unsigned long)cyc());

  /* (a) {0x00010203, 0x00000005} * {0x00000007, 0x10000001} as e32 -> e64 */
  put32(a, 0, 0x00010203); put32(a, 1, 0x00000005); put32(a, 2, 0); put32(a, 3, 0);
  put32(b, 0, 0x00000007); put32(b, 1, 0x10000001); put32(b, 2, 0); put32(b, 3, 0);
  memset(out, 0, 32); f10_vwmul_e32(out, preset, a, b); VT_FENCE();
  {
    uint64_t e0 = 0x00010203UL * 0x00000007UL, e1 = 0x00000005UL * 0x10000001UL;
    int ok = (out_q(out, 0) == e0 && out_q(out, 1) == e1 &&
              out_q(out, 2) == bytes_q(preset + 16) && out_q(out, 3) == bytes_q(preset + 24));
    if (!ok) bugs++;
    printf("[F10] vwmul.vv e32->e64 vl=2: v2=%016lx_%016lx v3=%016lx_%016lx expect v2=%016lx_%016lx %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           (unsigned long)out_q(out, 3), (unsigned long)out_q(out, 2),
           (unsigned long)e1, (unsigned long)e0,
           ok ? "ok" : (out_q(out, 1) == bytes_q(preset + 8) ? "BUG: element 1 = old vd (tail boundary from source eew)" : "BUG"));
  }

  /* (b) fp16 {1.5, 2, -3, 0.5} * {2, 4, 1.5, 8} -> fp32 {3, 8, -4.5, 4} */
  put16(a, 0, 0x3E00); put16(a, 1, 0x4000); put16(a, 2, 0xC200); put16(a, 3, 0x3800);
  put16(b, 0, 0x4000); put16(b, 1, 0x4400); put16(b, 2, 0x3E00); put16(b, 3, 0x4800);
  memset(out, 0, 32); f10_vfwmul_e16(out, preset, a, b); VT_FENCE();
  {
    int ok = (get32(out, 0) == 0x40400000 && get32(out, 1) == 0x41000000 &&
              get32(out, 2) == 0xC0900000 && get32(out, 3) == 0x40800000 &&
              out_q(out, 2) == bytes_q(preset + 16) && out_q(out, 3) == bytes_q(preset + 24));
    if (!ok) bugs++;
    printf("[F10] vfwmul.vv e16->e32 vl=4: v2=%016lx_%016lx expect=40800000c0900000_4100000040400000 %s\n",
           (unsigned long)out_q(out, 1), (unsigned long)out_q(out, 0),
           ok ? "ok" : "BUG: fp16 single-width products, nothing widened");
  }
  printf("[F10] done bugs=%d verdict=%s\n", bugs, bugs ? "WIDEN_WRONG" : "clean");
  return 0;
}
