/* F10: widening checks. v2/v3 are preset from a1 (32 B), sources
 * come from a2/a3, and results are stored through a0 (32 B). The
 * report covers the vwmul.vv e32 case only. */
#include "probe-common.S"

  .align 6
  .globl f10_vwmul_e32
  .type  f10_vwmul_e32, @function
f10_vwmul_e32:
  vl1re64.v v2, (a1)
  addi t0, a1, 16
  vl1re64.v v3, (t0)
  vl1re64.v v4, (a2)
  vl1re64.v v5, (a3)
  vsetivli x0, 2, e32, m1, tu, mu
  vwmul.vv v2, v4, v5
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  addi t0, a0, 16
  vse64.v v3, (t0)
  ret
  .size f10_vwmul_e32, .-f10_vwmul_e32

  .align 6
  .globl f10_vfwmul_e16
  .type  f10_vfwmul_e16, @function
f10_vfwmul_e16:
  vl1re64.v v2, (a1)
  addi t0, a1, 16
  vl1re64.v v3, (t0)
  vl1re64.v v4, (a2)
  vl1re64.v v5, (a3)
  vsetivli x0, 4, e16, m1, tu, mu
  vfwmul.vv v2, v4, v5
  vsetivli x0, 2, e64, m1, ta, ma
  vse64.v v2, (a0)
  addi t0, a0, 16
  vse64.v v3, (t0)
  ret
  .size f10_vfwmul_e16, .-f10_vfwmul_e16
