# vwmul.vv leaves an active widened result element unchanged

Tested on Kunminghu-v3 **`b9636416b8`, `MinimalConfig`**, VLEN=128. This issue was not reproduced in the latest Kunminghu-v2 version.

## Trigger and result

At PC `0x80000718`, the PoC multiplies v4={0x00010203, 5} by v5={7, 0x10000001}, after initializing the destination with recognizable bytes:

```asm
vsetivli x0, 2, e32, m1, tu, mu
vwmul.vv v2, v4, v5
```

Expected v2 is `0x0000000050000005_0000000000070e15`; observed v2 is `0xcfcecdcccbcac9c8_0000000000070e15`. The first product is correct; the second retains its old destination value.

RISC-V Unprivileged ISA **20240411**, section **31.11.12**, defines widening integer multiplication with double-width results: [official PDF, page 342](https://docs.riscv.org/reference/isa/v20240411/_attachments/riscv-unprivileged.pdf#page=342). Both products are active at VL=2; `tu` does not permit leaving the second unchanged.

![Official specification, PDF page 342](screenshots/spec-page-342.png)

## Evidence

All three difftest runs reproduce this mismatch without a no-commit watchdog: seed **0** [log](logs/replay-20260926/seed0.log) / [metadata](logs/replay-20260926/seed0.json), **1** [log](logs/replay-20260926/seed1.log) / [metadata](logs/replay-20260926/seed1.json), **2** [log](logs/replay-20260926/seed2.log) / [metadata](logs/replay-20260926/seed2.json).

![Difftest mismatch](screenshots/runtime-difference.png)

A separate seed-0 FST rebuild of the same DUT source shows correct raw products, then a 32-bit merge width, byte end=8 and active mask=`0x00ff`; the high product is replaced by oldVd before the actual RF write. This trace covers `vwmul.vv` only: [trace log](waveform/run.log) / [capture metadata](waveform/run.json), [signal paths, samples and analysis](waveform/analysis.md).

![Multiply result, merge and writeback](waveform/waveform.png)

A single seed-0 no-reference self-check stores the same partial result and completes: [log](logs/no-diff-comparison-20260926/seed0.log), [metadata](logs/no-diff-comparison-20260926/seed0.json), [screenshot](screenshots/no-diff-difference.png). `HIT GOOD TRAP` means completion, not correctness. The later `vfwmul.vv` output has no waveform coverage and is outside this report's scope.

## Reproduction

Use [replay.sh](replay.sh) with the included tested [BIN](poc/build/f10-widen-tail-boundary-riscv64-xs-light-kunminghu-v3.bin); also included are the [ELF](poc/build/f10-widen-tail-boundary-riscv64-xs-light-kunminghu-v3.elf), [disassembly](poc/build/f10-widen-tail-boundary-riscv64-xs-light-kunminghu-v3.txt), [C source](poc/main.c) and [assembly](poc/probe.S).

```bash
bash replay.sh 0
bash replay.sh 1
bash replay.sh 2
```

Set `XS_EMU` and `XS_REF` to the pinned binaries; replay checks their hashes.
