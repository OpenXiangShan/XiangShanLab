/* F13 -- vfmv.f.s commits an incorrect FP value. In the traced build,
 * VMove produces the correctly boxed result but the connected FP
 * writeback interface is disabled. Difftest stops at the move, so
 * the following dependent fsd is not assessed.
 */
#include "vt-common.h"

static uint8_t v[16] __attribute__((aligned(16)));
static uint8_t fpre[16] __attribute__((aligned(16)));
static uint8_t out[16] __attribute__((aligned(16)));
extern void f13_vfmv_f_s(void *o, const void *v, const void *fpreset);
static void put64(uint8_t *b, uint64_t x) { for (int k = 0; k < 8; k++) b[k] = (uint8_t)(x >> (8 * k)); }
static void put32(uint8_t *p, int i, uint32_t x) { for (int k = 0; k < 4; k++) p[4 * i + k] = (uint8_t)(x >> (8 * k)); }

int main(void) {
  if (vt_init("F13") != 0) return 1;
  put32(v, 0, 0x3F800000); put32(v, 1, 0x40000000); put32(v, 2, 0x40400000); put32(v, 3, 0x40800000);
  put64(fpre, 0xDEADBEEFDEADBEEFUL);
  memset(out, 0, 16);
  printf("[F13] start cyc=%lu: vfmv.f.s f3, v4 (v4[0]=1.0f) then fsd f3\n", (unsigned long)cyc());
  f13_vfmv_f_s(out, v, fpre); VT_FENCE();
  printf("[F13] completed cyc=%lu f3=%016lx expect=ffffffff3f800000 %s\n", (unsigned long)cyc(),
         (unsigned long)out_q(out, 0),
         out_q(out, 0) == 0xFFFFFFFF3F800000UL ? "ok" : "BUG: stale/absent FP result");
  return 0;
}
