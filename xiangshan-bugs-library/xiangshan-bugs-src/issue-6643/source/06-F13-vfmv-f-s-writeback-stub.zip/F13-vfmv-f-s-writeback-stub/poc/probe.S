/* F13: move to ft3 followed by a dependent fsd; difftest fails at
 * the move, before the fsd can be assessed. */
#include "probe-common.S"

  .align 6
  .globl f13_vfmv_f_s
  .type  f13_vfmv_f_s, @function
f13_vfmv_f_s:
  fld f3, 0(a2)
  vl1re64.v v4, (a1)
  vsetivli x0, 4, e32, m1, tu, mu
  vfmv.f.s f3, v4
  fsd f3, 0(a0)
  ret
  .size f13_vfmv_f_s, .-f13_vfmv_f_s
