# F13 waveform corroboration, with an explicit changed-value record

## Comparison with the existing report

The new traced emulator fails at the same target and `cycleCnt=8880`, with unchanged PoC and reference-library hashes and DUT runtime revision `b9636416b8`, dirty flag `0`. **Its wrong `ft3` value differs from the old seed-0 emulator:**

| Build | Expected ft3 | Observed ft3 |
| --- | --- | --- |
| Preserved original emulator, seed 0 | `0xffffffff3f800000` | `0xb94d8df476a85878` |
| Separately rebuilt FST emulator, seed 0 | `0xffffffff3f800000` | `0x87a3f4f2982f71b7` |

This difference was reported before adding the new evidence. The two values are retained separately. Identical numeric results across the two emulator builds are not claimed.

## Observed chain

All cycles are falling-edge FST sample indices including reset, not DUT `cycleCnt`. Values only count as transactions under their valid/write-enable signals.

| File cycle | Actual observation |
| --- | --- |
| 8940 | Dispatch lane 3 is valid/ready at PC `0x800003cc`, instruction `0x424011d7`, ROB `(flag=1,value=0x0a)`, uop 0, destination physical FP register `0x21` (33). |
| 8946 | A flush targets younger ROB `(1,0x0c)`, level 0. The target later commits. |
| 8951 | Valid VMove for that ROB and destination produces the correctly boxed FP result `0xffffffff3f800000`. The separate `VecRegion.out.fpWbNext` carries `wen=1`, destination 33 and the same correct value. |
| 8951 | The actually connected `VecRegion.out.toFltRegion.wbNext` has `wen=0`; the receiving `FltRegion.in.fromVecRegion.wbNext` also has `wen=0`. These must not be confused with the separate `out.fpWbNext`. |
| 8953 | ROB commit lane 0 commits target PC `0x800003cc`, ROB `(1,0x0a)`. Physical FP register 33 still reads `0x87a3f4f2982f71b7`. |
| 8954 | The delayed diff snapshot RAT maps architectural `ft3` to physical FP register 33. |

Across **all 8,959 sampled cycles and all seven actual FP RF write ports**, there is no enabled write to physical register 33. Its value is `0x87a3f4f2982f71b7` from the first sampled cycle to the final one. [physical-register-history.json](physical-register-history.json) records this check. The full-history check used the raw FST retained in the original full evidence archive; this compact submission contains its summary and the selected local samples, not the entire 8,959-cycle write-port history. The first-cycle value precedes execution of the target, supporting a retained simulation-initialized physical value, not an incorrectly calculated FU result. No original non-traced waveform exists, so the old build's physical-register history is not retrospectively asserted.

![Actual sampled FST waveform](waveform-evidence.png)

The graph displays the connected and separate writeback signals, one RF write port and physical state. The conclusion about all seven ports comes from the full-history check, not just the single plotted port. [samples.json](samples.json) has the plotted signal paths and values; [detail-samples.json](detail-samples.json) includes all seven ports, the flush and commit context. The included [probe samples](probe-samples.json), [detail samples](detail-samples.json) and [run metadata](run.json) retain instruction association, local signal evidence and command/hashes. The raw FST is archived with the original full evidence package and is not included here; its SHA-256 is recorded in run.json.

## Interpretation and limits

The trace corroborates a dropped vector-to-FP writeback path after correct boxing. It directly supports the source observation that `VecRegionModule.scala:253–254` ties the connected FP interface to zero, while `:391` exposes a separate output. `VMove.scala:40–48` already boxes the scalar result. The new wrong value is the destination's unchanged initial physical value in this traced build; it is not the FU result.

This is one seed on a rebuilt instrumented emulator. It strengthens the earlier writeback-path hypothesis, but no DUT fix-and-retest, latest-upstream retest, or independent-root-cause proof was performed. The original three-seed report remains separate evidence, including its original wrong values.

## Included evidence and review boundary

[selection.json](selection.json), [samples.json](samples.json), [detail-selection.json](detail-selection.json), [detail-samples.json](detail-samples.json), [probe-selection.json](probe-selection.json) and [probe-samples.json](probe-samples.json) retain exact signal paths and the selected observed values. [physical-register-history.json](physical-register-history.json) reports the full-history scan. The PNG alone, which displays one physical write port, does not establish the absence of writes on all seven ports; that broader claim relies on the separately recorded full-trace scan. No claim is made that the following dependent `fsd` completed or hung.
