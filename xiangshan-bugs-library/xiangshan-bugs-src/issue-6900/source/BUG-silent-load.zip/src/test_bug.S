.section .text
.globl _start
_start:
    # Bug case: dereference a value LOADED from writable data.
    #   bad_ptr[0] = FAULT_ADDR (aligned, canonical, unmapped).
    # Architecture: the second lw targets an address with no PMA /
    # no bus responder -> must raise load access fault (mcause=5).
    # We install mtvec BEFORE the deref, so the correct behavior is
    # to land in the handler and exit with code 5.
    # Observed on kunminghu-v3 emu: the emulator never delivers the
    # exception and never retires another instruction -> deadlock.
    la      t0, trap_handler
    csrw    mtvec, t0

    la      a4, bad_ptr
    ld      a5, 0(a4)          # a5 = FAULT_ADDR (load-value)
    lw      a6, 0(a5)          # <- dereference of loaded value

    # Only reached if the load (incorrectly) completes without fault:
    li      a0, 0xB0
    .word   0x0005006b         # exit 0xB0 = "no fault delivered"

    .align  2
trap_handler:
    csrr    a0, mcause         # expected: 5 (load access fault)
    .word   0x0005006b         # exit with mcause

    .section .data
    .align  3
bad_ptr:
    .dword  0x0000000050000000   # FAULT_ADDR: unmapped, 4K-aligned
