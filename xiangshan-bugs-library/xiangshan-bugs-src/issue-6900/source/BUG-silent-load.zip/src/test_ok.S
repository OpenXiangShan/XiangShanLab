.section .text
.globl _start
_start:
    # Control case: 2-level pointer chase over VALID addresses.
    # ptr_chain[0] -> ptr_chain[1] -> data. Must complete and exit 0xA1.
    la      a0, ptr_chain
    ld      a1, 0(a0)          # a1 = &ptr_chain[1]
    ld      a2, 0(a1)          # a2 = &data
    lw      a3, 0(a2)          # a3 = 0x12345678 (loaded value consumed)
    xor     a4, a3, a3         # zero if chain intact
    li      a0, 0xA1
    .word   0x0005006b         # NEMU-trap exit, code = 0xA1 (case A OK)

    .section .data
    .align  3
ptr_chain:
    .dword  ptr_chain + 8
    .dword  data
data:
    .word   0x12345678
