# XiangShan issue #6963 reproduction materials

The inline issue source was rebuilt and replayed on 2026-11-13 using the recorded kunminghu-v2 emulator and bundled reference. `replay.log` records the resulting difftest mismatch (exit code 1). `poc.elf` is the exact executable for that replay; `poc.S`, `link.ld` and disassembly are included. See `environment.md`, `build-emu.sh`, `source-provenance.json` and the two source patches for build provenance. Log terminal escape sequences were removed and local filesystem prefixes replaced; architectural output is unchanged.
