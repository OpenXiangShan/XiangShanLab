#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


def clean_name(name: str) -> str:
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_value(value: str | None) -> int | None:
    if value is None:
        return None
    value = value.strip().lower()
    if value in {"0", "1"}:
        return int(value)
    if value.startswith("b"):
        bits = value[1:]
        if any(c in bits for c in "xz"):
            return None
        return int(bits, 2)
    return None


def parse_symbols(path: Path) -> dict[str, int]:
    out = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if len(fields) >= 3:
            try:
                out[fields[2]] = int(fields[0], 16)
            except ValueError:
                pass
    return out


def parse_header(path: Path):
    wanted = {}
    for i in range(3):
        endpoint = "store" if i == 0 else f"store_{i}"
        wanted[f"store_{i}_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_valid"
        wanted[f"store_{i}_bits_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_valid"
        wanted[f"store_{i}_addr"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_addr"
        wanted[f"store_{i}_data"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_data"
        wanted[f"store_{i}_pc"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_pc"

    selected = {}
    code_to_keys = {}
    scope = []
    var_re = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")
    with path.open("r", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope"):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = var_re.match(line)
            if not match:
                continue
            code, raw_name = match.groups()
            full = ".".join(scope + [clean_name(raw_name)])
            for key, suffix in wanted.items():
                if full.endswith(suffix):
                    selected[key] = {"code": code, "full": full}
                    code_to_keys.setdefault(code, []).append(key)
    return selected, code_to_keys


def monitor(vcd: Path, symbols: dict[str, int], names: list[str]):
    selected, code_to_keys = parse_header(vcd)
    values = {key: None for key in selected}
    targets = {name: symbols[name] for name in names if name in symbols}
    stores = {name: [] for name in targets}
    now = 0
    in_body = False

    def sample(time: int):
        for i in range(3):
            valid = parse_value(values.get(f"store_{i}_valid")) == 1
            bits_valid = parse_value(values.get(f"store_{i}_bits_valid"))
            addr = parse_value(values.get(f"store_{i}_addr"))
            if not valid or bits_valid not in (None, 1):
                continue
            for name, target in targets.items():
                if addr == target:
                    stores[name].append({
                        "time": time,
                        "slot": i,
                        "addr": addr,
                        "pc": parse_value(values.get(f"store_{i}_pc")),
                        "data": parse_value(values.get(f"store_{i}_data")),
                    })

    with vcd.open("r", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                continue
            if line[0] in "01xz":
                for key in code_to_keys.get(line[1:], []):
                    values[key] = line[0]
                continue
            if line[0] in "bB":
                parts = line.split()
                if len(parts) >= 2:
                    for key in code_to_keys.get(parts[1], []):
                        values[key] = parts[0]
        sample(now)

    return {
        "selected_signal_count": len(selected),
        "missing_store_signals": sorted(
            key for key in [f"store_{i}_{field}" for i in range(3) for field in ("valid", "addr", "data", "pc")]
            if key not in selected
        ),
        "targets": {name: hex(addr) for name, addr in targets.items()},
        "stores": stores,
        "first_values": {
            name: (rows[0]["data"] if rows else None)
            for name, rows in stores.items()
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("symbols", type=Path)
    parser.add_argument("--json-out", type=Path, required=True)
    parser.add_argument("--store-symbols", default="result_delta,recovered_bit")
    args = parser.parse_args()

    symbols = parse_symbols(args.symbols)
    result = monitor(args.vcd, symbols, [item for item in args.store_symbols.split(",") if item])
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="ascii")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
