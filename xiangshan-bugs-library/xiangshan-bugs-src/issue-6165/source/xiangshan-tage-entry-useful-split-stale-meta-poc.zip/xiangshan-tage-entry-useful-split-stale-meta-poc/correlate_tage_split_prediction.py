#!/usr/bin/env python3
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path


SOURCE_NAMES = {
    0: "Ras",
    1: "ITTage",
    2: "Sc",
    3: "Tage",
    4: "Mbtb",
    5: "Fallthrough",
}


def parse_scalar(text):
    if text in ("0", "1"):
        return int(text)
    return None


def parse_vector(text):
    text = text.lower()
    if any(c in text for c in "xz"):
        return None
    return int(text, 2) if text else None


def classify(path):
    has_bpu_path = (
        ".frontend.inner_bpu." in path
        or "._inner_bpu_" in path
        or "._inner_ftq_" in path
    )
    if not has_bpu_path:
        m = re.search(
            r"\.(finalPred_s3_TageCounter|commit_branch_mispredicts_reason_TAGECounter|"
            r"resolve_branch_mispredicts_s3_source_TageCounter|mispredict_branch_use_providerCounter|"
            r"resolve_branch_use_providerCounter)$",
            path,
        )
        if m:
            return ("counter", m.group(1))
        return None

    m = re.search(r"\.inner_bpu\.tage\.io_(startPc|train_startPc)_addr$", path)
    if m:
        return ("tage_io", m.group(1))
    m = re.search(r"\.inner_bpu\.tage\.io_(trainReady)$", path)
    if m:
        return ("tage_io", m.group(1))
    m = re.search(r"\.inner_bpu\.tage\.io_stageCtrl_(s0_fire|s1_fire|s2_fire|t0_fire)$", path)
    if m:
        return ("tage_stage", m.group(1))

    m = re.search(r"\.inner_bpu\.io_toFtq_prediction_(ready|valid)$", path)
    if m:
        return ("pred", m.group(1))
    m = re.search(
        r"\.inner_bpu\.io_toFtq_prediction_bits_"
        r"(startPc_addr|target_addr|takenCfiOffset_valid|takenCfiOffset_bits|s3Override)$",
        path,
    )
    if m:
        return ("pred_bits", m.group(1))

    m = re.search(r"\.inner_bpu\.io_toFtq_meta_valid$", path)
    if m:
        return ("meta", "valid")
    m = re.search(
        r"\.inner_bpu\.io_toFtq_meta_bits_resolveMeta_tage_entries_(\d+)_"
        r"(useProvider|providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        return ("resolve_tage", int(m.group(1)), m.group(2))

    m = re.search(r"\._inner_bpu_io_toFtq_meta_valid$", path)
    if m:
        return ("stage_valid", "to_ftq")
    m = re.search(r"\._inner_ftq_io_toBpu_train_valid$", path)
    if m:
        return ("stage_valid", "train")
    m = re.search(
        r"\._inner_bpu_io_toFtq_meta_bits_resolveMeta_tage_entries_(\d+)_"
        r"(useProvider|providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        field = {
            "providerTakenCtr_value": "providerTakenCtr_value",
            "providerUsefulCtr_value": "providerUsefulCtr_value",
        }.get(m.group(2), m.group(2))
        return ("stage_tage", "to_ftq", int(m.group(1)), field)
    m = re.search(
        r"\._inner_ftq_io_toBpu_train_bits_meta_tage_entries_(\d+)_"
        r"(useProvider|providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        field = {
            "providerTakenCtr_value": "providerTakenCtr_value",
            "providerUsefulCtr_value": "providerUsefulCtr_value",
        }.get(m.group(2), m.group(2))
        return ("stage_tage", "train", int(m.group(1)), field)

    m = re.search(r"\.inner_bpu\.s3_predictionSource$", path)
    if m:
        return ("s3", "predictionSource")
    m = re.search(r"\.inner_bpu\.s3_prediction_(cfiPosition|target_addr|attribute_branchType|attribute_rasAction)$", path)
    if m:
        return ("s3_prediction", m.group(1))
    m = re.search(
        r"\.inner_bpu\.s3_mbtbResult_(\d+)_(valid|bits_cfiPosition|bits_target_addr|"
        r"bits_attribute_branchType|bits_taken)$",
        path,
    )
    if m:
        return ("s3_mbtb", int(m.group(1)), m.group(2))
    m = re.search(r"\.inner_bpu\.s3_tagePrediction_(\d+)_(useProvider|providerPred|hasAlt|altPred)$", path)
    if m:
        return ("s3_tage", int(m.group(1)), m.group(2))

    m = re.search(
        r"\.inner_bpu\.tage\.io_meta_entries_(\d+)_"
        r"(useProvider|providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        return ("tage_meta", int(m.group(1)), m.group(2))

    m = re.search(r"\.inner_bpu\.tage\.tables_(\d+)\.io_readReq_(\d+)_(valid|bits_setIdx|bits_bankMask)$", path)
    if m:
        field = {"bits_setIdx": "setIdx", "bits_bankMask": "bankMask"}.get(m.group(3), m.group(3))
        return ("read_req", int(m.group(1)), int(m.group(2)), field)
    m = re.search(
        r"\.inner_bpu\.tage\.tables_(\d+)\.io_readResp_(\d+)_entries_(\d+)_(valid|tag|takenCtr_value)$",
        path,
    )
    if m:
        return ("read_resp_entry", int(m.group(1)), int(m.group(2)), int(m.group(3)), m.group(4))
    m = re.search(r"\.inner_bpu\.tage\.tables_(\d+)\.io_readResp_(\d+)_usefulCtrs_(\d+)_value$", path)
    if m:
        return ("read_resp_useful", int(m.group(1)), int(m.group(2)), int(m.group(3)), "usefulCtr_value")

    return None


def parse_header(handle):
    code_to_keys = defaultdict(list)
    key_to_path = {}
    scope = []
    tracked = 0
    for raw in handle:
        line = raw.strip()
        if line.startswith("$scope"):
            parts = line.split()
            scope.append(parts[2])
            continue
        if line.startswith("$upscope"):
            if scope:
                scope.pop()
            continue
        if line.startswith("$enddefinitions"):
            break
        if not line.startswith("$var"):
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        code = parts[3]
        name = parts[4]
        path = ".".join(scope + [name])
        key = classify(path)
        if key is None:
            continue
        code_to_keys[code].append(key)
        key_to_path[key] = path
        tracked += 1
    return code_to_keys, key_to_path, tracked


def build_windows(strict, before_cycles=3, after_cycles=10, event_source="split"):
    windows = []
    events = []
    if event_source == "bad-read":
        for event in strict.get("first_bad_read_events", []):
            events.append(("bad_read", event))
    elif event_source == "bad-stage":
        for event in strict.get("first_bad_read_stage_meta_events", []):
            events.append(("bad_stage_meta", event))
    elif event_source == "split":
        for event in strict.get("first_reads_during_strict_split", []):
            events.append(("split_read", event))
        for event in strict.get("first_split_read_responses", []):
            events.append(("split_response", event))
    else:
        raise ValueError(f"unknown event_source: {event_source}")
    if not events:
        for event in strict.get("first_strict_split_events", []):
            events.append(("strict_split", event))

    for idx, (kind, event) in enumerate(events):
        base_time = event.get("read_time", event.get("time"))
        entry_time = event.get("entry_commit_time", base_time)
        response_time = event.get("response_time", event.get("time", base_time))
        start = max(0, min(base_time, entry_time) - before_cycles)
        end = max(base_time, response_time, event.get("time", base_time)) + after_cycles
        windows.append({
            "id": idx,
            "kind": kind,
            "start": start,
            "end": end,
            "event": event,
            "samples": [],
        })
    return windows


def in_any_window(time, windows):
    return [w for w in windows if w["start"] <= time <= w["end"]]


def lane_snapshot(values, prefix):
    lanes = []
    for lane in range(8):
        lane_data = {}
        for key, value in values.items():
            if len(key) >= 3 and key[0] == prefix and key[1] == lane:
                lane_data[key[2]] = value
        if lane_data:
            lanes.append({"lane": lane, **lane_data})
    return lanes


def stage_meta_snapshot(values):
    stages = {}
    for stage in ("to_ftq", "train"):
        lanes = []
        for lane in range(8):
            lane_data = {}
            for key, value in values.items():
                if len(key) >= 4 and key[0] == "stage_tage" and key[1] == stage and key[2] == lane:
                    lane_data[key[3]] = value
                if stage == "to_ftq" and len(key) >= 3 and key[0] == "resolve_tage" and key[1] == lane:
                    lane_data[key[2]] = value
            if lane_data:
                lanes.append({"lane": lane, **lane_data})
        valid = values.get(("stage_valid", stage))
        if stage == "to_ftq" and valid is None:
            valid = values.get(("meta", "valid"))
        stages[stage] = {
            "valid": valid,
            "entries": lanes,
        }
    return stages


def read_req_snapshot(values):
    reqs = defaultdict(dict)
    for key, value in values.items():
        if len(key) == 4 and key[0] == "read_req":
            _, table, channel, field = key
            reqs[(table, channel)][field] = value
    return [
        {"table": table, "channel": channel, **data}
        for (table, channel), data in sorted(reqs.items())
    ]


def read_resp_snapshot(values):
    entries = defaultdict(dict)
    for key, value in values.items():
        if len(key) == 5 and key[0] == "read_resp_entry":
            _, table, channel, way, field = key
            entries[(table, channel, way)][field] = value
        elif len(key) == 5 and key[0] == "read_resp_useful":
            _, table, channel, way, field = key
            entries[(table, channel, way)][field] = value
    return [
        {"table": table, "channel": channel, "way": way, **data}
        for (table, channel, way), data in sorted(entries.items())
    ]


def snapshot(time, values):
    source = values.get(("s3", "predictionSource"))
    tage_start_pc = values.get(("tage_io", "startPc"))
    tage_train_start_pc = values.get(("tage_io", "train_startPc"))
    return {
        "time": time,
        "tage_io": {
            "startPc_pruned": tage_start_pc,
            "startPc_addr": None if tage_start_pc is None else tage_start_pc << 1,
            "train_startPc_pruned": tage_train_start_pc,
            "train_startPc_addr": None if tage_train_start_pc is None else tage_train_start_pc << 1,
            "trainReady": values.get(("tage_io", "trainReady")),
            "s0_fire": values.get(("tage_stage", "s0_fire")),
            "s1_fire": values.get(("tage_stage", "s1_fire")),
            "s2_fire": values.get(("tage_stage", "s2_fire")),
            "t0_fire": values.get(("tage_stage", "t0_fire")),
        },
        "prediction": {
            "valid": values.get(("pred", "valid")),
            "ready": values.get(("pred", "ready")),
            "startPc": values.get(("pred_bits", "startPc_addr")),
            "target": values.get(("pred_bits", "target_addr")),
            "takenCfiOffset_valid": values.get(("pred_bits", "takenCfiOffset_valid")),
            "takenCfiOffset_bits": values.get(("pred_bits", "takenCfiOffset_bits")),
            "s3Override": values.get(("pred_bits", "s3Override")),
        },
        "meta_valid": values.get(("meta", "valid")),
        "s3_predictionSource": source,
        "s3_predictionSource_name": SOURCE_NAMES.get(source, "unknown") if source is not None else None,
        "s3_prediction": {
            "cfiPosition": values.get(("s3_prediction", "cfiPosition")),
            "target": values.get(("s3_prediction", "target_addr")),
            "branchType": values.get(("s3_prediction", "attribute_branchType")),
            "rasAction": values.get(("s3_prediction", "attribute_rasAction")),
        },
        "s3_tage": lane_snapshot(values, "s3_tage"),
        "s3_mbtb": lane_snapshot(values, "s3_mbtb"),
        "resolve_tage": lane_snapshot(values, "resolve_tage"),
        "tage_meta": lane_snapshot(values, "tage_meta"),
        "stage_meta": stage_meta_snapshot(values),
        "read_reqs": read_req_snapshot(values),
        "read_resps": read_resp_snapshot(values),
    }


def matching_read_resps(sample, event):
    table = event.get("table")
    channel = event.get("channel")
    way = event.get("way")
    tag = event.get("entry_tag")
    expected_useful = event.get("expected_useful")
    matches = []
    for resp in sample.get("read_resps", []):
        if resp.get("table") != table or resp.get("channel") != channel or resp.get("way") != way:
            continue
        if resp.get("valid") != 1 or resp.get("tag") != tag:
            continue
        item = dict(resp)
        item["tag_matches_entry_commit"] = True
        item["useful_matches_expected"] = resp.get("usefulCtr_value") == expected_useful
        matches.append(item)
    return matches


def matching_meta_entries(sample, event):
    table = event.get("table")
    way = event.get("way")
    expected_useful = event.get("expected_useful")
    matches = []
    for entry in sample.get("tage_meta", []):
        if entry.get("useProvider") != 1:
            continue
        if entry.get("providerTableIdx") != table or entry.get("providerWayIdx") != way:
            continue
        item = dict(entry)
        item["useful_matches_expected"] = entry.get("providerUsefulCtr_value") == expected_useful
        matches.append(item)
    return matches


def matching_stage_meta_entries(sample, event):
    table = event.get("table")
    way = event.get("way")
    taken_ctr = event.get("observed_taken_ctr")
    observed_useful = event.get("observed_useful")
    expected_useful = event.get("expected_useful")
    matches = []
    for stage, payload in sample.get("stage_meta", {}).items():
        stage_valid = payload.get("valid")
        for entry in payload.get("entries", []):
            if stage_valid != 1:
                continue
            if entry.get("useProvider") != 1:
                continue
            if entry.get("providerTableIdx") != table or entry.get("providerWayIdx") != way:
                continue
            if taken_ctr is not None and entry.get("providerTakenCtr_value") != taken_ctr:
                continue
            if observed_useful is not None and entry.get("providerUsefulCtr_value") != observed_useful:
                continue
            item = dict(entry)
            item["stage"] = stage
            item["stageValid"] = stage_valid
            item["providerUseful_matches_expected"] = entry.get("providerUsefulCtr_value") == expected_useful
            matches.append(item)
    return matches


def summarize_window(window):
    samples = window["samples"]
    event = window["event"]
    return {
        "tage_source_samples": [
            s for s in samples if s.get("s3_predictionSource_name") == "Tage"
        ],
        "s3_override_samples": [
            s for s in samples if s["prediction"].get("valid") == 1 and s["prediction"].get("s3Override") == 1
        ],
        "tage_provider_samples": [
            s for s in samples
            if any(lane.get("useProvider") == 1 for lane in s.get("s3_tage", []))
        ],
        "tage_meta_provider_samples": [
            s for s in samples
            if any(lane.get("useProvider") == 1 for lane in s.get("tage_meta", []))
        ],
        "matching_read_resp_samples": [
            {**s, "matching_read_resps": matching_read_resps(s, event)}
            for s in samples
            if matching_read_resps(s, event)
        ],
        "matching_meta_samples": [
            {**s, "matching_meta_entries": matching_meta_entries(s, event)}
            for s in samples
            if matching_meta_entries(s, event)
        ],
        "matching_stage_meta_samples": [
            {**s, "matching_stage_meta_entries": matching_stage_meta_entries(s, event)}
            for s in samples
            if matching_stage_meta_entries(s, event)
        ],
    }


def monitor(vcd_path, strict_json, before_cycles=3, after_cycles=10, event_source="split"):
    strict = json.loads(Path(strict_json).read_text())
    windows = build_windows(
        strict,
        before_cycles=before_cycles,
        after_cycles=after_cycles,
        event_source=event_source,
    )
    values = {}
    last_time = 0
    final_counters = {}

    def sample_if_needed(time):
        matching = in_any_window(time, windows)
        if not matching:
            return
        snap = snapshot(time, values)
        for window in matching:
            window["samples"].append(snap)

    with open(vcd_path, "r", errors="replace") as handle:
        code_to_keys, key_to_path, tracked = parse_header(handle)
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line[0] == "#":
                sample_if_needed(last_time)
                last_time = int(line[1:])
                continue
            if line[0] in "01xz":
                keys = code_to_keys.get(line[1:])
                if keys:
                    value = parse_scalar(line[0])
                    for key in keys:
                        values[key] = value
                continue
            if line[0] in "bB":
                try:
                    bits, code = line[1:].split(None, 1)
                except ValueError:
                    continue
                keys = code_to_keys.get(code)
                if keys:
                    value = parse_vector(bits)
                    for key in keys:
                        values[key] = value
        sample_if_needed(last_time)

    for key, value in values.items():
        if key[0] == "counter":
            final_counters[key[1]] = value

    out_windows = []
    for window in windows:
        summary = summarize_window(window)
        out_windows.append({
            "id": window["id"],
            "kind": window["kind"],
            "start": window["start"],
            "end": window["end"],
            "event": window["event"],
            "samples": window["samples"],
            "summary": {
                "tage_source_sample_count": len(summary["tage_source_samples"]),
                "s3_override_sample_count": len(summary["s3_override_samples"]),
                "tage_provider_sample_count": len(summary["tage_provider_samples"]),
                "tage_meta_provider_sample_count": len(summary["tage_meta_provider_samples"]),
                "matching_read_resp_sample_count": len(summary["matching_read_resp_samples"]),
                "matching_meta_sample_count": len(summary["matching_meta_samples"]),
                "matching_stage_meta_sample_count": len(summary["matching_stage_meta_samples"]),
                "first_tage_source_samples": summary["tage_source_samples"][:4],
                "first_s3_override_samples": summary["s3_override_samples"][:4],
                "first_tage_provider_samples": summary["tage_provider_samples"][:4],
                "first_tage_meta_provider_samples": summary["tage_meta_provider_samples"][:4],
                "first_matching_read_resp_samples": summary["matching_read_resp_samples"][:4],
                "first_matching_meta_samples": summary["matching_meta_samples"][:4],
                "first_matching_stage_meta_samples": summary["matching_stage_meta_samples"][:4],
            },
        })

    return {
        "vcd_path": str(vcd_path),
        "strict_json": str(strict_json),
        "event_source": event_source,
        "tracked_signals": tracked,
        "tracked_paths": {str(k): v for k, v in key_to_path.items()},
        "final_counters": final_counters,
        "windows": out_windows,
    }


def brief_result(result):
    windows = []
    for window in result["windows"]:
        summary = window["summary"]
        event = window["event"]
        windows.append({
            "id": window["id"],
            "kind": window["kind"],
            "range": [window["start"], window["end"]],
            "event": {
                "time": event.get("time"),
                "read_time": event.get("read_time"),
                "entry_commit_time": event.get("entry_commit_time"),
                "useful_commit_time": event.get("useful_commit_time"),
                "table": event.get("table"),
                "bank": event.get("bank"),
                "way": event.get("way"),
                "setIdx": event.get("setIdx"),
                "entry_tag": event.get("entry_tag"),
                "expected_useful": event.get("expected_useful"),
                "observed_useful": event.get("observed_useful"),
                "tag_matches_entry_commit": event.get("tag_matches_entry_commit"),
                "useful_matches_expected": event.get("useful_matches_expected"),
            },
            "counts": {
                "tage_source": summary["tage_source_sample_count"],
                "s3_override": summary["s3_override_sample_count"],
                "tage_provider": summary["tage_provider_sample_count"],
                "tage_meta_provider": summary["tage_meta_provider_sample_count"],
                "matching_read_resp": summary["matching_read_resp_sample_count"],
                "matching_meta": summary["matching_meta_sample_count"],
                "matching_stage_meta": summary["matching_stage_meta_sample_count"],
            },
            "matching_read_resp_times": [
                {
                    "time": sample["time"],
                    "tage_io": sample.get("tage_io"),
                    "matches": sample["matching_read_resps"],
                }
                for sample in summary["first_matching_read_resp_samples"]
            ],
            "matching_meta_times": [
                {
                    "time": sample["time"],
                    "predictionSource": sample.get("s3_predictionSource_name"),
                    "startPc": sample.get("prediction", {}).get("startPc"),
                    "tage_io": sample.get("tage_io"),
                    "matches": sample["matching_meta_entries"],
                }
                for sample in summary["first_matching_meta_samples"]
            ],
            "matching_stage_meta_times": [
                {
                    "time": sample["time"],
                    "tage_io": sample.get("tage_io"),
                    "matches": sample["matching_stage_meta_entries"],
                }
                for sample in summary["first_matching_stage_meta_samples"]
            ],
            "tage_source_times": [
                {
                    "time": sample["time"],
                    "startPc": sample.get("prediction", {}).get("startPc"),
                    "tage_io": sample.get("tage_io"),
                    "target": sample.get("s3_prediction", {}).get("target"),
                    "cfiPosition": sample.get("s3_prediction", {}).get("cfiPosition"),
                    "s3Override": sample.get("prediction", {}).get("s3Override"),
                }
                for sample in summary["first_tage_source_samples"]
            ],
        })
    return {
        "vcd_path": result["vcd_path"],
        "strict_json": result["strict_json"],
        "tracked_signals": result["tracked_signals"],
        "final_counters": result["final_counters"],
        "windows": windows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd")
    parser.add_argument("--strict-json", required=True)
    parser.add_argument("--json-out", required=True)
    parser.add_argument("--before-cycles", type=int, default=3)
    parser.add_argument("--after-cycles", type=int, default=10)
    parser.add_argument("--event-source", choices=("split", "bad-read", "bad-stage"), default="split")
    parser.add_argument("--print-full", action="store_true")
    args = parser.parse_args()
    result = monitor(
        args.vcd,
        args.strict_json,
        before_cycles=args.before_cycles,
        after_cycles=args.after_cycles,
        event_source=args.event_source,
    )
    Path(args.json_out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="ascii")
    printed = result if args.print_full else brief_result(result)
    print(json.dumps(printed, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
