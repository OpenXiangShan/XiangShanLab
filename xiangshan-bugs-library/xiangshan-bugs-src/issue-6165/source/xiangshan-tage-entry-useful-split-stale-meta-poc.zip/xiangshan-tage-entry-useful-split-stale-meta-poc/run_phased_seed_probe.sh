#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
RISCV_NM="${RISCV_NM:-/opt/riscv/bin/riscv64-unknown-elf-nm}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"
LINKER="${LINKER:-./linker.ld}"
TAGE_MONITOR="${TAGE_MONITOR:-./monitor_tage_split_strict.py}"

CYCLES="${CYCLES:-22000}"
WAVE_BEGIN="${WAVE_BEGIN:-0}"
WAVE_END="${WAVE_END:-$CYCLES}"
WARM_ITERS="${WARM_ITERS:-512}"
PHASE_ITERS="${PHASE_ITERS:-1536}"
SEED0="${SEED0:-0x13579d00}"
SEED1="${SEED1:-0x13579d22}"
RECOVERY_THRESHOLD="${RECOVERY_THRESHOLD:-0}"
INVERT_RECOVERY="${INVERT_RECOVERY:-0}"
RUNTIME_SECRET="${RUNTIME_SECRET:-0}"
MAX_PAIR_AGE="${MAX_PAIR_AGE:-8192}"
NEAR_WINDOW="${NEAR_WINDOW:-64}"
TIMEOUT_SECS="${TIMEOUT_SECS:-360}"
SUMMARY="${SUMMARY:-phased_seed_probe_summary.jsonl}"
KEEP_VCD="${KEEP_VCD:-0}"
SECRETS="${SECRETS:-0 1}"
RUN_TAGE_MONITOR="${RUN_TAGE_MONITOR:-1}"

export SEED0 SEED1 WARM_ITERS PHASE_ITERS KEEP_VCD RECOVERY_THRESHOLD INVERT_RECOVERY RUNTIME_SECRET

: > "$SUMMARY"

for secret in $SECRETS; do
  prefix="phased_seed_secret${secret}_w${WARM_ITERS}_p${PHASE_ITERS}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  symbols="${prefix}.symbols"
  wave="${prefix}_${WAVE_BEGIN}_${WAVE_END}.vcd"
  run_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.run.log"
  store_json="${prefix}_${WAVE_BEGIN}_${WAVE_END}.store.monitor.json"
  tage_json="${prefix}_${WAVE_BEGIN}_${WAVE_END}.tage_split.monitor.json"

  "$RISCV_GCC" \
    -nostdlib -nostartfiles -static \
    -march=rv64gc_zicsr -mabi=lp64d \
    -DSECRET_VALUE="$secret" \
    -DWARM_ITERS="$WARM_ITERS" \
    -DPHASE_ITERS="$PHASE_ITERS" \
    -DSEED0="$SEED0" \
    -DSEED1="$SEED1" \
    -DRECOVERY_THRESHOLD="$RECOVERY_THRESHOLD" \
    -DINVERT_RECOVERY="$INVERT_RECOVERY" \
    -DRUNTIME_SECRET="$RUNTIME_SECRET" \
    -T "$LINKER" \
    -o "$elf" \
    phased_seed_probe.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d "$elf" > "$objdump"
  "$RISCV_NM" -n "$elf" > "$symbols"

  timeout "${TIMEOUT_SECS}s" "$EMU" \
    -i "$bin" \
    --no-diff \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    --dump-wave-full \
    --wave-path="$wave" \
    > "$run_log" 2>&1

  python3 monitor_store_symbols.py "$wave" "$symbols" --json-out "$store_json" > "${store_json%.json}.log"
  if [ "$RUN_TAGE_MONITOR" = "1" ]; then
    python3 "$TAGE_MONITOR" "$wave" \
      --max-pair-age "$MAX_PAIR_AGE" \
      --near-window "$NEAR_WINDOW" \
      --json-out "$tage_json" > "${tage_json%.json}.log" || true
  else
    printf '{"counts": {}}\n' > "$tage_json"
    printf 'TAGE monitor skipped\n' > "${tage_json%.json}.log"
  fi

  python3 - "$secret" "$store_json" "$tage_json" "$wave" "$SUMMARY" <<'PY'
import json
import os
import sys

secret = int(sys.argv[1])
store = json.load(open(sys.argv[2]))
tage = json.load(open(sys.argv[3]))
wave = sys.argv[4]
summary = sys.argv[5]
counts = tage["counts"]

row = {
    "secret": secret,
    "seed": os.environ["SEED1"] if secret else os.environ["SEED0"],
    "warm_iters": int(os.environ["WARM_ITERS"], 0),
    "phase_iters": int(os.environ["PHASE_ITERS"], 0),
    "recovery_threshold": int(os.environ.get("RECOVERY_THRESHOLD", "0"), 0),
    "invert_recovery": int(os.environ.get("INVERT_RECOVERY", "0"), 0),
    "runtime_secret": int(os.environ.get("RUNTIME_SECRET", "0"), 0),
    "delta": store["first_values"].get("result_delta"),
    "recovered": store["first_values"].get("recovered_bit"),
    "result_store_count": len(store["stores"].get("result_delta", [])),
    "recovered_store_count": len(store["stores"].get("recovered_bit", [])),
    "strict_split_intervals": counts.get("strict_split_intervals", 0),
    "strict_split_expected_useful_1": counts.get("strict_split_expected_useful_1", 0),
    "reads_during_strict_split": counts.get("reads_during_strict_split", 0),
    "reads_during_strict_split_expected_useful_1": counts.get("reads_during_strict_split_expected_useful_1", 0),
    "split_read_tag_match_expected_useful_1": counts.get("split_read_tag_match_expected_useful_1", 0),
    "split_read_useful_mismatch": counts.get("split_read_useful_mismatch", 0),
    "bad_read_observations": counts.get("bad_read_observations", 0),
    "bad_read_any_meta_consumed": counts.get("bad_read_any_meta_consumed", 0),
    "bad_read_stage_meta_consumed": counts.get("bad_read_stage_meta_consumed", 0),
    "bad_read_to_ftq_meta_consumed": counts.get("bad_read_to_ftq_meta_consumed", 0),
    "bad_read_train_meta_consumed": counts.get("bad_read_train_meta_consumed", 0),
    "tage_json": sys.argv[3],
}
keep = (
    os.environ.get("KEEP_VCD", "0") == "1"
    or row["bad_read_any_meta_consumed"] > 0
    or row["bad_read_observations"] > 0
)
row["vcd"] = wave if keep else None
row["vcd_deleted"] = False
if not keep:
    try:
        os.unlink(wave)
        row["vcd_deleted"] = True
    except FileNotFoundError:
        row["vcd_deleted"] = True

with open(summary, "a", encoding="ascii") as out:
    out.write(json.dumps(row, sort_keys=True) + "\n")
print(json.dumps(row, sort_keys=True))
PY
done
