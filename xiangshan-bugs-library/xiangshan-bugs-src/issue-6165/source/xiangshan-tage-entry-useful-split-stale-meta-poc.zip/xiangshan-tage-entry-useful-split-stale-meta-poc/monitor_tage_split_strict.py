#!/usr/bin/env python3
import argparse
import json
import re
import sys
from collections import defaultdict, deque
from pathlib import Path


THIS_DIR = Path(__file__).resolve().parent
ORIG_MONITOR_DIR = THIS_DIR.parent / "tage_drop"
sys.path.insert(0, str(ORIG_MONITOR_DIR))
import monitor_tage_split_atomic as base  # noqa: E402


def bit_is_set(value, bit):
    return value is not None and ((value >> bit) & 1) == 1


def classify(path):
    key = base.classify(path)
    if key is not None:
        return key

    if ".frontend.inner_bpu." not in path and "._inner_bpu_" not in path and "._inner_ftq_" not in path:
        return None

    m = re.search(r"\.tage\.tables_(\d+)\.io_readResp_([01])_entries_(\d+)_takenCtr_value$", path)
    if m:
        return ("read_resp_entry", int(m.group(1)), int(m.group(2)), int(m.group(3)), "takenCtr")

    m = re.search(
        r"\.tage\.io_meta_entries_(\d+)_(useProvider|providerTableIdx|providerWayIdx|"
        r"providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        field = {
            "providerTakenCtr_value": "providerTakenCtr",
            "providerUsefulCtr_value": "providerUsefulCtr",
        }.get(m.group(2), m.group(2))
        return ("predict_meta", int(m.group(1)), field)

    m = re.search(r"\._inner_bpu_io_toFtq_meta_valid$", path)
    if m:
        return ("meta_valid", "to_ftq")

    m = re.search(r"\._inner_ftq_io_toBpu_train_valid$", path)
    if m:
        return ("meta_valid", "train")

    m = re.search(
        r"\._inner_bpu_io_toFtq_meta_bits_resolveMeta_tage_entries_(\d+)_(useProvider|"
        r"providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        field = {
            "providerTakenCtr_value": "providerTakenCtr",
            "providerUsefulCtr_value": "providerUsefulCtr",
        }.get(m.group(2), m.group(2))
        return ("stage_meta", "to_ftq", int(m.group(1)), field)

    m = re.search(
        r"\._inner_ftq_io_toBpu_train_bits_meta_tage_entries_(\d+)_(useProvider|"
        r"providerTableIdx|providerWayIdx|providerTakenCtr_value|providerUsefulCtr_value|altOrBasePred)$",
        path,
    )
    if m:
        field = {
            "providerTakenCtr_value": "providerTakenCtr",
            "providerUsefulCtr_value": "providerUsefulCtr",
        }.get(m.group(2), m.group(2))
        return ("stage_meta", "train", int(m.group(1)), field)

    return None


def parse_header(handle):
    code_to_keys = defaultdict(list)
    key_to_path = {}
    scope = []
    tracked = 0

    for raw in handle:
        line = raw.strip()
        if line.startswith("$scope"):
            parts = line.split()
            scope.append(parts[2])
            continue
        if line.startswith("$upscope"):
            if scope:
                scope.pop()
            continue
        if line.startswith("$enddefinitions"):
            break
        if not line.startswith("$var"):
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        code = parts[3]
        name = parts[4]
        path = ".".join(scope + [name])
        key = classify(path)
        if key is None:
            continue
        code_to_keys[code].append(key)
        key_to_path[key] = path
        tracked += 1

    return code_to_keys, key_to_path, tracked


def monitor(vcd_path, max_pair_age=256, near_window=16, meta_window=256):
    values = {}
    entry_ports = set()
    useful_ports = set()
    read_reqs = set()
    resp_lanes = set()
    predict_meta_slots = set()
    stage_meta_slots = defaultdict(set)
    pending_pairs = deque(maxlen=512)
    pending_resp_checks = deque()
    pending_bad_meta_checks = deque()
    counts = {
        "timestamps": 0,
        "tracked_signals": 0,
        "paired_enqueues_valid": 0,
        "paired_enqueues_accepted": 0,
        "paired_enqueues_expected_useful_0": 0,
        "paired_enqueues_expected_useful_1": 0,
        "paired_enqueues_expected_useful_other": 0,
        "entry_commits": 0,
        "useful_commits": 0,
        "same_cycle_entry_useful_commits": 0,
        "same_cycle_expected_useful_0": 0,
        "same_cycle_expected_useful_1": 0,
        "same_cycle_expected_useful_other": 0,
        "strict_split_intervals": 0,
        "strict_split_expected_useful_0": 0,
        "strict_split_expected_useful_1": 0,
        "strict_split_expected_useful_other": 0,
        "late_useful_commits_after_strict_split": 0,
        "reads_during_strict_split": 0,
        "reads_during_strict_split_expected_useful_1": 0,
        "split_read_responses": 0,
        "split_read_tag_match": 0,
        "split_read_tag_match_expected_useful_1": 0,
        "split_read_useful_mismatch": 0,
        "bad_read_observations": 0,
        "bad_read_provider_meta_table_way_matches": 0,
        "bad_read_provider_meta_consumed": 0,
        "bad_read_provider_meta_consumed_expected_useful_1": 0,
        "bad_read_stage_meta_consumed": 0,
        "bad_read_to_ftq_meta_consumed": 0,
        "bad_read_train_meta_consumed": 0,
        "bad_read_any_meta_consumed": 0,
        "near_split_read_reqs": 0,
        "near_split_bank_read_reqs": 0,
    }
    first_strict_split_events = []
    first_same_cycle_events = []
    first_reads_during_strict_split = []
    first_split_read_responses = []
    first_bad_read_events = []
    first_bad_read_provider_meta_events = []
    first_bad_read_stage_meta_events = []
    first_late_useful_commit_events = []
    first_near_split_read_reqs = []
    first_near_split_bank_read_reqs = []
    time = 0
    last_checked = None
    next_pair_id = 1

    with open(vcd_path, "r", errors="replace") as handle:
        code_to_keys, key_to_path, tracked = parse_header(handle)
        counts["tracked_signals"] = tracked

        for key in key_to_path:
            if key[0] in ("entry_enq", "entry_deq"):
                entry_ports.add(key[1:4])
            elif key[0] in ("useful_enq", "useful_deq"):
                useful_ports.add(key[1:4])
            elif key[0] == "read_req":
                read_reqs.add(key[1:3])
            elif key[0] in ("read_resp_entry", "read_resp_useful"):
                resp_lanes.add(key[1:4])
            elif key[0] == "predict_meta":
                predict_meta_slots.add(key[1])
            elif key[0] == "stage_meta":
                stage_meta_slots[key[1]].add(key[2])

        def snapshot_pair(table, bank, way):
            return {
                "id": None,
                "table": table,
                "bank": bank,
                "way": way,
                "enq_time": time,
                "setIdx": values.get(("entry_enq", table, bank, way, "setIdx")),
                "entry_tag": values.get(("entry_enq", table, bank, way, "entry_tag")),
                "expected_useful": values.get(("useful_enq", table, bank, way, "usefulCtr_value")),
                "entry_commit_time": None,
                "useful_commit_time": None,
                "strict_split_time": None,
                "entry_enq_path": key_to_path.get(("entry_enq", table, bank, way, "valid")),
                "useful_enq_path": key_to_path.get(("useful_enq", table, bank, way, "valid")),
                "entry_commit_path": key_to_path.get(("entry_deq", table, bank, way, "valid")),
                "useful_commit_path": key_to_path.get(("useful_deq", table, bank, way, "valid")),
            }

        def pair_event(pair, event_time):
            return {
                "time": event_time,
                "pair_id": pair["id"],
                "table": pair["table"],
                "bank": pair["bank"],
                "way": pair["way"],
                "setIdx": pair["setIdx"],
                "entry_tag": pair["entry_tag"],
                "expected_useful": pair["expected_useful"],
                "enq_time": pair["enq_time"],
                "entry_commit_time": pair["entry_commit_time"],
                "useful_commit_time": pair["useful_commit_time"],
                "strict_split_time": pair.get("strict_split_time"),
                "entry_enq_path": pair["entry_enq_path"],
                "useful_enq_path": pair["useful_enq_path"],
                "entry_commit_path": pair["entry_commit_path"],
                "useful_commit_path": pair["useful_commit_path"],
            }

        def collect_enqueues():
            nonlocal next_pair_id
            for table, bank, way in sorted(entry_ports & useful_ports):
                e_valid = values.get(("entry_enq", table, bank, way, "valid"))
                u_valid = values.get(("useful_enq", table, bank, way, "valid"))
                if e_valid != 1 or u_valid != 1:
                    continue
                e_set = values.get(("entry_enq", table, bank, way, "setIdx"))
                u_set = values.get(("useful_enq", table, bank, way, "setIdx"))
                tag = values.get(("entry_enq", table, bank, way, "entry_tag"))
                useful = values.get(("useful_enq", table, bank, way, "usefulCtr_value"))
                if e_set is None or e_set != u_set or tag is None or useful is None:
                    continue
                counts["paired_enqueues_valid"] += 1
                e_ready = values.get(("entry_enq", table, bank, way, "ready"))
                u_ready = values.get(("useful_enq", table, bank, way, "ready"))
                if e_ready != 1 or u_ready != 1:
                    continue
                pair = snapshot_pair(table, bank, way)
                pair["id"] = next_pair_id
                next_pair_id += 1
                pending_pairs.append(pair)
                counts["paired_enqueues_accepted"] += 1
                if useful == 0:
                    counts["paired_enqueues_expected_useful_0"] += 1
                elif useful == 1:
                    counts["paired_enqueues_expected_useful_1"] += 1
                else:
                    counts["paired_enqueues_expected_useful_other"] += 1

        def collect_commits():
            entry_commits = []
            useful_commits = []
            for table, bank, way in sorted(entry_ports):
                if (
                    values.get(("entry_deq", table, bank, way, "valid")) == 1
                    and values.get(("entry_deq", table, bank, way, "ready")) == 1
                ):
                    counts["entry_commits"] += 1
                    entry_commits.append({
                        "table": table,
                        "bank": bank,
                        "way": way,
                        "setIdx": values.get(("entry_deq", table, bank, way, "setIdx")),
                        "entry_tag": values.get(("entry_deq", table, bank, way, "entry_tag")),
                    })
            for table, bank, way in sorted(useful_ports):
                if (
                    values.get(("useful_deq", table, bank, way, "valid")) == 1
                    and values.get(("useful_deq", table, bank, way, "ready")) == 1
                ):
                    counts["useful_commits"] += 1
                    useful_commits.append({
                        "table": table,
                        "bank": bank,
                        "way": way,
                        "setIdx": values.get(("useful_deq", table, bank, way, "setIdx")),
                        "useful": values.get(("useful_deq", table, bank, way, "usefulCtr_value")),
                    })
            return entry_commits, useful_commits

        def apply_commits(entry_commits, useful_commits):
            entry_touched = []
            for commit in entry_commits:
                for pair in reversed(pending_pairs):
                    if (
                        pair["table"] == commit["table"]
                        and pair["bank"] == commit["bank"]
                        and pair["way"] == commit["way"]
                        and pair["setIdx"] == commit["setIdx"]
                        and pair["entry_tag"] == commit["entry_tag"]
                        and pair["entry_commit_time"] is None
                    ):
                        pair["entry_commit_time"] = time
                        entry_touched.append(pair)
                        break

            for commit in useful_commits:
                for pair in pending_pairs:
                    if (
                        pair["table"] == commit["table"]
                        and pair["bank"] == commit["bank"]
                        and pair["way"] == commit["way"]
                        and pair["setIdx"] == commit["setIdx"]
                        and pair["expected_useful"] == commit["useful"]
                        and pair["useful_commit_time"] is None
                    ):
                        if pair["entry_commit_time"] is not None and time > pair["entry_commit_time"]:
                            counts["late_useful_commits_after_strict_split"] += 1
                            if len(first_late_useful_commit_events) < 8:
                                first_late_useful_commit_events.append(pair_event(pair, time))
                        pair["useful_commit_time"] = time
                        break

            for pair in entry_touched:
                if pair["useful_commit_time"] == time:
                    counts["same_cycle_entry_useful_commits"] += 1
                    if pair["expected_useful"] == 0:
                        counts["same_cycle_expected_useful_0"] += 1
                    elif pair["expected_useful"] == 1:
                        counts["same_cycle_expected_useful_1"] += 1
                    else:
                        counts["same_cycle_expected_useful_other"] += 1
                    if len(first_same_cycle_events) < 8:
                        first_same_cycle_events.append(pair_event(pair, time))
                elif pair["useful_commit_time"] is None or pair["useful_commit_time"] > time:
                    pair["strict_split_time"] = time
                    counts["strict_split_intervals"] += 1
                    if pair["expected_useful"] == 0:
                        counts["strict_split_expected_useful_0"] += 1
                    elif pair["expected_useful"] == 1:
                        counts["strict_split_expected_useful_1"] += 1
                    else:
                        counts["strict_split_expected_useful_other"] += 1
                    if len(first_strict_split_events) < 8:
                        first_strict_split_events.append(pair_event(pair, time))

        def check_response_observations():
            while pending_resp_checks and pending_resp_checks[0]["check_after"] < time:
                pending_resp_checks.popleft()
            for item in list(pending_resp_checks):
                if item["check_after"] != time:
                    continue
                pair = item["pair"]
                table = pair["table"]
                way = pair["way"]
                ch = item["channel"]
                entry_valid = values.get(("read_resp_entry", table, ch, way, "valid"))
                tag = values.get(("read_resp_entry", table, ch, way, "tag"))
                taken_ctr = values.get(("read_resp_entry", table, ch, way, "takenCtr"))
                useful = values.get(("read_resp_useful", table, ch, way))
                tag_matches = entry_valid == 1 and tag == pair["entry_tag"]
                useful_mismatch = useful != pair["expected_useful"]
                meta_matches = []
                meta_consumed = []
                for slot in sorted(predict_meta_slots):
                    meta = {
                        "slot": slot,
                        "useProvider": values.get(("predict_meta", slot, "useProvider")),
                        "providerTableIdx": values.get(("predict_meta", slot, "providerTableIdx")),
                        "providerWayIdx": values.get(("predict_meta", slot, "providerWayIdx")),
                        "providerTakenCtr": values.get(("predict_meta", slot, "providerTakenCtr")),
                        "providerUsefulCtr": values.get(("predict_meta", slot, "providerUsefulCtr")),
                        "altOrBasePred": values.get(("predict_meta", slot, "altOrBasePred")),
                    }
                    table_way_match = meta["providerTableIdx"] == table and meta["providerWayIdx"] == way
                    if table_way_match:
                        meta_matches.append(meta)
                    if (
                        table_way_match
                        and meta["useProvider"] == 1
                        and meta["providerTakenCtr"] == taken_ctr
                        and meta["providerUsefulCtr"] == useful
                    ):
                        meta_consumed.append(meta)
                counts["split_read_responses"] += 1
                if tag_matches:
                    counts["split_read_tag_match"] += 1
                    if pair["expected_useful"] == 1:
                        counts["split_read_tag_match_expected_useful_1"] += 1
                if useful_mismatch:
                    counts["split_read_useful_mismatch"] += 1
                if len(first_split_read_responses) < 8:
                    first_split_read_responses.append({
                        "time": time,
                        "read_time": item["read_time"],
                        "channel": ch,
                        "entry_valid": entry_valid,
                        "observed_tag": tag,
                        "observed_taken_ctr": taken_ctr,
                        "observed_useful": useful,
                        "tag_matches_entry_commit": tag_matches,
                        "useful_matches_expected": not useful_mismatch,
                        "provider_meta_table_way_matches": meta_matches,
                        "provider_meta_consumed_matches": meta_consumed,
                        **pair_event(pair, time),
                    })
                if tag_matches and useful_mismatch:
                    counts["bad_read_observations"] += 1
                    if meta_matches:
                        counts["bad_read_provider_meta_table_way_matches"] += 1
                    if meta_consumed:
                        counts["bad_read_provider_meta_consumed"] += 1
                        if pair["expected_useful"] == 1:
                            counts["bad_read_provider_meta_consumed_expected_useful_1"] += 1
                    if len(first_bad_read_events) < 8:
                        first_bad_read_events.append({
                            "time": time,
                            "read_time": item["read_time"],
                            "channel": ch,
                            "observed_taken_ctr": taken_ctr,
                            "observed_useful": useful,
                            "provider_meta_table_way_matches": meta_matches,
                            "provider_meta_consumed_matches": meta_consumed,
                            **pair_event(pair, time),
                        })
                    if meta_consumed and len(first_bad_read_provider_meta_events) < 8:
                        first_bad_read_provider_meta_events.append({
                            "time": time,
                            "read_time": item["read_time"],
                            "channel": ch,
                            "observed_taken_ctr": taken_ctr,
                            "observed_useful": useful,
                            "provider_meta_consumed_matches": meta_consumed,
                            **pair_event(pair, time),
                        })
                    pending_bad_meta_checks.append({
                        "bad_id": counts["bad_read_observations"],
                        "response_time": time,
                        "deadline": time + meta_window,
                        "read_time": item["read_time"],
                        "channel": ch,
                        "table": table,
                        "way": way,
                        "observed_taken_ctr": taken_ctr,
                        "observed_useful": useful,
                        "expected_useful": pair["expected_useful"],
                        "pair_event": pair_event(pair, time),
                        "matched_stages": set(),
                        "any_consumed": bool(meta_consumed),
                    })
                    if meta_consumed:
                        counts["bad_read_any_meta_consumed"] += 1

        def collect_stage_meta_matches(item):
            matches_by_stage = {}
            consumed_by_stage = {}
            for stage, slots in sorted(stage_meta_slots.items()):
                stage_valid = values.get(("meta_valid", stage))
                matches = []
                consumed = []
                for slot in sorted(slots):
                    meta = {
                        "stage": stage,
                        "slot": slot,
                        "stageValid": stage_valid,
                        "useProvider": values.get(("stage_meta", stage, slot, "useProvider")),
                        "providerTableIdx": values.get(("stage_meta", stage, slot, "providerTableIdx")),
                        "providerWayIdx": values.get(("stage_meta", stage, slot, "providerWayIdx")),
                        "providerTakenCtr": values.get(("stage_meta", stage, slot, "providerTakenCtr")),
                        "providerUsefulCtr": values.get(("stage_meta", stage, slot, "providerUsefulCtr")),
                        "altOrBasePred": values.get(("stage_meta", stage, slot, "altOrBasePred")),
                    }
                    table_way_match = (
                        meta["providerTableIdx"] == item["table"]
                        and meta["providerWayIdx"] == item["way"]
                    )
                    if table_way_match:
                        matches.append(meta)
                    if (
                        stage_valid == 1
                        and table_way_match
                        and meta["useProvider"] == 1
                        and meta["providerTakenCtr"] == item["observed_taken_ctr"]
                        and meta["providerUsefulCtr"] == item["observed_useful"]
                    ):
                        consumed.append(meta)
                if matches:
                    matches_by_stage[stage] = matches
                if consumed:
                    consumed_by_stage[stage] = consumed
            return matches_by_stage, consumed_by_stage

        def check_bad_meta_consumption():
            while pending_bad_meta_checks and pending_bad_meta_checks[0]["deadline"] < time:
                pending_bad_meta_checks.popleft()
            for item in list(pending_bad_meta_checks):
                if time < item["response_time"] or time > item["deadline"]:
                    continue
                _, consumed_by_stage = collect_stage_meta_matches(item)
                for stage, consumed in consumed_by_stage.items():
                    if stage in item["matched_stages"]:
                        continue
                    item["matched_stages"].add(stage)
                    counts["bad_read_stage_meta_consumed"] += 1
                    counts[f"bad_read_{stage}_meta_consumed"] += 1
                    if not item["any_consumed"]:
                        counts["bad_read_any_meta_consumed"] += 1
                        item["any_consumed"] = True
                    if len(first_bad_read_stage_meta_events) < 8:
                        first_bad_read_stage_meta_events.append({
                            **item["pair_event"],
                            "time": time,
                            "offset_from_bad_read_response": time - item["response_time"],
                            "stage": stage,
                            "read_time": item["read_time"],
                            "response_time": item["response_time"],
                            "channel": item["channel"],
                            "observed_taken_ctr": item["observed_taken_ctr"],
                            "observed_useful": item["observed_useful"],
                            "stage_meta_consumed_matches": consumed,
                        })

        def collect_reads_during_split():
            for table, ch in sorted(read_reqs):
                if values.get(("read_req", table, ch, "valid")) != 1:
                    continue
                set_idx = values.get(("read_req", table, ch, "setIdx"))
                bank_mask = values.get(("read_req", table, ch, "bankMask"))
                for pair in pending_pairs:
                    active = (
                        pair["entry_commit_time"] is not None
                        and pair["useful_commit_time"] is None
                        and time > pair["entry_commit_time"]
                    )
                    if (
                        active
                        and pair["table"] == table
                        and pair["setIdx"] == set_idx
                        and bit_is_set(bank_mask, pair["bank"])
                    ):
                        counts["reads_during_strict_split"] += 1
                        if pair["expected_useful"] == 1:
                            counts["reads_during_strict_split_expected_useful_1"] += 1
                        if len(first_reads_during_strict_split) < 8:
                            first_reads_during_strict_split.append({
                                "time": time,
                                "channel": ch,
                                "read_req_valid_path": key_to_path.get(("read_req", table, ch, "valid")),
                                "read_req_setIdx_path": key_to_path.get(("read_req", table, ch, "setIdx")),
                                "read_req_bankMask_path": key_to_path.get(("read_req", table, ch, "bankMask")),
                                **pair_event(pair, time),
                            })
                        pending_resp_checks.append({
                            "check_after": time + 1,
                            "read_time": time,
                            "channel": ch,
                            "pair": dict(pair),
                        })

        def collect_reads_near_split():
            if near_window <= 0:
                return
            for table, ch in sorted(read_reqs):
                if values.get(("read_req", table, ch, "valid")) != 1:
                    continue
                set_idx = values.get(("read_req", table, ch, "setIdx"))
                bank_mask = values.get(("read_req", table, ch, "bankMask"))
                for pair in pending_pairs:
                    split_time = pair.get("strict_split_time")
                    if split_time is None:
                        continue
                    if time < split_time or time > split_time + near_window:
                        continue
                    if pair["table"] != table or not bit_is_set(bank_mask, pair["bank"]):
                        continue
                    active = (
                        pair["entry_commit_time"] is not None
                        and pair["useful_commit_time"] is None
                        and time > pair["entry_commit_time"]
                    )
                    bank_event = {
                        "time": time,
                        "channel": ch,
                        "offset_from_split": time - split_time,
                        "split_active": active,
                        "read_setIdx": set_idx,
                        "read_req_valid_path": key_to_path.get(("read_req", table, ch, "valid")),
                        "read_req_setIdx_path": key_to_path.get(("read_req", table, ch, "setIdx")),
                        "read_req_bankMask_path": key_to_path.get(("read_req", table, ch, "bankMask")),
                        **pair_event(pair, time),
                    }
                    counts["near_split_bank_read_reqs"] += 1
                    if len(first_near_split_bank_read_reqs) < 16:
                        first_near_split_bank_read_reqs.append(bank_event)
                    if pair["setIdx"] == set_idx:
                        counts["near_split_read_reqs"] += 1
                        if len(first_near_split_read_reqs) < 16:
                            first_near_split_read_reqs.append(bank_event)

        def check_cycle():
            nonlocal last_checked
            if last_checked == time:
                return
            last_checked = time
            counts["timestamps"] += 1
            if values.get(("top", "reset")) == 1:
                return

            check_response_observations()
            check_bad_meta_consumption()
            collect_enqueues()
            entry_commits, useful_commits = collect_commits()
            apply_commits(entry_commits, useful_commits)
            collect_reads_during_split()
            collect_reads_near_split()

            while pending_pairs and time - pending_pairs[0]["enq_time"] > max_pair_age:
                pending_pairs.popleft()

        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line[0] == "#":
                check_cycle()
                time = int(line[1:])
                continue
            if line[0] in "01xz":
                keys = code_to_keys.get(line[1:])
                if keys:
                    value = base.parse_scalar(line[0])
                    for key in keys:
                        values[key] = value
                continue
            if line[0] in "bB":
                try:
                    bits, code = line[1:].split(None, 1)
                except ValueError:
                    continue
                keys = code_to_keys.get(code)
                if keys:
                    value = base.parse_vector(bits)
                    for key in keys:
                        values[key] = value
        check_cycle()

    return {
        "poc_status": "strict_split_reproduced" if counts["strict_split_intervals"] > 0 else "no_strict_split",
        "success_predicate": "Entry commit must be strictly earlier than the matching useful-counter commit after cycle-level coalescing.",
        "vcd_path": str(vcd_path),
        "counts": counts,
        "first_strict_split_events": first_strict_split_events,
        "first_same_cycle_events": first_same_cycle_events,
        "first_reads_during_strict_split": first_reads_during_strict_split,
        "first_split_read_responses": first_split_read_responses,
        "first_bad_read_events": first_bad_read_events,
        "first_bad_read_provider_meta_events": first_bad_read_provider_meta_events,
        "first_bad_read_stage_meta_events": first_bad_read_stage_meta_events,
        "first_late_useful_commit_events": first_late_useful_commit_events,
        "first_near_split_read_reqs": first_near_split_read_reqs,
        "first_near_split_bank_read_reqs": first_near_split_bank_read_reqs,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd")
    parser.add_argument("--json-out", required=True)
    parser.add_argument(
        "--max-pair-age",
        type=int,
        default=256,
        help="Maximum cycles to retain an entry/useful pair while looking for delayed useful commits.",
    )
    parser.add_argument(
        "--near-window",
        type=int,
        default=16,
        help="Cycles after a strict split to report same table/set/bank read requests, even after useful commits.",
    )
    parser.add_argument(
        "--meta-window",
        type=int,
        default=256,
        help="Cycles after a bad raw read response to look for matching to-FTQ/train TAGE metadata.",
    )
    args = parser.parse_args()
    result = monitor(
        args.vcd,
        max_pair_age=args.max_pair_age,
        near_window=args.near_window,
        meta_window=args.meta_window,
    )
    with open(args.json_out, "w") as out:
        json.dump(result, out, indent=2, sort_keys=True)
        out.write("\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["poc_status"] == "strict_split_reproduced" else 2


if __name__ == "__main__":
    raise SystemExit(main())
