xiangshan xiangshan-amo-fault-forward-miss reproducer
===================================================================================================================================

Issue: [BUG] A cross-16-byte load after a store-page-faulting AMO commits 0 instead of the stored 0x20008, losing store-to-load forwarding

Files: 10

Files
-----

TIMELINE.md
    Anchor window timeline (cycle, sample, t and observed signals).
    SHA-256: ccb50e4a95fa461a96491e312fa89dce174a265f6536aaa600c5ee3c4abbbf68

comparison.json
    Sanitized DUT-versus-reference comparison record.
    SHA-256: 3745d628c53874abd6ee69c5b8ab121fb2ea5a7bfdfe53d75d16dfc439d74aac

disassembly.txt
    Full objdump of the reproducer; header names prog.elf.
    SHA-256: f411053bd1b36f037d10ff60e8227309d83f783d2cba32826547c0d2a530d997

nemu_reftrace_excerpt.txt
    Reference-model (NEMU) trace excerpt for the same addresses.
    SHA-256: 8f4ca0d9514bdcc9ea9417f470f92fa76f49eaea2f201042a2f1dd11883aa992

oracle.md
    Reference-model (Spike) result, renamed from ORACLE.md.
    SHA-256: 480e5cf6c2f8a0394f7624d0af3a66040aed418e05c13c80c6b95fb22ead5181

prog.elf
    Reproducer ELF (binary, unmodified).
    SHA-256: 07e2d159ca9b47a097d3350a1c03d26f735360c4e3fba26437c76952c567b04a

signals.csv
    Signal samples for the same window as TIMELINE.md.
    SHA-256: 570e1a9dc7a11895aa395800852a7067f8746947f18a0e12983de09d4af3a323

sim.log
    Simulator log for the recorded run.
    SHA-256: 1f74106c696a85f10913f561f3f522c3120363106d50a446b904de0e84a75c30

wave.fst
    FST waveform covering the anchor window.
    SHA-256: 2d11008147e9c82900cde4d365187f07907ef5f48b9fafc71cda992b3f88280f

Reproduction summary
--------------------

- Run the supplied ELF `repro_amo_fault_clobber.elf` on the KMHv3 build with DiffTest against the bundled NEMU reference.
- Execute `amoxor.w s1,a3,(s1)` at `0x80002b5c` with `s1 = 0x20008` and observe the store/AMO page fault (`scause = 0x0f`, `sepc = 0x2b5c`, `stval = 0x20008`).
- Let the trap handler save `s1` with `sd s1,88(sp)` at `0x80002394` and reload it with `ld s1,88(sp)` at `0x80002494`.
- Compare the reloaded `s1` against the reference model; DiffTest stops at the mismatch.

Expected:
  The reload must return the stored value. NEMU, the bundled DiffTest reference, records the same address written and read back:

Observed:
  The DUT commits a stale zero for the reload:

  - the faulting AMO traps correctly (`scause = 0x0f`, `sepc = 0x2b5c`, `stval = 0x20008`)
  - the reload `ld s1,88(sp)` at `0xffffffffffe02494` writes `dst 09 (s1) = 0`
  - DiffTest reports `s1 different at pc = 0xffffffffffe02370, right = 0x0000000000020008, wrong = 0x0000000000000000`
  - the run ends on the cycle/instr limit at `pc = 0x2b96` (`instrCnt = 9,065`, `cycleCnt = 15,000`)
  - the FST trace was dumped for the failing window; the waveform has 0 X/Z samples on the listed signals

Notes
-----

- Full run manifests, code-evidence markdown, waveform analysis JSON, symbol tables, and raw memory images are omitted because their headers contain internal paths.
- Absolute paths in the remaining text files have been replaced by file names; the objdump header now names prog.elf.
