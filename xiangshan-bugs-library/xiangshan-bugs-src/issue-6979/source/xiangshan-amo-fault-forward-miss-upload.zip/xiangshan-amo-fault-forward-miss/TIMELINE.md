# Waveform timeline: xiangshan/xiangshan-amo-fault-forward-miss

- 波形：`waveform`
- 采样：clock=`None`，edge=`negedge`，xz_value=`0`
- 锚点：cycle 9086 / sample 236 / t=9086
- 锚点值：load_s0_vaddr=0x0、load_s0_valid=0、sq_mask_lower=1、sb_mask_lower=1、sq_mask_upper=1、intRf_valid=1、intRf_data=0x0、ldout_vaddr=0x3ffffffe650ca
- X/Z 样本数：load_s0_vaddr=0、load_s0_valid=0、sq_mask_lower=0、sb_mask_lower=0、sq_mask_upper=0、intRf_valid=0、intRf_data=0、ldout_vaddr=0

| cycle | sample | t | load_s0_vaddr | load_s0_valid | sq_mask_lower | sb_mask_lower | sq_mask_upper | intRf_valid | intRf_data | ldout_vaddr |
|---:|---:|---:|---|---|---|---|---|---|---|---|
| 9081 | 231 | 9081 | 0x0 | 0 | 0 | 0 | 0 | 0 | 0x0 | 0x3ffffffe08100 |
| 9082 | 232 | 9082 | 0x3ffffffe650ca | 1 | 0 | 0 | 0 | 0 | 0x0 | 0x3ffffffe08100 |
| 9083 | 233 | 9083 | 0x3ffffffe650d0 | 1 | 0 | 0 | 0 | 0 | 0x0 | 0x3ffffffe08100 |
| 9084 | 234 | 9084 | 0x0 | 0 | 0 | 0 | 0 | 0 | 0x0 | 0x3ffffffe08100 |
| 9085 | 235 | 9085 | 0x0 | 0 | 1 | 1 | 1 | 0 | 0x0 | 0x3ffffffe650ca |
| 9086 | 236 | 9086 | 0x0 | 0 | 1 | 1 | 1 | 1 | 0x0 | 0x3ffffffe650ca |
| 9087 | 237 | 9087 | 0x0 | 0 | 1 | 1 | 1 | 0 | 0x0 | 0x3ffffffe650d0 |
| 9088 | 238 | 9088 | 0x0 | 0 | 1 | 1 | 1 | 0 | 0x0 | 0x3ffffffe650d0 |
| 9089 | 239 | 9089 | 0x3ffffffe08100 | 1 | 1 | 1 | 1 | 0 | 0x0 | 0x3ffffffe650d0 |
| 9090 | 240 | 9090 | 0x0 | 0 | 1 | 1 | 1 | 0 | 0x0 | 0x3ffffffe650d0 |
| 9091 | 241 | 9091 | 0x0 | 0 | 0 | 0 | 0 | 0 | 0x0 | 0x3ffffffe650d0 |

## 说明

- 锚点条件：`[["intRf_valid", "eq", 1], ["ldout_vaddr", "eq", "0x3ffffffe650ca"], ["intRf_data", "eq", "0x0"]]`
- 缺陷：cross-16B load lower half loses store-to-load forwarding and commits stale 0
- 轨迹起点 cycle：8850；`anchor_cycle = trace_origin + anchor_sample_cycle`。
