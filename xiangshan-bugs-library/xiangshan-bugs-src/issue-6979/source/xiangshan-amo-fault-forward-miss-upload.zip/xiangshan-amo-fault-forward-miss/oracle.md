# 独立模型对照：NEMU DiffTest REF

## Spike：部分可用，但早于目标位置偏离

同一 ELF 交给 Spike 时，第一条 trap 是 `instruction_page_fault`（`epc=0x265c`），随后出现 `store_address_misaligned` 和多条 `illegal_instruction`。Spike 没有到达 `0x2b5c` 的故障 AMO。原因是该 ELF 依赖 XiangShan 的 PMA/PMP 和自建 trap 环境，Spike 的缺省映射不同。`spike-rerun.json` 保留全部首陷阱记录，不用作判定依据。

## 采用的差分 oracle

| 模型 | 结果 | 记录 |
| --- | --- | --- |
| NEMU（XiangShan `ready-to-run` bundled REF） | `s1=0x20008` | `run/stdout.log` |
| XiangShan DUT（`4cf8b8d4ae`） | `s1=0`，`pc=0xffffffffffe02370` | `run/stdout.log` |

DiffTest 的原话：

```text
s1 different at pc = 0xffffffffffe02370,
right = 0x0000000000020008, wrong = 0x0000000000000000
```

`right` 是 NEMU 的值。`wrong` 是 DUT 的值。

## NEMU 记录中的同地址 store/load

`nemu_reftrace_excerpt.txt`：

```text
mmu_write: vaddr 0xffffffffffe650ca, paddr 0x800650ca, len 8, data 0x20008
mmu_read:  vaddr 0xffffffffffe650ca, paddr 0x800650ca, rdata 0x20008
```

NEMU 对同一地址先写 `0x20008`，后读回 `0x20008`。这直接支持 Load Value Axiom 的期望值。

## QEMU

`qemu-system-riscv64 -M virt -bios none -kernel prog.elf` 启动并执行到 boot 代码，30 s 内无自检输出。该 ELF 依赖 XiangShan tohost/PMEM，QEMU 不能作为完成判据。

## 备注

- `prog.elf` 是 Issue 附件中的原始 ELF。原始源码未提供；`disassembly.txt` 和 `symbols.json` 来自该 ELF。
- 结论不依赖 AMO 的推测写回时序。handler 的 store 数据 `0x20008` 已证明架构 x9 未被改坏。
