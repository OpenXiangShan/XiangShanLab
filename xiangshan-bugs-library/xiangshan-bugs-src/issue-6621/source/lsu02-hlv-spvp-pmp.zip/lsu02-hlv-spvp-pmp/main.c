#include <klib.h>
#include <stdint.h>

/*
 * LSU-02: HLV/HLVX/HSV effective privilege is hstatus.SPVP, including the
 * final PMP check. M-mode HLV with SPVP=U must not bypass an unlocked
 * R=0 PMP the way a native M access would.
 */

#define CAUSE_LOAD_ACCESS_FAULT 5ull
#define PMP_A_NAPOT 0x18ull

static volatile uint64_t trap_count;
static volatile uint64_t trap_mcause;
static volatile uint64_t hlv_value;
static uint8_t target_page[4096] __attribute__((aligned(4096)));

__attribute__((naked, aligned(4))) void trap_entry(void) {
  asm volatile(
    "csrr t0, mcause\n\t"
    "la t5, trap_mcause\n\t"
    "sd t0, 0(t5)\n\t"
    "la t5, trap_count\n\t"
    "ld t6, 0(t5)\n\t"
    "addi t6, t6, 1\n\t"
    "sd t6, 0(t5)\n\t"
    "csrr t1, mepc\n\t"
    "addi t1, t1, 4\n\t"
    "csrw mepc, t1\n\t"
    "mret\n\t");
}

static inline uint32_t do_hlv_wu(uintptr_t address) {
  register uint64_t value asm("a0");
  register uintptr_t rs1 asm("a1") = address;
  /* hlv.wu a0, (a1) */
  asm volatile(".word 0x6815c573" : "=r"(value) : "r"(rs1) : "memory");
  return (uint32_t)value;
}

static inline uint64_t pmp_napot_4kb(uintptr_t base) {
  return (base + 2047ull) >> 2;
}

int main(void) {
  uint64_t old_pmpcfg0, old_pmpaddr0, old_hstatus;

  printf("lsu02-hlv-spvp-pmp start\n");
  asm volatile("csrw mtvec, %0" :: "r"(trap_entry) : "memory");

  target_page[0] = 0x11;
  target_page[1] = 0x22;
  target_page[2] = 0x33;
  target_page[3] = 0x44;

  asm volatile("csrr %0, 0x3a0" : "=r"(old_pmpcfg0));
  asm volatile("csrr %0, 0x3b0" : "=r"(old_pmpaddr0));
  asm volatile("csrr %0, 0x600" : "=r"(old_hstatus));

  /* Bare VS/G translation so VA is the physical page. */
  asm volatile("csrw 0x180, x0"); /* satp */
  asm volatile("csrw 0x280, x0"); /* vsatp */
  asm volatile("csrw 0x680, x0"); /* hgatp */
  asm volatile("sfence.vma" ::: "memory");

  /* Unlocked NAPOT 4KiB, R=W=X=0 over the target. */
  asm volatile("csrw 0x3b0, %0" :: "r"(pmp_napot_4kb((uintptr_t)target_page)) : "memory");
  asm volatile("csrw 0x3a0, %0" :: "r"((old_pmpcfg0 & ~0xffull) | PMP_A_NAPOT) : "memory");
  /* SPVP = U */
  asm volatile("csrw 0x600, %0" :: "r"(old_hstatus & ~(1ull << 8)) : "memory");
  asm volatile("fence rw, rw" ::: "memory");

  hlv_value = do_hlv_wu((uintptr_t)target_page);

  asm volatile("csrw 0x3a0, %0" :: "r"(old_pmpcfg0) : "memory");
  asm volatile("csrw 0x3b0, %0" :: "r"(old_pmpaddr0) : "memory");
  asm volatile("csrw 0x600, %0" :: "r"(old_hstatus) : "memory");

  printf("trap_count=%lu mcause=%lu hlv=0x%lx\n", trap_count, trap_mcause, hlv_value);

  if (trap_count == 0) {
    printf("FAIL lsu02 M-mode HLV bypassed unlocked PMP under SPVP=U\n");
    return 1;
  }
  if (trap_mcause != CAUSE_LOAD_ACCESS_FAULT) {
    printf("FAIL lsu02 unexpected HLV trap cause\n");
    return 1;
  }

  printf("lsu02-hlv-spvp-pmp pass\n");
  return 0;
}
