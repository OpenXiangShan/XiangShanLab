OUTPUT_ARCH("riscv")
ENTRY(_start)
SECTIONS {
  . = 0x80000000;
  .text.entry : { KEEP(*(.text.entry)) }
  . = 0x80000040;
  .text.target : { *(.text.target) }
  . = 0x80002000;
  .text.safe : { *(.text.safe) }
  . = 0x80003000;
  .data : { *(.data .data.* .sdata .sdata.*) }
  .bss (NOLOAD) : { *(.bss .bss.* COMMON) }
  /DISCARD/ : { *(.comment) *(.note*) *(.riscv.attributes) }
}
