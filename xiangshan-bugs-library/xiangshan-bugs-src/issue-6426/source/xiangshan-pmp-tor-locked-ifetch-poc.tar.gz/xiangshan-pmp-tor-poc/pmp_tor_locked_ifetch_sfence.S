# 用于上游报告的最小 PoC。
# Boot stub 先跳往安全代码区 0x80002000。安全代码在 M-mode 配置
# e1=L|TOR|---，范围 [0x80000000, 0x80001000)，然后在保护区外执行
# sfence.vma 与 fence.i，再跳回保护区内的 TARGET。
# 正确行为：TARGET 取指触发 Instruction Access Fault，mcause=1。
# 错误行为：TARGET 被执行，difftest 与 NEMU 发生 ABORT。
    .option norvc

    # emu bootrom 固定从 0x80000000 进入；配置 PMP 前先离开将被锁定的区间。
    .section .text.entry
    .globl _start
_start:
    j       SAFE

    # 该代码位于 0x80000040，属于最终锁定的 TOR deny 区间。
    .section .text.target
    .balign 4
TARGET:
    li      t1, 0x5a               # 若能执行到这里，说明取指被错误放行
    la      t2, RESBUF
    sd      t1, 8(t2)
    la      t3, FAIL
    jr      t3

    # 以下所有指令均位于 0x80002000 起的保护区外。
    .section .text.safe
    .balign 4
SAFE:
    la      t0, HAND
    csrw    mtvec, t0

    # e0=OFF；e1 的 TOR 下界为零、上界为 0x80001000。
    csrw    pmpaddr0, zero
    li      t1, 0x2000400          # pmpaddr1: 0x80001000
    csrw    pmpaddr1, t1
    li      t2, 0x8800             # e1: L=1, A=TOR, R=W=X=0
    csrw    pmpcfg0, t2

    # 两条同步指令均不在新拒绝范围内，排除 PMP 更新后的陈旧状态。
    sfence.vma zero, zero
    fence.i

    la      t3, RESBUF
    li      t4, 0x77
    sd      t4, 0(t3)              # mcause 槽
    li      t4, 0x66
    sd      t4, 8(t3)              # mepc 槽

    la      t4, TARGET
    jr      t4

RESUME:
    la      t3, RESBUF
    ld      t4, 0(t3)
    li      t5, 1
    bne     t4, t5, FAIL
    ld      t4, 8(t3)
    la      t5, TARGET
    bne     t4, t5, FAIL
    j       GOODTRAP

FAIL:
1:  addi    t6, t6, 0
    j       1b

    .balign 4
GOODTRAP:
    .word 0x0000006b

    .balign 4
HAND:
    la      a0, RESBUF
    csrr    a1, mcause
    sd      a1, 0(a0)
    csrr    a1, mepc
    sd      a1, 8(a0)
    la      a1, RESUME
    csrw    mepc, a1
    mret

    # 位于 0x80003000，在 TOR 上界之外。
    .section .data
    .balign 8
RESBUF: .space 32
