# 锁定 TOR PMP 取指 PoC

启动 stub 位于 `0x80000000`，先跳到保护范围外的 `0x80002000`。安全代码在 M-mode 配置 `pmpaddr0=0`、`pmpaddr1=0x2000400`，并把 entry 1 配置为 `L=1, A=TOR, R=W=X=0`。因此拒绝范围应为 `[0x80000000, 0x80001000)`；目标 `TARGET=0x80000040` 位于其中。

PMP 写后，PoC 在范围外执行 `sfence.vma x0,x0` 与 `fence.i`，随后跳至 `TARGET`。这排除了已知的 PMP 更新后地址翻译或 I-cache 陈旧解释。

## 运行

```sh
/路径/emu --dump-commit-trace -C 120000 \
  -i pmp_tor_locked_ifetch_sfence.elf \
  --diff /路径/riscv64-nemu-interpreter-so
```

压缩包已包含可直接运行的 ELF，无需重新构建。正确实现中，取 `TARGET` 时应产生 `mcause=1`，handler 记录 `mepc=0x80000040`，随后到达 GOODTRAP；当前 XiangShan 继续进入 `TARGET` 并进入 `FAIL`。

## 已附证据

`pmp_tor_match.csv` 是同一 ELF 的波形抽取。在 time 2304，entry 1 的 `A=TOR,L=1,X=0`、`pmpaddr0=0`、`pmpaddr1=0x2000400`，请求地址为 `0x80000040`，但总匹配结果为 0 且 `io_resp_instr=0`。按 TOR 定义，该地址应命中 entry 1 并因 `X=0` 触发取指访问 fault。
