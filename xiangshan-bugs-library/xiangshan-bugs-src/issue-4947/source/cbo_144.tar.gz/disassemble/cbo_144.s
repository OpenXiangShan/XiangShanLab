
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <_end_trap>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <_end_trap>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	6521                	lui	a0,0x8
    800001be:	8005051b          	addiw	a0,a0,-2048 # 7800 <_start-0x7fff8800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_end_prefix>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_end_prefix>:
    80000200:	00060797          	auipc	a5,0x60
    80000204:	e4078793          	addi	a5,a5,-448 # 80060040 <d_5_2>
    80000208:	17c1                	addi	a5,a5,-16
    8000020a:	a027b82f          	amomax.d	a6,sp,(a5)

000000008000020e <_l1>:
    8000020e:	03f697b7          	lui	a5,0x3f69
    80000212:	2657879b          	addiw	a5,a5,613 # 3f69265 <_start-0x7c096d9b>
    80000216:	07b2                	slli	a5,a5,0xc
    80000218:	1f178793          	addi	a5,a5,497
    8000021c:	07b6                	slli	a5,a5,0xd
    8000021e:	67d78793          	addi	a5,a5,1661
    80000222:	07b2                	slli	a5,a5,0xc
    80000224:	17fd                	addi	a5,a5,-1
    80000226:	0017a00f          	cbo.clean	(a5)

000000008000022a <_l2>:
    8000022a:	98804893          	xori	a7,zero,-1656

000000008000022e <_l3>:
    8000022e:	0000100f          	fence.i

0000000080000232 <_l4>:
    80000232:	00010217          	auipc	tp,0x10
    80000236:	e6e20213          	addi	tp,tp,-402 # 800100a0 <d_0_8>
    8000023a:	1261                	addi	tp,tp,-8 # fffffffffffffff8 <_end+0xffffffff7ff9fdf8>
    8000023c:	1002382f          	lr.d	a6,(tp)

0000000080000240 <_l5>:
    80000240:	74085ff3          	csrrwi	t6,mnscratch,16
    80000244:	857e                	mv	a0,t6

0000000080000246 <_l6>:
    80000246:	19a78153          	fdiv.s	ft2,fa5,fs10,rne

000000008000024a <_l7>:
    8000024a:	725d                	lui	tp,0xffff7
    8000024c:	84a2021b          	addiw	tp,tp,-1974 # ffffffffffff684a <_end+0xffffffff7ff9664a>
    80000250:	0012200f          	cbo.clean	(tp)

0000000080000254 <_l8>:
    80000254:	b1f50cc3          	fmadd.s	fs9,fa0,ft11,fs6,rne

0000000080000258 <_l9>:
    80000258:	fd09e9b7          	lui	s3,0xfd09e
    8000025c:	ae79899b          	addiw	s3,s3,-1305 # fffffffffd09dae7 <_end+0xffffffff7d03d8e7>
    80000260:	09b2                	slli	s3,s3,0xc
    80000262:	46398993          	addi	s3,s3,1123
    80000266:	09b2                	slli	s3,s3,0xc
    80000268:	bcf98993          	addi	s3,s3,-1073
    8000026c:	09b6                	slli	s3,s3,0xd
    8000026e:	8bc98993          	addi	s3,s3,-1860
    80000272:	8239e013          	prefetch.w	-2016(s3)

0000000080000276 <_l10>:
    80000276:	0c000293          	li	t0,192
    8000027a:	60a2aff3          	csrrs	t6,henvcfg,t0
    8000027e:	8afe                	mv	s5,t6
    80000280:	c07e                	sw	t6,0(sp)

0000000080000282 <_l11>:
    80000282:	fff0e8b7          	lui	a7,0xfff0e
    80000286:	7d18889b          	addiw	a7,a7,2001 # fffffffffff0e7d1 <_end+0xffffffff7feae5d1>
    8000028a:	08b2                	slli	a7,a7,0xc
    8000028c:	2e588893          	addi	a7,a7,741
    80000290:	08c6                	slli	a7,a7,0x11
    80000292:	abd88893          	addi	a7,a7,-1347
    80000296:	08b6                	slli	a7,a7,0xd
    80000298:	0048a00f          	cbo.zero	(a7)

000000008000029c <_l12>:
    8000029c:	00030d97          	auipc	s11,0x30
    800002a0:	f14d8d93          	addi	s11,s11,-236 # 800301b0 <d_2_25>
    800002a4:	1de1                	addi	s11,s11,-8
    800002a6:	a0ddb12f          	amomax.d	sp,a3,(s11)

00000000800002aa <_l13>:
    800002aa:	05583437          	lui	s0,0x5583
    800002ae:	c074041b          	addiw	s0,s0,-1017 # 5582c07 <_start-0x7aa7d3f9>
    800002b2:	0432                	slli	s0,s0,0xc
    800002b4:	cc340413          	addi	s0,s0,-829
    800002b8:	0432                	slli	s0,s0,0xc
    800002ba:	7ad40413          	addi	s0,s0,1965
    800002be:	0432                	slli	s0,s0,0xc
    800002c0:	147d                	addi	s0,s0,-1
    800002c2:	0044200f          	cbo.zero	(s0)

00000000800002c6 <_l14>:
    800002c6:	20031b53          	fsgnjn.s	fs6,ft6,ft0

00000000800002ca <_l15>:
    800002ca:	00060e17          	auipc	t3,0x60
    800002ce:	dc6e0e13          	addi	t3,t3,-570 # 80060090 <d_5_7>
    800002d2:	0e21                	addi	t3,t3,8
    800002d4:	a13e3aaf          	amomax.d	s5,s3,(t3)

00000000800002d8 <_l16>:
    800002d8:	78f5                	lui	a7,0xffffd
    800002da:	be18889b          	addiw	a7,a7,-1055 # ffffffffffffcbe1 <_end+0xffffffff7ff9c9e1>
    800002de:	f438e013          	prefetch.w	-192(a7)

00000000800002e2 <_l17>:
    800002e2:	3057f013          	andi	zero,a5,773

00000000800002e6 <_l18>:
    800002e6:	008dbab7          	lui	s5,0x8db
    800002ea:	4a7a8a9b          	addiw	s5,s5,1191 # 8db4a7 <_start-0x7f724b59>
    800002ee:	0ab2                	slli	s5,s5,0xc
    800002f0:	691a8a93          	addi	s5,s5,1681
    800002f4:	0abe                	slli	s5,s5,0xf
    800002f6:	371a8a93          	addi	s5,s5,881
    800002fa:	0ab2                	slli	s5,s5,0xc
    800002fc:	1afd                	addi	s5,s5,-1
    800002fe:	004aa00f          	cbo.zero	(s5)

0000000080000302 <_l19>:
    80000302:	003fa137          	lui	sp,0x3fa
    80000306:	91b1011b          	addiw	sp,sp,-1765 # 3f991b <_start-0x7fc066e5>
    8000030a:	0132                	slli	sp,sp,0xc
    8000030c:	ac510113          	addi	sp,sp,-1339
    80000310:	0136                	slli	sp,sp,0xd
    80000312:	cad10113          	addi	sp,sp,-851
    80000316:	00316013          	prefetch.w	0(sp)

000000008000031a <_l20>:
    8000031a:	00d4cbb7          	lui	s7,0xd4c
    8000031e:	6b1b8b9b          	addiw	s7,s7,1713 # d4c6b1 <_start-0x7f2b394f>
    80000322:	0bb2                	slli	s7,s7,0xc
    80000324:	d59b8b93          	addi	s7,s7,-679
    80000328:	0bb6                	slli	s7,s7,0xd
    8000032a:	829b8b93          	addi	s7,s7,-2007
    8000032e:	0bba                	slli	s7,s7,0xe
    80000330:	1bfd                	addi	s7,s7,-1
    80000332:	004ba00f          	cbo.zero	(s7)

0000000080000336 <_l21>:
    80000336:	a00097d3          	flt.s	a5,ft1,ft0

000000008000033a <_l22>:
    8000033a:	00642cb7          	lui	s9,0x642
    8000033e:	197c8c9b          	addiw	s9,s9,407 # 642197 <_start-0x7f9bde69>
    80000342:	0cba                	slli	s9,s9,0xe
    80000344:	479c8c93          	addi	s9,s9,1145
    80000348:	0cb2                	slli	s9,s9,0xc
    8000034a:	7e1c8c93          	addi	s9,s9,2017
    8000034e:	0cb6                	slli	s9,s9,0xd
    80000350:	1cfd                	addi	s9,s9,-1
    80000352:	004ca00f          	cbo.zero	(s9)

0000000080000356 <_l23>:
    80000356:	e0021053          	fclass.s	zero,ft4

000000008000035a <_l24>:
    8000035a:	fd72b437          	lui	s0,0xfd72b
    8000035e:	fbf4041b          	addiw	s0,s0,-65 # fffffffffd72afbf <_end+0xffffffff7d6cadbf>
    80000362:	0432                	slli	s0,s0,0xc
    80000364:	aed40413          	addi	s0,s0,-1299
    80000368:	0436                	slli	s0,s0,0xd
    8000036a:	c1140413          	addi	s0,s0,-1007
    8000036e:	0432                	slli	s0,s0,0xc
    80000370:	147d                	addi	s0,s0,-1
    80000372:	d0146013          	prefetch.r	-768(s0)

0000000080000376 <_l25>:
    80000376:	0150d21b          	srliw	tp,ra,0x15

000000008000037a <_l26>:
    8000037a:	00dc131b          	slliw	t1,s8,0xd

000000008000037e <_l27>:
    8000037e:	a0f11e53          	flt.s	t3,ft2,fa5

0000000080000382 <_l28>:
    80000382:	1d600093          	li	ra,470
    80000386:	0040a00f          	cbo.zero	(ra)

000000008000038a <_l29>:
    8000038a:	00030e17          	auipc	t3,0x30
    8000038e:	e16e0e13          	addi	t3,t3,-490 # 800301a0 <d_2_24>
    80000392:	8e72                	mv	t3,t3
    80000394:	092e33af          	amoswap.d	t2,s2,(t3)

0000000080000398 <_l30>:
    80000398:	fffc9c37          	lui	s8,0xfffc9
    8000039c:	2c3d                	addiw	s8,s8,15 # fffffffffffc900f <_end+0xffffffff7ff68e0f>
    8000039e:	0c3a                	slli	s8,s8,0xe
    800003a0:	81fc0c13          	addi	s8,s8,-2017
    800003a4:	0c3a                	slli	s8,s8,0xe
    800003a6:	c8fc0c13          	addi	s8,s8,-881
    800003aa:	0c46                	slli	s8,s8,0x11
    800003ac:	1c7d                	addi	s8,s8,-1
    800003ae:	000c200f          	cbo.inval	(s8)

00000000800003b2 <_l31>:
    800003b2:	00000817          	auipc	a6,0x0
    800003b6:	1f680813          	addi	a6,a6,502 # 800005a8 <_l68>
    800003ba:	01281983          	lh	s3,18(a6)

00000000800003be <_l32>:
    800003be:	00030217          	auipc	tp,0x30
    800003c2:	cf220213          	addi	tp,tp,-782 # 800300b0 <d_2_9>
    800003c6:	00025903          	lhu	s2,0(tp) # 0 <_start-0x80000000>

00000000800003ca <_l33>:
    800003ca:	06a00f13          	li	t5,106
    800003ce:	004f200f          	cbo.zero	(t5)

00000000800003d2 <_l34>:
    800003d2:	ff38a537          	lui	a0,0xff38a
    800003d6:	dcb5051b          	addiw	a0,a0,-565 # ffffffffff389dcb <_end+0xffffffff7f329bcb>
    800003da:	0532                	slli	a0,a0,0xc
    800003dc:	d6f50513          	addi	a0,a0,-657
    800003e0:	0532                	slli	a0,a0,0xc
    800003e2:	7f350513          	addi	a0,a0,2035
    800003e6:	0532                	slli	a0,a0,0xc
    800003e8:	00356013          	prefetch.w	0(a0)

00000000800003ec <_l35>:
    800003ec:	9002                	ebreak

00000000800003ee <_l36>:
    800003ee:	01d04637          	lui	a2,0x1d04
    800003f2:	94b6061b          	addiw	a2,a2,-1717 # 1d0394b <_start-0x7e2fc6b5>
    800003f6:	0632                	slli	a2,a2,0xc
    800003f8:	35d60613          	addi	a2,a2,861
    800003fc:	0636                	slli	a2,a2,0xd
    800003fe:	3df60613          	addi	a2,a2,991
    80000402:	0636                	slli	a2,a2,0xd
    80000404:	167d                	addi	a2,a2,-1
    80000406:	0016200f          	cbo.clean	(a2)

000000008000040a <_l37>:
    8000040a:	33c00693          	li	a3,828
    8000040e:	0026a00f          	cbo.flush	(a3)

0000000080000412 <_l38>:
    80000412:	007f3437          	lui	s0,0x7f3
    80000416:	2354041b          	addiw	s0,s0,565 # 7f3235 <_start-0x7f80cdcb>
    8000041a:	0432                	slli	s0,s0,0xc
    8000041c:	60740413          	addi	s0,s0,1543
    80000420:	0432                	slli	s0,s0,0xc
    80000422:	5d840413          	addi	s0,s0,1496
    80000426:	0014200f          	cbo.clean	(s0)

000000008000042a <_l39>:
    8000042a:	58078153          	fsqrt.s	ft2,fa5,rne

000000008000042e <_l40>:
    8000042e:	ffcd19b7          	lui	s3,0xffcd1
    80000432:	e4b9899b          	addiw	s3,s3,-437 # ffffffffffcd0e4b <_end+0xffffffff7fc70c4b>
    80000436:	09b2                	slli	s3,s3,0xc
    80000438:	a7598993          	addi	s3,s3,-1419
    8000043c:	09ba                	slli	s3,s3,0xe
    8000043e:	36f98993          	addi	s3,s3,879
    80000442:	09b6                	slli	s3,s3,0xd
    80000444:	19fd                	addi	s3,s3,-1
    80000446:	0009a00f          	cbo.inval	(s3)

000000008000044a <_l41>:
    8000044a:	fd09e237          	lui	tp,0xfd09e
    8000044e:	ae72021b          	addiw	tp,tp,-1305 # fffffffffd09dae7 <_end+0xffffffff7d03d8e7>
    80000452:	0232                	slli	tp,tp,0xc
    80000454:	46320213          	addi	tp,tp,1123 # 463 <_start-0x7ffffb9d>
    80000458:	0232                	slli	tp,tp,0xc
    8000045a:	bcf20213          	addi	tp,tp,-1073 # fffffffffffffbcf <_end+0xffffffff7ff9f9cf>
    8000045e:	0236                	slli	tp,tp,0xd
    80000460:	a7c20213          	addi	tp,tp,-1412 # fffffffffffffa7c <_end+0xffffffff7ff9f87c>
    80000464:	0002200f          	cbo.inval	(tp)

0000000080000468 <_l42>:
    80000468:	87b54e37          	lui	t3,0x87b54

000000008000046c <_l43>:
    8000046c:	007f37b7          	lui	a5,0x7f3
    80000470:	2357879b          	addiw	a5,a5,565 # 7f3235 <_start-0x7f80cdcb>
    80000474:	07b2                	slli	a5,a5,0xc
    80000476:	68378793          	addi	a5,a5,1667
    8000047a:	07b2                	slli	a5,a5,0xc
    8000047c:	c1478793          	addi	a5,a5,-1004
    80000480:	0007a00f          	cbo.inval	(a5)

0000000080000484 <_l44>:
    80000484:	d0100e53          	fcvt.s.wu	ft8,zero,rne

0000000080000488 <_l45>:
    80000488:	11500a93          	li	s5,277
    8000048c:	004aa00f          	cbo.zero	(s5)

0000000080000490 <_l46>:
    80000490:	bc082d13          	slti	s10,a6,-1088

0000000080000494 <_l47>:
    80000494:	00010a17          	auipc	s4,0x10
    80000498:	c4ca0a13          	addi	s4,s4,-948 # 800100e0 <d_0_12>
    8000049c:	014a2f83          	lw	t6,20(s4)

00000000800004a0 <_l48>:
    800004a0:	ffbb9bb7          	lui	s7,0xffbb9
    800004a4:	68fb8b9b          	addiw	s7,s7,1679 # ffffffffffbb968f <_end+0xffffffff7fb5948f>
    800004a8:	0bb6                	slli	s7,s7,0xd
    800004aa:	dafb8b93          	addi	s7,s7,-593
    800004ae:	0bb6                	slli	s7,s7,0xd
    800004b0:	0ffb8b93          	addi	s7,s7,255
    800004b4:	0bb6                	slli	s7,s7,0xd
    800004b6:	1bfd                	addi	s7,s7,-1
    800004b8:	002ba00f          	cbo.flush	(s7)

00000000800004bc <_l49>:
    800004bc:	3620e163          	bltu	ra,sp,8000081e <_l108>

00000000800004c0 <_l50>:
    800004c0:	00030997          	auipc	s3,0x30
    800004c4:	c1098993          	addi	s3,s3,-1008 # 800300d0 <d_2_11>
    800004c8:	89ce                	mv	s3,s3
    800004ca:	a099a8af          	amomax.w	a7,s1,(s3)

00000000800004ce <_l51>:
    800004ce:	00010217          	auipc	tp,0x10
    800004d2:	ca220213          	addi	tp,tp,-862 # 80010170 <d_0_21>
    800004d6:	1221                	addi	tp,tp,-24 # ffffffffffffffe8 <_end+0xffffffff7ff9fde8>
    800004d8:	01d2282f          	amoadd.w	a6,t4,(tp)

00000000800004dc <_l52>:
    800004dc:	00060817          	auipc	a6,0x60
    800004e0:	be480813          	addi	a6,a6,-1052 # 800600c0 <d_5_10>
    800004e4:	00b80023          	sb	a1,0(a6)

00000000800004e8 <_l53>:
    800004e8:	2047acd3          	fsgnjx.s	fs9,fa5,ft4

00000000800004ec <_l54>:
    800004ec:	000880b7          	lui	ra,0x88
    800004f0:	efb0809b          	addiw	ra,ra,-261 # 87efb <_start-0x7ff78105>
    800004f4:	00b2                	slli	ra,ra,0xc
    800004f6:	69f08093          	addi	ra,ra,1695
    800004fa:	0000e013          	prefetch.i	0(ra)

00000000800004fe <_l55>:
    800004fe:	7679                	lui	a2,0xffffe
    80000500:	04a6061b          	addiw	a2,a2,74 # ffffffffffffe04a <_end+0xffffffff7ff9de4a>
    80000504:	42366013          	prefetch.w	1056(a2)

0000000080000508 <_l56>:
    80000508:	0ff0000f          	fence

000000008000050c <_l57>:
    8000050c:	ffee19b7          	lui	s3,0xffee1
    80000510:	27f9899b          	addiw	s3,s3,639 # ffffffffffee127f <_end+0xffffffff7fe8107f>
    80000514:	09b2                	slli	s3,s3,0xc
    80000516:	d3b98993          	addi	s3,s3,-709
    8000051a:	09b6                	slli	s3,s3,0xd
    8000051c:	79398993          	addi	s3,s3,1939
    80000520:	09ba                	slli	s3,s3,0xe
    80000522:	19fd                	addi	s3,s3,-1
    80000524:	0029a00f          	cbo.flush	(s3)

0000000080000528 <_l58>:
    80000528:	20bb2cd3          	fsgnjx.s	fs9,fs6,fa1

000000008000052c <_l59>:
    8000052c:	fc4979b7          	lui	s3,0xfc497
    80000530:	f5f9899b          	addiw	s3,s3,-161 # fffffffffc496f5f <_end+0xffffffff7c436d5f>
    80000534:	09b2                	slli	s3,s3,0xc
    80000536:	b4998993          	addi	s3,s3,-1207
    8000053a:	09b2                	slli	s3,s3,0xc
    8000053c:	2f998993          	addi	s3,s3,761
    80000540:	09b6                	slli	s3,s3,0xd
    80000542:	19fd                	addi	s3,s3,-1
    80000544:	fc39e013          	prefetch.w	-64(s3)

0000000080000548 <_l60>:
    80000548:	68500913          	li	s2,1669
    8000054c:	0049200f          	cbo.zero	(s2)

0000000080000550 <_l61>:
    80000550:	fe2b7c37          	lui	s8,0xfe2b7
    80000554:	f3dc0c1b          	addiw	s8,s8,-195 # fffffffffe2b6f3d <_end+0xffffffff7e256d3d>
    80000558:	0c32                	slli	s8,s8,0xc
    8000055a:	b5fc0c13          	addi	s8,s8,-1185
    8000055e:	0c3a                	slli	s8,s8,0xe
    80000560:	a25c0c13          	addi	s8,s8,-1499
    80000564:	0c32                	slli	s8,s8,0xc
    80000566:	1c7d                	addi	s8,s8,-1
    80000568:	004c200f          	cbo.zero	(s8)

000000008000056c <_l62>:
    8000056c:	00020817          	auipc	a6,0x20
    80000570:	ac480813          	addi	a6,a6,-1340 # 80020030 <d_1_1>
    80000574:	fe382627          	fsw	ft3,-20(a6)

0000000080000578 <_l63>:
    80000578:	00117bb7          	lui	s7,0x117
    8000057c:	4ffb8b9b          	addiw	s7,s7,1279 # 1174ff <_start-0x7fee8b01>
    80000580:	0bca                	slli	s7,s7,0x12
    80000582:	231b8b93          	addi	s7,s7,561
    80000586:	0bb2                	slli	s7,s7,0xc
    80000588:	b3db8b93          	addi	s7,s7,-1219
    8000058c:	0bb2                	slli	s7,s7,0xc
    8000058e:	1bfd                	addi	s7,s7,-1
    80000590:	9a1be013          	prefetch.r	-1632(s7)

0000000080000594 <_l64>:
    80000594:	0ff0000f          	fence

0000000080000598 <_l65>:
    80000598:	400b5093          	srai	ra,s6,0x0

000000008000059c <_l66>:
    8000059c:	22c00b13          	li	s6,556
    800005a0:	001b200f          	cbo.clean	(s6)

00000000800005a4 <_l67>:
    800005a4:	00c5539b          	srliw	t2,a0,0xc

00000000800005a8 <_l68>:
    800005a8:	52c00d13          	li	s10,1324
    800005ac:	143d6013          	prefetch.w	320(s10)

00000000800005b0 <_l69>:
    800005b0:	7f61                	lui	t5,0xffff8
    800005b2:	ea1f0f1b          	addiw	t5,t5,-351 # ffffffffffff7ea1 <_end+0xffffffff7ff97ca1>
    800005b6:	0f46                	slli	t5,t5,0x11
    800005b8:	af7f0f13          	addi	t5,t5,-1289
    800005bc:	0f32                	slli	t5,t5,0xc
    800005be:	25ff0f13          	addi	t5,t5,607
    800005c2:	0f3e                	slli	t5,t5,0xf
    800005c4:	001f200f          	cbo.clean	(t5)

00000000800005c8 <_l70>:
    800005c8:	7569                	lui	a0,0xffffa
    800005ca:	7aa5051b          	addiw	a0,a0,1962 # ffffffffffffa7aa <_end+0xffffffff7ff9a5aa>
    800005ce:	84156013          	prefetch.r	-1984(a0)

00000000800005d2 <_l71>:
    800005d2:	018553bb          	srlw	t2,a0,s8

00000000800005d6 <_l72>:
    800005d6:	0007fab7          	lui	s5,0x7f
    800005da:	323a8a9b          	addiw	s5,s5,803 # 7f323 <_start-0x7ff80cdd>
    800005de:	0ab6                	slli	s5,s5,0xd
    800005e0:	7cfa8a93          	addi	s5,s5,1999
    800005e4:	0abe                	slli	s5,s5,0xf
    800005e6:	6afa8a93          	addi	s5,s5,1711
    800005ea:	7c0ae013          	prefetch.i	1984(s5)

00000000800005ee <_l73>:
    800005ee:	003fa7b7          	lui	a5,0x3fa
    800005f2:	91b7879b          	addiw	a5,a5,-1765 # 3f991b <_start-0x7fc066e5>
    800005f6:	07b2                	slli	a5,a5,0xc
    800005f8:	acb78793          	addi	a5,a5,-1333
    800005fc:	07b6                	slli	a5,a5,0xd
    800005fe:	26978793          	addi	a5,a5,617
    80000602:	8417e013          	prefetch.r	-1984(a5)

0000000080000606 <_l74>:
    80000606:	00020417          	auipc	s0,0x20
    8000060a:	a8a40413          	addi	s0,s0,-1398 # 80020090 <d_1_7>
    8000060e:	0441                	addi	s0,s0,16
    80000610:	c1942a2f          	amominu.w	s4,s9,(s0)

0000000080000614 <_l75>:
    80000614:	5eb00493          	li	s1,1515
    80000618:	0014a00f          	cbo.clean	(s1)

000000008000061c <_l76>:
    8000061c:	00030617          	auipc	a2,0x30
    80000620:	b7460613          	addi	a2,a2,-1164 # 80030190 <d_2_23>
    80000624:	1661                	addi	a2,a2,-8
    80000626:	ffe005b7          	lui	a1,0xffe00
    8000062a:	8e2d                	xor	a2,a2,a1
    8000062c:	40b6332f          	amoor.d	t1,a1,(a2)

0000000080000630 <_l77>:
    80000630:	d03a00d3          	fcvt.s.lu	ft1,s4,rne

0000000080000634 <_l78>:
    80000634:	6de00393          	li	t2,1758
    80000638:	4613e013          	prefetch.r	1120(t2)

000000008000063c <_l79>:
    8000063c:	34e0096f          	jal	s2,8000098a <_l136>

0000000080000640 <_l80>:
    80000640:	fc5005b7          	lui	a1,0xfc500
    80000644:	3b15859b          	addiw	a1,a1,945 # fffffffffc5003b1 <_end+0xffffffff7c4a01b1>
    80000648:	05b2                	slli	a1,a1,0xc
    8000064a:	1a558593          	addi	a1,a1,421
    8000064e:	05b6                	slli	a1,a1,0xd
    80000650:	eed58593          	addi	a1,a1,-275
    80000654:	05b2                	slli	a1,a1,0xc
    80000656:	0585                	addi	a1,a1,1
    80000658:	0015e013          	prefetch.r	0(a1)

000000008000065c <_l81>:
    8000065c:	00030417          	auipc	s0,0x30
    80000660:	a0440413          	addi	s0,s0,-1532 # 80030060 <d_2_4>
    80000664:	01043423          	sd	a6,8(s0)

0000000080000668 <_l82>:
    80000668:	00050197          	auipc	gp,0x50
    8000066c:	ae818193          	addi	gp,gp,-1304 # 80050150 <d_4_19>
    80000670:	ffe00bb7          	lui	s7,0xffe00
    80000674:	0171c1b3          	xor	gp,gp,s7
    80000678:	0171a023          	sw	s7,0(gp)

000000008000067c <_l83>:
    8000067c:	fd09e4b7          	lui	s1,0xfd09e
    80000680:	ae74849b          	addiw	s1,s1,-1305 # fffffffffd09dae7 <_end+0xffffffff7d03d8e7>
    80000684:	04b2                	slli	s1,s1,0xc
    80000686:	46348493          	addi	s1,s1,1123
    8000068a:	04b2                	slli	s1,s1,0xc
    8000068c:	bcf48493          	addi	s1,s1,-1073
    80000690:	04b6                	slli	s1,s1,0xd
    80000692:	f2548493          	addi	s1,s1,-219
    80000696:	1414e013          	prefetch.r	320(s1)

000000008000069a <_l84>:
    8000069a:	e00e8353          	fmv.x.w	t1,ft9

000000008000069e <_l85>:
    8000069e:	fea2e337          	lui	t1,0xfea2e
    800006a2:	8153031b          	addiw	t1,t1,-2027 # fffffffffea2d815 <_end+0xffffffff7e9cd615>
    800006a6:	0332                	slli	t1,t1,0xc
    800006a8:	e1530313          	addi	t1,t1,-491
    800006ac:	0332                	slli	t1,t1,0xc
    800006ae:	ead30313          	addi	t1,t1,-339
    800006b2:	033a                	slli	t1,t1,0xe
    800006b4:	e3a30313          	addi	t1,t1,-454
    800006b8:	35631ff3          	csrrw	t6,mireg5,t1
    800006bc:	84fe                	mv	s1,t6

00000000800006be <_l86>:
    800006be:	001fdf37          	lui	t5,0x1fd
    800006c2:	c8df0f1b          	addiw	t5,t5,-883 # 1fcc8d <_start-0x7fe03373>
    800006c6:	0f3a                	slli	t5,t5,0xe
    800006c8:	e79f0f13          	addi	t5,t5,-391
    800006cc:	0f32                	slli	t5,t5,0xc
    800006ce:	d69f0f13          	addi	t5,t5,-663
    800006d2:	000f6013          	prefetch.i	0(t5)

00000000800006d6 <_l87>:
    800006d6:	7b7d                	lui	s6,0xfffff
    800006d8:	b31b0b1b          	addiw	s6,s6,-1231 # ffffffffffffeb31 <_end+0xffffffff7ff9e931>
    800006dc:	b63b6013          	prefetch.w	-1184(s6)

00000000800006e0 <_l88>:
    800006e0:	00e30cb7          	lui	s9,0xe30
    800006e4:	9a7c8c9b          	addiw	s9,s9,-1625 # e2f9a7 <_start-0x7f1d0659>
    800006e8:	0cb2                	slli	s9,s9,0xc
    800006ea:	79fc8c93          	addi	s9,s9,1951
    800006ee:	0cb2                	slli	s9,s9,0xc
    800006f0:	0cbd                	addi	s9,s9,15
    800006f2:	0cba                	slli	s9,s9,0xe
    800006f4:	000ca00f          	cbo.inval	(s9)

00000000800006f8 <_l89>:
    800006f8:	00000c17          	auipc	s8,0x0
    800006fc:	4b8c0c13          	addi	s8,s8,1208 # 80000bb0 <_l179>
    80000700:	000c0d67          	jalr	s10,s8

0000000080000704 <_l90>:
    80000704:	7de9                	lui	s11,0xffffa
    80000706:	8edd8d9b          	addiw	s11,s11,-1811 # ffffffffffff98ed <_end+0xffffffff7ff996ed>
    8000070a:	001da00f          	cbo.clean	(s11)

000000008000070e <_l91>:
    8000070e:	50000d13          	li	s10,1280
    80000712:	000d200f          	cbo.inval	(s10)

0000000080000716 <_l92>:
    80000716:	000809b7          	lui	s3,0x80
    8000071a:	5c39899b          	addiw	s3,s3,1475 # 805c3 <_start-0x7ff7fa3d>
    8000071e:	09b2                	slli	s3,s3,0xc
    80000720:	73f98993          	addi	s3,s3,1855
    80000724:	6009e013          	prefetch.i	1536(s3)

0000000080000728 <_l93>:
    80000728:	3fa00a13          	li	s4,1018
    8000072c:	fa1a6013          	prefetch.r	-96(s4)

0000000080000730 <_l94>:
    80000730:	7571                	lui	a0,0xffffc
    80000732:	c055051b          	addiw	a0,a0,-1019 # ffffffffffffbc05 <_end+0xffffffff7ff9ba05>
    80000736:	0015200f          	cbo.clean	(a0)

000000008000073a <_l95>:
    8000073a:	018b5bb7          	lui	s7,0x18b5
    8000073e:	3dfb8b9b          	addiw	s7,s7,991 # 18b53df <_start-0x7e74ac21>
    80000742:	0bb6                	slli	s7,s7,0xd
    80000744:	d61b8b93          	addi	s7,s7,-671
    80000748:	0bb6                	slli	s7,s7,0xd
    8000074a:	335b8b93          	addi	s7,s7,821
    8000074e:	0bb2                	slli	s7,s7,0xc
    80000750:	1bfd                	addi	s7,s7,-1
    80000752:	543be013          	prefetch.w	1344(s7)

0000000080000756 <_l96>:
    80000756:	fff50537          	lui	a0,0xfff50
    8000075a:	0515051b          	addiw	a0,a0,81 # fffffffffff50051 <_end+0xffffffff7feefe51>
    8000075e:	053a                	slli	a0,a0,0xe
    80000760:	6c550513          	addi	a0,a0,1733
    80000764:	053a                	slli	a0,a0,0xe
    80000766:	0c950513          	addi	a0,a0,201
    8000076a:	0532                	slli	a0,a0,0xc
    8000076c:	0505                	addi	a0,a0,1
    8000076e:	0025200f          	cbo.flush	(a0)

0000000080000772 <_l97>:
    80000772:	12d58073          	sfence.vma	a1,a3

0000000080000776 <_l98>:
    80000776:	fa13b237          	lui	tp,0xfa13b
    8000077a:	5cf2021b          	addiw	tp,tp,1487 # fffffffffa13b5cf <_end+0xffffffff7a0db3cf>
    8000077e:	0232                	slli	tp,tp,0xc
    80000780:	8c520213          	addi	tp,tp,-1851 # fffffffffffff8c5 <_end+0xffffffff7ff9f6c5>
    80000784:	0232                	slli	tp,tp,0xc
    80000786:	79d20213          	addi	tp,tp,1949 # 79d <_start-0x7ffff863>
    8000078a:	0232                	slli	tp,tp,0xc
    8000078c:	6fc20213          	addi	tp,tp,1788 # 6fc <_start-0x7ffff904>
    80000790:	0012200f          	cbo.clean	(tp)

0000000080000794 <_l99>:
    80000794:	b851074b          	fnmsub.s	fa4,ft2,ft5,fs7,rne

0000000080000798 <_l100>:
    80000798:	00040517          	auipc	a0,0x40
    8000079c:	92850513          	addi	a0,a0,-1752 # 800400c0 <d_3_10>
    800007a0:	1521                	addi	a0,a0,-24
    800007a2:	60a522af          	amoand.w	t0,a0,(a0)

00000000800007a6 <_l101>:
    800007a6:	004374b7          	lui	s1,0x437
    800007aa:	db54849b          	addiw	s1,s1,-587 # 436db5 <_start-0x7fbc924b>
    800007ae:	04b2                	slli	s1,s1,0xc
    800007b0:	f8b48493          	addi	s1,s1,-117
    800007b4:	04b6                	slli	s1,s1,0xd
    800007b6:	4bb48493          	addi	s1,s1,1211
    800007ba:	04be                	slli	s1,s1,0xf
    800007bc:	14fd                	addi	s1,s1,-1
    800007be:	0044a00f          	cbo.zero	(s1)

00000000800007c2 <_l102>:
    800007c2:	fa13beb7          	lui	t4,0xfa13b
    800007c6:	5cfe8e9b          	addiw	t4,t4,1487 # fffffffffa13b5cf <_end+0xffffffff7a0db3cf>
    800007ca:	0eb2                	slli	t4,t4,0xc
    800007cc:	8c5e8e93          	addi	t4,t4,-1851
    800007d0:	0eb2                	slli	t4,t4,0xc
    800007d2:	79de8e93          	addi	t4,t4,1949
    800007d6:	0eb2                	slli	t4,t4,0xc
    800007d8:	3bce8e93          	addi	t4,t4,956
    800007dc:	000ea00f          	cbo.inval	(t4)

00000000800007e0 <_l103>:
    800007e0:	d0018dd3          	fcvt.s.w	fs11,gp,rne

00000000800007e4 <_l104>:
    800007e4:	37700993          	li	s3,887
    800007e8:	0009a00f          	cbo.inval	(s3)

00000000800007ec <_l105>:
    800007ec:	00020297          	auipc	t0,0x20
    800007f0:	8a428293          	addi	t0,t0,-1884 # 80020090 <d_1_7>
    800007f4:	8296                	mv	t0,t0
    800007f6:	19e2ac2f          	sc.w	s8,t5,(t0)

00000000800007fa <_l106>:
    800007fa:	033a7e37          	lui	t3,0x33a7
    800007fe:	6f5e0e1b          	addiw	t3,t3,1781 # 33a76f5 <_start-0x7cc5890b>
    80000802:	0e36                	slli	t3,t3,0xd
    80000804:	0e7d                	addi	t3,t3,31
    80000806:	0e32                	slli	t3,t3,0xc
    80000808:	2bbe0e13          	addi	t3,t3,699
    8000080c:	0e32                	slli	t3,t3,0xc
    8000080e:	002e200f          	cbo.flush	(t3)

0000000080000812 <_l107>:
    80000812:	7fff1eb7          	lui	t4,0x7fff1
    80000816:	35ce8e9b          	addiw	t4,t4,860 # 7fff135c <_start-0xeca4>
    8000081a:	000ee013          	prefetch.i	0(t4)

000000008000081e <_l108>:
    8000081e:	00060a97          	auipc	s5,0x60
    80000822:	912a8a93          	addi	s5,s5,-1774 # 80060130 <d_5_17>
    80000826:	1ae1                	addi	s5,s5,-8
    80000828:	c11ab8af          	amominu.d	a7,a7,(s5)

000000008000082c <_l109>:
    8000082c:	000806b7          	lui	a3,0x80
    80000830:	26ad                	addiw	a3,a3,11 # 8000b <_start-0x7ff7fff5>
    80000832:	06b2                	slli	a3,a3,0xc
    80000834:	17968693          	addi	a3,a3,377
    80000838:	4806e013          	prefetch.i	1152(a3)

000000008000083c <_l110>:
    8000083c:	00020617          	auipc	a2,0x20
    80000840:	97460613          	addi	a2,a2,-1676 # 800201b0 <d_1_25>
    80000844:	fec62d87          	flw	fs11,-20(a2)

0000000080000848 <_l111>:
    80000848:	0005c437          	lui	s0,0x5c
    8000084c:	99d4041b          	addiw	s0,s0,-1635 # 5b99d <_start-0x7ffa4663>
    80000850:	043e                	slli	s0,s0,0xf
    80000852:	71f40413          	addi	s0,s0,1823
    80000856:	0432                	slli	s0,s0,0xc
    80000858:	0bc40413          	addi	s0,s0,188
    8000085c:	0024200f          	cbo.flush	(s0)

0000000080000860 <_l112>:
    80000860:	00030c97          	auipc	s9,0x30
    80000864:	860c8c93          	addi	s9,s9,-1952 # 800300c0 <d_2_10>
    80000868:	0cf1                	addi	s9,s9,28
    8000086a:	411cac2f          	amoor.w	s8,a7,(s9)

000000008000086e <_l113>:
    8000086e:	e00b92d3          	fclass.s	t0,fs7

0000000080000872 <_l114>:
    80000872:	037c2a37          	lui	s4,0x37c2
    80000876:	78da0a1b          	addiw	s4,s4,1933 # 37c278d <_start-0x7c83d873>
    8000087a:	0a32                	slli	s4,s4,0xc
    8000087c:	dc3a0a13          	addi	s4,s4,-573
    80000880:	0a32                	slli	s4,s4,0xc
    80000882:	527a0a13          	addi	s4,s4,1319
    80000886:	0a32                	slli	s4,s4,0xc
    80000888:	000a200f          	cbo.inval	(s4)

000000008000088c <_l115>:
    8000088c:	00040bb7          	lui	s7,0x40
    80000890:	2b9d                	addiw	s7,s7,7 # 40007 <_start-0x7ffbfff9>
    80000892:	0bb6                	slli	s7,s7,0xd
    80000894:	000be013          	prefetch.i	0(s7)

0000000080000898 <_l116>:
    80000898:	00000797          	auipc	a5,0x0
    8000089c:	9ea78793          	addi	a5,a5,-1558 # 80000282 <_l11>
    800008a0:	ffc7e383          	lwu	t2,-4(a5)

00000000800008a4 <_l117>:
    800008a4:	003e3c37          	lui	s8,0x3e3
    800008a8:	4abc0c1b          	addiw	s8,s8,1195 # 3e34ab <_start-0x7fc1cb55>
    800008ac:	0c3a                	slli	s8,s8,0xe
    800008ae:	0c25                	addi	s8,s8,9
    800008b0:	0c3e                	slli	s8,s8,0xf
    800008b2:	d2fc0c13          	addi	s8,s8,-721
    800008b6:	0c32                	slli	s8,s8,0xc
    800008b8:	aaec0c13          	addi	s8,s8,-1362
    800008bc:	001c200f          	cbo.clean	(s8)

00000000800008c0 <_l118>:
    800008c0:	000801b7          	lui	gp,0x80
    800008c4:	218d                	addiw	gp,gp,3 # 80003 <_start-0x7ff7fffd>
    800008c6:	01b2                	slli	gp,gp,0xc
    800008c8:	9a01e013          	prefetch.i	-1632(gp)

00000000800008cc <_l119>:
    800008cc:	015dd993          	srli	s3,s11,0x15

00000000800008d0 <_l120>:
    800008d0:	01e0f113          	andi	sp,ra,30

00000000800008d4 <_l121>:
    800008d4:	ed744e13          	xori	t3,s0,-297

00000000800008d8 <_l122>:
    800008d8:	00010a97          	auipc	s5,0x10
    800008dc:	828a8a93          	addi	s5,s5,-2008 # 80010100 <d_0_14>
    800008e0:	1aa1                	addi	s5,s5,-24
    800008e2:	807abc2f          	amomin.d	s8,t2,(s5)

00000000800008e6 <_l123>:
    800008e6:	0001fa17          	auipc	s4,0x1f
    800008ea:	76aa0a13          	addi	s4,s4,1898 # 80020050 <d_1_3>
    800008ee:	8a52                	mv	s4,s4
    800008f0:	002a3eaf          	amoadd.d	t4,sp,(s4)

00000000800008f4 <_l124>:
    800008f4:	12d00413          	li	s0,301
    800008f8:	0024200f          	cbo.flush	(s0)

00000000800008fc <_l125>:
    800008fc:	d0338353          	fcvt.s.lu	ft6,t2,rne

0000000080000900 <_l126>:
    80000900:	0e800cef          	jal	s9,800009e8 <_l142>

0000000080000904 <_l127>:
    80000904:	79f1                	lui	s3,0xffffc
    80000906:	7449899b          	addiw	s3,s3,1860 # ffffffffffffc744 <_end+0xffffffff7ff9c544>
    8000090a:	0049a00f          	cbo.zero	(s3)

000000008000090e <_l128>:
    8000090e:	fff13ab7          	lui	s5,0xfff13
    80000912:	acfa8a9b          	addiw	s5,s5,-1329 # fffffffffff12acf <_end+0xffffffff7feb28cf>
    80000916:	0ab2                	slli	s5,s5,0xc
    80000918:	ac3a8a93          	addi	s5,s5,-1341
    8000091c:	0ab2                	slli	s5,s5,0xc
    8000091e:	321a8a93          	addi	s5,s5,801
    80000922:	0ac6                	slli	s5,s5,0x11
    80000924:	657a8a93          	addi	s5,s5,1623
    80000928:	303ae013          	prefetch.w	768(s5)

000000008000092c <_l129>:
    8000092c:	001fd237          	lui	tp,0x1fd
    80000930:	c8d2021b          	addiw	tp,tp,-883 # 1fcc8d <_start-0x7fe03373>
    80000934:	0232                	slli	tp,tp,0xc
    80000936:	04f20213          	addi	tp,tp,79 # 4f <_start-0x7fffffb1>
    8000093a:	023a                	slli	tp,tp,0xe
    8000093c:	ed720213          	addi	tp,tp,-297 # fffffffffffffed7 <_end+0xffffffff7ff9fcd7>
    80000940:	0002200f          	cbo.inval	(tp)

0000000080000944 <_l130>:
    80000944:	58000053          	fsqrt.s	ft0,ft0,rne

0000000080000948 <_l131>:
    80000948:	41dcd6bb          	sraw	a3,s9,t4

000000008000094c <_l132>:
    8000094c:	00030597          	auipc	a1,0x30
    80000950:	88458593          	addi	a1,a1,-1916 # 800301d0 <d_2_27>
    80000954:	ff45e883          	lwu	a7,-12(a1)

0000000080000958 <_l133>:
    80000958:	fcaee9b7          	lui	s3,0xfcaee
    8000095c:	a239899b          	addiw	s3,s3,-1501 # fffffffffcaeda23 <_end+0xffffffff7ca8d823>
    80000960:	09b2                	slli	s3,s3,0xc
    80000962:	5ff98993          	addi	s3,s3,1535
    80000966:	09b2                	slli	s3,s3,0xc
    80000968:	59b98993          	addi	s3,s3,1435
    8000096c:	09b2                	slli	s3,s3,0xc
    8000096e:	0985                	addi	s3,s3,1
    80000970:	fc39e013          	prefetch.w	-64(s3)

0000000080000974 <_l134>:
    80000974:	6649                	lui	a2,0x12
    80000976:	f1b6061b          	addiw	a2,a2,-229 # 11f1b <_start-0x7ffee0e5>
    8000097a:	063e                	slli	a2,a2,0xf
    8000097c:	167d                	addi	a2,a2,-1
    8000097e:	bc066013          	prefetch.i	-1088(a2)

0000000080000982 <_l135>:
    80000982:	54900d93          	li	s11,1353
    80000986:	004da00f          	cbo.zero	(s11)

000000008000098a <_l136>:
    8000098a:	28920e53          	fmin.s	ft8,ft4,fs1

000000008000098e <_l137>:
    8000098e:	02ab1193          	slli	gp,s6,0x2a

0000000080000992 <_l138>:
    80000992:	00799137          	lui	sp,0x799
    80000996:	0c11011b          	addiw	sp,sp,193 # 7990c1 <_start-0x7f866f3f>
    8000099a:	0132                	slli	sp,sp,0xc
    8000099c:	c0b10113          	addi	sp,sp,-1013
    800009a0:	0136                	slli	sp,sp,0xd
    800009a2:	5bf10113          	addi	sp,sp,1471
    800009a6:	013a                	slli	sp,sp,0xe
    800009a8:	83710113          	addi	sp,sp,-1993
    800009ac:	0001200f          	cbo.inval	(sp)

00000000800009b0 <_l139>:
    800009b0:	15a00513          	li	a0,346
    800009b4:	00356013          	prefetch.w	0(a0)

00000000800009b8 <_l140>:
    800009b8:	0005c6b7          	lui	a3,0x5c
    800009bc:	99d6869b          	addiw	a3,a3,-1635 # 5b99d <_start-0x7ffa4663>
    800009c0:	06be                	slli	a3,a3,0xf
    800009c2:	71f68693          	addi	a3,a3,1823
    800009c6:	06b2                	slli	a3,a3,0xc
    800009c8:	0bc68693          	addi	a3,a3,188
    800009cc:	0046a00f          	cbo.zero	(a3)

00000000800009d0 <_l141>:
    800009d0:	b0156e37          	lui	t3,0xb0156
    800009d4:	291e0e1b          	addiw	t3,t3,657 # ffffffffb0156291 <_end+0xffffffff300f6091>
    800009d8:	0e36                	slli	t3,t3,0xd
    800009da:	64de0e13          	addi	t3,t3,1613
    800009de:	0e4a                	slli	t3,t3,0x12
    800009e0:	979e0e13          	addi	t3,t3,-1671
    800009e4:	003e6013          	prefetch.w	0(t3)

00000000800009e8 <_l142>:
    800009e8:	0151d23b          	srlw	tp,gp,s5

00000000800009ec <_l143>:
    800009ec:	a8c70b43          	fmadd.s	fs6,fa4,fa2,fs5,rne

00000000800009f0 <_l144>:
    800009f0:	00080bb7          	lui	s7,0x80
    800009f4:	2bbd                	addiw	s7,s7,15 # 8000f <_start-0x7ff7fff1>
    800009f6:	0bb2                	slli	s7,s7,0xc
    800009f8:	260be013          	prefetch.i	608(s7)

00000000800009fc <_l145>:
    800009fc:	0005f297          	auipc	t0,0x5f
    80000a00:	66428293          	addi	t0,t0,1636 # 80060060 <d_5_4>
    80000a04:	0002e903          	lwu	s2,0(t0)

0000000080000a08 <_l146>:
    80000a08:	0003f097          	auipc	ra,0x3f
    80000a0c:	62808093          	addi	ra,ra,1576 # 80040030 <d_3_1>
    80000a10:	8086                	mv	ra,ra
    80000a12:	2120a42f          	amoxor.w	s0,s2,(ra)

0000000080000a16 <_l147>:
    80000a16:	ffff8137          	lui	sp,0xffff8
    80000a1a:	2e71011b          	addiw	sp,sp,743 # ffffffffffff82e7 <_end+0xffffffff7ff980e7>
    80000a1e:	0011200f          	cbo.clean	(sp)

0000000080000a22 <_l148>:
    80000a22:	001fd137          	lui	sp,0x1fd
    80000a26:	c8d1011b          	addiw	sp,sp,-883 # 1fcc8d <_start-0x7fe03373>
    80000a2a:	013a                	slli	sp,sp,0xe
    80000a2c:	e7110113          	addi	sp,sp,-399
    80000a30:	0132                	slli	sp,sp,0xc
    80000a32:	67710113          	addi	sp,sp,1655
    80000a36:	5c016013          	prefetch.i	1472(sp)

0000000080000a3a <_l149>:
    80000a3a:	0c600313          	li	t1,198
    80000a3e:	0003200f          	cbo.inval	(t1)

0000000080000a42 <_l150>:
    80000a42:	1d8a8b63          	beq	s5,s8,80000c18 <_l189>

0000000080000a46 <_l151>:
    80000a46:	fd80ba37          	lui	s4,0xfd80b
    80000a4a:	b15a0a1b          	addiw	s4,s4,-1259 # fffffffffd80ab15 <_end+0xffffffff7d7aa915>
    80000a4e:	0a32                	slli	s4,s4,0xc
    80000a50:	899a0a13          	addi	s4,s4,-1895
    80000a54:	0a32                	slli	s4,s4,0xc
    80000a56:	33fa0a13          	addi	s4,s4,831
    80000a5a:	0a32                	slli	s4,s4,0xc
    80000a5c:	522a0a13          	addi	s4,s4,1314
    80000a60:	7e1a6013          	prefetch.r	2016(s4)

0000000080000a64 <_l152>:
    80000a64:	423b841b          	addiw	s0,s7,1059

0000000080000a68 <_l153>:
    80000a68:	fe803f37          	lui	t5,0xfe803
    80000a6c:	43df0f1b          	addiw	t5,t5,1085 # fffffffffe80343d <_end+0xffffffff7e7a323d>
    80000a70:	0f3a                	slli	t5,t5,0xe
    80000a72:	e91f0f13          	addi	t5,t5,-367
    80000a76:	0f32                	slli	t5,t5,0xc
    80000a78:	d1bf0f13          	addi	t5,t5,-741
    80000a7c:	0f32                	slli	t5,t5,0xc
    80000a7e:	0f05                	addi	t5,t5,1
    80000a80:	b01f6013          	prefetch.r	-1280(t5)

0000000080000a84 <_l154>:
    80000a84:	0004f517          	auipc	a0,0x4f
    80000a88:	6ac50513          	addi	a0,a0,1708 # 80050130 <d_4_17>
    80000a8c:	1541                	addi	a0,a0,-16
    80000a8e:	a175332f          	amomax.d	t1,s7,(a0)

0000000080000a92 <_l155>:
    80000a92:	0005c2b7          	lui	t0,0x5c
    80000a96:	99d2829b          	addiw	t0,t0,-1635 # 5b99d <_start-0x7ffa4663>
    80000a9a:	02be                	slli	t0,t0,0xf
    80000a9c:	71f28293          	addi	t0,t0,1823
    80000aa0:	02b2                	slli	t0,t0,0xc
    80000aa2:	0bc28293          	addi	t0,t0,188
    80000aa6:	0012e013          	prefetch.r	0(t0)

0000000080000aaa <_l156>:
    80000aaa:	104a8153          	fmul.s	ft2,fs5,ft4,rne

0000000080000aae <_l157>:
    80000aae:	0001fb17          	auipc	s6,0x1f
    80000ab2:	692b0b13          	addi	s6,s6,1682 # 80020140 <d_1_18>
    80000ab6:	8b5a                	mv	s6,s6
    80000ab8:	608b2aaf          	amoand.w	s5,s0,(s6)

0000000080000abc <_l158>:
    80000abc:	11030fd3          	fmul.s	ft11,ft6,fa6,rne

0000000080000ac0 <_l159>:
    80000ac0:	ff81fab7          	lui	s5,0xff81f
    80000ac4:	9cda8a9b          	addiw	s5,s5,-1587 # ffffffffff81e9cd <_end+0xffffffff7f7be7cd>
    80000ac8:	0ab6                	slli	s5,s5,0xd
    80000aca:	b35a8a93          	addi	s5,s5,-1227
    80000ace:	0ab2                	slli	s5,s5,0xc
    80000ad0:	38fa8a93          	addi	s5,s5,911
    80000ad4:	0abe                	slli	s5,s5,0xf
    80000ad6:	1afd                	addi	s5,s5,-1
    80000ad8:	004aa00f          	cbo.zero	(s5)

0000000080000adc <_l160>:
    80000adc:	7c71                	lui	s8,0xffffc
    80000ade:	072c0c1b          	addiw	s8,s8,114 # ffffffffffffc072 <_end+0xffffffff7ff9be72>
    80000ae2:	ba3c6013          	prefetch.w	-1120(s8)

0000000080000ae6 <_l161>:
    80000ae6:	0002f417          	auipc	s0,0x2f
    80000aea:	6aa40413          	addi	s0,s0,1706 # 80030190 <d_2_23>
    80000aee:	00043a83          	ld	s5,0(s0)

0000000080000af2 <_l162>:
    80000af2:	0002f117          	auipc	sp,0x2f
    80000af6:	6de10113          	addi	sp,sp,1758 # 800301d0 <d_2_27>
    80000afa:	c062                	sw	s8,0(sp)

0000000080000afc <_l163>:
    80000afc:	0363e063          	bltu	t2,s6,80000b1c <_l169>

0000000080000b00 <_l164>:
    80000b00:	02934a37          	lui	s4,0x2934

0000000080000b04 <_l165>:
    80000b04:	0000fb97          	auipc	s7,0xf
    80000b08:	61cb8b93          	addi	s7,s7,1564 # 80010120 <d_0_16>
    80000b0c:	fe3b8d03          	lb	s10,-29(s7)

0000000080000b10 <_l166>:
    80000b10:	00b86e63          	bltu	a6,a1,80000b2c <_l170>

0000000080000b14 <_l167>:
    80000b14:	0c4d0563          	beq	s10,tp,80000bde <_l182>

0000000080000b18 <_l168>:
    80000b18:	a03f11d3          	flt.s	gp,ft10,ft3

0000000080000b1c <_l169>:
    80000b1c:	00047837          	lui	a6,0x47
    80000b20:	e738081b          	addiw	a6,a6,-397 # 46e73 <_start-0x7ffb918d>
    80000b24:	0836                	slli	a6,a6,0xd
    80000b26:	187d                	addi	a6,a6,-1
    80000b28:	00086013          	prefetch.i	0(a6)

0000000080000b2c <_l170>:
    80000b2c:	21b88253          	fsgnj.s	ft4,fa7,fs11

0000000080000b30 <_l171>:
    80000b30:	20ea1453          	fsgnjn.s	fs0,fs4,fa4

0000000080000b34 <_l172>:
    80000b34:	004522b7          	lui	t0,0x452
    80000b38:	a2f2829b          	addiw	t0,t0,-1489 # 451a2f <_start-0x7fbae5d1>
    80000b3c:	02b6                	slli	t0,t0,0xd
    80000b3e:	99b28293          	addi	t0,t0,-1637
    80000b42:	02b6                	slli	t0,t0,0xd
    80000b44:	3eb28293          	addi	t0,t0,1003
    80000b48:	02b6                	slli	t0,t0,0xd
    80000b4a:	5ab28293          	addi	t0,t0,1451
    80000b4e:	2552ae73          	csrrs	t3,vsireg4,t0
    80000b52:	8872                	mv	a6,t3

0000000080000b54 <_l173>:
    80000b54:	0005f517          	auipc	a0,0x5f
    80000b58:	55c50513          	addi	a0,a0,1372 # 800600b0 <d_5_9>
    80000b5c:	1511                	addi	a0,a0,-28
    80000b5e:	ffe00e37          	lui	t3,0xffe00
    80000b62:	01c54533          	xor	a0,a0,t3
    80000b66:	21c52f2f          	amoxor.w	t5,t3,(a0)

0000000080000b6a <_l174>:
    80000b6a:	23100913          	li	s2,561
    80000b6e:	0009200f          	cbo.inval	(s2)

0000000080000b72 <_l175>:
    80000b72:	00005993          	srli	s3,zero,0x0

0000000080000b76 <_l176>:
    80000b76:	85df7c13          	andi	s8,t5,-1955

0000000080000b7a <_l177>:
    80000b7a:	fd80b637          	lui	a2,0xfd80b
    80000b7e:	b156061b          	addiw	a2,a2,-1259 # fffffffffd80ab15 <_end+0xffffffff7d7aa915>
    80000b82:	0632                	slli	a2,a2,0xc
    80000b84:	89960613          	addi	a2,a2,-1895
    80000b88:	0632                	slli	a2,a2,0xc
    80000b8a:	33f60613          	addi	a2,a2,831
    80000b8e:	0632                	slli	a2,a2,0xc
    80000b90:	08460613          	addi	a2,a2,132
    80000b94:	0016200f          	cbo.clean	(a2)

0000000080000b98 <_l178>:
    80000b98:	0005c6b7          	lui	a3,0x5c
    80000b9c:	99d6869b          	addiw	a3,a3,-1635 # 5b99d <_start-0x7ffa4663>
    80000ba0:	06be                	slli	a3,a3,0xf
    80000ba2:	71f68693          	addi	a3,a3,1823
    80000ba6:	06b2                	slli	a3,a3,0xc
    80000ba8:	0bc68693          	addi	a3,a3,188
    80000bac:	0006a00f          	cbo.inval	(a3)

0000000080000bb0 <_l179>:
    80000bb0:	002dc637          	lui	a2,0x2dc
    80000bb4:	34b6061b          	addiw	a2,a2,843 # 2dc34b <_start-0x7fd23cb5>
    80000bb8:	063a                	slli	a2,a2,0xe
    80000bba:	b2b60613          	addi	a2,a2,-1237
    80000bbe:	063a                	slli	a2,a2,0xe
    80000bc0:	e7160613          	addi	a2,a2,-399
    80000bc4:	0632                	slli	a2,a2,0xc
    80000bc6:	167d                	addi	a2,a2,-1
    80000bc8:	3a166013          	prefetch.r	928(a2)

0000000080000bcc <_l180>:
    80000bcc:	71ed                	lui	gp,0xffffb
    80000bce:	1af1819b          	addiw	gp,gp,431 # ffffffffffffb1af <_end+0xffffffff7ff9afaf>
    80000bd2:	0011a00f          	cbo.clean	(gp)

0000000080000bd6 <_l181>:
    80000bd6:	0bb00813          	li	a6,187
    80000bda:	0008200f          	cbo.inval	(a6)

0000000080000bde <_l182>:
    80000bde:	418453bb          	sraw	t2,s0,s8

0000000080000be2 <_l183>:
    80000be2:	29e28753          	fmin.s	fa4,ft5,ft10

0000000080000be6 <_l184>:
    80000be6:	00ca0337          	lui	t1,0xca0
    80000bea:	8273031b          	addiw	t1,t1,-2009 # c9f827 <_start-0x7f3607d9>
    80000bee:	0332                	slli	t1,t1,0xc
    80000bf0:	13f30313          	addi	t1,t1,319
    80000bf4:	0332                	slli	t1,t1,0xc
    80000bf6:	14530313          	addi	t1,t1,325
    80000bfa:	033e                	slli	t1,t1,0xf
    80000bfc:	2b730313          	addi	t1,t1,695
    80000c00:	2a336013          	prefetch.w	672(t1)

0000000080000c04 <_l185>:
    80000c04:	047ee863          	bltu	t4,t2,80000c54 <_l193>

0000000080000c08 <_l186>:
    80000c08:	80106413          	ori	s0,zero,-2047

0000000080000c0c <_l187>:
    80000c0c:	7b0d7e73          	csrrci	t3,dcsr,26

0000000080000c10 <_l188>:
    80000c10:	58200d93          	li	s11,1410
    80000c14:	004da00f          	cbo.zero	(s11)

0000000080000c18 <_l189>:
    80000c18:	0001f897          	auipc	a7,0x1f
    80000c1c:	58888893          	addi	a7,a7,1416 # 800201a0 <d_1_24>
    80000c20:	18c1                	addi	a7,a7,-16
    80000c22:	6168a42f          	amoand.w	s0,s6,(a7)

0000000080000c26 <_l190>:
    80000c26:	d0310e53          	fcvt.s.lu	ft8,sp,rne

0000000080000c2a <_l191>:
    80000c2a:	feb40db7          	lui	s11,0xfeb40
    80000c2e:	343d8d9b          	addiw	s11,s11,835 # fffffffffeb40343 <_end+0xffffffff7eae0143>
    80000c32:	0db6                	slli	s11,s11,0xd
    80000c34:	3a9d8d93          	addi	s11,s11,937
    80000c38:	0db2                	slli	s11,s11,0xc
    80000c3a:	0add8d93          	addi	s11,s11,173
    80000c3e:	0db2                	slli	s11,s11,0xc
    80000c40:	0d85                	addi	s11,s11,1
    80000c42:	000da00f          	cbo.inval	(s11)

0000000080000c46 <_l192>:
    80000c46:	0001f517          	auipc	a0,0x1f
    80000c4a:	58a50513          	addi	a0,a0,1418 # 800201d0 <d_1_27>
    80000c4e:	1531                	addi	a0,a0,-20
    80000c50:	10052c2f          	lr.w	s8,(a0)

0000000080000c54 <_l193>:
    80000c54:	fffa7f37          	lui	t5,0xfffa7
    80000c58:	6cdf0f1b          	addiw	t5,t5,1741 # fffffffffffa76cd <_end+0xffffffff7ff474cd>
    80000c5c:	0f3a                	slli	t5,t5,0xe
    80000c5e:	2a5f0f13          	addi	t5,t5,677
    80000c62:	0f46                	slli	t5,t5,0x11
    80000c64:	aadf0f13          	addi	t5,t5,-1363
    80000c68:	0f36                	slli	t5,t5,0xd
    80000c6a:	0f05                	addi	t5,t5,1
    80000c6c:	7e1f6013          	prefetch.r	2016(t5)

0000000080000c70 <_good_exit>:
    80000c70:	00001097          	auipc	ra,0x1
    80000c74:	59008093          	addi	ra,ra,1424 # 80002200 <csr_output_data>
    80000c78:	10002173          	csrr	sp,sstatus
    80000c7c:	0420bc23          	sd	sp,88(ra)
    80000c80:	10402173          	csrr	sp,sie
    80000c84:	0620b823          	sd	sp,112(ra)
    80000c88:	10502173          	csrr	sp,stvec
    80000c8c:	0620bc23          	sd	sp,120(ra)
    80000c90:	10602173          	csrr	sp,scounteren
    80000c94:	0820b023          	sd	sp,128(ra)
    80000c98:	14002173          	csrr	sp,sscratch
    80000c9c:	0820b423          	sd	sp,136(ra)
    80000ca0:	14102173          	csrr	sp,sepc
    80000ca4:	0820b823          	sd	sp,144(ra)
    80000ca8:	14202173          	csrr	sp,scause
    80000cac:	0820bc23          	sd	sp,152(ra)
    80000cb0:	14302173          	csrr	sp,stval
    80000cb4:	0a20b023          	sd	sp,160(ra)
    80000cb8:	14402173          	csrr	sp,sip
    80000cbc:	f7f17113          	andi	sp,sp,-129
    80000cc0:	0a20b423          	sd	sp,168(ra)
    80000cc4:	18002173          	csrr	sp,satp
    80000cc8:	0a20b823          	sd	sp,176(ra)
    80000ccc:	f1402173          	csrr	sp,mhartid
    80000cd0:	0a20bc23          	sd	sp,184(ra)
    80000cd4:	30002173          	csrr	sp,mstatus
    80000cd8:	0c20b023          	sd	sp,192(ra)
    80000cdc:	30202173          	csrr	sp,medeleg
    80000ce0:	0c20b423          	sd	sp,200(ra)
    80000ce4:	30302173          	csrr	sp,mideleg
    80000ce8:	0c20b823          	sd	sp,208(ra)
    80000cec:	30402173          	csrr	sp,mie
    80000cf0:	0c20bc23          	sd	sp,216(ra)
    80000cf4:	30502173          	csrr	sp,mtvec
    80000cf8:	0e20b023          	sd	sp,224(ra)
    80000cfc:	30602173          	csrr	sp,mcounteren
    80000d00:	0e20b423          	sd	sp,232(ra)
    80000d04:	34002173          	csrr	sp,mscratch
    80000d08:	0e20b823          	sd	sp,240(ra)
    80000d0c:	34102173          	csrr	sp,mepc
    80000d10:	0e20bc23          	sd	sp,248(ra)
    80000d14:	34202173          	csrr	sp,mcause
    80000d18:	1020b023          	sd	sp,256(ra)
    80000d1c:	34302173          	csrr	sp,mtval
    80000d20:	1020b423          	sd	sp,264(ra)
    80000d24:	34402173          	csrr	sp,mip
    80000d28:	f7f17113          	andi	sp,sp,-129
    80000d2c:	1020b823          	sd	sp,272(ra)
    80000d30:	3a002173          	csrr	sp,pmpcfg0
    80000d34:	1020bc23          	sd	sp,280(ra)
    80000d38:	3b002173          	csrr	sp,pmpaddr0
    80000d3c:	1220bc23          	sd	sp,312(ra)
    80000d40:	3b102173          	csrr	sp,pmpaddr1
    80000d44:	1420b023          	sd	sp,320(ra)
    80000d48:	3b202173          	csrr	sp,pmpaddr2
    80000d4c:	1420b423          	sd	sp,328(ra)
    80000d50:	3b302173          	csrr	sp,pmpaddr3
    80000d54:	1420b823          	sd	sp,336(ra)
    80000d58:	3b402173          	csrr	sp,pmpaddr4
    80000d5c:	1420bc23          	sd	sp,344(ra)
    80000d60:	3b502173          	csrr	sp,pmpaddr5
    80000d64:	1620b023          	sd	sp,352(ra)
    80000d68:	3b602173          	csrr	sp,pmpaddr6
    80000d6c:	1620b423          	sd	sp,360(ra)
    80000d70:	3b702173          	csrr	sp,pmpaddr7
    80000d74:	1620b823          	sd	sp,368(ra)
    80000d78:	6519                	lui	a0,0x6
    80000d7a:	30052073          	csrs	mstatus,a0

0000000080000d7e <fcsrs_dump>:
    80000d7e:	00102173          	frflags	sp
    80000d82:	0420b023          	sd	sp,64(ra)
    80000d86:	00202173          	frrm	sp
    80000d8a:	0420b423          	sd	sp,72(ra)
    80000d8e:	00302173          	frcsr	sp
    80000d92:	0420b823          	sd	sp,80(ra)

0000000080000d96 <reg_dump>:
    80000d96:	00001097          	auipc	ra,0x1
    80000d9a:	26a08093          	addi	ra,ra,618 # 80002000 <begin_signature>
    80000d9e:	0000b023          	sd	zero,0(ra)
    80000da2:	0020b823          	sd	sp,16(ra)
    80000da6:	0030bc23          	sd	gp,24(ra)
    80000daa:	0240b023          	sd	tp,32(ra)
    80000dae:	0250b423          	sd	t0,40(ra)
    80000db2:	0260b823          	sd	t1,48(ra)
    80000db6:	0270bc23          	sd	t2,56(ra)
    80000dba:	0480b023          	sd	s0,64(ra)
    80000dbe:	0490b423          	sd	s1,72(ra)
    80000dc2:	04a0b823          	sd	a0,80(ra)
    80000dc6:	04b0bc23          	sd	a1,88(ra)
    80000dca:	06c0b023          	sd	a2,96(ra)
    80000dce:	06d0b423          	sd	a3,104(ra)
    80000dd2:	06e0b823          	sd	a4,112(ra)
    80000dd6:	06f0bc23          	sd	a5,120(ra)
    80000dda:	0900b023          	sd	a6,128(ra)
    80000dde:	0910b423          	sd	a7,136(ra)
    80000de2:	0920b823          	sd	s2,144(ra)
    80000de6:	0930bc23          	sd	s3,152(ra)
    80000dea:	0b40b023          	sd	s4,160(ra)
    80000dee:	0b50b423          	sd	s5,168(ra)
    80000df2:	0b60b823          	sd	s6,176(ra)
    80000df6:	0b70bc23          	sd	s7,184(ra)
    80000dfa:	0d80b023          	sd	s8,192(ra)
    80000dfe:	0d90b423          	sd	s9,200(ra)
    80000e02:	0db0bc23          	sd	s11,216(ra)
    80000e06:	0fc0b023          	sd	t3,224(ra)
    80000e0a:	0fd0b423          	sd	t4,232(ra)
    80000e0e:	0fe0b823          	sd	t5,240(ra)

0000000080000e12 <freg_dump>:
    80000e12:	00001097          	auipc	ra,0x1
    80000e16:	2ee08093          	addi	ra,ra,750 # 80002100 <freg_output_data>
    80000e1a:	0010a427          	fsw	ft1,8(ra)
    80000e1e:	0020a827          	fsw	ft2,16(ra)
    80000e22:	0270ac27          	fsw	ft7,56(ra)
    80000e26:	0490a427          	fsw	fs1,72(ra)
    80000e2a:	04a0a827          	fsw	fa0,80(ra)
    80000e2e:	06c0a027          	fsw	fa2,96(ra)
    80000e32:	06d0a427          	fsw	fa3,104(ra)
    80000e36:	0b50a427          	fsw	fs5,168(ra)
    80000e3a:	0b60a827          	fsw	fs6,176(ra)
    80000e3e:	0d90a427          	fsw	fs9,200(ra)
    80000e42:	0da0a827          	fsw	fs10,208(ra)
    80000e46:	0fc0a027          	fsw	ft8,224(ra)
    80000e4a:	0fd0a427          	fsw	ft9,232(ra)
    80000e4e:	0fe0a827          	fsw	ft10,240(ra)
    80000e52:	0ff0ac27          	fsw	ft11,248(ra)
    80000e56:	00001097          	auipc	ra,0x1
    80000e5a:	2aa08093          	addi	ra,ra,682 # 80002100 <freg_output_data>
    80000e5e:	0000b027          	fsd	ft0,0(ra)
    80000e62:	0030bc27          	fsd	ft3,24(ra)
    80000e66:	0240b027          	fsd	ft4,32(ra)
    80000e6a:	0250b427          	fsd	ft5,40(ra)
    80000e6e:	0260b827          	fsd	ft6,48(ra)
    80000e72:	0480b027          	fsd	fs0,64(ra)
    80000e76:	04b0bc27          	fsd	fa1,88(ra)
    80000e7a:	06e0b827          	fsd	fa4,112(ra)
    80000e7e:	06f0bc27          	fsd	fa5,120(ra)
    80000e82:	0900b027          	fsd	fa6,128(ra)
    80000e86:	0910b427          	fsd	fa7,136(ra)
    80000e8a:	0920b827          	fsd	fs2,144(ra)
    80000e8e:	0930bc27          	fsd	fs3,152(ra)
    80000e92:	0b40b027          	fsd	fs4,160(ra)
    80000e96:	0b70bc27          	fsd	fs7,184(ra)
    80000e9a:	0d80b027          	fsd	fs8,192(ra)
    80000e9e:	0db0bc27          	fsd	fs11,216(ra)
    80000ea2:	4501                	li	a0,0
    80000ea4:	0005006b          	.insn	4, 0x0005006b
    80000ea8:	4185                	li	gp,1
    80000eaa:	00000f17          	auipc	t5,0x0
    80000eae:	143f2b23          	sw	gp,342(t5) # 80001000 <tohost>
    80000eb2:	a001                	j	80000eb2 <freg_dump+0xa0>

0000000080000eb4 <_end_main>:
	...
    80000ec4:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	849c                	.insn	2, 0x849c
    80010002:	f3f8                	sd	a4,224(a5)
    80010004:	8160                	.insn	2, 0x8160
    80010006:	8e02                	jr	t3
    80010008:	e6ec                	sd	a1,200(a3)
    8001000a:	2f8d                	addiw	t6,t6,3
    8001000c:	2094                	fld	fa3,0(s1)
    8001000e:	9149                	srli	a0,a0,0x32
    80010010:	75ba                	ld	a1,424(sp)
    80010012:	08b6                	slli	a7,a7,0xd
    80010014:	869d                	srai	a3,a3,0x7
    80010016:	6a11                	lui	s4,0x4
    80010018:	85f6                	mv	a1,t4
    8001001a:	0ec2                	slli	t4,t4,0x10
    8001001c:	f8cc47db          	.insn	4, 0xf8cc47db

0000000080010020 <d_0_0>:
    80010020:	76ee                	ld	a3,248(sp)
    80010022:	cdaa                	sw	a0,216(sp)
    80010024:	a5fd                	j	80010712 <_end_data0+0x512>
    80010026:	414a317b          	.insn	4, 0x414a317b
    8001002a:	9671                	srai	a2,a2,0x3c
    8001002c:	e52ec0ef          	jal	7fffc67e <_start-0x3982>

0000000080010030 <d_0_1>:
    80010030:	53dd                	li	t2,-9
    80010032:	bdc0                	fsd	fs0,184(a1)
    80010034:	de31                	beqz	a2,8000ff90 <end_signature+0xdbb0>
    80010036:	4d3c                	lw	a5,88(a0)
    80010038:	7e94                	ld	a3,56(a3)
    8001003a:	0305                	addi	t1,t1,1
    8001003c:	29be                	fld	fs3,456(sp)
    8001003e:	eb01                	bnez	a4,8001004e <d_0_2+0xe>

0000000080010040 <d_0_2>:
    80010040:	8b5c                	.insn	2, 0x8b5c
    80010042:	af12                	fsd	ft4,408(sp)
    80010044:	fdb098d3          	.insn	4, 0xfdb098d3
    80010048:	9e50                	.insn	2, 0x9e50
    8001004a:	2f61                	addiw	t5,t5,24
    8001004c:	fa46                	sd	a7,304(sp)
    8001004e:	          	jal	s6,8007d58c <_end+0x1d38c>

0000000080010050 <d_0_3>:
    80010050:	53e6                	lw	t2,120(sp)
    80010052:	aba9                	j	800105ac <_end_data0+0x3ac>
    80010054:	9bbd                	andi	a5,a5,-17
    80010056:	2b66                	fld	fs6,88(sp)
    80010058:	82a2                	mv	t0,s0
    8001005a:	9e02                	jalr	t3
    8001005c:	7162                	ld	sp,56(sp)
    8001005e:	0266                	slli	tp,tp,0x19

0000000080010060 <d_0_4>:
    80010060:	defd                	beqz	a3,8001005e <d_0_3+0xe>
    80010062:	5562                	lw	a0,56(sp)
    80010064:	7ca0                	ld	s0,120(s1)
    80010066:	723e                	ld	tp,488(sp)
    80010068:	bd0c                	fsd	fa1,56(a0)
    8001006a:	1178                	addi	a4,sp,172
    8001006c:	da32                	sw	a2,52(sp)
    8001006e:	b1fc                	fsd	fa5,224(a1)

0000000080010070 <d_0_5>:
    80010070:	5f88a5cf          	.insn	4, 0x5f88a5cf
    80010074:	528a                	lw	t0,160(sp)
    80010076:	c504                	sw	s1,8(a0)
    80010078:	e0ad29db          	.insn	4, 0xe0ad29db
    8001007c:	f57e                	sd	t6,168(sp)
    8001007e:	4b21                	li	s6,8

0000000080010080 <d_0_6>:
    80010080:	23ca                	fld	ft7,144(sp)
    80010082:	1f360503          	lb	a0,499(a2)
    80010086:	9d09                	subw	a0,a0,a0
    80010088:	1264                	addi	s1,sp,300
    8001008a:	e0edf70f          	.insn	4, 0xe0edf70f
    8001008e:	1e96                	slli	t4,t4,0x25

0000000080010090 <d_0_7>:
    80010090:	26ff 034d d5e6 f6fb 	.insn	14, 0x3e4dccb18d09f6fbd5e6034d26ff
    80010098:	8d09 ccb1 3e4d 
    8001009e:	          	sb	a1,1304(zero) # 518 <_start-0x7ffffae8>

00000000800100a0 <d_0_8>:
    800100a0:	50b0                	lw	a2,96(s1)
    800100a2:	7266                	ld	tp,120(sp)
    800100a4:	9104                	.insn	2, 0x9104
    800100a6:	1661                	addi	a2,a2,-8
    800100a8:	abcc                	fsd	fa1,144(a5)
    800100aa:	6ec2                	ld	t4,16(sp)
    800100ac:	3eba                	fld	ft9,424(sp)
    800100ae:	7b96                	ld	s7,352(sp)

00000000800100b0 <d_0_9>:
    800100b0:	00da                	slli	ra,ra,0x16
    800100b2:	9026                	c.add	zero,s1
    800100b4:	2cee                	fld	fs9,216(sp)
    800100b6:	db20                	sw	s0,112(a4)
    800100b8:	24d4                	fld	fa3,136(s1)
    800100ba:	a4c83da3          	sd	a2,-1445(a6)
    800100be:	beb2                	fsd	fa2,376(sp)

00000000800100c0 <d_0_10>:
    800100c0:	8e6e                	mv	t3,s11
    800100c2:	827a                	mv	tp,t5
    800100c4:	89b4                	.insn	2, 0x89b4
    800100c6:	3b29d2c7          	fmsub.d	ft5,fs3,fs2,ft7,unknown
    800100ca:	c9b2                	sw	a2,208(sp)
    800100cc:	f676                	sd	t4,296(sp)
    800100ce:	          	jal	t6,800f3f4a <_end+0x93d4a>

00000000800100d0 <d_0_11>:
    800100d0:	67de                	ld	a5,464(sp)
    800100d2:	2830                	fld	fa2,80(s0)
    800100d4:	18067e7b          	.insn	4, 0x18067e7b
    800100d8:	2f128fd7          	vxor.vv	v31,v17,v5
    800100dc:	4c5d                	li	s8,23
    800100de:	abba                	fsd	fa4,464(sp)

00000000800100e0 <d_0_12>:
    800100e0:	11ae                	slli	gp,gp,0x2b
    800100e2:	afb3a7bb          	.insn	4, 0xafb3a7bb
    800100e6:	e4ce                	sd	s3,72(sp)
    800100e8:	6e36fc13          	andi	s8,a3,1763
    800100ec:	44fc                	lw	a5,76(s1)
    800100ee:	657d                	lui	a0,0x1f

00000000800100f0 <d_0_13>:
    800100f0:	939f 35ac f95c      	.insn	6, 0xf95c35ac939f
    800100f6:	a001713f c368d5e7 	.insn	8, 0xc368d5e7a001713f
    800100fe:	          	lui	a0,0x43c26

0000000080010100 <d_0_14>:
    80010100:	43c2                	lw	t2,16(sp)
    80010102:	2fd0                	fld	fa2,152(a5)
    80010104:	2024                	fld	fs1,64(s0)
    80010106:	7918                	ld	a4,48(a0)
    80010108:	0754                	addi	a3,sp,900
    8001010a:	4ec2                	lw	t4,16(sp)
    8001010c:	a42e0ff3          	.insn	4, 0xa42e0ff3

0000000080010110 <d_0_15>:
    80010110:	c29e                	sw	t2,68(sp)
    80010112:	b756                	fsd	fs5,424(sp)
    80010114:	a1857a23          	.insn	4, 0xa1857a23
    80010118:	4d9a                	lw	s11,132(sp)
    8001011a:	2eff 6d74 c4a0  	.insn	14, 0x945596db68535988c4a06d742eff
    80010122:	   

0000000080010120 <d_0_16>:
    80010120:	5988                	lw	a0,48(a1)
    80010122:	96db6853          	.insn	4, 0x96db6853
    80010126:	9455                	srai	s0,s0,0x35
    80010128:	dc00                	sw	s0,56(s0)
    8001012a:	b109c0db          	.insn	4, 0xb109c0db
    8001012e:	b401                	j	8000fb2e <end_signature+0xd74e>

0000000080010130 <d_0_17>:
    80010130:	785f 3150 1718      	.insn	6, 0x17183150785f
    80010136:	a109                	j	80010538 <_end_data0+0x338>
    80010138:	e5fe                	sd	t6,200(sp)
    8001013a:	b8e76a6f          	jal	s4,7ff864c8 <_start-0x79b38>
    8001013e:	dd84                	sw	s1,56(a1)

0000000080010140 <d_0_18>:
    80010140:	5adf 1586 8042      	.insn	6, 0x804215865adf
    80010146:	53d4                	lw	a3,36(a5)
    80010148:	c3e4                	sw	s1,68(a5)
    8001014a:	4325                	li	t1,9
    8001014c:	5c82                	lw	s9,32(sp)
    8001014e:	1a0e                	slli	s4,s4,0x23

0000000080010150 <d_0_19>:
    80010150:	1d6a                	slli	s10,s10,0x3a
    80010152:	098104db          	.insn	4, 0x098104db
    80010156:	45f6                	lw	a1,92(sp)
    80010158:	1554                	addi	a3,sp,676
    8001015a:	9190                	.insn	2, 0x9190
    8001015c:	9b3fc9c7          	fmsub.d	fs3,ft11,fs3,fs3,rmm

0000000080010160 <d_0_20>:
    80010160:	a8a5                	j	800101d8 <d_0_27+0x8>
    80010162:	cb06                	sw	ra,148(sp)
    80010164:	c815                	beqz	s0,80010198 <d_0_23+0x8>
    80010166:	6825                	lui	a6,0x9
    80010168:	59856433          	.insn	4, 0x59856433
    8001016c:	80f4                	.insn	2, 0x80f4
    8001016e:	9071                	srli	s0,s0,0x3c

0000000080010170 <d_0_21>:
    80010170:	d22d                	beqz	a2,800100d2 <d_0_11+0x2>
    80010172:	b330                	fsd	fa2,96(a4)
    80010174:	a2f2                	fsd	ft8,320(sp)
    80010176:	cd48                	sw	a0,28(a0)
    80010178:	00df 29e1 0682      	.insn	6, 0x068229e100df
    8001017e:	a636                	fsd	fa3,264(sp)

0000000080010180 <d_0_22>:
    80010180:	f1df 51c5 529c      	.insn	6, 0x529c51c5f1df
    80010186:	033c                	addi	a5,sp,392
    80010188:	6281                	.insn	2, 0x6281
    8001018a:	d975                	beqz	a0,8001017e <d_0_21+0xe>
    8001018c:	d55b3843          	.insn	4, 0xd55b3843

0000000080010190 <d_0_23>:
    80010190:	806d                	srli	s0,s0,0x1b
    80010192:	a1e0                	fsd	fs0,192(a1)
    80010194:	324cd2fb          	.insn	4, 0x324cd2fb
    80010198:	ffde                	sd	s7,504(sp)
    8001019a:	34f1                	addiw	s1,s1,-4
    8001019c:	4abc                	lw	a5,80(a3)
    8001019e:	8fc4                	.insn	2, 0x8fc4

00000000800101a0 <d_0_24>:
    800101a0:	d304                	sw	s1,32(a4)
    800101a2:	6538                	ld	a4,72(a0)
    800101a4:	2dc2                	fld	fs11,16(sp)
    800101a6:	5541982b          	.insn	4, 0x5541982b
    800101aa:	ce91                	beqz	a3,800101c6 <d_0_26+0x6>
    800101ac:	04a1b873          	csrrc	a6,0x4a,gp

00000000800101b0 <d_0_25>:
    800101b0:	b381                	j	8000fef0 <end_signature+0xdb10>
    800101b2:	63c480a7          	.insn	4, 0x63c480a7
    800101b6:	fd01                	bnez	a0,800100ce <d_0_10+0xe>
    800101b8:	2fde3497          	auipc	s1,0x2fde3
    800101bc:	f134cabb          	.insn	4, 0xf134cabb

00000000800101c0 <d_0_26>:
    800101c0:	ecca                	sd	s2,88(sp)
    800101c2:	becca733          	.insn	4, 0xbecca733
    800101c6:	deea                	sw	s10,124(sp)
    800101c8:	2ef4                	fld	fa3,216(a3)
    800101ca:	c118780f          	.insn	4, 0xc118780f
    800101ce:	3061                	.insn	2, 0x3061

00000000800101d0 <d_0_27>:
    800101d0:	a41f a626 0e39      	.insn	6, 0x0e39a626a41f
    800101d6:	f8a9                	bnez	s1,80010128 <d_0_16+0x8>
    800101d8:	55119267          	.insn	4, 0x55119267
    800101dc:	b262                	fsd	fs8,288(sp)
    800101de:	ea8c3ff3          	csrrc	t6,0xea8,s8
    800101e2:	785a                	ld	a6,432(sp)
    800101e4:	f50d                	bnez	a0,8001010e <d_0_14+0xe>
    800101e6:	d1e6dcbb          	.insn	4, 0xd1e6dcbb
    800101ea:	a44c                	fsd	fa1,136(s0)
    800101ec:	5a45                	li	s4,-15
    800101ee:	0421                	addi	s0,s0,8
    800101f0:	5c0d                	li	s8,-29
    800101f2:	076ed3d7          	.insn	4, 0x076ed3d7
    800101f6:	b679                	j	8000fd84 <end_signature+0xd9a4>
    800101f8:	dab2                	sw	a2,116(sp)
    800101fa:	91b2                	add	gp,gp,a2
    800101fc:	fbe5                	bnez	a5,800101ec <d_0_27+0x1c>
    800101fe:	fe68                	sd	a0,248(a2)

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	bdab8cbf e6d94ff4 	.insn	8, 0xe6d94ff4bdab8cbf
    80020008:	05d5                	addi	a1,a1,21
    8002000a:	cec921c3          	.insn	4, 0xcec921c3
    8002000e:	7eb6                	ld	t4,360(sp)
    80020010:	16fb6143          	.insn	4, 0x16fb6143
    80020014:	6f6c                	ld	a1,216(a4)
    80020016:	4f3d                	li	t5,15
    80020018:	9e6a                	add	t3,t3,s10
    8002001a:	9125                	srli	a0,a0,0x29
    8002001c:	eb32                	sd	a2,400(sp)
    8002001e:	1b8e                	slli	s7,s7,0x23

0000000080020020 <d_1_0>:
    80020020:	dc29                	beqz	s0,8001ff7a <_end_data0+0xfd7a>
    80020022:	480d                	li	a6,3
    80020024:	0d66                	slli	s10,s10,0x19
    80020026:	84ac                	.insn	2, 0x84ac
    80020028:	d295                	beqz	a3,8001ff4c <_end_data0+0xfd4c>
    8002002a:	3ad9                	addiw	s5,s5,-10
    8002002c:	447f b3f0   	.insn	18, 0xf3aa280e3b49acad63650d82e4f6b3f0447f
    80020034:	    
    8002003c:	 

0000000080020030 <d_1_1>:
    80020030:	e4f6                	sd	t4,72(sp)
    80020032:	0d82                	c.slli64	s11
    80020034:	6365                	lui	t1,0x19
    80020036:	acad                	j	800202b0 <_end_data1+0xb0>
    80020038:	3b49                	addiw	s6,s6,-14
    8002003a:	280e                	fld	fa6,192(sp)
    8002003c:	f3aa                	sd	a0,480(sp)
    8002003e:	  	.insn	8, 0xa3410502fbb378bf

0000000080020040 <d_1_2>:
    80020040:	0502fbb3          	.insn	4, 0x0502fbb3
    80020044:	a341                	j	800205c4 <_end_data1+0x3c4>
    80020046:	8296                	mv	t0,t0
    80020048:	f6c4                	sd	s1,168(a3)
    8002004a:	2d45                	addiw	s10,s10,17
    8002004c:	9715                	srai	a4,a4,0x25
    8002004e:	          	.insn	4, 0xa6614a73

0000000080020050 <d_1_3>:
    80020050:	a661                	j	800203d8 <_end_data1+0x1d8>
    80020052:	492e                	lw	s2,200(sp)
    80020054:	9bee                	add	s7,s7,s11
    80020056:	e24c5347          	fmsub.d	ft6,fs8,ft4,ft8,unknown
    8002005a:	e7308cbf  	.insn	8, 0xc0cc261de7308cbf

0000000080020060 <d_1_4>:
    80020060:	c0cc                	sw	a1,4(s1)
    80020062:	3e1c                	fld	fa5,56(a2)
    80020064:	c328                	sw	a0,64(a4)
    80020066:	9c9fa9a3          	sw	s1,-1581(t6)
    8002006a:	dba2                	sw	s0,244(sp)
    8002006c:	3d1d                	addiw	s10,s10,-25
    8002006e:	8326                	mv	t1,s1

0000000080020070 <d_1_5>:
    80020070:	c264                	sw	s1,68(a2)
    80020072:	17e4                	addi	s1,sp,1004
    80020074:	a404                	fsd	fs1,8(s0)
    80020076:	02ad1e7f 7967ac15 	.insn	12, 0x66cbc7257967ac1502ad1e7f
    8002007e:	 

0000000080020080 <d_1_6>:
    80020080:	f6fd66cb          	.insn	4, 0xf6fd66cb
    80020084:	0b4d                	addi	s6,s6,19
    80020086:	c0ed98bb          	.insn	4, 0xc0ed98bb
    8002008a:	590e                	lw	s2,224(sp)
    8002008c:	f8f101f7          	.insn	4, 0xf8f101f7

0000000080020090 <d_1_7>:
    80020090:	e4f1                	bnez	s1,8002015c <d_1_19+0xc>
    80020092:	8dd8dd77          	.insn	4, 0x8dd8dd77
    80020096:	1101                	addi	sp,sp,-32
    80020098:	dac53cff 68966525 	.insn	16, 0xc45aed1e7c77484168966525dac53cff
    800200a0:	  

00000000800200a0 <d_1_8>:
    800200a0:	4841                	li	a6,16
    800200a2:	ed1e7c77          	.insn	4, 0xed1e7c77
    800200a6:	c45a                	sw	s6,8(sp)
    800200a8:	648d                	lui	s1,0x3
    800200aa:	48f8                	lw	a4,84(s1)
    800200ac:	00c2                	slli	ra,ra,0x10
    800200ae:	994c                	.insn	2, 0x994c

00000000800200b0 <d_1_9>:
    800200b0:	e3e5                	bnez	a5,80020190 <d_1_23>
    800200b2:	03b9                	addi	t2,t2,14
    800200b4:	6fbc9b53          	.insn	4, 0x6fbc9b53
    800200b8:	fa79                	bnez	a2,8002008e <d_1_6+0xe>
    800200ba:	d8e4                	sw	s1,116(s1)
    800200bc:	cbbd                	beqz	a5,80020132 <d_1_17+0x2>
    800200be:	3502                	fld	fa0,32(sp)

00000000800200c0 <d_1_10>:
    800200c0:	5f12                	lw	t5,36(sp)
    800200c2:	dac5bf83          	ld	t6,-596(a1)
    800200c6:	fb0c                	sd	a1,48(a4)
    800200c8:	a33fbaab          	.insn	4, 0xa33fbaab
    800200cc:	4c9bea77          	.insn	4, 0x4c9bea77

00000000800200d0 <d_1_11>:
    800200d0:	85e0                	.insn	2, 0x85e0
    800200d2:	64cc                	ld	a1,136(s1)
    800200d4:	f904                	sd	s1,48(a0)
    800200d6:	af5d                	j	8002088c <_end_data1+0x68c>
    800200d8:	c46e                	sw	s11,8(sp)
    800200da:	bd1fccfb          	.insn	4, 0xbd1fccfb
    800200de:	3470                	fld	fa2,232(s0)

00000000800200e0 <d_1_12>:
    800200e0:	5359                	li	t1,-10
    800200e2:	d3b8                	sw	a4,96(a5)
    800200e4:	9579                	srai	a0,a0,0x3e
    800200e6:	fc596bcf          	.insn	4, 0xfc596bcf
    800200ea:	c102                	sw	zero,128(sp)
    800200ec:	59a6                	lw	s3,104(sp)
    800200ee:	2c99                	addiw	s9,s9,6

00000000800200f0 <d_1_13>:
    800200f0:	c6be                	sw	a5,76(sp)
    800200f2:	4302                	lw	t1,0(sp)
    800200f4:	8b64                	.insn	2, 0x8b64
    800200f6:	9be0                	.insn	2, 0x9be0
    800200f8:	a44a                	fsd	fs2,8(sp)
    800200fa:	1c4c                	addi	a1,sp,564
    800200fc:	9419                	srai	s0,s0,0x26
    800200fe:	31fa                	fld	ft3,440(sp)

0000000080020100 <d_1_14>:
    80020100:	635a                	ld	t1,400(sp)
    80020102:	2454e5cf          	.insn	4, 0x2454e5cf
    80020106:	fab9                	bnez	a3,8002005c <d_1_3+0xc>
    80020108:	990c                	.insn	2, 0x990c
    8002010a:	5981                	li	s3,-32
    8002010c:	c3d69423          	sh	t4,-984(a3)

0000000080020110 <d_1_15>:
    80020110:	b975                	j	8001fdcc <_end_data0+0xfbcc>
    80020112:	c3c2                	sw	a6,196(sp)
    80020114:	a84c658f          	.insn	4, 0xa84c658f
    80020118:	142e                	slli	s0,s0,0x2b
    8002011a:	29cc                	fld	fa1,144(a1)
    8002011c:	219df813          	andi	a6,s11,537

0000000080020120 <d_1_16>:
    80020120:	e49f 3950 7bdc      	.insn	6, 0x7bdc3950e49f
    80020126:	cd229733          	.insn	4, 0xcd229733
    8002012a:	1132b747          	fmsub.s	fa4,ft5,fs3,ft2,rup
    8002012e:	3fe4                	fld	fs1,248(a5)

0000000080020130 <d_1_17>:
    80020130:	f990                	sd	a2,48(a1)
    80020132:	aaae                	fsd	fa1,336(sp)
    80020134:	5362bfa7          	fsd	fs6,1343(t0)
    80020138:	f39c11ef          	jal	gp,7ffe2070 <_start-0x1df90>
    8002013c:	b3ea                	fsd	fs10,480(sp)
    8002013e:	1ef1                	addi	t4,t4,-4

0000000080020140 <d_1_18>:
    80020140:	3128                	fld	fa0,96(a0)
    80020142:	e19c                	sd	a5,0(a1)
    80020144:	6095                	lui	ra,0x5
    80020146:	8dff 8075 5c88 fba8 	.insn	10, 0xbcf9fba85c8880758dff
    8002014e:	bcf9 

0000000080020150 <d_1_19>:
    80020150:	2c85                	addiw	s9,s9,1
    80020152:	9a9270eb          	.insn	4, 0x9a9270eb
    80020156:	2a42                	fld	fs4,16(sp)
    80020158:	2b4b8b17          	auipc	s6,0x2b4b8
    8002015c:	7baa                	ld	s7,168(sp)
    8002015e:	65fd                	lui	a1,0x1f

0000000080020160 <d_1_20>:
    80020160:	8b9e                	mv	s7,t2
    80020162:	6faa                	ld	t6,136(sp)
    80020164:	2cea                	fld	fs9,152(sp)
    80020166:	ac16                	fsd	ft5,24(sp)
    80020168:	1115                	addi	sp,sp,-27
    8002016a:	f151844b          	fnmsub.s	fs0,ft3,fs5,ft10,rne
    8002016e:	          	auipc	t4,0x7d63c

0000000080020170 <d_1_21>:
    80020170:	08037d63          	bgeu	t1,zero,8002020a <_end_data1+0xa>
    80020174:	ecae                	sd	a1,88(sp)
    80020176:	2bf58df7          	.insn	4, 0x2bf58df7
    8002017a:	eaae                	sd	a1,336(sp)
    8002017c:	db2b1ecf          	fnmadd.d	ft9,fs6,fs2,fs11,rtz

0000000080020180 <d_1_22>:
    80020180:	7045                	c.lui	zero,0xffff1
    80020182:	492a                	lw	s2,136(sp)
    80020184:	bad4                	fsd	fa3,176(a3)
    80020186:	9521                	srai	a0,a0,0x28
    80020188:	f8de                	sd	s7,112(sp)
    8002018a:	2794                	fld	fa3,8(a5)
    8002018c:	9b84                	.insn	2, 0x9b84
    8002018e:	3a6a                	fld	fs4,184(sp)

0000000080020190 <d_1_23>:
    80020190:	856b219b          	.insn	4, 0x856b219b
    80020194:	6bd8                	ld	a4,144(a5)
    80020196:	473d                	li	a4,15
    80020198:	d254                	sw	a3,36(a2)
    8002019a:	a3d0                	fsd	fa2,128(a5)
    8002019c:	6c860d47          	.insn	4, 0x6c860d47

00000000800201a0 <d_1_24>:
    800201a0:	42ac                	lw	a1,64(a3)
    800201a2:	f9d0                	sd	a2,176(a1)
    800201a4:	6f7f 0348 21bb 23af 	.insn	22, 0xf6fffd533193c2ea4b9649eb8c7123af21bb03486f7f
    800201ac:	8c71 49eb   
    800201b4:	   

00000000800201b0 <d_1_25>:
    800201b0:	4b96                	lw	s7,68(sp)
    800201b2:	c2ea                	sw	s10,68(sp)
    800201b4:	fd533193          	sltiu	gp,t1,-43
    800201b8:	f6ff                	.insn	2, 0xf6ff
    800201ba:	4caced07          	vloxseg3ei32.v	v26,(s9),v10,v0.t
    800201be:	          	.insn	4, 0x0ff866af

00000000800201c0 <d_1_26>:
    800201c0:	0ff8                	addi	a4,sp,988
    800201c2:	dc51                	beqz	s0,8002015e <d_1_19+0xe>
    800201c4:	42cd                	li	t0,19
    800201c6:	3e9a                	fld	ft9,416(sp)
    800201c8:	4602                	lw	a2,0(sp)
    800201ca:	ae06                	fsd	ft1,280(sp)
    800201cc:	9c85                	subw	s1,s1,s1
    800201ce:	6b7f    	.insn	22, 0x335015a931e0b7acf330e43a65bd7f1a190387546b7f
    800201d6:	    
    800201de:	   

00000000800201d0 <d_1_27>:
    800201d0:	8754                	.insn	2, 0x8754
    800201d2:	7f1a1903          	lh	s2,2033(s4) # 47f1 <_start-0x7fffb80f>
    800201d6:	65bd                	lui	a1,0xf
    800201d8:	e43a                	sd	a4,8(sp)
    800201da:	f330                	sd	a2,96(a4)
    800201dc:	b7ac                	fsd	fa1,104(a5)
    800201de:	31e0                	fld	fs0,224(a1)
    800201e0:	15a9                	addi	a1,a1,-22 # efea <_start-0x7fff1016>
    800201e2:	3350                	fld	fa2,160(a4)
    800201e4:	87a4                	.insn	2, 0x87a4
    800201e6:	ff99                	bnez	a5,80020104 <d_1_14+0x4>
    800201e8:	6be8                	ld	a0,208(a5)
    800201ea:	ea5f 852f 70b1      	.insn	6, 0x70b1852fea5f
    800201f0:	148d                	addi	s1,s1,-29 # 2fe3 <_start-0x7fffd01d>
    800201f2:	cb7d                	beqz	a4,800202e8 <_end_data1+0xe8>
    800201f4:	937c                	.insn	2, 0x937c
    800201f6:	cada                	sw	s6,84(sp)
    800201f8:	d931f3c3          	fmadd.s	ft7,ft3,fs3,fs11
    800201fc:	fd60                	sd	s0,248(a0)
    800201fe:	bc9a                	fsd	ft6,120(sp)

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	b9696f8f          	.insn	4, 0xb9696f8f
    80030004:	2c90                	fld	fa2,24(s1)
    80030006:	4bed                	li	s7,27
    80030008:	702c8763          	beq	s9,sp,80030716 <_end_data2+0x516>
    8003000c:	d0df ffe2 dbbe      	.insn	6, 0xdbbeffe2d0df
    80030012:	711372a7          	.insn	4, 0x711372a7
    80030016:	7978                	ld	a4,240(a0)
    80030018:	1004                	addi	s1,sp,32
    8003001a:	d796                	sw	t0,236(sp)
    8003001c:	4244                	lw	s1,4(a2)
    8003001e:	88f8                	.insn	2, 0x88f8

0000000080030020 <d_2_0>:
    80030020:	ef8d                	bnez	a5,8003005a <d_2_3+0xa>
    80030022:	8e65d06f          	j	7ff8d108 <_start-0x72ef8>
    80030026:	92a4                	.insn	2, 0x92a4
    80030028:	77a8                	ld	a0,104(a5)
    8003002a:	76aa                	ld	a3,168(sp)
    8003002c:	c4ca                	sw	s2,72(sp)
    8003002e:	8760                	.insn	2, 0x8760

0000000080030030 <d_2_1>:
    80030030:	8b53b4f3          	csrrc	s1,0x8b5,t2
    80030034:	ee21                	bnez	a2,8003008c <d_2_6+0xc>
    80030036:	57a9                	li	a5,-22
    80030038:	246a                	fld	fs0,152(sp)
    8003003a:	591a                	lw	s2,164(sp)
    8003003c:	c519                	beqz	a0,8003004a <d_2_2+0xa>
    8003003e:	b69c                	fsd	fa5,40(a3)

0000000080030040 <d_2_2>:
    80030040:	a1593e33          	.insn	4, 0xa1593e33
    80030044:	11d4                	addi	a3,sp,228
    80030046:	acb0                	fsd	fa2,88(s1)
    80030048:	0725                	addi	a4,a4,9
    8003004a:	605268d7          	.insn	4, 0x605268d7
    8003004e:	          	lh	a2,1906(s8)

0000000080030050 <d_2_3>:
    80030050:	772c                	ld	a1,104(a4)
    80030052:	b408                	fsd	fa0,40(s0)
    80030054:	fbe1                	bnez	a5,80030024 <d_2_0+0x4>
    80030056:	0088                	addi	a0,sp,64
    80030058:	ef6a965b          	.insn	4, 0xef6a965b
    8003005c:	f0a6                	sd	s1,96(sp)
    8003005e:	          	lui	a5,0x76a66

0000000080030060 <d_2_4>:
    80030060:	76a6                	ld	a3,104(sp)
    80030062:	2addeb83          	lwu	s7,685(s11)
    80030066:	0868                	addi	a0,sp,28
    80030068:	1461                	addi	s0,s0,-8
    8003006a:	e3f5                	bnez	a5,8003014e <d_2_18+0xe>
    8003006c:	adbc9c1b          	.insn	4, 0xadbc9c1b

0000000080030070 <d_2_5>:
    80030070:	cea6                	sw	s1,92(sp)
    80030072:	b185                	j	8002fcd2 <_end_data1+0xfad2>
    80030074:	fce38dc3          	.insn	4, 0xfce38dc3
    80030078:	78b9c6eb          	.insn	4, 0x78b9c6eb
    8003007c:	a774b687          	fld	fa3,-1417(s1)

0000000080030080 <d_2_6>:
    80030080:	d89f a60d bad4      	.insn	6, 0xbad4a60dd89f
    80030086:	f230                	sd	a2,96(a2)
    80030088:	b0a0                	fsd	fs0,96(s1)
    8003008a:	e2de                	sd	s7,320(sp)
    8003008c:	c2d4                	sw	a3,4(a3)
    8003008e:	c454                	sw	a3,12(s0)

0000000080030090 <d_2_7>:
    80030090:	d0b6                	sw	a3,96(sp)
    80030092:	d006                	sw	ra,32(sp)
    80030094:	628e6577          	.insn	4, 0x628e6577
    80030098:	1c30                	addi	a2,sp,568
    8003009a:	bc26                	fsd	fs1,56(sp)
    8003009c:	6548                	ld	a0,136(a0)
    8003009e:	cbbc                	sw	a5,80(a5)

00000000800300a0 <d_2_8>:
    800300a0:	49b1                	li	s3,12
    800300a2:	cc362b73          	csrrs	s6,0xcc3,a2
    800300a6:	5e61                	li	t3,-8
    800300a8:	f986                	sd	ra,240(sp)
    800300aa:	ad18                	fsd	fa4,24(a0)
    800300ac:	bbfe                	fsd	ft11,496(sp)
    800300ae:	f504                	sd	s1,40(a0)

00000000800300b0 <d_2_9>:
    800300b0:	f486                	sd	ra,104(sp)
    800300b2:	2522732b          	.insn	4, 0x2522732b
    800300b6:	47a9                	li	a5,10
    800300b8:	cb0c8157          	.insn	4, 0xcb0c8157
    800300bc:	2816                	fld	fa6,320(sp)
    800300be:	3dad                	addiw	s11,s11,-21

00000000800300c0 <d_2_10>:
    800300c0:	1c92                	slli	s9,s9,0x24
    800300c2:	93ba                	add	t2,t2,a4
    800300c4:	291c                	fld	fa5,16(a0)
    800300c6:	3d76                	fld	fs10,376(sp)
    800300c8:	3cbe                	fld	fs9,488(sp)
    800300ca:	04d4                	addi	a3,sp,580
    800300cc:	cd92                	sw	tp,216(sp)
    800300ce:	          	lui	s0,0x9e0

00000000800300d0 <d_2_11>:
    800300d0:	009e                	slli	ra,ra,0x7
    800300d2:	c926                	sw	s1,144(sp)
    800300d4:	a62d31e7          	.insn	4, 0xa62d31e7
    800300d8:	800c                	.insn	2, 0x800c
    800300da:	7ac1                	lui	s5,0xffff0
    800300dc:	750a                	ld	a0,160(sp)
    800300de:	a391                	j	80030622 <_end_data2+0x422>

00000000800300e0 <d_2_12>:
    800300e0:	542d                	li	s0,-21
    800300e2:	6c3d                	lui	s8,0xf
    800300e4:	3c95                	addiw	s9,s9,-27
    800300e6:	3544f00b          	.insn	4, 0x3544f00b
    800300ea:	7ad1                	lui	s5,0xffff4
    800300ec:	eca3628f          	.insn	4, 0xeca3628f

00000000800300f0 <d_2_13>:
    800300f0:	cd26                	sw	s1,152(sp)
    800300f2:	03d3fd5b          	.insn	4, 0x03d3fd5b
    800300f6:	3eb1                	addiw	t4,t4,-20 # fffffffffd65c15a <_end+0xffffffff7d5fbf5a>
    800300f8:	d8f2                	sw	t3,112(sp)
    800300fa:	0090                	addi	a2,sp,64
    800300fc:	3a85                	addiw	s5,s5,-31 # ffffffffffff3fe1 <_end+0xffffffff7ff93de1>
    800300fe:	0095                	addi	ra,ra,5 # 5005 <_start-0x7fffaffb>

0000000080030100 <d_2_14>:
    80030100:	c9d9                	beqz	a1,80030196 <d_2_23+0x6>
    80030102:	064d                	addi	a2,a2,19
    80030104:	55af6957          	.insn	4, 0x55af6957
    80030108:	71f8                	ld	a4,224(a1)
    8003010a:	8654                	.insn	2, 0x8654
    8003010c:	2bf0                	fld	fa2,208(a5)
    8003010e:	e98c                	sd	a1,16(a1)

0000000080030110 <d_2_15>:
    80030110:	ad32                	fsd	fa2,152(sp)
    80030112:	29a9                	addiw	s3,s3,10
    80030114:	911e                	add	sp,sp,t2
    80030116:	04854a93          	xori	s5,a0,72
    8003011a:	5fe5                	li	t6,-7
    8003011c:	f3d9                	bnez	a5,800300a2 <d_2_8+0x2>
    8003011e:	dde6                	sw	s9,248(sp)

0000000080030120 <d_2_16>:
    80030120:	af2a785b          	.insn	4, 0xaf2a785b
    80030124:	259fb7fb          	.insn	4, 0x259fb7fb
    80030128:	41dfd963          	bge	t6,t4,8003053a <_end_data2+0x33a>
    8003012c:	058d                	addi	a1,a1,3
    8003012e:	ad5c                	fsd	fa5,152(a0)

0000000080030130 <d_2_17>:
    80030130:	06c2                	slli	a3,a3,0x10
    80030132:	07ce                	slli	a5,a5,0x13
    80030134:	8c38                	.insn	2, 0x8c38
    80030136:	8c34                	.insn	2, 0x8c34
    80030138:	bdc6                	fsd	fa7,248(sp)
    8003013a:	2996decf          	fnmadd.s	ft9,fa3,fs9,ft5,unknown
    8003013e:	77f8                	ld	a4,232(a5)

0000000080030140 <d_2_18>:
    80030140:	f011                	bnez	s0,80030044 <d_2_2+0x4>
    80030142:	4ad171e7          	.insn	4, 0x4ad171e7
    80030146:	8465                	srai	s0,s0,0x19
    80030148:	8b0c                	.insn	2, 0x8b0c
    8003014a:	4b84                	lw	s1,16(a5)
    8003014c:	8d322a2b          	.insn	4, 0x8d322a2b

0000000080030150 <d_2_19>:
    80030150:	2fb1                	addiw	t6,t6,12
    80030152:	2800                	fld	fs0,16(s0)
    80030154:	99e1                	andi	a1,a1,-8
    80030156:	a6be                	fsd	fa5,328(sp)
    80030158:	84a4                	.insn	2, 0x84a4
    8003015a:	6e841f6f          	jal	t5,80071842 <_end+0x11642>
    8003015e:	          	andi	zero,s3,1228

0000000080030160 <d_2_20>:
    80030160:	4cc9                	li	s9,18
    80030162:	579c                	lw	a5,40(a5)
    80030164:	a200                	fsd	fs0,0(a2)
    80030166:	f8ba4d47          	fmsub.s	fs10,fs4,fa1,ft11,rmm
    8003016a:	d090                	sw	a2,32(s1)
    8003016c:	09d2                	slli	s3,s3,0x14
    8003016e:	          	jal	s2,800bf20c <_end+0x5f00c>

0000000080030170 <d_2_21>:
    80030170:	09e8                	addi	a0,sp,220
    80030172:	9c41                	.insn	2, 0x9c41
    80030174:	de35                	beqz	a2,800300f0 <d_2_13>
    80030176:	613e                	ld	sp,456(sp)
    80030178:	fe83ed9b          	.insn	4, 0xfe83ed9b
    8003017c:	92ee                	add	t0,t0,s11
    8003017e:	e22e                	sd	a1,256(sp)

0000000080030180 <d_2_22>:
    80030180:	bdae                	fsd	fa1,248(sp)
    80030182:	d37e                	sw	t6,164(sp)
    80030184:	d494                	sw	a3,40(s1)
    80030186:	50d1                	li	ra,-12
    80030188:	569d                	li	a3,-25
    8003018a:	51c664d7          	.insn	4, 0x51c664d7
    8003018e:	7549                	lui	a0,0xffff2

0000000080030190 <d_2_23>:
    80030190:	796d                	lui	s2,0xffffb
    80030192:	c7d6                	sw	s5,204(sp)
    80030194:	a0be                	fsd	fa5,64(sp)
    80030196:	f6bd                	bnez	a3,80030104 <d_2_14+0x4>
    80030198:	11a69ceb          	.insn	4, 0x11a69ceb
    8003019c:	0c8320d7          	vredxor.vs	v1,v8,v6,v0.t

00000000800301a0 <d_2_24>:
    800301a0:	1c16                	slli	s8,s8,0x25
    800301a2:	75e0                	ld	s0,232(a1)
    800301a4:	1b6a                	slli	s6,s6,0x3a
    800301a6:	4742                	lw	a4,16(sp)
    800301a8:	725f 24f7 8581      	.insn	6, 0x858124f7725f
    800301ae:	8a69                	andi	a2,a2,26

00000000800301b0 <d_2_25>:
    800301b0:	67a636d3          	.insn	4, 0x67a636d3
    800301b4:	3e34                	fld	fa3,120(a2)
    800301b6:	5a82e72b          	.insn	4, 0x5a82e72b
    800301ba:	79e1                	lui	s3,0xffff8
    800301bc:	30e6                	fld	ft1,120(sp)
    800301be:	73a2                	ld	t2,40(sp)

00000000800301c0 <d_2_26>:
    800301c0:	5f0c                	lw	a1,56(a4)
    800301c2:	61b44e4b          	fnmsub.s	ft8,fs0,fs11,fa2,rmm
    800301c6:	bb92dccb          	fnmsub.d	fs9,ft5,fs9,fs7,unknown
    800301ca:	ef188e13          	addi	t3,a7,-271
    800301ce:	          	.insn	4, 0x7cef1a13

00000000800301d0 <d_2_27>:
    800301d0:	82917cef          	jal	s9,7ff479f8 <_start-0xb8608>
    800301d4:	fd39                	bnez	a0,80030132 <d_2_17+0x2>
    800301d6:	bbae                	fsd	fa1,496(sp)
    800301d8:	dcaa                	sw	a0,120(sp)
    800301da:	6ec8                	ld	a0,152(a3)
    800301dc:	3dac                	fld	fa1,120(a1)
    800301de:	f638                	sd	a4,104(a2)
    800301e0:	74710863          	beq	sp,t2,80030930 <_end_data2+0x730>
    800301e4:	5e32                	lw	t3,44(sp)
    800301e6:	101a                	c.slli	zero,0x26
    800301e8:	d15e4f23          	.insn	4, 0xd15e4f23
    800301ec:	8845                	andi	s0,s0,17
    800301ee:	be66                	fsd	fs9,312(sp)
    800301f0:	6fa8                	ld	a0,88(a5)
    800301f2:	6992                	ld	s3,256(sp)
    800301f4:	1138                	addi	a4,sp,168
    800301f6:	e170                	sd	a2,192(a0)
    800301f8:	c8b6                	sw	a3,80(sp)
    800301fa:	e4c1                	bnez	s1,80030282 <_end_data2+0x82>
    800301fc:	21d9                	addiw	gp,gp,22
    800301fe:	c368                	sw	a0,68(a4)

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	7e83b293          	sltiu	t0,t2,2024
    80040004:	d5f5                	beqz	a1,8003fff0 <_end_data2+0xfdf0>
    80040006:	c8a9f32f          	.insn	4, 0xc8a9f32f
    8004000a:	14c0                	addi	s0,sp,612
    8004000c:	ae58                	fsd	fa4,152(a2)
    8004000e:	cd9a                	sw	t1,216(sp)
    80040010:	b161                	j	8003fc98 <_end_data2+0xfa98>
    80040012:	fb54                	sd	a3,176(a4)
    80040014:	cdf5                	beqz	a1,80040110 <d_3_15>
    80040016:	ffde                	sd	s7,504(sp)
    80040018:	83d5                	srli	a5,a5,0x15
    8004001a:	cb1d                	beqz	a4,80040050 <d_3_3>
    8004001c:	e846                	sd	a7,16(sp)
    8004001e:	44de                	lw	s1,212(sp)

0000000080040020 <d_3_0>:
    80040020:	b8a0                	fsd	fs0,112(s1)
    80040022:	6da1                	lui	s11,0x8
    80040024:	37a4                	fld	fs1,104(a5)
    80040026:	270e                	fld	fa4,192(sp)
    80040028:	dc30                	sw	a2,120(s0)
    8004002a:	f26c                	sd	a1,224(a2)
    8004002c:	e19e                	sd	t2,192(sp)
    8004002e:	1322                	slli	t1,t1,0x28

0000000080040030 <d_3_1>:
    80040030:	b848                	fsd	fa0,176(s0)
    80040032:	f8d6c03f b036c011 	.insn	8, 0xb036c011f8d6c03f
    8004003a:	3a12                	fld	fs4,288(sp)
    8004003c:	98e8                	.insn	2, 0x98e8
    8004003e:	          	lh	a6,-1991(s8) # e839 <_start-0x7fff17c7>

0000000080040040 <d_3_2>:
    80040040:	839c                	.insn	2, 0x839c
    80040042:	6b11                	lui	s6,0x4
    80040044:	df4399f3          	csrrw	s3,0xdf4,t2
    80040048:	fed5                	bnez	a3,80040004 <_random_data3+0x4>
    8004004a:	ff7b2ffb          	.insn	4, 0xff7b2ffb
    8004004e:	799e                	ld	s3,480(sp)

0000000080040050 <d_3_3>:
    80040050:	ec70df83          	lhu	t6,-313(ra)
    80040054:	116e6277          	.insn	4, 0x116e6277
    80040058:	5ef1                	li	t4,-4
    8004005a:	5979                	li	s2,-2
    8004005c:	be8d                	j	8003fbce <_end_data2+0xf9ce>
    8004005e:	b011                	j	8003f862 <_end_data2+0xf662>

0000000080040060 <d_3_4>:
    80040060:	d949                	beqz	a0,8003fff2 <_end_data2+0xfdf2>
    80040062:	c08c                	sw	a1,0(s1)
    80040064:	b732                	fsd	fa2,424(sp)
    80040066:	2fa0                	fld	fs0,88(a5)
    80040068:	6556                	ld	a0,336(sp)
    8004006a:	0f34                	addi	a3,sp,920
    8004006c:	5ede                	lw	t4,244(sp)
    8004006e:	e389                	bnez	a5,80040070 <d_3_5>

0000000080040070 <d_3_5>:
    80040070:	50de02ef          	jal	t0,80120d7c <_end+0xc0b7c>
    80040074:	08d2                	slli	a7,a7,0x14
    80040076:	d836                	sw	a3,48(sp)
    80040078:	2c8c                	fld	fa1,24(s1)
    8004007a:	d831                	beqz	s0,8003ffce <_end_data2+0xfdce>
    8004007c:	df38                	sw	a4,120(a4)
    8004007e:	          	auipc	t1,0xda72f

0000000080040080 <d_3_6>:
    80040080:	da72                	sw	t3,52(sp)
    80040082:	328c                	fld	fa1,32(a3)
    80040084:	9835                	andi	s0,s0,-19
    80040086:	0995                	addi	s3,s3,5 # ffffffffffff8005 <_end+0xffffffff7ff97e05>
    80040088:	d1dd                	beqz	a1,8004002e <d_3_0+0xe>
    8004008a:	c2a8                	sw	a0,64(a3)
    8004008c:	9d26                	add	s10,s10,s1
    8004008e:	          	jal	a1,8005f2e6 <_end_data4+0xf0e6>

0000000080040090 <d_3_7>:
    80040090:	2581                	sext.w	a1,a1
    80040092:	02ed                	addi	t0,t0,27
    80040094:	0ab2e897          	auipc	a7,0xab2e
    80040098:	1dc6                	slli	s11,s11,0x31
    8004009a:	3dd1                	addiw	s11,s11,-12 # 7ff4 <_start-0x7fff800c>
    8004009c:	7568                	ld	a0,232(a0)
    8004009e:	18f9                	addi	a7,a7,-2 # 8ab6e092 <_end+0xab0de92>

00000000800400a0 <d_3_8>:
    800400a0:	9a7a                	add	s4,s4,t5
    800400a2:	bfe0                	fsd	fs0,248(a5)
    800400a4:	5726                	lw	a4,104(sp)
    800400a6:	18e487a7          	.insn	4, 0x18e487a7
    800400aa:	978e                	add	a5,a5,gp
    800400ac:	e9c0                	sd	s0,144(a1)
    800400ae:	ae6e                	fsd	fs11,280(sp)

00000000800400b0 <d_3_9>:
    800400b0:	270a                	fld	fa4,128(sp)
    800400b2:	338e3da3          	sd	s8,827(t3) # ffffffffffe0033b <_end+0xffffffff7fda013b>
    800400b6:	fe08                	sd	a0,56(a2)
    800400b8:	3a60                	fld	fs0,240(a2)
    800400ba:	0befbb43          	fmadd.d	fs6,ft11,ft10,ft1,rup
    800400be:	d20e                	sw	gp,36(sp)

00000000800400c0 <d_3_10>:
    800400c0:	c07c0fb7          	lui	t6,0xc07c0
    800400c4:	e262                	sd	s8,256(sp)
    800400c6:	f1f4                	sd	a3,224(a1)
    800400c8:	a1e2                	fsd	fs8,192(sp)
    800400ca:	963b992f          	.insn	4, 0x963b992f
    800400ce:	44b2                	lw	s1,12(sp)

00000000800400d0 <d_3_11>:
    800400d0:	d239                	beqz	a2,80040016 <_random_data3+0x16>
    800400d2:	6c38                	ld	a4,88(s0)
    800400d4:	c82d                	beqz	s0,80040146 <d_3_18+0x6>
    800400d6:	1fd4                	addi	a3,sp,1012
    800400d8:	c1d1                	beqz	a1,8004015c <d_3_19+0xc>
    800400da:	f140                	sd	s0,160(a0)
    800400dc:	01a5                	addi	gp,gp,9
    800400de:	          	sb	a0,1042(zero) # 412 <_start-0x7ffffbee>

00000000800400e0 <d_3_12>:
    800400e0:	40a0                	lw	s0,64(s1)
    800400e2:	7abd                	lui	s5,0xfffef
    800400e4:	9364                	.insn	2, 0x9364
    800400e6:	f149fde3          	bgeu	s3,s4,80040000 <_random_data3>
    800400ea:	b8da                	fsd	fs6,112(sp)
    800400ec:	1132                	slli	sp,sp,0x2c
    800400ee:	8602                	jr	a2

00000000800400f0 <d_3_13>:
    800400f0:	4188                	lw	a0,0(a1)
    800400f2:	ea466943          	fmadd.d	fs2,fa2,ft4,ft9,unknown
    800400f6:	ee6d                	bnez	a2,800401f0 <d_3_27+0x20>
    800400f8:	ac6c                	fsd	fa1,216(s0)
    800400fa:	00bb423f  	.insn	8, 0xc39df06400bb423f

0000000080040100 <d_3_14>:
    80040100:	c39d                	beqz	a5,80040126 <d_3_16+0x6>
    80040102:	62c8                	ld	a0,128(a3)
    80040104:	f4e1                	bnez	s1,800400cc <d_3_10+0xc>
    80040106:	b3182f7b          	.insn	4, 0xb3182f7b
    8004010a:	d11e                	sw	t2,160(sp)
    8004010c:	564d                	li	a2,-13
    8004010e:	5f0a                	lw	t5,160(sp)

0000000080040110 <d_3_15>:
    80040110:	d7ee                	sw	s11,236(sp)
    80040112:	4817a79b          	.insn	4, 0x4817a79b
    80040116:	7906                	ld	s2,96(sp)
    80040118:	9486                	add	s1,s1,ra
    8004011a:	2484                	fld	fs1,8(s1)
    8004011c:	42a9                	li	t0,10
    8004011e:	7e5e                	ld	t3,496(sp)

0000000080040120 <d_3_16>:
    80040120:	3ed0                	fld	fa2,184(a3)
    80040122:	9385                	srli	a5,a5,0x21
    80040124:	aad5                	j	80040318 <_end_data3+0x118>
    80040126:	b5ed                	j	80040010 <_random_data3+0x10>
    80040128:	6991                	lui	s3,0x4
    8004012a:	deac6ab7          	lui	s5,0xdeac6
    8004012e:	9792                	add	a5,a5,tp

0000000080040130 <d_3_17>:
    80040130:	54f4                	lw	a3,108(s1)
    80040132:	da90                	sw	a2,48(a3)
    80040134:	55c9                	li	a1,-14
    80040136:	275ca82f          	amoxor.w.aqrl	a6,s5,(s9)
    8004013a:	5f98                	lw	a4,56(a5)
    8004013c:	ed518aa3          	sb	s5,-299(gp)

0000000080040140 <d_3_18>:
    80040140:	a18592b7          	lui	t0,0xa1859
    80040144:	c399                	beqz	a5,8004014a <d_3_18+0xa>
    80040146:	fed2                	sd	s4,376(sp)
    80040148:	75d0                	ld	a2,168(a1)
    8004014a:	8df6                	mv	s11,t4
    8004014c:	2930                	fld	fa2,80(a0)
    8004014e:	          	jal	t3,800c9212 <_end+0x69012>

0000000080040150 <d_3_19>:
    80040150:	0c48                	addi	a0,sp,532
    80040152:	d456                	sw	s5,40(sp)
    80040154:	c9b0                	sw	a2,80(a1)
    80040156:	5b89                	li	s7,-30
    80040158:	1912                	slli	s2,s2,0x24
    8004015a:	6e6e                	ld	t3,216(sp)
    8004015c:	ba21                	j	8003fa74 <_end_data2+0xf874>
    8004015e:	860d                	srai	a2,a2,0x3

0000000080040160 <d_3_20>:
    80040160:	3abcff47          	fmsub.d	ft10,fs9,fa1,ft7
    80040164:	4fdda947          	.insn	4, 0x4fdda947
    80040168:	8d0c2ce7          	.insn	4, 0x8d0c2ce7
    8004016c:	a3babcb3          	.insn	4, 0xa3babcb3

0000000080040170 <d_3_21>:
    80040170:	fbbe                	sd	a5,496(sp)
    80040172:	6a5c                	ld	a5,144(a2)
    80040174:	cf84                	sw	s1,24(a5)
    80040176:	ca0d                	beqz	a2,800401a8 <d_3_24+0x8>
    80040178:	95bd147f dc18a151 	.insn	12, 0x739bded0dc18a15195bd147f
    80040180:	 

0000000080040180 <d_3_22>:
    80040180:	ded0                	sw	a2,60(a3)
    80040182:	be38739b          	.insn	4, 0xbe38739b
    80040186:	481df167          	.insn	4, 0x481df167
    8004018a:	a36d                	j	80040734 <_end_data3+0x534>
    8004018c:	712c                	ld	a1,96(a0)
    8004018e:	1a46                	slli	s4,s4,0x31

0000000080040190 <d_3_23>:
    80040190:	13ec                	addi	a1,sp,492
    80040192:	af22                	fsd	fs0,408(sp)
    80040194:	9ab8a38f          	.insn	4, 0x9ab8a38f
    80040198:	0f26                	slli	t5,t5,0x9
    8004019a:	d6dc                	sw	a5,44(a3)
    8004019c:	1b92                	slli	s7,s7,0x24
    8004019e:	ae20                	fsd	fs0,88(a2)

00000000800401a0 <d_3_24>:
    800401a0:	fa7858db          	.insn	4, 0xfa7858db
    800401a4:	5a11                	li	s4,-28
    800401a6:	d364                	sw	s1,100(a4)
    800401a8:	9c3a                	add	s8,s8,a4
    800401aa:	d07c                	sw	a5,100(s0)
    800401ac:	d6c4                	sw	s1,44(a3)
    800401ae:	d32a                	sw	a0,164(sp)

00000000800401b0 <d_3_25>:
    800401b0:	9ffa                	add	t6,t6,t5
    800401b2:	a8ff c77e 3e80 9790 	.insn	14, 0xf51e274b3a7597903e80c77ea8ff
    800401ba:	3a75 274b f51e 

00000000800401c0 <d_3_26>:
    800401c0:	4b162e97          	auipc	t4,0x4b162
    800401c4:	229a                	fld	ft5,384(sp)
    800401c6:	630e                	ld	t1,192(sp)
    800401c8:	880d                	andi	s0,s0,3
    800401ca:	4fc4                	lw	s1,28(a5)
    800401cc:	943c857b          	.insn	4, 0x943c857b

00000000800401d0 <d_3_27>:
    800401d0:	33fd                	addiw	t2,t2,-1
    800401d2:	e95d                	bnez	a0,80040288 <_end_data3+0x88>
    800401d4:	3486                	fld	fs1,96(sp)
    800401d6:	c02a                	sw	a0,0(sp)
    800401d8:	1b90                	addi	a2,sp,496
    800401da:	12a2                	slli	t0,t0,0x28
    800401dc:	28a8                	fld	fa0,80(s1)
    800401de:	ecaa                	sd	a0,88(sp)
    800401e0:	fc51                	bnez	s0,8004017c <d_3_21+0xc>
    800401e2:	e209cadb          	.insn	4, 0xe209cadb
    800401e6:	fed1008b          	.insn	4, 0xfed1008b
    800401ea:	fc90                	sd	a2,56(s1)
    800401ec:	ad39a197          	auipc	gp,0xad39a
    800401f0:	87d29c93          	.insn	4, 0x87d29c93
    800401f4:	1fc9                	addi	t6,t6,-14 # ffffffffc07bfff2 <_end+0xffffffff4075fdf2>
    800401f6:	1fe4                	addi	s1,sp,1020
    800401f8:	d0b8                	sw	a4,96(s1)
    800401fa:	69f6                	ld	s3,344(sp)
    800401fc:	360c                	fld	fa1,40(a2)
    800401fe:	6d4c                	ld	a1,152(a0)

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	b53fb77b          	.insn	4, 0xb53fb77b
    80050004:	253e                	fld	fa0,456(sp)
    80050006:	de62                	sw	s8,60(sp)
    80050008:	c6c2                	sw	a6,76(sp)
    8005000a:	0ada573b          	.insn	4, 0x0ada573b
    8005000e:	a78a                	fsd	ft2,456(sp)
    80050010:	8c29                	xor	s0,s0,a0
    80050012:	d45a                	sw	s6,40(sp)
    80050014:	f982                	sd	zero,240(sp)
    80050016:	a50432af          	amomax.d.aq	t0,a6,(s0)
    8005001a:	23b1                	addiw	t2,t2,12
    8005001c:	2919                	addiw	s2,s2,6 # ffffffffffffb006 <_end+0xffffffff7ff9ae06>
    8005001e:	280d                	addiw	a6,a6,3 # 9003 <_start-0x7fff6ffd>

0000000080050020 <d_4_0>:
    80050020:	81ed                	srli	a1,a1,0x1b
    80050022:	f706                	sd	ra,424(sp)
    80050024:	7acc                	ld	a1,176(a3)
    80050026:	0096                	slli	ra,ra,0x5
    80050028:	de42                	sw	a6,60(sp)
    8005002a:	7916                	ld	s2,352(sp)
    8005002c:	0ca1                	addi	s9,s9,8
    8005002e:	          	.insn	4, 0x735653af

0000000080050030 <d_4_1>:
    80050030:	7356                	ld	t1,368(sp)
    80050032:	1471                	addi	s0,s0,-4 # 9dfffc <_start-0x7f620004>
    80050034:	fb3ff00f          	.insn	4, 0xfb3ff00f
    80050038:	e9cfa7a7          	fsw	ft8,-369(t6)
    8005003c:	8935                	andi	a0,a0,13
    8005003e:	          	.insn	4, 0x34ab0247

0000000080050040 <d_4_2>:
    80050040:	789634ab          	.insn	4, 0x789634ab
    80050044:	6e45                	lui	t3,0x11
    80050046:	64c1                	lui	s1,0x10
    80050048:	af5e                	fsd	fs7,408(sp)
    8005004a:	1311                	addi	t1,t1,-28 # 5a76f062 <_start-0x25890f9e>
    8005004c:	7a88                	ld	a0,48(a3)
    8005004e:	c1ee                	sw	s11,192(sp)

0000000080050050 <d_4_3>:
    80050050:	0965                	addi	s2,s2,25
    80050052:	a7d9                	j	80050818 <_end_data4+0x618>
    80050054:	c24d                	beqz	a2,800500f6 <d_4_13+0x6>
    80050056:	7697698f          	.insn	4, 0x7697698f
    8005005a:	bc18                	fsd	fa4,56(s0)
    8005005c:	9dee                	add	s11,s11,s11
    8005005e:	          	.insn	4, 0x89fb7e1b

0000000080050060 <d_4_4>:
    80050060:	382789fb          	.insn	4, 0x382789fb
    80050064:	8e9d                	sub	a3,a3,a5
    80050066:	5365                	li	t1,-7
    80050068:	f94e                	sd	s3,176(sp)
    8005006a:	9c6d                	.insn	2, 0x9c6d
    8005006c:	a2b0dec3          	fmadd.d	ft9,ft1,fa1,fs4,unknown

0000000080050070 <d_4_5>:
    80050070:	fd82                	sd	zero,248(sp)
    80050072:	36f2c41b          	.insn	4, 0x36f2c41b
    80050076:	d416                	sw	t0,40(sp)
    80050078:	afd1                	j	8005084c <_end_data4+0x64c>
    8005007a:	696c                	ld	a1,208(a0)
    8005007c:	01dadf0b          	.insn	4, 0x01dadf0b

0000000080050080 <d_4_6>:
    80050080:	1ec10447          	.insn	4, 0x1ec10447
    80050084:	6d95                	lui	s11,0x5
    80050086:	0086                	slli	ra,ra,0x1
    80050088:	8afd                	andi	a3,a3,31
    8005008a:	af16                	fsd	ft5,408(sp)
    8005008c:	8421e63b          	.insn	4, 0x8421e63b

0000000080050090 <d_4_7>:
    80050090:	cd60                	sw	s0,92(a0)
    80050092:	21b6                	fld	ft3,328(sp)
    80050094:	d239                	beqz	a2,8004ffda <_end_data3+0xfdda>
    80050096:	82c8                	.insn	2, 0x82c8
    80050098:	1e4c                	addi	a1,sp,820
    8005009a:	5d09                	li	s10,-30
    8005009c:	d196                	sw	t0,224(sp)
    8005009e:	b2fa                	fsd	ft10,352(sp)

00000000800500a0 <d_4_8>:
    800500a0:	1832                	slli	a6,a6,0x2c
    800500a2:	dd56                	sw	s5,184(sp)
    800500a4:	b0dd                	j	8004f98a <_end_data3+0xf78a>
    800500a6:	4345fe5b          	.insn	4, 0x4345fe5b
    800500aa:	4e9d                	li	t4,7
    800500ac:	1ace                	slli	s5,s5,0x33
    800500ae:	0d7e                	slli	s10,s10,0x1f

00000000800500b0 <d_4_9>:
    800500b0:	707a                	.insn	2, 0x707a
    800500b2:	8021                	srli	s0,s0,0x8
    800500b4:	21c0                	fld	fs0,128(a1)
    800500b6:	942c                	.insn	2, 0x942c
    800500b8:	2288                	fld	fa0,0(a3)
    800500ba:	a061                	j	80050142 <d_4_18+0x2>
    800500bc:	fc8a                	sd	sp,120(sp)
    800500be:	9664                	.insn	2, 0x9664

00000000800500c0 <d_4_10>:
    800500c0:	66a4e193          	ori	gp,s1,1642
    800500c4:	f2dc                	sd	a5,160(a3)
    800500c6:	abb0                	fsd	fa2,80(a5)
    800500c8:	4c0a                	lw	s8,128(sp)
    800500ca:	ebb4d193          	.insn	4, 0xebb4d193
    800500ce:	7d7e                	ld	s10,504(sp)

00000000800500d0 <d_4_11>:
    800500d0:	2c386d57          	vasub.vx	v26,v3,a6,v0.t
    800500d4:	263c                	fld	fa5,72(a2)
    800500d6:	6ded                	lui	s11,0x1b
    800500d8:	d7d6                	sw	s5,236(sp)
    800500da:	63e6                	ld	t2,88(sp)
    800500dc:	b13d                	j	8004fd0a <_end_data3+0xfb0a>
    800500de:	055e                	slli	a0,a0,0x17

00000000800500e0 <d_4_12>:
    800500e0:	e07d                	bnez	s0,800501c6 <d_4_26+0x6>
    800500e2:	90d1                	srli	s1,s1,0x34
    800500e4:	48b1                	li	a7,12
    800500e6:	ee0a                	sd	sp,280(sp)
    800500e8:	7f96                	ld	t6,352(sp)
    800500ea:	d5fc                	sw	a5,108(a1)
    800500ec:	0441                	addi	s0,s0,16
    800500ee:	          	.insn	4, 0xd4a1438f

00000000800500f0 <d_4_13>:
    800500f0:	d4a1                	beqz	s1,80050038 <d_4_1+0x8>
    800500f2:	212a                	fld	ft2,136(sp)
    800500f4:	1e6e                	slli	t3,t3,0x3b
    800500f6:	fe7f544b          	.insn	4, 0xfe7f544b
    800500fa:	6ec4                	ld	s1,152(a3)
    800500fc:	be4e                	fsd	fs3,312(sp)
    800500fe:	9829                	andi	s0,s0,-22

0000000080050100 <d_4_14>:
    80050100:	620301f7          	.insn	4, 0x620301f7
    80050104:	ab16                	fsd	ft5,400(sp)
    80050106:	c66e                	sw	s11,12(sp)
    80050108:	7592                	ld	a1,288(sp)
    8005010a:	3946                	fld	fs2,112(sp)
    8005010c:	c0fc116b          	.insn	4, 0xc0fc116b

0000000080050110 <d_4_15>:
    80050110:	65b93f7f 9a78e606 	.insn	16, 0xa840ee69250f76009a78e60665b93f7f
    80050118:	250f7600 a840ee69 

0000000080050120 <d_4_16>:
    80050120:	06b6                	slli	a3,a3,0xd
    80050122:	799773d7          	vsetvli	t2,a4,1945
    80050126:	2d8c                	fld	fa1,24(a1)
    80050128:	1798                	addi	a4,sp,992
    8005012a:	8f36                	mv	t5,a3
    8005012c:	95e15ad7          	.insn	4, 0x95e15ad7

0000000080050130 <d_4_17>:
    80050130:	332a                	fld	ft6,168(sp)
    80050132:	dce6                	sw	s9,120(sp)
    80050134:	a2a5                	j	8005029c <_end_data4+0x9c>
    80050136:	3c59                	addiw	s8,s8,-10
    80050138:	8198                	.insn	2, 0x8198
    8005013a:	7d74                	ld	a3,248(a0)
    8005013c:	3001c62b          	.insn	4, 0x3001c62b

0000000080050140 <d_4_18>:
    80050140:	6e000633          	.insn	4, 0x6e000633
    80050144:	c67983eb          	.insn	4, 0xc67983eb
    80050148:	3a35                	addiw	s4,s4,-19
    8005014a:	9071                	srli	s0,s0,0x3c
    8005014c:	7d26                	ld	s10,104(sp)
    8005014e:	8bed                	andi	a5,a5,27

0000000080050150 <d_4_19>:
    80050150:	56dc6b67          	.insn	4, 0x56dc6b67
    80050154:	9428                	.insn	2, 0x9428
    80050156:	83de623b          	.insn	4, 0x83de623b
    8005015a:	5469                	li	s0,-6
    8005015c:	c0ce                	sw	s3,64(sp)
    8005015e:	e708                	sd	a0,8(a4)

0000000080050160 <d_4_20>:
    80050160:	9a86                	add	s5,s5,ra
    80050162:	9da6                	add	s11,s11,s1
    80050164:	7c0e                	ld	s8,224(sp)
    80050166:	4c24                	lw	s1,88(s0)
    80050168:	9fb4                	.insn	2, 0x9fb4
    8005016a:	1e78                	addi	a4,sp,828
    8005016c:	34fa                	fld	fs1,440(sp)
    8005016e:	4fa1                	li	t6,8

0000000080050170 <d_4_21>:
    80050170:	2fb59e53          	.insn	4, 0x2fb59e53
    80050174:	3cee2e73          	csrrs	t3,0x3ce,t3
    80050178:	9b46                	add	s6,s6,a7
    8005017a:	d1d9                	beqz	a1,80050100 <d_4_14>
    8005017c:	d0c5                	beqz	s1,8005011c <d_4_15+0xc>
    8005017e:	9668                	.insn	2, 0x9668

0000000080050180 <d_4_22>:
    80050180:	6287098b          	.insn	4, 0x6287098b
    80050184:	8bf4                	.insn	2, 0x8bf4
    80050186:	a1ed                	j	80050670 <_end_data4+0x470>
    80050188:	1944                	addi	s1,sp,180
    8005018a:	94ca                	add	s1,s1,s2
    8005018c:	4270                	lw	a2,68(a2)
    8005018e:	a85c                	fsd	fa5,144(s0)

0000000080050190 <d_4_23>:
    80050190:	41c8ee93          	ori	t4,a7,1052
    80050194:	ac58                	fsd	fa4,152(s0)
    80050196:	3e36                	fld	ft8,360(sp)
    80050198:	13d8bff3          	csrrc	t6,0x13d,a7
    8005019c:	879d                	srai	a5,a5,0x7
    8005019e:	40ad                	li	ra,11

00000000800501a0 <d_4_24>:
    800501a0:	15ea                	slli	a1,a1,0x3a
    800501a2:	5cae                	lw	s9,232(sp)
    800501a4:	7fca                	ld	t6,176(sp)
    800501a6:	209e                	fld	ft1,448(sp)
    800501a8:	a7e8c797          	auipc	a5,0xa7e8c
    800501ac:	3d38                	fld	fa4,120(a0)
    800501ae:	12a5                	addi	t0,t0,-23 # ffffffffa1858fe9 <_end+0xffffffff217f8de9>

00000000800501b0 <d_4_25>:
    800501b0:	addd                	j	800508a6 <_end_data4+0x6a6>
    800501b2:	59b8                	lw	a4,112(a1)
    800501b4:	944e                	add	s0,s0,s3
    800501b6:	26ce                	fld	fa3,208(sp)
    800501b8:	5d6a                	lw	s10,184(sp)
    800501ba:	f2fd                	bnez	a3,800501a0 <d_4_24>
    800501bc:	aa0c9c63          	bnez	s9,8004f474 <_end_data3+0xf274>

00000000800501c0 <d_4_26>:
    800501c0:	8d44                	.insn	2, 0x8d44
    800501c2:	f1d6                	sd	s5,224(sp)
    800501c4:	aac1                	j	80050394 <_end_data4+0x194>
    800501c6:	aeb2                	fsd	fa2,344(sp)
    800501c8:	4c038f5b          	.insn	4, 0x4c038f5b
    800501cc:	5c059d37          	lui	s10,0x5c059

00000000800501d0 <d_4_27>:
    800501d0:	a889                	j	80050222 <_end_data4+0x22>
    800501d2:	d99e                	sw	t2,240(sp)
    800501d4:	2cd4                	fld	fa3,152(s1)
    800501d6:	d983174b          	fnmsub.s	fa4,ft6,fs8,fs11,rtz
    800501da:	b7df 6b8a d020      	.insn	6, 0xd0206b8ab7df
    800501e0:	45aa                	lw	a1,136(sp)
    800501e2:	94ad                	srai	s1,s1,0x2b
    800501e4:	850cdb93          	.insn	4, 0x850cdb93
    800501e8:	ac1c                	fsd	fa5,24(s0)
    800501ea:	cb55                	beqz	a4,8005029e <_end_data4+0x9e>
    800501ec:	f21a                	sd	t1,288(sp)
    800501ee:	bcde                	fsd	fs7,120(sp)
    800501f0:	287c                	fld	fa5,208(s0)
    800501f2:	3fca5357          	vfslide1down.vf	v6,v28,fs4
    800501f6:	bee9d1e3          	bge	s3,a4,8004fdd8 <_end_data3+0xfbd8>
    800501fa:	6146                	ld	sp,80(sp)
    800501fc:	9e5c                	.insn	2, 0x9e5c
    800501fe:	5268                	lw	a0,100(a2)

Disassembly of section .data.random5:

0000000080060000 <_random_data5>:
    80060000:	5647b6db          	.insn	4, 0x5647b6db
    80060004:	b8fc                	fsd	fa5,240(s1)
    80060006:	a9ee42c7          	fmsub.s	ft5,ft8,ft10,fs5,rmm
    8006000a:	1b12                	slli	s6,s6,0x24
    8006000c:	c5d4                	sw	a3,12(a1)
    8006000e:	be2a                	fsd	fa0,312(sp)
    80060010:	c82d                	beqz	s0,80060082 <d_5_6+0x2>
    80060012:	d7bd                	beqz	a5,8005ff80 <_end_data4+0xfd80>
    80060014:	b3c87d63          	bgeu	a6,t3,8005f34e <_end_data4+0xf14e>
    80060018:	a199                	j	8006045e <_end+0x25e>
    8006001a:	aef2                	fsd	ft8,344(sp)
    8006001c:	aeca                	fsd	fs2,344(sp)
    8006001e:	a4c9                	j	800602e0 <_end+0xe0>

0000000080060020 <d_5_0>:
    80060020:	725c                	ld	a5,160(a2)
    80060022:	2504                	fld	fs1,8(a0)
    80060024:	9604                	.insn	2, 0x9604
    80060026:	28c41527          	.insn	4, 0x28c41527
    8006002a:	7d86                	ld	s11,96(sp)
    8006002c:	7329                	lui	t1,0xfffea
    8006002e:	398a                	fld	fs3,160(sp)

0000000080060030 <d_5_1>:
    80060030:	5015                	c.li	zero,-27
    80060032:	d645                	beqz	a2,8005ffda <_end_data4+0xfdda>
    80060034:	7c4e0d67          	jalr	s10,1988(t3) # 117c4 <_start-0x7ffee83c>
    80060038:	16d9                	addi	a3,a3,-10
    8006003a:	14f64e87          	.insn	4, 0x14f64e87
    8006003e:	ea7c                	sd	a5,208(a2)

0000000080060040 <d_5_2>:
    80060040:	d219                	beqz	a2,8005ff46 <_end_data4+0xfd46>
    80060042:	c011                	beqz	s0,80060046 <d_5_2+0x6>
    80060044:	288a                	fld	fa7,128(sp)
    80060046:	6d00                	ld	s0,24(a0)
    80060048:	c5b1b8b3          	.insn	4, 0xc5b1b8b3
    8006004c:	15d8                	addi	a4,sp,740
    8006004e:	bb5f        	.insn	6, 0xeb49fc9bbb5f

0000000080060050 <d_5_3>:
    80060050:	eb49fc9b          	.insn	4, 0xeb49fc9b
    80060054:	30fe                	fld	ft1,504(sp)
    80060056:	590c                	lw	a1,48(a0)
    80060058:	3562                	fld	fa0,56(sp)
    8006005a:	ef6e                	sd	s11,408(sp)
    8006005c:	d856                	sw	s5,48(sp)
    8006005e:	9750                	.insn	2, 0x9750

0000000080060060 <d_5_4>:
    80060060:	9bba                	add	s7,s7,a4
    80060062:	f201fe37          	lui	t3,0xf201f
    80060066:	fae6                	sd	s9,368(sp)
    80060068:	a4012867          	.insn	4, 0xa4012867
    8006006c:	e7ee                	sd	s11,456(sp)
    8006006e:	0a9e                	slli	s5,s5,0x7

0000000080060070 <d_5_5>:
    80060070:	4bca                	lw	s7,144(sp)
    80060072:	ec78                	sd	a4,216(s0)
    80060074:	e7dc                	sd	a5,136(a5)
    80060076:	3f0e                	fld	ft10,224(sp)
    80060078:	a49e                	fsd	ft7,72(sp)
    8006007a:	e94a                	sd	s2,144(sp)
    8006007c:	4c28                	lw	a0,88(s0)
    8006007e:	7838                	ld	a4,112(s0)

0000000080060080 <d_5_6>:
    80060080:	48c0                	lw	s0,20(s1)
    80060082:	dbf0                	sw	a2,116(a5)
    80060084:	1942                	slli	s2,s2,0x30
    80060086:	2be4                	fld	fs1,208(a5)
    80060088:	7ce8                	ld	a0,248(s1)
    8006008a:	9935                	andi	a0,a0,-19
    8006008c:	f0b2                	sd	a2,96(sp)
    8006008e:	3136                	fld	ft2,360(sp)

0000000080060090 <d_5_7>:
    80060090:	19debdbf 99efa150 	.insn	8, 0x99efa15019debdbf
    80060098:	af6f9fc7          	.insn	4, 0xaf6f9fc7
    8006009c:	d9e1                	beqz	a1,8006006c <d_5_4+0xc>
    8006009e:	4ee4                	lw	s1,92(a3)

00000000800600a0 <d_5_8>:
    800600a0:	04d6                	slli	s1,s1,0x15
    800600a2:	21a0                	fld	fs0,64(a1)
    800600a4:	43c3a2fb          	.insn	4, 0x43c3a2fb
    800600a8:	8cbc                	.insn	2, 0x8cbc
    800600aa:	600a                	.insn	2, 0x600a
    800600ac:	9507eefb          	.insn	4, 0x9507eefb

00000000800600b0 <d_5_9>:
    800600b0:	8182                	jr	gp
    800600b2:	72666553          	.insn	4, 0x72666553
    800600b6:	6273f92f          	.insn	4, 0x6273f92f
    800600ba:	17b8                	addi	a4,sp,1000
    800600bc:	0d5a                	slli	s10,s10,0x16
    800600be:	c129                	beqz	a0,80060100 <d_5_14>

00000000800600c0 <d_5_10>:
    800600c0:	ce05caa7          	.insn	4, 0xce05caa7
    800600c4:	6a9fe357          	.insn	4, 0x6a9fe357
    800600c8:	8d9c                	.insn	2, 0x8d9c
    800600ca:	b602                	fsd	ft0,296(sp)
    800600cc:	3790                	fld	fa2,40(a5)
    800600ce:	56b0                	lw	a2,104(a3)

00000000800600d0 <d_5_11>:
    800600d0:	26fd                	addiw	a3,a3,31
    800600d2:	1661                	addi	a2,a2,-8
    800600d4:	07ba                	slli	a5,a5,0xe
    800600d6:	e760                	sd	s0,200(a4)
    800600d8:	cfc1                	beqz	a5,80060170 <d_5_21>
    800600da:	e636                	sd	a3,264(sp)
    800600dc:	b5dee417          	auipc	s0,0xb5dee

00000000800600e0 <d_5_12>:
    800600e0:	c5cc                	sw	a1,12(a1)
    800600e2:	f5c0                	sd	s0,168(a1)
    800600e4:	3119                	addiw	sp,sp,-26
    800600e6:	6625                	lui	a2,0x9
    800600e8:	54647e1b          	.insn	4, 0x54647e1b
    800600ec:	9a26                	add	s4,s4,s1
    800600ee:	          	.insn	4, 0xce93c2bb

00000000800600f0 <d_5_13>:
    800600f0:	fe12ce93          	xori	t4,t0,-31
    800600f4:	76f8                	ld	a4,232(a3)
    800600f6:	7e10                	ld	a2,56(a2)
    800600f8:	eed2                	sd	s4,344(sp)
    800600fa:	5e02c63f  	.insn	8, 0xc8dd3d415e02c63f

0000000080060100 <d_5_14>:
    80060100:	c8dd                	beqz	s1,800601b6 <d_5_25+0x6>
    80060102:	d100                	sw	s0,32(a0)
    80060104:	3872                	fld	fa6,312(sp)
    80060106:	c0ebb81b          	.insn	4, 0xc0ebb81b
    8006010a:	892e                	mv	s2,a1
    8006010c:	50c0e9a7          	.insn	4, 0x50c0e9a7

0000000080060110 <d_5_15>:
    80060110:	c268                	sw	a0,68(a2)
    80060112:	78ced7fb          	.insn	4, 0x78ced7fb
    80060116:	ed6c                	sd	a1,216(a0)
    80060118:	d086                	sw	ra,96(sp)
    8006011a:	77967a4b          	.insn	4, 0x77967a4b
    8006011e:	e038                	sd	a4,64(s0)

0000000080060120 <d_5_16>:
    80060120:	79ea                	ld	s3,184(sp)
    80060122:	2c60                	fld	fs0,216(s0)
    80060124:	44e1                	li	s1,24
    80060126:	4582                	lw	a1,0(sp)
    80060128:	7ad2                	ld	s5,304(sp)
    8006012a:	2d12                	fld	fs10,256(sp)
    8006012c:	eb4d                	bnez	a4,800601de <d_5_27+0xe>
    8006012e:	34e5                	addiw	s1,s1,-7 # fff9 <_start-0x7fff0007>

0000000080060130 <d_5_17>:
    80060130:	f430                	sd	a2,104(s0)
    80060132:	00fe                	slli	ra,ra,0x1f
    80060134:	bd997493          	andi	s1,s2,-1063
    80060138:	3632                	fld	fa2,296(sp)
    8006013a:	3a2a                	fld	fs4,168(sp)
    8006013c:	0fcf7e97          	auipc	t4,0xfcf7

0000000080060140 <d_5_18>:
    80060140:	8b180e57          	vssubu.vv	v28,v17,v16
    80060144:	8d68                	.insn	2, 0x8d68
    80060146:	93bd                	srli	a5,a5,0x2f
    80060148:	f554                	sd	a3,168(a0)
    8006014a:	8a0a                	mv	s4,sp
    8006014c:	5376                	lw	t1,124(sp)
    8006014e:	d7c9                	beqz	a5,800600d8 <d_5_11+0x8>

0000000080060150 <d_5_19>:
    80060150:	d232                	sw	a2,36(sp)
    80060152:	7a2c                	ld	a1,112(a2)
    80060154:	4304                	lw	s1,0(a4)
    80060156:	8791                	srai	a5,a5,0x4
    80060158:	89f4                	.insn	2, 0x89f4
    8006015a:	f61e                	sd	t2,296(sp)
    8006015c:	b195                	j	8005fdc0 <_end_data4+0xfbc0>
    8006015e:	6921                	lui	s2,0x8

0000000080060160 <d_5_20>:
    80060160:	8e40                	.insn	2, 0x8e40
    80060162:	b33ef9cb          	fnmsub.d	fs3,ft9,fs3,fs6
    80060166:	a7730b3b          	.insn	4, 0xa7730b3b
    8006016a:	8f9a4f8f          	.insn	4, 0x8f9a4f8f
    8006016e:	e514                	sd	a3,8(a0)

0000000080060170 <d_5_21>:
    80060170:	b03d                	j	8005f99e <_end_data4+0xf79e>
    80060172:	06d8                	addi	a4,sp,836
    80060174:	c1ec45e7          	.insn	4, 0xc1ec45e7
    80060178:	0dd2                	slli	s11,s11,0x14
    8006017a:	6d31                	lui	s10,0xc
    8006017c:	37d134cb          	.insn	4, 0x37d134cb

0000000080060180 <d_5_22>:
    80060180:	7615                	lui	a2,0xfffe5
    80060182:	77fa4f6b          	.insn	4, 0x77fa4f6b
    80060186:	d24f5f4f          	fnmadd.d	ft10,ft10,ft4,fs10,unknown
    8006018a:	6026                	.insn	2, 0x6026
    8006018c:	7c787427          	.insn	4, 0x7c787427

0000000080060190 <d_5_23>:
    80060190:	68a1                	lui	a7,0x8
    80060192:	19b2                	slli	s3,s3,0x2c
    80060194:	d669                	beqz	a2,8006015e <d_5_19+0xe>
    80060196:	a249                	j	80060318 <_end+0x118>
    80060198:	b87a5297          	auipc	t0,0xb87a5
    8006019c:	69394213          	xori	tp,s2,1683

00000000800601a0 <d_5_24>:
    800601a0:	62c2                	ld	t0,16(sp)
    800601a2:	3302                	fld	ft6,32(sp)
    800601a4:	814d6903          	lwu	s2,-2028(s10) # b814 <_start-0x7fff47ec>
    800601a8:	6a56                	ld	s4,336(sp)
    800601aa:	217e                	fld	ft2,472(sp)
    800601ac:	499ee6d3          	.insn	4, 0x499ee6d3

00000000800601b0 <d_5_25>:
    800601b0:	4da1                	li	s11,8
    800601b2:	3b35                	addiw	s6,s6,-19 # 3fed <_start-0x7fffc013>
    800601b4:	2aec                	fld	fa1,208(a3)
    800601b6:	037e6e73          	csrrsi	t3,0x37,28
    800601ba:	2c19c29b          	.insn	4, 0x2c19c29b
    800601be:	          	.insn	4, 0x47e3794f

00000000800601c0 <d_5_26>:
    800601c0:	752f47e3          	blt	t5,s2,8006110e <_end+0xf0e>
    800601c4:	6f16                	ld	t5,320(sp)
    800601c6:	fee5                	bnez	a3,800601be <d_5_25+0xe>
    800601c8:	223f86e7          	jalr	a3,547(t6)
    800601cc:	4016                	.insn	2, 0x4016
    800601ce:	86a0                	.insn	2, 0x86a0

00000000800601d0 <d_5_27>:
    800601d0:	d92e975b          	.insn	4, 0xd92e975b
    800601d4:	3c8a                	fld	fs9,160(sp)
    800601d6:	62d2                	ld	t0,272(sp)
    800601d8:	b780                	fsd	fs0,40(a5)
    800601da:	3b46                	fld	fs6,112(sp)
    800601dc:	1786                	slli	a5,a5,0x21
    800601de:	b29f225b          	.insn	4, 0xb29f225b
    800601e2:	8a98                	.insn	2, 0x8a98
    800601e4:	9795                	srai	a5,a5,0x25
    800601e6:	6914                	ld	a3,16(a0)
    800601e8:	dcad                	beqz	s1,80060162 <d_5_20+0x2>
    800601ea:	af7d2023          	sw	s7,-1312(s10)
    800601ee:	9a40                	.insn	2, 0x9a40
    800601f0:	08df 6ed6 489d      	.insn	6, 0x489d6ed608df
    800601f6:	5985                	li	s3,-31
    800601f8:	d8f2                	sw	t3,112(sp)
    800601fa:	7a5ca887          	flw	fa7,1957(s9)
    800601fe:	e918                	sd	a4,16(a0)

Disassembly of section .riscv.attributes:

0000000000000000 <.riscv.attributes>:
   0:	ee41                	bnez	a2,98 <_start-0x7fffff68>
   2:	0000                	unimp
   4:	7200                	ld	s0,32(a2)
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <_start-0x7fffffec>
   c:	00e4                	addi	s1,sp,76
   e:	0000                	unimp
  10:	7205                	lui	tp,0xfffe1
  12:	3676                	fld	fa2,376(sp)
  14:	6934                	ld	a3,80(a0)
  16:	7032                	.insn	2, 0x7032
  18:	5f31                	li	t5,-20
  1a:	326d                	addiw	tp,tp,-5 # fffffffffffe0ffb <_end+0xffffffff7ff80dfb>
  1c:	3070                	fld	fa2,224(s0)
  1e:	615f 7032 5f31      	.insn	6, 0x5f317032615f
  24:	3266                	fld	ft4,120(sp)
  26:	3270                	fld	fa2,224(a2)
  28:	645f 7032 5f32      	.insn	6, 0x5f327032645f
  2e:	30703263          	.insn	4, 0x30703263
  32:	765f 7031 5f30      	.insn	6, 0x5f307031765f
  38:	3168                	fld	fa0,224(a0)
  3a:	3070                	fld	fa2,224(s0)
  3c:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  42:	316d                	addiw	sp,sp,-5
  44:	3070                	fld	fa2,224(s0)
  46:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  4c:	3170                	fld	fa2,224(a0)
  4e:	3070                	fld	fa2,224(s0)
  50:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  56:	317a                	fld	ft2,440(sp)
  58:	3070                	fld	fa2,224(s0)
  5a:	7a5f 6369 7273      	.insn	6, 0x727363697a5f
  60:	7032                	.insn	2, 0x7032
  62:	5f30                	lw	a2,120(a4)
  64:	697a                	ld	s2,408(sp)
  66:	6566                	ld	a0,88(sp)
  68:	636e                	ld	t1,216(sp)
  6a:	6965                	lui	s2,0x19
  6c:	7032                	.insn	2, 0x7032
  6e:	5f30                	lw	a2,120(a4)
  70:	6d7a                	ld	s10,408(sp)
  72:	756d                	lui	a0,0xffffb
  74:	316c                	fld	fa1,224(a0)
  76:	3070                	fld	fa2,224(s0)
  78:	7a5f 6161 6f6d      	.insn	6, 0x6f6d61617a5f
  7e:	7031                	c.lui	zero,0xfffec
  80:	5f30                	lw	a2,120(a4)
  82:	617a                	ld	sp,408(sp)
  84:	726c                	ld	a1,224(a2)
  86:	70316373          	csrrsi	t1,0x703,2
  8a:	5f30                	lw	a2,120(a4)
  8c:	637a                	ld	t1,408(sp)
  8e:	3161                	addiw	sp,sp,-8
  90:	3070                	fld	fa2,224(s0)
  92:	7a5f 6463 7031      	.insn	6, 0x703164637a5f
  98:	5f30                	lw	a2,120(a4)
  9a:	767a                	ld	a2,440(sp)
  9c:	3365                	addiw	t1,t1,-7 # ffffffffffff9ff9 <_end+0xffffffff7ff99df9>
  9e:	6632                	ld	a2,264(sp)
  a0:	7031                	c.lui	zero,0xfffec
  a2:	5f30                	lw	a2,120(a4)
  a4:	767a                	ld	a2,440(sp)
  a6:	3365                	addiw	t1,t1,-7
  a8:	7832                	ld	a6,296(sp)
  aa:	7031                	c.lui	zero,0xfffec
  ac:	5f30                	lw	a2,120(a4)
  ae:	767a                	ld	a2,440(sp)
  b0:	3665                	addiw	a2,a2,-7 # fffffffffffe4ff9 <_end+0xffffffff7ff84df9>
  b2:	6434                	ld	a3,72(s0)
  b4:	7031                	c.lui	zero,0xfffec
  b6:	5f30                	lw	a2,120(a4)
  b8:	767a                	ld	a2,440(sp)
  ba:	3665                	addiw	a2,a2,-7
  bc:	6634                	ld	a3,72(a2)
  be:	7031                	c.lui	zero,0xfffec
  c0:	5f30                	lw	a2,120(a4)
  c2:	767a                	ld	a2,440(sp)
  c4:	3665                	addiw	a2,a2,-7
  c6:	7834                	ld	a3,112(s0)
  c8:	7031                	c.lui	zero,0xfffec
  ca:	5f30                	lw	a2,120(a4)
  cc:	767a                	ld	a2,440(sp)
  ce:	316c                	fld	fa1,224(a0)
  d0:	3832                	fld	fa6,296(sp)
  d2:	3162                	fld	ft2,56(sp)
  d4:	3070                	fld	fa2,224(s0)
  d6:	7a5f 6c76 3233      	.insn	6, 0x32336c767a5f
  dc:	3162                	fld	ft2,56(sp)
  de:	3070                	fld	fa2,224(s0)
  e0:	7a5f 6c76 3436      	.insn	6, 0x34366c767a5f
  e6:	3162                	fld	ft2,56(sp)
  e8:	3070                	fld	fa2,224(s0)
  ea:	0800                	addi	s0,sp,16
  ec:	0a01                	addi	s4,s4,0
  ee:	0b                	.byte	0x0b
