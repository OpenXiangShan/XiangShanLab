#include <klib.h>

#define CSR_MSTATUS  0x300
#define CSR_MEDELEG  0x302
#define CSR_MIDELEG  0x303
#define CSR_MTVEC    0x305
#define CSR_MENVCFG  0x30a
#define CSR_MEPC     0x341
#define CSR_SATP     0x180

#define BIT(n) (1UL << (n))

#define MENVCFG_CBCFE BIT(6)
#define MENVCFG_CBIE  (1UL << 4)
#define MENVCFG_CBZE  BIT(7)
#define MENVCFG_PBMTE BIT(62)

#define MSTATUS_MPP   (3UL << 11)
#define MSTATUS_MPP_S (1UL << 11)
#define MSTATUS_MPP_M (3UL << 11)

#define PTE_V   BIT(0)
#define PTE_R   BIT(1)
#define PTE_W   BIT(2)
#define PTE_X   BIT(3)
#define PTE_A   BIT(6)
#define PTE_D   BIT(7)
#define PTE_PBMT_NC BIT(61)

#define LEAF_PTE(pa, flags) (((((unsigned long)(pa)) >> 12) << 10) | (flags))
#define NONLEAF_PTE(pa)     (((((unsigned long)(pa)) >> 12) << 10) | PTE_V)

#define SATP_SV39 (8UL << 60)

__attribute__((aligned(4096))) static unsigned long g_root[512];
__attribute__((aligned(4096))) static unsigned long g_l1[512];
__attribute__((aligned(4096))) static unsigned long g_l0[512];

__attribute__((aligned(4096))) volatile unsigned char nc_target[4096];

volatile unsigned long return_to_mmode;

extern void m_trap_entry(void);
extern void s_entry(void);

static void setup_pmp(void)
{
    asm volatile(
        "li   t0, -1\n\t"
        "csrw pmpaddr0, t0\n\t"
        "li   t0, 0x1f\n\t"
        "csrw pmpcfg0, t0\n\t"
        ::: "t0", "memory");
}

static void setup_pagetables(void)
{
    for (int i = 0; i < 512; i++) { g_root[i] = 0; g_l1[i] = 0; g_l0[i] = 0; }

    unsigned long va   = (unsigned long)nc_target;
    unsigned long vpn2 = (va >> 30) & 0x1ff;
    unsigned long vpn1 = (va >> 21) & 0x1ff;
    unsigned long vpn0 = (va >> 12) & 0x1ff;

    g_root[vpn2] = NONLEAF_PTE((unsigned long)g_l1);

    unsigned long region_base = vpn2 << 30;
    for (unsigned long i = 0; i < 512; i++) {
        unsigned long pa = region_base + (i << 21);
        g_l1[i] = LEAF_PTE(pa, PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D);
    }

    g_l1[vpn1] = NONLEAF_PTE((unsigned long)g_l0);
    unsigned long chunk_base = region_base + (vpn1 << 21);
    for (unsigned long j = 0; j < 512; j++) {
        unsigned long pa = chunk_base + (j << 12);
        g_l0[j] = LEAF_PTE(pa, PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D);
    }

    g_l0[vpn0] = LEAF_PTE(va, PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D) | PTE_PBMT_NC;
}

int main(void)
{
    asm volatile("csrw %0, %1" :: "i"(CSR_MTVEC), "r"((unsigned long)m_trap_entry) : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_MEDELEG) : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_MIDELEG) : "memory");

    setup_pmp();

    unsigned long envcfg_bits = MENVCFG_PBMTE | MENVCFG_CBCFE | MENVCFG_CBIE | MENVCFG_CBZE;
    asm volatile("csrs %0, %1" :: "i"(CSR_MENVCFG), "r"(envcfg_bits) : "memory");

    for (int i = 0; i < 4096; i++) nc_target[i] = (unsigned char)(i & 0xff);

    setup_pagetables();
    asm volatile("fence rw, rw" ::: "memory");

    unsigned long satp = SATP_SV39 | ((unsigned long)g_root >> 12);
    asm volatile("csrw %0, %1\n\tsfence.vma" :: "i"(CSR_SATP), "r"(satp) : "memory");

    unsigned long mstatus;
    asm volatile("csrr %0, %1" : "=r"(mstatus) : "i"(CSR_MSTATUS));
    mstatus &= ~MSTATUS_MPP;
    mstatus |= MSTATUS_MPP_S;
    asm volatile("csrw %0, %1" :: "i"(CSR_MSTATUS), "r"(mstatus) : "memory");

    asm volatile("csrw %0, %1" :: "i"(CSR_MEPC), "r"((unsigned long)s_entry) : "memory");
    asm volatile("la %0, 1f" : "=r"(return_to_mmode));
    asm volatile("mret\n1:" ::: "memory");

    return 0;
}
