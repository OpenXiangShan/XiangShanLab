
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1

000000008000011a <_end_suffix>:
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <trap_mtvec>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <trap_mtvec>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	651d                	lui	a0,0x7
    800001be:	8005051b          	addiw	a0,a0,-2048 # 6800 <_start-0x7fff9800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid

00000000800001d6 <_end_prefix>:
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_fuzz_main>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_fuzz_main>:
    80000200:	203001d3          	fsgnj.s	ft3,ft0,ft3

0000000080000204 <_l1>:
    80000204:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000208:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    8000020c:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000210:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000214:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000218:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    8000021c:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000220:	3a0815f3          	csrrw	a1,pmpcfg0,a6
    80000224:	3a0815f3          	csrrw	a1,pmpcfg0,a6

0000000080000228 <_l2>:
    80000228:	00040717          	auipc	a4,0x40
    8000022c:	ec870713          	addi	a4,a4,-312 # 800400f0 <d_3_13>
    80000230:	01972023          	sw	s9,0(a4)

0000000080000234 <_l3>:
    80000234:	10483d73          	csrrc	s10,sie,a6
    80000238:	10483d73          	csrrc	s10,sie,a6
    8000023c:	10483d73          	csrrc	s10,sie,a6
    80000240:	10483d73          	csrrc	s10,sie,a6
    80000244:	10483d73          	csrrc	s10,sie,a6
    80000248:	10483d73          	csrrc	s10,sie,a6

000000008000024c <_l4>:
    8000024c:	01152873          	csrrs	a6,ssp,a0
    80000250:	01152873          	csrrs	a6,ssp,a0
    80000254:	01152873          	csrrs	a6,ssp,a0
    80000258:	01152873          	csrrs	a6,ssp,a0
    8000025c:	01152873          	csrrs	a6,ssp,a0
    80000260:	01152873          	csrrs	a6,ssp,a0
    80000264:	01152873          	csrrs	a6,ssp,a0

0000000080000268 <_l5>:
    80000268:	003721f3          	csrrs	gp,fcsr,a4
    8000026c:	003721f3          	csrrs	gp,fcsr,a4
    80000270:	003721f3          	csrrs	gp,fcsr,a4
    80000274:	003721f3          	csrrs	gp,fcsr,a4
    80000278:	003721f3          	csrrs	gp,fcsr,a4
    8000027c:	003721f3          	csrrs	gp,fcsr,a4
    80000280:	003721f3          	csrrs	gp,fcsr,a4
    80000284:	003721f3          	csrrs	gp,fcsr,a4
    80000288:	003721f3          	csrrs	gp,fcsr,a4
    8000028c:	003721f3          	csrrs	gp,fcsr,a4
    80000290:	003721f3          	csrrs	gp,fcsr,a4

0000000080000294 <_l6>:
    80000294:	0000100f          	fence.i

0000000080000298 <_l7>:
    80000298:	40f7d59b          	sraiw	a1,a5,0xf

000000008000029c <_l8>:
    8000029c:	c06ea273          	csrrs	tp,hpmcounter6,t4

00000000800002a0 <_l9>:
    800002a0:	257637f3          	csrrc	a5,vsireg6,a2
    800002a4:	257637f3          	csrrc	a5,vsireg6,a2
    800002a8:	257637f3          	csrrc	a5,vsireg6,a2
    800002ac:	257637f3          	csrrc	a5,vsireg6,a2

00000000800002b0 <_l10>:
    800002b0:	31018863          	beq	gp,a6,800005c0 <_l71>

00000000800002b4 <_l11>:
    800002b4:	00060417          	auipc	s0,0x60
    800002b8:	e0c40413          	addi	s0,s0,-500 # 800600c0 <d_5_10>
    800002bc:	0441                	addi	s0,s0,16
    800002be:	10043eaf          	lr.d	t4,(s0)

00000000800002c2 <_l12>:
    800002c2:	25673473          	csrrc	s0,vsireg5,a4
    800002c6:	25673473          	csrrc	s0,vsireg5,a4
    800002ca:	25673473          	csrrc	s0,vsireg5,a4
    800002ce:	25673473          	csrrc	s0,vsireg5,a4
    800002d2:	25673473          	csrrc	s0,vsireg5,a4
    800002d6:	25673473          	csrrc	s0,vsireg5,a4
    800002da:	25673473          	csrrc	s0,vsireg5,a4

00000000800002de <_l13>:
    800002de:	01a2853b          	addw	a0,t0,s10

00000000800002e2 <_l14>:
    800002e2:	19988fcf          	fnmadd.s	ft11,fa7,fs9,ft3,rne

00000000800002e6 <_l15>:
    800002e6:	7b371df3          	csrrw	s11,dscratch1,a4
    800002ea:	7b371df3          	csrrw	s11,dscratch1,a4
    800002ee:	7b371df3          	csrrw	s11,dscratch1,a4
    800002f2:	7b371df3          	csrrw	s11,dscratch1,a4
    800002f6:	7b371df3          	csrrw	s11,dscratch1,a4
    800002fa:	7b371df3          	csrrw	s11,dscratch1,a4
    800002fe:	7b371df3          	csrrw	s11,dscratch1,a4
    80000302:	7b371df3          	csrrw	s11,dscratch1,a4
    80000306:	7b371df3          	csrrw	s11,dscratch1,a4

000000008000030a <_l16>:
    8000030a:	00060717          	auipc	a4,0x60
    8000030e:	df670713          	addi	a4,a4,-522 # 80060100 <d_5_14>
    80000312:	1761                	addi	a4,a4,-8
    80000314:	ffe00237          	lui	tp,0xffe00
    80000318:	00474733          	xor	a4,a4,tp
    8000031c:	100729af          	lr.w	s3,(a4)

0000000080000320 <_l17>:
    80000320:	205519d3          	fsgnjn.s	fs3,fa0,ft5

0000000080000324 <_l18>:
    80000324:	12cb8073          	sfence.vma	s7,a2

0000000080000328 <_l19>:
    80000328:	00010697          	auipc	a3,0x10
    8000032c:	d9868693          	addi	a3,a3,-616 # 800100c0 <d_0_10>
    80000330:	01a69023          	sh	s10,0(a3)

0000000080000334 <_l20>:
    80000334:	3511b673          	csrrc	a2,mireg,gp
    80000338:	3511b673          	csrrc	a2,mireg,gp

000000008000033c <_l21>:
    8000033c:	00030d97          	auipc	s11,0x30
    80000340:	dc4d8d93          	addi	s11,s11,-572 # 80030100 <d_2_14>
    80000344:	ff8da427          	fsw	fs8,-24(s11)

0000000080000348 <_l22>:
    80000348:	150816f3          	csrrw	a3,siselect,a6
    8000034c:	150816f3          	csrrw	a3,siselect,a6
    80000350:	150816f3          	csrrw	a3,siselect,a6
    80000354:	150816f3          	csrrw	a3,siselect,a6
    80000358:	150816f3          	csrrw	a3,siselect,a6
    8000035c:	150816f3          	csrrw	a3,siselect,a6
    80000360:	150816f3          	csrrw	a3,siselect,a6

0000000080000364 <_l23>:
    80000364:	0000100f          	fence.i

0000000080000368 <_l24>:
    80000368:	000009b7          	lui	s3,0x0

000000008000036c <_l25>:
    8000036c:	08500153          	fsub.s	ft2,ft0,ft5,rne

0000000080000370 <_l26>:
    80000370:	3532b1f3          	csrrc	gp,mireg3,t0
    80000374:	3532b1f3          	csrrc	gp,mireg3,t0
    80000378:	3532b1f3          	csrrc	gp,mireg3,t0

000000008000037c <_l27>:
    8000037c:	10f205d3          	fmul.s	fa1,ft4,fa5,rne

0000000080000380 <_l28>:
    80000380:	c18f814b          	fnmsub.s	ft2,ft11,fs8,fs8,rne

0000000080000384 <_l29>:
    80000384:	00050797          	auipc	a5,0x50
    80000388:	dac78793          	addi	a5,a5,-596 # 80050130 <d_4_17>
    8000038c:	01e79183          	lh	gp,30(a5)

0000000080000390 <_l30>:
    80000390:	00030217          	auipc	tp,0x30
    80000394:	ce020213          	addi	tp,tp,-800 # 80030070 <d_2_5>
    80000398:	0261                	addi	tp,tp,24 # 18 <_start-0x7fffffe8>
    8000039a:	6182242f          	amoand.w	s0,s8,(tp)

000000008000039e <_l31>:
    8000039e:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003a2:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003a6:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003aa:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003ae:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003b2:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003b6:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003ba:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003be:	c07e3773          	csrrc	a4,hpmcounter7,t3
    800003c2:	c07e3773          	csrrc	a4,hpmcounter7,t3

00000000800003c6 <_l32>:
    800003c6:	00030917          	auipc	s2,0x30
    800003ca:	c5a90913          	addi	s2,s2,-934 # 80030020 <d_2_0>
    800003ce:	894a                	mv	s2,s2
    800003d0:	c0693b2f          	amominu.d	s6,t1,(s2)

00000000800003d4 <_l33>:
    800003d4:	304096f3          	csrrw	a3,mie,ra
    800003d8:	304096f3          	csrrw	a3,mie,ra
    800003dc:	304096f3          	csrrw	a3,mie,ra
    800003e0:	304096f3          	csrrw	a3,mie,ra

00000000800003e4 <_l34>:
    800003e4:	00045c9b          	srliw	s9,s0,0x0

00000000800003e8 <_l35>:
    800003e8:	d1ad8e93          	addi	t4,s11,-742

00000000800003ec <_l36>:
    800003ec:	00040217          	auipc	tp,0x40
    800003f0:	cb420213          	addi	tp,tp,-844 # 800400a0 <d_3_8>
    800003f4:	8212                	mv	tp,tp
    800003f6:	40b23caf          	amoor.d	s9,a1,(tp)

00000000800003fa <_l37>:
    800003fa:	00020b17          	auipc	s6,0x20
    800003fe:	cc6b0b13          	addi	s6,s6,-826 # 800200c0 <d_1_10>
    80000402:	8b5a                	mv	s6,s6
    80000404:	209b332f          	amoxor.d	t1,s1,(s6)

0000000080000408 <_l38>:
    80000408:	00000997          	auipc	s3,0x0
    8000040c:	15098993          	addi	s3,s3,336 # 80000558 <_l63>
    80000410:	000983e7          	jalr	t2,s3

0000000080000414 <_l39>:
    80000414:	1407ee73          	csrrsi	t3,sscratch,15

0000000080000418 <_l40>:
    80000418:	a02c0a53          	fle.s	s4,fs8,ft2

000000008000041c <_l41>:
    8000041c:	00010097          	auipc	ra,0x10
    80000420:	c2408093          	addi	ra,ra,-988 # 80010040 <d_0_2>
    80000424:	ff009223          	sh	a6,-28(ra)

0000000080000428 <_l42>:
    80000428:	00060917          	auipc	s2,0x60
    8000042c:	d2890913          	addi	s2,s2,-728 # 80060150 <d_5_19>
    80000430:	1971                	addi	s2,s2,-4
    80000432:	100925af          	lr.w	a1,(s2)

0000000080000436 <_l43>:
    80000436:	7dfd                	lui	s11,0xfffff

0000000080000438 <_l44>:
    80000438:	00010e97          	auipc	t4,0x10
    8000043c:	c38e8e93          	addi	t4,t4,-968 # 80010070 <d_0_5>
    80000440:	00eea027          	fsw	fa4,0(t4)

0000000080000444 <_l45>:
    80000444:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    80000448:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    8000044c:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    80000450:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    80000454:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    80000458:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    8000045c:	c84f2e73          	csrrs	t3,hpmcounter4h,t5
    80000460:	c84f2e73          	csrrs	t3,hpmcounter4h,t5

0000000080000464 <_l46>:
    80000464:	c0671b73          	csrrw	s6,hpmcounter6,a4
    80000468:	c0671b73          	csrrw	s6,hpmcounter6,a4
    8000046c:	c0671b73          	csrrw	s6,hpmcounter6,a4
    80000470:	c0671b73          	csrrw	s6,hpmcounter6,a4
    80000474:	c0671b73          	csrrw	s6,hpmcounter6,a4
    80000478:	c0671b73          	csrrw	s6,hpmcounter6,a4
    8000047c:	c0671b73          	csrrw	s6,hpmcounter6,a4
    80000480:	c0671b73          	csrrw	s6,hpmcounter6,a4

0000000080000484 <_l47>:
    80000484:	00060c17          	auipc	s8,0x60
    80000488:	bdcc0c13          	addi	s8,s8,-1060 # 80060060 <d_5_4>
    8000048c:	0c71                	addi	s8,s8,28
    8000048e:	60ac29af          	amoand.w	s3,a0,(s8)

0000000080000492 <_l48>:
    80000492:	406783bb          	subw	t2,a5,t1

0000000080000496 <_l49>:
    80000496:	156323f3          	csrrs	t2,sireg5,t1
    8000049a:	156323f3          	csrrs	t2,sireg5,t1
    8000049e:	156323f3          	csrrs	t2,sireg5,t1
    800004a2:	156323f3          	csrrs	t2,sireg5,t1
    800004a6:	156323f3          	csrrs	t2,sireg5,t1
    800004aa:	156323f3          	csrrs	t2,sireg5,t1
    800004ae:	156323f3          	csrrs	t2,sireg5,t1
    800004b2:	156323f3          	csrrs	t2,sireg5,t1
    800004b6:	156323f3          	csrrs	t2,sireg5,t1

00000000800004ba <_l50>:
    800004ba:	00050797          	auipc	a5,0x50
    800004be:	cd678793          	addi	a5,a5,-810 # 80050190 <d_4_23>
    800004c2:	ff87bd03          	ld	s10,-8(a5)

00000000800004c6 <_l51>:
    800004c6:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004ca:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004ce:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004d2:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004d6:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004da:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004de:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004e2:	c0879373          	csrrw	t1,hpmcounter8,a5
    800004e6:	c0879373          	csrrw	t1,hpmcounter8,a5

00000000800004ea <_l52>:
    800004ea:	d01b01cb          	fnmsub.s	ft3,fs6,ft1,fs10,rne

00000000800004ee <_l53>:
    800004ee:	21319753          	fsgnjn.s	fa4,ft3,fs3

00000000800004f2 <_l54>:
    800004f2:	135a8073          	sfence.vma	s5,s5

00000000800004f6 <_l55>:
    800004f6:	00040b97          	auipc	s7,0x40
    800004fa:	bcab8b93          	addi	s7,s7,-1078 # 800400c0 <d_3_10>
    800004fe:	8bde                	mv	s7,s7
    80000500:	e0dba7af          	amomaxu.w	a5,a3,(s7)

0000000080000504 <_l56>:
    80000504:	7b2412f3          	csrrw	t0,dscratch0,s0

0000000080000508 <_l57>:
    80000508:	104325f3          	csrrs	a1,sie,t1
    8000050c:	104325f3          	csrrs	a1,sie,t1
    80000510:	104325f3          	csrrs	a1,sie,t1

0000000080000514 <_l58>:
    80000514:	883c0247          	fmsub.s	ft4,fs8,ft3,fa7,rne

0000000080000518 <_l59>:
    80000518:	00000717          	auipc	a4,0x0
    8000051c:	0a870713          	addi	a4,a4,168 # 800005c0 <_l71>
    80000520:	fe271103          	lh	sp,-30(a4)

0000000080000524 <_l60>:
    80000524:	00000097          	auipc	ra,0x0
    80000528:	10408093          	addi	ra,ra,260 # 80000628 <_l76>
    8000052c:	00008267          	jalr	tp,ra

0000000080000530 <_l61>:
    80000530:	c0219d73          	csrrw	s10,instret,gp
    80000534:	c0219d73          	csrrw	s10,instret,gp
    80000538:	c0219d73          	csrrw	s10,instret,gp
    8000053c:	c0219d73          	csrrw	s10,instret,gp
    80000540:	c0219d73          	csrrw	s10,instret,gp
    80000544:	c0219d73          	csrrw	s10,instret,gp

0000000080000548 <_l62>:
    80000548:	34073cf3          	csrrc	s9,mscratch,a4
    8000054c:	34073cf3          	csrrc	s9,mscratch,a4
    80000550:	34073cf3          	csrrc	s9,mscratch,a4
    80000554:	34073cf3          	csrrc	s9,mscratch,a4

0000000080000558 <_l63>:
    80000558:	f1182e73          	csrrs	t3,mvendorid,a6
    8000055c:	f1182e73          	csrrs	t3,mvendorid,a6

0000000080000560 <_l64>:
    80000560:	00000c17          	auipc	s8,0x0
    80000564:	e66c0c13          	addi	s8,s8,-410 # 800003c6 <_l32>
    80000568:	01fc4383          	lbu	t2,31(s8)

000000008000056c <_l65>:
    8000056c:	18053673          	csrrc	a2,satp,a0
    80000570:	18053673          	csrrc	a2,satp,a0
    80000574:	18053673          	csrrc	a2,satp,a0
    80000578:	18053673          	csrrc	a2,satp,a0
    8000057c:	18053673          	csrrc	a2,satp,a0
    80000580:	18053673          	csrrc	a2,satp,a0
    80000584:	18053673          	csrrc	a2,satp,a0
    80000588:	18053673          	csrrc	a2,satp,a0
    8000058c:	18053673          	csrrc	a2,satp,a0

0000000080000590 <_l66>:
    80000590:	15359d73          	csrrw	s10,sireg3,a1
    80000594:	15359d73          	csrrw	s10,sireg3,a1
    80000598:	15359d73          	csrrw	s10,sireg3,a1
    8000059c:	15359d73          	csrrw	s10,sireg3,a1
    800005a0:	15359d73          	csrrw	s10,sireg3,a1
    800005a4:	15359d73          	csrrw	s10,sireg3,a1
    800005a8:	15359d73          	csrrw	s10,sireg3,a1
    800005ac:	15359d73          	csrrw	s10,sireg3,a1

00000000800005b0 <_l67>:
    800005b0:	01fd5e13          	srli	t3,s10,0x1f

00000000800005b4 <_l68>:
    800005b4:	28ff0153          	fmin.s	ft2,ft10,fa5

00000000800005b8 <_l69>:
    800005b8:	209711d3          	fsgnjn.s	ft3,fa4,fs1

00000000800005bc <_l70>:
    800005bc:	295689d3          	fmin.s	fs3,fa3,fs5

00000000800005c0 <_l71>:
    800005c0:	c803b173          	csrrc	sp,cycleh,t2
    800005c4:	c803b173          	csrrc	sp,cycleh,t2
    800005c8:	c803b173          	csrrc	sp,cycleh,t2
    800005cc:	c803b173          	csrrc	sp,cycleh,t2
    800005d0:	c803b173          	csrrc	sp,cycleh,t2
    800005d4:	c803b173          	csrrc	sp,cycleh,t2
    800005d8:	c803b173          	csrrc	sp,cycleh,t2
    800005dc:	c803b173          	csrrc	sp,cycleh,t2
    800005e0:	c803b173          	csrrc	sp,cycleh,t2
    800005e4:	c803b173          	csrrc	sp,cycleh,t2

00000000800005e8 <_l72>:
    800005e8:	30005073          	csrwi	mstatus,0
    800005ec:	343f73f3          	csrrci	t2,mtval,30

00000000800005f0 <_l73>:
    800005f0:	00040f17          	auipc	t5,0x40
    800005f4:	b20f0f13          	addi	t5,t5,-1248 # 80040110 <d_3_15>
    800005f8:	8f7a                	mv	t5,t5
    800005fa:	41df382f          	amoor.d	a6,t4,(t5)

00000000800005fe <_l74>:
    800005fe:	00020f17          	auipc	t5,0x20
    80000602:	ad2f0f13          	addi	t5,t5,-1326 # 800200d0 <d_1_11>
    80000606:	1f61                	addi	t5,t5,-8
    80000608:	808f342f          	amomin.d	s0,s0,(t5)

000000008000060c <_l75>:
    8000060c:	140692f3          	csrrw	t0,sscratch,a3
    80000610:	140692f3          	csrrw	t0,sscratch,a3
    80000614:	140692f3          	csrrw	t0,sscratch,a3
    80000618:	140692f3          	csrrw	t0,sscratch,a3
    8000061c:	140692f3          	csrrw	t0,sscratch,a3
    80000620:	140692f3          	csrrw	t0,sscratch,a3
    80000624:	140692f3          	csrrw	t0,sscratch,a3

0000000080000628 <_l76>:
    80000628:	14382673          	csrrs	a2,stval,a6
    8000062c:	14382673          	csrrs	a2,stval,a6
    80000630:	14382673          	csrrs	a2,stval,a6
    80000634:	14382673          	csrrs	a2,stval,a6

0000000080000638 <_l77>:
    80000638:	1409b2f3          	csrrc	t0,sscratch,s3
    8000063c:	1409b2f3          	csrrc	t0,sscratch,s3
    80000640:	1409b2f3          	csrrc	t0,sscratch,s3
    80000644:	1409b2f3          	csrrc	t0,sscratch,s3

0000000080000648 <_l78>:
    80000648:	d03b0d53          	fcvt.s.lu	fs10,s6,rne

000000008000064c <_l79>:
    8000064c:	15727e73          	csrrci	t3,sireg6,4
    80000650:	82f2                	mv	t0,t3
    80000652:	c072                	sw	t3,0(sp)

0000000080000654 <_l80>:
    80000654:	30005073          	csrwi	mstatus,0
    80000658:	340e63f3          	csrrsi	t2,mscratch,28
    8000065c:	8d1e                	mv	s10,t2

000000008000065e <_l81>:
    8000065e:	580c08d3          	fsqrt.s	fa7,fs8,rne

0000000080000662 <_good_exit>:
    80000662:	00002097          	auipc	ra,0x2
    80000666:	b9e08093          	addi	ra,ra,-1122 # 80002200 <csr_output_data>
    8000066a:	10002173          	csrr	sp,sstatus
    8000066e:	0420bc23          	sd	sp,88(ra)
    80000672:	10402173          	csrr	sp,sie
    80000676:	0620b823          	sd	sp,112(ra)
    8000067a:	10502173          	csrr	sp,stvec
    8000067e:	0620bc23          	sd	sp,120(ra)
    80000682:	10602173          	csrr	sp,scounteren
    80000686:	0820b023          	sd	sp,128(ra)
    8000068a:	14002173          	csrr	sp,sscratch
    8000068e:	0820b423          	sd	sp,136(ra)
    80000692:	14102173          	csrr	sp,sepc
    80000696:	0820b823          	sd	sp,144(ra)
    8000069a:	14202173          	csrr	sp,scause
    8000069e:	0820bc23          	sd	sp,152(ra)
    800006a2:	14302173          	csrr	sp,stval
    800006a6:	0a20b023          	sd	sp,160(ra)
    800006aa:	14402173          	csrr	sp,sip
    800006ae:	f7f17113          	andi	sp,sp,-129
    800006b2:	0a20b423          	sd	sp,168(ra)
    800006b6:	18002173          	csrr	sp,satp
    800006ba:	0a20b823          	sd	sp,176(ra)
    800006be:	f1402173          	csrr	sp,mhartid
    800006c2:	0a20bc23          	sd	sp,184(ra)
    800006c6:	30002173          	csrr	sp,mstatus
    800006ca:	0c20b023          	sd	sp,192(ra)
    800006ce:	30202173          	csrr	sp,medeleg
    800006d2:	0c20b423          	sd	sp,200(ra)
    800006d6:	30302173          	csrr	sp,mideleg
    800006da:	0c20b823          	sd	sp,208(ra)
    800006de:	30402173          	csrr	sp,mie
    800006e2:	0c20bc23          	sd	sp,216(ra)
    800006e6:	30502173          	csrr	sp,mtvec
    800006ea:	0e20b023          	sd	sp,224(ra)
    800006ee:	30602173          	csrr	sp,mcounteren
    800006f2:	0e20b423          	sd	sp,232(ra)
    800006f6:	34002173          	csrr	sp,mscratch
    800006fa:	0e20b823          	sd	sp,240(ra)
    800006fe:	34102173          	csrr	sp,mepc
    80000702:	0e20bc23          	sd	sp,248(ra)
    80000706:	34202173          	csrr	sp,mcause
    8000070a:	1020b023          	sd	sp,256(ra)
    8000070e:	34302173          	csrr	sp,mtval
    80000712:	1020b423          	sd	sp,264(ra)
    80000716:	34402173          	csrr	sp,mip
    8000071a:	f7f17113          	andi	sp,sp,-129
    8000071e:	1020b823          	sd	sp,272(ra)
    80000722:	3a002173          	csrr	sp,pmpcfg0
    80000726:	1020bc23          	sd	sp,280(ra)
    8000072a:	3b002173          	csrr	sp,pmpaddr0
    8000072e:	1220bc23          	sd	sp,312(ra)
    80000732:	3b102173          	csrr	sp,pmpaddr1
    80000736:	1420b023          	sd	sp,320(ra)
    8000073a:	3b202173          	csrr	sp,pmpaddr2
    8000073e:	1420b423          	sd	sp,328(ra)
    80000742:	3b302173          	csrr	sp,pmpaddr3
    80000746:	1420b823          	sd	sp,336(ra)
    8000074a:	3b402173          	csrr	sp,pmpaddr4
    8000074e:	1420bc23          	sd	sp,344(ra)
    80000752:	3b502173          	csrr	sp,pmpaddr5
    80000756:	1620b023          	sd	sp,352(ra)
    8000075a:	3b602173          	csrr	sp,pmpaddr6
    8000075e:	1620b423          	sd	sp,360(ra)
    80000762:	3b702173          	csrr	sp,pmpaddr7
    80000766:	1620b823          	sd	sp,368(ra)
    8000076a:	6519                	lui	a0,0x6
    8000076c:	30052073          	csrs	mstatus,a0

0000000080000770 <fcsrs_dump>:
    80000770:	00102173          	frflags	sp
    80000774:	0420b023          	sd	sp,64(ra)
    80000778:	00202173          	frrm	sp
    8000077c:	0420b423          	sd	sp,72(ra)
    80000780:	00302173          	frcsr	sp
    80000784:	0420b823          	sd	sp,80(ra)

0000000080000788 <reg_dump>:
    80000788:	00002097          	auipc	ra,0x2
    8000078c:	87808093          	addi	ra,ra,-1928 # 80002000 <begin_signature>
    80000790:	0000b023          	sd	zero,0(ra)
    80000794:	0020b823          	sd	sp,16(ra)
    80000798:	0030bc23          	sd	gp,24(ra)
    8000079c:	0240b023          	sd	tp,32(ra)
    800007a0:	0250b423          	sd	t0,40(ra)
    800007a4:	0260b823          	sd	t1,48(ra)
    800007a8:	0270bc23          	sd	t2,56(ra)
    800007ac:	0480b023          	sd	s0,64(ra)
    800007b0:	0490b423          	sd	s1,72(ra)
    800007b4:	04a0b823          	sd	a0,80(ra)
    800007b8:	04b0bc23          	sd	a1,88(ra)
    800007bc:	06c0b023          	sd	a2,96(ra)
    800007c0:	06d0b423          	sd	a3,104(ra)
    800007c4:	06e0b823          	sd	a4,112(ra)
    800007c8:	06f0bc23          	sd	a5,120(ra)
    800007cc:	0900b023          	sd	a6,128(ra)
    800007d0:	0910b423          	sd	a7,136(ra)
    800007d4:	0920b823          	sd	s2,144(ra)
    800007d8:	0930bc23          	sd	s3,152(ra)
    800007dc:	0b40b023          	sd	s4,160(ra)
    800007e0:	0b50b423          	sd	s5,168(ra)
    800007e4:	0b60b823          	sd	s6,176(ra)
    800007e8:	0b70bc23          	sd	s7,184(ra)
    800007ec:	0d80b023          	sd	s8,192(ra)
    800007f0:	0d90b423          	sd	s9,200(ra)
    800007f4:	0db0bc23          	sd	s11,216(ra)
    800007f8:	0fc0b023          	sd	t3,224(ra)
    800007fc:	0fd0b423          	sd	t4,232(ra)
    80000800:	0fe0b823          	sd	t5,240(ra)

0000000080000804 <freg_dump>:
    80000804:	00002097          	auipc	ra,0x2
    80000808:	8fc08093          	addi	ra,ra,-1796 # 80002100 <freg_output_data>
    8000080c:	0010a427          	fsw	ft1,8(ra)
    80000810:	0020a827          	fsw	ft2,16(ra)
    80000814:	0270ac27          	fsw	ft7,56(ra)
    80000818:	0490a427          	fsw	fs1,72(ra)
    8000081c:	04a0a827          	fsw	fa0,80(ra)
    80000820:	06c0a027          	fsw	fa2,96(ra)
    80000824:	06d0a427          	fsw	fa3,104(ra)
    80000828:	0b50a427          	fsw	fs5,168(ra)
    8000082c:	0b60a827          	fsw	fs6,176(ra)
    80000830:	0d90a427          	fsw	fs9,200(ra)
    80000834:	0da0a827          	fsw	fs10,208(ra)
    80000838:	0fc0a027          	fsw	ft8,224(ra)
    8000083c:	0fd0a427          	fsw	ft9,232(ra)
    80000840:	0fe0a827          	fsw	ft10,240(ra)
    80000844:	0ff0ac27          	fsw	ft11,248(ra)
    80000848:	00002097          	auipc	ra,0x2
    8000084c:	8b808093          	addi	ra,ra,-1864 # 80002100 <freg_output_data>
    80000850:	0000b027          	fsd	ft0,0(ra)
    80000854:	0030bc27          	fsd	ft3,24(ra)
    80000858:	0240b027          	fsd	ft4,32(ra)
    8000085c:	0250b427          	fsd	ft5,40(ra)
    80000860:	0260b827          	fsd	ft6,48(ra)
    80000864:	0480b027          	fsd	fs0,64(ra)
    80000868:	04b0bc27          	fsd	fa1,88(ra)
    8000086c:	06e0b827          	fsd	fa4,112(ra)
    80000870:	06f0bc27          	fsd	fa5,120(ra)
    80000874:	0900b027          	fsd	fa6,128(ra)
    80000878:	0910b427          	fsd	fa7,136(ra)
    8000087c:	0920b827          	fsd	fs2,144(ra)
    80000880:	0930bc27          	fsd	fs3,152(ra)
    80000884:	0b40b027          	fsd	fs4,160(ra)
    80000888:	0b70bc27          	fsd	fs7,184(ra)
    8000088c:	0d80b027          	fsd	fs8,192(ra)
    80000890:	0db0bc27          	fsd	fs11,216(ra)
    80000894:	4501                	li	a0,0
    80000896:	0005006b          	.insn	4, 0x0005006b
    8000089a:	4185                	li	gp,1
    8000089c:	00000f17          	auipc	t5,0x0
    800008a0:	763f2223          	sw	gp,1892(t5) # 80001000 <tohost>
    800008a4:	a001                	j	800008a4 <freg_dump+0xa0>

00000000800008a6 <_end_main>:
    800008a6:	0001                	nop
    800008a8:	00000013          	nop
    800008ac:	00000013          	nop
    800008b0:	00000013          	nop
    800008b4:	00000013          	nop
    800008b8:	00000013          	nop
    800008bc:	00000013          	nop
    800008c0:	00000013          	nop
    800008c4:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	ffa4                	sd	s1,120(a5)
    80010002:	59d9                	li	s3,-10
    80010004:	3b62                	fld	fs6,56(sp)
    80010006:	75b4                	ld	a3,104(a1)
    80010008:	e3bd                	bnez	a5,8001006e <d_0_4+0xe>
    8001000a:	bf11                	j	8000ff1e <end_signature+0xdb3e>
    8001000c:	554f3ab3          	.insn	4, 0x554f3ab3
    80010010:	4841                	li	a6,16
    80010012:	c416                	sw	t0,8(sp)
    80010014:	8836                	mv	a6,a3
    80010016:	ec41                	bnez	s0,800100ae <d_0_8+0xe>
    80010018:	8651                	srai	a2,a2,0x14
    8001001a:	b31fa997          	auipc	s3,0xb31fa
    8001001e:	8255                	srli	a2,a2,0x15

0000000080010020 <d_0_0>:
    80010020:	face274f          	fnmadd.d	fa4,ft8,fa2,ft11,rdn
    80010024:	d2f9                	beqz	a3,8000ffea <end_signature+0xdc0a>
    80010026:	14aa                	slli	s1,s1,0x2a
    80010028:	6c0c                	ld	a1,24(s0)
    8001002a:	b5f9                	j	8000fef8 <end_signature+0xdb18>
    8001002c:	33c6                	fld	ft7,112(sp)
    8001002e:	cb2d                	beqz	a4,800100a0 <d_0_8>

0000000080010030 <d_0_1>:
    80010030:	b621                	j	8000fb38 <end_signature+0xd758>
    80010032:	cf51                	beqz	a4,800100ce <d_0_10+0xe>
    80010034:	92ca                	add	t0,t0,s2
    80010036:	9d28                	.insn	2, 0x9d28
    80010038:	8c4d8383          	lb	t2,-1852(s11) # ffffffffffffe8c4 <_end+0xffffffff7ff9e6c4>
    8001003c:	ff60                	sd	s0,248(a4)
    8001003e:	2c24                	fld	fs1,88(s0)

0000000080010040 <d_0_2>:
    80010040:	35fa                	fld	fa1,440(sp)
    80010042:	d75de277          	.insn	4, 0xd75de277
    80010046:	9656                	add	a2,a2,s5
    80010048:	a10e                	fsd	ft3,128(sp)
    8001004a:	d0df bf66 0cb9      	.insn	6, 0x0cb9bf66d0df

0000000080010050 <d_0_3>:
    80010050:	9046                	c.add	zero,a7
    80010052:	e354                	sd	a3,128(a4)
    80010054:	8855cdd3          	.insn	4, 0x8855cdd3
    80010058:	5571                	li	a0,-4
    8001005a:	497c                	lw	a5,84(a0)
    8001005c:	d7b8                	sw	a4,104(a5)
    8001005e:	f734                	sd	a3,104(a4)

0000000080010060 <d_0_4>:
    80010060:	66f77d57          	vsetvli	s10,a4,1647
    80010064:	15e9                	addi	a1,a1,-6
    80010066:	7df81ac7          	.insn	4, 0x7df81ac7
    8001006a:	e7ba                	sd	a4,456(sp)
    8001006c:	227e329b          	.insn	4, 0x227e329b

0000000080010070 <d_0_5>:
    80010070:	9ea18757          	vsmul.vv	v14,v10,v3
    80010074:	7fb4793f 4473a98a 	.insn	8, 0x4473a98a7fb4793f
    8001007c:	2e09                	addiw	t3,t3,2
    8001007e:	          	.insn	4, 0x3af46927

0000000080010080 <d_0_6>:
    80010080:	3af4                	fld	fa3,240(a3)
    80010082:	4b5e521b          	.insn	4, 0x4b5e521b
    80010086:	ea775387          	vlsseg8e16.v	v7,(a4),t2
    8001008a:	af81                	j	800107da <_end_data0+0x5da>
    8001008c:	f29c                	sd	a5,32(a3)
    8001008e:	          	lb	s8,266(gp)

0000000080010090 <d_0_7>:
    80010090:	10a1                	addi	ra,ra,-24
    80010092:	842d                	srai	s0,s0,0xb
    80010094:	bda398ab          	.insn	4, 0xbda398ab
    80010098:	31ca                	fld	ft3,176(sp)
    8001009a:	ab45                	j	8001064a <_end_data0+0x44a>
    8001009c:	fe42                	sd	a6,312(sp)
    8001009e:	          	.insn	4, 0x510bf3b3

00000000800100a0 <d_0_8>:
    800100a0:	5236510b          	.insn	4, 0x5236510b
    800100a4:	3fb0                	fld	fa2,120(a5)
    800100a6:	81d0                	.insn	2, 0x81d0
    800100a8:	0864                	addi	s1,sp,28
    800100aa:	e932                	sd	a2,144(sp)
    800100ac:	aff9084f          	.insn	4, 0xaff9084f

00000000800100b0 <d_0_9>:
    800100b0:	5862                	lw	a6,56(sp)
    800100b2:	f192                	sd	tp,224(sp)
    800100b4:	42b1                	li	t0,12
    800100b6:	21ad                	addiw	gp,gp,11
    800100b8:	e269                	bnez	a2,8001017a <d_0_21+0xa>
    800100ba:	7c0d5b47          	.insn	4, 0x7c0d5b47
    800100be:	a78d                	j	80010820 <_end_data0+0x620>

00000000800100c0 <d_0_10>:
    800100c0:	16a8                	addi	a0,sp,872
    800100c2:	8f03596f          	jal	s2,7ff451b2 <_start-0xbae4e>
    800100c6:	5cb4                	lw	a3,120(s1)
    800100c8:	7cd2                	ld	s9,304(sp)
    800100ca:	3a8c                	fld	fa1,48(a3)
    800100cc:	703db4a3          	sd	gp,1801(s11)

00000000800100d0 <d_0_11>:
    800100d0:	1a40                	addi	s0,sp,308
    800100d2:	036a                	slli	t1,t1,0x1a
    800100d4:	4698                	lw	a4,8(a3)
    800100d6:	19a0                	addi	s0,sp,248
    800100d8:	8db0                	.insn	2, 0x8db0
    800100da:	d896                	sw	t0,112(sp)
    800100dc:	b47e                	fsd	ft11,40(sp)
    800100de:	          	fnmsub.d	fa0,fa4,fa7,fs8

00000000800100e0 <d_0_12>:
    800100e0:	616dc317          	auipc	t1,0x616dc
    800100e4:	cdba                	sw	a4,216(sp)
    800100e6:	fa7c                	sd	a5,240(a2)
    800100e8:	bd561feb          	.insn	4, 0xbd561feb
    800100ec:	369d                	addiw	a3,a3,-25
    800100ee:	  	.insn	16, 0xa274f4f782f1abbfa5aa58990a61347f
    800100f6:	  

00000000800100f0 <d_0_13>:
    800100f0:	0a61                	addi	s4,s4,24
    800100f2:	5899                	li	a7,-26
    800100f4:	a5aa                	fsd	fa0,200(sp)
    800100f6:	82f1abbf a274f4f7 	.insn	8, 0xa274f4f782f1abbf
    800100fe:	6e91                	lui	t4,0x4

0000000080010100 <d_0_14>:
    80010100:	9eb5                	addw	a3,a3,a3
    80010102:	b522                	fsd	fs0,168(sp)
    80010104:	5aa5                	li	s5,-23
    80010106:	6ec5                	lui	t4,0x11
    80010108:	cc05                	beqz	s0,80010140 <d_0_18>
    8001010a:	85e9                	srai	a1,a1,0x1a
    8001010c:	5ac6                	lw	s5,112(sp)
    8001010e:	          	fnmadd.s	ft9,ft8,fs9,fa0,rup

0000000080010110 <d_0_15>:
    80010110:	519e                	lw	gp,228(sp)
    80010112:	c53e                	sw	a5,136(sp)
    80010114:	91fc                	.insn	2, 0x91fc
    80010116:	7112                	ld	sp,288(sp)
    80010118:	653092b7          	lui	t0,0x65309
    8001011c:	5118                	lw	a4,32(a0)
    8001011e:	aca8                	fsd	fa0,88(s1)

0000000080010120 <d_0_16>:
    80010120:	9d1a                	add	s10,s10,t1
    80010122:	ce9a                	sw	t1,92(sp)
    80010124:	e2c2                	sd	a6,320(sp)
    80010126:	e268                	sd	a0,192(a2)
    80010128:	94259413          	.insn	4, 0x94259413
    8001012c:	07ea                	slli	a5,a5,0x1a
    8001012e:	c399                	beqz	a5,80010134 <d_0_17+0x4>

0000000080010130 <d_0_17>:
    80010130:	625f 75f6 605a      	.insn	6, 0x605a75f6625f
    80010136:	5b9d                	li	s7,-25
    80010138:	8a3363bf 944cbdbd 	.insn	8, 0x944cbdbd8a3363bf

0000000080010140 <d_0_18>:
    80010140:	66df 821a ad9a      	.insn	6, 0xad9a821a66df
    80010146:	de78                	sw	a4,124(a2)
    80010148:	089d                	addi	a7,a7,7
    8001014a:	4df6                	lw	s11,92(sp)
    8001014c:	61743c7f  	.insn	16, 0x51d6178069e0d43d54a0448d61743c7f
    80010154:	  

0000000080010150 <d_0_19>:
    80010150:	448d                	li	s1,3
    80010152:	54a0                	lw	s0,104(s1)
    80010154:	d43d                	beqz	s0,800100c2 <d_0_10+0x2>
    80010156:	69e0                	ld	s0,208(a1)
    80010158:	1780                	addi	s0,sp,992
    8001015a:	51d6                	lw	gp,116(sp)
    8001015c:	44767f7b          	.insn	4, 0x44767f7b

0000000080010160 <d_0_20>:
    80010160:	df39                	beqz	a4,800100be <d_0_9+0xe>
    80010162:	3025                	.insn	2, 0x3025
    80010164:	db4c                	sw	a1,52(a4)
    80010166:	640d                	lui	s0,0x3
    80010168:	261c                	fld	fa5,8(a2)
    8001016a:	3d7a9b8f          	.insn	4, 0x3d7a9b8f
    8001016e:	fdc8                	sd	a0,184(a1)

0000000080010170 <d_0_21>:
    80010170:	dad5                	beqz	a3,80010124 <d_0_16+0x4>
    80010172:	bcde                	fsd	fs7,120(sp)
    80010174:	e2e1                	bnez	a3,80010234 <_end_data0+0x34>
    80010176:	98dd2fcb          	fnmsub.s	ft11,fs10,fa3,fs3,rdn
    8001017a:	b0f7860f          	.insn	4, 0xb0f7860f
    8001017e:	a8a2                	fsd	fs0,80(sp)

0000000080010180 <d_0_22>:
    80010180:	7768                	ld	a0,232(a4)
    80010182:	dc4d                	beqz	s0,8001013c <d_0_17+0xc>
    80010184:	32fe                	fld	ft5,504(sp)
    80010186:	7d31                	lui	s10,0xfffec
    80010188:	5c76                	lw	s8,124(sp)
    8001018a:	9744db0f          	.insn	4, 0x9744db0f
    8001018e:	7afe                	ld	s5,504(sp)

0000000080010190 <d_0_23>:
    80010190:	5d4e                	lw	s10,240(sp)
    80010192:	27acf4db          	.insn	4, 0x27acf4db
    80010196:	b4dc                	fsd	fa5,168(s1)
    80010198:	1b76                	slli	s6,s6,0x3d
    8001019a:	e588                	sd	a0,8(a1)
    8001019c:	b1f1                	j	8000fe68 <end_signature+0xda88>
    8001019e:	          	lui	a6,0x401d

00000000800101a0 <d_0_24>:
    800101a0:	0401                	addi	s0,s0,0 # 3000 <_start-0x7fffd000>
    800101a2:	58e5                	li	a7,-7
    800101a4:	896c                	.insn	2, 0x896c
    800101a6:	26ae                	fld	fa3,200(sp)
    800101a8:	af3e                	fsd	fa5,408(sp)
    800101aa:	f2f5                	bnez	a3,8001018e <d_0_22+0xe>
    800101ac:	85f7c057          	vsadd.vx	v0,v31,a5,v0.t

00000000800101b0 <d_0_25>:
    800101b0:	d93c                	sw	a5,112(a0)
    800101b2:	2aa9                	addiw	s5,s5,10
    800101b4:	537c                	lw	a5,100(a4)
    800101b6:	b4a6                	fsd	fs1,104(sp)
    800101b8:	28a5                	addiw	a7,a7,9
    800101ba:	4438                	lw	a4,72(s0)
    800101bc:	7241                	lui	tp,0xffff0
    800101be:	          	lui	s2,0xb1469

00000000800101c0 <d_0_26>:
    800101c0:	b146                	fsd	fa7,160(sp)
    800101c2:	904fe107          	.insn	4, 0x904fe107
    800101c6:	f47f570f          	.insn	4, 0xf47f570f
    800101ca:	1346                	slli	t1,t1,0x31
    800101cc:	bcd5                	j	8000fcc0 <end_signature+0xd8e0>
    800101ce:	          	.insn	4, 0xa545546b

00000000800101d0 <d_0_27>:
    800101d0:	a545                	j	80010870 <_end_data0+0x670>
    800101d2:	2015104b          	fnmsub.s	ft0,fa0,ft1,ft4,rtz
    800101d6:	2e35c2b3          	.insn	4, 0x2e35c2b3
    800101da:	0bdd                	addi	s7,s7,23
    800101dc:	334d                	addiw	t1,t1,-13 # ffffffffe16ec0d3 <_end+0xffffffff6168bed3>
    800101de:	0e04                	addi	s1,sp,784
    800101e0:	be4667a3          	.insn	4, 0xbe4667a3
    800101e4:	d90e                	sw	gp,176(sp)
    800101e6:	749e                	ld	s1,480(sp)
    800101e8:	8f16                	mv	t5,t0
    800101ea:	3fdb9337          	lui	t1,0x3fdb9
    800101ee:	b859e2ab          	.insn	4, 0xb859e2ab
    800101f2:	6ab6                	ld	s5,328(sp)
    800101f4:	d896                	sw	t0,112(sp)
    800101f6:	1cbe                	slli	s9,s9,0x2f
    800101f8:	6949                	lui	s2,0x12
    800101fa:	bff5                	j	800101f6 <d_0_27+0x26>
    800101fc:	b2b1                	j	8000fb48 <end_signature+0xd768>
    800101fe:	22db                	.short	0x22db

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	15c1                	addi	a1,a1,-16
    80020002:	fbe1                	bnez	a5,8001ffd2 <_end_data0+0xfdd2>
    80020004:	00fa                	slli	ra,ra,0x1e
    80020006:	a5a014d3          	.insn	4, 0xa5a014d3
    8002000a:	e152                	sd	s4,128(sp)
    8002000c:	b9ee                	fsd	fs11,240(sp)
    8002000e:	dbe0                	sw	s0,116(a5)
    80020010:	d7ca                	sw	s2,236(sp)
    80020012:	0c7d                	addi	s8,s8,31
    80020014:	37f5                	addiw	a5,a5,-3
    80020016:	7281                	lui	t0,0xfffe0
    80020018:	b714                	fsd	fa3,40(a4)
    8002001a:	bff8                	fsd	fa4,248(a5)
    8002001c:	d9257e8b          	.insn	4, 0xd9257e8b

0000000080020020 <d_1_0>:
    80020020:	e3f9                	bnez	a5,800200e6 <d_1_12+0x6>
    80020022:	6eea                	ld	t4,152(sp)
    80020024:	e08c608b          	.insn	4, 0xe08c608b
    80020028:	4b3b6547          	fmsub.d	fa0,fs6,fs3,fs1,unknown
    8002002c:	4a34                	lw	a3,80(a2)
    8002002e:	905a                	c.add	zero,s6

0000000080020030 <d_1_1>:
    80020030:	19d87463          	bgeu	a6,t4,800201b8 <d_1_25+0x8>
    80020034:	6031                	c.lui	zero,0xc
    80020036:	37e9                	addiw	a5,a5,-6
    80020038:	0131                	addi	sp,sp,12
    8002003a:	8582                	jr	a1
    8002003c:	12ea01af          	.insn	4, 0x12ea01af

0000000080020040 <d_1_2>:
    80020040:	61ea                	ld	gp,152(sp)
    80020042:	ecad                	bnez	s1,800200bc <d_1_9+0xc>
    80020044:	2fec                	fld	fa1,216(a5)
    80020046:	978a                	add	a5,a5,sp
    80020048:	f38e                	sd	gp,480(sp)
    8002004a:	3758                	fld	fa4,168(a4)
    8002004c:	d390                	sw	a2,32(a5)
    8002004e:	af9d                	j	800207c4 <_end_data1+0x5c4>

0000000080020050 <d_1_3>:
    80020050:	55bad7e3          	bge	s5,s11,80020d9e <_end_data1+0xb9e>
    80020054:	13cd                	addi	t2,t2,-13
    80020056:	51a2                	lw	gp,40(sp)
    80020058:	a721                	j	80020760 <_end_data1+0x560>
    8002005a:	e9207a8f          	.insn	4, 0xe9207a8f
    8002005e:	1a86                	slli	s5,s5,0x21

0000000080020060 <d_1_4>:
    80020060:	389e2c87          	flw	fs9,905(t3)
    80020064:	7e6d                	lui	t3,0xffffb
    80020066:	70e0                	ld	s0,224(s1)
    80020068:	43f6f483          	.insn	4, 0x43f6f483
    8002006c:	04d1                	addi	s1,s1,20
    8002006e:	3609                	addiw	a2,a2,-30

0000000080020070 <d_1_5>:
    80020070:	884b4faf          	.insn	4, 0x884b4faf
    80020074:	8c94                	.insn	2, 0x8c94
    80020076:	1e09                	addi	t3,t3,-30 # ffffffffffffafe2 <_end+0xffffffff7ff9ade2>
    80020078:	54b0                	lw	a2,104(s1)
    8002007a:	5e54                	lw	a3,60(a2)
    8002007c:	3821                	addiw	a6,a6,-24 # 401cfe8 <_start-0x7bfe3018>
    8002007e:	3e0e                	fld	ft8,224(sp)

0000000080020080 <d_1_6>:
    80020080:	8a8eb653          	.insn	4, 0x8a8eb653
    80020084:	a991                	j	800204d8 <_end_data1+0x2d8>
    80020086:	e351                	bnez	a4,8002010a <d_1_14+0xa>
    80020088:	87e35a53          	.insn	4, 0x87e35a53
    8002008c:	927cf2b3          	.insn	4, 0x927cf2b3

0000000080020090 <d_1_7>:
    80020090:	328e                	fld	ft5,224(sp)
    80020092:	2cc0                	fld	fs0,152(s1)
    80020094:	3a0691f7          	.insn	4, 0x3a0691f7
    80020098:	ba3d                	j	8001f9d6 <_end_data0+0xf7d6>
    8002009a:	eeba                	sd	a4,344(sp)
    8002009c:	82d2                	mv	t0,s4
    8002009e:	50fe                	lw	ra,252(sp)

00000000800200a0 <d_1_8>:
    800200a0:	c99e                	sw	t2,208(sp)
    800200a2:	9cc1                	.insn	2, 0x9cc1
    800200a4:	d2c314f7          	.insn	4, 0xd2c314f7
    800200a8:	7d22                	ld	s10,40(sp)
    800200aa:	d906                	sw	ra,176(sp)
    800200ac:	d21f 6209       	.insn	6, 0x89d76209d21f

00000000800200b0 <d_1_9>:
    800200b0:	541189d7          	.insn	4, 0x541189d7
    800200b4:	eb486c97          	auipc	s9,0xeb486
    800200b8:	1e2a                	slli	t3,t3,0x2a
    800200ba:	8bf0420b          	.insn	4, 0x8bf0420b
    800200be:	          	.insn	4, 0x2095473b

00000000800200c0 <d_1_10>:
    800200c0:	2095                	addiw	ra,ra,5
    800200c2:	5bdc                	lw	a5,52(a5)
    800200c4:	e198                	sd	a4,0(a1)
    800200c6:	8824                	.insn	2, 0x8824
    800200c8:	2c29                	addiw	s8,s8,10
    800200ca:	fe7a                	sd	t5,312(sp)
    800200cc:	7c1f 962c       	.insn	6, 0x23b2962c7c1f

00000000800200d0 <d_1_11>:
    800200d0:	23b2                	fld	ft7,264(sp)
    800200d2:	9c85                	subw	s1,s1,s1
    800200d4:	ee6d                	bnez	a2,800201ce <d_1_26+0xe>
    800200d6:	b5780437          	lui	s0,0xb5780
    800200da:	1c61                	addi	s8,s8,-8
    800200dc:	ee98c0a7          	.insn	4, 0xee98c0a7

00000000800200e0 <d_1_12>:
    800200e0:	5335                	li	t1,-19
    800200e2:	bb596f0b          	.insn	4, 0xbb596f0b
    800200e6:	cfde                	sw	s7,220(sp)
    800200e8:	5e7c                	lw	a5,124(a2)
    800200ea:	e7a2                	sd	s0,456(sp)
    800200ec:	abc5                	j	800206dc <_end_data1+0x4dc>
    800200ee:	38d8                	fld	fa4,176(s1)

00000000800200f0 <d_1_13>:
    800200f0:	132c                	addi	a1,sp,424
    800200f2:	e6d6                	sd	s5,328(sp)
    800200f4:	51cd                	li	gp,-13
    800200f6:	a4aa                	fsd	fa0,72(sp)
    800200f8:	36fe                	fld	fa3,504(sp)
    800200fa:	e39e                	sd	t2,448(sp)
    800200fc:	196e                	slli	s2,s2,0x3b
    800200fe:	7e95                	lui	t4,0xfffe5

0000000080020100 <d_1_14>:
    80020100:	e34a                	sd	s2,384(sp)
    80020102:	27fc                	fld	fa5,200(a5)
    80020104:	a411                	j	80020308 <_end_data1+0x108>
    80020106:	6580                	ld	s0,8(a1)
    80020108:	ea52                	sd	s4,272(sp)
    8002010a:	c2bd2ab7          	lui	s5,0xc2bd2
    8002010e:	85bd                	srai	a1,a1,0xf

0000000080020110 <d_1_15>:
    80020110:	093e                	slli	s2,s2,0xf
    80020112:	e966                	sd	s9,144(sp)
    80020114:	8fc1                	or	a5,a5,s0
    80020116:	267a                	fld	fa2,408(sp)
    80020118:	abbfec47          	fmsub.d	fs8,ft11,fs11,fs5,unknown
    8002011c:	bd5c                	fsd	fa5,184(a0)
    8002011e:	89e4                	.insn	2, 0x89e4

0000000080020120 <d_1_16>:
    80020120:	89b4                	.insn	2, 0x89b4
    80020122:	0c44                	addi	s1,sp,532
    80020124:	1584                	addi	s1,sp,736
    80020126:	c94bed4b          	fnmsub.s	fs10,fs7,fs4,fs9,unknown
    8002012a:	b99a61e3          	bltu	s4,s9,8001fcac <_end_data0+0xfaac>
    8002012e:	f8e9                	bnez	s1,80020100 <d_1_14>

0000000080020130 <d_1_17>:
    80020130:	b7da                	fsd	fs6,488(sp)
    80020132:	6b41                	lui	s6,0x10
    80020134:	5e48                	lw	a0,60(a2)
    80020136:	d364                	sw	s1,100(a4)
    80020138:	d3e8                	sw	a0,100(a5)
    8002013a:	ad9c                	fsd	fa5,24(a1)
    8002013c:	97fa                	add	a5,a5,t5
    8002013e:	          	fnmsub.d	fs9,fa2,fa0,fa6,rne

0000000080020140 <d_1_18>:
    80020140:	82a6                	mv	t0,s1
    80020142:	ac04                	fsd	fs1,24(s0)
    80020144:	d189                	beqz	a1,80020046 <d_1_2+0x6>
    80020146:	0c52                	slli	s8,s8,0x14
    80020148:	5734                	lw	a3,104(a4)
    8002014a:	2c81                	sext.w	s9,s9
    8002014c:	d5bd                	beqz	a1,800200ba <d_1_9+0xa>
    8002014e:	          	lui	a3,0x31355

0000000080020150 <d_1_19>:
    80020150:	3135                	addiw	sp,sp,-19
    80020152:	9588                	.insn	2, 0x9588
    80020154:	a6b6                	fsd	fa3,328(sp)
    80020156:	dbb0                	sw	a2,112(a5)
    80020158:	eddc                	sd	a5,152(a1)
    8002015a:	c468                	sw	a0,76(s0)
    8002015c:	6ae4                	ld	s1,208(a3)
    8002015e:	          	.insn	4, 0x83a7c03b

0000000080020160 <d_1_20>:
    80020160:	821c83a7          	.insn	4, 0x821c83a7
    80020164:	87b1                	srai	a5,a5,0xc
    80020166:	e82781bf 21724b44 	.insn	8, 0x21724b44e82781bf
    8002016e:	8471                	srai	s0,s0,0x1c

0000000080020170 <d_1_21>:
    80020170:	2ab9                	addiw	s5,s5,14 # ffffffffc2bd200e <_end+0xffffffff42b71e0e>
    80020172:	fe19ef6b          	.insn	4, 0xfe19ef6b
    80020176:	aa671a73          	csrrw	s4,0xaa6,a4
    8002017a:	e7be                	sd	a5,456(sp)
    8002017c:	3145e7e3          	bltu	a1,s4,80020c8a <_end_data1+0xa8a>

0000000080020180 <d_1_22>:
    80020180:	552c                	lw	a1,104(a0)
    80020182:	acc9                	j	80020454 <_end_data1+0x254>
    80020184:	01231283          	lh	t0,18(t1) # 3fdb9012 <_start-0x40246fee>
    80020188:	4189                	li	gp,2
    8002018a:	1596                	slli	a1,a1,0x25
    8002018c:	4c91                	li	s9,4
    8002018e:	ffec                	sd	a1,248(a5)

0000000080020190 <d_1_23>:
    80020190:	f8d0                	sd	a2,176(s1)
    80020192:	366c                	fld	fa1,232(a2)
    80020194:	37a38ac7          	.insn	4, 0x37a38ac7
    80020198:	85d6                	mv	a1,s5
    8002019a:	04db8faf          	.insn	4, 0x04db8faf
    8002019e:	96c8                	.insn	2, 0x96c8

00000000800201a0 <d_1_24>:
    800201a0:	8a59                	andi	a2,a2,22
    800201a2:	2990                	fld	fa2,16(a1)
    800201a4:	c7ac                	sw	a1,72(a5)
    800201a6:	d37a                	sw	t5,164(sp)
    800201a8:	40ec                	lw	a1,68(s1)
    800201aa:	079f 2d14 bdbf      	.insn	6, 0xbdbf2d14079f

00000000800201b0 <d_1_25>:
    800201b0:	b3f9                	j	8001ff7e <_end_data0+0xfd7e>
    800201b2:	93b5                	srli	a5,a5,0x2d
    800201b4:	56ef570b          	.insn	4, 0x56ef570b
    800201b8:	807079bf edae035b 	.insn	8, 0xedae035b807079bf

00000000800201c0 <d_1_26>:
    800201c0:	d752                	sw	s4,172(sp)
    800201c2:	7a42                	ld	s4,48(sp)
    800201c4:	d4c4                	sw	s1,44(s1)
    800201c6:	e36fc1ef          	jal	gp,8001c7fc <_end_data0+0xc5fc>
    800201ca:	5fa6                	lw	t6,104(sp)
    800201cc:	204e                	fld	ft0,208(sp)
    800201ce:	a508                	fsd	fa0,8(a0)

00000000800201d0 <d_1_27>:
    800201d0:	7adf948b          	.insn	4, 0x7adf948b
    800201d4:	551c                	lw	a5,40(a0)
    800201d6:	199a                	slli	s3,s3,0x26
    800201d8:	8c4a                	mv	s8,s2
    800201da:	3a89                	addiw	s5,s5,-30
    800201dc:	2a92                	fld	fs5,256(sp)
    800201de:	0b24                	addi	s1,sp,408
    800201e0:	1c2a                	slli	s8,s8,0x2a
    800201e2:	85b2                	mv	a1,a2
    800201e4:	e7f4                	sd	a3,200(a5)
    800201e6:	0f0f8aef          	jal	s5,801182d6 <_end+0xb80d6>
    800201ea:	0296                	slli	t0,t0,0x5
    800201ec:	6e8e                	ld	t4,192(sp)
    800201ee:	db49a683          	lw	a3,-588(s3) # 33209dce <_start-0x4cdf6232>
    800201f2:	488e                	lw	a7,192(sp)
    800201f4:	1baa                	slli	s7,s7,0x2a
    800201f6:	1528b667          	.insn	4, 0x1528b667
    800201fa:	7cc5                	lui	s9,0xffff1
    800201fc:	9432                	add	s0,s0,a2
    800201fe:	fc63                	.short	0xfc63

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	7559                	lui	a0,0xffff6
    80030002:	3ae5399b          	.insn	4, 0x3ae5399b
    80030006:	73a2                	ld	t2,40(sp)
    80030008:	2bc0                	fld	fs0,144(a5)
    8003000a:	df62                	sw	s8,188(sp)
    8003000c:	151d                	addi	a0,a0,-25 # ffffffffffff5fe7 <_end+0xffffffff7ff95de7>
    8003000e:	6cb0                	ld	a2,88(s1)
    80030010:	5ee5                	li	t4,-7
    80030012:	e636                	sd	a3,264(sp)
    80030014:	5f2e                	lw	t5,232(sp)
    80030016:	d17c                	sw	a5,100(a0)
    80030018:	6f15                	lui	t5,0x5
    8003001a:	5eaaa69b          	.insn	4, 0x5eaaa69b
    8003001e:	b840                	fsd	fs0,176(s0)

0000000080030020 <d_2_0>:
    80030020:	77f1                	lui	a5,0xffffc
    80030022:	ded1                	beqz	a3,8002ffbe <_end_data1+0xfdbe>
    80030024:	4f64                	lw	s1,92(a4)
    80030026:	b22e                	fsd	fa1,288(sp)
    80030028:	f242                	sd	a6,288(sp)
    8003002a:	7d60                	ld	s0,248(a0)
    8003002c:	afb8d967          	.insn	4, 0xafb8d967

0000000080030030 <d_2_1>:
    80030030:	5948ef0f          	.insn	4, 0x5948ef0f
    80030034:	2432                	fld	fs0,264(sp)
    80030036:	30cd                	addiw	ra,ra,-13
    80030038:	c63e                	sw	a5,12(sp)
    8003003a:	f1e9                	bnez	a1,8002fffc <_end_data1+0xfdfc>
    8003003c:	197565db          	.insn	4, 0x197565db

0000000080030040 <d_2_2>:
    80030040:	19c4                	addi	s1,sp,244
    80030042:	acac                	fsd	fa1,88(s1)
    80030044:	3cae                	fld	fs9,232(sp)
    80030046:	bf6a                	fsd	fs10,440(sp)
    80030048:	0ae5                	addi	s5,s5,25
    8003004a:	2e49                	addiw	t3,t3,18
    8003004c:	e35e                	sd	s7,384(sp)
    8003004e:	          	.insn	4, 0x5efb793b

0000000080030050 <d_2_3>:
    80030050:	b5885efb          	.insn	4, 0xb5885efb
    80030054:	2804                	fld	fs1,16(s0)
    80030056:	a844                	fsd	fs1,144(s0)
    80030058:	4eec                	lw	a1,92(a3)
    8003005a:	dd3c37d3          	.insn	4, 0xdd3c37d3
    8003005e:	ca19                	beqz	a2,80030074 <d_2_5+0x4>

0000000080030060 <d_2_4>:
    80030060:	8d697377          	.insn	4, 0x8d697377
    80030064:	f50c                	sd	a1,40(a0)
    80030066:	ba91bacb          	fnmsub.d	fs5,ft3,fs1,fs7,rup
    8003006a:	7830                	ld	a2,112(s0)
    8003006c:	a3dd                	j	80030652 <_end_data2+0x452>
    8003006e:	d250                	sw	a2,36(a2)

0000000080030070 <d_2_5>:
    80030070:	9638                	.insn	2, 0x9638
    80030072:	7c10                	ld	a2,56(s0)
    80030074:	dae2                	sw	s8,116(sp)
    80030076:	fed8                	sd	a4,184(a3)
    80030078:	af2c                	fsd	fa1,88(a4)
    8003007a:	da4e0f87          	.insn	4, 0xda4e0f87
    8003007e:	f5f1                	bnez	a1,8003004a <d_2_2+0xa>

0000000080030080 <d_2_6>:
    80030080:	10aa                	slli	ra,ra,0x2a
    80030082:	9c89                	subw	s1,s1,a0
    80030084:	820a                	mv	tp,sp
    80030086:	a829                	j	800300a0 <d_2_8>
    80030088:	2b06                	fld	fs6,64(sp)
    8003008a:	b055                	j	8002f92e <_end_data1+0xf72e>
    8003008c:	2dfca4cf          	.insn	4, 0x2dfca4cf

0000000080030090 <d_2_7>:
    80030090:	4592                	lw	a1,4(sp)
    80030092:	63e8                	ld	a0,192(a5)
    80030094:	c23c                	sw	a5,64(a2)
    80030096:	29f1                	addiw	s3,s3,28
    80030098:	c7f81647          	.insn	4, 0xc7f81647
    8003009c:	206d                	.insn	2, 0x206d
    8003009e:	80d4                	.insn	2, 0x80d4

00000000800300a0 <d_2_8>:
    800300a0:	249927fb          	.insn	4, 0x249927fb
    800300a4:	1040                	addi	s0,sp,36
    800300a6:	9536                	add	a0,a0,a3
    800300a8:	8ac6                	mv	s5,a7
    800300aa:	6db5                	lui	s11,0xd
    800300ac:	66a39327          	.insn	4, 0x66a39327

00000000800300b0 <d_2_9>:
    800300b0:	ca5d                	beqz	a2,80030166 <d_2_20+0x6>
    800300b2:	b58a                	fsd	ft2,232(sp)
    800300b4:	067a                	slli	a2,a2,0x1e
    800300b6:	b12127c3          	fmadd.s	fa5,ft2,fs2,fs6,rdn
    800300ba:	0667a88f          	.insn	4, 0x0667a88f
    800300be:	          	.insn	4, 0xe63562af

00000000800300c0 <d_2_10>:
    800300c0:	e635                	bnez	a2,8003012c <d_2_16+0xc>
    800300c2:	05f83627          	fsd	ft11,76(a6)
    800300c6:	32ca                	fld	ft5,176(sp)
    800300c8:	6918c2c7          	fmsub.s	ft5,fa7,fa7,fa3,rmm
    800300cc:	1f2a                	slli	t5,t5,0x2a
    800300ce:	  	.insn	8, 0x80fcf32d22858fbf

00000000800300d0 <d_2_11>:
    800300d0:	2285                	addiw	t0,t0,1 # fffffffffffe0001 <_end+0xffffffff7ff7fe01>
    800300d2:	f32d                	bnez	a4,80030034 <d_2_1+0x4>
    800300d4:	80fc                	.insn	2, 0x80fc
    800300d6:	f470                	sd	a2,232(s0)
    800300d8:	b5bd                	j	8002ff46 <_end_data1+0xfd46>
    800300da:	64c9                	lui	s1,0x12
    800300dc:	33ee                	fld	ft7,248(sp)
    800300de:	0d9d                	addi	s11,s11,7 # d007 <_start-0x7fff2ff9>

00000000800300e0 <d_2_12>:
    800300e0:	205a                	fld	ft0,400(sp)
    800300e2:	53e8                	lw	a0,100(a5)
    800300e4:	5752                	lw	a4,52(sp)
    800300e6:	01e4                	addi	s1,sp,204
    800300e8:	d1c5                	beqz	a1,80030088 <d_2_6+0x8>
    800300ea:	98d8                	.insn	2, 0x98d8
    800300ec:	f3ce                	sd	s3,480(sp)
    800300ee:	bed9                	j	8002fcc4 <_end_data1+0xfac4>

00000000800300f0 <d_2_13>:
    800300f0:	0d0c                	addi	a1,sp,656
    800300f2:	109c                	addi	a5,sp,96
    800300f4:	e0fe1b4f          	fnmadd.s	fs6,ft8,fa5,ft8,rtz
    800300f8:	93ac                	.insn	2, 0x93ac
    800300fa:	eff8                	sd	a4,216(a5)
    800300fc:	c8ccee37          	lui	t3,0xc8cce

0000000080030100 <d_2_14>:
    80030100:	799d                	lui	s3,0xfffe7
    80030102:	6079                	c.lui	zero,0x1e
    80030104:	a585                	j	80030764 <_end_data2+0x564>
    80030106:	a639                	j	80030414 <_end_data2+0x214>
    80030108:	eabc                	sd	a5,80(a3)
    8003010a:	a11dc5a7          	.insn	4, 0xa11dc5a7
    8003010e:	097e                	slli	s2,s2,0x1f

0000000080030110 <d_2_15>:
    80030110:	3eb8                	fld	fa4,120(a3)
    80030112:	d309                	beqz	a4,80030014 <_random_data2+0x14>
    80030114:	bff71aeb          	.insn	4, 0xbff71aeb
    80030118:	e2e8a75b          	.insn	4, 0xe2e8a75b
    8003011c:	a129                	j	80030526 <_end_data2+0x326>
    8003011e:	c4bd                	beqz	s1,8003018c <d_2_22+0xc>

0000000080030120 <d_2_16>:
    80030120:	dc6c                	sw	a1,124(s0)
    80030122:	829f59c3          	fmadd.d	fs3,ft10,fs1,fa6,unknown
    80030126:	ee50                	sd	a2,152(a2)
    80030128:	15c5                	addi	a1,a1,-15
    8003012a:	4f7e                	lw	t5,220(sp)
    8003012c:	01126723          	.insn	4, 0x01126723

0000000080030130 <d_2_17>:
    80030130:	f13d                	bnez	a0,80030096 <d_2_7+0x6>
    80030132:	8f2e                	mv	t5,a1
    80030134:	412e                	lw	sp,200(sp)
    80030136:	3c6e                	fld	fs8,248(sp)
    80030138:	7b04                	ld	s1,48(a4)
    8003013a:	dd5426d7          	vwsub.wv	v13,v21,v8,v0.t
    8003013e:	          	.insn	4, 0x9e59bccb

0000000080030140 <d_2_18>:
    80030140:	9e59                	.insn	2, 0x9e59
    80030142:	b4a83f7f e904e075 	.insn	16, 0x3968510e8299798de904e075b4a83f7f
    8003014a:	8299798d  

0000000080030150 <d_2_19>:
    80030150:	3968                	fld	fa0,240(a0)
    80030152:	18a2                	slli	a7,a7,0x28
    80030154:	912470af          	.insn	4, 0x912470af
    80030158:	a679                	j	800304e6 <_end_data2+0x2e6>
    8003015a:	4a02                	lw	s4,0(sp)
    8003015c:	682a                	ld	a6,136(sp)
    8003015e:	          	.insn	4, 0xb800d98f

0000000080030160 <d_2_20>:
    80030160:	b800                	fsd	fs0,48(s0)
    80030162:	66a2                	ld	a3,8(sp)
    80030164:	6614                	ld	a3,8(a2)
    80030166:	5948                	lw	a0,52(a0)
    80030168:	4548                	lw	a0,12(a0)
    8003016a:	9ab1                	andi	a3,a3,-20
    8003016c:	b0f9b7d7          	vnsrl.wi	v15,v15,19,v0.t

0000000080030170 <d_2_21>:
    80030170:	bc69                	j	8002fc0a <_end_data1+0xfa0a>
    80030172:	0f80                	addi	s0,sp,976
    80030174:	295cfcc3          	fmadd.s	fs9,fs9,fs5,ft5
    80030178:	7bda                	ld	s7,432(sp)
    8003017a:	a0c5                	j	8003025a <_end_data2+0x5a>
    8003017c:	f87a                	sd	t5,48(sp)
    8003017e:	459d                	li	a1,7

0000000080030180 <d_2_22>:
    80030180:	4f55                	li	t5,21
    80030182:	7c9c                	ld	a5,56(s1)
    80030184:	a612                	fsd	ft4,264(sp)
    80030186:	cc15                	beqz	s0,800301c2 <d_2_26+0x2>
    80030188:	7cec46bf 3fdab33f 	.insn	8, 0x3fdab33f7cec46bf

0000000080030190 <d_2_23>:
    80030190:	e1694fb3          	.insn	4, 0xe1694fb3
    80030194:	1e9c                	addi	a5,sp,880
    80030196:	4802                	lw	a6,0(sp)
    80030198:	3626                	fld	fa2,104(sp)
    8003019a:	840b72bf  	.insn	8, 0x502e8f6c840b72bf

00000000800301a0 <d_2_24>:
    800301a0:	502e                	.insn	2, 0x502e
    800301a2:	2211                	addiw	tp,tp,4 # ffffffffffff0004 <_end+0xffffffff7ff8fe04>
    800301a4:	352a                	fld	fa0,168(sp)
    800301a6:	aa25                	j	800302de <_end_data2+0xde>
    800301a8:	15aa                	slli	a1,a1,0x2a
    800301aa:	e50a                	sd	sp,136(sp)
    800301ac:	35cc                	fld	fa1,168(a1)
    800301ae:	d44d                	beqz	s0,80030158 <d_2_19+0x8>

00000000800301b0 <d_2_25>:
    800301b0:	b7e5                	j	80030198 <d_2_23+0x8>
    800301b2:	7eaa3cc7          	.insn	4, 0x7eaa3cc7
    800301b6:	d6c8                	sw	a0,44(a3)
    800301b8:	b3f4292b          	.insn	4, 0xb3f4292b
    800301bc:	8490c86f          	jal	a6,7ff3ca04 <_start-0xc35fc>

00000000800301c0 <d_2_26>:
    800301c0:	a480                	fsd	fs0,8(s1)
    800301c2:	d318                	sw	a4,32(a4)
    800301c4:	cb154a67          	.insn	4, 0xcb154a67
    800301c8:	3c0588d7          	.insn	4, 0x3c0588d7
    800301cc:	1344                	addi	s1,sp,420
    800301ce:	026e                	slli	tp,tp,0x1b

00000000800301d0 <d_2_27>:
    800301d0:	a23142a3          	.insn	4, 0xa23142a3
    800301d4:	1e91abb7          	lui	s7,0x1e91a
    800301d8:	9ec2                	add	t4,t4,a6
    800301da:	36c5                	addiw	a3,a3,-15 # 31354ff1 <_start-0x4ecab00f>
    800301dc:	2ab6                	fld	fs5,328(sp)
    800301de:	1041                	c.nop	-16
    800301e0:	c96e                	sw	s11,144(sp)
    800301e2:	746eee7b          	.insn	4, 0x746eee7b
    800301e6:	2af4                	fld	fa3,208(a3)
    800301e8:	ca3e                	sw	a5,20(sp)
    800301ea:	3161                	addiw	sp,sp,-8
    800301ec:	74e4                	ld	s1,232(s1)
    800301ee:	6849                	lui	a6,0x12
    800301f0:	a75a                	fsd	fs6,392(sp)
    800301f2:	a8b2a3cb          	fnmsub.s	ft7,ft5,fa1,fs5,rdn
    800301f6:	807d                	srli	s0,s0,0x1f
    800301f8:	3851                	addiw	a6,a6,-12 # 11ff4 <_start-0x7ffee00c>
    800301fa:	38a8                	fld	fa0,112(s1)
    800301fc:	0bed                	addi	s7,s7,27 # 1e91a01b <_start-0x616e5fe5>
    800301fe:	9b77                	.short	0x9b77

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	8740f86b          	.insn	4, 0x8740f86b
    80040004:	0f86                	slli	t6,t6,0x1
    80040006:	855e                	mv	a0,s7
    80040008:	f204                	sd	s1,32(a2)
    8004000a:	65b9                	lui	a1,0xe
    8004000c:	1290                	addi	a2,sp,352
    8004000e:	4268                	lw	a0,68(a2)
    80040010:	08f0                	addi	a2,sp,92
    80040012:	897a                	mv	s2,t5
    80040014:	7115                	addi	sp,sp,-224
    80040016:	8a14                	.insn	2, 0x8a14
    80040018:	76a62573          	csrrs	a0,0x76a,a2
    8004001c:	d190                	sw	a2,32(a1)
    8004001e:	3f60                	fld	fs0,248(a4)

0000000080040020 <d_3_0>:
    80040020:	39e8                	fld	fa0,240(a1)
    80040022:	95d6                	add	a1,a1,s5
    80040024:	add4                	fsd	fa3,152(a1)
    80040026:	bed9                	j	8003fbfc <_end_data2+0xf9fc>
    80040028:	2f5d                	addiw	t5,t5,23 # 5017 <_start-0x7fffafe9>
    8004002a:	e8b9                	bnez	s1,80040080 <d_3_6>
    8004002c:	f6b9                	bnez	a3,8003ff7a <_end_data2+0xfd7a>
    8004002e:	6e21                	lui	t3,0x8

0000000080040030 <d_3_1>:
    80040030:	32c1d2d3          	.insn	4, 0x32c1d2d3
    80040034:	b91dc98f          	.insn	4, 0xb91dc98f
    80040038:	1041                	c.nop	-16
    8004003a:	e855                	bnez	s0,800400ee <d_3_12+0xe>
    8004003c:	985f37c7          	fmsub.s	fa5,ft10,ft5,fs3,rup

0000000080040040 <d_3_2>:
    80040040:	1d18                	addi	a4,sp,688
    80040042:	e0d0                	sd	a2,128(s1)
    80040044:	4d9a                	lw	s11,132(sp)
    80040046:	7c35                	lui	s8,0xfffed
    80040048:	9ac8bb13          	sltiu	s6,a7,-1620
    8004004c:	6461                	lui	s0,0x18
    8004004e:	a162                	fsd	fs8,128(sp)

0000000080040050 <d_3_3>:
    80040050:	3211                	addiw	tp,tp,-28 # ffffffffffffffe4 <_end+0xffffffff7ff9fde4>
    80040052:	3aa6                	fld	fs5,104(sp)
    80040054:	c26e                	sw	s11,4(sp)
    80040056:	cb06                	sw	ra,148(sp)
    80040058:	5c613447          	.insn	4, 0x5c613447
    8004005c:	5b89                	li	s7,-30
    8004005e:	0965                	addi	s2,s2,25 # 12019 <_start-0x7ffedfe7>

0000000080040060 <d_3_4>:
    80040060:	0914                	addi	a3,sp,144
    80040062:	e9f2                	sd	t3,208(sp)
    80040064:	ddb4                	sw	a3,120(a1)
    80040066:	49cd                	li	s3,19
    80040068:	b6c0                	fsd	fs0,168(a3)
    8004006a:	60fc                	ld	a5,192(s1)
    8004006c:	091a                	slli	s2,s2,0x6
    8004006e:	73ea                	ld	t2,184(sp)

0000000080040070 <d_3_5>:
    80040070:	0f39c1bb          	.insn	4, 0x0f39c1bb
    80040074:	8eb36a6b          	.insn	4, 0x8eb36a6b
    80040078:	f8d6                	sd	s5,112(sp)
    8004007a:	5322                	lw	t1,40(sp)
    8004007c:	b7d8                	fsd	fa4,168(a5)
    8004007e:	a4df        	.insn	6, 0x55e10309a4df

0000000080040080 <d_3_6>:
    80040080:	0309                	addi	t1,t1,2
    80040082:	55e1                	li	a1,-8
    80040084:	ad7a9d23          	sh	s7,-1318(s5)
    80040088:	8e56                	mv	t3,s5
    8004008a:	894e                	mv	s2,s3
    8004008c:	ef95                	bnez	a5,800400c8 <d_3_10+0x8>
    8004008e:	64ac                	ld	a1,72(s1)

0000000080040090 <d_3_7>:
    80040090:	4964                	lw	s1,84(a0)
    80040092:	da5c                	sw	a5,52(a2)
    80040094:	2f42                	fld	ft10,16(sp)
    80040096:	ab71                	j	80040632 <_end_data3+0x432>
    80040098:	b746                	fsd	fa7,424(sp)
    8004009a:	96f6                	add	a3,a3,t4
    8004009c:	21d2                	fld	ft3,272(sp)
    8004009e:	dcd5                	beqz	s1,8004005a <d_3_3+0xa>

00000000800400a0 <d_3_8>:
    800400a0:	5129                	li	sp,-22
    800400a2:	e0a1f037          	lui	zero,0xe0a1f
    800400a6:	1b573d73          	csrrc	s10,0x1b5,a4
    800400aa:	0446                	slli	s0,s0,0x11
    800400ac:	7ad4                	ld	a3,176(a3)
    800400ae:	2958                	fld	fa4,144(a0)

00000000800400b0 <d_3_9>:
    800400b0:	c7a83fab          	.insn	4, 0xc7a83fab
    800400b4:	bcce                	fsd	fs3,120(sp)
    800400b6:	9bcc958f          	.insn	4, 0x9bcc958f
    800400ba:	db7e                	sw	t6,180(sp)
    800400bc:	4c6b9f2b          	.insn	4, 0x4c6b9f2b

00000000800400c0 <d_3_10>:
    800400c0:	ec15f19b          	.insn	4, 0xec15f19b
    800400c4:	580a                	lw	a6,160(sp)
    800400c6:	3e76                	fld	ft8,376(sp)
    800400c8:	24d1                	addiw	s1,s1,20 # 12014 <_start-0x7ffedfec>
    800400ca:	6282                	ld	t0,0(sp)
    800400cc:	4e80                	lw	s0,24(a3)
    800400ce:	df08                	sw	a0,56(a4)

00000000800400d0 <d_3_11>:
    800400d0:	a2ad                	j	8004023a <_end_data3+0x3a>
    800400d2:	c97c                	sw	a5,84(a0)
    800400d4:	98884473          	.insn	4, 0x98884473
    800400d8:	dc11                	beqz	s0,8003fff4 <_end_data2+0xfdf4>
    800400da:	e5ac                	sd	a1,72(a1)
    800400dc:	0d78                	addi	a4,sp,668
    800400de:	9f69                	.insn	2, 0x9f69

00000000800400e0 <d_3_12>:
    800400e0:	5b64                	lw	s1,116(a4)
    800400e2:	7d98                	ld	a4,56(a1)
    800400e4:	0dfd                	addi	s11,s11,31
    800400e6:	4cc4                	lw	s1,28(s1)
    800400e8:	d040                	sw	s0,36(s0)
    800400ea:	ce2b1a4f          	.insn	4, 0xce2b1a4f
    800400ee:	ef1e                	sd	t2,408(sp)

00000000800400f0 <d_3_13>:
    800400f0:	5eb9e607          	.insn	4, 0x5eb9e607
    800400f4:	8ad9                	andi	a3,a3,22
    800400f6:	407e                	.insn	2, 0x407e
    800400f8:	1d4ebe97          	auipc	t4,0x1d4eb
    800400fc:	78dd                	lui	a7,0xffff7
    800400fe:	4cac                	lw	a1,88(s1)

0000000080040100 <d_3_14>:
    80040100:	a7fe                	fsd	ft11,456(sp)
    80040102:	9d39                	addw	a0,a0,a4
    80040104:	3b22                	fld	fs6,40(sp)
    80040106:	0a1a                	slli	s4,s4,0x6
    80040108:	0ba2                	slli	s7,s7,0x8
    8004010a:	a145                	j	800405aa <_end_data3+0x3aa>
    8004010c:	334d                	addiw	t1,t1,-13
    8004010e:	3a0d                	addiw	s4,s4,-29

0000000080040110 <d_3_15>:
    80040110:	591f 702a 4150      	.insn	6, 0x4150702a591f
    80040116:	ba7c9c07          	.insn	4, 0xba7c9c07
    8004011a:	ebd9                	bnez	a5,800401b0 <d_3_25>
    8004011c:	6d4c                	ld	a1,152(a0)
    8004011e:	4af4                	lw	a3,84(a3)

0000000080040120 <d_3_16>:
    80040120:	83b4                	.insn	2, 0x83b4
    80040122:	e8c9                	bnez	s1,800401b4 <d_3_25+0x4>
    80040124:	2385                	addiw	t2,t2,1
    80040126:	7d6a                	ld	s10,184(sp)
    80040128:	0fe6                	slli	t6,t6,0x19
    8004012a:	7dfe                	ld	s11,504(sp)
    8004012c:	f2ae                	sd	a1,352(sp)
    8004012e:	c311                	beqz	a4,80040132 <d_3_17+0x2>

0000000080040130 <d_3_17>:
    80040130:	edbd                	bnez	a1,800401ae <d_3_24+0xe>
    80040132:	f5df 3850 f04e      	.insn	6, 0xf04e3850f5df
    80040138:	4cb2                	lw	s9,12(sp)
    8004013a:	a111                	j	8004053e <_end_data3+0x33e>
    8004013c:	6e26217b          	.insn	4, 0x6e26217b

0000000080040140 <d_3_18>:
    80040140:	9631                	srai	a2,a2,0x2c
    80040142:	b8a0                	fsd	fs0,112(s1)
    80040144:	56c1cacf          	.insn	4, 0x56c1cacf
    80040148:	ac96ba37          	lui	s4,0xac96b
    8004014c:	105a                	c.slli	zero,0x36
    8004014e:	b086                	fsd	ft1,96(sp)

0000000080040150 <d_3_19>:
    80040150:	6a46                	ld	s4,80(sp)
    80040152:	ba2bd19b          	.insn	4, 0xba2bd19b
    80040156:	e929                	bnez	a0,800401a8 <d_3_24+0x8>
    80040158:	e9b714bb          	.insn	4, 0xe9b714bb
    8004015c:	bdb6                	fsd	fa3,248(sp)
    8004015e:	          	sh	t5,-1697(t6)

0000000080040160 <d_3_20>:
    80040160:	b30d95ef          	jal	a1,80019490 <_end_data0+0x9290>
    80040164:	c748                	sw	a0,12(a4)
    80040166:	9e9f ffd6 6181      	.insn	6, 0x6181ffd69e9f
    8004016c:	4b4d                	li	s6,19
    8004016e:	8a49                	andi	a2,a2,18

0000000080040170 <d_3_21>:
    80040170:	22fb7e9b          	.insn	4, 0x22fb7e9b
    80040174:	4eecb1a3          	sd	a4,1251(s9) # ffffffffffff14e3 <_end+0xffffffff7ff912e3>
    80040178:	a02ebda7          	fsd	ft2,-1509(t4) # 9d52ab13 <_end+0x1d4ca913>
    8004017c:	684449fb          	.insn	4, 0x684449fb

0000000080040180 <d_3_22>:
    80040180:	a77f b655 fc5a ec96 	.insn	14, 0x72524465cca3ec96fc5ab655a77f
    80040188:	cca3 4465 7252 
    8004018e:	b5f5                	j	8004007a <d_3_5+0xa>

0000000080040190 <d_3_23>:
    80040190:	d469                	beqz	s0,8004015a <d_3_19+0xa>
    80040192:	be1c                	fsd	fa5,56(a2)
    80040194:	dd51                	beqz	a0,80040130 <d_3_17>
    80040196:	6f88                	ld	a0,24(a5)
    80040198:	1a89                	addi	s5,s5,-30
    8004019a:	d016                	sw	t0,32(sp)
    8004019c:	d7b72ea7          	fsw	fs11,-643(a4)

00000000800401a0 <d_3_24>:
    800401a0:	4232                	lw	tp,12(sp)
    800401a2:	52e0                	lw	s0,100(a3)
    800401a4:	5cf132c3          	.insn	4, 0x5cf132c3
    800401a8:	c7fc                	sw	a5,76(a5)
    800401aa:	d6757343          	.insn	4, 0xd6757343
    800401ae:	40b8                	lw	a4,64(s1)

00000000800401b0 <d_3_25>:
    800401b0:	f4ce                	sd	s3,104(sp)
    800401b2:	6c9c                	ld	a5,24(s1)
    800401b4:	efa9                	bnez	a5,8004020e <_end_data3+0xe>
    800401b6:	2eed                	addiw	t4,t4,27
    800401b8:	cce2                	sw	s8,88(sp)
    800401ba:	d018                	sw	a4,32(s0)
    800401bc:	77bd6ecb          	.insn	4, 0x77bd6ecb

00000000800401c0 <d_3_26>:
    800401c0:	86b6                	mv	a3,a3
    800401c2:	1926                	slli	s2,s2,0x29
    800401c4:	793e                	ld	s2,488(sp)
    800401c6:	177d8797          	auipc	a5,0x177d8
    800401ca:	d87a                	sw	t5,48(sp)
    800401cc:	1910                	addi	a2,sp,176
    800401ce:	f2ba                	sd	a4,352(sp)

00000000800401d0 <d_3_27>:
    800401d0:	621c                	ld	a5,0(a2)
    800401d2:	4cdc                	lw	a5,28(s1)
    800401d4:	7628                	ld	a0,104(a2)
    800401d6:	11a8                	addi	a0,sp,232
    800401d8:	899a                	mv	s3,t1
    800401da:	92c0                	.insn	2, 0x92c0
    800401dc:	55e1                	li	a1,-8
    800401de:	ea3a                	sd	a4,272(sp)
    800401e0:	e9cc7f77          	.insn	4, 0xe9cc7f77
    800401e4:	bc1f 077e 10c9      	.insn	6, 0x10c9077ebc1f
    800401ea:	dd6a                	sw	s10,184(sp)
    800401ec:	624020ab          	.insn	4, 0x624020ab
    800401f0:	db2d                	beqz	a4,80040162 <d_3_20+0x2>
    800401f2:	95f0bb0b          	.insn	4, 0x95f0bb0b
    800401f6:	f45a                	sd	s6,40(sp)
    800401f8:	9175                	srli	a0,a0,0x3d
    800401fa:	93b6                	add	t2,t2,a3
    800401fc:	aecc                	fsd	fa1,152(a3)
    800401fe:	e4b2                	sd	a2,72(sp)

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	0189                	addi	gp,gp,2
    80050002:	e97e                	sd	t6,144(sp)
    80050004:	aee8                	fsd	fa0,216(a3)
    80050006:	6019                	c.lui	zero,0x6
    80050008:	15a6                	slli	a1,a1,0x29
    8005000a:	9b09                	andi	a4,a4,-30
    8005000c:	4506                	lw	a0,64(sp)
    8005000e:	22b13e9b          	.insn	4, 0x22b13e9b
    80050012:	01450fbf 81bccf13 	.insn	8, 0x81bccf1301450fbf
    8005001a:	b3c0                	fsd	fs0,160(a5)
    8005001c:	ffdf 53d5       	.insn	6, 0xa91753d5ffdf

0000000080050020 <d_4_0>:
    80050020:	3f5fa917          	auipc	s2,0x3f5fa
    80050024:	c7ac                	sw	a1,72(a5)
    80050026:	a776                	fsd	ft9,392(sp)
    80050028:	5a08                	lw	a0,48(a2)
    8005002a:	c618                	sw	a4,8(a2)
    8005002c:	e4775767          	.insn	4, 0xe4775767

0000000080050030 <d_4_1>:
    80050030:	eab6                	sd	a3,336(sp)
    80050032:	c3e543d3          	.insn	4, 0xc3e543d3
    80050036:	e3fc                	sd	a5,192(a5)
    80050038:	3caa                	fld	fs9,168(sp)
    8005003a:	6fb069ef          	jal	s3,80056f34 <_end_data4+0x6d34>
    8005003e:	c19d                	beqz	a1,80050064 <d_4_4+0x4>

0000000080050040 <d_4_2>:
    80050040:	d035                	beqz	s0,8004ffa4 <_end_data3+0xfda4>
    80050042:	f725                	bnez	a4,8004ffaa <_end_data3+0xfdaa>
    80050044:	aeb5                	j	800503c0 <_end_data4+0x1c0>
    80050046:	cc69                	beqz	s0,80050120 <d_4_16>
    80050048:	7f25                	lui	t5,0xfffe9
    8005004a:	76c1                	lui	a3,0xffff0
    8005004c:	1b2d                	addi	s6,s6,-21 # ffeb <_start-0x7fff0015>
    8005004e:	          	.insn	4, 0x2273540b

0000000080050050 <d_4_3>:
    80050050:	54a62273          	csrrs	tp,0x54a,a2
    80050054:	2b5a                	fld	fs6,400(sp)
    80050056:	dad1                	beqz	a3,8004ffea <_end_data3+0xfdea>
    80050058:	2a2e                	fld	fs4,200(sp)
    8005005a:	b884                	fsd	fs1,48(s1)
    8005005c:	579e                	lw	a5,228(sp)
    8005005e:	a2d4                	fsd	fa3,128(a3)

0000000080050060 <d_4_4>:
    80050060:	1769                	addi	a4,a4,-6
    80050062:	5043d57f a3644c40 	.insn	20, 0xbd1932d0ea47583865cfff14a3644c405043d57f
    8005006a:	65cfff14  
    80050072:	 

0000000080050070 <d_4_5>:
    80050070:	32d0ea47          	fmsub.d	fs4,ft1,fa3,ft6,unknown
    80050074:	bd19                	j	8004fe8a <_end_data3+0xfc8a>
    80050076:	5118                	lw	a4,32(a0)
    80050078:	1e88                	addi	a0,sp,880
    8005007a:	4f30                	lw	a2,88(a4)
    8005007c:	95a4                	.insn	2, 0x95a4
    8005007e:	7f56                	ld	t5,368(sp)

0000000080050080 <d_4_6>:
    80050080:	387a                	fld	fa6,440(sp)
    80050082:	4a25                	li	s4,9
    80050084:	8802                	jr	a6
    80050086:	8667a51b          	.insn	4, 0x8667a51b
    8005008a:	4286                	lw	t0,64(sp)
    8005008c:	22d6                	fld	ft5,336(sp)
    8005008e:	          	.insn	4, 0xea652d8b

0000000080050090 <d_4_7>:
    80050090:	ea65                	bnez	a2,80050180 <d_4_22>
    80050092:	36b6c377          	.insn	4, 0x36b6c377
    80050096:	4b0c                	lw	a1,16(a4)
    80050098:	1c6c                	addi	a1,sp,572
    8005009a:	f088                	sd	a0,32(s1)
    8005009c:	aa0e                	fsd	ft3,272(sp)
    8005009e:	7714                	ld	a3,40(a4)

00000000800500a0 <d_4_8>:
    800500a0:	f6cab87f f5cebaf8 	.insn	16, 0x7dce84ba527d49a6f5cebaf8f6cab87f
    800500a8:	527d49a6 7dce84ba 

00000000800500b0 <d_4_9>:
    800500b0:	706d                	c.lui	zero,0xffffb
    800500b2:	8c95f9d3          	.insn	4, 0x8c95f9d3
    800500b6:	744edc03          	lhu	s8,1860(t4)
    800500ba:	199f d0d1 50a0      	.insn	6, 0x50a0d0d1199f

00000000800500c0 <d_4_10>:
    800500c0:	d005                	beqz	s0,8004ffe0 <_end_data3+0xfde0>
    800500c2:	b14b1ccf          	fnmadd.s	fs9,fs6,fs4,fs6,rtz
    800500c6:	9914                	.insn	2, 0x9914
    800500c8:	ab42                	fsd	fa6,400(sp)
    800500ca:	9329                	srli	a4,a4,0x2a
    800500cc:	d747573b          	.insn	4, 0xd747573b

00000000800500d0 <d_4_11>:
    800500d0:	00f9                	addi	ra,ra,30
    800500d2:	450d1e43          	.insn	4, 0x450d1e43
    800500d6:	22a1                	addiw	t0,t0,8
    800500d8:	609b1deb          	.insn	4, 0x609b1deb
    800500dc:	0a68                	addi	a0,sp,284
    800500de:	d374                	sw	a3,100(a4)

00000000800500e0 <d_4_12>:
    800500e0:	cfc0                	sw	s0,28(a5)
    800500e2:	2451                	addiw	s0,s0,20 # 18014 <_start-0x7ffe7fec>
    800500e4:	7e62042b          	.insn	4, 0x7e62042b
    800500e8:	9a71                	andi	a2,a2,-4
    800500ea:	9495                	srai	s1,s1,0x25
    800500ec:	bc0d                	j	8004fb1e <_end_data3+0xf91e>
    800500ee:	ffcd                	bnez	a5,800500a8 <d_4_8+0x8>

00000000800500f0 <d_4_13>:
    800500f0:	224d                	addiw	tp,tp,19 # 13 <_start-0x7fffffed>
    800500f2:	dab4                	sw	a3,112(a3)
    800500f4:	7152                	ld	sp,304(sp)
    800500f6:	389d                	addiw	a7,a7,-25 # ffffffffffff6fe7 <_end+0xffffffff7ff96de7>
    800500f8:	5649                	li	a2,-14
    800500fa:	45d1e83b          	.insn	4, 0x45d1e83b
    800500fe:	b061                	j	8004f986 <_end_data3+0xf786>

0000000080050100 <d_4_14>:
    80050100:	a9ca                	fsd	fs2,208(sp)
    80050102:	2f45                	addiw	t5,t5,17 # fffffffffffe9011 <_end+0xffffffff7ff88e11>
    80050104:	37ec                	fld	fa1,232(a5)
    80050106:	3af8                	fld	fa4,240(a3)
    80050108:	e41f 4ab0 6881      	.insn	6, 0x68814ab0e41f
    8005010e:	9d15                	subw	a0,a0,a3

0000000080050110 <d_4_15>:
    80050110:	0464                	addi	s1,sp,524
    80050112:	5660                	lw	s0,108(a2)
    80050114:	0944                	addi	s1,sp,148
    80050116:	e374                	sd	a3,192(a4)
    80050118:	caad6d3f a7d2018b 	.insn	8, 0xa7d2018bcaad6d3f

0000000080050120 <d_4_16>:
    80050120:	681a                	ld	a6,384(sp)
    80050122:	52f4                	lw	a3,100(a3)
    80050124:	6700                	ld	s0,8(a4)
    80050126:	bfed                	j	80050120 <d_4_16>
    80050128:	a3b8                	fsd	fa4,64(a5)
    8005012a:	7fa5                	lui	t6,0xfffe9
    8005012c:	e2b5                	bnez	a3,80050190 <d_4_23>
    8005012e:	e946                	sd	a7,144(sp)

0000000080050130 <d_4_17>:
    80050130:	354a                	fld	fa0,176(sp)
    80050132:	7f51                	lui	t5,0xffff4
    80050134:	d404ad27          	fsw	ft0,-678(s1)
    80050138:	6681                	.insn	2, 0x6681
    8005013a:	069ad603          	lhu	a2,105(s5)
    8005013e:	6fe1                	lui	t6,0x18

0000000080050140 <d_4_18>:
    80050140:	4119                	li	sp,6
    80050142:	6e1c                	ld	a5,24(a2)
    80050144:	0d9ce427          	vsoxei32.v	v8,(s9),v25,v0.t
    80050148:	fdce                	sd	s3,248(sp)
    8005014a:	030b6ab3          	rem	s5,s6,a6
    8005014e:	95c0                	.insn	2, 0x95c0

0000000080050150 <d_4_19>:
    80050150:	8b206f23          	.insn	4, 0x8b206f23
    80050154:	6ea9503b          	.insn	4, 0x6ea9503b
    80050158:	4656082f          	.insn	4, 0x4656082f
    8005015c:	7c633dff  	.insn	16, 0xb564f8b045886ea29e78930c7c633dff
    80050164:	  

0000000080050160 <d_4_20>:
    80050160:	930c                	.insn	2, 0x930c
    80050162:	9e78                	.insn	2, 0x9e78
    80050164:	6ea2                	ld	t4,8(sp)
    80050166:	4588                	lw	a0,8(a1)
    80050168:	f8b0                	sd	a2,112(s1)
    8005016a:	b564                	fsd	fs1,232(a0)
    8005016c:	c7a1                	beqz	a5,800501b4 <d_4_25+0x4>
    8005016e:	ec8e                	sd	gp,88(sp)

0000000080050170 <d_4_21>:
    80050170:	1fb8                	addi	a4,sp,1016
    80050172:	8122                	mv	sp,s0
    80050174:	a98e                	fsd	ft3,208(sp)
    80050176:	b245                	j	8004fb16 <_end_data3+0xf916>
    80050178:	29c1                	addiw	s3,s3,16 # fffffffffffe7010 <_end+0xffffffff7ff86e10>
    8005017a:	894d                	andi	a0,a0,19
    8005017c:	5e68                	lw	a0,124(a2)
    8005017e:	97e5                	srai	a5,a5,0x39

0000000080050180 <d_4_22>:
    80050180:	ae84502b          	.insn	4, 0xae84502b
    80050184:	53c0                	lw	s0,36(a5)
    80050186:	63ec                	ld	a1,192(a5)
    80050188:	1bd8                	addi	a4,sp,500
    8005018a:	074cfdf7          	.insn	4, 0x074cfdf7
    8005018e:	          	.insn	4, 0x3d59e3fb

0000000080050190 <d_4_23>:
    80050190:	3d59                	addiw	s10,s10,-10 # fffffffffffebff6 <_end+0xffffffff7ff8bdf6>
    80050192:	1f61                	addi	t5,t5,-8 # ffffffffffff3ff8 <_end+0xffffffff7ff93df8>
    80050194:	2ea6                	fld	ft9,72(sp)
    80050196:	52d5                	li	t0,-11
    80050198:	921d                	srli	a2,a2,0x27
    8005019a:	9c98                	.insn	2, 0x9c98
    8005019c:	439c99a3          	sh	s9,1075(s9)

00000000800501a0 <d_4_24>:
    800501a0:	3f56                	fld	ft10,368(sp)
    800501a2:	e160                	sd	s0,192(a0)
    800501a4:	71ff                	.insn	2, 0x71ff
    800501a6:	d5da                	sw	s6,232(sp)
    800501a8:	f536f72b          	.insn	4, 0xf536f72b
    800501ac:	0fb2                	slli	t6,t6,0xc
    800501ae:	8b39                	andi	a4,a4,14

00000000800501b0 <d_4_25>:
    800501b0:	8ad4                	.insn	2, 0x8ad4
    800501b2:	8464                	.insn	2, 0x8464
    800501b4:	918b9feb          	.insn	4, 0x918b9feb
    800501b8:	c2980577          	.insn	4, 0xc2980577
    800501bc:	136d                	addi	t1,t1,-5
    800501be:	aa70                	fsd	fa2,208(a2)

00000000800501c0 <d_4_26>:
    800501c0:	a674                	fsd	fa3,200(a2)
    800501c2:	d2fc                	sw	a5,100(a3)
    800501c4:	3aa2                	fld	fs5,40(sp)
    800501c6:	7170                	ld	a2,224(a0)
    800501c8:	9218eba7          	.insn	4, 0x9218eba7
    800501cc:	a281                	j	8005030c <_end_data4+0x10c>
    800501ce:	          	vluxseg2ei8.v	v20,(gp),v1

00000000800501d0 <d_4_27>:
    800501d0:	2611                	addiw	a2,a2,4
    800501d2:	bfda                	fsd	fs6,504(sp)
    800501d4:	17a8                	addi	a0,sp,1000
    800501d6:	12a2                	slli	t0,t0,0x28
    800501d8:	06b2                	slli	a3,a3,0xc
    800501da:	f6f8                	sd	a4,232(a3)
    800501dc:	313e                	fld	ft2,488(sp)
    800501de:	dd8c                	sw	a1,56(a1)
    800501e0:	a1fe                	fsd	ft11,192(sp)
    800501e2:	3bd0                	fld	fa2,176(a5)
    800501e4:	d798                	sw	a4,40(a5)
    800501e6:	ef11                	bnez	a4,80050202 <_end_data4+0x2>
    800501e8:	0431                	addi	s0,s0,12
    800501ea:	f82c                	sd	a1,112(s0)
    800501ec:	684d                	lui	a6,0x13
    800501ee:	d748                	sw	a0,44(a4)
    800501f0:	a2e94d57          	vsrl.vx	v26,v14,s2
    800501f4:	68c0b887          	fld	fa7,1676(ra)
    800501f8:	518c                	lw	a1,32(a1)
    800501fa:	aa68                	fsd	fa0,208(a2)
    800501fc:	be66                	fsd	fs9,312(sp)
    800501fe:	f60b                	.short	0xf60b

Disassembly of section .data.random5:

0000000080060000 <_random_data5>:
    80060000:	34ae                	fld	fs1,232(sp)
    80060002:	219f 69dd b562      	.insn	6, 0xb56269dd219f
    80060008:	55fc107b          	.insn	4, 0x55fc107b
    8006000c:	3658                	fld	fa4,168(a2)
    8006000e:	1351                	addi	t1,t1,-12
    80060010:	aac1                	j	800601e0 <d_5_27+0x10>
    80060012:	cbb49a9b          	.insn	4, 0xcbb49a9b
    80060016:	8346                	mv	t1,a7
    80060018:	6075                	c.lui	zero,0x1d
    8006001a:	9deecfe3          	blt	t4,t5,8005f9f8 <_end_data4+0xf7f8>
    8006001e:	b90c                	fsd	fa1,48(a0)

0000000080060020 <d_5_0>:
    80060020:	be66                	fsd	fs9,312(sp)
    80060022:	0776                	slli	a4,a4,0x1d
    80060024:	cb99                	beqz	a5,8006003a <d_5_1+0xa>
    80060026:	8552c22f          	.insn	4, 0x8552c22f
    8006002a:	844e                	mv	s0,s3
    8006002c:	3a45e2f7          	.insn	4, 0x3a45e2f7

0000000080060030 <d_5_1>:
    80060030:	a568                	fsd	fa0,200(a0)
    80060032:	4e66                	lw	t3,88(sp)
    80060034:	4d62                	lw	s10,24(sp)
    80060036:	2ec13433          	.insn	4, 0x2ec13433
    8006003a:	cac1ba5b          	.insn	4, 0xcac1ba5b
    8006003e:	b715                	j	8005ff62 <_end_data4+0xfd62>

0000000080060040 <d_5_2>:
    80060040:	965f 1cdb 36a9      	.insn	6, 0x36a91cdb965f
    80060046:	d6ca41d7          	.insn	4, 0xd6ca41d7
    8006004a:	5c4a785b          	.insn	4, 0x5c4a785b
    8006004e:	          	.insn	4, 0xeb91815b

0000000080060050 <d_5_3>:
    80060050:	eb91                	bnez	a5,80060064 <d_5_4+0x4>
    80060052:	daa40957          	.insn	4, 0xdaa40957
    80060056:	67c16fcf          	.insn	4, 0x67c16fcf
    8006005a:	0ff83b03          	ld	s6,255(a6) # 130ff <_start-0x7ffecf01>
    8006005e:	d7a2                	sw	s0,236(sp)

0000000080060060 <d_5_4>:
    80060060:	f872                	sd	t3,48(sp)
    80060062:	56e5d5fb          	.insn	4, 0x56e5d5fb
    80060066:	7e22                	ld	t3,40(sp)
    80060068:	39fc                	fld	fa5,240(a1)
    8006006a:	39b9                	addiw	s3,s3,-18
    8006006c:	4c41                	li	s8,16
    8006006e:	b558                	fsd	fa4,168(a0)

0000000080060070 <d_5_5>:
    80060070:	331e                	fld	ft6,480(sp)
    80060072:	6d114517          	auipc	a0,0x6d114
    80060076:	e13e                	sd	a5,128(sp)
    80060078:	03b5e1af          	.insn	4, 0x03b5e1af
    8006007c:	c310                	sw	a2,0(a4)
    8006007e:	c71d                	beqz	a4,800600ac <d_5_8+0xc>

0000000080060080 <d_5_6>:
    80060080:	a2ba                	fsd	fa4,320(sp)
    80060082:	f380                	sd	s0,32(a5)
    80060084:	17db1daf          	.insn	4, 0x17db1daf
    80060088:	5bc9                	li	s7,-14
    8006008a:	8de2                	mv	s11,s8
    8006008c:	246a                	fld	fs0,152(sp)
    8006008e:	6df6                	ld	s11,344(sp)

0000000080060090 <d_5_7>:
    80060090:	c35c0487          	.insn	4, 0xc35c0487
    80060094:	115d                	addi	sp,sp,-9
    80060096:	33a4                	fld	fs1,96(a5)
    80060098:	9852                	add	a6,a6,s4
    8006009a:	4a5e                	lw	s4,212(sp)
    8006009c:	55a98f4f          	.insn	4, 0x55a98f4f

00000000800600a0 <d_5_8>:
    800600a0:	3eab670f          	.insn	4, 0x3eab670f
    800600a4:	d75d                	beqz	a4,80060052 <d_5_3+0x2>
    800600a6:	1c31                	addi	s8,s8,-20 # fffffffffffecfec <_end+0xffffffff7ff8cdec>
    800600a8:	0b09                	addi	s6,s6,2
    800600aa:	756d                	lui	a0,0xffffb
    800600ac:	ded5                	beqz	a3,80060068 <d_5_4+0x8>
    800600ae:	1eda                	slli	t4,t4,0x36

00000000800600b0 <d_5_9>:
    800600b0:	b41f 07c8 95a7      	.insn	6, 0x95a707c8b41f
    800600b6:	0c0caf07          	flw	ft10,192(s9)
    800600ba:	563e                	lw	a2,236(sp)
    800600bc:	4665                	li	a2,25
    800600be:	f8ba                	sd	a4,112(sp)

00000000800600c0 <d_5_10>:
    800600c0:	c500                	sw	s0,8(a0)
    800600c2:	6b38                	ld	a4,80(a4)
    800600c4:	4920                	lw	s0,80(a0)
    800600c6:	a77f 9e73 971e 8857 	.insn	14, 0x2573c0beaad48857971e9e73a77f
    800600ce:	aad4   

00000000800600d0 <d_5_11>:
    800600d0:	c0be                	sw	a5,64(sp)
    800600d2:	b9352573          	csrrs	a0,mhpmcounter19h,a0
    800600d6:	60b2                	ld	ra,264(sp)
    800600d8:	21c1                	addiw	gp,gp,16
    800600da:	5dd444a7          	.insn	4, 0x5dd444a7
    800600de:	          	.insn	4, 0x76daacfb

00000000800600e0 <d_5_12>:
    800600e0:	76da                	ld	a3,432(sp)
    800600e2:	7c71                	lui	s8,0xffffc
    800600e4:	1a86                	slli	s5,s5,0x21
    800600e6:	a2ba                	fsd	fa4,320(sp)
    800600e8:	ab54                	fsd	fa3,144(a4)
    800600ea:	c769                	beqz	a4,800601b4 <d_5_25+0x4>
    800600ec:	052a                	slli	a0,a0,0xa
    800600ee:	          	.insn	4, 0x2d2817ab

00000000800600f0 <d_5_13>:
    800600f0:	2d28                	fld	fa0,88(a0)
    800600f2:	6b74                	ld	a3,208(a4)
    800600f4:	ef323b77          	.insn	4, 0xef323b77
    800600f8:	2271                	addiw	tp,tp,28 # 1c <_start-0x7fffffe4>
    800600fa:	40045d93          	srai	s11,s0,0x0
    800600fe:	4e5c                	lw	a5,28(a2)

0000000080060100 <d_5_14>:
    80060100:	ae50                	fsd	fa2,152(a2)
    80060102:	6a2d                	lui	s4,0xb
    80060104:	7059f98f          	.insn	4, 0x7059f98f
    80060108:	49e8                	lw	a0,84(a1)
    8006010a:	0bca                	slli	s7,s7,0x12
    8006010c:	9265                	srli	a2,a2,0x39
    8006010e:	          	.insn	4, 0x5f26842f

0000000080060110 <d_5_15>:
    80060110:	5f26                	lw	t5,104(sp)
    80060112:	c019                	beqz	s0,80060118 <d_5_15+0x8>
    80060114:	ad80                	fsd	fs0,24(a1)
    80060116:	90b381ef          	jal	gp,7ff98a20 <_start-0x675e0>
    8006011a:	b5b8                	fsd	fa4,104(a1)
    8006011c:	866c                	.insn	2, 0x866c
    8006011e:	7cec                	ld	a1,248(s1)

0000000080060120 <d_5_16>:
    80060120:	a2e6e633          	.insn	4, 0xa2e6e633
    80060124:	5bb4                	lw	a3,112(a5)
    80060126:	808e                	mv	ra,gp
    80060128:	b1f0                	fsd	fa2,224(a1)
    8006012a:	cab1                	beqz	a3,8006017e <d_5_21+0xe>
    8006012c:	a07c                	fsd	fa5,192(s0)
    8006012e:	          	.insn	4, 0x6c685fe7

0000000080060130 <d_5_17>:
    80060130:	6c68                	ld	a0,216(s0)
    80060132:	d5e70ba7          	.insn	4, 0xd5e70ba7
    80060136:	7af6                	ld	s5,376(sp)
    80060138:	fd54                	sd	a3,184(a0)
    8006013a:	22ad2b77          	.insn	4, 0x22ad2b77
    8006013e:	f44d                	bnez	s0,800600e8 <d_5_12+0x8>

0000000080060140 <d_5_18>:
    80060140:	91e4                	.insn	2, 0x91e4
    80060142:	52beee87          	.insn	4, 0x52beee87
    80060146:	7910                	ld	a2,48(a0)
    80060148:	260f6373          	csrrsi	t1,0x260,30
    8006014c:	2aa6                	fld	fs5,72(sp)
    8006014e:	fb8d                	bnez	a5,80060080 <d_5_6>

0000000080060150 <d_5_19>:
    80060150:	b9d9                	j	8005fe26 <_end_data4+0xfc26>
    80060152:	63b8                	ld	a4,64(a5)
    80060154:	5b55                	li	s6,-11
    80060156:	6c007847          	.insn	4, 0x6c007847
    8006015a:	e8e5                	bnez	s1,8006024a <_end+0x4a>
    8006015c:	fe42                	sd	a6,312(sp)
    8006015e:	b308                	fsd	fa0,32(a4)

0000000080060160 <d_5_20>:
    80060160:	bf76                	fsd	ft9,440(sp)
    80060162:	6e99                	lui	t4,0x6
    80060164:	0dc1                	addi	s11,s11,16
    80060166:	7888                	ld	a0,48(s1)
    80060168:	5d84                	lw	s1,56(a1)
    8006016a:	5899                	li	a7,-26
    8006016c:	dd84                	sw	s1,56(a1)
    8006016e:	6e94                	ld	a3,24(a3)

0000000080060170 <d_5_21>:
    80060170:	e8504d5b          	.insn	4, 0xe8504d5b
    80060174:	6eda                	ld	t4,400(sp)
    80060176:	3809                	addiw	a6,a6,-30
    80060178:	24f0                	fld	fa2,200(s1)
    8006017a:	cfdc0c67          	jalr	s8,-771(s8) # ffffffffffffbcfd <_end+0xffffffff7ff9bafd>
    8006017e:	          	andi	s11,a0,-1615

0000000080060180 <d_5_22>:
    80060180:	9b15                	andi	a4,a4,-27
    80060182:	3695d733          	.insn	4, 0x3695d733
    80060186:	34b42e2f          	.insn	4, 0x34b42e2f
    8006018a:	b56a                	fsd	fs10,168(sp)
    8006018c:	8ab5                	andi	a3,a3,13
    8006018e:	5f69                	li	t5,-6

0000000080060190 <d_5_23>:
    80060190:	e52bd927          	vsuxseg8ei16.v	v18,(s7),v18,v0.t
    80060194:	8aae                	mv	s5,a1
    80060196:	9f64202f          	.insn	4, 0x9f64202f
    8006019a:	4d12                	lw	s10,4(sp)
    8006019c:	9e76                	add	t3,t3,t4
    8006019e:	b3b1                	j	8005feea <_end_data4+0xfcea>

00000000800601a0 <d_5_24>:
    800601a0:	914c                	.insn	2, 0x914c
    800601a2:	b621                	j	8005fcaa <_end_data4+0xfaaa>
    800601a4:	8ced                	and	s1,s1,a1
    800601a6:	9418                	.insn	2, 0x9418
    800601a8:	fb9f 07d0 81ec      	.insn	6, 0x81ec07d0fb9f
    800601ae:	a208                	fsd	fa0,0(a2)

00000000800601b0 <d_5_25>:
    800601b0:	0ff2                	slli	t6,t6,0x1c
    800601b2:	ad2c                	fsd	fa1,88(a0)
    800601b4:	26ff 5380 48dd 5aa5 	.insn	14, 0x21d43db5bd135aa548dd538026ff
    800601bc:	bd13 3db5  

00000000800601c0 <d_5_26>:
    800601c0:	21d4                	fld	fa3,128(a1)
    800601c2:	02fd                	addi	t0,t0,31
    800601c4:	1e21                	addi	t3,t3,-24 # 7fe8 <_start-0x7fff8018>
    800601c6:	289d                	addiw	a7,a7,7
    800601c8:	b978                	fsd	fa4,240(a0)
    800601ca:	ed759483          	lh	s1,-297(a1) # ded7 <_start-0x7fff2129>
    800601ce:	          	vwadd.wx	v6,v12,a7,v0.t

00000000800601d0 <d_5_27>:
    800601d0:	d4c8                	sw	a0,44(s1)
    800601d2:	20f9                	addiw	ra,ra,30
    800601d4:	f629                	bnez	a2,8006011e <d_5_15+0xe>
    800601d6:	6f99                	lui	t6,0x6
    800601d8:	d696862f          	.insn	4, 0xd696862f
    800601dc:	19ebced3          	fdiv.s	ft9,fs7,ft10,rmm
    800601e0:	cb2e                	sw	a1,148(sp)
    800601e2:	bab6                	fsd	fa3,368(sp)
    800601e4:	cd51                	beqz	a0,80060280 <_end+0x80>
    800601e6:	fb1e                	sd	t2,432(sp)
    800601e8:	0e814ec3          	.insn	4, 0x0e814ec3
    800601ec:	8026fc53          	.insn	4, 0x8026fc53
    800601f0:	84ebb947          	.insn	4, 0x84ebb947
    800601f4:	6b79                	lui	s6,0x1e
    800601f6:	96d4                	.insn	2, 0x96d4
    800601f8:	fca2                	sd	s0,120(sp)
    800601fa:	d4c0                	sw	s0,44(s1)
    800601fc:	a561                	j	80060884 <_end+0x684>
    800601fe:	4753                	.short	0x4753

Disassembly of section .riscv.attributes:

0000000000000000 <.riscv.attributes>:
   0:	ee41                	bnez	a2,98 <_start-0x7fffff68>
   2:	0000                	unimp
   4:	7200                	ld	s0,32(a2)
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <_start-0x7fffffec>
   c:	00e4                	addi	s1,sp,76
   e:	0000                	unimp
  10:	7205                	lui	tp,0xfffe1
  12:	3676                	fld	fa2,376(sp)
  14:	6934                	ld	a3,80(a0)
  16:	7032                	.insn	2, 0x7032
  18:	5f31                	li	t5,-20
  1a:	326d                	addiw	tp,tp,-5 # fffffffffffe0ffb <_end+0xffffffff7ff80dfb>
  1c:	3070                	fld	fa2,224(s0)
  1e:	615f 7032 5f31      	.insn	6, 0x5f317032615f
  24:	3266                	fld	ft4,120(sp)
  26:	3270                	fld	fa2,224(a2)
  28:	645f 7032 5f32      	.insn	6, 0x5f327032645f
  2e:	30703263          	.insn	4, 0x30703263
  32:	765f 7031 5f30      	.insn	6, 0x5f307031765f
  38:	3168                	fld	fa0,224(a0)
  3a:	3070                	fld	fa2,224(s0)
  3c:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  42:	316d                	addiw	sp,sp,-5
  44:	3070                	fld	fa2,224(s0)
  46:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  4c:	3170                	fld	fa2,224(a0)
  4e:	3070                	fld	fa2,224(s0)
  50:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  56:	317a                	fld	ft2,440(sp)
  58:	3070                	fld	fa2,224(s0)
  5a:	7a5f 6369 7273      	.insn	6, 0x727363697a5f
  60:	7032                	.insn	2, 0x7032
  62:	5f30                	lw	a2,120(a4)
  64:	697a                	ld	s2,408(sp)
  66:	6566                	ld	a0,88(sp)
  68:	636e                	ld	t1,216(sp)
  6a:	6965                	lui	s2,0x19
  6c:	7032                	.insn	2, 0x7032
  6e:	5f30                	lw	a2,120(a4)
  70:	6d7a                	ld	s10,408(sp)
  72:	756d                	lui	a0,0xffffb
  74:	316c                	fld	fa1,224(a0)
  76:	3070                	fld	fa2,224(s0)
  78:	7a5f 6161 6f6d      	.insn	6, 0x6f6d61617a5f
  7e:	7031                	c.lui	zero,0xfffec
  80:	5f30                	lw	a2,120(a4)
  82:	617a                	ld	sp,408(sp)
  84:	726c                	ld	a1,224(a2)
  86:	70316373          	csrrsi	t1,0x703,2
  8a:	5f30                	lw	a2,120(a4)
  8c:	637a                	ld	t1,408(sp)
  8e:	3161                	addiw	sp,sp,-8
  90:	3070                	fld	fa2,224(s0)
  92:	7a5f 6463 7031      	.insn	6, 0x703164637a5f
  98:	5f30                	lw	a2,120(a4)
  9a:	767a                	ld	a2,440(sp)
  9c:	3365                	addiw	t1,t1,-7 # ffffffffffff9ff9 <_end+0xffffffff7ff99df9>
  9e:	6632                	ld	a2,264(sp)
  a0:	7031                	c.lui	zero,0xfffec
  a2:	5f30                	lw	a2,120(a4)
  a4:	767a                	ld	a2,440(sp)
  a6:	3365                	addiw	t1,t1,-7
  a8:	7832                	ld	a6,296(sp)
  aa:	7031                	c.lui	zero,0xfffec
  ac:	5f30                	lw	a2,120(a4)
  ae:	767a                	ld	a2,440(sp)
  b0:	3665                	addiw	a2,a2,-7
  b2:	6434                	ld	a3,72(s0)
  b4:	7031                	c.lui	zero,0xfffec
  b6:	5f30                	lw	a2,120(a4)
  b8:	767a                	ld	a2,440(sp)
  ba:	3665                	addiw	a2,a2,-7
  bc:	6634                	ld	a3,72(a2)
  be:	7031                	c.lui	zero,0xfffec
  c0:	5f30                	lw	a2,120(a4)
  c2:	767a                	ld	a2,440(sp)
  c4:	3665                	addiw	a2,a2,-7
  c6:	7834                	ld	a3,112(s0)
  c8:	7031                	c.lui	zero,0xfffec
  ca:	5f30                	lw	a2,120(a4)
  cc:	767a                	ld	a2,440(sp)
  ce:	316c                	fld	fa1,224(a0)
  d0:	3832                	fld	fa6,296(sp)
  d2:	3162                	fld	ft2,56(sp)
  d4:	3070                	fld	fa2,224(s0)
  d6:	7a5f 6c76 3233      	.insn	6, 0x32336c767a5f
  dc:	3162                	fld	ft2,56(sp)
  de:	3070                	fld	fa2,224(s0)
  e0:	7a5f 6c76 3436      	.insn	6, 0x34366c767a5f
  e6:	3162                	fld	ft2,56(sp)
  e8:	3070                	fld	fa2,224(s0)
  ea:	0800                	addi	s0,sp,16
  ec:	0a01                	addi	s4,s4,0 # b000 <_start-0x7fff5000>
  ee:	0b                	.byte	0x0b
