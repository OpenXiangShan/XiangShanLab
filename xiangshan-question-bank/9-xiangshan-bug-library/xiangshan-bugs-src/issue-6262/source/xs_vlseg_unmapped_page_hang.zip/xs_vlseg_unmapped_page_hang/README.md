# XS filing package — vlseg<nf> to unmapped page deadlocks (VSegmentUnit)

Paste `ISSUE.md` into the XS bug-report form
(https://github.com/OpenXiangShan/XiangShan/issues/new?template=1-bug_report.yaml).

Attach:
- `min_vlseg4.elf`  — minimal reproducer (vsetvli e32,m2; vlseg4e32.v to unmapped 0x40020). HANGS.
- `repro_vlseg2.elf` — second instance (vlseg2e32.v, nf=2) → same hang (shows vlseg<nf> scope).
- `repro_newtip_2b5769e.log` — reproduction on the latest mainline (XS 2b5769e8b2, tip-matching NEMU ref).

Evidence (context; not necessarily attached):
- `vcd_root_cause_vlseg4.txt` — VSegmentUnit FSM waveform: livelock re-walking TLB, page fault
  never raised (exceptionVec_13 / io_exceptionInfo_valid / io_uopwriteback_valid never assert).
- `vcd_sibling_vlseg2.txt` — same VCD signature for the nf=2 instance.

Do NOT attach any *.S from the harness (contains fuzz-template markers). The essential
4-instruction sequence is inlined in ISSUE.md; maintainers can run the attached .elf directly.

Decision still open for the filer: the AI-assistance checkbox (see the block at the end of ISSUE.md).
