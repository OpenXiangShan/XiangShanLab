#include <klib.h>

#define CSR_MSTATUS  0x300
#define CSR_MEDELEG  0x302
#define CSR_MIDELEG  0x303
#define CSR_MTVEC    0x305
#define CSR_MENVCFG  0x30a
#define CSR_MEPC     0x341
#define CSR_HSTATUS  0x600
#define CSR_HENVCFG  0x60a
#define CSR_HGATP    0x680
#define CSR_VSATP    0x280
#define CSR_VSSTATUS 0x200

#define BIT(n) (1UL << (n))

#define ENVCFG_DTE    BIT(59)  
#define SSTATUS_SDT   BIT(24)   
#define MSTATUS_MPV   BIT(39)
#define MSTATUS_MPP   (3UL << 11)
#define MSTATUS_MPP_U (0UL << 11)
#define MSTATUS_MIE   BIT(3)

volatile unsigned long return_to_mmode;

extern void m_trap_entry(void);
extern void vu_entry(void);

static void run_poc(void)
{
    unsigned long mstatus;

    asm volatile("csrw %0, %1" :: "i"(CSR_MTVEC), "r"((unsigned long)m_trap_entry) : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_MEDELEG) : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_MIDELEG) : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_HGATP)   : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_VSATP)   : "memory");
    asm volatile("csrw %0, zero" :: "i"(CSR_HSTATUS) : "memory");

    asm volatile("csrs %0, %1" :: "i"(CSR_MENVCFG), "r"(ENVCFG_DTE) : "memory");
    asm volatile("csrs %0, %1" :: "i"(CSR_HENVCFG), "r"(ENVCFG_DTE) : "memory");

    asm volatile("csrs %0, %1" :: "i"(CSR_VSSTATUS), "r"(SSTATUS_SDT) : "memory");

    asm volatile("csrr %0, %1" : "=r"(mstatus) : "i"(CSR_MSTATUS));
    mstatus &= ~MSTATUS_MPP;
    mstatus |= MSTATUS_MPP_U;
    mstatus |= MSTATUS_MPV;
    mstatus &= ~MSTATUS_MIE;
    asm volatile("csrw %0, %1" :: "i"(CSR_MSTATUS), "r"(mstatus) : "memory");

    asm volatile("csrw %0, %1" :: "i"(CSR_MEPC), "r"((unsigned long)vu_entry) : "memory");
    asm volatile("la %0, 1f" : "=r"(return_to_mmode));
    asm volatile("mret\n1:" ::: "memory");
}

int main(void)
{
    run_poc();
    return 0;
}
