#!/usr/bin/env python3
import argparse
import json
import re
import sys


TARGET_LOAD_VADDR = 0x800000D0
TARGET_LOAD_PADDR_WORD = TARGET_LOAD_VADDR >> 4
EXPECTED = 0xAABBCCDD11223344
BAD_LOW_ONLY = 0xDEADBEEF11223344


VAR_RE = re.compile(r"\s*\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
SCOPE_RE = re.compile(r"\s*\$scope\s+\S+\s+(\S+)\s+\$end")


def parse_int(bits):
    if bits is None:
        return None
    bits = bits.strip()
    if not bits:
        return None
    if any(c in bits.lower() for c in "xz"):
        return None
    return int(bits, 2)


def norm_scalar(v):
    if v in ("0", "1"):
        return int(v)
    return None


def collect_header(path):
    id_to_names = {}
    name_to_id = {}
    widths = {}
    scope = []
    with open(path, "rt", errors="replace") as f:
        for line in f:
            if line.lstrip().startswith("$enddefinitions"):
                break
            m = SCOPE_RE.match(line)
            if m:
                scope.append(m.group(1))
                continue
            if line.lstrip().startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            m = VAR_RE.match(line)
            if not m:
                continue
            width = int(m.group(1))
            sid = m.group(2)
            raw_name = m.group(3).strip()
            name = raw_name.split()[0]
            full = ".".join(scope + [name])
            id_to_names.setdefault(sid, []).append(full)
            name_to_id.setdefault(full, sid)
            widths[sid] = max(widths.get(sid, 0), width)
    return id_to_names, name_to_id, widths


def find_unique(name_to_id, suffix):
    matches = [(name, sid) for name, sid in name_to_id.items() if name.endswith(suffix)]
    if not matches:
        return None
    # Prefer the deepest scoped match; aliases share the same id anyway.
    matches.sort(key=lambda x: (x[0].count("."), len(x[0])), reverse=True)
    return matches[0]


def find_port_signals(name_to_id):
    ports = []
    for idx in range(3):
        required = {
            "s0_valid": f"io_sqForward_s0Req_valid" if idx == 0 else f"io_sqForward_{idx}_s0Req_valid",
        }
        # The RTL scopes expose each load unit as simple signal names. Use the
        # internal StoreQueue suffixes with per-port suffixes for ports 1 and 2.
        suf = "" if idx == 0 else f"_{idx}"
        sigs = {
            "s0_valid": f"_inner_lsq_io_forward_{idx}_s0Req_valid",
            "s0_vaddr": f"_inner_lsq_io_forward_{idx}_s0Req_bits_vaddr",
            "s2_resp_valid": f"_inner_lsq_io_forward_{idx}_s2Resp_valid",
            "s2_forward_invalid": f"_inner_lsq_io_forward_{idx}_s2Resp_bits_forwardInvalid",
            "s2_match_invalid": f"_inner_lsq_io_forward_{idx}_s2Resp_bits_matchInvalid",
            "s2_valid": f"s2Valid{suf}",
            "s1_multi": f"s1MultiMatch{suf}",
            "s2_multi": f"s2MultiMatch{suf}",
            "s2_forward_valid": f"s2ForwardValid{suf}",
            "s2_out_mask": f"s2OutMask{suf}",
            "s2_safe_forward": f"s2SafeForward{suf}",
            "s2_load_mask": f"s2LoadMaskEnd{suf}",
            "s2_load_paddr": f"s2LoadPaddr{suf}",
            "s2_load_start": f"s2LoadStart{suf}",
            "s2_final_mask": f"s2FinalMask{suf}",
            "s2_select_oh": f"s2SelectOH{suf}",
        }
        found = {}
        for key, suffix in sigs.items():
            item = find_unique(name_to_id, suffix)
            if item is not None:
                found[key] = {"path": item[0], "id": item[1]}
        mask_ids = []
        data_ids = []
        for bit in range(16):
            item = find_unique(name_to_id, f"_inner_lsq_io_forward_{idx}_s2Resp_bits_forwardMask_{bit}")
            if item is not None:
                mask_ids.append((bit, item[0], item[1]))
            item = find_unique(name_to_id, f"_inner_lsq_io_forward_{idx}_s2Resp_bits_forwardData_{bit}")
            if item is not None:
                data_ids.append((bit, item[0], item[1]))
        found["boundary_mask_bits"] = mask_ids
        found["boundary_data_bytes"] = data_ids
        # The boundary SQ request/response aliases are common for the selected
        # load-unit scope; still record one logical port per internal suffix.
        if all(k in found for k in ("s2_valid", "s2_resp_valid", "s1_multi", "s2_multi", "s2_forward_valid", "s2_out_mask", "s2_safe_forward", "s2_load_mask", "s2_load_paddr", "s2_load_start")):
            ports.append({"port": idx, "signals": found})
    return ports


def find_writeback_signals(name_to_id):
    ports = []
    for idx in range(5):
        sigs = {
            "rf_valid": f"io_mem_intWriteback_{idx}_0_toIntRf_valid",
            "rf_data": f"io_mem_intWriteback_{idx}_0_toIntRf_bits_data",
            "rob_paddr": f"io_mem_intWriteback_{idx}_0_toRob_bits_debugInfo_paddr",
            "rob_vaddr": f"io_mem_intWriteback_{idx}_0_toRob_bits_debugInfo_vaddr",
        }
        found = {}
        for key, suffix in sigs.items():
            item = find_unique(name_to_id, suffix)
            if item is not None:
                found[key] = {"path": item[0], "id": item[1]}
        if all(k in found for k in sigs):
            ports.append({"port": idx, "signals": found})
    return ports


def get(vals, sig):
    if not sig or "id" not in sig:
        return None
    return vals.get(sig["id"])


def assemble_bits(vals, bit_entries):
    mask = 0
    for bit, _path, sid in bit_entries:
        val = vals.get(sid)
        if val == "1" or val == 1:
            mask |= 1 << bit
    return mask


def assemble_bytes(vals, byte_entries):
    data = 0
    known = 0
    for byte, _path, sid in byte_entries:
        val = vals.get(sid)
        if isinstance(val, str):
            iv = parse_int(val)
        else:
            iv = val
        if iv is None:
            continue
        data |= (iv & 0xFF) << (8 * byte)
        known |= 1 << byte
    return data, known


def scan(path, ports, wb_ports):
    tracked = set()
    for p in ports:
        for key, info in p["signals"].items():
            if isinstance(info, dict):
                tracked.add(info["id"])
            elif isinstance(info, list):
                for _bit, _name, sid in info:
                    tracked.add(sid)
    for p in wb_ports:
        for info in p["signals"].values():
            tracked.add(info["id"])

    vals = {}
    time = None
    events = []
    valid_events = []
    wb_events = []
    predicate = None

    def evaluate():
        nonlocal predicate
        if time is None:
            return
        for p in ports:
            sigs = p["signals"]
            s2_valid = get(vals, sigs["s2_valid"])
            s2_resp_valid = get(vals, sigs["s2_resp_valid"])
            s0_vaddr = get(vals, sigs.get("s0_vaddr", {}))
            if isinstance(s0_vaddr, str):
                s0_vaddr_i = parse_int(s0_vaddr)
            else:
                s0_vaddr_i = s0_vaddr
            mask = assemble_bits(vals, sigs.get("boundary_mask_bits", []))
            data, known = assemble_bytes(vals, sigs.get("boundary_data_bytes", []))
            entry = {
                "time": time,
                "port": p["port"],
                "s0_vaddr": s0_vaddr_i,
                "s2_valid": s2_valid,
                "s2_resp_valid": s2_resp_valid,
                "s1_multi": get(vals, sigs["s1_multi"]),
                "s2_multi": get(vals, sigs["s2_multi"]),
                "s2_forward_valid": get(vals, sigs["s2_forward_valid"]),
                "s2_out_mask": parse_int(get(vals, sigs["s2_out_mask"])) if isinstance(get(vals, sigs["s2_out_mask"]), str) else get(vals, sigs["s2_out_mask"]),
                "s2_safe_forward": get(vals, sigs["s2_safe_forward"]),
                "s2_load_mask": parse_int(get(vals, sigs["s2_load_mask"])) if isinstance(get(vals, sigs["s2_load_mask"]), str) else get(vals, sigs["s2_load_mask"]),
                "s2_load_paddr": parse_int(get(vals, sigs["s2_load_paddr"])) if isinstance(get(vals, sigs["s2_load_paddr"]), str) else get(vals, sigs["s2_load_paddr"]),
                "s2_load_start": parse_int(get(vals, sigs["s2_load_start"])) if isinstance(get(vals, sigs["s2_load_start"]), str) else get(vals, sigs["s2_load_start"]),
                "s2_final_mask": parse_int(get(vals, sigs["s2_final_mask"])) if "s2_final_mask" in sigs and isinstance(get(vals, sigs["s2_final_mask"]), str) else (get(vals, sigs["s2_final_mask"]) if "s2_final_mask" in sigs else None),
                "forward_invalid": get(vals, sigs.get("s2_forward_invalid", {})),
                "match_invalid": get(vals, sigs.get("s2_match_invalid", {})),
                "boundary_mask": mask,
                "boundary_data": data,
                "boundary_data_known_mask": known,
            }
            target_paddr = entry["s2_load_paddr"] in (TARGET_LOAD_PADDR_WORD, TARGET_LOAD_PADDR_WORD & ((1 << 44) - 1), TARGET_LOAD_PADDR_WORD & 0x7fffffff)
            interesting_addr = s0_vaddr_i == TARGET_LOAD_VADDR or (target_paddr and entry["s2_load_start"] == 0)
            interesting_forward = s2_valid == 1 and entry["s2_forward_valid"] == 1
            if s2_valid == 1 or interesting_addr or interesting_forward:
                if not events or events[-1] != entry:
                    events.append(entry)
                    if len(events) > 200:
                        del events[0]
            if s2_valid == 1:
                valid_events.append(entry)
                if len(valid_events) > 500:
                    del valid_events[0]
            bad_mask = entry["s2_load_mask"] == 0xFF and entry["s2_out_mask"] in (0x0F, 0xF)
            bad_forward = (
                s2_valid == 1
                and s2_resp_valid == 1
                and entry["s2_forward_valid"] == 1
                and entry["s2_multi"] == 1
                and entry["s2_safe_forward"] == 1
                and entry["forward_invalid"] == 0
                and bad_mask
                and entry["s2_load_start"] == 0
                and target_paddr
            )
            if bad_forward and predicate is None:
                predicate = dict(entry)
        for p in wb_ports:
            sigs = p["signals"]
            if get(vals, sigs["rf_valid"]) != 1:
                continue
            vaddr = get(vals, sigs["rob_vaddr"])
            data = get(vals, sigs["rf_data"])
            paddr = get(vals, sigs["rob_paddr"])
            vaddr_i = parse_int(vaddr) if isinstance(vaddr, str) else vaddr
            data_i = parse_int(data) if isinstance(data, str) else data
            paddr_i = parse_int(paddr) if isinstance(paddr, str) else paddr
            if vaddr_i == TARGET_LOAD_VADDR or data_i in (EXPECTED, BAD_LOW_ONLY):
                wb_events.append({
                    "time": time,
                    "port": p["port"],
                    "vaddr": vaddr_i,
                    "paddr": paddr_i,
                    "data": data_i,
                })
                if len(wb_events) > 40:
                    del wb_events[0]

    with open(path, "rt", errors="replace") as f:
        in_dump = False
        for line in f:
            if not in_dump:
                if line.lstrip().startswith("$enddefinitions"):
                    in_dump = True
                continue
            if not line:
                continue
            c = line[0]
            if c == "#":
                evaluate()
                try:
                    time = int(line[1:])
                except ValueError:
                    time = None
                continue
            if c in "01xz":
                sid = line[1:].strip()
                if sid in tracked:
                    vals[sid] = norm_scalar(c) if c in "01" else c
                continue
            if c == "b":
                try:
                    bits, sid = line[1:].strip().split(None, 1)
                except ValueError:
                    continue
                sid = sid.strip()
                if sid in tracked:
                    vals[sid] = bits
    evaluate()
    return predicate, events, valid_events, wb_events


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("vcd")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--json-out")
    args = ap.parse_args()

    id_to_names, name_to_id, _widths = collect_header(args.vcd)
    ports = find_port_signals(name_to_id)
    wb_ports = find_writeback_signals(name_to_id)

    if args.list:
        print(json.dumps({"sq_ports": ports, "writeback_ports": wb_ports}, indent=2, sort_keys=True))
        return 0

    predicate, events, valid_events, wb_events = scan(args.vcd, ports, wb_ports)
    bad_writebacks = [
        e for e in wb_events
        if e.get("vaddr") == TARGET_LOAD_VADDR and e.get("data") == BAD_LOW_ONLY
    ]
    good_writebacks = [
        e for e in wb_events
        if e.get("vaddr") == TARGET_LOAD_VADDR and e.get("data") == EXPECTED
    ]
    reproduced = bool(predicate and bad_writebacks and not good_writebacks)
    result = {
        "target_load_vaddr": TARGET_LOAD_VADDR,
        "target_load_paddr_word": TARGET_LOAD_PADDR_WORD,
        "expected_load_data": EXPECTED,
        "bad_low_only_data": BAD_LOW_ONLY,
        "sq_ports": ports,
        "writeback_ports": wb_ports,
        "predicate_result": "reproduced" if reproduced else "not_reproduced",
        "predicate_event": predicate,
        "bad_writebacks": bad_writebacks,
        "good_writebacks": good_writebacks,
        "recent_sq_events": events,
        "valid_sq_events": valid_events,
        "writeback_events": wb_events,
        "success_predicate": "bad SQ event (s2Valid && s2ForwardValid && s2MultiMatch && s2SafeForward && !forwardInvalid && s2LoadMaskEnd==0x00ff && s2OutMask==0x000f for paddr_word 0x800000d) followed by target load writeback data 0xdeadbeef11223344 and no writeback of expected 0xaabbccdd11223344",
    }
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json_out:
        with open(args.json_out, "w") as f:
            f.write(text)
            f.write("\n")
    return 0 if reproduced else 2


if __name__ == "__main__":
    sys.exit(main())
