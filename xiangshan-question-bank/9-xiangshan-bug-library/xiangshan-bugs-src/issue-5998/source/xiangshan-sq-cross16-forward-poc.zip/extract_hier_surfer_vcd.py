#!/usr/bin/env python3
import argparse
import re
import string


VAR_RE = re.compile(r"\s*\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
SCOPE_RE = re.compile(r"\s*\$scope\s+\S+\s+(\S+)\s+\$end")


SIGNAL_SUFFIXES = [
    "s2Valid",
    "_inner_lsq_io_forward_0_s2Resp_valid",
    "s2ForwardValid",
    "s1MultiMatch",
    "s2MultiMatch",
    "s2SafeForward",
    "s2LoadMaskEnd",
    "s2OutMask",
    "s2FinalMask",
    "s2LoadPaddr",
    "s2LoadStart",
    "_inner_lsq_io_forward_0_s2Resp_bits_forwardInvalid",
    "_inner_lsq_io_forward_0_s2Resp_bits_matchInvalid",
    "io_mem_intWriteback_0_0_toIntRf_valid",
    "io_mem_intWriteback_0_0_toIntRf_bits_pdest",
    "io_mem_intWriteback_0_0_toIntRf_bits_data",
    "io_mem_intWriteback_0_0_toIntRf_bits_isFromLoadUnit",
    "io_mem_intWriteback_0_0_toRob_bits_debugInfo_vaddr",
    "io_mem_intWriteback_0_0_toRob_bits_debugInfo_paddr",
]


def short_ids():
    chars = string.ascii_letters + string.digits + "!#$%&()*+,-./:;<=>?@[]^_{}~"
    for ch in chars:
        yield ch
    for a in chars:
        for b in chars:
            yield a + b


def collect_header(path):
    timescale = "$timescale 1ps $end"
    name_to_id = {}
    widths = {}
    scope = []
    with open(path, "rt", errors="replace") as f:
        for line in f:
            if line.lstrip().startswith("$timescale"):
                parts = [line.rstrip()]
                if "$end" not in line:
                    for tline in f:
                        parts.append(tline.rstrip())
                        if "$end" in tline:
                            break
                timescale = " ".join(p.strip() for p in parts)
                continue
            if line.lstrip().startswith("$enddefinitions"):
                break
            m = SCOPE_RE.match(line)
            if m:
                scope.append(m.group(1))
                continue
            if line.lstrip().startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            m = VAR_RE.match(line)
            if not m:
                continue
            width = int(m.group(1))
            sid = m.group(2)
            raw_name = m.group(3).strip()
            name = raw_name.split()[0]
            full = ".".join(scope + [name])
            name_to_id.setdefault(full, sid)
            widths[sid] = max(widths.get(sid, 0), width)
    return timescale, name_to_id, widths


def find_unique(name_to_id, suffix):
    matches = [(name, sid) for name, sid in name_to_id.items() if name.endswith(suffix)]
    if not matches:
        return None
    matches.sort(key=lambda x: (x[0].count("."), len(x[0])), reverse=True)
    return matches[0]


def parse_value_line(line):
    if not line:
        return None, None
    c = line[0]
    if c in "01xz":
        return line[1:].strip(), c
    if c == "b":
        try:
            bits, sid = line[1:].strip().split(None, 1)
        except ValueError:
            return None, None
        return sid.strip(), "b" + bits
    return None, None


def dump_value(out, value, new_id, width):
    if value is None:
        return
    if width == 1 and value in "01xz":
        out.write(f"{value}{new_id}\n")
    elif value.startswith("b"):
        out.write(f"{value} {new_id}\n")
    else:
        out.write(f"b{value} {new_id}\n")


def add_to_tree(tree, path_parts, sig):
    node = tree
    for part in path_parts[:-1]:
        node = node.setdefault(part, {"children": {}, "signals": []})["children"]
    parent = tree
    for part in path_parts[:-1]:
        parent = parent[part]["children"]
    parent.setdefault("__signals__", {"children": {}, "signals": []})["signals"].append(sig)


def write_scope(out, name, node, indent=""):
    if name != "__root__":
        out.write(f"{indent}$scope module {name} $end\n")
        indent += " "
    for sig in node.get("signals", []):
        out.write(f"{indent}$var wire {sig['width']} {sig['new_id']} {sig['name']} $end\n")
    for child_name, child in node.get("children", {}).items():
        write_scope(out, child_name, child, indent)
    if name != "__root__":
        out.write(f"{indent[:-1]}$upscope $end\n")


def build_scope_tree(selected):
    root = {"children": {}, "signals": []}
    for sig in selected:
        parts = sig["path"].split(".")
        node = root
        for part in parts[:-1]:
            node = node["children"].setdefault(part, {"children": {}, "signals": []})
        node["signals"].append(sig)
    return root


def extract(src, dst, start, end):
    timescale, name_to_id, widths = collect_header(src)
    ids = short_ids()
    id_to_new = {}
    selected = []
    for suffix in SIGNAL_SUFFIXES:
        found = find_unique(name_to_id, suffix)
        if not found:
            continue
        path, old_id = found
        if old_id not in id_to_new:
            id_to_new[old_id] = next(ids)
        selected.append({
            "path": path,
            "name": path.split(".")[-1],
            "old_id": old_id,
            "new_id": id_to_new[old_id],
            "width": widths.get(old_id, 1),
        })

    old_to_sig = {}
    for sig in selected:
        old_to_sig.setdefault(sig["old_id"], sig)

    start_values = {}
    events = []
    cur_time = 0
    with open(src, "rt", errors="replace") as f:
        in_dump = False
        for line in f:
            if not in_dump:
                if line.lstrip().startswith("$enddefinitions"):
                    in_dump = True
                continue
            if line.startswith("#"):
                try:
                    cur_time = int(line[1:])
                except ValueError:
                    cur_time = 0
                if cur_time > end:
                    break
                continue
            old_id, value = parse_value_line(line.strip())
            if old_id not in old_to_sig:
                continue
            if cur_time <= start:
                start_values[old_id] = value
            if start <= cur_time <= end:
                events.append((cur_time, old_id, value))

    with open(dst, "wt") as out:
        out.write("$date\n  hierarchy-preserving extraction for XiangShan cross16 SQ repro\n$end\n")
        out.write("$version\n  extract_hier_surfer_vcd.py\n$end\n")
        out.write(timescale + "\n")
        write_scope(out, "__root__", build_scope_tree(selected))
        out.write("$enddefinitions $end\n")
        out.write(f"#{start}\n")
        out.write("$dumpvars\n")
        dumped = set()
        for sig in selected:
            if sig["old_id"] in dumped:
                continue
            dumped.add(sig["old_id"])
            dump_value(out, start_values.get(sig["old_id"]), sig["new_id"], sig["width"])
        out.write("$end\n")

        last_time = start
        for time, old_id, value in events:
            if time != last_time:
                out.write(f"#{time}\n")
                last_time = time
            sig = old_to_sig[old_id]
            dump_value(out, value, sig["new_id"], sig["width"])
        out.write(f"#{end}\n")

    return selected


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--start", type=int, default=16740)
    ap.add_argument("--end", type=int, default=16770)
    args = ap.parse_args()
    selected = extract(args.src, args.dst, args.start, args.end)
    print(f"wrote {args.dst}")
    print(f"window {args.start}..{args.end}, signals {len(selected)}")
    for sig in selected:
        print(sig["path"])


if __name__ == "__main__":
    main()
