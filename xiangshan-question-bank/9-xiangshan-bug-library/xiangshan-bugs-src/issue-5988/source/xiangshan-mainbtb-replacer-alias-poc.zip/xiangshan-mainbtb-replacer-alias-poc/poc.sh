#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
BUGDIR="$ROOT/bug/2026-05-11-mainbtb-replacer-set-alias-runtime"
OUTDIR="$BUGDIR/out"
ASM_SRC="${ASM_SRC:-$BUGDIR/branch_alias_sequence.S}"
XS_HOME="${XS_HOME:-$ROOT/XiangShan}"
if [[ -z "${EMU:-}" ]]; then
  if [[ -x "$XS_HOME/build/emu" ]]; then
    EMU="$XS_HOME/build/emu"
  elif [[ -x "$XS_HOME/build/verilator-compile/emu" ]]; then
    EMU="$XS_HOME/build/verilator-compile/emu"
  else
    EMU="$XS_HOME/build/emu"
  fi
fi
SIM_CYCLES="${SIM_CYCLES:-10000}"
SIM_TIMEOUT="${SIM_TIMEOUT:-90s}"

usage() {
  cat <<USAGE
Usage:
  bash $0
  EMU=/path/to/xiangshan/emu bash $0

Reproduction method:
  1. Compile the standalone branch sequence:
       $ASM_SRC
  2. Link A-sites at 0x80010000/0x80020000/0x80030000/0x80040000.
  3. Link B-sites at 0x80014000/0x80024000/0x80034000/0x80044000.
  4. Prove statically that A1 and B1 have different MainBTB setIdx but the same replacerSetIdx.
  5. Run stock XiangShan emu and check native MainBTB allocate evidence.

Environment overrides:
  ASM_SRC     Assembly sequence source. Default: $ASM_SRC
  XS_HOME     XiangShan checkout. Default: $XS_HOME
  EMU         XiangShan emulator. Default auto-detects build/emu or build/verilator-compile/emu.
  SIM_CYCLES  Max emu cycles. Default: $SIM_CYCLES
  SIM_TIMEOUT Timeout for emu run. Default: $SIM_TIMEOUT
USAGE
}

case "${1:-}" in
  -h|--help)
    usage
    exit 0
    ;;
  "")
    ;;
  *)
    echo "[-] unknown argument: $1" >&2
    usage >&2
    exit 2
    ;;
esac

mkdir -p "$OUTDIR"

export PATH="/opt/riscv/bin:/usr/lib/llvm-18/bin:$PATH"

need_tool() {
  local tool=$1
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "[-] missing tool: $tool" >&2
    exit 1
  fi
}

need_tool riscv64-unknown-elf-gcc
need_tool riscv64-unknown-elf-objcopy
need_tool riscv64-unknown-elf-objdump
need_tool riscv64-unknown-elf-nm
need_tool rg
need_tool timeout

LDS="$OUTDIR/poc.ld"
ELF="$OUTDIR/poc.elf"
BIN="$OUTDIR/poc.bin"
DISASM="$OUTDIR/poc.txt"
SYMS="$OUTDIR/symbols.txt"
STATIC="$OUTDIR/static_proof.txt"
EMU_LOG="$OUTDIR/emu_run.txt"
VERDICT="$OUTDIR/verdict.txt"

if [[ ! -f "$ASM_SRC" ]]; then
  echo "[-] missing assembly sequence: $ASM_SRC" >&2
  exit 1
fi

cat > "$LDS" <<'LD'
ENTRY(_start)

MEMORY {
  ram (rwx) : ORIGIN = 0x80000000, LENGTH = 1024M
}

SECTIONS {
  .text.entry 0x80000000 : { *(.text.entry) }

  .text.a1 0x80010000 : { *(.text.a1) }
  .text.a2 0x80020000 : { *(.text.a2) }
  .text.a3 0x80030000 : { *(.text.a3) }
  .text.a4 0x80040000 : { *(.text.a4) }

  .text.b1 0x80014000 : { *(.text.b1) }
  .text.b2 0x80024000 : { *(.text.b2) }
  .text.b3 0x80034000 : { *(.text.b3) }
  .text.b4 0x80044000 : { *(.text.b4) }

  .rodata : { *(.rodata*) }
  .data : { *(.data*) }
  .bss 0x80080000 (NOLOAD) : ALIGN(16) { *(.bss*) *(.sbss*) *(COMMON) }
}
LD

riscv64-unknown-elf-gcc \
  -march=rv64gc \
  -mabi=lp64d \
  -mcmodel=medany \
  -nostdlib \
  -static \
  -Wl,--build-id=none \
  -Wl,--gc-sections \
  -Wl,-T,"$LDS" \
  -o "$ELF" \
  "$ASM_SRC"

riscv64-unknown-elf-objcopy -O binary "$ELF" "$BIN"
riscv64-unknown-elf-objdump -d "$ELF" > "$DISASM"
riscv64-unknown-elf-nm -n "$ELF" > "$SYMS"

labels=(site_A1 site_A2 site_A3 site_A4 site_B1 site_B2 site_B3 site_B4)
{
  echo "Current-source MainBTB index math:"
  echo "  FetchBlockSizeWidth    = 6"
  echo "  FetchBlockAlignWidth   = 5"
  echo "  AlignBankIdxLen        = 1"
  echo "  InternalBankIdxLen     = 2"
  echo "  SetIdxLen              = 8"
  echo "  setIdx                 = addr[15:8]"
  echo "  replacerSetIdx         = addr[13:6]"
  echo
  printf "%-8s %-12s %-10s %-16s\n" "label" "addr" "setIdx" "replacerSetIdx"
  for label in "${labels[@]}"; do
    addr_hex=$(awk -v s="$label" '$3 == s { print $1 }' "$SYMS")
    if [[ -z "$addr_hex" ]]; then
      echo "missing symbol: $label" >&2
      exit 1
    fi
    addr=$((16#$addr_hex))
    set_idx=$(((addr >> 8) & 0xff))
    replacer_idx=$(((addr >> 6) & 0xff))
    printf "%-8s 0x%08x 0x%02x       0x%02x\n" "$label" "$addr" "$set_idx" "$replacer_idx"
  done
} > "$STATIC"

A1_SET=$(awk '$1 == "site_A1" { print $3 }' "$STATIC")
B1_SET=$(awk '$1 == "site_B1" { print $3 }' "$STATIC")
A1_REPL=$(awk '$1 == "site_A1" { print $4 }' "$STATIC")
B1_REPL=$(awk '$1 == "site_B1" { print $4 }' "$STATIC")

if [[ "$A1_SET" == "$B1_SET" || "$A1_REPL" != "$B1_REPL" ]]; then
  echo "[-] expected alias pattern not found in built PoC" >&2
  cat "$STATIC" >&2
  exit 1
fi

echo "Reproduction method:"
echo "  sequence: $ASM_SRC"
echo "  linker:   $LDS"
echo "  binary:   $BIN"
echo "  emu:      $EMU"
echo "  cycles:   $SIM_CYCLES"
echo

echo "[1/2] Static alias proof"
cat "$STATIC"
echo

if [[ ! -x "$EMU" ]]; then
  {
    echo "site_A1_setIdx=$A1_SET"
    echo "site_B1_setIdx=$B1_SET"
    echo "site_A1_replacerSetIdx=$A1_REPL"
    echo "site_B1_replacerSetIdx=$B1_REPL"
    echo "asm_source=$ASM_SRC"
    echo "cpu_runtime_status=skipped_missing_emu"
    echo "emu_path=$EMU"
  } | tee "$VERDICT"
  echo "[-] missing executable emulator: $EMU" >&2
  echo "[-] Static reproduction succeeded; CPU runtime proof needs a built XiangShan emu." >&2
  exit 2
fi

echo "[2/2] CPU runtime on XiangShan emu"
set +e
timeout "$SIM_TIMEOUT" "$EMU" -i "$BIN" --no-diff -C "$SIM_CYCLES" > "$EMU_LOG" 2>&1
EMU_RC=$?
set -e

if [[ "$EMU_RC" -ne 0 ]]; then
  echo "[-] emu run failed with status $EMU_RC" >&2
  tail -n 80 "$EMU_LOG" >&2 || true
  exit 1
fi

GOOD_TRAP=0
INSTR_COUNT_SEEN=0
IMAGE_LOADED=0
GUEST_CYCLE_SEEN=0
MBTB_ALLOC=0

if rg -q "HIT GOOD TRAP|EXITING WITH CODE 0|trapCode: 0" "$EMU_LOG"; then
  GOOD_TRAP=1
fi
if rg -q "Core-0 instrCnt = [1-9][0-9]*" "$EMU_LOG"; then
  INSTR_COUNT_SEEN=1
fi
if rg -q "The image is $BIN" "$EMU_LOG"; then
  IMAGE_LOADED=1
fi
if rg -q "Guest cycle spent: [1-9][0-9]*" "$EMU_LOG"; then
  GUEST_CYCLE_SEEN=1
fi
if rg -q "bpu\\.mbtb\\.alignBanks_[0-9]+: _allocate,\\s+[1-9][0-9]*" "$EMU_LOG"; then
  MBTB_ALLOC=1
fi

{
  echo "site_A1_setIdx=$A1_SET"
  echo "site_B1_setIdx=$B1_SET"
  echo "site_A1_replacerSetIdx=$A1_REPL"
  echo "site_B1_replacerSetIdx=$B1_REPL"
  echo "asm_source=$ASM_SRC"
  echo "sim_cycles=$SIM_CYCLES"
  echo "cpu_image_loaded=$IMAGE_LOADED"
  echo "cpu_guest_cycle_seen=$GUEST_CYCLE_SEEN"
  echo "cpu_instr_count_seen=$INSTR_COUNT_SEEN"
  echo "cpu_good_trap=$GOOD_TRAP"
  echo "cpu_mbtb_allocate_seen=$MBTB_ALLOC"
} | tee "$VERDICT"

if [[ "$IMAGE_LOADED" -ne 1 || "$GUEST_CYCLE_SEEN" -ne 1 ]]; then
  echo "[-] stock emu did not report loading/running the generated image" >&2
  rg "The image is|Guest cycle spent|HIT GOOD TRAP|Core-0 instrCnt|bpu\\.mbtb\\.alignBanks_[0-9]+: _allocate" "$EMU_LOG" >&2 || true
  exit 1
fi

if [[ "$MBTB_ALLOC" -ne 1 ]]; then
  echo "[-] stock emu ran the generated image, but native MainBTB allocate counter was not observed." >&2
  rg "The image is|Guest cycle spent|HIT GOOD TRAP|Core-0 instrCnt|bpu\\.mbtb\\.alignBanks_[0-9]+: _allocate" "$EMU_LOG" >&2 || true
  exit 1
fi

echo "[+] FINAL: CPU-executable branch PCs in this PoC hit different MainBTB physical sets but the same replacerSetIdx."
echo "[+] Stock XiangShan emu loaded the generated image and reported native MainBTB allocation activity."
