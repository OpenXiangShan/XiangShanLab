#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
BUGDIR="$ROOT/bug/2026-05-11-mainbtb-replacer-set-alias-runtime"
OUTDIR="$BUGDIR/out_cross_context"
ASM_SRC="$BUGDIR/cross_context_sequence.S"
XS_HOME="${XS_HOME:-$ROOT/XiangShan}"

if [[ -z "${EMU:-}" ]]; then
  if [[ -x "$XS_HOME/build/emu" ]]; then
    EMU="$XS_HOME/build/emu"
  elif [[ -x "$XS_HOME/build/verilator-compile/emu" ]]; then
    EMU="$XS_HOME/build/verilator-compile/emu"
  else
    EMU="$XS_HOME/build/emu"
  fi
fi

SIM_CYCLES="${SIM_CYCLES:-30000}"
SIM_TIMEOUT="${SIM_TIMEOUT:-240s}"
ROUND_COUNT="${ROUND_COUNT:-1}"
VICTIM_WARM_LOOPS="${VICTIM_WARM_LOOPS:-6}"
ATTACKER_LOOPS="${ATTACKER_LOOPS:-16}"
VICTIM_PROBE_LOOPS="${VICTIM_PROBE_LOOPS:-3}"
USE_FENCEI="${USE_FENCEI:-0}"

mkdir -p "$OUTDIR"
export PATH="/opt/riscv/bin:/usr/lib/llvm-18/bin:$PATH"

need_tool() {
  local tool=$1
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "[-] missing tool: $tool" >&2
    exit 1
  fi
}

for tool in riscv64-unknown-elf-gcc riscv64-unknown-elf-objcopy riscv64-unknown-elf-objdump riscv64-unknown-elf-nm rg awk timeout; do
  need_tool "$tool"
done

if [[ ! -x "$EMU" ]]; then
  echo "[-] missing executable emulator: $EMU" >&2
  exit 2
fi

write_linker() {
  local mode=$1
  local lds=$2
  local b1 b2 b3 b4

  case "$mode" in
    alias|noattacker)
      b1=0x80014000
      b2=0x80024000
      b3=0x80034000
      b4=0x80044000
      ;;
    control)
      b1=0x80014100
      b2=0x80024100
      b3=0x80034100
      b4=0x80044100
      ;;
    *)
      echo "bad mode: $mode" >&2
      exit 1
      ;;
  esac

  cat > "$lds" <<LD
ENTRY(_start)

MEMORY {
  ram (rwx) : ORIGIN = 0x80000000, LENGTH = 1024M
}

SECTIONS {
  .text.entry 0x80000000 : { *(.text.entry) }

  .text.a1 0x80010000 : { KEEP(*(.text.a1)) }
  .text.a2 0x80020000 : { KEEP(*(.text.a2)) }
  .text.a3 0x80030000 : { KEEP(*(.text.a3)) }
  .text.a4 0x80040000 : { KEEP(*(.text.a4)) }
  .text.a5 0x80050000 : { KEEP(*(.text.a5)) }

  .text.b1 $b1 : { KEEP(*(.text.b1)) }
  .text.b2 $b2 : { KEEP(*(.text.b2)) }
  .text.b3 $b3 : { KEEP(*(.text.b3)) }
  .text.b4 $b4 : { KEEP(*(.text.b4)) }

  .rodata : { *(.rodata*) }
  .data : { *(.data*) }
  .bss 0x80080000 (NOLOAD) : ALIGN(16) { *(.bss*) *(.sbss*) *(COMMON) }
}
LD
}

build_case() {
  local mode=$1
  local dir="$OUTDIR/$mode"
  mkdir -p "$dir"

  local lds="$dir/poc.ld"
  local elf="$dir/poc.elf"
  local bin="$dir/poc.bin"
  local disasm="$dir/poc.txt"
  local syms="$dir/symbols.txt"
  local static="$dir/static.txt"

  write_linker "$mode" "$lds"

  local extra_defs=()
  if [[ "$mode" == "noattacker" ]]; then
    extra_defs+=("-DNO_ATTACKER=1")
  fi
  if [[ "$USE_FENCEI" == "1" ]]; then
    extra_defs+=("-DUSE_FENCEI=1")
  fi

  riscv64-unknown-elf-gcc \
    -march=rv64gc \
    -mabi=lp64d \
    -mcmodel=medany \
    -nostdlib \
    -static \
    -DROUND_COUNT="$ROUND_COUNT" \
    -DVICTIM_WARM_LOOPS="$VICTIM_WARM_LOOPS" \
    -DATTACKER_LOOPS="$ATTACKER_LOOPS" \
    -DVICTIM_PROBE_LOOPS="$VICTIM_PROBE_LOOPS" \
    "${extra_defs[@]}" \
    -Wl,--build-id=none \
    -Wl,--gc-sections \
    -Wl,-T,"$lds" \
    -o "$elf" \
    "$ASM_SRC"

  riscv64-unknown-elf-objcopy -O binary "$elf" "$bin"
  riscv64-unknown-elf-objdump -d "$elf" > "$disasm"
  riscv64-unknown-elf-nm -n "$elf" > "$syms"

  {
    printf "%-8s %-12s %-10s %-16s\n" "label" "addr" "setIdx" "replacerSetIdx"
    for label in site_A1 site_A2 site_A3 site_A4 site_A5 site_B1 site_B2 site_B3 site_B4; do
      local addr_hex
      addr_hex=$(awk -v s="$label" '$3 == s { print $1 }' "$syms")
      if [[ -z "$addr_hex" ]]; then
        echo "missing symbol: $label" >&2
        exit 1
      fi
      local addr=$((16#$addr_hex))
      printf "%-8s 0x%08x 0x%02x       0x%02x\n" \
        "$label" "$addr" "$(((addr >> 8) & 0xff))" "$(((addr >> 6) & 0xff))"
    done
  } > "$static"
}

run_case() {
  local mode=$1
  local dir="$OUTDIR/$mode"
  local bin="$dir/poc.bin"
  local log="$dir/emu.log"

  set +e
  timeout "$SIM_TIMEOUT" "$EMU" -i "$bin" --no-diff -C "$SIM_CYCLES" > "$log" 2>&1
  local rc=$?
  set -e

  if [[ "$rc" -ne 0 ]]; then
    echo "[-] $mode emu failed: $rc" >&2
    tail -n 80 "$log" >&2 || true
    exit 1
  fi
}

get_perf() {
  local log=$1
  local pattern=$2
  local line
  line=$(rg "$pattern" "$log" | tail -n 1 || true)
  if [[ -z "$line" ]]; then
    echo 0
    return
  fi
  printf '%s\n' "$line" | awk '{ gsub(",", "", $NF); print $NF + 0 }'
}

get_guest_cycles() {
  local log=$1
  local line
  line=$(rg "Guest cycle spent: [0-9]+" "$log" | tail -n 1 || true)
  if [[ -z "$line" ]]; then
    echo 0
    return
  fi
  printf '%s\n' "$line" | sed -E 's/.*Guest cycle spent: ([0-9]+).*/\1/'
}

get_instr_count() {
  local log=$1
  local line
  line=$(rg "Core-0 instrCnt = [0-9]+" "$log" | tail -n 1 || true)
  if [[ -z "$line" ]]; then
    echo 0
    return
  fi
  printf '%s\n' "$line" | sed -E 's/.*Core-0 instrCnt = ([0-9,]+).*/\1/' | tr -d ','
}

summarize_case() {
  local mode=$1
  local dir="$OUTDIR/$mode"
  local log="$dir/emu.log"
  local summary="$dir/summary.txt"

  local image_loaded=0 good_trap=0
  rg -q "The image is $dir/poc.bin" "$log" && image_loaded=1
  rg -q "HIT GOOD TRAP|EXITING WITH CODE 0|trapCode: 0" "$log" && good_trap=1

  {
    echo "mode=$mode"
    echo "image_loaded=$image_loaded"
    echo "good_trap=$good_trap"
    echo "guest_cycles=$(get_guest_cycles "$log")"
    echo "instr_count=$(get_instr_count "$log")"
    echo "mbtb_align0_allocate=$(get_perf "$log" "bpu\\.mbtb\\.alignBanks_0: _allocate")"
    echo "mbtb_total_train=$(get_perf "$log" "bpu\\.mbtb: total_train")"
    echo "mbtb_pred_hit=$(get_perf "$log" "bpu\\.mbtb: pred_hit,")"
    echo "mbtb_pred_miss=$(get_perf "$log" "bpu\\.mbtb: pred_miss")"
    echo "mbtb_train_has_mispredict=$(get_perf "$log" "bpu\\.mbtb: train_has_mispredict")"
    echo "mbtb_train_hit_mispredict=$(get_perf "$log" "bpu\\.mbtb: train_hit_mispredict")"
    echo "ftq_commit_branch_num=$(get_perf "$log" "ftq: commit_branch_num")"
    echo "ftq_commit_branch_mispredicts=$(get_perf "$log" "ftq: commit_branch_mispredicts,")"
    echo "ftq_commit_branch_mispredicts_reason_BTB=$(get_perf "$log" "ftq: commit_branch_mispredicts_reason_BTB")"
    echo "ftq_commit_branch_mispredicts_type_direct=$(get_perf "$log" "ftq: commit_branch_mispredicts_type_direct")"
    echo "ftq_commit_branch_mispredicts_s3_source_Mbtb=$(get_perf "$log" "ftq: commit_branch_mispredicts_s3_source_Mbtb")"
    echo "icache_prefetcher_bpuS0Flush=$(get_perf "$log" "icache\\.prefetcher: bpuS0Flush")"
    echo "icache_prefetcher_bpuS1Flush=$(get_perf "$log" "icache\\.prefetcher: bpuS1Flush")"
    echo "frontend_squashCycles_bpWrong_redirect=$(get_perf "$log" "frontend\\.inner: squashCycles_bpWrong_redirect")"
    echo "rob_commitInstr=$(get_perf "$log" "rob: commitInstr,")"
  } > "$summary"

  cat "$summary"
}

read_summary_value() {
  local mode=$1
  local key=$2
  awk -F= -v key="$key" '$1 == key { print $2 }' "$OUTDIR/$mode/summary.txt"
}

echo "[1/5] Build cross-context workloads"
build_case alias
build_case control
build_case noattacker

echo
echo "[2/5] Static index proof"
for mode in alias control noattacker; do
  echo "$mode:"
  cat "$OUTDIR/$mode/static.txt"
  echo
done

alias_a_set=$(awk '$1 == "site_A1" { print $3 }' "$OUTDIR/alias/static.txt")
alias_b_set=$(awk '$1 == "site_B1" { print $3 }' "$OUTDIR/alias/static.txt")
alias_a_repl=$(awk '$1 == "site_A1" { print $4 }' "$OUTDIR/alias/static.txt")
alias_b_repl=$(awk '$1 == "site_B1" { print $4 }' "$OUTDIR/alias/static.txt")
control_b_repl=$(awk '$1 == "site_B1" { print $4 }' "$OUTDIR/control/static.txt")

if [[ "$alias_a_set" == "$alias_b_set" || "$alias_a_repl" != "$alias_b_repl" || "$control_b_repl" == "$alias_a_repl" ]]; then
  echo "[-] unexpected static layout" >&2
  exit 1
fi

echo "[3/5] Run stock XiangShan emu"
run_case alias
run_case control
run_case noattacker

echo
echo "[4/5] Native perf summaries"
summarize_case alias
summarize_case control
summarize_case noattacker

alias_alloc=$(read_summary_value alias mbtb_align0_allocate)
control_alloc=$(read_summary_value control mbtb_align0_allocate)
alias_btb_misp=$(read_summary_value alias ftq_commit_branch_mispredicts_reason_BTB)
control_btb_misp=$(read_summary_value control ftq_commit_branch_mispredicts_reason_BTB)
alias_direct_misp=$(read_summary_value alias ftq_commit_branch_mispredicts_type_direct)
control_direct_misp=$(read_summary_value control ftq_commit_branch_mispredicts_type_direct)
alias_flush0=$(read_summary_value alias icache_prefetcher_bpuS0Flush)
control_flush0=$(read_summary_value control icache_prefetcher_bpuS0Flush)
alias_instr=$(read_summary_value alias rob_commitInstr)
control_instr=$(read_summary_value control rob_commitInstr)
alias_image=$(read_summary_value alias image_loaded)
control_image=$(read_summary_value control image_loaded)

impact=0
if [[ "$alias_image" -eq 1 && "$control_image" -eq 1 &&
      "$alias_instr" -eq "$control_instr" &&
      "$alias_alloc" -gt "$control_alloc" &&
      "$alias_btb_misp" -gt "$control_btb_misp" &&
      "$alias_direct_misp" -gt "$control_direct_misp" ]]; then
  impact=1
fi

{
  echo "performance_impact_confirmed=$impact"
  echo "same_committed_instruction_count=$([[ "$alias_instr" -eq "$control_instr" ]] && echo 1 || echo 0)"
  echo "alias_rob_commitInstr=$alias_instr"
  echo "control_rob_commitInstr=$control_instr"
  echo "alias_mbtb_align0_allocate=$alias_alloc"
  echo "control_mbtb_align0_allocate=$control_alloc"
  echo "alias_ftq_commit_branch_mispredicts_reason_BTB=$alias_btb_misp"
  echo "control_ftq_commit_branch_mispredicts_reason_BTB=$control_btb_misp"
  echo "alias_ftq_commit_branch_mispredicts_type_direct=$alias_direct_misp"
  echo "control_ftq_commit_branch_mispredicts_type_direct=$control_direct_misp"
  echo "alias_icache_prefetcher_bpuS0Flush=$alias_flush0"
  echo "control_icache_prefetcher_bpuS0Flush=$control_flush0"
} > "$OUTDIR/verdict.txt"

echo
echo "[5/5] Verdict"
cat "$OUTDIR/verdict.txt"

if [[ "$impact" -ne 1 ]]; then
  echo "[-] The workload ran, but the selected counters did not show the expected alias > control impact." >&2
  exit 1
fi

echo "[+] FINAL: attacker B* code in a different physical MainBTB set measurably perturbs victim A* frontend behavior when it aliases the replacement-state row."
