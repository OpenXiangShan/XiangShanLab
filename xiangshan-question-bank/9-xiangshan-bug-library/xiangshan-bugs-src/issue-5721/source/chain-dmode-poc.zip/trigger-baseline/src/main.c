/*
 * Trigger Baseline Test (Control Group)
 *
 * Prove that a debugger breakpoint (action=1, dmode=1) on target_func
 * DOES halt the CPU when there is NO chain attack.
 * Compare with chain-dmode-poc (attack test) to form a controlled experiment.
 */

#include <klib.h>

#define CSR_READ(csr) ({                          \
    unsigned long __v;                            \
    asm volatile("csrr %0, " #csr                 \
                 : "=r"(__v) : : "memory");       \
    __v;                                          \
})

#define CSR_WRITE(csr, val) ({                    \
    unsigned long __v = (unsigned long)(val);     \
    asm volatile("csrw " #csr ", %0"              \
                 : : "rK"(__v) : "memory");       \
})

#define GET_TYPE(v)   (((v) >> 60) & 0xF)
#define GET_DMODE(v)  (((v) >> 59) & 0x1)
#define GET_ACTION(v) (((v) >> 12) & 0xF)
#define GET_M(v)      (((v) >> 6)  & 0x1)
#define GET_EXEC(v)   (((v) >> 2)  & 0x1)

void __attribute__((noinline, naked)) target_func(void) {
    asm volatile(
        ".option push\n"
        ".option norvc\n"
        "add x0, x0, x0\n"
        "ret\n"
        ".option pop\n"
    );
}

int main() {
    printf("\n=== Trigger Baseline Test (Control Group) ===\n\n");
    printf("  target_func @ 0x%lx\n\n", (unsigned long)target_func);

    printf("--- Waiting for debugger to set trigger[1] (dmode=1) ---\n");

    volatile unsigned long poll_val;
    unsigned long poll_count = 0;
    while (1) {
        CSR_WRITE(tselect, 1);
        poll_val = CSR_READ(tdata1);
        if (GET_DMODE(poll_val)) {
            break;
        }
        poll_count++;
        if ((poll_count & 0xFFFFF) == 0) {
            printf("  ... still waiting (poll #%ld, tdata1=0x%lx)\n",
                   poll_count, (unsigned long)poll_val);
        }
    }

    printf("  trigger[1] dmode=1 DETECTED! (tdata1=0x%lx)\n\n", (unsigned long)poll_val);

    CSR_WRITE(tselect, 1);
    unsigned long t1 = CSR_READ(tdata1);
    unsigned long t2 = CSR_READ(tdata2);
    printf("  trigger[1]: tdata1=0x%lx tdata2=0x%lx\n", t1, t2);
    printf("    dmode=%ld action=%ld m=%ld exec=%ld\n",
           GET_DMODE(t1), GET_ACTION(t1), GET_M(t1), GET_EXEC(t1));

    printf("\n--- Calling target_func() WITHOUT chain attack ---\n");
    printf("  Expected: CPU halts (trigger fires). If next line prints, trigger is broken.\n");

    target_func();

    printf("\n  >> UNEXPECTED: CPU continued -- trigger[1] did NOT halt!\n");

    return 1;
}
