/*
 * chain+dmode Forward Check PoC (Attack Test)
 *
 * M-mode chain attack: write chain=1 to dmode=0 trigger[0],
 * neutralizing dmode=1 trigger[1]'s breakpoint.
 * Use trigger-baseline as control group (proves trigger works without attack).
 */

#include <klib.h>

#define CSR_READ(csr) ({                          \
    unsigned long __v;                            \
    asm volatile("csrr %0, " #csr                 \
                 : "=r"(__v) : : "memory");       \
    __v;                                          \
})

#define CSR_WRITE(csr, val) ({                    \
    unsigned long __v = (unsigned long)(val);     \
    asm volatile("csrw " #csr ", %0"              \
                 : : "rK"(__v) : "memory");       \
})

#define TDATA1_TYPE_MCONTROL6  (6UL << 60)
#define TDATA1_CHAIN           (1UL << 11)
#define TDATA1_M               (1UL << 6)
#define TDATA1_EXECUTE         (1UL << 2)

#define GET_TYPE(v)   (((v) >> 60) & 0xF)
#define GET_DMODE(v)  (((v) >> 59) & 0x1)
#define GET_CHAIN(v)  (((v) >> 11) & 0x1)
#define GET_ACTION(v) (((v) >> 12) & 0xF)
#define GET_M(v)      (((v) >> 6)  & 0x1)
#define GET_EXEC(v)   (((v) >> 2)  & 0x1)

void __attribute__((noinline, naked)) target_func(void) {
    asm volatile(
        ".option push\n"
        ".option norvc\n"
        "add x0, x0, x0\n"
        "ret\n"
        ".option pop\n"
    );
}

int main() {
    int fail = 0;

    printf("\n=== chain+dmode Forward Check PoC (Attack Test) ===\n\n");
    printf("  target_func @ 0x%lx\n\n", (unsigned long)target_func);

    /* Phase 1: Wait for debugger to set trigger[1] dmode=1 */
    printf("--- Phase 1: Waiting for debugger to set trigger[1] (dmode=1) ---\n");

    volatile unsigned long poll_val;
    unsigned long poll_count = 0;
    while (1) {
        CSR_WRITE(tselect, 1);
        poll_val = CSR_READ(tdata1);
        if (GET_DMODE(poll_val)) break;
        poll_count++;
        if ((poll_count & 0xFFFFF) == 0)
            printf("  ... still waiting (poll #%ld)\n", poll_count);
    }
    printf("  trigger[1] dmode=1 DETECTED!\n\n");

    /* Read trigger config */
    CSR_WRITE(tselect, 1);
    unsigned long t1_tdata1 = CSR_READ(tdata1);
    unsigned long t1_tdata2 = CSR_READ(tdata2);
    printf("--- Trigger state before attack ---\n");
    printf("  trigger[1]: tdata1=0x%lx tdata2=0x%lx\n", t1_tdata1, t1_tdata2);
    printf("    dmode=%ld action=%ld m=%ld exec=%ld\n",
           GET_DMODE(t1_tdata1), GET_ACTION(t1_tdata1),
           GET_M(t1_tdata1), GET_EXEC(t1_tdata1));

    CSR_WRITE(tselect, 0);
    unsigned long t0_pre = CSR_READ(tdata1);
    printf("  trigger[0]: tdata1=0x%lx (dmode=%ld)\n\n", t0_pre, GET_DMODE(t0_pre));

    /* Phase 2: M-mode chain attack */
    printf("--- Phase 2: M-mode chain attack ---\n");

    CSR_WRITE(tselect, 0);
    unsigned long t0_wval = TDATA1_TYPE_MCONTROL6 | TDATA1_CHAIN | TDATA1_M | TDATA1_EXECUTE;
    CSR_WRITE(tdata1, t0_wval);
    CSR_WRITE(tdata2, 0xDEAD0000UL);
    printf("  Wrote trigger[0]: tdata1=0x%lx (chain=1, dmode=0), tdata2=0xDEAD0000\n", t0_wval);

    unsigned long t0_rval = CSR_READ(tdata1);
    unsigned long t0_td2  = CSR_READ(tdata2);
    unsigned long chain_bit = GET_CHAIN(t0_rval);
    printf("  Readback: tdata1=0x%lx tdata2=0x%lx\n", t0_rval, t0_td2);
    printf("    TYPE=%ld  DMODE=%ld  CHAIN=%ld  M=%ld  EXEC=%ld\n",
           GET_TYPE(t0_rval), GET_DMODE(t0_rval), chain_bit,
           GET_M(t0_rval), GET_EXEC(t0_rval));

    if (chain_bit == 0) {
        printf("  chain=0 -- hardware enforced forward check. [PASS]\n");
    } else {
        printf("  chain=1 preserved! (spec requires chain=0 when next trigger dmode=1)\n\n");

        printf("--- Phase 3: Verify trigger[1] neutralized ---\n");
        printf("  Calling target_func()...\n");
        target_func();
        printf("  CPU continued -- trigger[1] NEUTRALIZED! (action=1 did NOT halt)\n");
        fail++;
    }

    /* Final Verdict */
    printf("\n=== Final Verdict ===\n");
    printf("  chain written = %ld (expected: 0)\n", chain_bit);
    if (chain_bit && fail) {
        printf("  trigger[1] fired = NO (neutralized)\n");
        printf("\n  VULNERABILITY CONFIRMED:\n");
        printf("    1. Debugger set trigger[1] with dmode=1, action=1\n");
        printf("    2. M-mode wrote chain=1 to trigger[0] (dmode=0)\n");
        printf("    3. Hardware did NOT clear chain (spec violation)\n");
        printf("    4. trigger[1] breakpoint no longer fires\n");
    }
    printf("\n=== Result: %d failure(s) ===\n", fail);

    return fail;
}
