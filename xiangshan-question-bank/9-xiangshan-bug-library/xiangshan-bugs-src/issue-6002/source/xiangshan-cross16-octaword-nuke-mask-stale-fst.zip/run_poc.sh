#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

SRC="${SRC:-poc.S}"
PREFIX="${PREFIX:-${SRC%.S}}"
CYCLES="${CYCLES:-17000}"
WAVE_BEGIN="${WAVE_BEGIN:-7000}"
WAVE_END="${WAVE_END:-15000}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
WAVE="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
RUN_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.run.log"
MONITOR_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
MONITOR_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

echo "[build] ${SRC} -> ${ELF}"
"$RISCV_GCC" \
  -march=rv64gc \
  -mabi=lp64 \
  -mcmodel=medany \
  -nostdlib \
  -nostartfiles \
  -T linker.ld \
  -o "$ELF" \
  "$SRC"
"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -d -s "$ELF" > "$OBJDUMP"

echo "[run] ${EMU}"
"$EMU" \
  "--max-cycles=${CYCLES}" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  --dump-wave-full \
  "--wave-path=${WAVE}" \
  -i "$BIN" \
  > "$RUN_LOG" 2>&1

echo "[parse] ${WAVE}"
python3 ./parse_cross16_nuke_vcd.py "$WAVE" "$MONITOR_JSON" > "$MONITOR_LOG"

python3 - "$MONITOR_JSON" <<'PY'
import json
import sys

path = sys.argv[1]
with open(path) as f:
    result = json.load(f)

predicate = result["predicate"]
print(json.dumps(predicate, indent=2, sort_keys=True))
if not predicate.get("reproduced"):
    raise SystemExit("cross-16B OctaWord nuke-mask bug was not reproduced")

store = result["target_store_octa_nukes"][0]
load = result["target_load_writebacks"][0]
print(
    "reproduced: "
    f"store_nuke time={store['time']} paddr={store['paddr']} mask={store['mask']} "
    f"rob={store['rob']}; "
    f"load_wb time={load['time']} paddr={load['paddr']} data={load['data']} "
    f"rob={load['rob']}"
)
print(f"monitor json: {path}")
PY
