#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path


TEST_BUF = 0x80001080
STORE_ADDR = TEST_BUF + 12
LOAD_ADDR = TEST_BUF + 16
EXPECTED = 0x11223344


def norm_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def read_header(path):
    scope = []
    vars_seen = []
    with path.open("r", errors="replace") as f:
        for line in f:
            s = line.strip()
            if s == "$enddefinitions $end":
                break
            if s.startswith("$scope "):
                parts = s.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
            elif s.startswith("$upscope"):
                if scope:
                    scope.pop()
            elif s.startswith("$var "):
                parts = s.split()
                if len(parts) >= 5:
                    name = norm_name(" ".join(parts[4:-1]))
                    vars_seen.append({
                        "width": int(parts[2]),
                        "code": parts[3],
                        "name": name,
                        "full_name": ".".join(scope + [name]),
                    })
    return vars_seen


def choose_signals(vars_seen):
    wanted = {}
    for su in range(2):
        stem = f"_inner_StoreUnit_{su}_io_staNukeQueryReq"
        for field in ("valid", "bits_paddr", "bits_mask", "bits_matchType", "bits_robIdx_flag", "bits_robIdx_value"):
            wanted[f"su{su}_{field}"] = stem + "_" + field
    for lu in range(3):
        stem = f"_inner_LoadUnit_{lu}_io_ldout"
        for field in (
            "toRob_valid",
            "toRob_bits_robIdx_flag",
            "toRob_bits_robIdx_value",
            "toRob_bits_debugInfo_paddr",
            "toRob_bits_debugInfo_vaddr",
            "toIntRf_valid",
            "toIntRf_bits_data",
        ):
            wanted[f"lu{lu}_{field}"] = stem + "_" + field
        stem = f"_inner_LoadUnit_{lu}_io_rollback"
        for field in ("valid", "bits_robIdx_flag", "bits_robIdx_value"):
            wanted[f"lu{lu}_rollback_{field}"] = stem + "_" + field
    for rb in range(2):
        stem = f"_inner_lsq_io_nuke_rollback_{rb}"
        for field in ("valid", "bits_robIdx_flag", "bits_robIdx_value"):
            wanted[f"lsq_rb{rb}_{field}"] = stem + "_" + field

    selected = {}
    missing = {}
    for key, suffix in wanted.items():
        matches = [v for v in vars_seen if v["full_name"].endswith(suffix) or v["name"].endswith(suffix)]
        if matches:
            selected[key] = sorted(matches, key=lambda v: (len(v["full_name"]), v["full_name"]))[0]
        else:
            missing[key] = suffix
    return selected, missing


def parse_bin(bits):
    bits = bits.strip()
    if not bits or any(c in bits.lower() for c in "xz"):
        return None
    return int(bits, 2)


def parse_wave(path, selected):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)
    values = {key: 0 for key in selected}
    events = []
    current_time = None
    in_body = False

    def rob(prefix):
        return [values.get(prefix + "_bits_robIdx_flag", 0), values.get(prefix + "_bits_robIdx_value", 0)]

    def emit_current():
        if current_time is None:
            return
        for su in range(2):
            prefix = f"su{su}"
            if values.get(prefix + "_valid") == 1:
                events.append({
                    "type": "store_nuke",
                    "time": current_time,
                    "unit": su,
                    "paddr": values.get(prefix + "_bits_paddr"),
                    "mask": values.get(prefix + "_bits_mask"),
                    "matchType": values.get(prefix + "_bits_matchType"),
                    "rob": rob(prefix),
                })
        for lu in range(3):
            prefix = f"lu{lu}"
            if values.get(prefix + "_toRob_valid") == 1 or values.get(prefix + "_toIntRf_valid") == 1:
                events.append({
                    "type": "load_wb",
                    "time": current_time,
                    "unit": lu,
                    "paddr": values.get(prefix + "_toRob_bits_debugInfo_paddr"),
                    "vaddr": values.get(prefix + "_toRob_bits_debugInfo_vaddr"),
                    "data": values.get(prefix + "_toIntRf_bits_data"),
                    "rob": rob(prefix + "_toRob"),
                })
            if values.get(prefix + "_rollback_valid") == 1:
                events.append({
                    "type": "load_rollback",
                    "time": current_time,
                    "unit": lu,
                    "rob": rob(prefix + "_rollback"),
                })
        for rb in range(2):
            prefix = f"lsq_rb{rb}"
            if values.get(prefix + "_valid") == 1:
                events.append({
                    "type": "lsq_nuke_rollback",
                    "time": current_time,
                    "unit": rb,
                    "rob": rob(prefix),
                })

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            first = line[0]
            if first == "#":
                emit_current()
                current_time = int(line[1:])
            elif first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bB":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_bin(parts[0][1:])
                        for key in keys:
                            values[key] = value
        emit_current()
    return events


def hx(value):
    return None if value is None else hex(value)


def event_out(event):
    out = dict(event)
    for key in ("paddr", "vaddr", "data", "mask"):
        if key in out:
            out[key] = hx(out[key])
    return out


def main(argv):
    if len(argv) != 3:
        print("usage: validate_cross16_monitor.py <wave.vcd> <out.json>", file=sys.stderr)
        return 2
    wave = Path(argv[1])
    out = Path(argv[2])
    selected, missing = choose_signals(read_header(wave))
    events = parse_wave(wave, selected)

    store_nukes = [
        e for e in events
        if e["type"] == "store_nuke"
        and e.get("paddr") == STORE_ADDR
        and e.get("matchType") == 1
    ]
    truncated_nukes = [e for e in store_nukes if e.get("mask") == 0xF000]
    target_loads = [
        e for e in events
        if e["type"] == "load_wb"
        and (e.get("paddr") == LOAD_ADDR or e.get("vaddr") == LOAD_ADDR)
    ]
    bad_target_loads = [
        e for e in target_loads
        if e.get("data") is not None and e.get("data") != EXPECTED
    ]
    rollback_robs = {
        tuple(e["rob"])
        for e in events
        if e["type"] in ("load_rollback", "lsq_nuke_rollback")
    }
    bad_no_rollback = [
        e for e in bad_target_loads
        if tuple(e["rob"]) not in rollback_robs
    ]

    result = {
        "wave": str(wave),
        "addresses": {
            "test_buf": hx(TEST_BUF),
            "store_addr": hx(STORE_ADDR),
            "load_addr": hx(LOAD_ADDR),
            "expected_load_data": hx(EXPECTED),
        },
        "selected_signal_count": len(selected),
        "missing_signal_count": len(missing),
        "missing_signals": missing,
        "selected_signals": {key: sig["full_name"] for key, sig in sorted(selected.items())},
        "target_store_octa_nukes": [event_out(e) for e in store_nukes[:20]],
        "target_load_writebacks": [event_out(e) for e in target_loads[:20]],
        "rollbacks": [event_out(e) for e in events if e["type"] in ("load_rollback", "lsq_nuke_rollback")][:80],
        "predicate": {
            "has_target_octa_nuke": bool(store_nukes),
            "has_truncated_store_mask": bool(truncated_nukes),
            "has_target_load_writeback": bool(target_loads),
            "has_bad_target_load_without_rollback": bool(bad_no_rollback),
            "reproduced": bool(truncated_nukes and bad_no_rollback),
        },
    }
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["predicate"], sort_keys=True))
    return 0 if result["predicate"]["reproduced"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
