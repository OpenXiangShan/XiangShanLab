#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--max-events", type=int, default=32)
    return parser.parse_args()


def bit_is_one(value):
    if value == "1":
        return True
    if value and value.startswith("b"):
        return int(value[1:].replace("x", "0").replace("z", "0"), 2) != 0
    return False


def main():
    args = parse_args()
    scope = []
    code_to_name = {}
    values = {}
    events = []
    var_re = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")
    table_re = re.compile(r"MicroTageTable(?:_(\d+))?")
    bank_re = re.compile(r"utage_entry_sram_bank(\d+)")
    table_ids = set()
    bank_count = 0
    now = 0
    in_header = True

    def add(code, name):
        code_to_name[code] = name
        values.setdefault(name, "x")

    def sample(time):
        if time < args.start or len(events) >= args.max_events:
            return
        abtb_enable = values.get("abtb.io_enable", "x")
        bpu_s0_fire = values.get("inner_bpu.abtb_io_stageCtrl_s0_fire_probe", "x")
        bpu_reset_done = values.get("inner_bpu.sramResetDone", "x")
        if bit_is_one(abtb_enable):
            return
        for table_id in sorted(table_ids):
            table_done = values.get(f"utage.table{table_id}.io_sramResetDone", "x")
            for bank_id in range(4):
                rcken = values.get(f"utage.table{table_id}.bank{bank_id}.rckEn", "0")
                read_valid = values.get(f"utage.table{table_id}.bank{bank_id}.io_r_req_valid", "x")
                bank_done = values.get(f"utage.table{table_id}.bank{bank_id}.io_resetDone", "x")
                if bit_is_one(rcken):
                    events.append(
                        {
                            "time": time,
                            "table": table_id,
                            "bank": bank_id,
                            "abtb_io_enable": abtb_enable,
                            "bpu_sramResetDone": bpu_reset_done,
                            "bpu_s0_fire": bpu_s0_fire,
                            "utage_table_sramResetDone": table_done,
                            "utage_bank_resetDone": bank_done,
                            "utage_bank_io_r_req_valid": read_valid,
                            "utage_bank_rckEn": rcken,
                        }
                    )
                    if len(events) >= args.max_events:
                        return

    with args.vcd.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("$scope"):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = var_re.match(line)
            if match:
                code, leaf = match.groups()
                if scope and scope[-1] == "inner_bpu":
                    if leaf == "sramResetDone":
                        add(code, "inner_bpu.sramResetDone")
                    elif leaf == "abtb_io_stageCtrl_s0_fire_probe":
                        add(code, "inner_bpu.abtb_io_stageCtrl_s0_fire_probe")
                elif scope and scope[-1] == "abtb" and leaf == "io_enable":
                    add(code, "abtb.io_enable")
                elif scope and scope[-1] == "utage" and leaf == "io_enable":
                    add(code, "utage.io_enable")
                elif scope:
                    m_table = table_re.fullmatch(scope[-1])
                    if m_table:
                        table_id = int(m_table.group(1) or 0)
                        table_ids.add(table_id)
                        if leaf == "io_sramResetDone":
                            add(code, f"utage.table{table_id}.io_sramResetDone")
                    if len(scope) >= 2:
                        m_table = table_re.fullmatch(scope[-2])
                        m_bank = bank_re.fullmatch(scope[-1])
                        if m_table and m_bank:
                            table_id = int(m_table.group(1) or 0)
                            bank_id = int(m_bank.group(1))
                            table_ids.add(table_id)
                            bank_count += 1
                            if leaf == "io_r_req_valid":
                                add(code, f"utage.table{table_id}.bank{bank_id}.io_r_req_valid")
                            elif leaf == "io_resetDone":
                                add(code, f"utage.table{table_id}.bank{bank_id}.io_resetDone")
                            elif leaf == "rckEn":
                                add(code, f"utage.table{table_id}.bank{bank_id}.rckEn")
                continue
            if line.startswith("$enddefinitions"):
                in_header = False
                continue
            if in_header:
                continue
            if line.startswith("#"):
                sample(now)
                if len(events) >= args.max_events:
                    break
                now = int(line[1:])
                continue
            if line[0] in "01xz":
                value, code = line[0], line[1:]
            elif line[0] == "b":
                value, code = line.split(maxsplit=1)
            else:
                continue
            name = code_to_name.get(code)
            if name is not None:
                values[name] = value
    sample(now)

    required = [
        "abtb.io_enable",
        "inner_bpu.sramResetDone",
        "inner_bpu.abtb_io_stageCtrl_s0_fire_probe",
        "utage.table0.bank0.rckEn",
        "utage.table0.bank0.io_resetDone",
    ]
    missing = [name for name in required if name not in values]
    result = {
        "predicate_result": "reproduced" if events else "not_reproduced",
        "success_predicate": (
            "exists settled VCD sample >= start with abtb.io_enable==0 and any "
            "MicroTageTable utage_entry_sram_bank*.rckEn==1"
        ),
        "start_time": args.start,
        "event_count": len(events),
        "first_events": events,
        "missing_core_signals": missing,
        "tables_found": sorted(table_ids),
        "bank_signal_groups_found": bank_count,
        "signals_found_count": len(values),
        "signals_found_sample": sorted(values)[:40],
    }
    if missing and not events:
        result["predicate_result"] = "failed"
        result["reason"] = "missing core ABTB/uTage monitor signals"
    if args.json_out:
        args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["predicate_result"] == "reproduced" else 1


if __name__ == "__main__":
    raise SystemExit(main())
