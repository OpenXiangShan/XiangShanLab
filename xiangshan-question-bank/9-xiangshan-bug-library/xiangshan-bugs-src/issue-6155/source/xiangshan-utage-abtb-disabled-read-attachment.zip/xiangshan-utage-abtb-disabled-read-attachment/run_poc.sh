#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build/emu}"
DIFF="${DIFF:-/root/HardwareAgent/XiangShan/ready-to-run/riscv64-nemu-interpreter-so}"

PREFIX="${PREFIX:-utage_abtb_disabled_read}"
CYCLES="${CYCLES:-9000}"
WAVE_BEGIN="${WAVE_BEGIN:-7800}"
WAVE_END="${WAVE_END:-9000}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
WAVE="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
RUN_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.run.log"
MONITOR_JSON="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
MONITOR_LOG="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

"$RISCV_GCC" \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr -mabi=lp64d \
  -T link.ld \
  -o "$ELF" \
  poc.S
"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -d "$ELF" > "$OBJDUMP"

"$EMU" \
  -i "$BIN" \
  --diff "$DIFF" \
  -C "$CYCLES" \
  -b "$WAVE_BEGIN" \
  -e "$WAVE_END" \
  --dump-wave \
  --wave-path="$WAVE" \
  > "$RUN_LOG" 2>&1

python3 ./monitor_utage_disabled_read.py \
  "$WAVE" \
  --start "$WAVE_BEGIN" \
  --json-out "$MONITOR_JSON" \
  > "$MONITOR_LOG"

python3 - "$MONITOR_JSON" <<'PY'
import json
import sys
path = sys.argv[1]
with open(path) as f:
    result = json.load(f)
print(json.dumps(result, indent=2))
if result.get("predicate_result") != "reproduced":
    raise SystemExit("uTage disabled-read predicate was not reproduced")
first = result["first_events"][0]
print(
    "reproduced: "
    f"time={first['time']} abtb_enable={first['abtb_io_enable']} "
    f"table={first['table']} bank={first['bank']} rckEn={first['utage_bank_rckEn']} "
    f"read_valid={first['utage_bank_io_r_req_valid']} bpu_s0_fire={first['bpu_s0_fire']}"
)
PY
