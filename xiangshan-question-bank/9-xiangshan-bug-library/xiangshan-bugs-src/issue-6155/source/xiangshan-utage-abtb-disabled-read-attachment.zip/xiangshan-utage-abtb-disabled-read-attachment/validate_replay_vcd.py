#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--json-out", type=Path, required=True)
    parser.add_argument("--max-events", type=int, default=16)
    return parser.parse_args()


def is_one(value):
    if value == "1":
        return True
    if value.startswith("b"):
        return any(bit == "1" for bit in value[1:])
    return False


def is_zero(value):
    if value == "0":
        return True
    if value.startswith("b"):
        return not any(bit == "1" for bit in value[1:].replace("x", "0").replace("z", "0"))
    return False


def bank_key(full_name):
    match = re.search(
        r"\.inner_bpu\.utage\.MicroTageTable(?:_(?P<table>\d+))?"
        r"\.utage_entry_sram_bank(?P<bank>\d+)"
        r"\.(?P<leaf>io_r_req_valid|io_resetDone|rckEn)$",
        full_name,
    )
    if not match:
        return None
    return (
        int(match.group("table") or 0),
        int(match.group("bank")),
        match.group("leaf"),
    )


def main():
    args = parse_args()
    scope = []
    code_to_signal = {}
    values = {}
    banks = {}
    tables = set()
    events = []
    now = 0
    in_header = True
    var_re = re.compile(r"\$var\s+\S+\s+\d+\s+(?P<code>\S+)\s+(?P<leaf>.+?)\s+\$end")

    def register(code, full_name):
        if full_name.endswith(".inner_bpu.abtb.io_enable"):
            code_to_signal[code] = "abtb_enable"
        elif full_name.endswith(".inner_bpu.sramResetDone"):
            code_to_signal[code] = "bpu_sram_reset_done"
        elif full_name.endswith(".inner_bpu.abtb_io_stageCtrl_s0_fire_probe"):
            code_to_signal[code] = "bpu_s0_fire"
        elif re.search(r"\.inner_bpu\.utage\.MicroTageTable(?:_\d+)?\.io_sramResetDone$", full_name):
            table_match = re.search(r"MicroTageTable(?:_(\d+))?\.io_sramResetDone$", full_name)
            table = int(table_match.group(1) or 0)
            tables.add(table)
            code_to_signal[code] = f"table{table}.sram_reset_done"
        else:
            key = bank_key(full_name)
            if key:
                table, bank, leaf = key
                tables.add(table)
                banks.setdefault((table, bank), {})
                code_to_signal[code] = f"table{table}.bank{bank}.{leaf}"

    def signal(name):
        return values.get(name, "x")

    def sample(time):
        if time < args.start or len(events) >= args.max_events:
            return
        if not is_zero(signal("abtb_enable")):
            return
        if not is_one(signal("bpu_sram_reset_done")):
            return
        if not is_one(signal("bpu_s0_fire")):
            return
        for table, bank in sorted(banks):
            table_done = signal(f"table{table}.sram_reset_done")
            bank_done = signal(f"table{table}.bank{bank}.io_resetDone")
            read_valid = signal(f"table{table}.bank{bank}.io_r_req_valid")
            rcken = signal(f"table{table}.bank{bank}.rckEn")
            if is_one(table_done) and is_one(bank_done) and is_one(read_valid) and is_one(rcken):
                events.append(
                    {
                        "time": time,
                        "table": table,
                        "bank": bank,
                        "abtb_io_enable": signal("abtb_enable"),
                        "bpu_sramResetDone": signal("bpu_sram_reset_done"),
                        "bpu_s0_fire": signal("bpu_s0_fire"),
                        "utage_table_sramResetDone": table_done,
                        "utage_bank_resetDone": bank_done,
                        "utage_bank_io_r_req_valid": read_valid,
                        "utage_bank_rckEn": rcken,
                    }
                )
                if len(events) >= args.max_events:
                    return

    with args.vcd.open("r", errors="replace") as vcd:
        for raw_line in vcd:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("$scope"):
                fields = line.split()
                if len(fields) >= 3:
                    scope.append(fields[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = var_re.match(line)
            if match:
                register(match.group("code"), ".".join(scope + [match.group("leaf")]))
                continue
            if line.startswith("$enddefinitions"):
                in_header = False
                continue
            if in_header:
                continue
            if line.startswith("#"):
                sample(now)
                if len(events) >= args.max_events:
                    break
                now = int(line[1:])
                continue
            if line[0] in "01xz":
                value, code = line[0], line[1:]
            elif line[0] == "b":
                value, code = line.split(maxsplit=1)
            else:
                continue
            name = code_to_signal.get(code)
            if name is not None:
                values[name] = value
    sample(now)

    required = [
        "abtb_enable",
        "bpu_sram_reset_done",
        "bpu_s0_fire",
        "table0.sram_reset_done",
        "table0.bank0.io_resetDone",
        "table0.bank0.io_r_req_valid",
        "table0.bank0.rckEn",
    ]
    missing = [name for name in required if name not in values]
    result = {
        "predicate_result": "reproduced" if events else "not_reproduced",
        "success_predicate": (
            "exists VCD sample >= start where ABTB is disabled, BPU/uTage/bank SRAM "
            "reset is complete, frontend s0 fires, and a uTage bank has read-valid and rckEn high"
        ),
        "start_time": args.start,
        "event_count": len(events),
        "first_events": events,
        "missing_core_signals": missing,
        "tables_found": sorted(tables),
        "bank_groups_found": len(banks),
        "signals_tracked": sorted(values),
    }
    args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if events and not missing else 1


if __name__ == "__main__":
    raise SystemExit(main())
