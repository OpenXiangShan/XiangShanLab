#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


PERF_RE = re.compile(r"\[PERF\s*\].*:\s*([^,]+),\s*(-?\d+)\s*$")
VAR_RE = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")


def clean_name(name: str) -> str:
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_int(value: str | None) -> int | None:
    if value is None:
        return None
    value = value.strip()
    if value in {"0", "1"}:
        return int(value)
    if value[:1].lower() == "b":
        bits = value[1:].lower()
        if any(ch in bits for ch in "xz"):
            return None
        return int(bits, 2)
    if value.lower() in {"x", "z"}:
        return None
    return None


def parse_symbols(path: Path) -> dict[str, int]:
    out: dict[str, int] = {}
    for line in path.read_text(errors="replace").splitlines():
        parts = line.split()
        if len(parts) >= 3:
            try:
                out[parts[2]] = int(parts[0], 16)
            except ValueError:
                pass
    return out


def parse_objdump_forbidden(path: Path, start: int, end: int) -> list[str]:
    insn_re = re.compile(r"^\s*([0-9a-fA-F]+):\s+[0-9a-fA-F]+\s+\s*([a-z.0-9_]+)\b")
    bad_re = re.compile(r"\b(jalr|jr|ret)\b")
    out = []
    for line in path.read_text(errors="replace").splitlines():
        match = insn_re.match(line)
        if not match:
            continue
        pc = int(match.group(1), 16)
        mnemonic = match.group(2)
        if start <= pc < end and bad_re.search(mnemonic):
            out.append(line.strip())
    return out


def parse_perf(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    if not path or not path.exists():
        return values
    for line in path.read_text(errors="replace").splitlines():
        match = PERF_RE.search(line)
        if not match:
            continue
        key, raw_value = match.groups()
        key = key.strip()
        value = int(raw_value)
        if key in {
            "commit_branch_mispredicts",
            "commit_branch_num",
            "commit_branch_mispredicts_type_indirect",
            "commit_branch_mispredicts_reason_BTB",
            "commit_branch_mispredicts_reason_TAGE",
            "commitInstr",
        }:
            values[key] = value
        if key in {
            "ittage_table_updates",
            "ittage_table_hits",
            "ittage_table_read_write_conflict",
            "ittage_table_update_drop",
            "ittage_used",
        }:
            values[key] = values.get(key, 0) + value
    return values


def select_vcd_signals(path: Path):
    wanted_suffixes = {}
    for i in range(3):
        endpoint = "store" if i == 0 else f"store_{i}"
        wanted_suffixes[f"store_{i}_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_valid"
        wanted_suffixes[f"store_{i}_bits_valid"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_valid"
        wanted_suffixes[f"store_{i}_addr"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_addr"
        wanted_suffixes[f"store_{i}_data"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_data"
        wanted_suffixes[f"store_{i}_pc"] = f"TOP.SimTop.endpoint.{endpoint}.io_bits_pc"

    selected = {}
    code_to_keys: dict[str, list[str]] = {}
    scope: list[str] = []
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope"):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = VAR_RE.match(line)
            if not match:
                continue
            code, raw_name = match.groups()
            full = ".".join(scope + [clean_name(raw_name)])
            for key, suffix in wanted_suffixes.items():
                if full.endswith(suffix):
                    selected[key] = {"code": code, "full": full}
                    code_to_keys.setdefault(code, []).append(key)
    return selected, code_to_keys


def parse_vcd_stores(path: Path, result_delta: int, result_done: int):
    selected, code_to_keys = select_vcd_signals(path)
    values = {key: None for key in selected}
    now = None
    in_body = False
    delta_stores = []
    done_stores = []

    def sample(time: int | None):
        if time is None:
            return
        for i in range(3):
            valid = parse_int(values.get(f"store_{i}_valid")) == 1
            bits_valid = parse_int(values.get(f"store_{i}_bits_valid"))
            addr = parse_int(values.get(f"store_{i}_addr"))
            if not valid or bits_valid not in (None, 1):
                continue
            row = {
                "time": time,
                "slot": i,
                "addr": addr,
                "data": parse_int(values.get(f"store_{i}_data")),
                "pc": parse_int(values.get(f"store_{i}_pc")),
            }
            if addr == result_delta:
                delta_stores.append(row)
            if addr == result_done:
                done_stores.append(row)

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                continue
            if line[0] in "01xXzZ":
                value, code = line[0], line[1:].strip()
                for key in code_to_keys.get(code, []):
                    values[key] = value
                continue
            if line[0] in "bB":
                parts = line.split()
                if len(parts) == 2:
                    value, code = parts
                    for key in code_to_keys.get(code, []):
                        values[key] = value
        sample(now)

    return {
        "selected_signal_count": len(selected),
        "missing": sorted(k for k in [
            "store_0_valid", "store_0_addr", "store_0_data",
            "store_1_valid", "store_1_addr", "store_1_data",
            "store_2_valid", "store_2_addr", "store_2_data",
        ] if k not in selected),
        "delta_store_count": len(delta_stores),
        "done_store_count": len(done_stores),
        "delta_values": [row["data"] for row in delta_stores[:8]],
        "done_values": [row["data"] for row in done_stores[:8]],
        "first_delta_stores": delta_stores[:8],
        "first_done_stores": done_stores[:8],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", type=Path, required=True)
    ap.add_argument("--objdump", type=Path, required=True)
    ap.add_argument("--run-log", type=Path)
    ap.add_argument("--vcd", type=Path)
    ap.add_argument("--json-out", type=Path, required=True)
    args = ap.parse_args()

    symbols = parse_symbols(args.symbols)
    required = ["after_jalr", "hammer_done", "result_delta", "result_done"]
    missing_symbols = [name for name in required if name not in symbols]
    if missing_symbols:
        raise SystemExit(f"missing symbols: {missing_symbols}")

    result = {
        "symbols": {name: hex(symbols[name]) for name in sorted(symbols) if name in {
            "_start", "pattern_loop", "victim_jalr_site", "after_jalr", "hammer_loop",
            "hammer_done", "begin_measure", "end_measure", "target_a", "target_b",
            "result_delta", "result_done",
        }},
        "direct_phase_forbidden_indirects": parse_objdump_forbidden(
            args.objdump, symbols["after_jalr"], symbols["hammer_done"]
        ),
        "perf": parse_perf(args.run_log) if args.run_log else {},
    }
    if args.vcd:
        result["vcd"] = parse_vcd_stores(args.vcd, symbols["result_delta"], symbols["result_done"])

    result["predicate"] = {
        "direct_phase_has_no_indirect": not result["direct_phase_forbidden_indirects"],
        "rdcycle_delta_observed": bool(result.get("vcd", {}).get("delta_values")),
        "program_done_store_observed": bool(result.get("vcd", {}).get("done_values")),
        "ittage_conflict_observed": result["perf"].get("ittage_table_read_write_conflict", 0) > 0,
        "ittage_update_drop_observed": result["perf"].get("ittage_table_update_drop", 0) > 0,
    }

    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
