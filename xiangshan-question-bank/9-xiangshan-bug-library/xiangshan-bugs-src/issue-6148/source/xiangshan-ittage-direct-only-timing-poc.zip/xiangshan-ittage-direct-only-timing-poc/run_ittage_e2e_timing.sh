#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
RISCV_NM="${RISCV_NM:-/opt/riscv/bin/riscv64-unknown-elf-nm}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

HAMMER_BANK="${HAMMER_BANK:-0}"
WARM_ITERS="${WARM_ITERS:-96}"
MEASURE_ITERS="${MEASURE_ITERS:-96}"
HAMMER_ITERS="${HAMMER_ITERS:-64}"
PREFIX="${PREFIX:-ittage_e2e_bank${HAMMER_BANK}}"
CYCLES="${CYCLES:-60000}"
TIMEOUT_SECS="${TIMEOUT_SECS:-180}"
WAVE="${WAVE:-0}"
WAVE_BEGIN="${WAVE_BEGIN:-0}"
WAVE_END="${WAVE_END:-60000}"

ELF="${PREFIX}.elf"
BIN="${PREFIX}.bin"
OBJDUMP="${PREFIX}.objdump"
SYMBOLS="${PREFIX}.symbols"
RUN_LOG="${PREFIX}.run.log"
VCD="${PREFIX}_${WAVE_BEGIN}_${WAVE_END}.vcd"
JSON="${PREFIX}.monitor.json"
MONITOR_LOG="${PREFIX}.monitor.log"

"$RISCV_GCC" \
  -nostdlib -nostartfiles -static \
  -march=rv64gc_zicsr -mabi=lp64d \
  -Wl,--no-relax \
  -DHAMMER_BANK="$HAMMER_BANK" \
  -DWARM_ITERS="$WARM_ITERS" \
  -DMEASURE_ITERS="$MEASURE_ITERS" \
  -DHAMMER_ITERS="$HAMMER_ITERS" \
  -T link.ld \
  -o "$ELF" \
  ittage_e2e_timing.S

"$RISCV_OBJCOPY" -O binary "$ELF" "$BIN"
"$RISCV_OBJDUMP" -d -t "$ELF" > "$OBJDUMP"
"$RISCV_NM" -n "$ELF" > "$SYMBOLS"

emu_args=(
  -i "$BIN"
  --no-diff
  -C "$CYCLES"
  --force-dump-result
)

if [[ "$WAVE" == "1" ]]; then
  emu_args+=(
    -b "$WAVE_BEGIN"
    -e "$WAVE_END"
    --dump-wave-full
    --wave-path="$VCD"
  )
fi

timeout "${TIMEOUT_SECS}s" "$EMU" "${emu_args[@]}" > "$RUN_LOG" 2>&1

monitor_args=(
  --symbols "$SYMBOLS"
  --objdump "$OBJDUMP"
  --run-log "$RUN_LOG"
  --json-out "$JSON"
)

if [[ "$WAVE" == "1" ]]; then
  monitor_args+=(--vcd "$VCD")
fi

python3 ./monitor_ittage_e2e_timing.py "${monitor_args[@]}" > "$MONITOR_LOG"
cat "$MONITOR_LOG"
