#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


DEFAULT_CASES = {
    "hammer_bank0": "e2e_bank0_w8_m8_h32_wave0_12k.monitor.json",
    "hammer_bank1": "e2e_bank1_w8_m8_h32_wave8p5_11k.monitor.json",
    "ctrl_bank0": "e2e_ctrl_bank0_w8_m8_h0_wave0_12k.monitor.json",
    "ctrl_bank1": "e2e_ctrl_bank1_w8_m8_h0_wave0_12k.monitor.json",
}


def load_case(path: Path) -> dict:
    data = json.loads(path.read_text())
    return {
        "file": path.name,
        "delta": data.get("vcd", {}).get("delta_values", [None])[0],
        "done": data.get("vcd", {}).get("done_values", [None])[0],
        "direct_ok": data["predicate"]["direct_phase_has_no_indirect"],
        "conflict": data["perf"].get("ittage_table_read_write_conflict"),
        "updates": data["perf"].get("ittage_table_updates"),
        "drops": data["perf"].get("ittage_table_update_drop"),
        "misp": data["perf"].get("commit_branch_mispredicts"),
        "tage_misp": data["perf"].get("commit_branch_mispredicts_reason_TAGE"),
        "ind_misp": data["perf"].get("commit_branch_mispredicts_type_indirect"),
        "commitInstr": data["perf"].get("commitInstr"),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=Path("."))
    parser.add_argument("--json-out", type=Path, default=Path("ittage_e2e_timing_verdict.json"))
    args = parser.parse_args()

    rows = {
        name: load_case(args.base / filename)
        for name, filename in DEFAULT_CASES.items()
    }
    derived = {
        "control_bank_delta_cycles": rows["ctrl_bank0"]["delta"] - rows["ctrl_bank1"]["delta"],
        "hammer_bank0_minus_bank1_cycles": rows["hammer_bank0"]["delta"] - rows["hammer_bank1"]["delta"],
        "hammer_bank0_minus_ctrl_cycles": rows["hammer_bank0"]["delta"] - rows["ctrl_bank0"]["delta"],
        "hammer_bank1_minus_ctrl_cycles": rows["hammer_bank1"]["delta"] - rows["ctrl_bank1"]["delta"],
        "hammer_bank0_over_bank1_ratio": rows["hammer_bank0"]["delta"] / rows["hammer_bank1"]["delta"],
        "hammer_conflict_bank0_minus_bank1": rows["hammer_bank0"]["conflict"] - rows["hammer_bank1"]["conflict"],
        "hammer_misp_bank0_minus_bank1": rows["hammer_bank0"]["misp"] - rows["hammer_bank1"]["misp"],
        "hammer_tage_misp_bank0_minus_bank1": rows["hammer_bank0"]["tage_misp"] - rows["hammer_bank1"]["tage_misp"],
    }
    predicate = {
        "all_program_results_observed": all(row["delta"] is not None and row["done"] == 1 for row in rows.values()),
        "all_direct_phases_have_no_indirect": all(row["direct_ok"] for row in rows.values()),
        "control_banks_have_equal_timing": derived["control_bank_delta_cycles"] == 0,
        "hammer_bank0_is_slower_than_bank1": derived["hammer_bank0_minus_bank1_cycles"] > 0,
        "hammer_bank0_has_more_ittage_conflict": derived["hammer_conflict_bank0_minus_bank1"] > 0,
        "hammer_bank0_has_more_branch_mispredicts": derived["hammer_misp_bank0_minus_bank1"] > 0,
    }
    predicate["e2e_timing_channel_observed"] = all(predicate.values())

    result = {
        "rows": rows,
        "derived": derived,
        "predicate": predicate,
    }
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if predicate["e2e_timing_channel_observed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
