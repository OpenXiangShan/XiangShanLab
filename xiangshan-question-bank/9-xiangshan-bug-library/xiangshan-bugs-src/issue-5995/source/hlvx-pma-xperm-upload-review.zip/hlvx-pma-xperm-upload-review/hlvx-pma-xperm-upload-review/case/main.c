#include <klib.h>
#include <stdint.h>

#define CSR_PMACFG0 0x7c0
#define CSR_PMAADDR0 0x7c8
#define PMA_R 0x01ull
#define PMA_W 0x02ull
#define PMA_X 0x04ull
#define PMA_A_NAPOT 0x18ull
#define PMA_C 0x40ull
#define CAUSE_LOAD_ACCESS_FAULT 5ull

static volatile uint64_t trap_count;
static volatile uint64_t trap_mcause;
static volatile uint64_t trap_mepc;
static volatile uint64_t trap_mtval;
static volatile uint64_t trap_mtval2;
static volatile uint64_t trap_htval;
static volatile uint64_t hlvx_value;

static uint8_t target_page[4096] __attribute__((aligned(4096)));

void trap_entry(void);

__attribute__((naked, aligned(4))) void trap_entry(void) {
  asm volatile(
    "csrr t0, mcause\n\t"
    "csrr t1, mepc\n\t"
    "csrr t2, mtval\n\t"
    "csrr t3, 0x34b\n\t"
    "csrr t4, 0x643\n\t"
    "la t5, trap_mcause\n\t"
    "sd t0, 0(t5)\n\t"
    "la t5, trap_mepc\n\t"
    "sd t1, 0(t5)\n\t"
    "la t5, trap_mtval\n\t"
    "sd t2, 0(t5)\n\t"
    "la t5, trap_mtval2\n\t"
    "sd t3, 0(t5)\n\t"
    "la t5, trap_htval\n\t"
    "sd t4, 0(t5)\n\t"
    "la t5, trap_count\n\t"
    "ld t6, 0(t5)\n\t"
    "addi t6, t6, 1\n\t"
    "sd t6, 0(t5)\n\t"
    "addi t1, t1, 4\n\t"
    "csrw mepc, t1\n\t"
    "mret\n\t");
}

static inline uint64_t read_csr_num(uint32_t csr) {
  uint64_t value = 0;
  switch (csr) {
    case CSR_PMACFG0:
      asm volatile("csrr %0, 0x7c0" : "=r"(value));
      break;
    case CSR_PMAADDR0:
      asm volatile("csrr %0, 0x7c8" : "=r"(value));
      break;
  }
  return value;
}

static inline void write_pmacfg0(uint64_t value) {
  asm volatile("csrw 0x7c0, %0" :: "r"(value) : "memory");
}

static inline void write_pmaaddr0(uint64_t value) {
  asm volatile("csrw 0x7c8, %0" :: "r"(value) : "memory");
}

static inline uint64_t read_hstatus(void) {
  uint64_t value;
  asm volatile("csrr %0, 0x600" : "=r"(value));
  return value;
}

static inline void write_hstatus(uint64_t value) {
  asm volatile("csrw 0x600, %0" :: "r"(value) : "memory");
}

static inline uint32_t do_hlvx_wu(uintptr_t address) {
  register uint64_t value asm("a0");
  register uintptr_t rs1 asm("a1") = address;
  asm volatile(".word 0x6835c573" : "=r"(value) : "r"(rs1) : "memory");
  return (uint32_t)value;
}

static inline uint64_t pma_napot_4kb(uintptr_t base) {
  return (base + 2047ull) >> 2;
}

int main(void) {
  printf("hlvx-pma-xperm start\n");
  asm volatile("csrw mtvec, %0" :: "r"(trap_entry) : "memory");

  target_page[0] = 0x5a;
  target_page[1] = 0xa5;
  target_page[2] = 0x3c;
  target_page[3] = 0xc3;

  uint64_t old_pmacfg0 = read_csr_num(CSR_PMACFG0);
  uint64_t old_pmaaddr0 = read_csr_num(CSR_PMAADDR0);
  uint64_t old_hstatus = read_hstatus();

  uintptr_t page_base = (uintptr_t)target_page;
  write_pmaaddr0(pma_napot_4kb(page_base));
  write_pmacfg0((old_pmacfg0 & ~0xffull) | PMA_C | PMA_A_NAPOT | PMA_W | PMA_R);
  write_hstatus(old_hstatus & ~(1ull << 8));
  asm volatile("fence rw, rw" ::: "memory");

  hlvx_value = do_hlvx_wu((uintptr_t)target_page);
  asm volatile("fence rw, rw" ::: "memory");

  write_pmacfg0(old_pmacfg0);
  write_pmaaddr0(old_pmaaddr0);
  write_hstatus(old_hstatus);

  printf("trap_count=%lu mcause=%lu mtval=0x%lx mtval2=0x%lx htval=0x%lx hlvx=0x%lx\n",
         trap_count, trap_mcause, trap_mtval, trap_mtval2, trap_htval, hlvx_value);

  if (trap_count == 0) {
    printf("FAIL hlvx bypassed PMA execute permission\n");
    assert(0);
  }
  if (trap_mcause != CAUSE_LOAD_ACCESS_FAULT) {
    printf("FAIL unexpected hlvx trap cause\n");
    assert(0);
  }

  printf("hlvx-pma-xperm pass\n");
  return 0;
}
