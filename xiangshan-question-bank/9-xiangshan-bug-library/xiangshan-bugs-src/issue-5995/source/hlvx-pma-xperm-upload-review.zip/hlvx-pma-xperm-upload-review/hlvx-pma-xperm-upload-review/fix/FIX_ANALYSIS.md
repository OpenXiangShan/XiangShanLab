# HLVX PMA/PMP 执行权限修复分析

## 根因

`HLVX.HU/WU` 被解码为 load，LoadUnit 也正确拉起了 TLB 请求中的 `hlvx` 旁带信号。TLB 已经用该旁带信号处理页表权限检查，但最终 PMP/PMA 检查只收到 `cmd = TlbCmd.read`。因此最终物理属性只检查 `R`，没有检查 `X`，导致 HLVX 可以从 `R=1, X=0` 的 PMA 区域读出数据。

这不是“PMA 可配置所以不算问题”。PMA 在本实现里确实可由固件/测试配置，但一旦某个区域被配置为 `R=1, X=0`，硬件就必须执行这个最终物理属性。对 `HLVX` 来说，RISC-V privileged/H 扩展要求最终 supervisor physical memory attributes 同时授予读权限和执行权限。

## 已实现的修复

- 在 `PMPReqBundle` 中增加 `hlvx` 旁带，并为普通 PMP/PMA 请求默认置为 `false`。
- 从 TLB 将 `req_out(i).hlvx` 传入 PMP/PMA 检查。
- 在 PMP 和 PMA 检查中，将 `hlvx && !cfg.x` 作为 load access fault 通过 `resp.ld` 上报，从而保留 HLVX 作为 load 指令的异常类型。
- 对 IFU、ICache、prefetch、PTW、bitmap、atomic、hybrid、store 和 vector 等非 HLVX 请求源显式设置 `hlvx := false.B`，避免新增旁带出现 `DontCare`。

## 为什么不直接把命令改成 `exec`

如果把 HLVX 的最终 PMP/PMA 请求命令改成 `TlbCmd.exec`，硬件会报告 instruction access fault，而不是 load access fault。HLVX 仍然是 load 指令，正确行为是“按 load 报异常，但额外要求最终物理执行权限”。因此使用独立旁带更符合异常语义。

## 验证解释

- 修复前 difftest 运行中，HLVX 直接读出数据，IT 打印 `trap_count=0` 并失败。
- 修复后 difftest-enabled 运行在 HLVX 指令处出现 mismatch：DUT 报 `mcause=5`，而 NEMU 参考模型没有建模该 IT 动态写入的 PMA CSR 状态。这是预期现象，说明 DUT 行为已经变成正确 trap。
- 修复后 `--no-diff` 两次运行均通过：IT 观测到 `trap_count=1`、`mcause=5`、`mtval=0x80002000`，最后 `HIT GOOD TRAP`。
