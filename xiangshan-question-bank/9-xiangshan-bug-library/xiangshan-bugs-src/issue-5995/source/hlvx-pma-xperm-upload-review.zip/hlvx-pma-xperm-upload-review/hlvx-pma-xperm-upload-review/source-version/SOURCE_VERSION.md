# Source Version

- Branch: kunminghu-v2
- Commit: 4d1d56db9374d8163c1475e0ebf41265ec85d240
- Commit subject: submodule(CoupledL2): bump CoupledL2 (#5949)
- Commit date: 2026-05-14T10:10:42+08:00
- Working tree note: local tree contains the HLVX PMA/PMP fix and pre-existing local Makefile helper changes.

## Modified source files for this fix
- src/main/scala/xiangshan/backend/fu/PMA.scala
- src/main/scala/xiangshan/backend/fu/PMP.scala
- src/main/scala/xiangshan/cache/mmu/BitmapCheck.scala
- src/main/scala/xiangshan/cache/mmu/PageTableWalker.scala
- src/main/scala/xiangshan/cache/mmu/TLB.scala
- src/main/scala/xiangshan/frontend/IFU.scala
- src/main/scala/xiangshan/frontend/icache/ICacheMainPipe.scala
- src/main/scala/xiangshan/frontend/icache/IPrefetch.scala
- src/main/scala/xiangshan/mem/pipeline/AtomicsUnit.scala
- src/main/scala/xiangshan/mem/pipeline/HybridUnit.scala
- src/main/scala/xiangshan/mem/prefetch/L1PrefetchComponent.scala
- src/main/scala/xiangshan/mem/prefetch/SMSPrefetcher.scala
- src/main/scala/xiangshan/mem/vector/VSegmentUnit.scala

## Git status at package time
 M Makefile
 M src/main/scala/xiangshan/backend/fu/PMA.scala
 M src/main/scala/xiangshan/backend/fu/PMP.scala
 M src/main/scala/xiangshan/cache/mmu/BitmapCheck.scala
 M src/main/scala/xiangshan/cache/mmu/PageTableWalker.scala
 M src/main/scala/xiangshan/cache/mmu/TLB.scala
 M src/main/scala/xiangshan/frontend/IFU.scala
 M src/main/scala/xiangshan/frontend/icache/ICacheMainPipe.scala
 M src/main/scala/xiangshan/frontend/icache/IPrefetch.scala
 M src/main/scala/xiangshan/mem/pipeline/AtomicsUnit.scala
 M src/main/scala/xiangshan/mem/pipeline/HybridUnit.scala
 M src/main/scala/xiangshan/mem/prefetch/L1PrefetchComponent.scala
 M src/main/scala/xiangshan/mem/prefetch/SMSPrefetcher.scala
 M src/main/scala/xiangshan/mem/vector/VSegmentUnit.scala
