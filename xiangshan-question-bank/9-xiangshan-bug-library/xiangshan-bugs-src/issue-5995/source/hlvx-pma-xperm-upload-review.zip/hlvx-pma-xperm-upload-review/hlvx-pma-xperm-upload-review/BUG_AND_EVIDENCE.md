# Bug Description and Evidence Chain

## Bug summary

`HLVX.HU/WU` does not check final PMA/PMP execute permission.

The design correctly uses execute permission during TLB page-table permission checks, but the final physical PMA/PMP check is issued as a normal load request. Therefore, if a physical region is configured as readable but non-executable (`R=1, X=0`), `HLVX` can still read data instead of raising load access fault.

## Expected behavior

For `HLVX.HU/WU` targeting a final physical region configured as `R=1, X=0`:

- the access must not return data;
- the core must raise load access fault;
- `mcause` must be `5`;
- the exception type must remain a load exception.

## Observed pre-fix behavior

Pre-fix runs show that the target data is returned and no trap is taken:

```text
trap_count=0 mcause=0 mtval=0x0 mtval2=0x0 htval=0x0 hlvx=0xc33ca55a
FAIL hlvx bypassed PMA execute permission
HIT BAD TRAP
```

Evidence files:

- `logs/pre-fix/20260519-185540-hlvx-pma-xperm-try1.log`
- `logs/pre-fix/20260519-185735-hlvx-pma-xperm-rerun1.log`
- `logs/pre-fix/20260519-185858-hlvx-pma-xperm-rerun2.log`

## Post-fix behavior

After the local fix, DUT self-check observes the expected load access fault:

```text
trap_count=1 mcause=5 mtval=0x80002000 mtval2=0x0 htval=0x0 hlvx=0x15
hlvx-pma-xperm pass
HIT GOOD TRAP
```

Evidence files:

- `logs/post-fix/20260519-213227-hlvx-pma-xperm-fixed-nodiff-1.log`
- `logs/post-fix/20260519-213227-hlvx-pma-xperm-fixed-nodiff-2.log`

The difftest-enabled post-fix logs show an expected reference mismatch because the reference simulator does not implement this dynamic PMA CSR update; DUT now traps with `mcause=5`.

## Source evidence chain

### 1. Decode path

File: `src/main/scala/xiangshan/backend/decode/DecodeUnit.scala`

`HLVX_HU/WU` are decoded to load-unit operations:

- `LSUOpType.hlvxhu`
- `LSUOpType.hlvxwu`

### 2. LoadUnit request path

File: `src/main/scala/xiangshan/mem/pipeline/LoadUnit.scala`

HLVX is sent as a load request:

```scala
io.tlb.req.bits.cmd := TlbCmd.read
io.tlb.req.bits.hlvx := s0_tlb_hlvx
```

This is correct for exception type, but the `hlvx` intent must continue into final PMA/PMP checking.

### 3. TLB permission path

File: `src/main/scala/xiangshan/cache/mmu/TLB.scala`

TLB page-table permission checks use `hlvx` correctly, so HLVX checks execute permission during translation. The original issue is that the final PMP/PMA request path did not forward this `hlvx` intent.

Fix evidence:

```scala
pmp_check(addr, req_out(i).size, req_out(i).cmd, req_out(i).hlvx, noTranslateReg, i)
pmp(idx).bits.hlvx := hlvx
```

### 4. PMA check

File: `src/main/scala/xiangshan/backend/fu/PMA.scala`

Fix evidence:

```scala
def pma_check(cmd: UInt, cfg: PMPConfig, hlvx: Bool = false.B) = {
  resp.ld := TlbCmd.isRead(cmd) && (!cfg.r || hlvx && !cfg.x)
}
```

### 5. PMP check

File: `src/main/scala/xiangshan/backend/fu/PMP.scala`

Fix evidence:

```scala
val hlvx = Output(Bool())
def pmp_check(cmd: UInt, cfg: PMPConfig, hlvx: Bool = false.B) = {
  resp.ld := TlbCmd.isRead(cmd) && !TlbCmd.isAmo(cmd) && (!cfg.r || hlvx && !cfg.x)
}
val resp_pma = pma_check(cmd, res_pma.cfg, hlvx)
```

## Test case

Test source:

- `case/main.c`

Built artifacts:

- `binaries/hlvx-pma-xperm-riscv64-xs.bin`
- `binaries/hlvx-pma-xperm-riscv64-xs.elf`
- `binaries/hlvx-pma-xperm-riscv64-xs.txt`

The test configures PMA entry 0 as a 4 KiB NAPOT region over the target page with `R=1, W=1, C=1, X=0`, then executes `hlvx.wu` encoded as `.word 0x6835c573`.

## Commands

Build and run commands are recorded in:

- `commands/COMMANDS.md`

## Source version and patch

Source version and dirty state are recorded in:

- `source-version/SOURCE_VERSION.md`

Patch files:

- `source-version/source-fix.diff`
- `fix/hlvx-pma-fix.diff`

Detailed fix analysis:

- `fix/FIX_ANALYSIS.md`

## Checksums and manifest

- Full file manifest: `MANIFEST.txt`
- Full package checksums: `SHA256SUMS.txt`
- Binary checksums: `binaries/SHA256SUMS.txt`
