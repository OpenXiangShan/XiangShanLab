# Commands

## Build emulator

```sh
make emu WITH_CONSTANTIN=0 WITH_CHISELDB=0 CONFIG='XSNoCTopConfig --enable-difftest' ISSUE=E.b XSTOP_PREFIX=bosc_ JVM_XMX=10g
```

## Build IT workload

```sh
source ../load-nexus-am-env.sh
make -C build/bug-hunt/session-002/cases/hlvx-pma-xperm ARCH=riscv64-xs LINUX_GNU_TOOLCHAIN=0 clean image
```

## Pre-fix reproduction command

```sh
TIMEOUT_SECONDS=90 MAX_INSTR=500000 \
  build/bug-hunt/session-002/run_workload.sh ready hlvx-pma-xperm-rerun1 \
  build/bug-hunt/session-002/cases/hlvx-pma-xperm/build/hlvx-pma-xperm-riscv64-xs.bin
```

Expected pre-fix marker:

```text
trap_count=0 ... hlvx=0xc33ca55a
FAIL hlvx bypassed PMA execute permission
HIT BAD TRAP
```

## Post-fix DUT self-check command

```sh
build/emu -i build/bug-hunt/session-002/cases/hlvx-pma-xperm/build/hlvx-pma-xperm-riscv64-xs.bin --no-diff --max-instr=500000
```

Expected post-fix marker:

```text
trap_count=1 mcause=5 mtval=0x80002000 ...
hlvx-pma-xperm pass
HIT GOOD TRAP
```
