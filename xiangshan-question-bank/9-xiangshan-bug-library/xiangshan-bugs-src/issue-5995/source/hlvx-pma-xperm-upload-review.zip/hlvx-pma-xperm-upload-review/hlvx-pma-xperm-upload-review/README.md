# HLVX PMA/PMP X-permission upload review package

This folder is prepared for review before creating a single upload archive.

## Contents

- `BUG_AND_EVIDENCE.md`: root bug description and source evidence chain.
- `case/`: minimal IT source and Makefile.
- `binaries/`: built AM workload binary/ELF/disassembly plus SHA256 checksums.
- `source-version/`: XiangShan source commit, dirty status, and source fix diff.
- `commands/`: exact build and run commands used for reproduction/validation.
- `results/`: concise before/after run summary.
- `fix/`: detailed fix analysis and patch diff.
- `logs/`: raw pre-fix and post-fix run logs/status files.
- `issue/`: concise GitHub issue body.

## Review checklist

- Test case source is in `case/main.c`.
- Workload binary is in `binaries/hlvx-pma-xperm-riscv64-xs.bin`.
- Source version is in `source-version/SOURCE_VERSION.md`.
- Source patch is in `source-version/source-fix.diff` and `fix/hlvx-pma-fix.diff`.
- Commands are in `commands/COMMANDS.md`.
- Results are in `results/RUN_SUMMARY.txt`.
- Detailed fix plan is in `fix/FIX_ANALYSIS.md`.
