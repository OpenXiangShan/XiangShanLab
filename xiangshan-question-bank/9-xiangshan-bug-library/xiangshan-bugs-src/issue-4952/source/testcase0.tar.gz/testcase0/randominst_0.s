
output_8_15/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <_end_trap>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <_end_trap>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	6521                	lui	a0,0x8
    800001be:	8005051b          	addiw	a0,a0,-2048 # 7800 <_start-0x7fff8800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_end_prefix>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_end_prefix>:
    80000200:	00010517          	auipc	a0,0x10
    80000204:	f4050513          	addi	a0,a0,-192 # 80010140 <d_0_18>
    80000208:	0521                	addi	a0,a0,8
    8000020a:	61453a2f          	amoand.d	s4,s4,(a0)

000000008000020e <_l1>:
    8000020e:	0000100f          	fence.i

0000000080000212 <_l2>:
    80000212:	185d8a53          	fdiv.s	fs4,fs11,ft5,rne

0000000080000216 <_l3>:
    80000216:	00000393          	li	t2,0
    8000021a:	3553bf73          	csrrc	t5,mireg4,t2
    8000021e:	83fa                	mv	t2,t5

0000000080000220 <_l4>:
    80000220:	000a7513          	andi	a0,s4,0

0000000080000224 <_l5>:
    80000224:	983c894f          	fnmadd.s	fs2,fs9,ft3,fs3,rne

0000000080000228 <_l6>:
    80000228:	a16121d3          	feq.s	gp,ft2,fs6

000000008000022c <_l7>:
    8000022c:	00000917          	auipc	s2,0x0
    80000230:	0e490913          	addi	s2,s2,228 # 80000310 <_l33>
    80000234:	00090667          	jalr	a2,s2

0000000080000238 <_l8>:
    80000238:	00010597          	auipc	a1,0x10
    8000023c:	e5858593          	addi	a1,a1,-424 # 80010090 <d_0_7>
    80000240:	0005a007          	flw	ft0,0(a1)

0000000080000244 <_l9>:
    80000244:	01092193          	slti	gp,s2,16

0000000080000248 <_l10>:
    80000248:	580601d3          	fsqrt.s	ft3,fa2,rne

000000008000024c <_l11>:
    8000024c:	29b38f53          	fmin.s	ft10,ft7,fs11

0000000080000250 <_l12>:
    80000250:	00040b97          	auipc	s7,0x40
    80000254:	ee0b8b93          	addi	s7,s7,-288 # 80040130 <d_3_17>
    80000258:	0be1                	addi	s7,s7,24
    8000025a:	08dbaa2f          	amoswap.w	s4,a3,(s7)

000000008000025e <_l13>:
    8000025e:	00060e17          	auipc	t3,0x60
    80000262:	f32e0e13          	addi	t3,t3,-206 # 80060190 <d_5_23>
    80000266:	0e41                	addi	t3,t3,16
    80000268:	00fe2f2f          	amoadd.w	t5,a5,(t3)

000000008000026c <_l14>:
    8000026c:	143ec463          	blt	t4,gp,800003b4 <_l49>

0000000080000270 <_l15>:
    80000270:	00040117          	auipc	sp,0x40
    80000274:	e1010113          	addi	sp,sp,-496 # 80040080 <d_3_6>
    80000278:	ff013a83          	ld	s5,-16(sp)

000000008000027c <_l16>:
    8000027c:	35707f73          	csrrci	t5,mireg6,0
    80000280:	87fa                	mv	a5,t5
    80000282:	c07a                	sw	t5,0(sp)

0000000080000284 <_l17>:
    80000284:	b0d13793          	sltiu	a5,sp,-1267

0000000080000288 <_l18>:
    80000288:	1211cc13          	xori	s8,gp,289

000000008000028c <_l19>:
    8000028c:	00040497          	auipc	s1,0x40
    80000290:	f3448493          	addi	s1,s1,-204 # 800401c0 <d_3_26>
    80000294:	04f1                	addi	s1,s1,28
    80000296:	41d4ac2f          	amoor.w	s8,t4,(s1)

000000008000029a <_l20>:
    8000029a:	083581d3          	fsub.s	ft3,fa1,ft3,rne

000000008000029e <_l21>:
    8000029e:	00000c97          	auipc	s9,0x0
    800002a2:	108c8c93          	addi	s9,s9,264 # 800003a6 <_l47>
    800002a6:	000c86e7          	jalr	a3,s9

00000000800002aa <_l22>:
    800002aa:	00030097          	auipc	ra,0x30
    800002ae:	e1608093          	addi	ra,ra,-490 # 800300c0 <d_2_10>
    800002b2:	8086                	mv	ra,ra
    800002b4:	c090b4af          	amominu.d	s1,s1,(ra)

00000000800002b8 <_l23>:
    800002b8:	00010897          	auipc	a7,0x10
    800002bc:	ed888893          	addi	a7,a7,-296 # 80010190 <d_0_23>
    800002c0:	0891                	addi	a7,a7,4
    800002c2:	e138a6af          	amomaxu.w	a3,s3,(a7)

00000000800002c6 <_l24>:
    800002c6:	00050917          	auipc	s2,0x50
    800002ca:	e0a90913          	addi	s2,s2,-502 # 800500d0 <d_4_11>
    800002ce:	00392e27          	fsw	ft3,28(s2)

00000000800002d2 <_l25>:
    800002d2:	00040997          	auipc	s3,0x40
    800002d6:	dfe98993          	addi	s3,s3,-514 # 800400d0 <d_3_11>
    800002da:	09e1                	addi	s3,s3,24
    800002dc:	2029bb2f          	amoxor.d	s6,sp,(s3)

00000000800002e0 <_l26>:
    800002e0:	0000100f          	fence.i

00000000800002e4 <_l27>:
    800002e4:	00050397          	auipc	t2,0x50
    800002e8:	edc38393          	addi	t2,t2,-292 # 800501c0 <d_4_26>
    800002ec:	03b1                	addi	t2,t2,12
    800002ee:	c0d3acaf          	amominu.w	s9,a3,(t2)

00000000800002f2 <_l28>:
    800002f2:	02531113          	slli	sp,t1,0x25

00000000800002f6 <_l29>:
    800002f6:	07094363          	blt	s2,a6,8000035c <_l41>

00000000800002fa <_l30>:
    800002fa:	0335d863          	bge	a1,s3,8000032a <_l35>

00000000800002fe <_l31>:
    800002fe:	4139541b          	sraiw	s0,s2,0x13

0000000080000302 <_l32>:
    80000302:	00040c97          	auipc	s9,0x40
    80000306:	e3ec8c93          	addi	s9,s9,-450 # 80040140 <d_3_18>
    8000030a:	1ca1                	addi	s9,s9,-24
    8000030c:	60bcaeaf          	amoand.w	t4,a1,(s9)

0000000080000310 <_l33>:
    80000310:	00030d97          	auipc	s11,0x30
    80000314:	d70d8d93          	addi	s11,s11,-656 # 80030080 <d_2_6>
    80000318:	ffedd403          	lhu	s0,-2(s11)

000000008000031c <_l34>:
    8000031c:	00010917          	auipc	s2,0x10
    80000320:	e7490913          	addi	s2,s2,-396 # 80010190 <d_0_23>
    80000324:	1921                	addi	s2,s2,-24
    80000326:	a1792f2f          	amomax.w	t5,s7,(s2)

000000008000032a <_l35>:
    8000032a:	00000117          	auipc	sp,0x0
    8000032e:	08e10113          	addi	sp,sp,142 # 800003b8 <_good_exit>
    80000332:	ffc16083          	lwu	ra,-4(sp)

0000000080000336 <_l36>:
    80000336:	01690ed3          	fadd.s	ft9,fs2,fs6,rne

000000008000033a <_l37>:
    8000033a:	c02589d3          	fcvt.l.s	s3,fa1,rne

000000008000033e <_l38>:
    8000033e:	00030717          	auipc	a4,0x30
    80000342:	da270713          	addi	a4,a4,-606 # 800300e0 <d_2_12>
    80000346:	01c71f03          	lh	t5,28(a4)

000000008000034a <_l39>:
    8000034a:	20cb2dd3          	fsgnjx.s	fs11,fs6,fa2

000000008000034e <_l40>:
    8000034e:	00030d17          	auipc	s10,0x30
    80000352:	da2d0d13          	addi	s10,s10,-606 # 800300f0 <d_2_13>
    80000356:	1d51                	addi	s10,s10,-12
    80000358:	81dd262f          	amomin.w	a2,t4,(s10)

000000008000035c <_l41>:
    8000035c:	00030597          	auipc	a1,0x30
    80000360:	d0458593          	addi	a1,a1,-764 # 80030060 <d_2_4>
    80000364:	15f1                	addi	a1,a1,-4
    80000366:	a0d5a52f          	amomax.w	a0,a3,(a1)

000000008000036a <_l42>:
    8000036a:	30431ff3          	csrrw	t6,mie,t1
    8000036e:	8efe                	mv	t4,t6
    80000370:	c07e                	sw	t6,0(sp)

0000000080000372 <_l43>:
    80000372:	03675a63          	bge	a4,s6,800003a6 <_l47>

0000000080000376 <_l44>:
    80000376:	00030597          	auipc	a1,0x30
    8000037a:	e0a58593          	addi	a1,a1,-502 # 80030180 <d_2_22>
    8000037e:	05a1                	addi	a1,a1,8
    80000380:	8145ac2f          	amomin.w	s8,s4,(a1)

0000000080000384 <_l45>:
    80000384:	00060297          	auipc	t0,0x60
    80000388:	d9c28293          	addi	t0,t0,-612 # 80060120 <d_5_16>
    8000038c:	ffe00ab7          	lui	s5,0xffe00
    80000390:	0152c2b3          	xor	t0,t0,s5
    80000394:	fe929323          	sh	s1,-26(t0)

0000000080000398 <_l46>:
    80000398:	00020497          	auipc	s1,0x20
    8000039c:	d7848493          	addi	s1,s1,-648 # 80020110 <d_1_15>
    800003a0:	14a1                	addi	s1,s1,-24
    800003a2:	c174af2f          	amominu.w	t5,s7,(s1)

00000000800003a6 <_l47>:
    800003a6:	30005073          	csrwi	mstatus,0
    800003aa:	f134df73          	csrrwi	t5,mimpid,9
    800003ae:	c07a                	sw	t5,0(sp)

00000000800003b0 <_l48>:
    800003b0:	c0210053          	fcvt.l.s	zero,ft2,rne

00000000800003b4 <_l49>:
    800003b4:	d90dd937          	lui	s2,0xd90dd

00000000800003b8 <_good_exit>:
    800003b8:	00002097          	auipc	ra,0x2
    800003bc:	e4808093          	addi	ra,ra,-440 # 80002200 <csr_output_data>
    800003c0:	10002173          	csrr	sp,sstatus
    800003c4:	0420bc23          	sd	sp,88(ra)
    800003c8:	10402173          	csrr	sp,sie
    800003cc:	0620b823          	sd	sp,112(ra)
    800003d0:	10502173          	csrr	sp,stvec
    800003d4:	0620bc23          	sd	sp,120(ra)
    800003d8:	10602173          	csrr	sp,scounteren
    800003dc:	0820b023          	sd	sp,128(ra)
    800003e0:	14002173          	csrr	sp,sscratch
    800003e4:	0820b423          	sd	sp,136(ra)
    800003e8:	14102173          	csrr	sp,sepc
    800003ec:	0820b823          	sd	sp,144(ra)
    800003f0:	14202173          	csrr	sp,scause
    800003f4:	0820bc23          	sd	sp,152(ra)
    800003f8:	14302173          	csrr	sp,stval
    800003fc:	0a20b023          	sd	sp,160(ra)
    80000400:	14402173          	csrr	sp,sip
    80000404:	f7f17113          	andi	sp,sp,-129
    80000408:	0a20b423          	sd	sp,168(ra)
    8000040c:	18002173          	csrr	sp,satp
    80000410:	0a20b823          	sd	sp,176(ra)
    80000414:	f1402173          	csrr	sp,mhartid
    80000418:	0a20bc23          	sd	sp,184(ra)
    8000041c:	30002173          	csrr	sp,mstatus
    80000420:	0c20b023          	sd	sp,192(ra)
    80000424:	30202173          	csrr	sp,medeleg
    80000428:	0c20b423          	sd	sp,200(ra)
    8000042c:	30302173          	csrr	sp,mideleg
    80000430:	0c20b823          	sd	sp,208(ra)
    80000434:	30402173          	csrr	sp,mie
    80000438:	0c20bc23          	sd	sp,216(ra)
    8000043c:	30502173          	csrr	sp,mtvec
    80000440:	0e20b023          	sd	sp,224(ra)
    80000444:	30602173          	csrr	sp,mcounteren
    80000448:	0e20b423          	sd	sp,232(ra)
    8000044c:	34002173          	csrr	sp,mscratch
    80000450:	0e20b823          	sd	sp,240(ra)
    80000454:	34102173          	csrr	sp,mepc
    80000458:	0e20bc23          	sd	sp,248(ra)
    8000045c:	34202173          	csrr	sp,mcause
    80000460:	1020b023          	sd	sp,256(ra)
    80000464:	34302173          	csrr	sp,mtval
    80000468:	1020b423          	sd	sp,264(ra)
    8000046c:	34402173          	csrr	sp,mip
    80000470:	f7f17113          	andi	sp,sp,-129
    80000474:	1020b823          	sd	sp,272(ra)
    80000478:	3a002173          	csrr	sp,pmpcfg0
    8000047c:	1020bc23          	sd	sp,280(ra)
    80000480:	3b002173          	csrr	sp,pmpaddr0
    80000484:	1220bc23          	sd	sp,312(ra)
    80000488:	3b102173          	csrr	sp,pmpaddr1
    8000048c:	1420b023          	sd	sp,320(ra)
    80000490:	3b202173          	csrr	sp,pmpaddr2
    80000494:	1420b423          	sd	sp,328(ra)
    80000498:	3b302173          	csrr	sp,pmpaddr3
    8000049c:	1420b823          	sd	sp,336(ra)
    800004a0:	3b402173          	csrr	sp,pmpaddr4
    800004a4:	1420bc23          	sd	sp,344(ra)
    800004a8:	3b502173          	csrr	sp,pmpaddr5
    800004ac:	1620b023          	sd	sp,352(ra)
    800004b0:	3b602173          	csrr	sp,pmpaddr6
    800004b4:	1620b423          	sd	sp,360(ra)
    800004b8:	3b702173          	csrr	sp,pmpaddr7
    800004bc:	1620b823          	sd	sp,368(ra)
    800004c0:	6519                	lui	a0,0x6
    800004c2:	30052073          	csrs	mstatus,a0

00000000800004c6 <fcsrs_dump>:
    800004c6:	00102173          	frflags	sp
    800004ca:	0420b023          	sd	sp,64(ra)
    800004ce:	00202173          	frrm	sp
    800004d2:	0420b423          	sd	sp,72(ra)
    800004d6:	00302173          	frcsr	sp
    800004da:	0420b823          	sd	sp,80(ra)

00000000800004de <reg_dump>:
    800004de:	00002097          	auipc	ra,0x2
    800004e2:	b2208093          	addi	ra,ra,-1246 # 80002000 <begin_signature>
    800004e6:	0000b023          	sd	zero,0(ra)
    800004ea:	0020b823          	sd	sp,16(ra)
    800004ee:	0030bc23          	sd	gp,24(ra)
    800004f2:	0240b023          	sd	tp,32(ra)
    800004f6:	0250b423          	sd	t0,40(ra)
    800004fa:	0260b823          	sd	t1,48(ra)
    800004fe:	0270bc23          	sd	t2,56(ra)
    80000502:	0480b023          	sd	s0,64(ra)
    80000506:	0490b423          	sd	s1,72(ra)
    8000050a:	04a0b823          	sd	a0,80(ra)
    8000050e:	04b0bc23          	sd	a1,88(ra)
    80000512:	06c0b023          	sd	a2,96(ra)
    80000516:	06d0b423          	sd	a3,104(ra)
    8000051a:	06e0b823          	sd	a4,112(ra)
    8000051e:	06f0bc23          	sd	a5,120(ra)
    80000522:	0900b023          	sd	a6,128(ra)
    80000526:	0910b423          	sd	a7,136(ra)
    8000052a:	0920b823          	sd	s2,144(ra)
    8000052e:	0930bc23          	sd	s3,152(ra)
    80000532:	0b40b023          	sd	s4,160(ra)
    80000536:	0b50b423          	sd	s5,168(ra)
    8000053a:	0b60b823          	sd	s6,176(ra)
    8000053e:	0b70bc23          	sd	s7,184(ra)
    80000542:	0d80b023          	sd	s8,192(ra)
    80000546:	0d90b423          	sd	s9,200(ra)
    8000054a:	0db0bc23          	sd	s11,216(ra)
    8000054e:	0fc0b023          	sd	t3,224(ra)
    80000552:	0fd0b423          	sd	t4,232(ra)
    80000556:	0fe0b823          	sd	t5,240(ra)

000000008000055a <freg_dump>:
    8000055a:	00002097          	auipc	ra,0x2
    8000055e:	ba608093          	addi	ra,ra,-1114 # 80002100 <freg_output_data>
    80000562:	0010a427          	fsw	ft1,8(ra)
    80000566:	0020a827          	fsw	ft2,16(ra)
    8000056a:	0270ac27          	fsw	ft7,56(ra)
    8000056e:	0490a427          	fsw	fs1,72(ra)
    80000572:	04a0a827          	fsw	fa0,80(ra)
    80000576:	06c0a027          	fsw	fa2,96(ra)
    8000057a:	06d0a427          	fsw	fa3,104(ra)
    8000057e:	0b50a427          	fsw	fs5,168(ra)
    80000582:	0b60a827          	fsw	fs6,176(ra)
    80000586:	0d90a427          	fsw	fs9,200(ra)
    8000058a:	0da0a827          	fsw	fs10,208(ra)
    8000058e:	0fc0a027          	fsw	ft8,224(ra)
    80000592:	0fd0a427          	fsw	ft9,232(ra)
    80000596:	0fe0a827          	fsw	ft10,240(ra)
    8000059a:	0ff0ac27          	fsw	ft11,248(ra)
    8000059e:	00002097          	auipc	ra,0x2
    800005a2:	b6208093          	addi	ra,ra,-1182 # 80002100 <freg_output_data>
    800005a6:	0000b027          	fsd	ft0,0(ra)
    800005aa:	0030bc27          	fsd	ft3,24(ra)
    800005ae:	0240b027          	fsd	ft4,32(ra)
    800005b2:	0250b427          	fsd	ft5,40(ra)
    800005b6:	0260b827          	fsd	ft6,48(ra)
    800005ba:	0480b027          	fsd	fs0,64(ra)
    800005be:	04b0bc27          	fsd	fa1,88(ra)
    800005c2:	06e0b827          	fsd	fa4,112(ra)
    800005c6:	06f0bc27          	fsd	fa5,120(ra)
    800005ca:	0900b027          	fsd	fa6,128(ra)
    800005ce:	0910b427          	fsd	fa7,136(ra)
    800005d2:	0920b827          	fsd	fs2,144(ra)
    800005d6:	0930bc27          	fsd	fs3,152(ra)
    800005da:	0b40b027          	fsd	fs4,160(ra)
    800005de:	0b70bc27          	fsd	fs7,184(ra)
    800005e2:	0d80b027          	fsd	fs8,192(ra)
    800005e6:	0db0bc27          	fsd	fs11,216(ra)
    800005ea:	4501                	li	a0,0
    800005ec:	0005006b          	.insn	4, 0x0005006b
    800005f0:	4185                	li	gp,1
    800005f2:	00001f17          	auipc	t5,0x1
    800005f6:	a03f2723          	sw	gp,-1522(t5) # 80001000 <tohost>
    800005fa:	a001                	j	800005fa <freg_dump+0xa0>

00000000800005fc <_end_main>:
	...
    8000060c:	00000013          	nop
    80000610:	00000013          	nop
    80000614:	00000013          	nop
    80000618:	00000013          	nop
    8000061c:	00000013          	nop
    80000620:	00000013          	nop
    80000624:	00000013          	nop
    80000628:	00000013          	nop
    8000062c:	00000013          	nop
    80000630:	00000013          	nop
    80000634:	00000013          	nop
    80000638:	00000013          	nop
    8000063c:	00000013          	nop
    80000640:	00000013          	nop
    80000644:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	7475                	lui	s0,0xffffd
    80010002:	dc666807          	.insn	4, 0xdc666807
    80010006:	b0870efb          	.insn	4, 0xb0870efb
    8001000a:	fbbb232b          	.insn	4, 0xfbbb232b
    8001000e:	fb7f                	.insn	2, 0xfb7f
    80010010:	8eaa                	mv	t4,a0
    80010012:	87ff b950 a4c9 4b71 	.insn	10, 0x0bc04b71a4c9b95087ff
    8001001a:	0bc0 
    8001001c:	d2ae                	sw	a1,100(sp)
    8001001e:	7412                	ld	s0,288(sp)

0000000080010020 <d_0_0>:
    80010020:	2e747d2f          	.insn	4, 0x2e747d2f
    80010024:	5f11                	li	t5,-28
    80010026:	ec28                	sd	a0,88(s0)
    80010028:	ccdc                	sw	a5,28(s1)
    8001002a:	ff67f58b          	.insn	4, 0xff67f58b
    8001002e:	e5e5                	bnez	a1,80010116 <d_0_15+0x6>

0000000080010030 <d_0_1>:
    80010030:	22c8                	fld	fa0,128(a3)
    80010032:	0192                	slli	gp,gp,0x4
    80010034:	7252                	ld	tp,304(sp)
    80010036:	6580                	ld	s0,8(a1)
    80010038:	5ee75517          	auipc	a0,0x5ee75
    8001003c:	81b35393          	.insn	4, 0x81b35393

0000000080010040 <d_0_2>:
    80010040:	deba                	sw	a4,124(sp)
    80010042:	ee86                	sd	ra,344(sp)
    80010044:	02f6                	slli	t0,t0,0x1d
    80010046:	8fdd                	or	a5,a5,a5
    80010048:	fe35                	bnez	a2,8000ffc4 <end_signature+0xdbe4>
    8001004a:	2a5f4cbb          	.insn	4, 0x2a5f4cbb
    8001004e:	bfc5                	j	8001003e <d_0_1+0xe>

0000000080010050 <d_0_3>:
    80010050:	dcfd                	beqz	s1,8001004e <d_0_2+0xe>
    80010052:	3031                	.insn	2, 0x3031
    80010054:	a9c0                	fsd	fs0,144(a1)
    80010056:	c705                	beqz	a4,8001007e <d_0_5+0xe>
    80010058:	39c1                	addiw	s3,s3,-16
    8001005a:	f168                	sd	a0,224(a0)
    8001005c:	4bd4                	lw	a3,20(a5)
    8001005e:	          	fnmsub.d	fs0,fa0,fs11,fa7,unknown

0000000080010060 <d_0_4>:
    80010060:	8bb5                	andi	a5,a5,13
    80010062:	a676                	fsd	ft9,264(sp)
    80010064:	ea79                	bnez	a2,8001013a <d_0_17+0xa>
    80010066:	a855bc17          	auipc	s8,0xa855b
    8001006a:	b9da117b          	.insn	4, 0xb9da117b
    8001006e:	994c                	.insn	2, 0x994c

0000000080010070 <d_0_5>:
    80010070:	001751d7          	vfadd.vf	v3,v1,fa4,v0.t
    80010074:	46f9                	li	a3,30
    80010076:	65bfe62b          	.insn	4, 0x65bfe62b
    8001007a:	5e6e                	lw	t3,248(sp)
    8001007c:	181c186f          	jal	a6,800d19fc <_end+0x717fc>

0000000080010080 <d_0_6>:
    80010080:	76569d27          	.insn	4, 0x76569d27
    80010084:	3c81                	addiw	s9,s9,-32
    80010086:	9db4bc3f 48be229d 	.insn	8, 0x48be229d9db4bc3f
    8001008e:	ab96                	fsd	ft5,464(sp)

0000000080010090 <d_0_7>:
    80010090:	e99f a251 3f44      	.insn	6, 0x3f44a251e99f
    80010096:	9694ebbf 6a030f7d 	.insn	8, 0x6a030f7d9694ebbf
    8001009e:	          	.insn	4, 0x10e9bbd7

00000000800100a0 <d_0_8>:
    800100a0:	10e9                	addi	ra,ra,-6
    800100a2:	d8cd                	beqz	s1,80010054 <d_0_3+0x4>
    800100a4:	61d4                	ld	a3,128(a1)
    800100a6:	9228a01b          	.insn	4, 0x9228a01b
    800100aa:	c93e                	sw	a5,144(sp)
    800100ac:	cf49                	beqz	a4,80010146 <d_0_18+0x6>
    800100ae:	          	fnmsub.d	fs8,fa1,fs5,fs1,rne

00000000800100b0 <d_0_9>:
    800100b0:	4b55                	li	s6,21
    800100b2:	2d55                	addiw	s10,s10,21
    800100b4:	1319                	addi	t1,t1,-26
    800100b6:	e3b2                	sd	a2,448(sp)
    800100b8:	d1d5                	beqz	a1,8001005c <d_0_3+0xc>
    800100ba:	b7bc                	fsd	fa5,104(a5)
    800100bc:	f2277923          	.insn	4, 0xf2277923

00000000800100c0 <d_0_10>:
    800100c0:	d308                	sw	a0,32(a4)
    800100c2:	fef1                	bnez	a3,8001009e <d_0_7+0xe>
    800100c4:	1096                	slli	ra,ra,0x25
    800100c6:	c4f5                	beqz	s1,800101b2 <d_0_25+0x2>
    800100c8:	3b21f0bb          	.insn	4, 0x3b21f0bb
    800100cc:	3618                	fld	fa4,40(a2)
    800100ce:	7ab2                	ld	s5,296(sp)

00000000800100d0 <d_0_11>:
    800100d0:	ef39bc13          	sltiu	s8,s3,-269
    800100d4:	b0e9                	j	8000f99e <end_signature+0xd5be>
    800100d6:	f156                	sd	s5,160(sp)
    800100d8:	e589                	bnez	a1,800100e2 <d_0_12+0x2>
    800100da:	7f01                	lui	t5,0xfffe0
    800100dc:	af5a                	fsd	fs6,408(sp)
    800100de:	          	vssseg8e16.v	v16,(s5),s1,v0.t

00000000800100e0 <d_0_12>:
    800100e0:	e89a                	sd	t1,80(sp)
    800100e2:	1aa6                	slli	s5,s5,0x29
    800100e4:	2e0e                	fld	ft8,192(sp)
    800100e6:	4b6a                	lw	s6,152(sp)
    800100e8:	e6d0                	sd	a2,136(a3)
    800100ea:	44b0a66b          	.insn	4, 0x44b0a66b
    800100ee:	6bea                	ld	s7,152(sp)

00000000800100f0 <d_0_13>:
    800100f0:	93c9                	srli	a5,a5,0x32
    800100f2:	10b1                	addi	ra,ra,-20
    800100f4:	d745                	beqz	a4,8001009c <d_0_7+0xc>
    800100f6:	a490                	fsd	fa2,8(s1)
    800100f8:	08ba                	slli	a7,a7,0xe
    800100fa:	33c22ef7          	.insn	4, 0x33c22ef7
    800100fe:	7a2e                	ld	s4,232(sp)

0000000080010100 <d_0_14>:
    80010100:	111c                	addi	a5,sp,160
    80010102:	56141be3          	bne	s0,ra,80010e78 <_end_data0+0xc78>
    80010106:	41bf6aa3          	.insn	4, 0x41bf6aa3
    8001010a:	2c36                	fld	fs8,328(sp)
    8001010c:	d4ae                	sw	a1,104(sp)
    8001010e:	ac7c                	fsd	fa5,216(s0)

0000000080010110 <d_0_15>:
    80010110:	6df1125b          	.insn	4, 0x6df1125b
    80010114:	313d                	addiw	sp,sp,-17
    80010116:	bf4e                	fsd	fs3,440(sp)
    80010118:	d9a9                	beqz	a1,8001006a <d_0_4+0xa>
    8001011a:	72a0b7f3          	csrrc	a5,mhpmevent10h,ra
    8001011e:	0a21                	addi	s4,s4,8

0000000080010120 <d_0_16>:
    80010120:	134f48f7          	.insn	4, 0x134f48f7
    80010124:	909163af          	.insn	4, 0x909163af
    80010128:	101c                	addi	a5,sp,32
    8001012a:	9564                	.insn	2, 0x9564
    8001012c:	26032243          	.insn	4, 0x26032243

0000000080010130 <d_0_17>:
    80010130:	a58d                	j	80010792 <_end_data0+0x592>
    80010132:	caa1                	beqz	a3,80010182 <d_0_22+0x2>
    80010134:	63ba                	ld	t2,392(sp)
    80010136:	9ccf08cf          	.insn	4, 0x9ccf08cf
    8001013a:	3086                	fld	ft1,96(sp)
    8001013c:	752e5927          	.insn	4, 0x752e5927

0000000080010140 <d_0_18>:
    80010140:	d9dd                	beqz	a1,800100f6 <d_0_13+0x6>
    80010142:	4b46a413          	slti	s0,a3,1204
    80010146:	c795                	beqz	a5,80010172 <d_0_21+0x2>
    80010148:	b7c4                	fsd	fs1,168(a5)
    8001014a:	adc60423          	sb	t3,-1336(a2)
    8001014e:	          	.insn	4, 0x772d915b

0000000080010150 <d_0_19>:
    80010150:	772d                	lui	a4,0xfffeb
    80010152:	ac5f c6af f00a      	.insn	6, 0xf00ac6afac5f
    80010158:	58dd                	li	a7,-9
    8001015a:	e9ec                	sd	a1,208(a1)
    8001015c:	42ba                	lw	t0,140(sp)
    8001015e:	8e2c                	.insn	2, 0x8e2c

0000000080010160 <d_0_20>:
    80010160:	6eb9                	lui	t4,0xe
    80010162:	09d2                	slli	s3,s3,0x14
    80010164:	7a51                	lui	s4,0xffff4
    80010166:	ab48                	fsd	fa0,144(a4)
    80010168:	fcae                	sd	a1,120(sp)
    8001016a:	c93c69f7          	.insn	4, 0xc93c69f7
    8001016e:	221c                	fld	fa5,0(a2)

0000000080010170 <d_0_21>:
    80010170:	5e18                	lw	a4,56(a2)
    80010172:	f5a1                	bnez	a1,800100ba <d_0_9+0xa>
    80010174:	b692                	fsd	ft4,360(sp)
    80010176:	07de                	slli	a5,a5,0x17
    80010178:	902e                	c.add	zero,a1
    8001017a:	5851                	li	a6,-12
    8001017c:	c0ac                	sw	a1,64(s1)
    8001017e:	9e5e                	add	t3,t3,s7

0000000080010180 <d_0_22>:
    80010180:	48d9                	li	a7,22
    80010182:	defe                	sw	t6,124(sp)
    80010184:	9221                	srli	a2,a2,0x28
    80010186:	6da0                	ld	s0,88(a1)
    80010188:	e7574a33          	.insn	4, 0xe7574a33
    8001018c:	03fc                	addi	a5,sp,460
    8001018e:	          	jalr	a2,-599(t4) # dda9 <_start-0x7fff2257>

0000000080010190 <d_0_23>:
    80010190:	da9e                	sw	t2,116(sp)
    80010192:	d57a                	sw	t5,168(sp)
    80010194:	c9e9                	beqz	a1,80010266 <_end_data0+0x66>
    80010196:	8d70ad43          	.insn	4, 0x8d70ad43
    8001019a:	fdfd                	bnez	a1,80010198 <d_0_23+0x8>
    8001019c:	5218                	lw	a4,32(a2)
    8001019e:	          	fld	ft0,1614(s3)

00000000800101a0 <d_0_24>:
    800101a0:	64e9                	lui	s1,0x1a
    800101a2:	3926                	fld	fs2,104(sp)
    800101a4:	75e5                	lui	a1,0xffff9
    800101a6:	86d5                	srai	a3,a3,0x15
    800101a8:	0c2d                	addi	s8,s8,11 # 2856b071 <_start-0x57a94f8f>
    800101aa:	fcc3858f          	.insn	4, 0xfcc3858f
    800101ae:	9958                	.insn	2, 0x9958

00000000800101b0 <d_0_25>:
    800101b0:	d9d6                	sw	s5,240(sp)
    800101b2:	6f88ac47          	.insn	4, 0x6f88ac47
    800101b6:	d876                	sw	t4,48(sp)
    800101b8:	2ac99e6f          	jal	t3,800a9464 <_end+0x49264>
    800101bc:	c015                	beqz	s0,800101e0 <d_0_27+0x10>
    800101be:	2590                	fld	fa2,8(a1)

00000000800101c0 <d_0_26>:
    800101c0:	be8b9b2b          	.insn	4, 0xbe8b9b2b
    800101c4:	b354c29b          	.insn	4, 0xb354c29b
    800101c8:	1c82                	slli	s9,s9,0x20
    800101ca:	ba79                	j	8000fb68 <end_signature+0xd788>
    800101cc:	fa36                	sd	a3,304(sp)
    800101ce:	f1f8                	sd	a4,224(a1)

00000000800101d0 <d_0_27>:
    800101d0:	471e                	lw	a4,196(sp)
    800101d2:	03ca                	slli	t2,t2,0x12
    800101d4:	fcfe6af7          	.insn	4, 0xfcfe6af7
    800101d8:	a62c                	fsd	fa1,72(a2)
    800101da:	5726                	lw	a4,104(sp)
    800101dc:	e9caa72b          	.insn	4, 0xe9caa72b
    800101e0:	30d9                	addiw	ra,ra,-10
    800101e2:	8471                	srai	s0,s0,0x1c
    800101e4:	2f7d6203          	lwu	tp,759(s10)
    800101e8:	0fa5                	addi	t6,t6,9
    800101ea:	48d1                	li	a7,20
    800101ec:	3aea                	fld	fs5,184(sp)
    800101ee:	2a54                	fld	fa3,144(a2)
    800101f0:	a8c0                	fsd	fs0,144(s1)
    800101f2:	6b09a0e7          	.insn	4, 0x6b09a0e7
    800101f6:	5055                	c.li	zero,-11
    800101f8:	e4d4                	sd	a3,136(s1)
    800101fa:	658c8a87          	vluxseg4ei8.v	v21,(s9),v24,v0.t
    800101fe:	0c6e                	slli	s8,s8,0x1b

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	5b0e                	lw	s6,224(sp)
    80020002:	51a0                	lw	s0,96(a1)
    80020004:	c275                	beqz	a2,800200e8 <d_1_12+0x8>
    80020006:	9bacc8b7          	lui	a7,0x9bacc
    8002000a:	b7f5                	j	8001fff6 <_end_data0+0xfdf6>
    8002000c:	ffd1                	bnez	a5,8001ffa8 <_end_data0+0xfda8>
    8002000e:	d6cc                	sw	a1,44(a3)
    80020010:	6ab9                	lui	s5,0xe
    80020012:	1126                	slli	sp,sp,0x29
    80020014:	d239c77b          	.insn	4, 0xd239c77b
    80020018:	dc40                	sw	s0,60(s0)
    8002001a:	aac5                	j	8002020a <_end_data1+0xa>
    8002001c:	ddd0                	sw	a2,60(a1)
    8002001e:	  	.insn	8, 0x2d240a555883a63f

0000000080020020 <d_1_0>:
    80020020:	0a555883          	lhu	a7,165(a0) # dee850dd <_end+0x5ee24edd>
    80020024:	2d24                	fld	fs1,88(a0)
    80020026:	df32                	sw	a2,188(sp)
    80020028:	0d957443          	.insn	4, 0x0d957443
    8002002c:	6d35                	lui	s10,0xd
    8002002e:	c3e9                	beqz	a5,800200f0 <d_1_13>

0000000080020030 <d_1_1>:
    80020030:	e699                	bnez	a3,8002003e <d_1_1+0xe>
    80020032:	1f1e                	slli	t5,t5,0x27
    80020034:	fe9f 7e1c c118      	.insn	6, 0xc1187e1cfe9f
    8002003a:	ced0                	sw	a2,28(a3)
    8002003c:	593a                	lw	s2,172(sp)
    8002003e:	          	csrrsi	gp,0x700,31

0000000080020040 <d_1_2>:
    80020040:	5ded700f          	.insn	4, 0x5ded700f
    80020044:	6c9d                	lui	s9,0x7
    80020046:	c3e4                	sw	s1,68(a5)
    80020048:	9925                	andi	a0,a0,-23
    8002004a:	91bd                	srli	a1,a1,0x2f
    8002004c:	3c6a                	fld	fs8,184(sp)
    8002004e:	d762                	sw	s8,172(sp)

0000000080020050 <d_1_3>:
    80020050:	c555                	beqz	a0,800200fc <d_1_13+0xc>
    80020052:	1acc                	addi	a1,sp,372
    80020054:	d4ed                	beqz	s1,8002003e <d_1_1+0xe>
    80020056:	645d                	lui	s0,0x17
    80020058:	9955                	andi	a0,a0,-11
    8002005a:	b1bd                	j	8001fcc8 <_end_data0+0xfac8>
    8002005c:	444e                	lw	s0,208(sp)
    8002005e:	b61c                	fsd	fa5,40(a2)

0000000080020060 <d_1_4>:
    80020060:	7a27a6af          	.insn	4, 0x7a27a6af
    80020064:	47010d3b          	.insn	4, 0x47010d3b
    80020068:	3320                	fld	fs0,96(a4)
    8002006a:	4f4d                	li	t5,19
    8002006c:	7fc2                	ld	t6,48(sp)
    8002006e:	7b54                	ld	a3,176(a4)

0000000080020070 <d_1_5>:
    80020070:	dbf9                	beqz	a5,80020046 <d_1_2+0x6>
    80020072:	6318                	ld	a4,0(a4)
    80020074:	ccd6                	sw	s5,88(sp)
    80020076:	ecc1                	bnez	s1,8002010e <d_1_14+0xe>
    80020078:	859eabbf 8958e82f 	.insn	8, 0x8958e82f859eabbf

0000000080020080 <d_1_6>:
    80020080:	4e9f 559d 2557      	.insn	6, 0x2557559d4e9f
    80020086:	26fd71bb          	.insn	4, 0x26fd71bb
    8002008a:	b656                	fsd	fs5,296(sp)
    8002008c:	5202e52b          	.insn	4, 0x5202e52b

0000000080020090 <d_1_7>:
    80020090:	615a                	ld	sp,400(sp)
    80020092:	9eb0                	.insn	2, 0x9eb0
    80020094:	3a45                	addiw	s4,s4,-15 # ffffffffffff3ff1 <_end+0xffffffff7ff93df1>
    80020096:	dadfaea7          	fsw	fa3,-579(t6)
    8002009a:	7d3a                	ld	s10,424(sp)
    8002009c:	aa698923          	sb	t1,-1358(s3)

00000000800200a0 <d_1_8>:
    800200a0:	b74a                	fsd	fs2,424(sp)
    800200a2:	440a                	lw	s0,128(sp)
    800200a4:	b56e                	fsd	fs11,168(sp)
    800200a6:	95a5                	srai	a1,a1,0x29
    800200a8:	9e6df3cb          	.insn	4, 0x9e6df3cb
    800200ac:	d971                	beqz	a0,80020080 <d_1_6>
    800200ae:	b98e                	fsd	ft3,240(sp)

00000000800200b0 <d_1_9>:
    800200b0:	c46c                	sw	a1,76(s0)
    800200b2:	f97f                	.insn	2, 0xf97f
    800200b4:	0e25                	addi	t3,t3,9
    800200b6:	7160                	ld	s0,224(a0)
    800200b8:	ac22                	fsd	fs0,24(sp)
    800200ba:	fb26                	sd	s1,432(sp)
    800200bc:	65d6                	ld	a1,336(sp)
    800200be:	3550                	fld	fa2,168(a0)

00000000800200c0 <d_1_10>:
    800200c0:	fd104e0b          	.insn	4, 0xfd104e0b
    800200c4:	a90d                	j	800204f6 <_end_data1+0x2f6>
    800200c6:	0e1e7ccb          	.insn	4, 0x0e1e7ccb
    800200ca:	eae86377          	.insn	4, 0xeae86377
    800200ce:	3964                	fld	fs1,240(a0)

00000000800200d0 <d_1_11>:
    800200d0:	a9be                	fsd	fa5,208(sp)
    800200d2:	4ffd544b          	.insn	4, 0x4ffd544b
    800200d6:	f8f2                	sd	t3,112(sp)
    800200d8:	68de                	ld	a7,464(sp)
    800200da:	7b1d                	lui	s6,0xfffe7
    800200dc:	a8e1a923          	sw	a4,-1390(gp)

00000000800200e0 <d_1_12>:
    800200e0:	1d16                	slli	s10,s10,0x25
    800200e2:	09f2                	slli	s3,s3,0x1c
    800200e4:	5fa6                	lw	t6,104(sp)
    800200e6:	5984                	lw	s1,48(a1)
    800200e8:	85dc                	.insn	2, 0x85dc
    800200ea:	1a72                	slli	s4,s4,0x3c
    800200ec:	1e52                	slli	t3,t3,0x34
    800200ee:	0946                	slli	s2,s2,0x11

00000000800200f0 <d_1_13>:
    800200f0:	2085                	addiw	ra,ra,1
    800200f2:	5e9c                	lw	a5,56(a3)
    800200f4:	0561                	addi	a0,a0,24
    800200f6:	20be                	fld	ft1,456(sp)
    800200f8:	26d4                	fld	fa3,136(a3)
    800200fa:	a6c4                	fsd	fs1,136(a3)
    800200fc:	0f90                	addi	a2,sp,976
    800200fe:	          	.insn	4, 0x2b490ab3

0000000080020100 <d_1_14>:
    80020100:	2b49                	addiw	s6,s6,18 # fffffffffffe7012 <_end+0xffffffff7ff86e12>
    80020102:	1b2cdd23          	.insn	4, 0x1b2cdd23
    80020106:	b095                	j	8001f96a <_end_data0+0xf76a>
    80020108:	5e61                	li	t3,-8
    8002010a:	f46e                	sd	s11,40(sp)
    8002010c:	a994                	fsd	fa3,16(a1)
    8002010e:	a141                	j	8002058e <_end_data1+0x38e>

0000000080020110 <d_1_15>:
    80020110:	31b5a993          	slti	s3,a1,795
    80020114:	2cf0                	fld	fa2,216(s1)
    80020116:	b244                	fsd	fs1,160(a2)
    80020118:	37ae                	fld	fa5,232(sp)
    8002011a:	027f cb97 56ee  	.insn	10, 0x722efe9956eecb97027f
    80020122:	 

0000000080020120 <d_1_16>:
    80020120:	fe99                	bnez	a3,8002003e <d_1_1+0xe>
    80020122:	722e                	ld	tp,232(sp)
    80020124:	8965                	andi	a0,a0,25
    80020126:	fba9                	bnez	a5,80020078 <d_1_5+0x8>
    80020128:	c9db8d83          	lb	s11,-867(s7)
    8002012c:	5348                	lw	a0,36(a4)
    8002012e:	          	.insn	4, 0x106dc6f3

0000000080020130 <d_1_17>:
    80020130:	106d                	c.nop	-5
    80020132:	a11c                	fsd	fa5,0(a0)
    80020134:	20fc                	fld	fa5,192(s1)
    80020136:	1cdc                	addi	a5,sp,628
    80020138:	d7be                	sw	a5,236(sp)
    8002013a:	26b6                	fld	fa3,328(sp)
    8002013c:	83962a03          	lw	s4,-1991(a2)

0000000080020140 <d_1_18>:
    80020140:	3349                	addiw	t1,t1,-14
    80020142:	aa03dfef          	jal	t6,7ff5d3e2 <_start-0xa2c1e>
    80020146:	cf6d                	beqz	a4,80020240 <_end_data1+0x40>
    80020148:	349f 93fd 5643      	.insn	6, 0x564393fd349f
    8002014e:	8214                	.insn	2, 0x8214

0000000080020150 <d_1_19>:
    80020150:	fa06                	sd	ra,304(sp)
    80020152:	4b7f5db7          	lui	s11,0x4b7f5
    80020156:	dd0d                	beqz	a0,80020090 <d_1_7>
    80020158:	56bc615b          	.insn	4, 0x56bc615b
    8002015c:	a576                	fsd	ft9,136(sp)
    8002015e:	1c19                	addi	s8,s8,-26

0000000080020160 <d_1_20>:
    80020160:	ddf4                	sw	a3,124(a1)
    80020162:	e974                	sd	a3,208(a0)
    80020164:	ed79                	bnez	a0,80020242 <_end_data1+0x42>
    80020166:	e140                	sd	s0,128(a0)
    80020168:	eca8                	sd	a0,88(s1)
    8002016a:	c935                	beqz	a0,800201de <d_1_27+0xe>
    8002016c:	6aea                	ld	s5,152(sp)
    8002016e:	1598                	addi	a4,sp,736

0000000080020170 <d_1_21>:
    80020170:	0e1a                	slli	t3,t3,0x6
    80020172:	0ced                	addi	s9,s9,27 # 701b <_start-0x7fff8fe5>
    80020174:	2ab8                	fld	fa4,80(a3)
    80020176:	7dda                	ld	s11,432(sp)
    80020178:	ca4019bf c65d6715 	.insn	8, 0xc65d6715ca4019bf

0000000080020180 <d_1_22>:
    80020180:	273dff0b          	.insn	4, 0x273dff0b
    80020184:	10d5                	addi	ra,ra,-11
    80020186:	e780                	sd	s0,8(a5)
    80020188:	7140b04f          	fnmadd.s	ft0,ft1,fs4,fa4,rup
    8002018c:	268d4597          	auipc	a1,0x268d4

0000000080020190 <d_1_23>:
    80020190:	405f b930 d599      	.insn	6, 0xd599b930405f
    80020196:	b3e1                	j	8001ff5e <_end_data0+0xfd5e>
    80020198:	7765                	lui	a4,0xffff9
    8002019a:	7518                	ld	a4,40(a0)
    8002019c:	6a8c                	ld	a1,16(a3)
    8002019e:	          	.insn	4, 0xc7aa6f77

00000000800201a0 <d_1_24>:
    800201a0:	c7aa                	sw	a0,204(sp)
    800201a2:	f3c5                	bnez	a5,80020142 <d_1_18+0x2>
    800201a4:	4676                	lw	a2,92(sp)
    800201a6:	3b20                	fld	fs0,112(a4)
    800201a8:	e5f4                	sd	a3,200(a1)
    800201aa:	8480                	.insn	2, 0x8480
    800201ac:	c53d                	beqz	a0,8002021a <_end_data1+0x1a>
    800201ae:	7225                	lui	tp,0xfffe9

00000000800201b0 <d_1_25>:
    800201b0:	778e                	ld	a5,224(sp)
    800201b2:	eb24                	sd	s1,80(a4)
    800201b4:	2174                	fld	fa3,192(a0)
    800201b6:	477a                	lw	a4,156(sp)
    800201b8:	8eeb104f          	.insn	4, 0x8eeb104f
    800201bc:	c6f5                	beqz	a3,800202a8 <_end_data1+0xa8>
    800201be:	4abe                	lw	s5,204(sp)

00000000800201c0 <d_1_26>:
    800201c0:	d45d                	beqz	s0,8002016e <d_1_20+0xe>
    800201c2:	efbc                	sd	a5,88(a5)
    800201c4:	5b51                	li	s6,-12
    800201c6:	7984                	ld	s1,48(a1)
    800201c8:	1220                	addi	s0,sp,296
    800201ca:	5308                	lw	a0,32(a4)
    800201cc:	81f5                	srli	a1,a1,0x1d
    800201ce:	9b2e                	add	s6,s6,a1

00000000800201d0 <d_1_27>:
    800201d0:	9d088023          	sb	a6,-1600(a7) # ffffffff9bacb9c0 <_end+0xffffffff1ba6b7c0>
    800201d4:	3adde047          	fmsub.d	ft0,fs11,fa3,ft7,unknown
    800201d8:	8350                	.insn	2, 0x8350
    800201da:	b545592b          	.insn	4, 0xb545592b
    800201de:	d7bd                	beqz	a5,8002014c <d_1_18+0xc>
    800201e0:	fdde                	sd	s7,248(sp)
    800201e2:	d7e4                	sw	s1,108(a5)
    800201e4:	7596                	ld	a1,352(sp)
    800201e6:	74d5                	lui	s1,0xffff5
    800201e8:	3c8a                	fld	fs9,160(sp)
    800201ea:	94c9                	srai	s1,s1,0x32
    800201ec:	d252                	sw	s4,36(sp)
    800201ee:	49ba                	lw	s3,140(sp)
    800201f0:	fc3e3f6f          	jal	t5,800041b2 <end_signature+0x1dd2>
    800201f4:	0025                	c.nop	9
    800201f6:	663d                	lui	a2,0xf
    800201f8:	1a7c                	addi	a5,sp,316
    800201fa:	ed49                	bnez	a0,80020294 <_end_data1+0x94>
    800201fc:	e6058767          	jalr	a4,-416(a1) # a68f3fec <_end+0x26893dec>

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	39a1                	addiw	s3,s3,-24
    80030002:	03f1                	addi	t2,t2,28
    80030004:	6ca9                	lui	s9,0xa
    80030006:	a718ef8f          	.insn	4, 0xa718ef8f
    8003000a:	c084                	sw	s1,0(s1)
    8003000c:	a51c                	fsd	fa5,8(a0)
    8003000e:	ab7a                	fsd	ft10,400(sp)
    80030010:	ba4c                	fsd	fa1,176(a2)
    80030012:	8862                	mv	a6,s8
    80030014:	40a8058f          	.insn	4, 0x40a8058f
    80030018:	0e46                	slli	t3,t3,0x11
    8003001a:	ca5f e4c8 a9cc      	.insn	6, 0xa9cce4c8ca5f

0000000080030020 <d_2_0>:
    80030020:	edb23d1b          	.insn	4, 0xedb23d1b
    80030024:	c86a                	sw	s10,16(sp)
    80030026:	2cf2                	fld	fs9,280(sp)
    80030028:	42c5                	li	t0,17
    8003002a:	3b7a6423          	.insn	4, 0x3b7a6423
    8003002e:	17de                	slli	a5,a5,0x37

0000000080030030 <d_2_1>:
    80030030:	927c                	.insn	2, 0x927c
    80030032:	8a15                	andi	a2,a2,5
    80030034:	f22d5aff 0fb4eb2b 	.insn	20, 0x3112f3f250d9f9da3bba4c720fb4eb2bf22d5aff
    8003003c:	3bba4c72  
    80030044:	 

0000000080030040 <d_2_2>:
    80030040:	f9da                	sd	s6,240(sp)
    80030042:	50d9                	li	ra,-10
    80030044:	f3f2                	sd	t3,480(sp)
    80030046:	3112                	fld	ft2,288(sp)
    80030048:	724a                	ld	tp,176(sp)
    8003004a:	225d                	addiw	tp,tp,23 # fffffffffffe9017 <_end+0xffffffff7ff88e17>
    8003004c:	3ef9                	addiw	t4,t4,-2
    8003004e:	bbe4                	fsd	fs1,240(a5)

0000000080030050 <d_2_3>:
    80030050:	58ca                	lw	a7,176(sp)
    80030052:	963b7f03          	.insn	4, 0x963b7f03
    80030056:	88dd                	andi	s1,s1,23
    80030058:	c488                	sw	a0,8(s1)
    8003005a:	3acc                	fld	fa1,176(a3)
    8003005c:	0e81                	addi	t4,t4,0
    8003005e:	aa14                	fsd	fa3,16(a2)

0000000080030060 <d_2_4>:
    80030060:	13c2                	slli	t2,t2,0x30
    80030062:	013b833f d6f28dd4 	.insn	8, 0xd6f28dd4013b833f
    8003006a:	3a3887a7          	.insn	4, 0x3a3887a7
    8003006e:	3945                	addiw	s2,s2,-15 # ffffffffd90dcff1 <_end+0xffffffff5907cdf1>

0000000080030070 <d_2_5>:
    80030070:	9b01                	andi	a4,a4,-32
    80030072:	792c                	ld	a1,112(a0)
    80030074:	2916                	fld	fs2,320(sp)
    80030076:	fc95                	bnez	s1,8002ffb2 <_end_data1+0xfdb2>
    80030078:	0485                	addi	s1,s1,1 # ffffffffffff5001 <_end+0xffffffff7ff94e01>
    8003007a:	80a4                	.insn	2, 0x80a4
    8003007c:	1e9c                	addi	a5,sp,880
    8003007e:	c4f2                	sw	t3,72(sp)

0000000080030080 <d_2_6>:
    80030080:	c7c8                	sw	a0,12(a5)
    80030082:	aa8c                	fsd	fa1,16(a3)
    80030084:	300e                	fld	ft0,224(sp)
    80030086:	c8ae                	sw	a1,80(sp)
    80030088:	4ca9                	li	s9,10
    8003008a:	f164                	sd	s1,224(a0)
    8003008c:	1091                	addi	ra,ra,-28
    8003008e:	1e60                	addi	s0,sp,828

0000000080030090 <d_2_7>:
    80030090:	910d                	srli	a0,a0,0x23
    80030092:	a5a9                	j	800306dc <_end_data2+0x4dc>
    80030094:	24dd                	addiw	s1,s1,23
    80030096:	a6bc                	fsd	fa5,72(a3)
    80030098:	6fe9                	lui	t6,0x1a
    8003009a:	385d                	addiw	a6,a6,-9
    8003009c:	f3f6                	sd	t4,480(sp)
    8003009e:	          	auipc	gp,0x70595

00000000800300a0 <d_2_8>:
    800300a0:	7059                	c.lui	zero,0xffff6
    800300a2:	fdcd9eeb          	.insn	4, 0xfdcd9eeb
    800300a6:	8509                	srai	a0,a0,0x2
    800300a8:	ffb1bd07          	fld	fs10,-5(gp) # f05c5099 <_end+0x70564e99>
    800300ac:	8b41                	andi	a4,a4,16
    800300ae:	9d54                	.insn	2, 0x9d54

00000000800300b0 <d_2_9>:
    800300b0:	5054f4ab          	.insn	4, 0x5054f4ab
    800300b4:	3d9d                	addiw	s11,s11,-25 # 4b7f4fe7 <_start-0x3480b019>
    800300b6:	1f9e                	slli	t6,t6,0x27
    800300b8:	e37e                	sd	t6,384(sp)
    800300ba:	c30d                	beqz	a4,800300dc <d_2_11+0xc>
    800300bc:	c795                	beqz	a5,800300e8 <d_2_12+0x8>
    800300be:	55f5                	li	a1,-3

00000000800300c0 <d_2_10>:
    800300c0:	8d18                	.insn	2, 0x8d18
    800300c2:	4309                	li	t1,2
    800300c4:	f0c4                	sd	s1,160(s1)
    800300c6:	ffb6                	sd	a3,504(sp)
    800300c8:	4fae                	lw	t6,200(sp)
    800300ca:	2ec1                	addiw	t4,t4,16
    800300cc:	a3ba0103          	lb	sp,-1477(s4)

00000000800300d0 <d_2_11>:
    800300d0:	a3a2                	fsd	fs0,448(sp)
    800300d2:	6e44                	ld	s1,152(a2)
    800300d4:	7959                	lui	s2,0xffff6
    800300d6:	3db8                	fld	fa4,120(a1)
    800300d8:	40b9                	li	ra,14
    800300da:	445d                	li	s0,23
    800300dc:	8ec2                	mv	t4,a6
    800300de:	931c                	.insn	2, 0x931c

00000000800300e0 <d_2_12>:
    800300e0:	1234                	addi	a3,sp,296
    800300e2:	dffa                	sw	t5,252(sp)
    800300e4:	0276                	slli	tp,tp,0x1d
    800300e6:	71e9                	lui	gp,0xffffa
    800300e8:	e498                	sd	a4,8(s1)
    800300ea:	078d                	addi	a5,a5,3
    800300ec:	fdf0                	sd	a2,248(a1)
    800300ee:	6fb0                	ld	a2,88(a5)

00000000800300f0 <d_2_13>:
    800300f0:	05b4                	addi	a3,sp,712
    800300f2:	7ff73f87          	fld	ft11,2047(a4) # ffffffffffff97ff <_end+0xffffffff7ff995ff>
    800300f6:	70f8                	ld	a4,224(s1)
    800300f8:	91dc                	.insn	2, 0x91dc
    800300fa:	e781                	bnez	a5,80030102 <d_2_14+0x2>
    800300fc:	d1986d17          	auipc	s10,0xd1986

0000000080030100 <d_2_14>:
    80030100:	d5d9b92f          	.insn	4, 0xd5d9b92f
    80030104:	3a96fb83          	.insn	4, 0x3a96fb83
    80030108:	43e15263          	bge	sp,t5,8003052c <_end_data2+0x32c>
    8003010c:	330d5d53          	.insn	4, 0x330d5d53

0000000080030110 <d_2_15>:
    80030110:	2891                	addiw	a7,a7,4
    80030112:	895a488f          	.insn	4, 0x895a488f
    80030116:	7c90e8cf          	.insn	4, 0x7c90e8cf
    8003011a:	b7b6                	fsd	fa3,488(sp)
    8003011c:	8b71                	andi	a4,a4,28
    8003011e:	a634                	fsd	fa3,72(a2)

0000000080030120 <d_2_16>:
    80030120:	c130                	sw	a2,64(a0)
    80030122:	d2da                	sw	s6,100(sp)
    80030124:	4946                	lw	s2,80(sp)
    80030126:	931a                	add	t1,t1,t1
    80030128:	59c5                	li	s3,-15
    8003012a:	0a28                	addi	a0,sp,280
    8003012c:	2d9a                	fld	fs11,384(sp)
    8003012e:	          	lwu	a4,-89(t3)

0000000080030130 <d_2_17>:
    80030130:	fa7e                	sd	t6,304(sp)
    80030132:	0550                	addi	a2,sp,644
    80030134:	e81469d3          	.insn	4, 0xe81469d3
    80030138:	5c35                	li	s8,-19
    8003013a:	e73b7cf7          	.insn	4, 0xe73b7cf7
    8003013e:	87bc                	.insn	2, 0x87bc

0000000080030140 <d_2_18>:
    80030140:	ca51                	beqz	a2,800301d4 <d_2_27+0x4>
    80030142:	e686                	sd	ra,328(sp)
    80030144:	68c0                	ld	s0,144(s1)
    80030146:	ffed                	bnez	a5,80030140 <d_2_18>
    80030148:	066d                	addi	a2,a2,27 # f01b <_start-0x7fff0fe5>
    8003014a:	5db1                	li	s11,-20
    8003014c:	c50d                	beqz	a0,80030176 <d_2_21+0x6>
    8003014e:	c95a                	sw	s6,144(sp)

0000000080030150 <d_2_19>:
    80030150:	f104                	sd	s1,32(a0)
    80030152:	d7c4                	sw	s1,44(a5)
    80030154:	6a51                	lui	s4,0x14
    80030156:	012c15b7          	lui	a1,0x12c1
    8003015a:	f575                	bnez	a0,80030146 <d_2_18+0x6>
    8003015c:	41d2                	lw	gp,20(sp)
    8003015e:	2c2a                	fld	fs8,136(sp)

0000000080030160 <d_2_20>:
    80030160:	eeba                	sd	a4,344(sp)
    80030162:	ca5798fb          	.insn	4, 0xca5798fb
    80030166:	1ed9                	addi	t4,t4,-10
    80030168:	95a59523          	sh	s10,-1718(a1) # 12c094a <_start-0x7ed3f6b6>
    8003016c:	ab2a                	fsd	fa0,400(sp)
    8003016e:	e5a0                	sd	s0,72(a1)

0000000080030170 <d_2_21>:
    80030170:	b5e2                	fsd	fs8,232(sp)
    80030172:	3cac                	fld	fa1,120(s1)
    80030174:	4752                	lw	a4,20(sp)
    80030176:	bf12                	fsd	ft4,440(sp)
    80030178:	151e                	slli	a0,a0,0x27
    8003017a:	14c8598b          	.insn	4, 0x14c8598b
    8003017e:	ca5e                	sw	s7,20(sp)

0000000080030180 <d_2_22>:
    80030180:	9c90                	.insn	2, 0x9c90
    80030182:	a52c                	fsd	fa1,72(a0)
    80030184:	6eb0                	ld	a2,88(a3)
    80030186:	caec                	sw	a1,84(a3)
    80030188:	4c48                	lw	a0,28(s0)
    8003018a:	c2d19de3          	bne	gp,a3,8002fdc4 <_end_data1+0xfbc4>
    8003018e:	5d7d                	li	s10,-1

0000000080030190 <d_2_23>:
    80030190:	c7605cb3          	.insn	4, 0xc7605cb3
    80030194:	c9be                	sw	a5,208(sp)
    80030196:	9159                	srli	a0,a0,0x36
    80030198:	2140                	fld	fs0,128(a0)
    8003019a:	9c7b0033          	.insn	4, 0x9c7b0033
    8003019e:	6edd                	lui	t4,0x17

00000000800301a0 <d_2_24>:
    800301a0:	3816                	fld	fa6,352(sp)
    800301a2:	61ee98a3          	sh	t5,1553(t4) # 17611 <_start-0x7ffe89ef>
    800301a6:	4ee0                	lw	s0,92(a3)
    800301a8:	914e                	add	sp,sp,s3
    800301aa:	2522d36f          	jal	t1,8005d3fc <_end_data4+0xd1fc>
    800301ae:	af56                	fsd	fs5,408(sp)

00000000800301b0 <d_2_25>:
    800301b0:	55eed1e7          	.insn	4, 0x55eed1e7
    800301b4:	865101f3          	.insn	4, 0x865101f3
    800301b8:	92be                	add	t0,t0,a5
    800301ba:	a8aa                	fsd	fa0,80(sp)
    800301bc:	6795                	lui	a5,0x5
    800301be:	          	.insn	4, 0x69377ef7

00000000800301c0 <d_2_26>:
    800301c0:	efb36937          	lui	s2,0xefb36
    800301c4:	19ba                	slli	s3,s3,0x2e
    800301c6:	f41f 9ec4 0b6b      	.insn	6, 0x0b6b9ec4f41f
    800301cc:	e44e                	sd	s3,8(sp)
    800301ce:	86d4                	.insn	2, 0x86d4

00000000800301d0 <d_2_27>:
    800301d0:	7534                	ld	a3,104(a0)
    800301d2:	75da                	ld	a1,432(sp)
    800301d4:	e4a1                	bnez	s1,8003021c <_end_data2+0x1c>
    800301d6:	e451                	bnez	s0,80030262 <_end_data2+0x62>
    800301d8:	53fb59bb          	.insn	4, 0x53fb59bb
    800301dc:	cd909a0f          	.insn	4, 0xcd909a0f
    800301e0:	ccfe                	sw	t6,88(sp)
    800301e2:	fe2a                	sd	a0,312(sp)
    800301e4:	2b21                	addiw	s6,s6,8
    800301e6:	c71a552b          	.insn	4, 0xc71a552b
    800301ea:	6e51                	lui	t3,0x14
    800301ec:	4504                	lw	s1,8(a0)
    800301ee:	1f28                	addi	a0,sp,952
    800301f0:	5cfa                	lw	s9,188(sp)
    800301f2:	43ee                	lw	t2,216(sp)
    800301f4:	726c                	ld	a1,224(a2)
    800301f6:	b0ce                	fsd	fs3,96(sp)
    800301f8:	1074                	addi	a3,sp,44
    800301fa:	704a                	.insn	2, 0x704a
    800301fc:	c272f9f7          	.insn	4, 0xc272f9f7

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	6840                	ld	s0,144(s0)
    80040002:	1779                	addi	a4,a4,-2
    80040004:	c301                	beqz	a4,80040004 <_random_data3+0x4>
    80040006:	8636                	mv	a2,a3
    80040008:	357555e7          	.insn	4, 0x357555e7
    8004000c:	df1e                	sw	t2,188(sp)
    8004000e:	725314b7          	lui	s1,0x72531
    80040012:	c586                	sw	ra,200(sp)
    80040014:	767f                	.insn	2, 0x767f
    80040016:	081d                	addi	a6,a6,7
    80040018:	100e                	c.slli	zero,0x23
    8004001a:	2fa5                	addiw	t6,t6,9 # 1a009 <_start-0x7ffe5ff7>
    8004001c:	3de0                	fld	fs0,248(a1)
    8004001e:	c8c4                	sw	s1,20(s1)

0000000080040020 <d_3_0>:
    80040020:	bb5d                	j	8003fdd6 <_end_data2+0xfbd6>
    80040022:	68086f2b          	.insn	4, 0x68086f2b
    80040026:	6fa9                	lui	t6,0xa
    80040028:	d59e                	sw	t2,232(sp)
    8004002a:	a238                	fsd	fa4,64(a2)
    8004002c:	8922                	mv	s2,s0
    8004002e:	e67a                	sd	t5,264(sp)

0000000080040030 <d_3_1>:
    80040030:	7b04                	ld	s1,48(a4)
    80040032:	d0f9                	beqz	s1,8003fff8 <_end_data2+0xfdf8>
    80040034:	b538                	fsd	fa4,104(a0)
    80040036:	4151                	li	sp,20
    80040038:	8c64                	.insn	2, 0x8c64
    8004003a:	d272abe3          	.insn	4, 0xd272abe3
    8004003e:	5866                	lw	a6,120(sp)

0000000080040040 <d_3_2>:
    80040040:	fb81                	bnez	a5,8003ff50 <_end_data2+0xfd50>
    80040042:	ee3d                	bnez	a2,800400c0 <d_3_10>
    80040044:	ef26                	sd	s1,408(sp)
    80040046:	87d9ad77          	.insn	4, 0x87d9ad77
    8004004a:	cc16                	sw	t0,24(sp)
    8004004c:	f0ee                	sd	s11,96(sp)
    8004004e:	          	.insn	4, 0x914e4d67

0000000080040050 <d_3_3>:
    80040050:	914e                	add	sp,sp,s3
    80040052:	3d04                	fld	fs1,56(a0)
    80040054:	7b8520e7          	.insn	4, 0x7b8520e7
    80040058:	296c                	fld	fa1,208(a0)
    8004005a:	a525                	j	80040682 <_end_data3+0x482>
    8004005c:	d08c                	sw	a1,32(s1)
    8004005e:	236e                	fld	ft6,216(sp)

0000000080040060 <d_3_4>:
    80040060:	8e0e                	mv	t3,gp
    80040062:	7a63c2db          	.insn	4, 0x7a63c2db
    80040066:	b45a                	fsd	fs6,40(sp)
    80040068:	b944                	fsd	fs1,176(a0)
    8004006a:	d4e0                	sw	s0,108(s1)
    8004006c:	07d9                	addi	a5,a5,22 # 5016 <_start-0x7fffafea>
    8004006e:	4218                	lw	a4,0(a2)

0000000080040070 <d_3_5>:
    80040070:	a6f2                	fsd	ft8,328(sp)
    80040072:	f3c5                	bnez	a5,80040012 <_random_data3+0x12>
    80040074:	eb25                	bnez	a4,800400e4 <d_3_12+0x4>
    80040076:	bc40                	fsd	fs0,184(s0)
    80040078:	a48d1e2f          	.insn	4, 0xa48d1e2f
    8004007c:	eb00                	sd	s0,16(a4)
    8004007e:	a68e                	fsd	ft3,328(sp)

0000000080040080 <d_3_6>:
    80040080:	afde                	fsd	fs7,472(sp)
    80040082:	3d52                	fld	fs10,304(sp)
    80040084:	e2b9                	bnez	a3,800400ca <d_3_10+0xa>
    80040086:	361e                	fld	fa2,480(sp)
    80040088:	67a1                	lui	a5,0x8
    8004008a:	3fa5b8a3          	sd	s10,1009(a1)
    8004008e:	a4f0                	fsd	fa2,200(s1)

0000000080040090 <d_3_7>:
    80040090:	5771                	li	a4,-4
    80040092:	70b84caf          	.insn	4, 0x70b84caf
    80040096:	e8ee                	sd	s11,80(sp)
    80040098:	d2aa                	sw	a0,100(sp)
    8004009a:	79b6                	ld	s3,360(sp)
    8004009c:	ea34f413          	andi	s0,s1,-349

00000000800400a0 <d_3_8>:
    800400a0:	36d9                	addiw	a3,a3,-10
    800400a2:	219e68af          	.insn	4, 0x219e68af
    800400a6:	d4f6                	sw	t4,104(sp)
    800400a8:	021a                	slli	tp,tp,0x6
    800400aa:	56ba9363          	bne	s5,a1,80040610 <_end_data3+0x410>
    800400ae:	c6cd                	beqz	a3,80040158 <d_3_19+0x8>

00000000800400b0 <d_3_9>:
    800400b0:	734d                	lui	t1,0xffff3
    800400b2:	b79f d686 2743      	.insn	6, 0x2743d686b79f
    800400b8:	1c35                	addi	s8,s8,-19
    800400ba:	43df 1081 7562      	.insn	6, 0x7562108143df

00000000800400c0 <d_3_10>:
    800400c0:	448acd73          	.insn	4, 0x448acd73
    800400c4:	4b00                	lw	s0,16(a4)
    800400c6:	94a5f1bb          	.insn	4, 0x94a5f1bb
    800400ca:	7658                	ld	a4,168(a2)
    800400cc:	257d                	addiw	a0,a0,31
    800400ce:	8d64                	.insn	2, 0x8d64

00000000800400d0 <d_3_11>:
    800400d0:	f496                	sd	t0,104(sp)
    800400d2:	a0d84de3          	blt	a6,a3,8003faec <_end_data2+0xf8ec>
    800400d6:	3955                	addiw	s2,s2,-11 # ffffffffefb35ff5 <_end+0xffffffff6fad5df5>
    800400d8:	8bb8                	.insn	2, 0x8bb8
    800400da:	fce049af          	.insn	4, 0xfce049af
    800400de:	          	.insn	4, 0x3201740b

00000000800400e0 <d_3_12>:
    800400e0:	3201                	addiw	tp,tp,-32 # ffffffffffffffe0 <_end+0xffffffff7ff9fde0>
    800400e2:	71cd                	lui	gp,0xffff3
    800400e4:	fc1d9f87          	.insn	4, 0xfc1d9f87
    800400e8:	e321                	bnez	a4,80040128 <d_3_16+0x8>
    800400ea:	e4eb5473          	csrrwi	s0,0xe4e,22
    800400ee:	cc14                	sw	a3,24(s0)

00000000800400f0 <d_3_13>:
    800400f0:	3c39a98f          	.insn	4, 0x3c39a98f
    800400f4:	0a99                	addi	s5,s5,6 # e006 <_start-0x7fff1ffa>
    800400f6:	57e9                	li	a5,-6
    800400f8:	db68                	sw	a0,116(a4)
    800400fa:	5b7849e7          	.insn	4, 0x5b7849e7
    800400fe:	6178                	ld	a4,192(a0)

0000000080040100 <d_3_14>:
    80040100:	0c6d                	addi	s8,s8,27
    80040102:	706a                	.insn	2, 0x706a
    80040104:	a17d2a3f 3a71ed81 	.insn	8, 0x3a71ed81a17d2a3f
    8004010c:	1b45                	addi	s6,s6,-15
    8004010e:	7e08                	ld	a0,56(a2)

0000000080040110 <d_3_15>:
    80040110:	2f9a                	fld	ft11,384(sp)
    80040112:	e980                	sd	s0,16(a1)
    80040114:	964db44f          	.insn	4, 0x964db44f
    80040118:	07d9                	addi	a5,a5,22 # 8016 <_start-0x7fff7fea>
    8004011a:	fd51                	bnez	a0,800400b6 <d_3_9+0x6>
    8004011c:	63c2                	ld	t2,16(sp)
    8004011e:	feed                	bnez	a3,80040118 <d_3_15+0x8>

0000000080040120 <d_3_16>:
    80040120:	5a9dd0cf          	fnmadd.d	ft1,fs11,fs1,fa1,unknown
    80040124:	9e9c                	.insn	2, 0x9e9c
    80040126:	6d04                	ld	s1,24(a0)
    80040128:	76ee                	ld	a3,248(sp)
    8004012a:	1b4d                	addi	s6,s6,-13
    8004012c:	f61a                	sd	t1,296(sp)
    8004012e:	d4fe                	sw	t6,104(sp)

0000000080040130 <d_3_17>:
    80040130:	68ca                	ld	a7,144(sp)
    80040132:	0862                	slli	a6,a6,0x18
    80040134:	b630                	fsd	fa2,104(a2)
    80040136:	b031                	j	8003f942 <_end_data2+0xf742>
    80040138:	12aa                	slli	t0,t0,0x2a
    8004013a:	87ae                	mv	a5,a1
    8004013c:	1e25                	addi	t3,t3,-23 # 13fe9 <_start-0x7ffec017>
    8004013e:	4250                	lw	a2,4(a2)

0000000080040140 <d_3_18>:
    80040140:	02162dbb          	.insn	4, 0x02162dbb
    80040144:	8706                	mv	a4,ra
    80040146:	afb5                	j	800408c2 <_end_data3+0x6c2>
    80040148:	1c24                	addi	s1,sp,568
    8004014a:	979f616f          	jal	sp,80036ac2 <_end_data2+0x68c2>
    8004014e:	60ca                	ld	ra,144(sp)

0000000080040150 <d_3_19>:
    80040150:	429f 5a71 bc44      	.insn	6, 0xbc445a71429f
    80040156:	b71d                	j	8004007c <d_3_5+0xc>
    80040158:	ae9f 870a 4b03      	.insn	6, 0x4b03870aae9f
    8004015e:	d922                	sw	s0,176(sp)

0000000080040160 <d_3_20>:
    80040160:	9c483d7b          	.insn	4, 0x9c483d7b
    80040164:	81b2                	mv	gp,a2
    80040166:	5aa8                	lw	a0,112(a3)
    80040168:	ee21                	bnez	a2,800401c0 <d_3_26>
    8004016a:	6599                	lui	a1,0x6
    8004016c:	07dd                	addi	a5,a5,23
    8004016e:	1dfd                	addi	s11,s11,-1

0000000080040170 <d_3_21>:
    80040170:	c20d                	beqz	a2,80040192 <d_3_23+0x2>
    80040172:	bed5567f 873d84a1 	.insn	20, 0x738439dc3e0755ce3ac40607873d84a1bed5567f
    8004017a:	3ac40607  
    80040182:	 

0000000080040180 <d_3_22>:
    80040180:	39dc3e07          	fld	ft8,925(s8)
    80040184:	7384                	ld	s1,32(a5)
    80040186:	10ea                	slli	ra,ra,0x3a
    80040188:	74dc                	ld	a5,168(s1)
    8004018a:	c34a                	sw	s2,132(sp)
    8004018c:	5994                	lw	a3,48(a1)
    8004018e:	1585                	addi	a1,a1,-31 # 5fe1 <_start-0x7fffa01f>

0000000080040190 <d_3_23>:
    80040190:	85ad                	srai	a1,a1,0xb
    80040192:	6034                	ld	a3,64(s0)
    80040194:	1aa6                	slli	s5,s5,0x29
    80040196:	5bfa                	lw	s7,188(sp)
    80040198:	7894                	ld	a3,48(s1)
    8004019a:	48c8                	lw	a0,20(s1)
    8004019c:	f69d                	bnez	a3,800400ca <d_3_10+0xa>
    8004019e:	c98d                	beqz	a1,800401d0 <d_3_27>

00000000800401a0 <d_3_24>:
    800401a0:	75e51fbf 6a571f12 	.insn	8, 0x6a571f1275e51fbf
    800401a8:	cf64                	sw	s1,92(a4)
    800401aa:	fa21                	bnez	a2,800400fa <d_3_13+0xa>
    800401ac:	6639                	lui	a2,0xe
    800401ae:	          	.insn	4, 0xe4e2d8b3

00000000800401b0 <d_3_25>:
    800401b0:	e4e2                	sd	s8,72(sp)
    800401b2:	6230                	ld	a2,64(a2)
    800401b4:	475c                	lw	a5,12(a4)
    800401b6:	58c8                	lw	a0,52(s1)
    800401b8:	049e                	slli	s1,s1,0x7
    800401ba:	141e                	slli	s0,s0,0x27
    800401bc:	7c48                	ld	a0,184(s0)
    800401be:	11c1                	addi	gp,gp,-16 # ffffffffffff2ff0 <_end+0xffffffff7ff92df0>

00000000800401c0 <d_3_26>:
    800401c0:	5b5c                	lw	a5,52(a4)
    800401c2:	c195                	beqz	a1,800401e6 <d_3_27+0x16>
    800401c4:	47473137          	lui	sp,0x47473
    800401c8:	0d20                	addi	s0,sp,664
    800401ca:	e92a                	sd	a0,144(sp)
    800401cc:	ab21                	j	800406e4 <_end_data3+0x4e4>
    800401ce:	fa5f        	.insn	6, 0xbaac63e1fa5f

00000000800401d0 <d_3_27>:
    800401d0:	63e1                	lui	t2,0x18
    800401d2:	baac                	fsd	fa1,112(a3)
    800401d4:	01b4                	addi	a3,sp,200
    800401d6:	d30893a3          	sh	a6,-729(a7)
   