#include <klib.h>

#define BIT(n) (1UL << (n))

#define CSR_MSTATUS   0x300
#define CSR_MIE       0x304
#define CSR_MTVEC     0x305
#define CSR_MSTATEEN0 0x30c
#define CSR_MIP       0x344
#define CSR_MCYCLE    0xb00
#define CSR_HSTATUS   0x600
#define CSR_HIDELEG   0x603
#define CSR_HIE       0x604
#define CSR_HVICTL    0x609
#define CSR_HGATP     0x680
#define CSR_VSATP     0x280
#define CSR_HVIP      0x645
#define CSR_VSTOPI    0xeb0

#define MSTATUS_MIE      BIT(3)
#define MSTATEEN0_AIA    BIT(59)
#define MSTATEEN0_IMSIC  BIT(58)
#define MSTATEEN0_CSRIND BIT(60)

#define VSSI_BIT BIT(2)

#define HVICTL_VTI       BIT(30)
#define HVICTL_IPRIOM    BIT(8)
#define HVICTL_IID(x)    (((unsigned long)(x) & 0xfff) << 16)
#define HVICTL_IPRIO(x)  ((unsigned long)(x) & 0xff)

#define STALL_THRESHOLD  100000UL

extern void m_trap_entry(void);

volatile unsigned long trap_mcause;
volatile unsigned long trap_mepc;
volatile unsigned long trap_mtval;
volatile unsigned long trap_taken;

#define CSRR(num) ({ unsigned long __v; \
    asm volatile("csrr %0, " #num : "=r"(__v) :: "memory"); __v; })
#define CSRW(num, val) \
    asm volatile("csrw " #num ", %0" :: "r"((unsigned long)(val)) : "memory")

static void setup_pmp(void)
{
    asm volatile(
        "li   t0, -1\n\t"
        "csrw pmpaddr0, t0\n\t"
        "li   t0, 0x1f\n\t"
        "csrw pmpcfg0, t0\n\t"
        ::: "t0", "memory");
}

static void clear_intr_sources(void)
{
    CSRW(0x609, 0);
    CSRW(0x645, 0);
    CSRW(0x604, 0);
    CSRW(0x344, 0);
    CSRW(0x304, 0);
    CSRW(0x603, 0);
}

static unsigned long wfi_stall_cycles(void)
{
    unsigned long a, b;
    asm volatile("fence" ::: "memory");
    a = CSRR(0xb00);
    asm volatile("wfi" ::: "memory");
    b = CSRR(0xb00);
    return b - a;
}

static unsigned long case_A_mip_path(void)
{
    clear_intr_sources();
    CSRW(0x645, VSSI_BIT);
    CSRW(0x604, VSSI_BIT);
    CSRW(0x304, VSSI_BIT);
    asm volatile("fence" ::: "memory");
    return wfi_stall_cycles();
}

static unsigned long case_B_hvictl_inject(unsigned long *vstopi_out)
{
    clear_intr_sources();
    unsigned long hvictl = HVICTL_VTI | HVICTL_IID(16) | HVICTL_IPRIOM | HVICTL_IPRIO(2);
    CSRW(0x680, 0);
    CSRW(0x280, 0);
    CSRW(0x600, 0);
    CSRW(0x609, hvictl);
    asm volatile("fence" ::: "memory");
    asm volatile("nop; nop; nop; nop; nop; nop; nop; nop");
    *vstopi_out = CSRR(0xeb0);
    return wfi_stall_cycles();
}

int main(void)
{
    setup_pmp();
    CSRW(0x305, (unsigned long)m_trap_entry);
    asm volatile("csrc 0x300, %0" :: "r"(MSTATUS_MIE) : "memory");
    CSRW(0x30c, MSTATEEN0_AIA | MSTATEEN0_IMSIC | MSTATEEN0_CSRIND);
    trap_taken = 0;

    unsigned long stallA = case_A_mip_path();
    printf("[A] mip path: WFI resumed in %lu cycles\n", stallA);

    unsigned long vstopi = 0;
    unsigned long stallB = case_B_hvictl_inject(&vstopi);
    printf("[B] hvictl.VTI path: WFI resumed in %lu cycles (vstopi=0x%08lx)\n", stallB, vstopi);

    if (stallA < STALL_THRESHOLD && stallB >= STALL_THRESHOLD) {
        printf("BUG: vstopi pending but WFI stalled %lu cycles to hardware timeout\n", stallB);
    } else {
        printf("OK: both paths woke promptly\n");
    }

    return 0;
}
