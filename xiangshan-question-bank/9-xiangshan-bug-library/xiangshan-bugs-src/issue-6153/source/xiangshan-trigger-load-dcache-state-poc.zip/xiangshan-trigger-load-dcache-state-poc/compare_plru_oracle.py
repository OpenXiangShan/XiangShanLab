#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def probe_miss(report, name):
    probe = report.get("first_probe", {}).get(name)
    return None if probe is None else probe.get("miss")


def has_trigger(report, expected_name):
    for event in report.get("matching_trigger_events", []):
        if (
            event.get("name") == expected_name
            and event.get("s1_kill") == 0
            and event.get("s1_internal_kill") == 0
            and event.get("s2_kill") == 1
        ):
            return True
    return False


def has_killed_metadata_update(report, expected_name):
    def recent_has_killed_hit(event):
        for recent in event.get("recent_s2", []):
            if (
                recent.get("name") == expected_name
                and recent.get("miss") == 0
                and recent.get("s2_kill") == 1
                and recent.get("phase") == "pre"
            ):
                return True
        return False

    return (
        any(recent_has_killed_hit(event) for event in report.get("matching_replacement_events", []))
        and any(recent_has_killed_hit(event) for event in report.get("matching_access_events", []))
    )


def summarize(report):
    return {
        "predicate_result": report.get("predicate_result"),
        "expected_secret_line": report.get("expected_secret_line"),
        "addresses": report.get("addresses"),
        "same_set_stride": report.get("same_set_stride"),
        "first_probe": report.get("first_probe"),
        "trigger_events": report.get("matching_trigger_events", [])[:2],
        "metadata_events": report.get("matching_replacement_events", [])[:2],
        "access_events": report.get("matching_access_events", [])[:2],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--secret1", type=Path, required=True)
    parser.add_argument("--secret0", type=Path, required=True)
    parser.add_argument("--json-out", type=Path)
    args = parser.parse_args()

    s1 = load(args.secret1)
    s0 = load(args.secret0)

    checks = {
        "secret1_predicate": s1.get("predicate_result")
        == "plru_oracle_secret1_target_hit_control_miss",
        "secret0_predicate": s0.get("predicate_result") == "plru_oracle_secret0_target_miss",
        "same_addresses": s1.get("addresses") == s0.get("addresses"),
        "same_set_stride_0x4000": (
            s1.get("same_set_stride", {}).get("control_minus_target") == "0x4000"
            and s1.get("same_set_stride", {}).get("filler_or_evict_stride") == "0x4000"
            and s1.get("same_set_stride") == s0.get("same_set_stride")
        ),
        "secret1_target_trigger_not_s1_killed": has_trigger(s1, "target"),
        "secret0_control_trigger_not_s1_killed": has_trigger(s0, "control"),
        "secret1_killed_target_metadata_update": has_killed_metadata_update(s1, "target"),
        "secret0_killed_control_metadata_update": has_killed_metadata_update(s0, "control"),
        "secret1_probe_target_hit": probe_miss(s1, "target") == 0,
        "secret1_probe_control_miss": probe_miss(s1, "control") == 1,
        "secret0_probe_target_miss": probe_miss(s0, "target") == 1,
        "secret0_probe_control_hit": probe_miss(s0, "control") == 0,
    }
    result = {
        "predicate_result": "differential_plru_cache_oracle_reproduced"
        if all(checks.values())
        else "not_reproduced",
        "checks": checks,
        "secret1": summarize(s1),
        "secret0": summarize(s0),
    }
    print(json.dumps(result, indent=2))
    if args.json_out:
        args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["predicate_result"] != "not_reproduced" else 2


if __name__ == "__main__":
    raise SystemExit(main())
