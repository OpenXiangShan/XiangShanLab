#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


TRIGGER_ACTION_BREAKPOINT = 0


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("--symbols", type=Path, required=True)
    parser.add_argument("--secret-select", type=int, choices=(0, 1), required=True)
    parser.add_argument("--begin", type=int, default=0)
    parser.add_argument("--end", type=int)
    parser.add_argument("--json-out", type=Path)
    return parser.parse_args()


def norm_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def read_symbols(path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\S\s+(\S+)$")
    for raw in path.read_text(errors="replace").splitlines():
        match = sym_re.match(raw.strip())
        if match:
            addr, name = match.groups()
            symbols[name] = int(addr, 16)
    return symbols


def read_header(path):
    scope = []
    selected = {}
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")

    def add_if(full, width, code):
        for unit in range(3):
            base_lu = f"memBlock.inner_LoadUnit_{unit}"
            base_ldu = f"inner_dcache.dcache.ldu_{unit}"
            pairs = {
                f"lu{unit}_s1_valid": f"{base_lu}.s1.io_pipeIn_valid",
                f"lu{unit}_s1_vaddr": f"{base_lu}.s1.io_pipeIn_bits_vaddr",
                f"lu{unit}_s1_trigger_action": f"{base_lu}.s1._loadTrigger_tdataVec_io_toLoadStore_triggerAction",
                f"lu{unit}_s1_trigger_vaddr": f"{base_lu}.s1._loadTrigger_tdataVec_io_toLoadStore_triggerVaddr",
                f"lu{unit}_s1_kill": f"{base_lu}.io_dcache_s1_kill",
                f"lu{unit}_s1_internal_kill": f"{base_lu}.s1.io_dcacheKill",
                f"lu{unit}_s2_valid": f"{base_lu}.s2.io_pipeIn_valid",
                f"lu{unit}_s2_vaddr": f"{base_lu}.s2.io_pipeIn_bits_vaddr",
                f"lu{unit}_s2_kill": f"{base_lu}.io_dcache_s2_kill",
                f"ldu{unit}_replace_valid": f"{base_ldu}.io_replace_access_valid",
                f"ldu{unit}_replace_set": f"{base_ldu}.io_replace_access_bits_set",
                f"ldu{unit}_replace_way": f"{base_ldu}.io_replace_access_bits_way",
                f"ldu{unit}_access_valid": f"{base_ldu}.io_access_flag_write_valid",
                f"ldu{unit}_access_idx": f"{base_ldu}.io_access_flag_write_bits_idx",
                f"ldu{unit}_access_way_en": f"{base_ldu}.io_access_flag_write_bits_way_en",
            }
            for key, suffix in pairs.items():
                if full.endswith(suffix) and key not in selected:
                    selected[key] = {"code": code, "width": width, "full_name": full}

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = var_re.match(line)
            if match:
                width, code, leaf = match.groups()
                add_if(".".join(scope + [norm_name(leaf)]), int(width), code)
    return selected


def parse_bits(text):
    if text is None or any(ch in text.lower() for ch in "xz"):
        return None
    return int(text, 2)


def is_one(v):
    return v == 1


def fmt(v):
    return None if v is None else hex(v)


def parse_wave(path, selected, addrs, begin, end):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)
    values = {key: None for key in selected}
    target_addrs = {addrs["target_line"]: "target", addrs["control_line"]: "control"}
    trigger_events = []
    replacement_events = []
    access_events = []
    recent_s2 = {unit: [] for unit in range(3)}

    def val(key):
        return values.get(key)

    def sample(time):
        if time is None or time < begin or (end is not None and time > end):
            return
        for unit in range(3):
            s2_vaddr = val(f"lu{unit}_s2_vaddr")
            if is_one(val(f"lu{unit}_s2_valid")) and s2_vaddr in target_addrs:
                recent_s2[unit].append(
                    {
                        "time": time,
                        "name": target_addrs[s2_vaddr],
                        "vaddr": fmt(s2_vaddr),
                        "s2_kill": val(f"lu{unit}_s2_kill"),
                    }
                )
                recent_s2[unit] = recent_s2[unit][-8:]

            s1_vaddr = val(f"lu{unit}_s1_vaddr")
            if (
                is_one(val(f"lu{unit}_s1_valid"))
                and s1_vaddr in target_addrs
                and val(f"lu{unit}_s1_trigger_action") == TRIGGER_ACTION_BREAKPOINT
            ):
                trigger_events.append(
                    {
                        "time": time,
                        "unit": unit,
                        "name": target_addrs[s1_vaddr],
                        "vaddr": fmt(s1_vaddr),
                        "trigger_vaddr": fmt(val(f"lu{unit}_s1_trigger_vaddr")),
                        "s1_kill": val(f"lu{unit}_s1_kill"),
                        "s1_internal_kill": val(f"lu{unit}_s1_internal_kill"),
                        "s2_kill": val(f"lu{unit}_s2_kill"),
                    }
                )

            if is_one(val(f"ldu{unit}_replace_valid")):
                replacement_events.append(
                    {
                        "time": time,
                        "unit": unit,
                        "set": val(f"ldu{unit}_replace_set"),
                        "way": val(f"ldu{unit}_replace_way"),
                        "recent_s2": list(recent_s2[unit]),
                    }
                )
            if is_one(val(f"ldu{unit}_access_valid")):
                access_events.append(
                    {
                        "time": time,
                        "unit": unit,
                        "idx": val(f"ldu{unit}_access_idx"),
                        "way_en": val(f"ldu{unit}_access_way_en"),
                        "recent_s2": list(recent_s2[unit]),
                    }
                )

    now = None
    in_body = False
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                if end is not None and now > end:
                    break
                continue
            first = line[0]
            if first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bB":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_bits(parts[0][1:])
                        for key in keys:
                            values[key] = value
        sample(now)
    return trigger_events, replacement_events, access_events


def event_matches_secret(event, expected):
    for s2 in event.get("recent_s2", []):
        if s2["name"] == expected and s2["s2_kill"] == 1:
            return True
    return False


def main():
    args = parse_args()
    symbols = read_symbols(args.symbols)
    missing_symbols = [name for name in ("target_line", "control_line") if name not in symbols]
    if missing_symbols:
        result = {"predicate_result": "failed", "missing_symbols": missing_symbols}
        print(json.dumps(result, indent=2))
        return 1
    addrs = {name: symbols[name] for name in ("target_line", "control_line")}
    selected = read_header(args.vcd)
    required = []
    for unit in range(3):
        required += [
            f"lu{unit}_s1_valid", f"lu{unit}_s1_vaddr", f"lu{unit}_s1_trigger_action",
            f"lu{unit}_s2_valid", f"lu{unit}_s2_vaddr", f"lu{unit}_s2_kill",
            f"ldu{unit}_replace_valid", f"ldu{unit}_replace_set", f"ldu{unit}_replace_way",
            f"ldu{unit}_access_valid", f"ldu{unit}_access_idx", f"ldu{unit}_access_way_en",
        ]
    missing = [key for key in required if key not in selected]
    if missing:
        result = {
            "predicate_result": "failed",
            "missing": missing,
            "selected_signals": {k: v["full_name"] for k, v in sorted(selected.items())},
        }
        print(json.dumps(result, indent=2))
        if args.json_out:
            args.json_out.write_text(json.dumps(result, indent=2) + "\n")
        return 1

    triggers, repl, access = parse_wave(args.vcd, selected, addrs, args.begin, args.end)
    expected = "target" if args.secret_select else "control"
    matching_triggers = [e for e in triggers if e["name"] == expected]
    matching_repl = [e for e in repl if event_matches_secret(e, expected)]
    matching_access = [e for e in access if event_matches_secret(e, expected)]
    if matching_repl and matching_access:
        predicate = "killed_load_updates_replacement_and_access_metadata"
    elif matching_repl:
        predicate = "killed_load_updates_replacement_metadata"
    elif matching_access:
        predicate = "killed_load_updates_access_metadata"
    elif matching_triggers:
        predicate = "trigger_seen_no_metadata_update"
    else:
        predicate = "not_observed"

    result = {
        "predicate_result": predicate,
        "secret_select": args.secret_select,
        "expected_secret_line": expected,
        "window": {"begin": args.begin, "end": args.end},
        "addresses": {k: hex(v) for k, v in addrs.items()},
        "matching_trigger_events": matching_triggers[:8],
        "matching_replacement_events": matching_repl[:8],
        "matching_access_events": matching_access[:8],
        "event_counts": {
            "trigger": len(triggers),
            "replacement": len(repl),
            "access": len(access),
        },
        "selected_signals": {k: v["full_name"] for k, v in sorted(selected.items())},
    }
    print(json.dumps(result, indent=2))
    if args.json_out:
        args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if predicate != "not_observed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
