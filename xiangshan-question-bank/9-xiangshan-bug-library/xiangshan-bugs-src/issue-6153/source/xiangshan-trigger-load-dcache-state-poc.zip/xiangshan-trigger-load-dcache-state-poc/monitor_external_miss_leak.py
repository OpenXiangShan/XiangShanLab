#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


SIGNAL_SUFFIXES = {
    "ldu0_valid": ".inner_dcache.dcache.ldu_0.io_miss_req_valid",
    "ldu0_ready": ".inner_dcache.dcache.ldu_0.io_miss_req_ready",
    "ldu0_addr": ".inner_dcache.dcache.ldu_0.io_miss_req_bits_addr",
    "ldu0_vaddr": ".inner_dcache.dcache.ldu_0.io_miss_req_bits_vaddr",
    "ldu0_cancel": ".inner_dcache.dcache.ldu_0.io_miss_req_bits_cancel",
    "arb_valid": ".inner_dcache.dcache.missReqArb.io_out_valid",
    "arb_ready": ".inner_dcache.dcache.missReqArb.io_out_ready",
    "arb_addr": ".inner_dcache.dcache.missReqArb.io_out_bits_addr",
    "arb_vaddr": ".inner_dcache.dcache.missReqArb.io_out_bits_vaddr",
    "arb_cancel": ".inner_dcache.dcache.missReqArb.io_out_bits_cancel",
    "mq_req_valid": ".inner_dcache.dcache.missQueue.io_req_valid",
    "mq_req_ready": ".inner_dcache.dcache.missQueue.io_req_ready",
    "mq_req_addr": ".inner_dcache.dcache.missQueue.io_req_bits_addr",
    "mq_req_vaddr": ".inner_dcache.dcache.missQueue.io_req_bits_vaddr",
    "mq_req_cancel": ".inner_dcache.dcache.missQueue.io_req_bits_cancel",
    "mq_alloc": ".inner_dcache.dcache.missQueue.alloc",
    "mq_merge": ".inner_dcache.dcache.missQueue.merge",
    "mq_pipe_alloc": ".inner_dcache.dcache.missQueue.miss_req_pipe_reg_alloc",
    "mq_pipe_merge": ".inner_dcache.dcache.missQueue.miss_req_pipe_reg_merge",
    "mq_pipe_cancel": ".inner_dcache.dcache.missQueue.miss_req_pipe_reg_cancel",
    "mq_pipe_addr": ".inner_dcache.dcache.missQueue.miss_req_pipe_reg_req_addr",
    "mq_pipe_vaddr": ".inner_dcache.dcache.missQueue.miss_req_pipe_reg_req_vaddr",
    "mem_acq_valid": ".inner_dcache.dcache.missQueue.io_mem_acquire_valid",
    "mem_acq_ready": ".inner_dcache.dcache.missQueue.io_mem_acquire_ready",
    "mem_acq_addr": ".inner_dcache.dcache.missQueue.io_mem_acquire_bits_address",
    "mem_acq_user_vaddr": ".inner_dcache.dcache.missQueue.io_mem_acquire_bits_user_vaddr",
    "dcache_a_valid": ".inner_dcache.auto_client_out_a_valid",
    "dcache_a_ready": ".inner_dcache.auto_client_out_a_ready",
    "dcache_a_addr": ".inner_dcache.auto_client_out_a_bits_address",
    "dcache_a_user_vaddr": ".inner_dcache.auto_client_out_a_bits_user_vaddr",
    "l2_a_valid": ".core.auto_memBlock_inner_dcache_client_out_a_valid",
    "l2_a_ready": ".core.auto_memBlock_inner_dcache_client_out_a_ready",
    "l2_a_addr": ".core.auto_memBlock_inner_dcache_client_out_a_bits_address",
    "l2_a_user_vaddr": ".core.auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("vcd", type=Path)
    parser.add_argument("--symbols", type=Path, required=True)
    parser.add_argument("--begin", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--secret-select", type=int, choices=(0, 1), required=True)
    parser.add_argument("--json-out", type=Path)
    return parser.parse_args()


def norm_name(name):
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def read_symbols(path):
    symbols = {}
    sym_re = re.compile(r"^([0-9a-fA-F]+)\s+\S\s+(\S+)$")
    for raw in path.read_text(errors="replace").splitlines():
        match = sym_re.match(raw.strip())
        if match:
            addr, name = match.groups()
            symbols[name] = int(addr, 16)
    return symbols


def read_header(path):
    selected = {}
    scope = []
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope "):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = var_re.match(line)
            if not match:
                continue
            width, code, leaf = match.groups()
            full = ".".join(scope + [norm_name(leaf)])
            for key, suffix in SIGNAL_SUFFIXES.items():
                if full.endswith(suffix) and key not in selected:
                    selected[key] = {
                        "code": code,
                        "width": int(width),
                        "full_name": full,
                    }
    return selected


def parse_bits(text):
    if text is None or any(ch in text.lower() for ch in "xz"):
        return None
    return int(text, 2)


def fmt(value):
    return None if value is None else hex(value)


def is_line_addr(value, lines):
    return value in lines


def line_name(value, addrs):
    if value == addrs["target_line"]:
        return "target"
    if value == addrs["control_line"]:
        return "control"
    return "other"


def parse_wave(path, selected, addrs, begin, end):
    code_to_keys = {}
    for key, sig in selected.items():
        code_to_keys.setdefault(sig["code"], []).append(key)

    values = {key: None for key in selected}
    lines = {addrs["target_line"], addrs["control_line"]}
    events = {
        "ldu0_miss_req": [],
        "arb_out": [],
        "missqueue_req": [],
        "missqueue_pipe_reg": [],
        "mem_acquire": [],
        "dcache_a": [],
        "l2_a": [],
    }
    max_events = 200

    def val(key):
        return values.get(key)

    def one(key):
        return val(key) == 1

    def append(kind, event):
        if len(events[kind]) < max_events:
            events[kind].append(event)

    def req_event(time, prefix):
        addr = val(f"{prefix}_addr")
        vaddr = val(f"{prefix}_vaddr")
        return {
            "time": time,
            "addr": fmt(addr),
            "vaddr": fmt(vaddr),
            "line": line_name(addr, addrs),
            "ready": val(f"{prefix}_ready"),
            "cancel": val(f"{prefix}_cancel"),
        }

    def channel_event(time, prefix):
        addr = val(f"{prefix}_addr")
        return {
            "time": time,
            "addr": fmt(addr),
            "line": line_name(addr, addrs),
            "ready": val(f"{prefix}_ready"),
            "user_vaddr": fmt(val(f"{prefix}_user_vaddr")),
        }

    def sample(time):
        if time is None or time < begin or time > end:
            return
        if one("ldu0_valid") and is_line_addr(val("ldu0_addr"), lines):
            append("ldu0_miss_req", req_event(time, "ldu0"))
        if one("arb_valid") and is_line_addr(val("arb_addr"), lines):
            append("arb_out", req_event(time, "arb"))
        if one("mq_req_valid") and is_line_addr(val("mq_req_addr"), lines):
            append("missqueue_req", req_event(time, "mq_req"))
        pipe_addr = val("mq_pipe_addr")
        pipe_vaddr = val("mq_pipe_vaddr")
        if (
            is_line_addr(pipe_addr, lines)
            and (one("mq_pipe_alloc") or one("mq_pipe_merge") or one("mq_pipe_cancel"))
        ):
            append(
                "missqueue_pipe_reg",
                {
                    "time": time,
                    "addr": fmt(pipe_addr),
                    "vaddr": fmt(pipe_vaddr),
                    "line": line_name(pipe_addr, addrs),
                    "alloc": val("mq_pipe_alloc"),
                    "merge": val("mq_pipe_merge"),
                    "cancel": val("mq_pipe_cancel"),
                },
            )
        if one("mem_acq_valid") and is_line_addr(val("mem_acq_addr"), lines):
            append("mem_acquire", channel_event(time, "mem_acq"))
        if one("dcache_a_valid") and is_line_addr(val("dcache_a_addr"), lines):
            append("dcache_a", channel_event(time, "dcache_a"))
        if one("l2_a_valid") and is_line_addr(val("l2_a_addr"), lines):
            append("l2_a", channel_event(time, "l2_a"))

    now = None
    in_body = False
    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                in_body = line == "$enddefinitions $end"
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                if now > end:
                    break
                continue
            first = line[0]
            if first in "01xXzZ":
                keys = code_to_keys.get(line[1:].strip())
                if keys:
                    value = None if first in "xXzZ" else int(first)
                    for key in keys:
                        values[key] = value
            elif first in "bB":
                parts = line.split()
                if len(parts) == 2:
                    keys = code_to_keys.get(parts[1])
                    if keys:
                        value = parse_bits(parts[0][1:])
                        for key in keys:
                            values[key] = value
        sample(now)
    return events


def main():
    args = parse_args()
    symbols = read_symbols(args.symbols)
    required_symbols = ["target_line", "control_line"]
    missing_symbols = [name for name in required_symbols if name not in symbols]
    if missing_symbols:
        result = {"predicate_result": "failed", "missing_symbols": missing_symbols}
        print(json.dumps(result, indent=2))
        if args.json_out:
            args.json_out.write_text(json.dumps(result, indent=2) + "\n")
        return 1

    addrs = {name: symbols[name] for name in required_symbols}
    selected = read_header(args.vcd)
    missing = sorted(set(SIGNAL_SUFFIXES) - set(selected))
    if missing:
        result = {
            "predicate_result": "failed",
            "reason": "missing VCD signals",
            "missing": missing,
            "selected_signals": {k: v["full_name"] for k, v in sorted(selected.items())},
        }
        print(json.dumps(result, indent=2))
        if args.json_out:
            args.json_out.write_text(json.dumps(result, indent=2) + "\n")
        return 1

    events = parse_wave(args.vcd, selected, addrs, args.begin, args.end)
    expected = "target" if args.secret_select else "control"
    expected_ldu = [e for e in events["ldu0_miss_req"] if e["line"] == expected]
    expected_mq_req = [e for e in events["missqueue_req"] if e["line"] == expected]
    canceled_mq_req = [e for e in expected_mq_req if e["cancel"] == 1]
    expected_acq = [e for e in events["mem_acquire"] if e["line"] == expected]
    expected_a = [e for e in events["dcache_a"] if e["line"] == expected]
    expected_l2_a = [e for e in events["l2_a"] if e["line"] == expected]
    pipe_allocs = [
        e for e in events["missqueue_pipe_reg"]
        if e["line"] == expected and (e["alloc"] == 1 or e["merge"] == 1)
    ]

    request_reaches_mq_canceled = bool(expected_ldu and canceled_mq_req)
    no_external_acquire = not expected_acq and not expected_a and not expected_l2_a and not pipe_allocs
    if request_reaches_mq_canceled and no_external_acquire:
        predicate = "miss_request_canceled_before_external_acquire"
    elif expected_acq or expected_a or expected_l2_a:
        predicate = "external_acquire_observed"
    elif expected_ldu:
        predicate = "ldu_miss_without_external_acquire"
    else:
        predicate = "not_observed"

    result = {
        "predicate_result": predicate,
        "secret_select": args.secret_select,
        "expected_secret_line": expected,
        "window": {"begin": args.begin, "end": args.end},
        "addresses": {k: hex(v) for k, v in addrs.items()},
        "request_reaches_missqueue_canceled": request_reaches_mq_canceled,
        "no_external_acquire_for_expected_line": no_external_acquire,
        "event_counts": {k: len(v) for k, v in events.items()},
        "events": events,
        "selected_signals": {k: v["full_name"] for k, v in sorted(selected.items())},
    }
    print(json.dumps(result, indent=2))
    if args.json_out:
        args.json_out.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if predicate != "not_observed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
