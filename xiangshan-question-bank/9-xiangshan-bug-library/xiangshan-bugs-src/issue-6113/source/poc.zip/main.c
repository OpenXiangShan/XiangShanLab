#include <klib.h>

volatile unsigned long trap_mcause = 0xffff;
volatile unsigned long trap_mepc;
volatile unsigned long trap_mtval;
volatile unsigned long observed_sireg = 0xdeadbeefUL;
volatile unsigned long return_to_mmode;

extern void m_trap_entry(void);
extern void vs_entry(void);

#define BIT(n) (1UL << (n))

#define MSTATEEN0_CSRIND BIT(60)
#define MSTATEEN0_AIA    BIT(59)
#define MSTATEEN0_IMSIC  BIT(58)

#define MSTATUS_MPP_M  (3UL << 11)
#define MSTATUS_MPP_S  (1UL << 11)
#define MSTATUS_MPV    BIT(39)
#define MSTATUS_MIE    BIT(3)
#define MSTATUS_SIE    BIT(1)

static void setup_pmp(void)
{
    asm volatile(
        "li   t0, -1\n\t"
        "csrw pmpaddr0, t0\n\t"
        "li   t0, 0x1f\n\t"    
        "csrw pmpcfg0, t0\n\t"
        ::: "t0", "memory"
    );
}

static void run_poc(void)
{
    unsigned long mstatus;
    unsigned long mstateen = MSTATEEN0_CSRIND | MSTATEEN0_IMSIC;            
    unsigned long hstateen = MSTATEEN0_CSRIND | MSTATEEN0_AIA | MSTATEEN0_IMSIC;

    setup_pmp();

    asm volatile("csrw 0x305, %0" :: "r"((unsigned long)m_trap_entry) : "memory"); 
    asm volatile("csrw 0x302, zero" ::: "memory");                                
    asm volatile("csrw 0x303, zero" ::: "memory");                              
    asm volatile("csrw 0x30c, %0" :: "r"(mstateen) : "memory");                   
    asm volatile("csrw 0x60c, %0" :: "r"(hstateen) : "memory");                    
    asm volatile("csrw 0x680, zero" ::: "memory");                                 
    asm volatile("csrw 0x280, zero" ::: "memory");                                 
    asm volatile("csrw 0x600, zero" ::: "memory");                                 

    asm volatile("csrr %0, 0x300" : "=r"(mstatus));
    mstatus &= ~MSTATUS_MPP_M;
    mstatus |= MSTATUS_MPP_S;       
    mstatus |= MSTATUS_MPV;         
    mstatus &= ~MSTATUS_MIE;
    mstatus &= ~MSTATUS_SIE;
    asm volatile("csrw 0x300, %0" :: "r"(mstatus) : "memory");

    asm volatile("csrw 0x341, %0" :: "r"((unsigned long)vs_entry) : "memory");     
    asm volatile("la %0, 1f" : "=r"(return_to_mmode));
    asm volatile("mret\n1:" ::: "t0", "t1", "t2", "t3", "memory");
}

int main(void)
{
    printf("=== AIA VS-mode sireg iprio-window PoC (vsiselect=0x30, mstateen0.AIA=0) ===\n");

    run_poc();

    printf("[*] trap_mcause=%lu trap_mepc=0x%lx trap_mtval=0x%lx observed_sireg=0x%lx\n",
           trap_mcause, trap_mepc, trap_mtval, observed_sireg);

    if (trap_mcause == 2)
        printf("=== this CPU raised ILLEGAL INSTRUCTION (EX_II, cause=2) ===\n");
    else if (trap_mcause == 22)
        printf("=== this CPU raised VIRTUAL INSTRUCTION (EX_VI, cause=22) ===\n");
    else
        printf("=== UNEXPECTED cause=%lu (no target trap?) ===\n", trap_mcause);

    return 0;
}
