
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <_end_trap>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <_end_trap>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	6521                	lui	a0,0x8
    800001be:	8005051b          	addiw	a0,a0,-2048 # 7800 <_start-0x7fff8800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_end_prefix>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_end_prefix>:
    80000200:	7a59d3f3          	csrrwi	t2,tcontrol,19
    80000204:	8a9e                	mv	s5,t2

0000000080000206 <_l1>:
    80000206:	00020517          	auipc	a0,0x20
    8000020a:	fca50513          	addi	a0,a0,-54 # 800201d0 <d_1_27>
    8000020e:	852a                	mv	a0,a0
    80000210:	2145372f          	amoxor.d	a4,s4,(a0)

0000000080000214 <_l2>:
    80000214:	00000a97          	auipc	s5,0x0
    80000218:	42ca8a93          	addi	s5,s5,1068 # 80000640 <_l92>
    8000021c:	008aa807          	flw	fa6,8(s5)

0000000080000220 <_l3>:
    80000220:	feaf5eb7          	lui	t4,0xfeaf5
    80000224:	d89e8e9b          	addiw	t4,t4,-631 # fffffffffeaf4d89 <_end+0xffffffff7ea94b89>
    80000228:	0eb6                	slli	t4,t4,0xd
    8000022a:	223e8e93          	addi	t4,t4,547
    8000022e:	0eb2                	slli	t4,t4,0xc
    80000230:	f21e8e93          	addi	t4,t4,-223
    80000234:	0eb6                	slli	t4,t4,0xd
    80000236:	21ee8e93          	addi	t4,t4,542
    8000023a:	721ebff3          	csrrc	t6,mcyclecfgh,t4
    8000023e:	837e                	mv	t1,t6

0000000080000240 <_l4>:
    80000240:	00e1169b          	slliw	a3,sp,0xe

0000000080000244 <_l5>:
    80000244:	a5d68213          	addi	tp,a3,-1443

0000000080000248 <_l6>:
    80000248:	003803d3          	fadd.s	ft7,fa6,ft3,rne

000000008000024c <_l7>:
    8000024c:	00030517          	auipc	a0,0x30
    80000250:	df450513          	addi	a0,a0,-524 # 80030040 <d_2_2>
    80000254:	852a                	mv	a0,a0
    80000256:	ffe008b7          	lui	a7,0xffe00
    8000025a:	01154533          	xor	a0,a0,a7
    8000025e:	c11531af          	amominu.d	gp,a7,(a0)

0000000080000262 <_l8>:
    80000262:	30005073          	csrwi	mstatus,0
    80000266:	000bcfb7          	lui	t6,0xbc
    8000026a:	b79f8f9b          	addiw	t6,t6,-1159 # bbb79 <_start-0x7ff44487>
    8000026e:	0fb6                	slli	t6,t6,0xd
    80000270:	201f8f93          	addi	t6,t6,513
    80000274:	0fb2                	slli	t6,t6,0xc
    80000276:	24bf8f93          	addi	t6,t6,587
    8000027a:	0fbe                	slli	t6,t6,0xf
    8000027c:	d98f8f93          	addi	t6,t6,-616
    80000280:	155fb2f3          	csrrc	t0,sireg4,t6
    80000284:	8416                	mv	s0,t0

0000000080000286 <_l9>:
    80000286:	00000497          	auipc	s1,0x0
    8000028a:	21a48493          	addi	s1,s1,538 # 800004a0 <_l60>
    8000028e:	fe848603          	lb	a2,-24(s1)

0000000080000292 <_l10>:
    80000292:	3438fef3          	csrrci	t4,mtval,17
    80000296:	8676                	mv	a2,t4

0000000080000298 <_l11>:
    80000298:	00020a17          	auipc	s4,0x20
    8000029c:	e48a0a13          	addi	s4,s4,-440 # 800200e0 <d_1_12>
    800002a0:	8a52                	mv	s4,s4
    800002a2:	818a26af          	amomin.w	a3,s8,(s4)

00000000800002a6 <_l12>:
    800002a6:	2b0b8163          	beq	s7,a6,80000548 <_l76>

00000000800002aa <_l13>:
    800002aa:	7a45d3f3          	csrrwi	t2,tinfo,11
    800002ae:	881e                	mv	a6,t2

00000000800002b0 <_l14>:
    800002b0:	017b1d13          	slli	s10,s6,0x17

00000000800002b4 <_l15>:
    800002b4:	0000100f          	fence.i

00000000800002b8 <_l16>:
    800002b8:	30005073          	csrwi	mstatus,0
    800002bc:	7a3ee3f3          	csrrsi	t2,tdata3,29
    800002c0:	839e                	mv	t2,t2

00000000800002c2 <_l17>:
    800002c2:	6f21                	lui	t5,0x8
    800002c4:	888f0f1b          	addiw	t5,t5,-1912 # 7888 <_start-0x7fff8778>
    800002c8:	300f32f3          	csrrc	t0,mstatus,t5
    800002cc:	8d16                	mv	s10,t0

00000000800002ce <_l18>:
    800002ce:	ff967f37          	lui	t5,0xff967
    800002d2:	1d1f0f1b          	addiw	t5,t5,465 # ffffffffff9671d1 <_end+0xffffffff7f906fd1>
    800002d6:	0f42                	slli	t5,t5,0x10
    800002d8:	f37f0f13          	addi	t5,t5,-201
    800002dc:	0f32                	slli	t5,t5,0xc
    800002de:	19ff0f13          	addi	t5,t5,415
    800002e2:	0f32                	slli	t5,t5,0xc
    800002e4:	a2ff0f13          	addi	t5,t5,-1489
    800002e8:	7aaf3ff3          	csrrc	t6,mscontext,t5
    800002ec:	8b7e                	mv	s6,t6
    800002ee:	c07e                	sw	t6,0(sp)

00000000800002f0 <_l19>:
    800002f0:	00010197          	auipc	gp,0x10
    800002f4:	d7018193          	addi	gp,gp,-656 # 80010060 <d_0_4>
    800002f8:	ff118fa3          	sb	a7,-1(gp)

00000000800002fc <_l20>:
    800002fc:	30005073          	csrwi	mstatus,0
    80000300:	f1487ef3          	csrrci	t4,mhartid,16

0000000080000304 <_l21>:
    80000304:	00000397          	auipc	t2,0x0
    80000308:	2ea38393          	addi	t2,t2,746 # 800005ee <_l84>
    8000030c:	01c3a803          	lw	a6,28(t2)

0000000080000310 <_l22>:
    80000310:	30005073          	csrwi	mstatus,0
    80000314:	5a87fff3          	csrrci	t6,scontext,15

0000000080000318 <_l23>:
    80000318:	30005073          	csrwi	mstatus,0
    8000031c:	156ce373          	csrrsi	t1,sireg5,25
    80000320:	861a                	mv	a2,t1
    80000322:	c01a                	sw	t1,0(sp)

0000000080000324 <_l24>:
    80000324:	21560653          	fsgnj.s	fa2,fa2,fs5

0000000080000328 <_l25>:
    80000328:	00010297          	auipc	t0,0x10
    8000032c:	e1828293          	addi	t0,t0,-488 # 80010140 <d_0_18>
    80000330:	12b1                	addi	t0,t0,-20
    80000332:	e152a72f          	amomaxu.w	a4,s5,(t0)

0000000080000336 <_l26>:
    80000336:	00050e97          	auipc	t4,0x50
    8000033a:	e5ae8e93          	addi	t4,t4,-422 # 80050190 <d_4_23>
    8000033e:	fefebc23          	sd	a5,-8(t4)

0000000080000342 <_l27>:
    80000342:	0ff0000f          	fence

0000000080000346 <_l28>:
    80000346:	007f86d3          	fadd.s	fa3,ft11,ft7,rne

000000008000034a <_l29>:
    8000034a:	c0330ad3          	fcvt.lu.s	s5,ft6,rne

000000008000034e <_l30>:
    8000034e:	80000cb7          	lui	s9,0x80000

0000000080000352 <_l31>:
    80000352:	00030d17          	auipc	s10,0x30
    80000356:	e2ed0d13          	addi	s10,s10,-466 # 80030180 <d_2_22>
    8000035a:	8d6a                	mv	s10,s10
    8000035c:	090d33af          	amoswap.d	t2,a6,(s10)

0000000080000360 <_l32>:
    80000360:	10020bd3          	fmul.s	fs7,ft4,ft0,rne

0000000080000364 <_l33>:
    80000364:	7a837373          	csrrci	t1,mcontext,6
    80000368:	8e1a                	mv	t3,t1

000000008000036a <_l34>:
    8000036a:	6a826ef3          	csrrsi	t4,hcontext,4
    8000036e:	81f6                	mv	gp,t4

0000000080000370 <_l35>:
    80000370:	f115fe73          	csrrci	t3,mvendorid,11
    80000374:	89f2                	mv	s3,t3

0000000080000376 <_l36>:
    80000376:	00020a97          	auipc	s5,0x20
    8000037a:	dcaa8a93          	addi	s5,s5,-566 # 80020140 <d_1_18>
    8000037e:	8ad6                	mv	s5,s5
    80000380:	819aa72f          	amomin.w	a4,s9,(s5)

0000000080000384 <_l37>:
    80000384:	00000497          	auipc	s1,0x0
    80000388:	ede48493          	addi	s1,s1,-290 # 80000262 <_l8>
    8000038c:	ff54c983          	lbu	s3,-11(s1)

0000000080000390 <_l38>:
    80000390:	16135063          	bge	t1,ra,800004f0 <_l67>

0000000080000394 <_l39>:
    80000394:	107b8a53          	fmul.s	fs4,fs7,ft7,rne

0000000080000398 <_l40>:
    80000398:	00060897          	auipc	a7,0x60
    8000039c:	d9888893          	addi	a7,a7,-616 # 80060130 <d_5_17>
    800003a0:	fe88c583          	lbu	a1,-24(a7)

00000000800003a4 <_l41>:
    800003a4:	00050c97          	auipc	s9,0x50
    800003a8:	d4cc8c93          	addi	s9,s9,-692 # 800500f0 <d_4_13>
    800003ac:	ff1c8123          	sb	a7,-30(s9)

00000000800003b0 <_l42>:
    800003b0:	00050d97          	auipc	s11,0x50
    800003b4:	cf0d8d93          	addi	s11,s11,-784 # 800500a0 <d_4_8>
    800003b8:	ff8dd183          	lhu	gp,-8(s11)

00000000800003bc <_l43>:
    800003bc:	00010617          	auipc	a2,0x10
    800003c0:	de460613          	addi	a2,a2,-540 # 800101a0 <d_0_24>
    800003c4:	0641                	addi	a2,a2,16
    800003c6:	41362caf          	amoor.w	s9,s3,(a2)

00000000800003ca <_l44>:
    800003ca:	00030e97          	auipc	t4,0x30
    800003ce:	cc6e8e93          	addi	t4,t4,-826 # 80030090 <d_2_7>
    800003d2:	00deb823          	sd	a3,16(t4)

00000000800003d6 <_l45>:
    800003d6:	6a8be3f3          	csrrsi	t2,hcontext,23
    800003da:	859e                	mv	a1,t2

00000000800003dc <_l46>:
    800003dc:	30005073          	csrwi	mstatus,0
    800003e0:	3def0337          	lui	t1,0x3def0
    800003e4:	9f33031b          	addiw	t1,t1,-1549 # 3deef9f3 <_start-0x4211060d>
    800003e8:	0332                	slli	t1,t1,0xc
    800003ea:	e0130313          	addi	t1,t1,-511
    800003ee:	0342                	slli	t1,t1,0x10
    800003f0:	3f130313          	addi	t1,t1,1009
    800003f4:	15233ff3          	csrrc	t6,sireg2,t1
    800003f8:	8e7e                	mv	t3,t6
    800003fa:	c07e                	sw	t6,0(sp)

00000000800003fc <_l47>:
    800003fc:	f802ee37          	lui	t3,0xf802e
    80000400:	0a3e0e1b          	addiw	t3,t3,163 # fffffffff802e0a3 <_end+0xffffffff77fcdea3>
    80000404:	0e32                	slli	t3,t3,0xc
    80000406:	07be0e13          	addi	t3,t3,123
    8000040a:	0e32                	slli	t3,t3,0xc
    8000040c:	03be0e13          	addi	t3,t3,59
    80000410:	0e32                	slli	t3,t3,0xc
    80000412:	bf3e0e13          	addi	t3,t3,-1037
    80000416:	7b3e2f73          	csrrs	t5,dscratch1,t3
    8000041a:	000f0013          	mv	zero,t5

000000008000041e <_l48>:
    8000041e:	7b05ef73          	csrrsi	t5,dcsr,11

0000000080000422 <_l49>:
    80000422:	294407d3          	fmin.s	fa5,fs0,fs4

0000000080000426 <_l50>:
    80000426:	ffec7e37          	lui	t3,0xffec7
    8000042a:	817e0e1b          	addiw	t3,t3,-2025 # ffffffffffec6817 <_end+0xffffffff7fe66617>
    8000042e:	0e36                	slli	t3,t3,0xd
    80000430:	6a5e0e13          	addi	t3,t3,1701
    80000434:	0e3a                	slli	t3,t3,0xe
    80000436:	cefe0e13          	addi	t3,t3,-785
    8000043a:	0e3a                	slli	t3,t3,0xe
    8000043c:	1e4e0e13          	addi	t3,t3,484
    80000440:	350e1ef3          	csrrw	t4,miselect,t3
    80000444:	88f6                	mv	a7,t4
    80000446:	c076                	sw	t4,0(sp)

0000000080000448 <_l51>:
    80000448:	b2e0ac13          	slti	s8,ra,-1234

000000008000044c <_l52>:
    8000044c:	7a4dee73          	csrrsi	t3,tinfo,27
    80000450:	8772                	mv	a4,t3

0000000080000452 <_l53>:
    80000452:	342d72f3          	csrrci	t0,mcause,26
    80000456:	8816                	mv	a6,t0

0000000080000458 <_l54>:
    80000458:	00000e97          	auipc	t4,0x0
    8000045c:	236e8e93          	addi	t4,t4,566 # 8000068e <_good_exit>
    80000460:	141e9073          	csrw	sepc,t4
    80000464:	10200073          	sret

0000000080000468 <_l55>:
    80000468:	13750073          	sfence.vma	a0,s7

000000008000046c <_l56>:
    8000046c:	7a3ea373          	csrrs	t1,tdata3,t4
    80000470:	851a                	mv	a0,t1

0000000080000472 <_l57>:
    80000472:	30005073          	csrwi	mstatus,0
    80000476:	7b1df3f3          	csrrci	t2,dpc,27
    8000047a:	8d9e                	mv	s11,t2

000000008000047c <_l58>:
    8000047c:	feb722b7          	lui	t0,0xfeb72
    80000480:	0bb2829b          	addiw	t0,t0,187 # fffffffffeb720bb <_end+0xffffffff7eb11ebb>
    80000484:	02b2                	slli	t0,t0,0xc
    80000486:	4f928293          	addi	t0,t0,1273
    8000048a:	02b6                	slli	t0,t0,0xd
    8000048c:	9ed28293          	addi	t0,t0,-1555
    80000490:	02b2                	slli	t0,t0,0xc
    80000492:	26728293          	addi	t0,t0,615
    80000496:	7a129ff3          	csrrw	t6,tdata1,t0
    8000049a:	88fe                	mv	a7,t6

000000008000049c <_l59>:
    8000049c:	f810e613          	ori	a2,ra,-127

00000000800004a0 <_l60>:
    800004a0:	00040a97          	auipc	s5,0x40
    800004a4:	d30a8a93          	addi	s5,s5,-720 # 800401d0 <d_3_27>
    800004a8:	1ae1                	addi	s5,s5,-8
    800004aa:	21bab92f          	amoxor.d	s2,s11,(s5)

00000000800004ae <_l61>:
    800004ae:	1da08d1b          	addiw	s10,ra,474

00000000800004b2 <_l62>:
    800004b2:	03d61f17          	auipc	t5,0x3d61

00000000800004b6 <_l63>:
    800004b6:	79018fc7          	fmsub.s	ft11,ft3,fa6,fa5,rne

00000000800004ba <_l64>:
    800004ba:	0008b3b7          	lui	t2,0x8b
    800004be:	5d93839b          	addiw	t2,t2,1497 # 8b5d9 <_start-0x7ff74a27>
    800004c2:	03b6                	slli	t2,t2,0xd
    800004c4:	47338393          	addi	t2,t2,1139
    800004c8:	03c2                	slli	t2,t2,0x10
    800004ca:	71738393          	addi	t2,t2,1815
    800004ce:	03ba                	slli	t2,t2,0xe
    800004d0:	1e338393          	addi	t2,t2,483
    800004d4:	7a439ef3          	csrrw	t4,tinfo,t2
    800004d8:	82f6                	mv	t0,t4

00000000800004da <_l65>:
    800004da:	00030b97          	auipc	s7,0x30
    800004de:	ce6b8b93          	addi	s7,s7,-794 # 800301c0 <d_2_26>
    800004e2:	00ebb023          	sd	a4,0(s7)

00000000800004e6 <_l66>:
    800004e6:	30005073          	csrwi	mstatus,0
    800004ea:	7a2552f3          	csrrwi	t0,tdata2,10
    800004ee:	8396                	mv	t2,t0

00000000800004f0 <_l67>:
    800004f0:	00000097          	auipc	ra,0x0
    800004f4:	14c08093          	addi	ra,ra,332 # 8000063c <_l91>
    800004f8:	04109073          	csrw	uepc,ra
    800004fc:	00200073          	uret

0000000080000500 <_l68>:
    80000500:	00050f17          	auipc	t5,0x50
    80000504:	ba0f0f13          	addi	t5,t5,-1120 # 800500a0 <d_4_8>
    80000508:	1f41                	addi	t5,t5,-16
    8000050a:	801f3aaf          	amomin.d	s5,ra,(t5)

000000008000050e <_l69>:
    8000050e:	30005073          	csrwi	mstatus,0
    80000512:	7a495373          	csrrwi	t1,tinfo,18
    80000516:	841a                	mv	s0,t1

0000000080000518 <_l70>:
    80000518:	17200aef          	jal	s5,8000068a <_l96>

000000008000051c <_l71>:
    8000051c:	00060d17          	auipc	s10,0x60
    80000520:	c94d0d13          	addi	s10,s10,-876 # 800601b0 <d_5_25>
    80000524:	fecd1123          	sh	a2,-30(s10)

0000000080000528 <_l72>:
    80000528:	ff084893          	xori	a7,a6,-16

000000008000052c <_l73>:
    8000052c:	7a23de73          	csrrwi	t3,tdata2,7
    80000530:	8972                	mv	s2,t3

0000000080000532 <_l74>:
    80000532:	537d                	li	t1,-1
    80000534:	7a833373          	csrrc	t1,mcontext,t1
    80000538:	851a                	mv	a0,t1

000000008000053a <_l75>:
    8000053a:	00020197          	auipc	gp,0x20
    8000053e:	b9618193          	addi	gp,gp,-1130 # 800200d0 <d_1_11>
    80000542:	01e1                	addi	gp,gp,24
    80000544:	21a1a9af          	amoxor.w	s3,s10,(gp)

0000000080000548 <_l76>:
    80000548:	00050797          	auipc	a5,0x50
    8000054c:	b4878793          	addi	a5,a5,-1208 # 80050090 <d_4_7>
    80000550:	fe17c903          	lbu	s2,-31(a5)

0000000080000554 <_l77>:
    80000554:	30005073          	csrwi	mstatus,0
    80000558:	30405073          	csrwi	mie,0
    8000055c:	ff0e9337          	lui	t1,0xff0e9
    80000560:	9ef3031b          	addiw	t1,t1,-1553 # ffffffffff0e89ef <_end+0xffffffff7f0887ef>
    80000564:	033a                	slli	t1,t1,0xe
    80000566:	cef30313          	addi	t1,t1,-785
    8000056a:	0332                	slli	t1,t1,0xc
    8000056c:	d8130313          	addi	t1,t1,-639
    80000570:	0336                	slli	t1,t1,0xd
    80000572:	51130313          	addi	t1,t1,1297
    80000576:	74431ef3          	csrrw	t4,mnstatus,t1
    8000057a:	8876                	mv	a6,t4

000000008000057c <_l78>:
    8000057c:	d567cd93          	xori	s11,a5,-682

0000000080000580 <_l79>:
    80000580:	ffd93e37          	lui	t3,0xffd93
    80000584:	275e0e1b          	addiw	t3,t3,629 # ffffffffffd93275 <_end+0xffffffff7fd33075>
    80000588:	0e3e                	slli	t3,t3,0xf
    8000058a:	06fe0e13          	addi	t3,t3,111
    8000058e:	0e36                	slli	t3,t3,0xd
    80000590:	811e0e13          	addi	t3,t3,-2031
    80000594:	0e36                	slli	t3,t3,0xd
    80000596:	a16e0e13          	addi	t3,t3,-1514
    8000059a:	255e12f3          	csrrw	t0,vsireg4,t3
    8000059e:	8e16                	mv	t3,t0
    800005a0:	c016                	sw	t0,0(sp)

00000000800005a2 <_l80>:
    800005a2:	f1246ef3          	csrrsi	t4,marchid,8
    800005a6:	8a76                	mv	s4,t4

00000000800005a8 <_l81>:
    800005a8:	fd714f37          	lui	t5,0xfd714
    800005ac:	589f0f1b          	addiw	t5,t5,1417 # fffffffffd714589 <_end+0xffffffff7d6b4389>
    800005b0:	0f32                	slli	t5,t5,0xc
    800005b2:	e3bf0f13          	addi	t5,t5,-453
    800005b6:	0f32                	slli	t5,t5,0xc
    800005b8:	05ff0f13          	addi	t5,t5,95
    800005bc:	0f32                	slli	t5,t5,0xc
    800005be:	b22f0f13          	addi	t5,t5,-1246
    800005c2:	7b1f2373          	csrrs	t1,dpc,t5
    800005c6:	c01a                	sw	t1,0(sp)

00000000800005c8 <_l82>:
    800005c8:	d02901d3          	fcvt.s.l	ft3,s2,rne

00000000800005cc <_l83>:
    800005cc:	00903f37          	lui	t5,0x903
    800005d0:	b3ff0f1b          	addiw	t5,t5,-1217 # 902b3f <_start-0x7f6fd4c1>
    800005d4:	0f3e                	slli	t5,t5,0xf
    800005d6:	a73f0f13          	addi	t5,t5,-1421
    800005da:	0f32                	slli	t5,t5,0xc
    800005dc:	799f0f13          	addi	t5,t5,1945
    800005e0:	0f32                	slli	t5,t5,0xc
    800005e2:	766f0f13          	addi	t5,t5,1894
    800005e6:	7a4f3ef3          	csrrc	t4,tinfo,t5
    800005ea:	8276                	mv	tp,t4
    800005ec:	c076                	sw	t4,0(sp)

00000000800005ee <_l84>:
    800005ee:	00050917          	auipc	s2,0x50
    800005f2:	ac290913          	addi	s2,s2,-1342 # 800500b0 <d_4_9>
    800005f6:	00093d83          	ld	s11,0(s2)

00000000800005fa <_l85>:
    800005fa:	00000293          	li	t0,0
    800005fe:	7b22be73          	csrrc	t3,dscratch0,t0
    80000602:	8772                	mv	a4,t3

0000000080000604 <_l86>:
    80000604:	fff89f37          	lui	t5,0xfff89
    80000608:	d2bf0f1b          	addiw	t5,t5,-725 # fffffffffff88d2b <_end+0xffffffff7ff28b2b>
    8000060c:	1f02                	slli	t5,t5,0x20
    8000060e:	09ff0f13          	addi	t5,t5,159
    80000612:	0f32                	slli	t5,t5,0xc
    80000614:	e85f0f13          	addi	t5,t5,-379
    80000618:	180f33f3          	csrrc	t2,satp,t5

000000008000061c <_l87>:
    8000061c:	30005073          	csrwi	mstatus,0
    80000620:	00000293          	li	t0,0
    80000624:	7b12aff3          	csrrs	t6,dpc,t0
    80000628:	8d7e                	mv	s10,t6

000000008000062a <_l88>:
    8000062a:	30005073          	csrwi	mstatus,0
    8000062e:	3527ff73          	csrrci	t5,mireg2,15
    80000632:	817a                	mv	sp,t5

0000000080000634 <_l89>:
    80000634:	40fe529b          	sraiw	t0,t3,0xf

0000000080000638 <_l90>:
    80000638:	d0170a53          	fcvt.s.wu	fs4,a4,rne

000000008000063c <_l91>:
    8000063c:	290701d3          	fmin.s	ft3,fa4,fa6

0000000080000640 <_l92>:
    80000640:	30005073          	csrwi	mstatus,0
    80000644:	fd340337          	lui	t1,0xfd340
    80000648:	3093031b          	addiw	t1,t1,777 # fffffffffd340309 <_end+0xffffffff7d2e0109>
    8000064c:	0332                	slli	t1,t1,0xc
    8000064e:	f0330313          	addi	t1,t1,-253
    80000652:	0336                	slli	t1,t1,0xd
    80000654:	3a530313          	addi	t1,t1,933
    80000658:	0332                	slli	t1,t1,0xc
    8000065a:	0315                	addi	t1,t1,5
    8000065c:	7a331e73          	csrrw	t3,tdata3,t1
    80000660:	89f2                	mv	s3,t3

0000000080000662 <_l93>:
    80000662:	002b72f3          	csrrci	t0,frm,22
    80000666:	8f96                	mv	t6,t0

0000000080000668 <_l94>:
    80000668:	00010a17          	auipc	s4,0x10
    8000066c:	a68a0a13          	addi	s4,s4,-1432 # 800100d0 <d_0_11>
    80000670:	1a11                	addi	s4,s4,-28
    80000672:	616a2a2f          	amoand.w	s4,s6,(s4)

0000000080000676 <_l95>:
    80000676:	00020317          	auipc	t1,0x20
    8000067a:	9ba30313          	addi	t1,t1,-1606 # 80020030 <d_1_1>
    8000067e:	ffe00eb7          	lui	t4,0xffe00
    80000682:	01d34333          	xor	t1,t1,t4
    80000686:	fe432b87          	flw	fs7,-28(t1)

000000008000068a <_l96>:
    8000068a:	58030d53          	fsqrt.s	fs10,ft6,rne

000000008000068e <_good_exit>:
    8000068e:	00002097          	auipc	ra,0x2
    80000692:	b7208093          	addi	ra,ra,-1166 # 80002200 <csr_output_data>
    80000696:	10002173          	csrr	sp,sstatus
    8000069a:	0420bc23          	sd	sp,88(ra)
    8000069e:	10402173          	csrr	sp,sie
    800006a2:	0620b823          	sd	sp,112(ra)
    800006a6:	10502173          	csrr	sp,stvec
    800006aa:	0620bc23          	sd	sp,120(ra)
    800006ae:	10602173          	csrr	sp,scounteren
    800006b2:	0820b023          	sd	sp,128(ra)
    800006b6:	14002173          	csrr	sp,sscratch
    800006ba:	0820b423          	sd	sp,136(ra)
    800006be:	14102173          	csrr	sp,sepc
    800006c2:	0820b823          	sd	sp,144(ra)
    800006c6:	14202173          	csrr	sp,scause
    800006ca:	0820bc23          	sd	sp,152(ra)
    800006ce:	14302173          	csrr	sp,stval
    800006d2:	0a20b023          	sd	sp,160(ra)
    800006d6:	14402173          	csrr	sp,sip
    800006da:	f7f17113          	andi	sp,sp,-129
    800006de:	0a20b423          	sd	sp,168(ra)
    800006e2:	18002173          	csrr	sp,satp
    800006e6:	0a20b823          	sd	sp,176(ra)
    800006ea:	f1402173          	csrr	sp,mhartid
    800006ee:	0a20bc23          	sd	sp,184(ra)
    800006f2:	30002173          	csrr	sp,mstatus
    800006f6:	0c20b023          	sd	sp,192(ra)
    800006fa:	30202173          	csrr	sp,medeleg
    800006fe:	0c20b423          	sd	sp,200(ra)
    80000702:	30302173          	csrr	sp,mideleg
    80000706:	0c20b823          	sd	sp,208(ra)
    8000070a:	30402173          	csrr	sp,mie
    8000070e:	0c20bc23          	sd	sp,216(ra)
    80000712:	30502173          	csrr	sp,mtvec
    80000716:	0e20b023          	sd	sp,224(ra)
    8000071a:	30602173          	csrr	sp,mcounteren
    8000071e:	0e20b423          	sd	sp,232(ra)
    80000722:	34002173          	csrr	sp,mscratch
    80000726:	0e20b823          	sd	sp,240(ra)
    8000072a:	34102173          	csrr	sp,mepc
    8000072e:	0e20bc23          	sd	sp,248(ra)
    80000732:	34202173          	csrr	sp,mcause
    80000736:	1020b023          	sd	sp,256(ra)
    8000073a:	34302173          	csrr	sp,mtval
    8000073e:	1020b423          	sd	sp,264(ra)
    80000742:	34402173          	csrr	sp,mip
    80000746:	f7f17113          	andi	sp,sp,-129
    8000074a:	1020b823          	sd	sp,272(ra)
    8000074e:	3a002173          	csrr	sp,pmpcfg0
    80000752:	1020bc23          	sd	sp,280(ra)
    80000756:	3b002173          	csrr	sp,pmpaddr0
    8000075a:	1220bc23          	sd	sp,312(ra)
    8000075e:	3b102173          	csrr	sp,pmpaddr1
    80000762:	1420b023          	sd	sp,320(ra)
    80000766:	3b202173          	csrr	sp,pmpaddr2
    8000076a:	1420b423          	sd	sp,328(ra)
    8000076e:	3b302173          	csrr	sp,pmpaddr3
    80000772:	1420b823          	sd	sp,336(ra)
    80000776:	3b402173          	csrr	sp,pmpaddr4
    8000077a:	1420bc23          	sd	sp,344(ra)
    8000077e:	3b502173          	csrr	sp,pmpaddr5
    80000782:	1620b023          	sd	sp,352(ra)
    80000786:	3b602173          	csrr	sp,pmpaddr6
    8000078a:	1620b423          	sd	sp,360(ra)
    8000078e:	3b702173          	csrr	sp,pmpaddr7
    80000792:	1620b823          	sd	sp,368(ra)
    80000796:	6519                	lui	a0,0x6
    80000798:	30052073          	csrs	mstatus,a0

000000008000079c <fcsrs_dump>:
    8000079c:	00102173          	frflags	sp
    800007a0:	0420b023          	sd	sp,64(ra)
    800007a4:	00202173          	frrm	sp
    800007a8:	0420b423          	sd	sp,72(ra)
    800007ac:	00302173          	frcsr	sp
    800007b0:	0420b823          	sd	sp,80(ra)

00000000800007b4 <reg_dump>:
    800007b4:	00002097          	auipc	ra,0x2
    800007b8:	84c08093          	addi	ra,ra,-1972 # 80002000 <begin_signature>
    800007bc:	0000b023          	sd	zero,0(ra)
    800007c0:	0020b823          	sd	sp,16(ra)
    800007c4:	0030bc23          	sd	gp,24(ra)
    800007c8:	0240b023          	sd	tp,32(ra)
    800007cc:	0250b423          	sd	t0,40(ra)
    800007d0:	0260b823          	sd	t1,48(ra)
    800007d4:	0270bc23          	sd	t2,56(ra)
    800007d8:	0480b023          	sd	s0,64(ra)
    800007dc:	0490b423          	sd	s1,72(ra)
    800007e0:	04a0b823          	sd	a0,80(ra)
    800007e4:	04b0bc23          	sd	a1,88(ra)
    800007e8:	06c0b023          	sd	a2,96(ra)
    800007ec:	06d0b423          	sd	a3,104(ra)
    800007f0:	06e0b823          	sd	a4,112(ra)
    800007f4:	06f0bc23          	sd	a5,120(ra)
    800007f8:	0900b023          	sd	a6,128(ra)
    800007fc:	0910b423          	sd	a7,136(ra)
    80000800:	0920b823          	sd	s2,144(ra)
    80000804:	0930bc23          	sd	s3,152(ra)
    80000808:	0b40b023          	sd	s4,160(ra)
    8000080c:	0b50b423          	sd	s5,168(ra)
    80000810:	0b60b823          	sd	s6,176(ra)
    80000814:	0b70bc23          	sd	s7,184(ra)
    80000818:	0d80b023          	sd	s8,192(ra)
    8000081c:	0d90b423          	sd	s9,200(ra)
    80000820:	0db0bc23          	sd	s11,216(ra)
    80000824:	0fc0b023          	sd	t3,224(ra)
    80000828:	0fd0b423          	sd	t4,232(ra)
    8000082c:	0fe0b823          	sd	t5,240(ra)

0000000080000830 <freg_dump>:
    80000830:	00002097          	auipc	ra,0x2
    80000834:	8d008093          	addi	ra,ra,-1840 # 80002100 <freg_output_data>
    80000838:	0010a427          	fsw	ft1,8(ra)
    8000083c:	0020a827          	fsw	ft2,16(ra)
    80000840:	0270ac27          	fsw	ft7,56(ra)
    80000844:	0490a427          	fsw	fs1,72(ra)
    80000848:	04a0a827          	fsw	fa0,80(ra)
    8000084c:	06c0a027          	fsw	fa2,96(ra)
    80000850:	06d0a427          	fsw	fa3,104(ra)
    80000854:	0b50a427          	fsw	fs5,168(ra)
    80000858:	0b60a827          	fsw	fs6,176(ra)
    8000085c:	0d90a427          	fsw	fs9,200(ra)
    80000860:	0da0a827          	fsw	fs10,208(ra)
    80000864:	0fc0a027          	fsw	ft8,224(ra)
    80000868:	0fd0a427          	fsw	ft9,232(ra)
    8000086c:	0fe0a827          	fsw	ft10,240(ra)
    80000870:	0ff0ac27          	fsw	ft11,248(ra)
    80000874:	00002097          	auipc	ra,0x2
    80000878:	88c08093          	addi	ra,ra,-1908 # 80002100 <freg_output_data>
    8000087c:	0000b027          	fsd	ft0,0(ra)
    80000880:	0030bc27          	fsd	ft3,24(ra)
    80000884:	0240b027          	fsd	ft4,32(ra)
    80000888:	0250b427          	fsd	ft5,40(ra)
    8000088c:	0260b827          	fsd	ft6,48(ra)
    80000890:	0480b027          	fsd	fs0,64(ra)
    80000894:	04b0bc27          	fsd	fa1,88(ra)
    80000898:	06e0b827          	fsd	fa4,112(ra)
    8000089c:	06f0bc27          	fsd	fa5,120(ra)
    800008a0:	0900b027          	fsd	fa6,128(ra)
    800008a4:	0910b427          	fsd	fa7,136(ra)
    800008a8:	0920b827          	fsd	fs2,144(ra)
    800008ac:	0930bc27          	fsd	fs3,152(ra)
    800008b0:	0b40b027          	fsd	fs4,160(ra)
    800008b4:	0b70bc27          	fsd	fs7,184(ra)
    800008b8:	0d80b027          	fsd	fs8,192(ra)
    800008bc:	0db0bc27          	fsd	fs11,216(ra)
    800008c0:	4501                	li	a0,0
    800008c2:	0005006b          	.insn	4, 0x0005006b
    800008c6:	4185                	li	gp,1
    800008c8:	00000f17          	auipc	t5,0x0
    800008cc:	723f2c23          	sw	gp,1848(t5) # 80001000 <tohost>
    800008d0:	a001                	j	800008d0 <freg_dump+0xa0>

00000000800008d2 <_end_main>:
	...
    800008e2:	0001                	nop
    800008e4:	00000013          	nop
    800008e8:	00000013          	nop
    800008ec:	00000013          	nop
    800008f0:	00000013          	nop
    800008f4:	00000013          	nop
    800008f8:	00000013          	nop
    800008fc:	00000013          	nop
    80000900:	00000013          	nop
    80000904:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	6cc6                	ld	s9,80(sp)
    80010002:	8098                	.insn	2, 0x8098
    80010004:	164a                	slli	a2,a2,0x32
    80010006:	27453daf          	amoxor.d.aqrl	s11,s4,(a0)
    8001000a:	fc6157d3          	.insn	4, 0xfc6157d3
    8001000e:	5285                	li	t0,-31
    80010010:	8754                	.insn	2, 0x8754
    80010012:	d8e0963b          	.insn	4, 0xd8e0963b
    80010016:	1374846b          	.insn	4, 0x1374846b
    8001001a:	fd3a                	sd	a4,184(sp)
    8001001c:	069563cf          	.insn	4, 0x069563cf

0000000080010020 <d_0_0>:
    80010020:	0cbf7ac3          	.insn	4, 0x0cbf7ac3
    80010024:	2207a04f          	fnmadd.d	ft0,fa5,ft0,ft4,rdn
    80010028:	9c8977a7          	.insn	4, 0x9c8977a7
    8001002c:	4304                	lw	s1,0(a4)
    8001002e:	b90d                	j	8000fc60 <end_signature+0xd880>

0000000080010030 <d_0_1>:
    80010030:	aa09                	j	80010142 <d_0_18+0x2>
    80010032:	6931                	lui	s2,0xc
    80010034:	ce51                	beqz	a2,800100d0 <d_0_11>
    80010036:	4429                	li	s0,10
    80010038:	6056                	.insn	2, 0x6056
    8001003a:	ac7f a229 15e2  	.insn	14, 0xdb6e7b79e56c41d015e2a229ac7f
    80010042:	   

0000000080010040 <d_0_2>:
    80010040:	41d0                	lw	a2,4(a1)
    80010042:	e56c                	sd	a1,200(a0)
    80010044:	7b79                	lui	s6,0xffffe
    80010046:	db6e                	sw	s11,180(sp)
    80010048:	7be0                	ld	s0,240(a5)
    8001004a:	37dbf0c3          	.insn	4, 0x37dbf0c3
    8001004e:	9c54                	.insn	2, 0x9c54

0000000080010050 <d_0_3>:
    80010050:	75b8                	ld	a4,104(a1)
    80010052:	712e                	ld	sp,232(sp)
    80010054:	31e8                	fld	fa0,224(a1)
    80010056:	a722                	fsd	fs0,392(sp)
    80010058:	f840                	sd	s0,176(s0)
    8001005a:	9c8614cb          	.insn	4, 0x9c8614cb
    8001005e:	225a                	fld	ft4,400(sp)

0000000080010060 <d_0_4>:
    80010060:	b9771e53          	.insn	4, 0xb9771e53
    80010064:	de50                	sw	a2,60(a2)
    80010066:	c6d85c6f          	jal	s8,7ff95cd2 <_start-0x6a32e>
    8001006a:	9c89                	subw	s1,s1,a0
    8001006c:	4722                	lw	a4,8(sp)
    8001006e:	8058                	.insn	2, 0x8058

0000000080010070 <d_0_5>:
    80010070:	6681                	.insn	2, 0x6681
    80010072:	120d                	addi	tp,tp,-29 # ffffffffffffffe3 <_end+0xffffffff7ff9fde3>
    80010074:	1fe0                	addi	s0,sp,1020
    80010076:	d118                	sw	a4,32(a0)
    80010078:	f0ba5e3f 1f6c1527 	.insn	8, 0x1f6c1527f0ba5e3f

0000000080010080 <d_0_6>:
    80010080:	fee8                	sd	a0,248(a3)
    80010082:	1e56                	slli	t3,t3,0x35
    80010084:	8ec2b8b3          	.insn	4, 0x8ec2b8b3
    80010088:	672a                	ld	a4,136(sp)
    8001008a:	f0a9                	bnez	s1,8000ffcc <end_signature+0xdbec>
    8001008c:	cc5a                	sw	s6,24(sp)
    8001008e:	b70a                	fsd	ft2,424(sp)

0000000080010090 <d_0_7>:
    80010090:	7efa83b3          	.insn	4, 0x7efa83b3
    80010094:	8ff0                	.insn	2, 0x8ff0
    80010096:	fae243b3          	.insn	4, 0xfae243b3
    8001009a:	071d                	addi	a4,a4,7
    8001009c:	4c0a                	lw	s8,128(sp)
    8001009e:	bec2                	fsd	fa6,376(sp)

00000000800100a0 <d_0_8>:
    800100a0:	efb9                	bnez	a5,800100fe <d_0_13+0xe>
    800100a2:	04da                	slli	s1,s1,0x16
    800100a4:	c44c                	sw	a1,12(s0)
    800100a6:	67bd                	lui	a5,0xf
    800100a8:	4218                	lw	a4,0(a2)
    800100aa:	215dfcd7          	vsetvli	s9,s11,533
    800100ae:	          	.insn	4, 0x98c4139b

00000000800100b0 <d_0_9>:
    800100b0:	98c4                	.insn	2, 0x98c4
    800100b2:	d465                	beqz	s0,8001009a <d_0_7+0xa>
    800100b4:	82de                	mv	t0,s7
    800100b6:	8c08                	.insn	2, 0x8c08
    800100b8:	2a70                	fld	fa2,208(a2)
    800100ba:	3385                	addiw	t2,t2,-31
    800100bc:	180e                	slli	a6,a6,0x23
    800100be:	          	lw	s0,614(a5) # f266 <_start-0x7fff0d9a>

00000000800100c0 <d_0_10>:
    800100c0:	546b2667          	.insn	4, 0x546b2667
    800100c4:	de5b4c2b          	.insn	4, 0xde5b4c2b
    800100c8:	4b8a                	lw	s7,128(sp)
    800100ca:	79d8                	ld	a4,176(a1)
    800100cc:	423c                	lw	a5,64(a2)
    800100ce:	ec31                	bnez	s0,8001012a <d_0_16+0xa>

00000000800100d0 <d_0_11>:
    800100d0:	11ae                	slli	gp,gp,0x2b
    800100d2:	7ea632bf fc949d37 	.insn	8, 0xfc949d377ea632bf
    800100da:	3669                	addiw	a2,a2,-6
    800100dc:	e794                	sd	a3,8(a5)
    800100de:	3188                	fld	fa0,32(a1)

00000000800100e0 <d_0_12>:
    800100e0:	6b9a                	ld	s7,384(sp)
    800100e2:	41874f8b          	.insn	4, 0x41874f8b
    800100e6:	6884                	ld	s1,16(s1)
    800100e8:	bc18                	fsd	fa4,56(s0)
    800100ea:	f5f1                	bnez	a1,800100b6 <d_0_9+0x6>
    800100ec:	f1f9                	bnez	a1,800100b2 <d_0_9+0x2>
    800100ee:	22fa                	fld	ft5,408(sp)

00000000800100f0 <d_0_13>:
    800100f0:	6cdc                	ld	a5,152(s1)
    800100f2:	7871                	lui	a6,0xffffc
    800100f4:	1d3314bf 8caa461b 	.insn	8, 0x8caa461b1d3314bf
    800100fc:	5186                	lw	gp,96(sp)
    800100fe:	6af2                	ld	s5,280(sp)

0000000080010100 <d_0_14>:
    80010100:	a710                	fsd	fa2,8(a4)
    80010102:	3910                	fld	fa2,48(a0)
    80010104:	6c0c0043          	.insn	4, 0x6c0c0043
    80010108:	5fee                	lw	t6,248(sp)
    8001010a:	ee1b164b          	.insn	4, 0xee1b164b
    8001010e:	4688                	lw	a0,8(a3)

0000000080010110 <d_0_15>:
    80010110:	3e6899e3          	bne	a7,t1,80010d02 <_end_data0+0xb02>
    80010114:	94c8                	.insn	2, 0x94c8
    80010116:	1b3e                	slli	s6,s6,0x2f
    80010118:	d38e                	sw	gp,228(sp)
    8001011a:	606e                	.insn	2, 0x606e
    8001011c:	2708                	fld	fa0,8(a4)
    8001011e:	a7a4                	fsd	fs1,72(a5)

0000000080010120 <d_0_16>:
    80010120:	f0e3ac33          	.insn	4, 0xf0e3ac33
    80010124:	1285                	addi	t0,t0,-31
    80010126:	2d5c                	fld	fa5,152(a0)
    80010128:	806a                	c.mv	zero,s10
    8001012a:	e578990f          	.insn	4, 0xe578990f
    8001012e:	5246                	lw	tp,112(sp)

0000000080010130 <d_0_17>:
    80010130:	e473dd47          	.insn	4, 0xe473dd47
    80010134:	de28                	sw	a0,120(a2)
    80010136:	aa6c                	fsd	fa1,208(a2)
    80010138:	7e12                	ld	t3,288(sp)
    8001013a:	2286                	fld	ft5,64(sp)
    8001013c:	40f1                	li	ra,28
    8001013e:	9caa                	add	s9,s9,a0

0000000080010140 <d_0_18>:
    80010140:	b98d                	j	8000fdb2 <end_signature+0xd9d2>
    80010142:	b864                	fsd	fs1,240(s0)
    80010144:	d0e6                	sw	s9,96(sp)
    80010146:	52df dce6 d96e      	.insn	6, 0xd96edce652df
    8001014c:	7cb4                	ld	a3,120(s1)
    8001014e:	          	lui	a0,0x355cc

0000000080010150 <d_0_19>:
    80010150:	355c                	fld	fa5,168(a0)
    80010152:	7362                	ld	t1,56(sp)
    80010154:	8e7e                	mv	t3,t6
    80010156:	22cb90c7          	fmsub.d	ft1,fs7,fa2,ft4,rtz
    8001015a:	d79d                	beqz	a5,80010088 <d_0_6+0x8>
    8001015c:	65c0                	ld	s0,136(a1)
    8001015e:	a22d                	j	80010288 <_end_data0+0x88>

0000000080010160 <d_0_20>:
    80010160:	7f1a27a3          	sw	a7,2031(s4)
    80010164:	d080                	sw	s0,32(s1)
    80010166:	c938                	sw	a4,80(a0)
    80010168:	7799                	lui	a5,0xfffe6
    8001016a:	44521da7          	.insn	4, 0x44521da7
    8001016e:	4ba6                	lw	s7,72(sp)

0000000080010170 <d_0_21>:
    80010170:	923603fb          	.insn	4, 0x923603fb
    80010174:	65ecf1f7          	.insn	4, 0x65ecf1f7
    80010178:	6e1f fcaa 335b      	.insn	6, 0x335bfcaa6e1f
    8001017e:	5151                	li	sp,-12

0000000080010180 <d_0_22>:
    80010180:	115d                	addi	sp,sp,-9
    80010182:	192b2a2f          	sc.w	s4,s2,(s6)
    80010186:	8916                	mv	s2,t0
    80010188:	c672fd33          	.insn	4, 0xc672fd33
    8001018c:	097e                	slli	s2,s2,0x1f
    8001018e:	d814                	sw	a3,48(s0)

0000000080010190 <d_0_23>:
    80010190:	3b4a80b7          	lui	ra,0x3b4a8
    80010194:	78850a7b          	.insn	4, 0x78850a7b
    80010198:	2bf1                	addiw	s7,s7,28
    8001019a:	95d2                	add	a1,a1,s4
    8001019c:	6b8a                	ld	s7,128(sp)
    8001019e:	c2df        	.insn	6, 0x7c562a54c2df

00000000800101a0 <d_0_24>:
    800101a0:	2a54                	fld	fa3,144(a2)
    800101a2:	7c56                	ld	s8,368(sp)
    800101a4:	81f1                	srli	a1,a1,0x1c
    800101a6:	389f eb51 2a7d      	.insn	6, 0x2a7deb51389f
    800101ac:	da69                	beqz	a2,8001017e <d_0_21+0xe>
    800101ae:	26dc                	fld	fa5,136(a3)

00000000800101b0 <d_0_25>:
    800101b0:	07f8                	addi	a4,sp,972
    800101b2:	def4                	sw	a3,124(a3)
    800101b4:	0b1afa07          	vlse64.v	v20,(s5),a7
    800101b8:	6b12                	ld	s6,256(sp)
    800101ba:	af723857          	vssra.vi	v16,v23,4
    800101be:	e5b5                	bnez	a1,8001022a <_end_data0+0x2a>

00000000800101c0 <d_0_26>:
    800101c0:	608e                	ld	ra,192(sp)
    800101c2:	d5fc                	sw	a5,108(a1)
    800101c4:	1edd                	addi	t4,t4,-9 # ffffffffffdffff7 <_end+0xffffffff7fd9fdf7>
    800101c6:	6ddc060f          	.insn	4, 0x6ddc060f
    800101ca:	e9d7920f          	.insn	4, 0xe9d7920f
    800101ce:	d805                	beqz	s0,800100fe <d_0_13+0xe>

00000000800101d0 <d_0_27>:
    800101d0:	e486                	sd	ra,72(sp)
    800101d2:	ffae                	sd	a1,504(sp)
    800101d4:	f54d                	bnez	a0,8001017e <d_0_21+0xe>
    800101d6:	7fc3dce3          	bge	t2,t3,800111ce <_end_data0+0xfce>
    800101da:	9772                	add	a4,a4,t3
    800101dc:	e63ea48b          	.insn	4, 0xe63ea48b
    800101e0:	fba5                	bnez	a5,80010150 <d_0_19>
    800101e2:	6c12                	ld	s8,256(sp)
    800101e4:	7f6e                	ld	t5,248(sp)
    800101e6:	74d85ca7          	.insn	4, 0x74d85ca7
    800101ea:	914ec3c3          	fmadd.s	ft7,ft9,fs4,fs2,rmm
    800101ee:	593f2733          	.insn	4, 0x593f2733
    800101f2:	c5b4                	sw	a3,72(a1)
    800101f4:	7fea                	ld	t6,184(sp)
    800101f6:	90ef597b          	.insn	4, 0x90ef597b
    800101fa:	3cd1ae77          	.insn	4, 0x3cd1ae77
    800101fe:	f0af                	.short	0xf0af

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	fe41                	bnez	a2,8001ff98 <_end_data0+0xfd98>
    80020002:	7bf9498f          	.insn	4, 0x7bf9498f
    80020006:	ad98                	fsd	fa4,24(a1)
    80020008:	c26703ab          	.insn	4, 0xc26703ab
    8002000c:	cc9a                	sw	t1,88(sp)
    8002000e:	5519                	li	a0,-26
    80020010:	b03d                	j	8001f83e <_end_data0+0xf63e>
    80020012:	6595                	lui	a1,0x5
    80020014:	7849                	lui	a6,0xffff2
    80020016:	6bfd                	lui	s7,0x1f
    80020018:	99ccdee7          	.insn	4, 0x99ccdee7
    8002001c:	1834                	addi	a3,sp,56
    8002001e:	82d9                	srli	a3,a3,0x16

0000000080020020 <d_1_0>:
    80020020:	05538b57          	.insn	4, 0x05538b57
    80020024:	7331                	lui	t1,0xfffec
    80020026:	c7e2ad87          	flw	fs11,-898(t0)
    8002002a:	14d1                	addi	s1,s1,-12
    8002002c:	e22c                	sd	a1,64(a2)
    8002002e:	3e7e                	fld	ft8,504(sp)

0000000080020030 <d_1_1>:
    80020030:	0f587f03          	.insn	4, 0x0f587f03
    80020034:	0ab0                	addi	a2,sp,344
    80020036:	a22d                	j	80020160 <d_1_20>
    80020038:	017f 00aa f9e1 3134 	.insn	10, 0x66843134f9e100aa017f
    80020040:	 

0000000080020040 <d_1_2>:
    80020040:	6684                	ld	s1,8(a3)
    80020042:	b2356a2b          	.insn	4, 0xb2356a2b
    80020046:	fed6                	sd	s5,376(sp)
    80020048:	7278                	ld	a4,224(a2)
    8002004a:	f7ea                	sd	s10,488(sp)
    8002004c:	eaae                	sd	a1,336(sp)
    8002004e:	1104                	addi	s1,sp,160

0000000080020050 <d_1_3>:
    80020050:	5c51                	li	s8,-12
    80020052:	3862                	fld	fa6,56(sp)
    80020054:	8ecc                	.insn	2, 0x8ecc
    80020056:	ce36abef          	jal	s7,7ff8ad38 <_start-0x752c8>
    8002005a:	b8d2                	fsd	fs4,112(sp)
    8002005c:	0eaa                	slli	t4,t4,0xa
    8002005e:	          	auipc	s11,0x54a81

0000000080020060 <d_1_4>:
    80020060:	54a8                	lw	a0,104(s1)
    80020062:	d121                	beqz	a0,8001ffa2 <_end_data0+0xfda2>
    80020064:	c9e6                	sw	s9,208(sp)
    80020066:	ab05bf27          	fsd	fa6,-1346(a1) # 4abe <_start-0x7fffb542>
    8002006a:	b35d2497          	auipc	s1,0xb35d2
    8002006e:	8285                	srli	a3,a3,0x1

0000000080020070 <d_1_5>:
    80020070:	c7b8                	sw	a4,72(a5)
    80020072:	ab94ee0f          	.insn	4, 0xab94ee0f
    80020076:	ded5                	beqz	a3,80020032 <d_1_1+0x2>
    80020078:	ac31                	j	80020294 <_end_data1+0x94>
    8002007a:	0d31                	addi	s10,s10,12
    8002007c:	21d4                	fld	fa3,128(a1)
    8002007e:	91fe                	add	gp,gp,t6

0000000080020080 <d_1_6>:
    80020080:	b279                	j	8001fa0e <_end_data0+0xf80e>
    80020082:	8225                	srli	a2,a2,0x9
    80020084:	96a8                	.insn	2, 0x96a8
    80020086:	b17d                	j	8001fd34 <_end_data0+0xfb34>
    80020088:	9942                	add	s2,s2,a6
    8002008a:	8ec5                	or	a3,a3,s1
    8002008c:	bd17322f          	.insn	4, 0xbd17322f

0000000080020090 <d_1_7>:
    80020090:	1f56                	slli	t5,t5,0x35
    80020092:	a360                	fsd	fs0,192(a4)
    80020094:	b75f d20d 9d6f      	.insn	6, 0x9d6fd20db75f
    8002009a:	857d                	srai	a0,a0,0x1f
    8002009c:	b449df43          	.insn	4, 0xb449df43

00000000800200a0 <d_1_8>:
    800200a0:	3d3fec83          	lwu	s9,979(t6)
    800200a4:	c470                	sw	a2,76(s0)
    800200a6:	1edf 60b7 ae5b      	.insn	6, 0xae5b60b71edf
    800200ac:	ffe4                	sd	s1,248(a5)
    800200ae:	4a9a                	lw	s5,132(sp)

00000000800200b0 <d_1_9>:
    800200b0:	6b3c                	ld	a5,80(a4)
    800200b2:	1d9074db          	.insn	4, 0x1d9074db
    800200b6:	3120                	fld	fs0,96(a0)
    800200b8:	be52                	fsd	fs4,312(sp)
    800200ba:	ea4c                	sd	a1,144(a2)
    800200bc:	889d                	andi	s1,s1,7
    800200be:	600a                	.insn	2, 0x600a

00000000800200c0 <d_1_10>:
    800200c0:	e55f ad44 3316      	.insn	6, 0x3316ad44e55f
    800200c6:	509d                	li	ra,-25
    800200c8:	a18c                	fsd	fa1,0(a1)
    800200ca:	084aeacf          	fnmadd.s	fs5,fs5,ft4,ft1,unknown
    800200ce:	bf1d                	j	80020004 <_random_data1+0x4>

00000000800200d0 <d_1_11>:
    800200d0:	1177a1af          	.insn	4, 0x1177a1af
    800200d4:	3bf1                	addiw	s7,s7,-4 # 1effc <_start-0x7ffe1004>
    800200d6:	53e4                	lw	s1,100(a5)
    800200d8:	5014                	lw	a3,32(s0)
    800200da:	5432                	lw	s0,44(sp)
    800200dc:	dfd0                	sw	a2,60(a5)
    800200de:	87e8                	.insn	2, 0x87e8

00000000800200e0 <d_1_12>:
    800200e0:	f8a0                	sd	s0,112(s1)
    800200e2:	a75d                	j	80020888 <_end_data1+0x688>
    800200e4:	49da                	lw	s3,148(sp)
    800200e6:	14e6                	slli	s1,s1,0x39
    800200e8:	5e5e9e0f          	.insn	4, 0x5e5e9e0f
    800200ec:	ffa6                	sd	s1,504(sp)
    800200ee:	4909                	li	s2,2

00000000800200f0 <d_1_13>:
    800200f0:	6260                	ld	s0,192(a2)
    800200f2:	b8ba                	fsd	fa4,112(sp)
    800200f4:	ed88                	sd	a0,24(a1)
    800200f6:	8d4e9de3          	bne	t4,s4,8001f9d0 <_end_data0+0xf7d0>
    800200fa:	77b5                	lui	a5,0xfffed
    800200fc:	6e6d                	lui	t3,0x1b
    800200fe:	          	auipc	s8,0x45efc

0000000080020100 <d_1_14>:
    80020100:	c68a45ef          	jal	a1,7ffc4568 <_start-0x3ba98>
    80020104:	f3de                	sd	s7,480(sp)
    80020106:	0866                	slli	a6,a6,0x19
    80020108:	1a8d                	addi	s5,s5,-29
    8002010a:	1238                	addi	a4,sp,296
    8002010c:	ac05                	j	8002033c <_end_data1+0x13c>
    8002010e:	c46a                	sw	s10,8(sp)

0000000080020110 <d_1_15>:
    80020110:	f4bc                	sd	a5,104(s1)
    80020112:	add8                	fsd	fa4,152(a1)
    80020114:	4938                	lw	a4,80(a0)
    80020116:	2a41                	addiw	s4,s4,16
    80020118:	5348                	lw	a0,36(a4)
    8002011a:	0d6d                	addi	s10,s10,27
    8002011c:	26e5                	addiw	a3,a3,25
    8002011e:	c431                	beqz	s0,8002016a <d_1_20+0xa>

0000000080020120 <d_1_16>:
    80020120:	1532                	slli	a0,a0,0x2c
    80020122:	fac1                	bnez	a3,800200b2 <d_1_9+0x2>
    80020124:	240f1beb          	.insn	4, 0x240f1beb
    80020128:	ed26                	sd	s1,152(sp)
    8002012a:	7800                	ld	s0,48(s0)
    8002012c:	a50a0da7          	vsuxseg6ei8.v	v27,(s4),v16,v0.t

0000000080020130 <d_1_17>:
    80020130:	4b891453          	.insn	4, 0x4b891453
    80020134:	f1c1ac03          	lw	s8,-228(gp)
    80020138:	ca16                	sw	t0,20(sp)
    8002013a:	ddea                	sw	s10,248(sp)
    8002013c:	706fb04b          	fnmsub.s	ft0,ft11,ft6,fa4,rup

0000000080020140 <d_1_18>:
    80020140:	1d6e                	slli	s10,s10,0x3b
    80020142:	01b9                	addi	gp,gp,14
    80020144:	2e08                	fld	fa0,24(a2)
    80020146:	7130                	ld	a2,96(a0)
    80020148:	c021768b          	.insn	4, 0xc021768b
    8002014c:	f3e2                	sd	s8,480(sp)
    8002014e:	cb6e                	sw	s11,148(sp)

0000000080020150 <d_1_19>:
    80020150:	af02                	fsd	ft0,408(sp)
    80020152:	1856                	slli	a6,a6,0x35
    80020154:	55f6                	lw	a1,124(sp)
    80020156:	d6ea                	sw	s10,108(sp)
    80020158:	f925                	bnez	a0,800200c8 <d_1_10+0x8>
    8002015a:	6f84                	ld	s1,24(a5)
    8002015c:	2e9a                	fld	ft9,384(sp)
    8002015e:	11bc                	addi	a5,sp,232

0000000080020160 <d_1_20>:
    80020160:	2719                	addiw	a4,a4,6
    80020162:	099d                	addi	s3,s3,7
    80020164:	2c19                	addiw	s8,s8,6 # ffffffffc5f1c104 <_end+0xffffffff45ebbf04>
    80020166:	a04c                	fsd	fa1,128(s0)
    80020168:	de81                	beqz	a3,80020080 <d_1_6>
    8002016a:	4a4d                	li	s4,19
    8002016c:	bfaa                	fsd	fa0,504(sp)
    8002016e:	          	.insn	4, 0xcadca4db

0000000080020170 <d_1_21>:
    80020170:	cadc                	sw	a5,20(a3)
    80020172:	5be8                	lw	a0,116(a5)
    80020174:	13dbab23          	sw	t4,310(s7)
    80020178:	766e                	ld	a2,248(sp)
    8002017a:	cba5                	beqz	a5,800201ea <d_1_27+0x1a>
    8002017c:	af02                	fsd	ft0,408(sp)
    8002017e:	09d6                	slli	s3,s3,0x15

0000000080020180 <d_1_22>:
    80020180:	c57c                	sw	a5,76(a0)
    80020182:	24d1                	addiw	s1,s1,20 # 335f207e <_start-0x4ca0df82>
    80020184:	f9d0                	sd	a2,176(a1)
    80020186:	27c2debb          	.insn	4, 0x27c2debb
    8002018a:	ca2d                	beqz	a2,800201fc <d_1_27+0x2c>
    8002018c:	999a                	add	s3,s3,t1
    8002018e:	70f6                	ld	ra,376(sp)

0000000080020190 <d_1_23>:
    80020190:	4415                	li	s0,5
    80020192:	2e3d                	addiw	t3,t3,15 # 1b00f <_start-0x7ffe4ff1>
    80020194:	6599eec7          	.insn	4, 0x6599eec7
    80020198:	768c                	ld	a1,40(a3)
    8002019a:	025d                	addi	tp,tp,23 # 17 <_start-0x7fffffe9>
    8002019c:	1f415c27          	.insn	4, 0x1f415c27

00000000800201a0 <d_1_24>:
    800201a0:	6646                	ld	a2,80(sp)
    800201a2:	f410                	sd	a2,40(s0)
    800201a4:	7b25                	lui	s6,0xfffe9
    800201a6:	a328                	fsd	fa0,64(a4)
    800201a8:	be51                	j	8001fd3c <_end_data0+0xfb3c>
    800201aa:	8d38                	.insn	2, 0x8d38
    800201ac:	4082                	lw	ra,0(sp)
    800201ae:	1061                	c.nop	-8

00000000800201b0 <d_1_25>:
    800201b0:	78e43273          	csrrc	tp,0x78e,s0
    800201b4:	ca7d3e4b          	fnmsub.d	ft8,fs10,ft7,fs9,rup
    800201b8:	50b2                	lw	ra,44(sp)
    800201ba:	60dedfef          	jal	t6,8010dfc6 <_end+0xaddc6>
    800201be:	          	.insn	4, 0xe7151bab

00000000800201c0 <d_1_26>:
    800201c0:	e715                	bnez	a4,800201ec <d_1_27+0x1c>
    800201c2:	cec1                	beqz	a3,8002025a <_end_data1+0x5a>
    800201c4:	7f04                	ld	s1,56(a4)
    800201c6:	6e02                	ld	t3,0(sp)
    800201c8:	7651                	lui	a2,0xffff4
    800201ca:	8745                	srai	a4,a4,0x11
    800201cc:	2c48490b          	.insn	4, 0x2c48490b

00000000800201d0 <d_1_27>:
    800201d0:	f759                	bnez	a4,8002015e <d_1_19+0xe>
    800201d2:	32081f8f          	.insn	4, 0x32081f8f
    800201d6:	ef6d                	bnez	a4,800202d0 <_end_data1+0xd0>
    800201d8:	48cc                	lw	a1,20(s1)
    800201da:	2505                	addiw	a0,a0,1 # 355cc001 <_start-0x4aa33fff>
    800201dc:	6a8b5c2f          	.insn	4, 0x6a8b5c2f
    800201e0:	52d9cdcf          	fnmadd.d	fs11,fs3,fa3,fa0,rmm
    800201e4:	45f46207          	vluxseg3ei32.v	v4,(s0),v31,v0.t
    800201e8:	9df8                	.insn	2, 0x9df8
    800201ea:	6032                	.insn	2, 0x6032
    800201ec:	3c48                	fld	fa0,184(s0)
    800201ee:	952e                	add	a0,a0,a1
    800201f0:	10f4                	addi	a3,sp,108
    800201f2:	8111                	srli	a0,a0,0x4
    800201f4:	409f c395 efb9      	.insn	6, 0xefb9c395409f
    800201fa:	d55c                	sw	a5,44(a0)
    800201fc:	b6d0                	fsd	fa2,168(a3)
    800201fe:	ad79                	j	8002089c <_end_data1+0x69c>

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	99d470d3          	.insn	4, 0x99d470d3
    80030004:	7664                	ld	s1,232(a2)
    80030006:	a81d                	j	8003003c <d_2_1+0xc>
    80030008:	8125563f f799d4f5 	.insn	8, 0xf799d4f58125563f
    80030010:	d5a4                	sw	s1,104(a1)
    80030012:	90f9                	srli	s1,s1,0x3e
    80030014:	2515                	addiw	a0,a0,5
    80030016:	9a50                	.insn	2, 0x9a50
    80030018:	a0233bff c7dd3573 	.insn	16, 0x813ff2238e2441f7c7dd3573a0233bff
    80030020:	  

0000000080030020 <d_2_0>:
    80030020:	8e2441f7          	.insn	4, 0x8e2441f7
    80030024:	813ff223          	.insn	4, 0x813ff223
    80030028:	59a3778f          	.insn	4, 0x59a3778f
    8003002c:	fccac9ef          	jal	s3,7ffdc7f8 <_start-0x23808>

0000000080030030 <d_2_1>:
    80030030:	d545                	beqz	a0,8002ffd8 <_end_data1+0xfdd8>
    80030032:	b3e5                	j	8002fe1a <_end_data1+0xfc1a>
    80030034:	0fca3373          	csrrc	t1,0xfc,s4
    80030038:	a289                	j	8003017a <d_2_21+0xa>
    8003003a:	0014                	.insn	2, 0x0014
    8003003c:	3e0d                	addiw	t3,t3,-29
    8003003e:	8586                	mv	a1,ra

0000000080030040 <d_2_2>:
    80030040:	769d                	lui	a3,0xfffe7
    80030042:	35a0                	fld	fs0,104(a1)
    80030044:	383a                	fld	fa6,424(sp)
    80030046:	0854                	addi	a3,sp,20
    80030048:	fa60                	sd	s0,240(a2)
    8003004a:	83df 8d2f 6aa9      	.insn	6, 0x6aa98d2f83df

0000000080030050 <d_2_3>:
    80030050:	1dcc                	addi	a1,sp,756
    80030052:	155a                	slli	a0,a0,0x36
    80030054:	6589                	lui	a1,0x2
    80030056:	7d8637a3          	sd	s8,1999(a2) # ffffffffffff47cf <_end+0xffffffff7ff945cf>
    8003005a:	dd37304b          	.insn	4, 0xdd37304b
    8003005e:	8874                	.insn	2, 0x8874

0000000080030060 <d_2_4>:
    80030060:	fd4b3833          	.insn	4, 0xfd4b3833
    80030064:	a38c                	fsd	fa1,0(a5)
    80030066:	0db8                	addi	a4,sp,728
    80030068:	d1c2                	sw	a6,224(sp)
    8003006a:	f84db57f  	.insn	16, 0x196359728b880968228b928ef84db57f
    80030072:	  

0000000080030070 <d_2_5>:
    80030070:	0968228b          	.insn	4, 0x0968228b
    80030074:	8b88                	.insn	2, 0x8b88
    80030076:	5972                	lw	s2,60(sp)
    80030078:	72c01963          	bne	zero,a2,800307aa <_end_data2+0x5aa>
    8003007c:	1ad6                	slli	s5,s5,0x35
    8003007e:	          	.insn	4, 0xa34e2eb3

0000000080030080 <d_2_6>:
    80030080:	a34e                	fsd	fs3,384(sp)
    80030082:	f4d4                	sd	a3,168(s1)
    80030084:	8fbc                	.insn	2, 0x8fbc
    80030086:	b426                	fsd	fs1,40(sp)
    80030088:	60c8                	ld	a0,128(s1)
    8003008a:	aec8                	fsd	fa0,152(a3)
    8003008c:	7441                	lui	s0,0xffff0
    8003008e:	04ff    	.insn	10, 0x1b637b2d76e6924704ff
    80030096:	 

0000000080030090 <d_2_7>:
    80030090:	76e69247          	.insn	4, 0x76e69247
    80030094:	7b2d                	lui	s6,0xfffeb
    80030096:	3dfe1b63          	bne	t3,t6,8003046c <_end_data2+0x26c>
    8003009a:	149c                	addi	a5,sp,608
    8003009c:	3be5cd67          	.insn	4, 0x3be5cd67

00000000800300a0 <d_2_8>:
    800300a0:	31d9                	addiw	gp,gp,-10
    800300a2:	4d94                	lw	a3,24(a1)
    800300a4:	946c                	.insn	2, 0x946c
    800300a6:	a0ff 6195 cc15 e928 	.insn	14, 0x85da9e629baae928cc156195a0ff
    800300ae:	9baa   

00000000800300b0 <d_2_9>:
    800300b0:	9e62                	add	t3,t3,s8
    800300b2:	85da                	mv	a1,s6
    800300b4:	49f1                	li	s3,28
    800300b6:	09bd0def          	jal	s11,80100950 <_end+0xa0750>
    800300ba:	97d5                	srai	a5,a5,0x35
    800300bc:	4ffd5beb          	.insn	4, 0x4ffd5beb

00000000800300c0 <d_2_10>:
    800300c0:	2891d4ab          	.insn	4, 0x2891d4ab
    800300c4:	a59b05d7          	vsra.vv	v11,v25,v22,v0.t
    800300c8:	23bc                	fld	fa5,64(a5)
    800300ca:	5a73adef          	jal	s11,8006ae70 <_end+0xac70>
    800300ce:	68da                	ld	a7,400(sp)

00000000800300d0 <d_2_11>:
    800300d0:	a404                	fsd	fs1,8(s0)
    800300d2:	6aed                	lui	s5,0x1b
    800300d4:	c4a2                	sw	s0,72(sp)
    800300d6:	9f20                	.insn	2, 0x9f20
    800300d8:	6f65                	lui	t5,0x19
    800300da:	2036                	fld	ft0,328(sp)
    800300dc:	4bc5                	li	s7,17
    800300de:	47d1                	li	a5,20

00000000800300e0 <d_2_12>:
    800300e0:	a6c0                	fsd	fs0,136(a3)
    800300e2:	a712b103          	ld	sp,-1423(t0)
    800300e6:	e16c                	sd	a1,192(a0)
    800300e8:	d54eee07          	.insn	4, 0xd54eee07
    800300ec:	08c6                	slli	a7,a7,0x11
    800300ee:	96da                	add	a3,a3,s6

00000000800300f0 <d_2_13>:
    800300f0:	4a0e5c87          	vlsseg3e16.v	v25,(t3),zero
    800300f4:	7dd1                	lui	s11,0xffff4
    800300f6:	a49e                	fsd	ft7,72(sp)
    800300f8:	d9b6                	sw	a3,240(sp)
    800300fa:	6a11                	lui	s4,0x4
    800300fc:	3814                	fld	fa3,48(s0)
    800300fe:	0ae4                	addi	s1,sp,348

0000000080030100 <d_2_14>:
    80030100:	2855                	addiw	a6,a6,21 # ffffffffffff2015 <_end+0xffffffff7ff91e15>
    80030102:	c840                	sw	s0,20(s0)
    80030104:	af90                	fsd	fa2,24(a5)
    80030106:	f00a8e73          	.insn	4, 0xf00a8e73
    8003010a:	54e0                	lw	s0,108(s1)
    8003010c:	fec0                	sd	s0,184(a3)
    8003010e:	0146                	slli	sp,sp,0x11

0000000080030110 <d_2_15>:
    80030110:	ce81                	beqz	a3,80030128 <d_2_16+0x8>
    80030112:	d0d0                	sw	a2,36(s1)
    80030114:	368fa583          	lw	a1,872(t6)
    80030118:	b620                	fsd	fs0,104(a2)
    8003011a:	d494                	sw	a3,40(s1)
    8003011c:	9cc8                	.insn	2, 0x9cc8
    8003011e:	4222                	lw	tp,8(sp)

0000000080030120 <d_2_16>:
    80030120:	32b8                	fld	fa4,96(a3)
    80030122:	94d1                	srai	s1,s1,0x34
    80030124:	aca0                	fsd	fs0,88(s1)
    80030126:	1b92                	slli	s7,s7,0x24
    80030128:	d468                	sw	a0,108(s0)
    8003012a:	9285                	srli	a3,a3,0x21
    8003012c:	9f0ff7cf          	.insn	4, 0x9f0ff7cf

0000000080030130 <d_2_17>:
    80030130:	bbde                	fsd	fs7,496(sp)
    80030132:	67d86137          	lui	sp,0x67d86
    80030136:	b9dd                	j	8002fe2c <_end_data1+0xfc2c>
    80030138:	46ce                	lw	a3,208(sp)
    8003013a:	4cba                	lw	s9,140(sp)
    8003013c:	f6a2                	sd	s0,360(sp)
    8003013e:	          	.insn	4, 0xf6183a8b

0000000080030140 <d_2_18>:
    80030140:	f618                	sd	a4,40(a2)
    80030142:	7989                	lui	s3,0xfffe2
    80030144:	d8f0a487          	flw	fs1,-625(ra) # 3b4a7d8f <_start-0x44b58271>
    80030148:	2d92                	fld	fs11,256(sp)
    8003014a:	1264                	addi	s1,sp,300
    8003014c:	b962                	fsd	fs8,176(sp)
    8003014e:	b9b6                	fsd	fa3,240(sp)

0000000080030150 <d_2_19>:
    80030150:	ae40                	fsd	fs0,152(a2)
    80030152:	1e8e                	slli	t4,t4,0x23
    80030154:	96cc                	.insn	2, 0x96cc
    80030156:	b611                	j	8002fc5a <_end_data1+0xfa5a>
    80030158:	d04150c3          	fmadd.s	ft1,ft2,ft4,fs10,unknown
    8003015c:	b006                	fsd	ft1,32(sp)
    8003015e:	          	.insn	4, 0x5ac4f22b

0000000080030160 <d_2_20>:
    80030160:	5ac4                	lw	s1,52(a3)
    80030162:	252a                	fld	fa0,136(sp)
    80030164:	e005                	bnez	s0,80030184 <d_2_22+0x4>
    80030166:	a9c0                	fsd	fs0,144(a1)
    80030168:	6d09                	lui	s10,0x2
    8003016a:	d41f fcb8 410d      	.insn	6, 0x410dfcb8d41f

0000000080030170 <d_2_21>:
    80030170:	aafc                	fsd	fa5,208(a3)
    80030172:	e654                	sd	a3,136(a2)
    80030174:	feb2                	sd	a2,376(sp)
    80030176:	550d                	li	a0,-29
    80030178:	c4dd                	beqz	s1,80030226 <_end_data2+0x26>
    8003017a:	a0e0                	fsd	fs0,192(s1)
    8003017c:	aa720287          	vlsseg6e8.v	v5,(tp),t2

0000000080030180 <d_2_22>:
    80030180:	be95                	j	8002fcf4 <_end_data1+0xfaf4>
    80030182:	fd12                	sd	tp,184(sp)
    80030184:	1e5f 36d1 ee01      	.insn	6, 0xee0136d11e5f
    8003018a:	6640                	ld	s0,136(a2)
    8003018c:	677c                	ld	a5,200(a4)
    8003018e:	b3bd                	j	8002fefc <_end_data1+0xfcfc>

0000000080030190 <d_2_23>:
    80030190:	12f1                	addi	t0,t0,-4
    80030192:	2cb924cf          	.insn	4, 0x2cb924cf
    80030196:	ff34                	sd	a3,120(a4)
    80030198:	efcdbf73          	csrrc	t5,0xefc,s11
    8003019c:	d936                	sw	a3,176(sp)
    8003019e:	0e99                	addi	t4,t4,6

00000000800301a0 <d_2_24>:
    800301a0:	5524c4af          	.insn	4, 0x5524c4af
    800301a4:	f9a8aac3          	fmadd.s	fs5,fa7,fs10,ft11,rdn
    800301a8:	961a                	add	a2,a2,t1
    800301aa:	453e                	lw	a0,204(sp)
    800301ac:	a451                	j	80030430 <_end_data2+0x230>
    800301ae:	          	.insn	4, 0x577a5523

00000000800301b0 <d_2_25>:
    800301b0:	577a                	lw	a4,188(sp)
    800301b2:	b29f 81e9 0789      	.insn	6, 0x078981e9b29f
    800301b8:	50bc                	lw	a5,96(s1)
    800301ba:	9e773d4f          	.insn	4, 0x9e773d4f
    800301be:	e43d                	bnez	s0,8003022c <_end_data2+0x2c>

00000000800301c0 <d_2_26>:
    800301c0:	109f 6497 f092      	.insn	6, 0xf0926497109f
    800301c6:	d6f2                	sw	t3,108(sp)
    800301c8:	52b1                	li	t0,-20
    800301ca:	440e                	lw	s0,192(sp)
    800301cc:	9131507f  	.insn	20, 0xe64be97f81375090668ffba1df2fd9f09131507f
    800301d4:	  
    800301dc:	 

00000000800301d0 <d_2_27>:
    800301d0:	d9f0                	sw	a2,116(a1)
    800301d2:	fba1df2f          	.insn	4, 0xfba1df2f
    800301d6:	5090668f          	.insn	4, 0x5090668f
    800301da:	e97f8137          	lui	sp,0xe97f8
    800301de:	44d6e64b          	.insn	4, 0x44d6e64b
    800301e2:	ac2e                	fsd	fa1,24(sp)
    800301e4:	7769                	lui	a4,0xffffa
    800301e6:	35de                	fld	fa1,496(sp)
    800301e8:	d07b84eb          	.insn	4, 0xd07b84eb
    800301ec:	44d1                	li	s1,20
    800301ee:	05c6658f          	.insn	4, 0x05c6658f
    800301f2:	40da                	lw	ra,148(sp)
    800301f4:	5595874f          	.insn	4, 0x5595874f
    800301f8:	f407ceb7          	lui	t4,0xf407c
    800301fc:	b008                	fsd	fa0,32(s0)
    800301fe:	628a                	ld	t0,128(sp)

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	5a44                	lw	s1,52(a2)
    80040002:	f5de                	sd	s7,232(sp)
    80040004:	6039                	c.lui	zero,0xe
    80040006:	ff57ca57          	.insn	4, 0xff57ca57
    8004000a:	0ee4                	addi	s1,sp,860
    8004000c:	ad81546b          	.insn	4, 0xad81546b
    80040010:	6178                	ld	a4,192(a0)
    80040012:	5f74                	lw	a3,124(a4)
    80040014:	443d                	li	s0,15
    80040016:	ccdcf017          	auipc	zero,0xccdcf
    8004001a:	0970f37b          	.insn	4, 0x0970f37b
    8004001e:	          	fnmadd.s	fs4,fs11,fs4,ft2,rup

0000000080040020 <d_3_0>:
    80040020:	114d                	addi	sp,sp,-13 # ffffffffe97f7ff3 <_end+0xffffffff69797df3>
    80040022:	9461                	srai	s0,s0,0x38
    80040024:	4ad4                	lw	a3,20(a3)
    80040026:	0cfa5d8b          	.insn	4, 0x0cfa5d8b
    8004002a:	aea9                	j	80040384 <_end_data3+0x184>
    8004002c:	b65e                	fsd	fs7,296(sp)
    8004002e:	2454                	fld	fa3,136(s0)

0000000080040030 <d_3_1>:
    80040030:	5060                	lw	s0,100(s0)
    80040032:	31e8                	fld	fa0,224(a1)
    80040034:	25a8                	fld	fa0,72(a1)
    80040036:	fd31                	bnez	a0,8003ff92 <_end_data2+0xfd92>
    80040038:	d711                	beqz	a4,8003ff44 <_end_data2+0xfd44>
    8004003a:	4ab5796f          	jal	s2,80097ce4 <_end+0x37ae4>
    8004003e:	a1d4                	fsd	fa3,128(a1)

0000000080040040 <d_3_2>:
    80040040:	284ad7a3          	.insn	4, 0x284ad7a3
    80040044:	c42bc5ab          	.insn	4, 0xc42bc5ab
    80040048:	cae1                	beqz	a3,80040118 <d_3_15+0x8>
    8004004a:	c4b5                	beqz	s1,800400b6 <d_3_9+0x6>
    8004004c:	2fbd                	addiw	t6,t6,15
    8004004e:	          	.insn	4, 0xa42ce28f

0000000080040050 <d_3_3>:
    80040050:	a42c                	fsd	fa1,72(s0)
    80040052:	2f75                	addiw	t5,t5,29 # 1901d <_start-0x7ffe6fe3>
    80040054:	e19a                	sd	t1,192(sp)
    80040056:	4414                	lw	a3,8(s0)
    80040058:	7c9e                	ld	s9,480(sp)
    8004005a:	e42a                	sd	a0,8(sp)
    8004005c:	99d6                	add	s3,s3,s5
    8004005e:	00c9                	addi	ra,ra,18

0000000080040060 <d_3_4>:
    80040060:	a0765117          	auipc	sp,0xa0765
    80040064:	28b9                	addiw	a7,a7,14
    80040066:	fafd                	bnez	a3,8004005c <d_3_3+0xc>
    80040068:	d415                	beqz	s0,8003ff94 <_end_data2+0xfd94>
    8004006a:	69b2                	ld	s3,264(sp)
    8004006c:	f555                	bnez	a0,80040018 <_random_data3+0x18>
    8004006e:	2122                	fld	ft2,8(sp)

0000000080040070 <d_3_5>:
    80040070:	e9ff 1f5c 2676 0953 	.insn	22, 0xc3aab02e840844315d39f42880a9095326761f5ce9ff
    80040078:	80a9 f428 5d39 4431 
    80040080:	   

0000000080040080 <d_3_6>:
    80040080:	8408                	.insn	2, 0x8408
    80040082:	b02e                	fsd	fa1,32(sp)
    80040084:	c3aa                	sw	a0,196(sp)
    80040086:	4df4                	lw	a3,92(a1)
    80040088:	719a                	ld	gp,416(sp)
    8004008a:	3bc2                	fld	fs7,48(sp)
    8004008c:	64a0091b          	addiw	s2,zero,1610

0000000080040090 <d_3_7>:
    80040090:	b148                	fsd	fa0,160(a0)
    80040092:	0888                	addi	a0,sp,80
    80040094:	07ee                	slli	a5,a5,0x1b
    80040096:	8ac6                	mv	s5,a7
    80040098:	44b4                	lw	a3,72(s1)
    8004009a:	cadb8e6b          	.insn	4, 0xcadb8e6b
    8004009e:	d025                	beqz	s0,8003fffe <_end_data2+0xfdfe>

00000000800400a0 <d_3_8>:
    800400a0:	83fd                	srli	a5,a5,0x1f
    800400a2:	20a1                	addiw	ra,ra,8
    800400a4:	8b1f 3f95 f79d      	.insn	6, 0xf79d3f958b1f
    800400aa:	0328df57          	vfadd.vf	v30,v18,fa7
    800400ae:	          	.insn	4, 0x150d7a8b

00000000800400b0 <d_3_9>:
    800400b0:	150d                	addi	a0,a0,-29
    800400b2:	0785                	addi	a5,a5,1 # fffffffffffed001 <_end+0xffffffff7ff8ce01>
    800400b4:	634d                	lui	t1,0x13
    800400b6:	447c0927          	vsuxseg3ei8.v	v18,(s8),v7,v0.t
    800400ba:	9280                	.insn	2, 0x9280
    800400bc:	c4b2ffd3          	.insn	4, 0xc4b2ffd3

00000000800400c0 <d_3_10>:
    800400c0:	c029                	beqz	s0,80040102 <d_3_14+0x2>
    800400c2:	3d4bb5bf 398ba1ad 	.insn	8, 0x398ba1ad3d4bb5bf
    800400ca:	2381                	sext.w	t2,t2
    800400cc:	13cf34ff  	.insn	16, 0xe6214ebfd2ed2d25af11594713cf34ff
    800400d4:	  

00000000800400d0 <d_3_11>:
    800400d0:	af115947          	.insn	4, 0xaf115947
    800400d4:	2d25                	addiw	s10,s10,9 # 2009 <_start-0x7fffdff7>
    800400d6:	d2ed                	beqz	a3,800400b8 <d_3_9+0x8>
    800400d8:	e6214ebf 72848efc 	.insn	8, 0x72848efce6214ebf

00000000800400e0 <d_3_12>:
    800400e0:	1bd0                	addi	a2,sp,500
    800400e2:	3ce1                	addiw	s9,s9,-8
    800400e4:	83e8                	.insn	2, 0x83e8
    800400e6:	a452                	fsd	fs4,8(sp)
    800400e8:	1c9c                	addi	a5,sp,624
    800400ea:	a625                	j	80040412 <_end_data3+0x212>
    800400ec:	221f9be7          	.insn	4, 0x221f9be7

00000000800400f0 <d_3_13>:
    800400f0:	33b1                	addiw	t2,t2,-20
    800400f2:	ec656d8f          	.insn	4, 0xec656d8f
    800400f6:	98b6                	add	a7,a7,a3
    800400f8:	8b35                	andi	a4,a4,13
    800400fa:	94d2                	add	s1,s1,s4
    800400fc:	8374                	.insn	2, 0x8374
    800400fe:	8366                	mv	t1,s9

0000000080040100 <d_3_14>:
    80040100:	6cca                	ld	s9,144(sp)
    80040102:	68327447          	fmsub.s	fs0,ft4,ft3,fa3
    80040106:	6e71                	lui	t3,0x1c
    80040108:	0a0d                	addi	s4,s4,3 # 4003 <_start-0x7fffbffd>
    8004010a:	1a8e                	slli	s5,s5,0x23
    8004010c:	dbc0                	sw	s0,52(a5)
    8004010e:	4685                	li	a3,1

0000000080040110 <d_3_15>:
    80040110:	304d                	.insn	2, 0x304d
    80040112:	05fe                	slli	a1,a1,0x1f
    80040114:	3ce8                	fld	fa0,248(s1)
    80040116:	6359                	lui	t1,0x16
    80040118:	1fb9                	addi	t6,t6,-18
    8004011a:	1eea5ee3          	bge	s4,a4,80040b16 <_end_data3+0x916>
    8004011e:	0b80                	addi	s0,sp,464

0000000080040120 <d_3_16>:
    80040120:	20c0                	fld	fs0,128(s1)
    80040122:	1564                	addi	s1,sp,684
    80040124:	52c8                	lw	a0,36(a3)
    80040126:	6051                	c.lui	zero,0x14
    80040128:	d4e37e93          	andi	t4,t1,-690
    8004012c:	8500                	.insn	2, 0x8500
    8004012e:	56ac                	lw	a1,104(a3)

0000000080040130 <d_3_17>:
    80040130:	e72e                	sd	a1,392(sp)
    80040132:	68a4                	ld	s1,80(s1)
    80040134:	e99e                	sd	t2,208(sp)
    80040136:	1ae2                	slli	s5,s5,0x38
    80040138:	8d02                	jr	s10
    8004013a:	603859fb          	.insn	4, 0x603859fb
    8004013e:	          	.insn	4, 0x47d56af7

0000000080040140 <d_3_18>:
    80040140:	47d5                	li	a5,21
    80040142:	fd5a                	sd	s6,184(sp)
    80040144:	da8503ef          	jal	t2,7ff906ec <_start-0x6f914>
    80040148:	b155                	j	8003fdec <_end_data2+0xfbec>
    8004014a:	0de9                	addi	s11,s11,26 # ffffffffffff401a <_end+0xffffffff7ff93e1a>
    8004014c:	81a8                	.insn	2, 0x81a8
    8004014e:	          	fmadd.d	ft4,fs5,ft10,fa7,unknown

0000000080040150 <d_3_19>:
    80040150:	8bea                	mv	s7,s10
    80040152:	8194                	.insn	2, 0x8194
    80040154:	b735                	j	80040080 <d_3_6>
    80040156:	5300                	lw	s0,32(a4)
    80040158:	cb91                	beqz	a5,8004016c <d_3_20+0xc>
    8004015a:	13b8                	addi	a4,sp,488
    8004015c:	9fe1                	.insn	2, 0x9fe1
    8004015e:	ae8a                	fsd	ft2,344(sp)

0000000080040160 <d_3_20>:
    80040160:	b2a8                	fsd	fa0,96(a3)
    80040162:	e00bcbef          	jal	s7,7fffc762 <_start-0x389e>
    80040166:	5d20                	lw	s0,120(a0)
    80040168:	a8a6                	fsd	fs1,80(sp)
    8004016a:	6128                	ld	a0,64(a0)
    8004016c:	b501                	j	8003ff6c <_end_data2+0xfd6c>
    8004016e:	bc9c                	fsd	fa5,56(s1)

0000000080040170 <d_3_21>:
    80040170:	a6f606bf d379dfca 	.insn	8, 0xd379dfcaa6f606bf
    80040178:	7545                	lui	a0,0xffff1
    8004017a:	38e0                	fld	fs0,240(s1)
    8004017c:	3fc6d4b7          	lui	s1,0x3fc6d

0000000080040180 <d_3_22>:
    80040180:	f24bca9b          	.insn	4, 0xf24bca9b
    80040184:	3695                	addiw	a3,a3,-27 # fffffffffffe6fe5 <_end+0xffffffff7ff86de5>
    80040186:	75d5                	lui	a1,0xffff5
    80040188:	5f00                	lw	s0,56(a4)
    8004018a:	17cfa81b          	.insn	4, 0x17cfa81b
    8004018e:	0d4d                	addi	s10,s10,19

0000000080040190 <d_3_23>:
    80040190:	d74e                	sw	s3,172(sp)
    80040192:	767e                	ld	a2,504(sp)
    80040194:	d0dd                	beqz	s1,8004013a <d_3_17+0xa>
    80040196:	ae70                	fsd	fa2,216(a2)
    80040198:	97b8                	.insn	2, 0x97b8
    8004019a:	a854                	fsd	fa3,144(s0)
    8004019c:	ca2a0acf          	fnmadd.d	fs5,fs4,ft2,fs9,rne

00000000800401a0 <d_3_24>:
    800401a0:	369c                	fld	fa5,40(a3)
    800401a2:	8cbe                	mv	s9,a5
    800401a4:	9981                	andi	a1,a1,-32
    800401a6:	add2933b          	.insn	4, 0xadd2933b
    800401aa:	61b497a3          	sh	s11,1551(s1) # 3fc6d60f <_start-0x403929f1>
    800401ae:	          	.insn	4, 0xf7fcb2b3

00000000800401b0 <d_3_25>:
    800401b0:	f7fc                	sd	a5,232(a5)
    800401b2:	172a                	slli	a4,a4,0x2a
    800401b4:	2bd9                	addiw	s7,s7,22
    800401b6:	f774                	sd	a3,232(a4)
    800401b8:	b8b0                	fsd	fa2,112(s1)
    800401ba:	4539                	li	a0,14
    800401bc:	328a                	fld	ft5,160(sp)
    800401be:	eb1d                	bnez	a4,800401f4 <d_3_27+0x24>

00000000800401c0 <d_3_26>:
    800401c0:	87fa                	mv	a5,t5
    800401c2:	abb0                	fsd	fa2,80(a5)
    800401c4:	d44e                	sw	s3,40(sp)
    800401c6:	8aee890b          	.insn	4, 0x8aee890b
    800401ca:	60186753          	.insn	4, 0x60186753
    800401ce:	edc8                	sd	a0,152(a1)

00000000800401d0 <d_3_27>:
    800401d0:	bc1d57ef          	jal	a5,80015d90 <_end_data0+0x5b90>
    800401d4:	58dd                	li	a7,-9
    800401d6:	c5c4                	sw	s1,12(a1)
    800401d8:	5369                	li	t1,-6
    800401da:	1390                	addi	a2,sp,480
    800401dc:	3b78                	fld	fa4,240(a4)
    800401de:	da3a                	sw	a4,52(sp)
    800401e0:	381d                	addiw	a6,a6,-25
    800401e2:	3f6b831b          	addiw	t1,s7,1014
    800401e6:	982c                	.insn	2, 0x982c
    800401e8:	ea726d83          	lwu	s11,-345(tp) # fffffffffffffea7 <_end+0xffffffff7ff9fca7>
    800401ec:	b8df 8dc9 c7ac      	.insn	6, 0xc7ac8dc9b8df
    800401f2:	48a48307          	vlsseg3e8.v	v6,(s1),a0,v0.t
    800401f6:	0c21                	addi	s8,s8,8
    800401f8:	a2ba                	fsd	fa4,320(sp)
    800401fa:	719e                	ld	gp,480(sp)
    800401fc:	5634                	lw	a3,104(a2)
    800401fe:	5bb4                	lw	a3,112(a5)

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	1fc5                	addi	t6,t6,-15
    80050002:	753a                	ld	a0,424(sp)
    80050004:	1f82                	slli	t6,t6,0x20
    80050006:	5e3a                	lw	t3,172(sp)
    80050008:	0eff 53e1 ea2b 9f0d 	.insn	10, 0x23ae9f0dea2b53e10eff
    80050010:	23ae 
    80050012:	fd89                	bnez	a1,8004ff2c <_end_data3+0xfd2c>
    80050014:	a2522763          	.insn	4, 0xa2522763
    80050018:	71baa957          	.insn	4, 0x71baa957
    8005001c:	5452                	lw	s0,52(sp)
    8005001e:	1418                	addi	a4,sp,544

0000000080050020 <d_4_0>:
    80050020:	fc30                	sd	a2,120(s0)
    80050022:	0d3d                	addi	s10,s10,15
    80050024:	11663703          	ld	a4,278(a2)
    80050028:	6b00                	ld	s0,16(a4)
    8005002a:	b7a4                	fsd	fs1,104(a5)
    8005002c:	43ba                	lw	t2,140(sp)
    8005002e:	5904                	lw	s1,48(a0)

0000000080050030 <d_4_1>:
    80050030:	7e80                	ld	s0,56(a3)
    80050032:	31b1                	addiw	gp,gp,-20
    80050034:	b5696a57          	vmacc.vx	v20,s2,v22,v0.t
    80050038:	eb6c                	sd	a1,208(a4)
    8005003a:	2b99                	addiw	s7,s7,6
    8005003c:	b3a8                	fsd	fa0,96(a5)
    8005003e:	00c5                	addi	ra,ra,17

0000000080050040 <d_4_2>:
    80050040:	ab50                	fsd	fa2,144(a4)
    80050042:	2d55                	addiw	s10,s10,21
    80050044:	9cd0                	.insn	2, 0x9cd0
    80050046:	336e                	fld	ft6,248(sp)
    80050048:	5dec                	lw	a1,124(a1)
    8005004a:	5346                	lw	t1,112(sp)
    8005004c:	f22d                	bnez	a2,8004ffae <_end_data3+0xfdae>
    8005004e:	4f75                	li	t5,29

0000000080050050 <d_4_3>:
    80050050:	8c29                	xor	s0,s0,a0
    80050052:	bab9                	j	8004f9b0 <_end_data3+0xf7b0>
    80050054:	bb00                	fsd	fs0,48(a4)
    80050056:	5a84                	lw	s1,48(a3)
    80050058:	22ca                	fld	ft5,144(sp)
    8005005a:	de64                	sw	s1,124(a2)
    8005005c:	97b9                	srai	a5,a5,0x2e
    8005005e:	a300                	fsd	fs0,0(a4)

0000000080050060 <d_4_4>:
    80050060:	c587294b          	.insn	4, 0xc587294b
    80050064:	9935                	andi	a0,a0,-19
    80050066:	7f3d09af          	.insn	4, 0x7f3d09af
    8005006a:	9699                	srai	a3,a3,0x26
    8005006c:	e8d9                	bnez	s1,80050102 <d_4_14+0x2>
    8005006e:	ffe1                	bnez	a5,80050046 <d_4_2+0x6>

0000000080050070 <d_4_5>:
    80050070:	46fd                	li	a3,31
    80050072:	e732                	sd	a2,392(sp)
    80050074:	daf1                	beqz	a3,80050048 <d_4_2+0x8>
    80050076:	4d7d                	li	s10,31
    80050078:	665614c7          	.insn	4, 0x665614c7
    8005007c:	c009                	beqz	s0,8005007e <d_4_5+0xe>
    8005007e:	          	.insn	4, 0x116df567

0000000080050080 <d_4_6>:
    80050080:	116d                	addi	sp,sp,-5 # 207a505b <_start-0x5f85afa5>
    80050082:	47cc                	lw	a1,12(a5)
    80050084:	3f52748b          	.insn	4, 0x3f52748b
    80050088:	69d1                	lui	s3,0x14
    8005008a:	c7f2                	sw	t3,204(sp)
    8005008c:	4cb4                	lw	a3,88(s1)
    8005008e:	          	.insn	4, 0x264ac89b

0000000080050090 <d_4_7>:
    80050090:	264a                	fld	fa2,144(sp)
    80050092:	98ba                	add	a7,a7,a4
    80050094:	f69037bf 12bbff9e 	.insn	8, 0x12bbff9ef69037bf
    8005009c:	e15345fb          	.insn	4, 0xe15345fb

00000000800500a0 <d_4_8>:
    800500a0:	a3da                	fsd	fs6,448(sp)
    800500a2:	7965                	lui	s2,0xffff9
    800500a4:	1932ad0b          	.insn	4, 0x1932ad0b
    800500a8:	57451927          	.insn	4, 0x57451927
    800500ac:	2b6c                	fld	fa1,208(a4)
    800500ae:	2900                	fld	fs0,16(a0)

00000000800500b0 <d_4_9>:
    800500b0:	fd58e8bb          	.insn	4, 0xfd58e8bb
    800500b4:	ece8                	sd	a0,216(s1)
    800500b6:	6ac84683          	lbu	a3,1708(a6)
    800500ba:	67a2                	ld	a5,8(sp)
    800500bc:	3cac                	fld	fa1,120(s1)
    800500be:	c88c                	sw	a1