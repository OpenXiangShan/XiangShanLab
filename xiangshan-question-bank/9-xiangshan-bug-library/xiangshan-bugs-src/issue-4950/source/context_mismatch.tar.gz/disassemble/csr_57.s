
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <_end_trap>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <_end_trap>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	6521                	lui	a0,0x8
    800001be:	8005051b          	addiw	a0,a0,-2048 # 7800 <_start-0x7fff8800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_end_prefix>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_end_prefix>:
    80000200:	30005073          	csrwi	mstatus,0
    80000204:	70fcefb7          	lui	t6,0x70fce
    80000208:	bc9f8f9b          	addiw	t6,t6,-1079 # 70fcdbc9 <_start-0xf032437>
    8000020c:	0fbe                	slli	t6,t6,0xf
    8000020e:	981f8f93          	addi	t6,t6,-1663
    80000212:	0fba                	slli	t6,t6,0xe
    80000214:	28ef8f93          	addi	t6,t6,654
    80000218:	7b3fbf73          	csrrc	t5,dscratch1,t6
    8000021c:	8cfa                	mv	s9,t5

000000008000021e <_l1>:
    8000021e:	ffe00b97          	auipc	s7,0xffe00

0000000080000222 <_l2>:
    80000222:	a1741a53          	flt.s	s4,fs0,fs7

0000000080000226 <_l3>:
    80000226:	91eee793          	ori	a5,t4,-1762

000000008000022a <_l4>:
    8000022a:	00445e37          	lui	t3,0x445
    8000022e:	797e0e1b          	addiw	t3,t3,1943 # 445797 <_start-0x7fbba869>
    80000232:	0e3e                	slli	t3,t3,0xf
    80000234:	b5de0e13          	addi	t3,t3,-1187
    80000238:	0e32                	slli	t3,t3,0xc
    8000023a:	2f7e0e13          	addi	t3,t3,759
    8000023e:	0e36                	slli	t3,t3,0xd
    80000240:	8b5e0e13          	addi	t3,t3,-1867
    80000244:	741e1ef3          	csrrw	t4,mnepc,t3
    80000248:	88f6                	mv	a7,t4

000000008000024a <_l5>:
    8000024a:	00060a17          	auipc	s4,0x60
    8000024e:	e56a0a13          	addi	s4,s4,-426 # 800600a0 <d_5_8>
    80000252:	000a2e83          	lw	t4,0(s4)

0000000080000256 <_l6>:
    80000256:	0ff0000f          	fence

000000008000025a <_l7>:
    8000025a:	e00b8e53          	fmv.x.w	t3,fs7

000000008000025e <_l8>:
    8000025e:	c02b80d3          	fcvt.l.s	ra,fs7,rne

0000000080000262 <_l9>:
    80000262:	feb30eb7          	lui	t4,0xfeb30
    80000266:	3dbe8e9b          	addiw	t4,t4,987 # fffffffffeb303db <_end+0xffffffff7ead01db>
    8000026a:	0eb2                	slli	t4,t4,0xc
    8000026c:	b09e8e93          	addi	t4,t4,-1271
    80000270:	0eba                	slli	t4,t4,0xe
    80000272:	4f9e8e93          	addi	t4,t4,1273
    80000276:	0eb2                	slli	t4,t4,0xc
    80000278:	210e8e93          	addi	t4,t4,528
    8000027c:	7a4e9f73          	csrrw	t5,tinfo,t4
    80000280:	83fa                	mv	t2,t5
    80000282:	c07a                	sw	t5,0(sp)

0000000080000284 <_l10>:
    80000284:	0347eeb7          	lui	t4,0x347e
    80000288:	66fe8e9b          	addiw	t4,t4,1647 # 347e66f <_start-0x7cb81991>
    8000028c:	0eb2                	slli	t4,t4,0xc
    8000028e:	db9e8e93          	addi	t4,t4,-583
    80000292:	0eb2                	slli	t4,t4,0xc
    80000294:	b67e8e93          	addi	t4,t4,-1177
    80000298:	0eb6                	slli	t4,t4,0xd
    8000029a:	d8de8e93          	addi	t4,t4,-627
    8000029e:	7a4e9ef3          	csrrw	t4,tinfo,t4
    800002a2:	84f6                	mv	s1,t4

00000000800002a4 <_l11>:
    800002a4:	fed74fb7          	lui	t6,0xfed74
    800002a8:	86df8f9b          	addiw	t6,t6,-1939 # fffffffffed7386d <_end+0xffffffff7ed1366d>
    800002ac:	0fb2                	slli	t6,t6,0xc
    800002ae:	129f8f93          	addi	t6,t6,297
    800002b2:	0fb2                	slli	t6,t6,0xc
    800002b4:	c73f8f93          	addi	t6,t6,-909
    800002b8:	0fb2                	slli	t6,t6,0xc
    800002ba:	437f8f93          	addi	t6,t6,1079
    800002be:	7a0fa2f3          	csrrs	t0,tselect,t6
    800002c2:	8616                	mv	a2,t0

00000000800002c4 <_l12>:
    800002c4:	00000d17          	auipc	s10,0x0
    800002c8:	3c0d0d13          	addi	s10,s10,960 # 80000684 <_l100>
    800002cc:	041d1073          	csrw	uepc,s10
    800002d0:	00200073          	uret

00000000800002d4 <_l13>:
    800002d4:	ff8512b7          	lui	t0,0xff851
    800002d8:	8692829b          	addiw	t0,t0,-1943 # ffffffffff850869 <_end+0xffffffff7f7f0669>
    800002dc:	02b2                	slli	t0,t0,0xc
    800002de:	39f28293          	addi	t0,t0,927
    800002e2:	02b2                	slli	t0,t0,0xc
    800002e4:	cb928293          	addi	t0,t0,-839
    800002e8:	02ba                	slli	t0,t0,0xe
    800002ea:	0be28293          	addi	t0,t0,190
    800002ee:	6a8292f3          	csrrw	t0,hcontext,t0
    800002f2:	8796                	mv	a5,t0
    800002f4:	c016                	sw	t0,0(sp)

00000000800002f6 <_l14>:
    800002f6:	0ff0000f          	fence

00000000800002fa <_l15>:
    800002fa:	80290413          	addi	s0,s2,-2046

00000000800002fe <_l16>:
    800002fe:	217f9a53          	fsgnjn.s	fs4,ft11,fs7

0000000080000302 <_l17>:
    80000302:	150262f3          	csrrsi	t0,siselect,4
    80000306:	8616                	mv	a2,t0

0000000080000308 <_l18>:
    80000308:	c01c84d3          	fcvt.wu.s	s1,fs9,rne

000000008000030c <_l19>:
    8000030c:	00030597          	auipc	a1,0x30
    80000310:	d1458593          	addi	a1,a1,-748 # 80030020 <d_2_0>
    80000314:	05a1                	addi	a1,a1,8
    80000316:	80a5b12f          	amomin.d	sp,a0,(a1)

000000008000031a <_l20>:
    8000031a:	00030b97          	auipc	s7,0x30
    8000031e:	e86b8b93          	addi	s7,s7,-378 # 800301a0 <d_2_24>
    80000322:	ff4be083          	lwu	ra,-12(s7)

0000000080000326 <_l21>:
    80000326:	7b006e73          	csrrsi	t3,dcsr,0
    8000032a:	c072                	sw	t3,0(sp)

000000008000032c <_l22>:
    8000032c:	30005073          	csrwi	mstatus,0
    80000330:	1fb2ceb7          	lui	t4,0x1fb2c
    80000334:	94de8e9b          	addiw	t4,t4,-1715 # 1fb2b94d <_start-0x604d46b3>
    80000338:	0eb2                	slli	t4,t4,0xc
    8000033a:	88fe8e93          	addi	t4,t4,-1905
    8000033e:	0eda                	slli	t4,t4,0x16
    80000340:	747e8e93          	addi	t4,t4,1863
    80000344:	7a2eb373          	csrrc	t1,tdata2,t4
    80000348:	841a                	mv	s0,t1

000000008000034a <_l23>:
    8000034a:	7a0d6ef3          	csrrsi	t4,tselect,26
    8000034e:	c076                	sw	t4,0(sp)

0000000080000350 <_l24>:
    80000350:	00060c17          	auipc	s8,0x60
    80000354:	e80c0c13          	addi	s8,s8,-384 # 800601d0 <d_5_27>
    80000358:	1c61                	addi	s8,s8,-8
    8000035a:	a09c3aaf          	amomax.d	s5,s1,(s8)

000000008000035e <_l25>:
    8000035e:	d2aa9997          	auipc	s3,0xd2aa9

0000000080000362 <_l26>:
    80000362:	00060397          	auipc	t2,0x60
    80000366:	e2e38393          	addi	t2,t2,-466 # 80060190 <d_5_23>
    8000036a:	00a38023          	sb	a0,0(t2)

000000008000036e <_l27>:
    8000036e:	7fee7a13          	andi	s4,t3,2046

0000000080000372 <_l28>:
    80000372:	7a04f3f3          	csrrci	t2,tselect,9
    80000376:	8b1e                	mv	s6,t2

0000000080000378 <_l29>:
    80000378:	00020917          	auipc	s2,0x20
    8000037c:	cc890913          	addi	s2,s2,-824 # 80020040 <d_1_2>
    80000380:	1971                	addi	s2,s2,-4
    80000382:	c1392aaf          	amominu.w	s5,s3,(s2)

0000000080000386 <_l30>:
    80000386:	00866f37          	lui	t5,0x866
    8000038a:	e79f0f1b          	addiw	t5,t5,-391 # 865e79 <_start-0x7f79a187>
    8000038e:	0f32                	slli	t5,t5,0xc
    80000390:	e51f0f13          	addi	t5,t5,-431
    80000394:	0f32                	slli	t5,t5,0xc
    80000396:	b33f0f13          	addi	t5,t5,-1229
    8000039a:	0f32                	slli	t5,t5,0xc
    8000039c:	b19f0f13          	addi	t5,t5,-1255
    800003a0:	150f12f3          	csrrw	t0,siselect,t5
    800003a4:	8396                	mv	t2,t0

00000000800003a6 <_l31>:
    800003a6:	00dc22b7          	lui	t0,0xdc2
    800003aa:	d532829b          	addiw	t0,t0,-685 # dc1d53 <_start-0x7f23e2ad>
    800003ae:	02b2                	slli	t0,t0,0xc
    800003b0:	8cd28293          	addi	t0,t0,-1843
    800003b4:	02ba                	slli	t0,t0,0xe
    800003b6:	79528293          	addi	t0,t0,1941
    800003ba:	02b2                	slli	t0,t0,0xc
    800003bc:	24c28293          	addi	t0,t0,588
    800003c0:	7a32b373          	csrrc	t1,tdata3,t0
    800003c4:	00030013          	mv	zero,t1

00000000800003c8 <_l32>:
    800003c8:	00050e97          	auipc	t4,0x50
    800003cc:	dc8e8e93          	addi	t4,t4,-568 # 80050190 <d_4_23>
    800003d0:	8ef6                	mv	t4,t4
    800003d2:	ffe00b37          	lui	s6,0xffe00
    800003d6:	016eceb3          	xor	t4,t4,s6
    800003da:	100eb2af          	lr.d	t0,(t4)

00000000800003de <_l33>:
    800003de:	00060217          	auipc	tp,0x60
    800003e2:	c6220213          	addi	tp,tp,-926 # 80060040 <d_5_2>
    800003e6:	1211                	addi	tp,tp,-28 # ffffffffffffffe4 <_end+0xffffffff7ff9fde4>
    800003e8:	18b2262f          	sc.w	a2,a1,(tp)

00000000800003ec <_l34>:
    800003ec:	8040a493          	slti	s1,ra,-2044

00000000800003f0 <_l35>:
    800003f0:	fe1503b7          	lui	t2,0xfe150
    800003f4:	3a53839b          	addiw	t2,t2,933 # fffffffffe1503a5 <_end+0xffffffff7e0f01a5>
    800003f8:	03b6                	slli	t2,t2,0xd
    800003fa:	79538393          	addi	t2,t2,1941
    800003fe:	03b2                	slli	t2,t2,0xc
    80000400:	31f38393          	addi	t2,t2,799
    80000404:	03b6                	slli	t2,t2,0xd
    80000406:	19338393          	addi	t2,t2,403
    8000040a:	7a339ef3          	csrrw	t4,tdata3,t2

000000008000040e <_l36>:
    8000040e:	00030217          	auipc	tp,0x30
    80000412:	d9220213          	addi	tp,tp,-622 # 800301a0 <d_2_24>
    80000416:	0271                	addi	tp,tp,28 # 1c <_start-0x7fffffe4>
    80000418:	a1022d2f          	amomax.w	s10,a6,(tp)

000000008000041c <_l37>:
    8000041c:	30005073          	csrwi	mstatus,0
    80000420:	30405073          	csrwi	mie,0
    80000424:	257ad373          	csrrwi	t1,vsireg6,21
    80000428:	871a                	mv	a4,t1

000000008000042a <_l38>:
    8000042a:	197a85d3          	fdiv.s	fa1,fs5,fs7,rne

000000008000042e <_l39>:
    8000042e:	00020297          	auipc	t0,0x20
    80000432:	cd228293          	addi	t0,t0,-814 # 80020100 <d_1_14>
    80000436:	01b2b023          	sd	s11,0(t0)

000000008000043a <_l40>:
    8000043a:	32a2f113          	andi	sp,t0,810

000000008000043e <_l41>:
    8000043e:	009b8dbb          	addw	s11,s7,s1

0000000080000442 <_l42>:
    80000442:	12f18073          	sfence.vma	gp,a5

0000000080000446 <_l43>:
    80000446:	c0168353          	fcvt.wu.s	t1,fa3,rne

000000008000044a <_l44>:
    8000044a:	a02d2b53          	feq.s	s6,fs10,ft2

000000008000044e <_l45>:
    8000044e:	d0f08343          	fmadd.s	ft6,ft1,fa5,fs10,rne

0000000080000452 <_l46>:
    80000452:	00050c17          	auipc	s8,0x50
    80000456:	d5ec0c13          	addi	s8,s8,-674 # 800501b0 <d_4_25>
    8000045a:	ff8c2a23          	sw	s8,-12(s8)

000000008000045e <_l47>:
    8000045e:	20dca053          	fsgnjx.s	ft0,fs9,fa3

0000000080000462 <_l48>:
    80000462:	7b01e2f3          	csrrsi	t0,dcsr,3
    80000466:	8e16                	mv	t3,t0

0000000080000468 <_l49>:
    80000468:	7b3f62f3          	csrrsi	t0,dscratch1,30
    8000046c:	8e96                	mv	t4,t0

000000008000046e <_l50>:
    8000046e:	30005073          	csrwi	mstatus,0
    80000472:	30405073          	csrwi	mie,0
    80000476:	6289                	lui	t0,0x2
    80000478:	e832829b          	addiw	t0,t0,-381 # 1e83 <_start-0x7fffe17d>
    8000047c:	1286                	slli	t0,t0,0x21
    8000047e:	05d28293          	addi	t0,t0,93
    80000482:	02b6                	slli	t0,t0,0xd
    80000484:	1c628293          	addi	t0,t0,454
    80000488:	1802aef3          	csrrs	t4,satp,t0
    8000048c:	8c76                	mv	s8,t4
    8000048e:	c076                	sw	t4,0(sp)

0000000080000490 <_l51>:
    80000490:	722e6f73          	csrrsi	t5,minstretcfgh,28
    80000494:	83fa                	mv	t2,t5

0000000080000496 <_l52>:
    80000496:	029383b7          	lui	t2,0x2938
    8000049a:	4573839b          	addiw	t2,t2,1111 # 2938457 <_start-0x7d6c7ba9>
    8000049e:	03b2                	slli	t2,t2,0xc
    800004a0:	4cd38393          	addi	t2,t2,1229
    800004a4:	03b2                	slli	t2,t2,0xc
    800004a6:	f8538393          	addi	t2,t2,-123
    800004aa:	03b6                	slli	t2,t2,0xd
    800004ac:	6e838393          	addi	t2,t2,1768
    800004b0:	f1139e73          	csrrw	t3,mvendorid,t2
    800004b4:	80f2                	mv	ra,t3
    800004b6:	c072                	sw	t3,0(sp)

00000000800004b8 <_l53>:
    800004b8:	30005073          	csrwi	mstatus,0
    800004bc:	0195ff37          	lui	t5,0x195f
    800004c0:	4f1f0f1b          	addiw	t5,t5,1265 # 195f4f1 <_start-0x7e6a0b0f>
    800004c4:	0f32                	slli	t5,t5,0xc
    800004c6:	417f0f13          	addi	t5,t5,1047
    800004ca:	0f32                	slli	t5,t5,0xc
    800004cc:	ec9f0f13          	addi	t5,t5,-311
    800004d0:	0f3a                	slli	t5,t5,0xe
    800004d2:	ebef0f13          	addi	t5,t5,-322
    800004d6:	7aaf1ef3          	csrrw	t4,mscontext,t5
    800004da:	8876                	mv	a6,t4

00000000800004dc <_l54>:
    800004dc:	2b8cfb13          	andi	s6,s9,696

00000000800004e0 <_l55>:
    800004e0:	304d04cb          	fnmsub.s	fs1,fs10,ft4,ft6,rne

00000000800004e4 <_l56>:
    800004e4:	d0100d53          	fcvt.s.wu	fs10,zero,rne

00000000800004e8 <_l57>:
    800004e8:	00f59e37          	lui	t3,0xf59
    800004ec:	d95e0e1b          	addiw	t3,t3,-619 # f58d95 <_start-0x7f0a726b>
    800004f0:	0e3a                	slli	t3,t3,0xe
    800004f2:	f79e0e13          	addi	t3,t3,-135
    800004f6:	0e36                	slli	t3,t3,0xd
    800004f8:	9a9e0e13          	addi	t3,t3,-1623
    800004fc:	0e32                	slli	t3,t3,0xc
    800004fe:	ba9e0e13          	addi	t3,t3,-1111
    80000502:	3a0e1373          	csrrw	t1,pmpcfg0,t3
    80000506:	899a                	mv	s3,t1

0000000080000508 <_l58>:
    80000508:	00030f17          	auipc	t5,0x30
    8000050c:	c88f0f13          	addi	t5,t5,-888 # 80030190 <d_2_23>
    80000510:	8f7a                	mv	t5,t5
    80000512:	ffe00637          	lui	a2,0xffe00
    80000516:	00cf4f33          	xor	t5,t5,a2
    8000051a:	100f3caf          	lr.d	s9,(t5)

000000008000051e <_l59>:
    8000051e:	3028e3f3          	csrrsi	t2,medeleg,17
    80000522:	8c9e                	mv	s9,t2
    80000524:	c01e                	sw	t2,0(sp)

0000000080000526 <_l60>:
    80000526:	0090d093          	srli	ra,ra,0x9

000000008000052a <_l61>:
    8000052a:	d0100353          	fcvt.s.wu	ft6,zero,rne

000000008000052e <_l62>:
    8000052e:	a092a5d3          	feq.s	a1,ft5,fs1

0000000080000532 <_l63>:
    80000532:	028b4663          	blt	s6,s0,8000055e <_l70>

0000000080000536 <_l64>:
    80000536:	00040697          	auipc	a3,0x40
    8000053a:	c8a68693          	addi	a3,a3,-886 # 800401c0 <d_3_26>
    8000053e:	ffc6ed03          	lwu	s10,-4(a3)

0000000080000542 <_l65>:
    80000542:	598100cf          	fnmadd.s	ft1,ft2,fs8,fa1,rne

0000000080000546 <_l66>:
    80000546:	15061363          	bne	a2,a6,8000068c <_l102>

000000008000054a <_l67>:
    8000054a:	00000717          	auipc	a4,0x0
    8000054e:	ffc70713          	addi	a4,a4,-4 # 80000546 <_l66>
    80000552:	ff275283          	lhu	t0,-14(a4)

0000000080000556 <_l68>:
    80000556:	0150941b          	slliw	s0,ra,0x15

000000008000055a <_l69>:
    8000055a:	40fb05bb          	subw	a1,s6,a5

000000008000055e <_l70>:
    8000055e:	00010c17          	auipc	s8,0x10
    80000562:	bb2c0c13          	addi	s8,s8,-1102 # 80010110 <d_0_15>
    80000566:	ff8c2883          	lw	a7,-8(s8)

000000008000056a <_l71>:
    8000056a:	30005073          	csrwi	mstatus,0
    8000056e:	357f6f73          	csrrsi	t5,mireg6,30
    80000572:	84fa                	mv	s1,t5

0000000080000574 <_l72>:
    80000574:	30005073          	csrwi	mstatus,0
    80000578:	153b7f73          	csrrci	t5,sireg3,22
    8000057c:	897a                	mv	s2,t5
    8000057e:	c07a                	sw	t5,0(sp)

0000000080000580 <_l73>:
    80000580:	00060b17          	auipc	s6,0x60
    80000584:	b70b0b13          	addi	s6,s6,-1168 # 800600f0 <d_5_13>
    80000588:	1b21                	addi	s6,s6,-24
    8000058a:	100b38af          	lr.d	a7,(s6)

000000008000058e <_l74>:
    8000058e:	29289bd3          	fmax.s	fs7,fa7,fs2

0000000080000592 <_l75>:
    80000592:	7b3a73f3          	csrrci	t2,dscratch1,20
    80000596:	849e                	mv	s1,t2

0000000080000598 <_l76>:
    80000598:	3408de73          	csrrwi	t3,mscratch,17

000000008000059c <_l77>:
    8000059c:	30005073          	csrwi	mstatus,0
    800005a0:	340bf3f3          	csrrci	t2,mscratch,23
    800005a4:	881e                	mv	a6,t2

00000000800005a6 <_l78>:
    800005a6:	7a577ef3          	csrrci	t4,tcontrol,14

00000000800005aa <_l79>:
    800005aa:	07e0096f          	jal	s2,80000628 <_l90>

00000000800005ae <_l80>:
    800005ae:	00040d97          	auipc	s11,0x40
    800005b2:	ae2d8d93          	addi	s11,s11,-1310 # 80040090 <d_3_7>
    800005b6:	018dae87          	flw	ft9,24(s11)

00000000800005ba <_l81>:
    800005ba:	00000097          	auipc	ra,0x0
    800005be:	ca808093          	addi	ra,ra,-856 # 80000262 <_l9>
    800005c2:	fe40d303          	lhu	t1,-28(ra)

00000000800005c6 <_l82>:
    800005c6:	18bb0b53          	fdiv.s	fs6,fs6,fa1,rne

00000000800005ca <_l83>:
    800005ca:	06c90eb7          	lui	t4,0x6c90
    800005ce:	ab1e8e9b          	addiw	t4,t4,-1359 # 6c8fab1 <_start-0x7937054f>
    800005d2:	0eb2                	slli	t4,t4,0xc
    800005d4:	8fbe8e93          	addi	t4,t4,-1797
    800005d8:	0eb2                	slli	t4,t4,0xc
    800005da:	af3e8e93          	addi	t4,t4,-1293
    800005de:	0eb2                	slli	t4,t4,0xc
    800005e0:	acce8e93          	addi	t4,t4,-1332
    800005e4:	721eaef3          	csrrs	t4,mcyclecfgh,t4
    800005e8:	8b76                	mv	s6,t4

00000000800005ea <_l84>:
    800005ea:	00060817          	auipc	a6,0x60
    800005ee:	b7680813          	addi	a6,a6,-1162 # 80060160 <d_5_20>
    800005f2:	00d81e23          	sh	a3,28(a6)

00000000800005f6 <_l85>:
    800005f6:	00050297          	auipc	t0,0x50
    800005fa:	ada28293          	addi	t0,t0,-1318 # 800500d0 <d_4_11>
    800005fe:	12a1                	addi	t0,t0,-24
    80000600:	2152b22f          	amoxor.d	tp,s5,(t0)

0000000080000604 <_l86>:
    80000604:	00040a17          	auipc	s4,0x40
    80000608:	a7ca0a13          	addi	s4,s4,-1412 # 80040080 <d_3_6>
    8000060c:	0a61                	addi	s4,s4,24
    8000060e:	40da242f          	amoor.w	s0,a3,(s4)

0000000080000612 <_l87>:
    80000612:	286f90d3          	fmax.s	ft1,ft11,ft6

0000000080000616 <_l88>:
    80000616:	d8d50cc7          	fmsub.s	fs9,fa0,fa3,fs11,rne

000000008000061a <_l89>:
    8000061a:	00020097          	auipc	ra,0x20
    8000061e:	a1608093          	addi	ra,ra,-1514 # 80020030 <d_1_1>
    80000622:	10a1                	addi	ra,ra,-24
    80000624:	0070ad2f          	amoadd.w	s10,t2,(ra)

0000000080000628 <_l90>:
    80000628:	00050397          	auipc	t2,0x50
    8000062c:	b4838393          	addi	t2,t2,-1208 # 80050170 <d_4_21>
    80000630:	0133ae27          	fsw	fs3,28(t2)

0000000080000634 <_l91>:
    80000634:	30005073          	csrwi	mstatus,0
    80000638:	7a5c52f3          	csrrwi	t0,tcontrol,24
    8000063c:	8516                	mv	a0,t0

000000008000063e <_l92>:
    8000063e:	11710ed3          	fmul.s	ft9,ft2,fs7,rne

0000000080000642 <_l93>:
    80000642:	1044d2f3          	csrrwi	t0,sie,9
    80000646:	8e96                	mv	t4,t0

0000000080000648 <_l94>:
    80000648:	0430f663          	bgeu	ra,gp,80000694 <_l103>

000000008000064c <_l95>:
    8000064c:	00020397          	auipc	t2,0x20
    80000650:	b5438393          	addi	t2,t2,-1196 # 800201a0 <d_1_24>
    80000654:	03b1                	addi	t2,t2,12
    80000656:	61a3a92f          	amoand.w	s2,s10,(t2)

000000008000065a <_l96>:
    8000065a:	00000293          	li	t0,0
    8000065e:	7b0293f3          	csrrw	t2,dcsr,t0
    80000662:	851e                	mv	a0,t2
    80000664:	c01e                	sw	t2,0(sp)

0000000080000666 <_l97>:
    80000666:	00000c97          	auipc	s9,0x0
    8000066a:	034c8c93          	addi	s9,s9,52 # 8000069a <_l104>
    8000066e:	000c8e67          	jalr	t3,s9

0000000080000672 <_l98>:
    80000672:	f13462f3          	csrrsi	t0,mimpid,8
    80000676:	8316                	mv	t1,t0

0000000080000678 <_l99>:
    80000678:	30005073          	csrwi	mstatus,0
    8000067c:	7a1852f3          	csrrwi	t0,tdata1,16
    80000680:	8696                	mv	a3,t0
    80000682:	c016                	sw	t0,0(sp)

0000000080000684 <_l100>:
    80000684:	03ea7c63          	bgeu	s4,t5,800006bc <_l106>

0000000080000688 <_l101>:
    80000688:	c01082d3          	fcvt.wu.s	t0,ft1,rne

000000008000068c <_l102>:
    8000068c:	7a02eef3          	csrrsi	t4,tselect,5
    80000690:	88f6                	mv	a7,t4
    80000692:	c076                	sw	t4,0(sp)

0000000080000694 <_l103>:
    80000694:	f145ee73          	csrrsi	t3,mhartid,11
    80000698:	8af2                	mv	s5,t3

000000008000069a <_l104>:
    8000069a:	7a2ee3f3          	csrrsi	t2,tdata2,29

000000008000069e <_l105>:
    8000069e:	ff13b2b7          	lui	t0,0xff13b
    800006a2:	5912829b          	addiw	t0,t0,1425 # ffffffffff13b591 <_end+0xffffffff7f0db391>
    800006a6:	02b2                	slli	t0,t0,0xc
    800006a8:	6c328293          	addi	t0,t0,1731
    800006ac:	02b6                	slli	t0,t0,0xd
    800006ae:	11128293          	addi	t0,t0,273
    800006b2:	02b2                	slli	t0,t0,0xc
    800006b4:	aca28293          	addi	t0,t0,-1334
    800006b8:	7a1292f3          	csrrw	t0,tdata1,t0

00000000800006bc <_l106>:
    800006bc:	d0230053          	fcvt.s.l	ft0,t1,rne

00000000800006c0 <_good_exit>:
    800006c0:	00002097          	auipc	ra,0x2
    800006c4:	b4008093          	addi	ra,ra,-1216 # 80002200 <csr_output_data>
    800006c8:	10002173          	csrr	sp,sstatus
    800006cc:	0420bc23          	sd	sp,88(ra)
    800006d0:	10402173          	csrr	sp,sie
    800006d4:	0620b823          	sd	sp,112(ra)
    800006d8:	10502173          	csrr	sp,stvec
    800006dc:	0620bc23          	sd	sp,120(ra)
    800006e0:	10602173          	csrr	sp,scounteren
    800006e4:	0820b023          	sd	sp,128(ra)
    800006e8:	14002173          	csrr	sp,sscratch
    800006ec:	0820b423          	sd	sp,136(ra)
    800006f0:	14102173          	csrr	sp,sepc
    800006f4:	0820b823          	sd	sp,144(ra)
    800006f8:	14202173          	csrr	sp,scause
    800006fc:	0820bc23          	sd	sp,152(ra)
    80000700:	14302173          	csrr	sp,stval
    80000704:	0a20b023          	sd	sp,160(ra)
    80000708:	14402173          	csrr	sp,sip
    8000070c:	f7f17113          	andi	sp,sp,-129
    80000710:	0a20b423          	sd	sp,168(ra)
    80000714:	18002173          	csrr	sp,satp
    80000718:	0a20b823          	sd	sp,176(ra)
    8000071c:	f1402173          	csrr	sp,mhartid
    80000720:	0a20bc23          	sd	sp,184(ra)
    80000724:	30002173          	csrr	sp,mstatus
    80000728:	0c20b023          	sd	sp,192(ra)
    8000072c:	30202173          	csrr	sp,medeleg
    80000730:	0c20b423          	sd	sp,200(ra)
    80000734:	30302173          	csrr	sp,mideleg
    80000738:	0c20b823          	sd	sp,208(ra)
    8000073c:	30402173          	csrr	sp,mie
    80000740:	0c20bc23          	sd	sp,216(ra)
    80000744:	30502173          	csrr	sp,mtvec
    80000748:	0e20b023          	sd	sp,224(ra)
    8000074c:	30602173          	csrr	sp,mcounteren
    80000750:	0e20b423          	sd	sp,232(ra)
    80000754:	34002173          	csrr	sp,mscratch
    80000758:	0e20b823          	sd	sp,240(ra)
    8000075c:	34102173          	csrr	sp,mepc
    80000760:	0e20bc23          	sd	sp,248(ra)
    80000764:	34202173          	csrr	sp,mcause
    80000768:	1020b023          	sd	sp,256(ra)
    8000076c:	34302173          	csrr	sp,mtval
    80000770:	1020b423          	sd	sp,264(ra)
    80000774:	34402173          	csrr	sp,mip
    80000778:	f7f17113          	andi	sp,sp,-129
    8000077c:	1020b823          	sd	sp,272(ra)
    80000780:	3a002173          	csrr	sp,pmpcfg0
    80000784:	1020bc23          	sd	sp,280(ra)
    80000788:	3b002173          	csrr	sp,pmpaddr0
    8000078c:	1220bc23          	sd	sp,312(ra)
    80000790:	3b102173          	csrr	sp,pmpaddr1
    80000794:	1420b023          	sd	sp,320(ra)
    80000798:	3b202173          	csrr	sp,pmpaddr2
    8000079c:	1420b423          	sd	sp,328(ra)
    800007a0:	3b302173          	csrr	sp,pmpaddr3
    800007a4:	1420b823          	sd	sp,336(ra)
    800007a8:	3b402173          	csrr	sp,pmpaddr4
    800007ac:	1420bc23          	sd	sp,344(ra)
    800007b0:	3b502173          	csrr	sp,pmpaddr5
    800007b4:	1620b023          	sd	sp,352(ra)
    800007b8:	3b602173          	csrr	sp,pmpaddr6
    800007bc:	1620b423          	sd	sp,360(ra)
    800007c0:	3b702173          	csrr	sp,pmpaddr7
    800007c4:	1620b823          	sd	sp,368(ra)
    800007c8:	6519                	lui	a0,0x6
    800007ca:	30052073          	csrs	mstatus,a0

00000000800007ce <fcsrs_dump>:
    800007ce:	00102173          	frflags	sp
    800007d2:	0420b023          	sd	sp,64(ra)
    800007d6:	00202173          	frrm	sp
    800007da:	0420b423          	sd	sp,72(ra)
    800007de:	00302173          	frcsr	sp
    800007e2:	0420b823          	sd	sp,80(ra)

00000000800007e6 <reg_dump>:
    800007e6:	00002097          	auipc	ra,0x2
    800007ea:	81a08093          	addi	ra,ra,-2022 # 80002000 <begin_signature>
    800007ee:	0000b023          	sd	zero,0(ra)
    800007f2:	0020b823          	sd	sp,16(ra)
    800007f6:	0030bc23          	sd	gp,24(ra)
    800007fa:	0240b023          	sd	tp,32(ra)
    800007fe:	0250b423          	sd	t0,40(ra)
    80000802:	0260b823          	sd	t1,48(ra)
    80000806:	0270bc23          	sd	t2,56(ra)
    8000080a:	0480b023          	sd	s0,64(ra)
    8000080e:	0490b423          	sd	s1,72(ra)
    80000812:	04a0b823          	sd	a0,80(ra)
    80000816:	04b0bc23          	sd	a1,88(ra)
    8000081a:	06c0b023          	sd	a2,96(ra)
    8000081e:	06d0b423          	sd	a3,104(ra)
    80000822:	06e0b823          	sd	a4,112(ra)
    80000826:	06f0bc23          	sd	a5,120(ra)
    8000082a:	0900b023          	sd	a6,128(ra)
    8000082e:	0910b423          	sd	a7,136(ra)
    80000832:	0920b823          	sd	s2,144(ra)
    80000836:	0930bc23          	sd	s3,152(ra)
    8000083a:	0b40b023          	sd	s4,160(ra)
    8000083e:	0b50b423          	sd	s5,168(ra)
    80000842:	0b60b823          	sd	s6,176(ra)
    80000846:	0b70bc23          	sd	s7,184(ra)
    8000084a:	0d80b023          	sd	s8,192(ra)
    8000084e:	0d90b423          	sd	s9,200(ra)
    80000852:	0db0bc23          	sd	s11,216(ra)
    80000856:	0fc0b023          	sd	t3,224(ra)
    8000085a:	0fd0b423          	sd	t4,232(ra)
    8000085e:	0fe0b823          	sd	t5,240(ra)

0000000080000862 <freg_dump>:
    80000862:	00002097          	auipc	ra,0x2
    80000866:	89e08093          	addi	ra,ra,-1890 # 80002100 <freg_output_data>
    8000086a:	0010a427          	fsw	ft1,8(ra)
    8000086e:	0020a827          	fsw	ft2,16(ra)
    80000872:	0270ac27          	fsw	ft7,56(ra)
    80000876:	0490a427          	fsw	fs1,72(ra)
    8000087a:	04a0a827          	fsw	fa0,80(ra)
    8000087e:	06c0a027          	fsw	fa2,96(ra)
    80000882:	06d0a427          	fsw	fa3,104(ra)
    80000886:	0b50a427          	fsw	fs5,168(ra)
    8000088a:	0b60a827          	fsw	fs6,176(ra)
    8000088e:	0d90a427          	fsw	fs9,200(ra)
    80000892:	0da0a827          	fsw	fs10,208(ra)
    80000896:	0fc0a027          	fsw	ft8,224(ra)
    8000089a:	0fd0a427          	fsw	ft9,232(ra)
    8000089e:	0fe0a827          	fsw	ft10,240(ra)
    800008a2:	0ff0ac27          	fsw	ft11,248(ra)
    800008a6:	00002097          	auipc	ra,0x2
    800008aa:	85a08093          	addi	ra,ra,-1958 # 80002100 <freg_output_data>
    800008ae:	0000b027          	fsd	ft0,0(ra)
    800008b2:	0030bc27          	fsd	ft3,24(ra)
    800008b6:	0240b027          	fsd	ft4,32(ra)
    800008ba:	0250b427          	fsd	ft5,40(ra)
    800008be:	0260b827          	fsd	ft6,48(ra)
    800008c2:	0480b027          	fsd	fs0,64(ra)
    800008c6:	04b0bc27          	fsd	fa1,88(ra)
    800008ca:	06e0b827          	fsd	fa4,112(ra)
    800008ce:	06f0bc27          	fsd	fa5,120(ra)
    800008d2:	0900b027          	fsd	fa6,128(ra)
    800008d6:	0910b427          	fsd	fa7,136(ra)
    800008da:	0920b827          	fsd	fs2,144(ra)
    800008de:	0930bc27          	fsd	fs3,152(ra)
    800008e2:	0b40b027          	fsd	fs4,160(ra)
    800008e6:	0b70bc27          	fsd	fs7,184(ra)
    800008ea:	0d80b027          	fsd	fs8,192(ra)
    800008ee:	0db0bc27          	fsd	fs11,216(ra)
    800008f2:	4501                	li	a0,0
    800008f4:	0005006b          	.insn	4, 0x0005006b
    800008f8:	4185                	li	gp,1
    800008fa:	00000f17          	auipc	t5,0x0
    800008fe:	703f2323          	sw	gp,1798(t5) # 80001000 <tohost>
    80000902:	a001                	j	80000902 <freg_dump+0xa0>

0000000080000904 <_end_main>:
	...
    80000914:	00000013          	nop
    80000918:	00000013          	nop
    8000091c:	00000013          	nop
    80000920:	00000013          	nop
    80000924:	00000013          	nop
    80000928:	00000013          	nop
    8000092c:	00000013          	nop
    80000930:	00000013          	nop
    80000934:	00000013          	nop
    80000938:	00000013          	nop
    8000093c:	00000013          	nop
    80000940:	00000013          	nop
    80000944:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	39c665cb          	fnmsub.s	fa1,fa2,ft8,ft7,unknown
    80010004:	f290                	sd	a2,32(a3)
    80010006:	15de9c13          	.insn	4, 0x15de9c13
    8001000a:	ab1a                	fsd	ft6,400(sp)
    8001000c:	f828                	sd	a0,112(s0)
    8001000e:	4a19                	li	s4,6
    80010010:	c258                	sw	a4,4(a2)
    80010012:	35cd                	addiw	a1,a1,-13
    80010014:	56f4                	lw	a3,108(a3)
    80010016:	ca8329c7          	fmsub.d	fs3,ft6,fs0,fs9,rdn
    8001001a:	b0ea                	fsd	fs10,96(sp)
    8001001c:	29bd2ec7          	fmsub.s	ft9,fs10,fs11,ft5,rdn

0000000080010020 <d_0_0>:
    80010020:	05ba                	slli	a1,a1,0xe
    80010022:	ea9d                	bnez	a3,80010058 <d_0_3+0x8>
    80010024:	a7b9                	j	80010772 <_end_data0+0x572>
    80010026:	e86d                	bnez	s0,80010118 <d_0_15+0x8>
    80010028:	e6ed                	bnez	a3,80010112 <d_0_15+0x2>
    8001002a:	4a1d                	li	s4,7
    8001002c:	86c9                	srai	a3,a3,0x12
    8001002e:	656a                	ld	a0,152(sp)

0000000080010030 <d_0_1>:
    80010030:	0eb5b043          	.insn	4, 0x0eb5b043
    80010034:	0c26                	slli	s8,s8,0x9
    80010036:	755e                	ld	a0,496(sp)
    80010038:	638c                	ld	a1,0(a5)
    8001003a:	d831                	beqz	s0,8000ff8e <end_signature+0xdbae>
    8001003c:	a036                	fsd	fa3,0(sp)
    8001003e:	a7c8                	fsd	fa0,136(a5)

0000000080010040 <d_0_2>:
    80010040:	83ce                	mv	t2,s3
    80010042:	68aa                	ld	a7,136(sp)
    80010044:	d8cb1057          	vfwsub.wv	v0,v12,v22,v0.t
    80010048:	fdeadebf a71fb0e8 	.insn	8, 0xa71fb0e8fdeadebf

0000000080010050 <d_0_3>:
    80010050:	097c                	addi	a5,sp,156
    80010052:	003a                	c.slli	zero,0xe
    80010054:	4d9a                	lw	s11,132(sp)
    80010056:	5d339913          	.insn	4, 0x5d339913
    8001005a:	d852                	sw	s4,48(sp)
    8001005c:	2054                	fld	fa3,128(s0)
    8001005e:	          	.insn	4, 0xbd68af9b

0000000080010060 <d_0_4>:
    80010060:	bd68                	fsd	fa0,248(a0)
    80010062:	84ce                	mv	s1,s3
    80010064:	0d7d                	addi	s10,s10,31
    80010066:	53ad                	li	t2,-21
    80010068:	4a00                	lw	s0,16(a2)
    8001006a:	7671                	lui	a2,0xffffc
    8001006c:	b597cdaf          	.insn	4, 0xb597cdaf

0000000080010070 <d_0_5>:
    80010070:	52be                	lw	t0,236(sp)
    80010072:	ba74f5e7          	.insn	4, 0xba74f5e7
    80010076:	eee0                	sd	s0,216(a3)
    80010078:	0bae                	slli	s7,s7,0xb
    8001007a:	0a61                	addi	s4,s4,24
    8001007c:	853e                	mv	a0,a5
    8001007e:	5c92                	lw	s9,36(sp)

0000000080010080 <d_0_6>:
    80010080:	aa44                	fsd	fs1,144(a2)
    80010082:	5d2b9dcf          	.insn	4, 0x5d2b9dcf
    80010086:	9b20183b          	.insn	4, 0x9b20183b
    8001008a:	16b1                	addi	a3,a3,-20
    8001008c:	8390                	.insn	2, 0x8390
    8001008e:	5ea5                	li	t4,-23

0000000080010090 <d_0_7>:
    80010090:	ed84                	sd	s1,24(a1)
    80010092:	230e                	fld	ft6,192(sp)
    80010094:	39c4                	fld	fs1,176(a1)
    80010096:	4c3f6723          	.insn	4, 0x4c3f6723
    8001009a:	6c24                	ld	s1,88(s0)
    8001009c:	be4d                	j	8000fc4e <end_signature+0xd86e>
    8001009e:	934d                	srli	a4,a4,0x33

00000000800100a0 <d_0_8>:
    800100a0:	7c5c                	ld	a5,184(s0)
    800100a2:	3e35                	addiw	t3,t3,-19
    800100a4:	0df5                	addi	s11,s11,29
    800100a6:	2932                	fld	fs2,264(sp)
    800100a8:	c59c                	sw	a5,8(a1)
    800100aa:	67d815b3          	.insn	4, 0x67d815b3
    800100ae:	          	.insn	4, 0x93a5a36b

00000000800100b0 <d_0_9>:
    800100b0:	93a5                	srli	a5,a5,0x29
    800100b2:	24f2                	fld	fs1,280(sp)
    800100b4:	0e166603          	lwu	a2,225(a2) # ffffffffffffc0e1 <_end+0xffffffff7ff9bee1>
    800100b8:	33b0bfe3          	.insn	4, 0x33b0bfe3
    800100bc:	5bc0                	lw	s0,52(a5)
    800100be:	ceb9                	beqz	a3,8001011c <d_0_15+0xc>

00000000800100c0 <d_0_10>:
    800100c0:	27da                	fld	fa5,400(sp)
    800100c2:	b851e1eb          	.insn	4, 0xb851e1eb
    800100c6:	a266e4cf          	fnmadd.d	fs1,fa3,ft6,fs4,unknown
    800100ca:	dc9e                	sw	t2,120(sp)
    800100cc:	9649                	srai	a2,a2,0x32
    800100ce:	4e22                	lw	t3,8(sp)

00000000800100d0 <d_0_11>:
    800100d0:	8d98                	.insn	2, 0x8d98
    800100d2:	0508                	addi	a0,sp,640
    800100d4:	89df 14ef cfad      	.insn	6, 0xcfad14ef89df
    800100da:	5830                	lw	a2,112(s0)
    800100dc:	7360                	ld	s0,224(a4)
    800100de:	53e5                	li	t2,-7

00000000800100e0 <d_0_12>:
    800100e0:	916e                	add	sp,sp,s11
    800100e2:	b721                	j	8000ffea <end_signature+0xdc0a>
    800100e4:	0b64                	addi	s1,sp,412
    800100e6:	ece0                	sd	s0,216(s1)
    800100e8:	2778                	fld	fa4,200(a4)
    800100ea:	fa92                	sd	tp,368(sp)
    800100ec:	18be                	slli	a7,a7,0x2f
    800100ee:	d536                	sw	a3,168(sp)

00000000800100f0 <d_0_13>:
    800100f0:	9d28                	.insn	2, 0x9d28
    800100f2:	5656                	lw	a2,116(sp)
    800100f4:	8a9824e3          	.insn	4, 0x8a9824e3
    800100f8:	a9f5                	j	800105f4 <_end_data0+0x3f4>
    800100fa:	c205                	beqz	a2,8001011a <d_0_15+0xa>
    800100fc:	b89c                	fsd	fa5,48(s1)
    800100fe:	6e80                	ld	s0,24(a3)

0000000080010100 <d_0_14>:
    80010100:	1a0a                	slli	s4,s4,0x22
    80010102:	c26e                	sw	s11,4(sp)
    80010104:	629e                	ld	t0,448(sp)
    80010106:	b7459c3f b9fd8ae5 	.insn	8, 0xb9fd8ae5b7459c3f
    8001010e:	36ee                	fld	fa3,248(sp)

0000000080010110 <d_0_15>:
    80010110:	3a28                	fld	fa0,112(a2)
    80010112:	fe54                	sd	a3,184(a2)
    80010114:	8a20                	.insn	2, 0x8a20
    80010116:	11af6513          	ori	a0,t5,282
    8001011a:	d5c6                	sw	a7,232(sp)
    8001011c:	f8755c63          	bge	a0,t2,8000f8b4 <end_signature+0xd4d4>

0000000080010120 <d_0_16>:
    80010120:	625d                	lui	tp,0x17
    80010122:	eead                	bnez	a3,8001019c <d_0_23+0xc>
    80010124:	3824                	fld	fs1,112(s0)
    80010126:	dfac                	sw	a1,120(a5)
    80010128:	2d6d                	addiw	s10,s10,27
    8001012a:	bca94a73          	.insn	4, 0xbca94a73
    8001012e:	9158                	.insn	2, 0x9158

0000000080010130 <d_0_17>:
    80010130:	af4c                	fsd	fa1,152(a4)
    80010132:	923c                	.insn	2, 0x923c
    80010134:	d7dd                	beqz	a5,800100e2 <d_0_12+0x2>
    80010136:	1a22                	slli	s4,s4,0x28
    80010138:	9e86                	add	t4,t4,ra
    8001013a:	8c49                	or	s0,s0,a0
    8001013c:	4df281db          	.insn	4, 0x4df281db

0000000080010140 <d_0_18>:
    80010140:	b8da                	fsd	fs6,112(sp)
    80010142:	0a9d                	addi	s5,s5,7
    80010144:	c3322137          	lui	sp,0xc3322
    80010148:	1b653343          	fmadd.d	ft6,fa0,fs6,ft3,rup
    8001014c:	3354c387          	.insn	4, 0x3354c387

0000000080010150 <d_0_19>:
    80010150:	3209                	addiw	tp,tp,-30 # 16fe2 <_start-0x7ffe901e>
    80010152:	a235                	j	8001027e <_end_data0+0x7e>
    80010154:	3dd19063          	bne	gp,t4,80010514 <_end_data0+0x314>
    80010158:	9c48                	.insn	2, 0x9c48
    8001015a:	05478ea3          	sb	s4,93(a5)
    8001015e:	c1df        	.insn	6, 0x772fbd63c1df

0000000080010160 <d_0_20>:
    80010160:	772fbd63          	.insn	4, 0x772fbd63
    80010164:	b81b3673          	csrrc	a2,0xb81,s6
    80010168:	6c45                	lui	s8,0x11
    8001016a:	4606                	lw	a2,64(sp)
    8001016c:	b6ac                	fsd	fa1,104(a3)
    8001016e:	8d66                	mv	s10,s9

0000000080010170 <d_0_21>:
    80010170:	143a                	slli	s0,s0,0x2e
    80010172:	f261                	bnez	a2,80010132 <d_0_17+0x2>
    80010174:	efb51f97          	auipc	t6,0xefb51
    80010178:	a884                	fsd	fs1,16(s1)
    8001017a:	514d2867          	.insn	4, 0x514d2867
    8001017e:	32ec                	fld	fa1,224(a3)

0000000080010180 <d_0_22>:
    80010180:	f171                	bnez	a0,80010144 <d_0_18+0x4>
    80010182:	5f0b0227          	.insn	4, 0x5f0b0227
    80010186:	482d                	li	a6,11
    80010188:	5142                	lw	sp,48(sp)
    8001018a:	aabc                	fsd	fa5,80(a3)
    8001018c:	42e9                	li	t0,26
    8001018e:	3849                	addiw	a6,a6,-14

0000000080010190 <d_0_23>:
    80010190:	7029                	c.lui	zero,0xfffea
    80010192:	0c0e                	slli	s8,s8,0x3
    80010194:	a138                	fsd	fa4,64(a0)
    80010196:	c1636ba7          	.insn	4, 0xc1636ba7
    8001019a:	1d7d                	addi	s10,s10,-1
    8001019c:	fac0                	sd	s0,176(a3)
    8001019e:	e17f    	.insn	22, 0xa4668f675ae33060739db67e05df0317ffb1c195e17f
    800101a6:	    
    800101ae:	   

00000000800101a0 <d_0_24>:
    800101a0:	c195                	beqz	a1,800101c4 <d_0_26+0x4>
    800101a2:	ffb1                	bnez	a5,800100fe <d_0_13+0xe>
    800101a4:	05df0317          	auipc	t1,0x5df0
    800101a8:	b67e                	fsd	ft11,296(sp)
    800101aa:	739d                	lui	t2,0xfffe7
    800101ac:	3060                	fld	fs0,224(s0)
    800101ae:	          	bge	a4,s6,8000faa2 <end_signature+0xd6c2>

00000000800101b0 <d_0_25>:
    800101b0:	a4668f67          	jalr	t5,-1466(a3)
    800101b4:	125bca13          	xori	s4,s7,293
    800101b8:	54d6                	lw	s1,116(sp)
    800101ba:	2644                	fld	fs1,136(a2)
    800101bc:	e21b0683          	lb	a3,-479(s6)

00000000800101c0 <d_0_26>:
    800101c0:	24b9                	addiw	s1,s1,14
    800101c2:	fd6919cb          	.insn	4, 0xfd6919cb
    800101c6:	4424                	lw	s1,72(s0)
    800101c8:	d34c                	sw	a1,36(a4)
    800101ca:	0ddc                	addi	a5,sp,724
    800101cc:	cca6                	sw	s1,88(sp)
    800101ce:	4bc5                	li	s7,17

00000000800101d0 <d_0_27>:
    800101d0:	41da                	lw	gp,148(sp)
    800101d2:	0b49                	addi	s6,s6,18
    800101d4:	d8c1                	beqz	s1,80010164 <d_0_20+0x4>
    800101d6:	0455                	addi	s0,s0,21
    800101d8:	135a                	slli	t1,t1,0x36
    800101da:	aa50                	fsd	fa2,144(a2)
    800101dc:	1cd6                	slli	s9,s9,0x35
    800101de:	ea36                	sd	a3,272(sp)
    800101e0:	17457ea7          	.insn	4, 0x17457ea7
    800101e4:	8712                	mv	a4,tp
    800101e6:	80d6                	mv	ra,s5
    800101e8:	6c501b03          	lh	s6,1733(zero) # 6c5 <_start-0x7ffff93b>
    800101ec:	a94dc557          	vssrl.vx	v10,v20,s11,v0.t
    800101f0:	2a21                	addiw	s4,s4,8
    800101f2:	dbf66357          	vwsubu.wx	v6,v31,a2
    800101f6:	e5dc                	sd	a5,136(a1)
    800101f8:	4448                	lw	a0,12(s0)
    800101fa:	a7d2                	fsd	fs4,456(sp)
    800101fc:	efcd075f          	.word	0xefcd075f

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	dd22                	sw	s0,184(sp)
    80020002:	1af2                	slli	s5,s5,0x3c
    80020004:	e7ae344b          	.insn	4, 0xe7ae344b
    80020008:	f6e2                	sd	s8,360(sp)
    8002000a:	a8de6bfb          	.insn	4, 0xa8de6bfb
    8002000e:	8796                	mv	a5,t0
    80020010:	0596                	slli	a1,a1,0x5
    80020012:	85dc                	.insn	2, 0x85dc
    80020014:	5af0                	lw	a2,116(a3)
    80020016:	bb11                	j	8001fd2a <_end_data0+0xfb2a>
    80020018:	9a3c                	.insn	2, 0x9a3c
    8002001a:	1c99                	addi	s9,s9,-26
    8002001c:	6cf08fab          	.insn	4, 0x6cf08fab

0000000080020020 <d_1_0>:
    80020020:	3ce0                	fld	fs0,248(s1)
    80020022:	ef89                	bnez	a5,8002003c <d_1_1+0xc>
    80020024:	3df4                	fld	fa3,248(a1)
    80020026:	b408                	fsd	fa0,40(s0)
    80020028:	a2da                	fsd	fs6,320(sp)
    8002002a:	63e6                	ld	t2,88(sp)
    8002002c:	24d9                	addiw	s1,s1,22
    8002002e:	0cb0                	addi	a2,sp,600

0000000080020030 <d_1_1>:
    80020030:	0013b5d3          	fadd.s	fa1,ft7,ft1,rup
    80020034:	450e                	lw	a0,192(sp)
    80020036:	a3975713          	.insn	4, 0xa3975713
    8002003a:	73a91d4f          	fnmadd.d	fs10,fs2,fs10,fa4,rtz
    8002003e:	d998                	sw	a4,48(a1)

0000000080020040 <d_1_2>:
    80020040:	3ffa                	fld	ft11,440(sp)
    80020042:	a03ed587          	.insn	4, 0xa03ed587
    80020046:	c059                	beqz	s0,800200cc <d_1_10+0xc>
    80020048:	1d98                	addi	a4,sp,752
    8002004a:	1c2a298f          	.insn	4, 0x1c2a298f
    8002004e:	3c06                	fld	fs8,96(sp)

0000000080020050 <d_1_3>:
    80020050:	248d153b          	.insn	4, 0x248d153b
    80020054:	9ca1                	addw	s1,s1,s0
    80020056:	819a                	mv	gp,t1
    80020058:	d278                	sw	a4,100(a2)
    8002005a:	c0ff 7d3a ae80  	.insn	18, 0x168fd898eac8afd5668dc6eaae807d3ac0ff
    80020062:	    
    8002006a:	 

0000000080020060 <d_1_4>:
    80020060:	c6ea                	sw	s10,76(sp)
    80020062:	668d                	lui	a3,0x3
    80020064:	afd5                	j	80020858 <_end_data1+0x658>
    80020066:	eac8                	sd	a0,144(a3)
    80020068:	d898                	sw	a4,48(s1)
    8002006a:	4fc7168f          	.insn	4, 0x4fc7168f
    8002006e:	c5e0                	sw	s0,76(a1)

0000000080020070 <d_1_5>:
    80020070:	1ecd                	addi	t4,t4,-13
    80020072:	2639                	addiw	a2,a2,14
    80020074:	ffcaf263          	bgeu	s5,t3,8001f858 <_end_data0+0xf658>
    80020078:	d7d4                	sw	a3,44(a5)
    8002007a:	9d1d                	subw	a0,a0,a5
    8002007c:	e501ffb3          	.insn	4, 0xe501ffb3

0000000080020080 <d_1_6>:
    80020080:	e781                	bnez	a5,80020088 <d_1_6+0x8>
    80020082:	2e94                	fld	fa3,24(a3)
    80020084:	11d9                	addi	gp,gp,-10
    80020086:	1100d17f f879b4c6 	.insn	20, 0x425a9c15d3474d7ea3b1ab03f879b4c61100d17f
    8002008e:	  
    80020096:	 

0000000080020090 <d_1_7>:
    80020090:	a3b1                	j	800205dc <_end_data1+0x3dc>
    80020092:	4d7e                	lw	s10,220(sp)
    80020094:	9c15d347          	.insn	4, 0x9c15d347
    80020098:	425a                	lw	tp,148(sp)
    8002009a:	01da                	slli	gp,gp,0x16
    8002009c:	1884                	addi	s1,sp,112
    8002009e:	bb0a                	fsd	ft2,432(sp)

00000000800200a0 <d_1_8>:
    800200a0:	e800                	sd	s0,16(s0)
    800200a2:	e830                	sd	a2,80(s0)
    800200a4:	56a6                	lw	a3,104(sp)
    800200a6:	9d0aedd3          	.insn	4, 0x9d0aedd3
    800200aa:	2b31                	addiw	s6,s6,12
    800200ac:	5376bc4f          	fnmadd.d	fs8,fa3,fs7,fa0,rup

00000000800200b0 <d_1_9>:
    800200b0:	7d5e                	ld	s10,496(sp)
    800200b2:	d298                	sw	a4,32(a3)
    800200b4:	8971                	andi	a0,a0,28
    800200b6:	0fb8                	addi	a4,sp,984
    800200b8:	42d0                	lw	a2,4(a3)
    800200ba:	d21d                	beqz	a2,8001ffe0 <_end_data0+0xfde0>
    800200bc:	0cf2                	slli	s9,s9,0x1c
    800200be:	b491                	j	8001fb02 <_end_data0+0xf902>

00000000800200c0 <d_1_10>:
    800200c0:	cec31e93          	.insn	4, 0xcec31e93
    800200c4:	ffec                	sd	a1,248(a5)
    800200c6:	7876                	ld	a6,376(sp)
    800200c8:	21ac                	fld	fa1,64(a1)
    800200ca:	850c                	.insn	2, 0x850c
    800200cc:	a561                	j	80020754 <_end_data1+0x554>
    800200ce:	          	.insn	4, 0xb369c35b

00000000800200d0 <d_1_11>:
    800200d0:	b369                	j	8001fe5a <_end_data0+0xfc5a>
    800200d2:	2749                	addiw	a4,a4,18
    800200d4:	f4ea                	sd	s10,104(sp)
    800200d6:	ae0a                	fsd	ft2,280(sp)
    800200d8:	10095fbb          	.insn	4, 0x10095fbb
    800200dc:	25ff b10b   	.insn	14, 0x6d1a27813dd299a85692b10b25ff
    800200e4:	   

00000000800200e0 <d_1_12>:
    800200e0:	5692                	lw	a3,36(sp)
    800200e2:	99a8                	.insn	2, 0x99a8
    800200e4:	3dd2                	fld	fs11,304(sp)
    800200e6:	2781                	sext.w	a5,a5
    800200e8:	6d1a                	ld	s10,384(sp)
    800200ea:	fdc461a7          	.insn	4, 0xfdc461a7
    800200ee:	8616                	mv	a2,t0

00000000800200f0 <d_1_13>:
    800200f0:	ae70                	fsd	fa2,216(a2)
    800200f2:	9818                	.insn	2, 0x9818
    800200f4:	14d8                	addi	a4,sp,612
    800200f6:	d9049de7          	.insn	4, 0xd9049de7
    800200fa:	d1c2                	sw	a6,224(sp)
    800200fc:	6b3c59bf  	.insn	8, 0xb6edbade6b3c59bf

0000000080020100 <d_1_14>:
    80020100:	bade                	fsd	fs7,368(sp)
    80020102:	b6ed                	j	8001fcec <_end_data0+0xfaec>
    80020104:	ca92                	sw	tp,84(sp)
    80020106:	4f78                	lw	a4,92(a4)
    80020108:	c764                	sw	s1,76(a4)
    8002010a:	3cb2                	fld	fs9,296(sp)
    8002010c:	59e23693          	sltiu	a3,tp,1438

0000000080020110 <d_1_15>:
    80020110:	3f16                	fld	ft10,352(sp)
    80020112:	699dfaaf          	.insn	4, 0x699dfaaf
    80020116:	3aa4                	fld	fs1,112(a3)
    80020118:	f595                	bnez	a1,80020044 <d_1_2+0x4>
    8002011a:	30c4                	fld	fs1,160(s1)
    8002011c:	cee6                	sw	s9,92(sp)
    8002011e:	cec5                	beqz	a3,800201d6 <d_1_27+0x6>

0000000080020120 <d_1_16>:
    80020120:	bd84                	fsd	fs1,56(a1)
    80020122:	9f263c2b          	.insn	4, 0x9f263c2b
    80020126:	fddec683          	lbu	a3,-35(t4)
    8002012a:	ab833e17          	auipc	t3,0xab833
    8002012e:	eac8                	sd	a0,144(a3)

0000000080020130 <d_1_17>:
    80020130:	5cc4                	lw	s1,60(s1)
    80020132:	9f22                	add	t5,t5,s0
    80020134:	070e19f7          	.insn	4, 0x070e19f7
    80020138:	ee0d                	bnez	a2,80020172 <d_1_21+0x2>
    8002013a:	0b2015eb          	.insn	4, 0x0b2015eb
    8002013e:	3018                	fld	fa4,32(s0)

0000000080020140 <d_1_18>:
    80020140:	e3a5588b          	.insn	4, 0xe3a5588b
    80020144:	eff1                	bnez	a5,80020220 <_end_data1+0x20>
    80020146:	404fffe7          	.insn	4, 0x404fffe7
    8002014a:	91b8                	.insn	2, 0x91b8
    8002014c:	e425                	bnez	s0,800201b4 <d_1_25+0x4>
    8002014e:	8e02                	jr	t3

0000000080020150 <d_1_19>:
    80020150:	693f663b          	.insn	4, 0x693f663b
    80020154:	d752                	sw	s4,172(sp)
    80020156:	993e                	add	s2,s2,a5
    80020158:	c444cd87          	.insn	4, 0xc444cd87
    8002015c:	04d9                	addi	s1,s1,22
    8002015e:	3dae                	fld	fs11,232(sp)

0000000080020160 <d_1_20>:
    80020160:	4e656b97          	auipc	s7,0x4e656
    80020164:	9c55                	.insn	2, 0x9c55
    80020166:	6e1d                	lui	t3,0x7
    80020168:	69b0                	ld	a2,80(a1)
    8002016a:	7fd1                	lui	t6,0xffff4
    8002016c:	0774                	addi	a3,sp,908
    8002016e:	160e                	slli	a2,a2,0x23

0000000080020170 <d_1_21>:
    80020170:	7370                	ld	a2,224(a4)
    80020172:	4972                	lw	s2,28(sp)
    80020174:	7dc3888f          	.insn	4, 0x7dc3888f
    80020178:	f45d4593          	xori	a1,s10,-187
    8002017c:	3d20                	fld	fs0,120(a0)
    8002017e:	8caa                	mv	s9,a0

0000000080020180 <d_1_22>:
    80020180:	9d54                	.insn	2, 0x9d54
    80020182:	693e3ceb          	.insn	4, 0x693e3ceb
    80020186:	cea1                	beqz	a3,800201de <d_1_27+0xe>
    80020188:	a2a8                	fsd	fa0,64(a3)
    8002018a:	8216                	mv	tp,t0
    8002018c:	542d                	li	s0,-21
    8002018e:	e132                	sd	a2,128(sp)

0000000080020190 <d_1_23>:
    80020190:	092d                	addi	s2,s2,11
    80020192:	4835                	li	a6,13
    80020194:	929a3eeb          	.insn	4, 0x929a3eeb
    80020198:	087f aa43 cd13 e5b6 	.insn	10, 0x050ae5b6cd13aa43087f
    800201a0:	 

00000000800201a0 <d_1_24>:
    800201a0:	050a                	slli	a0,a0,0x2
    800201a2:	dbceaf4f          	fnmadd.d	ft10,ft9,ft8,fs11,rdn
    800201a6:	7f25                	lui	t5,0xfffe9
    800201a8:	e5ed7337          	lui	t1,0xe5ed7
    800201ac:	cb24                	sw	s1,80(a4)
    800201ae:	b6c8                	fsd	fa0,168(a3)

00000000800201b0 <d_1_25>:
    800201b0:	d6e8                	sw	a0,108(a3)
    800201b2:	becd                	j	8001fda4 <_end_data0+0xfba4>
    800201b4:	07f0                	addi	a2,sp,972
    800201b6:	9f5f496f          	jal	s2,80014baa <_end_data0+0x49aa>
    800201ba:	7896                	ld	a7,352(sp)
    800201bc:	b97a                	fsd	ft10,176(sp)
    800201be:	15fd                	addi	a1,a1,-1

00000000800201c0 <d_1_26>:
    800201c0:	f486                	sd	ra,104(sp)
    800201c2:	9820                	.insn	2, 0x9820
    800201c4:	63a23f2b          	.insn	4, 0x63a23f2b
    800201c8:	655e                	ld	a0,464(sp)
    800201ca:	0ff4                	addi	a3,sp,988
    800201cc:	94f2                	add	s1,s1,t3
    800201ce:	b314                	fsd	fa3,32(a4)

00000000800201d0 <d_1_27>:
    800201d0:	fb10                	sd	a2,48(a4)
    800201d2:	ae65                	j	8002058a <_end_data1+0x38a>
    800201d4:	113e                	slli	sp,sp,0x2f
    800201d6:	2ca389f7          	.insn	4, 0x2ca389f7
    800201da:	c379                	beqz	a4,800202a0 <_end_data1+0xa0>
    800201dc:	e614                	sd	a3,8(a2)
    800201de:	e81f 5e37 4482      	.insn	6, 0x44825e37e81f
    800201e4:	c284                	sw	s1,0(a3)
    800201e6:	5278                	lw	a4,100(a2)
    800201e8:	2c8e9d1b          	.insn	4, 0x2c8e9d1b
    800201ec:	6472                	ld	s0,280(sp)
    800201ee:	6ccd79b7          	lui	s3,0x6ccd7
    800201f2:	5c91ad1b          	.insn	4, 0x5c91ad1b
    800201f6:	e2a6                	sd	s1,320(sp)
    800201f8:	f9ef946b          	.insn	4, 0xf9ef946b
    800201fc:	fdde                	sd	s7,248(sp)
    800201fe:	7cc5                	lui	s9,0xffff1

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	bbba                	fsd	fa4,496(sp)
    80030002:	b5151473          	csrrw	s0,0xb51,a0
    80030006:	62da                	ld	t0,400(sp)
    80030008:	0db405b7          	lui	a1,0xdb40
    8003000c:	94185d53          	.insn	4, 0x94185d53
    80030010:	ae66                	fsd	fs9,280(sp)
    80030012:	9d3e                	add	s10,s10,a5
    80030014:	6594                	ld	a3,8(a1)
    80030016:	460010d3          	.insn	4, 0x460010d3
    8003001a:	71dc1e0b          	.insn	4, 0x71dc1e0b
    8003001e:	de58                	sw	a4,60(a2)

0000000080030020 <d_2_0>:
    80030020:	11221693          	.insn	4, 0x11221693
    80030024:	6218                	ld	a4,0(a2)
    80030026:	7d48                	ld	a0,184(a0)
    80030028:	48dd                	li	a7,23
    8003002a:	ed1b29c3          	.insn	4, 0xed1b29c3
    8003002e:	b49d                	j	8002fa94 <_end_data1+0xf894>

0000000080030030 <d_2_1>:
    80030030:	47f1                	li	a5,28
    80030032:	acb8                	fsd	fa4,88(s1)
    80030034:	f429                	bnez	s0,8002ff7e <_end_data1+0xfd7e>
    80030036:	ef85                	bnez	a5,8003006e <d_2_4+0xe>
    80030038:	c9c0                	sw	s0,20(a1)
    8003003a:	0df5                	addi	s11,s11,29
    8003003c:	95139107          	.insn	4, 0x95139107

0000000080030040 <d_2_2>:
    80030040:	0162                	slli	sp,sp,0x18
    80030042:	93ef4247          	fmsub.d	ft4,ft10,ft10,fs2,rmm
    80030046:	72c2                	ld	t0,48(sp)
    80030048:	6d78                	ld	a4,216(a0)
    8003004a:	11bf67bf  	.insn	8, 0x3c60d69211bf67bf

0000000080030050 <d_2_3>:
    80030050:	3c60                	fld	fs0,248(s0)
    80030052:	29d5                	addiw	s3,s3,21 # 6ccd7015 <_start-0x13328feb>
    80030054:	ce70                	sw	a2,92(a2)
    80030056:	cd3f15ef          	jal	a1,80021d28 <_end_data1+0x1b28>
    8003005a:	ad14                	fsd	fa3,24(a0)
    8003005c:	935d                	srli	a4,a4,0x37
    8003005e:	0518                	addi	a4,sp,640

0000000080030060 <d_2_4>:
    80030060:	7d30                	ld	a2,120(a0)
    80030062:	55cd95bf 752a4ff4 	.insn	8, 0x752a4ff455cd95bf
    8003006a:	7ffa                	ld	t6,440(sp)
    8003006c:	481d                	li	a6,7
    8003006e:	afb2                	fsd	fa2,472(sp)

0000000080030070 <d_2_5>:
    80030070:	5a2223c3          	fmadd.d	ft7,ft4,ft2,fa1,rdn
    80030074:	5c0a                	lw	s8,160(sp)
    80030076:	2666                	fld	fa2,88(sp)
    80030078:	1cae                	slli	s9,s9,0x2b
    8003007a:	d7d0                	sw	a2,44(a5)
    8003007c:	5dd5                	li	s11,-11
    8003007e:	17bc                	addi	a5,sp,1000

0000000080030080 <d_2_6>:
    80030080:	0918                	addi	a4,sp,144
    80030082:	b4b4fe4f          	.insn	4, 0xb4b4fe4f
    80030086:	72838283          	lb	t0,1832(t2) # fffffffffffe7728 <_end+0xffffffff7ff87528>
    8003008a:	c8f1                	beqz	s1,8003015e <d_2_19+0xe>
    8003008c:	3c4c                	fld	fa1,184(s0)
    8003008e:	b5c5                	j	8002ff6e <_end_data1+0xfd6e>

0000000080030090 <d_2_7>:
    80030090:	7574                	ld	a3,232(a0)
    80030092:	103e                	c.slli	zero,0x2f
    80030094:	25dff77b          	.insn	4, 0x25dff77b
    80030098:	1be2                	slli	s7,s7,0x38
    8003009a:	bdb02e77          	.insn	4, 0xbdb02e77
    8003009e:	c000                	sw	s0,0(s0)

00000000800300a0 <d_2_8>:
    800300a0:	454d                	li	a0,19
    800300a2:	8da0                	.insn	2, 0x8da0
    800300a4:	1766                	slli	a4,a4,0x39
    800300a6:	158a3007          	fld	ft0,344(s4)
    800300aa:	e369                	bnez	a4,8003016c <d_2_20+0xc>
    800300ac:	ba04                	fsd	fs1,48(a2)
    800300ae:	11e4                	addi	s1,sp,236

00000000800300b0 <d_2_9>:
    800300b0:	aa04                	fsd	fs1,16(a2)
    800300b2:	9fa9                	addw	a5,a5,a0
    800300b4:	f1276223          	.insn	4, 0xf1276223
    800300b8:	66ae                	ld	a3,200(sp)
    800300ba:	7b1d                	lui	s6,0xfffe7
    800300bc:	08b6a33b          	.insn	4, 0x08b6a33b

00000000800300c0 <d_2_10>:
    800300c0:	d3c2                	sw	a6,228(sp)
    800300c2:	95cc6a0f          	.insn	4, 0x95cc6a0f
    800300c6:	30d0                	fld	fa2,160(s1)
    800300c8:	64c1                	lui	s1,0x10
    800300ca:	6a65ed0f          	.insn	4, 0x6a65ed0f
    800300ce:	ea49                	bnez	a2,80030160 <d_2_20>

00000000800300d0 <d_2_11>:
    800300d0:	9327aac3          	fmadd.d	fs5,fa5,fs2,fs2,rdn
    800300d4:	8062                	c.mv	zero,s8
    800300d6:	2f26                	fld	ft10,72(sp)
    800300d8:	134c                	addi	a1,sp,420
    800300da:	8a8d                	andi	a3,a3,3
    800300dc:	3f15                	addiw	t5,t5,-27 # fffffffffffe8fe5 <_end+0xffffffff7ff88de5>
    800300de:	8cce                	mv	s9,s3

00000000800300e0 <d_2_12>:
    800300e0:	7623444f          	.insn	4, 0x7623444f
    800300e4:	11ba                	slli	gp,gp,0x2e
    800300e6:	db0912e7          	.insn	4, 0xdb0912e7
    800300ea:	2542654b          	.insn	4, 0x2542654b
    800300ee:	          	beqz	t1,800300c6 <d_2_10+0x6>

00000000800300f0 <d_2_13>:
    800300f0:	02e0fc03          	.insn	4, 0x02e0fc03
    800300f4:	cf99                	beqz	a5,80030112 <d_2_15+0x2>
    800300f6:	4a04                	lw	s1,16(a2)
    800300f8:	8548                	.insn	2, 0x8548
    800300fa:	3fb1                	addiw	t6,t6,-20 # ffffffffffff3fec <_end+0xffffffff7ff93dec>
    800300fc:	0019                	c.nop	6
    800300fe:	63c0                	ld	s0,128(a5)

0000000080030100 <d_2_14>:
    80030100:	f75d                	bnez	a4,800300ae <d_2_8+0xe>
    80030102:	13d1                	addi	t2,t2,-12
    80030104:	a7e8                	fsd	fa0,200(a5)
    80030106:	ae12                	fsd	ft4,280(sp)
    80030108:	200e                	fld	ft0,192(sp)
    8003010a:	cfb8                	sw	a4,88(a5)
    8003010c:	1e72                	slli	t3,t3,0x3c
    8003010e:	e131                	bnez	a0,80030152 <d_2_19+0x2>

0000000080030110 <d_2_15>:
    80030110:	f018                	sd	a4,32(s0)
    80030112:	5178                	lw	a4,100(a0)
    80030114:	43191803          	lh	a6,1073(s2)
    80030118:	b8e8                	fsd	fa0,240(s1)
    8003011a:	c348                	sw	a0,4(a4)
    8003011c:	c641                	beqz	a2,800301a4 <d_2_24+0x4>
    8003011e:	31a0                	fld	fs0,96(a1)

0000000080030120 <d_2_16>:
    80030120:	2376                	fld	ft6,344(sp)
    80030122:	1f20                	addi	s0,sp,952
    80030124:	15a136c3          	.insn	4, 0x15a136c3
    80030128:	71c5                	lui	gp,0xffff1
    8003012a:	c625                	beqz	a2,80030192 <d_2_23+0x2>
    8003012c:	0008                	.insn	2, 0x0008
    8003012e:	3bee                	fld	fs7,248(sp)

0000000080030130 <d_2_17>:
    80030130:	e5b4                	sd	a3,72(a1)
    80030132:	e8cfdc3b          	.insn	4, 0xe8cfdc3b
    80030136:	8ab0                	.insn	2, 0x8ab0
    80030138:	0a2e                	slli	s4,s4,0xb
    8003013a:	c979                	beqz	a0,80030210 <_end_data2+0x10>
    8003013c:	8d0c                	.insn	2, 0x8d0c
    8003013e:	1755                	addi	a4,a4,-11

0000000080030140 <d_2_18>:
    80030140:	b2ec                	fsd	fa1,224(a3)
    80030142:	8b9c                	.insn	2, 0x8b9c
    80030144:	a84642f7          	.insn	4, 0xa84642f7
    80030148:	e405                	bnez	s0,80030170 <d_2_21>
    8003014a:	87b2                	mv	a5,a2
    8003014c:	b0f0b0af          	.insn	4, 0xb0f0b0af

0000000080030150 <d_2_19>:
    80030150:	6ec0                	ld	s0,152(a3)
    80030152:	ee8c                	sd	a1,24(a3)
    80030154:	f4cdfb2f          	.insn	4, 0xf4cdfb2f
    80030158:	d62b268b          	.insn	4, 0xd62b268b
    8003015c:	9f8a                	add	t6,t6,sp
    8003015e:	439c                	lw	a5,0(a5)

0000000080030160 <d_2_20>:
    80030160:	ab20                	fsd	fs0,80(a4)
    80030162:	28e0                	fld	fs0,208(s1)
    80030164:	4f29                	li	t5,10
    80030166:	3752                	fld	fa4,304(sp)
    80030168:	b38d                	j	8002feca <_end_data1+0xfcca>
    8003016a:	272d                	addiw	a4,a4,11
    8003016c:	4a24                	lw	s1,80(a2)
    8003016e:	318c                	fld	fa1,32(a1)

0000000080030170 <d_2_21>:
    80030170:	e981                	bnez	a1,80030180 <d_2_22>
    80030172:	03f1                	addi	t2,t2,28
    80030174:	b6ec                	fsd	fa1,232(a3)
    80030176:	b09d                	j	8002f9dc <_end_data1+0xf7dc>
    80030178:	cfe2                	sw	s8,220(sp)
    8003017a:	64646c27          	vsuxseg4ei32.v	v24,(s0),v6,v0.t
    8003017e:	b07a                	fsd	ft10,32(sp)

0000000080030180 <d_2_22>:
    80030180:	6111                	addi	sp,sp,256
    80030182:	ffde                	sd	s7,504(sp)
    80030184:	1174                	addi	a3,sp,172
    80030186:	214010ff 6dd3cc82 	.insn	12, 0xb4e43c056dd3cc82214010ff
    8003018e:	 

0000000080030190 <d_2_23>:
    80030190:	b4e4                	fsd	fs1,232(s1)
    80030192:	829f 5afb 0ddd      	.insn	6, 0x0ddd5afb829f
    80030198:	1efec7a3          	.insn	4, 0x1efec7a3
    8003019c:	d810                	sw	a2,48(s0)
    8003019e:	a9c1                	j	8003066e <_end_data2+0x46e>

00000000800301a0 <d_2_24>:
    800301a0:	2441                	addiw	s0,s0,16
    800301a2:	f786                	sd	ra,488(sp)
    800301a4:	c0850237          	lui	tp,0xc0850
    800301a8:	441a                	lw	s0,132(sp)
    800301aa:	3cb4                	fld	fa3,120(s1)
    800301ac:	7228                	ld	a0,96(a2)
    800301ae:	1229                	addi	tp,tp,-22 # ffffffffc084ffea <_end+0xffffffff407efdea>

00000000800301b0 <d_2_25>:
    800301b0:	e982                	sd	zero,208(sp)
    800301b2:	4d11                	li	s10,4
    800301b4:	5ff5b413          	sltiu	s0,a1,1535
    800301b8:	6d59                	lui	s10,0x16
    800301ba:	f6060827          	.insn	4, 0xf6060827
    800301be:	5ee8                	lw	a0,124(a3)

00000000800301c0 <d_2_26>:
    800301c0:	0636                	slli	a2,a2,0xd
    800301c2:	4cf2                	lw	s9,28(sp)
    800301c4:	5338                	lw	a4,96(a4)
    800301c6:	ba4d                	j	8002fb78 <_end_data1+0xf978>
    800301c8:	c216                	sw	t0,4(sp)
    800301ca:	d624                	sw	s1,104(a2)
    800301cc:	f3fd9fef          	jal	t6,8000a10a <end_signature+0x7d2a>

00000000800301d0 <d_2_27>:
    800301d0:	59b33157          	.insn	4, 0x59b33157
    800301d4:	fd65                	bnez	a0,800301cc <d_2_26+0xc>
    800301d6:	3f9d                	addiw	t6,t6,-25
    800301d8:	b4686317          	auipc	t1,0xb4686
    800301dc:	610e0883          	lb	a7,1552(t3) # 7610 <_start-0x7fff89f0>
    800301e0:	e15d5f9b          	.insn	4, 0xe15d5f9b
    800301e4:	9235e4e3          	bltu	a1,gp,8002fb0c <_end_data1+0xf90c>
    800301e8:	1c54                	addi	a3,sp,564
    800301ea:	a0f9                	j	800302b8 <_end_data2+0xb8>
    800301ec:	49b9                	li	s3,14
    800301ee:	66aa                	ld	a3,136(sp)
    800301f0:	69a2                	ld	s3,8(sp)
    800301f2:	11c0dfe3          	bge	ra,t3,80030b10 <_end_data2+0x910>
    800301f6:	5cf8                	lw	a4,124(s1)
    800301f8:	9afe                	add	s5,s5,t6
    800301fa:	bc54                	fsd	fa3,184(s0)
    800301fc:	bc39c7cb          	.insn	4, 0xbc39c7cb

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	98f5                	andi	s1,s1,-3
    80040002:	da2eff57          	vsetivli	t5,29,418
    80040006:	6040                	ld	s0,128(s0)
    80040008:	edbe                	sd	a5,216(sp)
    8004000a:	a48e                	fsd	ft3,72(sp)
    8004000c:	e3aa                	sd	a0,448(sp)
    8004000e:	8bb2                	mv	s7,a2
    80040010:	88fa                	mv	a7,t5
    80040012:	4622                	lw	a2,8(sp)
    80040014:	2315                	addiw	t1,t1,5 # 346b61dd <_start-0x4b949e23>
    80040016:	bb20                	fsd	fs0,112(a4)
    80040018:	eb2f2853          	.insn	4, 0xeb2f2853
    8004001c:	513c                	lw	a5,96(a0)
    8004001e:	318a                	fld	ft3,160(sp)

0000000080040020 <d_3_0>:
    80040020:	bbebae3f a921c6cd 	.insn	8, 0xa921c6cdbbebae3f
    80040028:	955a                	add	a0,a0,s6
    8004002a:	de78                	sw	a4,124(a2)
    8004002c:	76a4                	ld	s1,104(a3)
    8004002e:	ec1e                	sd	t2,24(sp)

0000000080040030 <d_3_1>:
    80040030:	fb11                	bnez	a4,8003ff44 <_end_data2+0xfd44>
    80040032:	58ae                	lw	a7,232(sp)
    80040034:	7d9e                	ld	s11,480(sp)
    80040036:	cd1e                	sw	t2,152(sp)
    80040038:	53e3360b          	.insn	4, 0x53e3360b
    8004003c:	2711b553          	.insn	4, 0x2711b553

0000000080040040 <d_3_2>:
    80040040:	2c35                	addiw	s8,s8,13 # 1100d <_start-0x7ffeeff3>
    80040042:	afbec1b7          	lui	gp,0xafbec
    80040046:	dafc                	sw	a5,116(a3)
    80040048:	6445                	lui	s0,0x11
    8004004a:	3901                	addiw	s2,s2,-32
    8004004c:	0ae4                	addi	s1,sp,348
    8004004e:	8668                	.insn	2, 0x8668

0000000080040050 <d_3_3>:
    80040050:	278a                	fld	fa5,128(sp)
    80040052:	758c                	ld	a1,40(a1)
    80040054:	cbe0                	sw	s0,84(a5)
    80040056:	a149                	j	800404d8 <_end_data3+0x2d8>
    80040058:	d995                	beqz	a1,8003ff8c <_end_data2+0xfd8c>
    8004005a:	2a68                	fld	fa0,208(a2)
    8004005c:	d732                	sw	a2,172(sp)
    8004005e:	4f49                	li	t5,18

0000000080040060 <d_3_4>:
    80040060:	b14c                	fsd	fa1,160(a0)
    80040062:	94b4                	.insn	2, 0x94b4
    80040064:	c38d                	beqz	a5,80040086 <d_3_6+0x6>
    80040066:	536a                	lw	t1,184(sp)
    80040068:	db85                	beqz	a5,8003ff98 <_end_data2+0xfd98>
    8004006a:	b71a                	fsd	ft6,424(sp)
    8004006c:	c2e83b3f  	.insn	8, 0xd1dc02b3c2e83b3f

0000000080040070 <d_3_5>:
    80040070:	d1dc02b3          	.insn	4, 0xd1dc02b3
    80040074:	32bbff6f          	jal	t5,800ffb9e <_end+0x9f99e>
    80040078:	1a44                	addi	s1,sp,308
    8004007a:	24e6                	fld	fs1,88(sp)
    8004007c:	6e7a5803          	lhu	a6,1767(s4)

0000000080040080 <d_3_6>:
    80040080:	8b84                	.insn	2, 0x8b84
    80040082:	fc65                	bnez	s0,8004007a <d_3_5+0xa>
    80040084:	a16c                	fsd	fa1,192(a0)
    80040086:	01036b93          	ori	s7,t1,16
    8004008a:	d27b7c7b          	.insn	4, 0xd27b7c7b
    8004008e:	          	.insn	4, 0x736ffc7b

0000000080040090 <d_3_7>:
    80040090:	1eac736f          	jal	t1,8010727a <_end+0xa707a>
    80040094:	696e                	ld	s2,216(sp)
    80040096:	a1e1                	j	8004055e <_end_data3+0x35e>
    80040098:	941a                	add	s0,s0,t1
    8004009a:	910d                	srli	a0,a0,0x23
    8004009c:	49bc                	lw	a5,80(a1)
    8004009e:	76ea                	ld	a3,184(sp)

00000000800400a0 <d_3_8>:
    800400a0:	ebda                	sd	s6,464(sp)
    800400a2:	d85a                	sw	s6,48(sp)
    800400a4:	6df4                	ld	a3,216(a1)
    800400a6:	8c61                	and	s0,s0,s0
    800400a8:	2f80                	fld	fs0,24(a5)
    800400aa:	902c                	.insn	2, 0x902c
    800400ac:	fd6e                	sd	s11,184(sp)
    800400ae:	740a                	ld	s0,160(sp)

00000000800400b0 <d_3_9>:
    800400b0:	0168                	addi	a0,sp,140
    800400b2:	3f18                	fld	fa4,56(a4)
    800400b4:	ab71                	j	80040650 <_end_data3+0x450>
    800400b6:	1aa0                	addi	s0,sp,376
    800400b8:	808a                	mv	ra,sp
    800400ba:	c672                	sw	t3,12(sp)
    800400bc:	0819                	addi	a6,a6,6
    800400be:	ece2                	sd	s8,88(sp)

00000000800400c0 <d_3_10>:
    800400c0:	ff5d                	bnez	a4,8004007e <d_3_5+0xe>
    800400c2:	4059                	c.li	zero,22
    800400c4:	e8c60573          	.insn	4, 0xe8c60573
    800400c8:	8b85444b          	fnmsub.d	fs0,fa0,fs8,fa7,rmm
    800400cc:	82165937          	lui	s2,0x82165

00000000800400d0 <d_3_11>:
    800400d0:	7f66                	ld	t5,120(sp)
    800400d2:	34ae                	fld	fs1,232(sp)
    800400d4:	741e                	ld	s0,480(sp)
    800400d6:	69c5                	lui	s3,0x11
    800400d8:	2555                	addiw	a0,a0,21 # 6015 <_start-0x7fff9feb>
    800400da:	39c2                	fld	fs3,48(sp)
    800400dc:	b2d654bb          	.insn	4, 0xb2d654bb

00000000800400e0 <d_3_12>:
    800400e0:	99adeb57          	vmulhsu.vx	v22,v26,s11,v0.t
    800400e4:	688a5497          	auipc	s1,0x688a5
    800400e8:	558e                	lw	a1,224(sp)
    800400ea:	9956                	add	s2,s2,s5
    800400ec:	5089                	li	ra,-30
    800400ee:	5274                	lw	a3,100(a2)

00000000800400f0 <d_3_13>:
    800400f0:	8750e1bb          	.insn	4, 0x8750e1bb
    800400f4:	f189                	bnez	a1,8003fff6 <_end_data2+0xfdf6>
    800400f6:	47d0                	lw	a2,12(a5)
    800400f8:	9041                	srli	s0,s0,0x30
    800400fa:	b846                	fsd	fa7,48(sp)
    800400fc:	af4a                	fsd	fs2,408(sp)
    800400fe:	0a46                	slli	s4,s4,0x11

0000000080040100 <d_3_14>:
    80040100:	e9fc                	sd	a5,208(a1)
    80040102:	181e                	slli	a6,a6,0x27
    80040104:	a572                	fsd	ft8,136(sp)
    80040106:	024c                	addi	a1,sp,260
    80040108:	be721bf3          	csrrw	s7,0xbe7,tp
    8004010c:	82f4                	.insn	2, 0x82f4
    8004010e:	6c54                	ld	a3,152(s0)

0000000080040110 <d_3_15>:
    80040110:	fff6                	sd	t4,504(sp)
    80040112:	6ff9                	lui	t6,0x1e
    80040114:	d589                	beqz	a1,8004001e <_random_data3+0x1e>
    80040116:	1be6                	slli	s7,s7,0x39
    80040118:	dd8d                	beqz	a1,80040052 <d_3_3+0x2>
    8004011a:	2afd                	addiw	s5,s5,31
    8004011c:	f51c                	sd	a5,40(a0)
    8004011e:	2d24                	fld	fs1,88(a0)

0000000080040120 <d_3_16>:
    80040120:	b4a4                	fsd	fs1,104(s1)
    80040122:	7d00                	ld	s0,56(a0)
    80040124:	e75a                	sd	s6,392(sp)
    80040126:	1569                	addi	a0,a0,-6
    80040128:	af0a                	fsd	ft2,408(sp)
    8004012a:	73bd                	lui	t2,0xfffef
    8004012c:	910ec3db          	.insn	4, 0x910ec3db

0000000080040130 <d_3_17>:
    80040130:	e904                	sd	s1,16(a0)
    80040132:	3402                	fld	fs0,32(sp)
    80040134:	82ba                	mv	t0,a4
    80040136:	d6fc                	sw	a5,108(a3)
    80040138:	28668227          	vssseg2e8.v	v4,(a3),t1,v0.t
    8004013c:	4e2d                	li	t3,11
    8004013e:	d560                	sw	s0,108(a0)

0000000080040140 <d_3_18>:
    80040140:	dca5                	beqz	s1,800400b8 <d_3_9+0x8>
    80040142:	0c49                	addi	s8,s8,18
    80040144:	64ee                	ld	s1,216(sp)
    80040146:	61d38f8f          	.insn	4, 0x61d38f8f
    8004014a:	e58c                	sd	a1,8(a1)
    8004014c:	c056                	sw	s5,0(sp)
    8004014e:	c081                	beqz	s1,8004014e <d_3_18+0xe>

0000000080040150 <d_3_19>:
    80040150:	9a86                	add	s5,s5,ra
    80040152:	81eb170f          	.insn	4, 0x81eb170f
    80040156:	84de                	mv	s1,s7
    80040158:	5ef1                	li	t4,-4
    8004015a:	bab2                	fsd	fa2,368(sp)
    8004015c:	4fde                	lw	t6,212(sp)
    8004015e:	          	jal	s10,800885b8 <_end+0x283b8>

0000000080040160 <d_3_20>:
    80040160:	45a4                	lw	s1,72(a1)
    80040162:	55b1                	li	a1,-20
    80040164:	e727072b          	.insn	4, 0xe727072b
    80040168:	0d70                	addi	a2,sp,668
    8004016a:	4016                	.insn	2, 0x4016
    8004016c:	edb5                	bnez	a1,800401e8 <d_3_27+0x18>
    8004016e:	a286                	fsd	ft1,320(sp)

0000000080040170 <d_3_21>:
    80040170:	bf60                	fsd	fs0,248(a4)
    80040172:	4d176dd3          	.insn	4, 0x4d176dd3
    80040176:	9584                	.insn	2, 0x9584
    80040178:	8a99                	andi	a3,a3,6
    8004017a:	ef59                	bnez	a4,80040218 <_end_data3+0x18>
    8004017c:	67eb016b          	.insn	4, 0x67eb016b

0000000080040180 <d_3_22>:
    80040180:	27009e73          	csrrw	t3,0x270,ra
    80040184:	905c5b7f f606f95a 	.insn	20, 0x0efbcf641b281ff31068a8ecf606f95a905c5b7f
    8004018c:	1068a8ec  
    80040194:	 

0000000080040190 <d_3_23>:
    80040190:	1b281ff3          	csrrw	t6,0x1b2,a6
    80040194:	cf64                	sw	s1,92(a4)
    80040196:	0dfd0efb          	.insn	4, 0x0dfd0efb
    8004019a:	e876                	sd	t4,16(sp)
    8004019c:	d22d                	beqz	a2,800400fe <d_3_13+0xe>
    8004019e:	          	lui	s10,0x4ce81

00000000800401a0 <d_3_24>:
    800401a0:	4ce8                	lw	a0,92(s1)
    800401a2:	ddc9                	beqz	a1,8004013c <d_3_17+0xc>
    800401a4:	b071                	j	8003fa30 <_end_data2+0xf830>
    800401a6:	b6535253          	.insn	4, 0xb6535253
    800401aa:	7c2c                	ld	a1,120(s0)
    800401ac:	1244                	addi	s1,sp,292
    800401ae:	1746                	slli	a4,a4,0x31

00000000800401b0 <d_3_25>:
    800401b0:	ef4614c3          	.insn	4, 0xef4614c3
    800401b4:	2d20                	fld	fs0,88(a0)
    800401b6:	6d0c                	ld	a1,24(a0)
    800401b8:	e44c                	sd	a1,136(s0)
    800401ba:	830c                	.insn	2, 0x830c
    800401bc:	6261258f          	.insn	4, 0x6261258f

00000000800401c0 <d_3_26>:
    800401c0:	479e                	lw	a5,196(sp)
    800401c2:	bb6c                	fsd	fa1,240(a4)
    800401c4:	335f e9dc 482b      	.insn	6, 0x482be9dc335f
    800401ca:	5aec1f43          	fmadd.d	ft10,fs8,fa4,fa1,rtz
    800401ce:	44e0                	lw	s0,76(s1)

00000000800401d0 <d_3_27>:
    800401d0:	a9df31cf          	fnmadd.s	ft3,ft10,ft9,fs5,rup
    800401d4:	3ccba137          	lui	sp,0x3ccba
    800401d8:	db36                	sw	a3,180(sp)
    800401da:	5438                	lw	a4,104(s0)
    800401dc:	8de8                	.insn	2, 0x8de8
    800401de:	5758                	lw	a4,44(a4)
    800401e0:	6f36                	ld	t5,328(sp)
    800401e2:	372d                	addiw	a4,a4,-21
    800401e4:	cebd                	beqz	a3,80040262 <_end_data3+0x62>
    800401e6:	12e0                	addi	s0,sp,364
    800401e8:	9e78                	.insn	2, 0x9e78
    800401ea:	f322                	sd	s0,416(sp)
    800401ec:	a319                	j	800406f2 <_end_data3+0x4f2>
    800401ee:	c33a                	sw	a4,132(sp)
    800401f0:	49a0                	lw	s0,80(a1)
    800401f2:	eb72                	sd	t3,400(sp)
    800401f4:	3288                	fld	fa0,32(a3)
    800401f6:	9cd8                	.insn	2, 0x9cd8
    800401f8:	dfe4                	sw	s1,124(a5)
    800401fa:	0ea0                	addi	s0,sp,856
    800401fc:	8265                	srli	a2,a2,0x19
    800401fe:	2769                	addiw	a4,a4,26

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	cfb8                	sw	a4,88(a5)
    80050002:	67e1                	lui	a5,0x18
    80050004:	2a7e84f3          	.insn	4, 0x2a7e84f3
    80050008:	a46c                	fsd	fa1,200(s0)
    8005000a:	fc79                	bnez	s0,8004ffe8 <_end_data3+0xfde8>
    8005000c:	ec2e                	sd	a1,24(sp)
    8005000e:	5070e6b7          	lui	a3,0x5070e
    80050012:	3f00                	fld	fs0,56(a4)
    80050014:	ab11                	j	80050528 <_end_data4+0x328>
    80050016:	29fe                	fld	fs3,472(sp)
    80050018:	6fff 6e38 d5cd 16d3 	.insn	22, 0x34dd32dc9e38793da5d05b3d688a16d3d5cd6e386fff
    80050020:	    
    80050028:	   

0000000080050020 <d_4_0>:
    80050020:	688a                	ld	a7,128(sp)
    80050022:	5b3d                	li	s6,-17
    80050024:	a5d0                	fsd	fa2,136(a1)
    80050026:	793d                	lui	s2,0xfffef
    80050028:	9e38                	.insn	2, 0x9e38
    8005002a:	32dc                	fld	fa5,160(a3)
    8005002c:	34dd                	addiw	s1,s1,-9 # ffffffffe88e50db <_end+0xffffffff68884edb>
    8005002e:	ab4c                	fsd	fa1,144(a4)

0000000080050030 <d_4_1>:
    80050030:	ee1f5da3          	.insn	4, 0xee1f5da3
    80050034:	d0190733          	.insn	4, 0xd0190733
    80050038:	6aa1                	lui	s5,0x8
    8005003a:	b4ed                	j	8004fb24 <_end_data3+0xf924>
    8005003c:	e684                	sd	s1,8(a3)
    8005003e:	9d19                	subw	a0,a0,a4

0000000080050040 <d_4_2>:
    80050040:	46cc                	lw	a1,12(a3)
    80050042:	ec7f c985 36da a429 	.insn	22, 0x2b019e99b196b277b9dab9ee3762a42936dac985ec7f
    8005004a:	3762 b9ee b9da  
    80050052:	   

0000000080050050 <d_4_3>:
    80050050:	b196b277          	.insn	4, 0xb196b277
    80050054:	9e99                	subw	a3,a3,a4
    80050056:	2b01                	sext.w	s6,s6
    80050058:	f235                	bnez	a2,8004ffbc <_end_data3+0xfdbc>
    8005005a:	43c5                	li	t2,17
    8005005c:	b1d94733          	.insn	4, 0xb1d94733

0000000080050060 <d_4_4>:
    80050060:	d24cacf3          	csrrs	s9,0xd24,s9
    80050064:	eab53853          	.insn	4, 0xeab53853
    80050068:	cd25                	beqz	a0,800500e0 <d_4_12>
    8005006a:	d8bc                	sw	a5,112(s1)
    8005006c:	cac6                	sw	a7,84(sp)
    8005006e:	2d89                	addiw	s11,s11,2

0000000080050070 <d_4_5>:
    80050070:	a5ac9007          	.insn	4, 0xa5ac9007
    80050074:	ca6c                	sw	a1,84(a2)
    80050076:	c849                	beqz	s0,80050108 <d_4_14+0x8>
    80050078:	a3bc                	fsd	fa5,64(a5)
    8005007a:	113e                	slli	sp,sp,0x2f
    8005007c:	2d22                	fld	fs10,8(sp)
    8005007e:	e032                	sd	a2,0(sp)

0000000080050080 <d_4_6>:
    80050080:	5798                	lw	a4,40(a5)
    80050082:	a1c6a73b          	.insn	4, 0xa1c6a73b
    80050086:	7ea5                	lui	t4,0xfffe9
    80050088:	09cbbedb          	.insn	4, 0x09cbbedb
    8005008c:	2c8f040f          	.insn	4, 0x2c8f040f

0000000080050090 <d_4_7>:
    80050090:	43cc                	lw	a1,4(a5)
    80050092:	c789                	beqz	a5,8005009c <d_4_7+0xc>
    80050094:	5831                	li	a6,-20
    80050096:	8a04                	.insn	2, 0x8a04
    80050098:	c316                	sw	t0,132(sp)
    8005009a:	a221                	j	800501a2 <d_4_24+0x2>
    8005009c:	4e4d                	li	t3,19
    8005009e:	880c                	.insn	2, 0x880c

00000000800500a0 <d_4_8>:
    800500a0:	f48a3d27          	fsd	fs0,-166(s4)
    800500a4:	df1aa7cb          	.insn	4, 0xdf1aa7cb
    800500a8:	a5e2                	fsd	fs8,200(sp)
    800500aa:	1459                	addi	s0,s0,-10 # 10ff6 <_start-0x7ffef00a>
    800500ac:	ca8901c7          	fmsub.d	ft3,fs2,fs0,fs9,rne

00000000800500b0 <d_4_9>:
    800500b0:	dc82                	sw	zero,120(sp)
    800500b2:	5c8cc6f3          	.insn	4, 0x5c8cc6f3
    800500b6:	f162                	sd	s8,160(sp)
    800500b8:	180a                	slli	a6,a6,0x22
    800500ba:	1d92                	slli	s11,s11,0x24
    800500bc:	03fe                	slli	t2,t2,0x1f
    800500be:	e0c8                	sd	a0,128(s1)

00000000800500c0 <d_4_10>:
    800500c0:	5185                	li	gp,-31
    800500c2:	351c                	fld	fa5,40(a0)
    800500c4:	4228                	lw	a0,64(a2)
    800500c6:	0532                	slli	a0,a0,0xc
    800500c8:	0ef2                	slli	t4,t4,0x1c
    800500ca:	1cbd5e23          	.insn	4, 0x1cbd5e23
    800500ce:	3159                	addiw	sp,sp,-10 # 3ccb9ff6 <_start-0x4334600a>

00000000800500d0 <d_4_11>:
    800500d0:	83ad                	srli	a5,a5,0xb
    800500d2:	f6f4                	sd	a3,232(a3)
    800500d4:	7d51                	lui	s10,0xffff4
    800500d6:	768a                	ld	a3,160(sp)
    800500d8:	adc8877b          	.insn	4, 0xadc8877b
    800500dc:	9524                	.insn	2, 0x9524
    800500de:	0279                	addi	tp,tp,30 # 1e <_start-0x7fffffe2>

00000000800500e0 <d_4_12>:
    800500e0:	81ad0f43          	fmadd.s	ft10,fs10,fs10,fa6,rne
    800500e4:	56e4                	lw	s1,108(a3)
    800500e6:	878d                	srai	a5,a5,0x3
    800500e8:	2f56                	fld	ft10,336(sp)
    800500ea:	fd082b3b          	.insn	4, 0xfd082b3b
    800500ee:	944a                	add	s0,s0,s2

00000000800500f0 <d_4_13>:
    800500f0:	a89f 1d74 fe00      	.insn	6, 0xfe001d74a89f
    800500f6:	357a                	fld	fa0,440(sp)
    800500f8:	5822                	lw	a6,40(sp)
    800500fa:	7489                	lui	s1,0xfffe2
    800500fc:	38e2                	fld	fa7,56(sp)
    800500fe:	4c62                	lw	s8,24(sp)

0000000080050100 <d_4_14>:
    80050100:	1aa4                	addi	s1,sp,376
    80050102:	8d34332b          	.insn	4, 0x8d34332b
    80050106:	e50a6947          	.insn	4, 0xe50a6947
    8005010a:	1f9eeeb3          	.insn	4, 0x1f9eeeb3
    8005010e:	2f21                	addiw	t5,t5,8

0000000080050110 <d_4_15>:
    80050110:	4066                	.insn	2, 0x4066
    80050112:	b674187b          	.insn	4, 0xb674187b
    80050116:	a93e                	fsd	fa5,144(sp)
    80050118:	2946                	fld	fs2,80(sp)
    8005011a:	33eff967          	.insn	4, 0x33eff967
    8005011e:	1086                	slli	ra,ra,0x21

0000000080050120 <d_4_16>:
    80050120:	aad9                	j	800502f6 <_end_data4+0xf6>
    80050122:	a5489343          	.insn	4, 0xa5489343
    80050126:	89f2a1a7          	fsw	ft11,-1917(t0)
    8005012a:	7b4eb4db          	.insn	4, 0x7b4eb4db
    8005012e:	          	.insn	4, 0xa447a2b3

0000000080050130 <d_4_17>:
    80050130:	9f9fa447          	.insn	4, 0x9f9fa447
    80050134:	efb1                	bnez	a5,80050190 <d_4_23>
    80050136:	ded8b43f 241a51aa 	.insn	8, 0x241a51aaded8b43f
    8005013e:	3ada                	fld	fs5,432(sp)

0000000080050140 <d_4_18>:
    80050140:	9ae0                	.insn	2, 0x9ae0
    80050142:	bd88                	fsd	fa0,56(a1)
    80050144:	e614                	sd	a3,8(a2)
    80050146:	5b41                	li	s6,-16
    80050148:	3141                	addiw	sp,sp,-16
    8005014a:	3c62                	fld	fs8,56(sp)
    8005014c:	e5dc                	sd	a5,136(a1)
    8005014e:	9f29                	addw	a4,a4,a0

0000000080050150 <d_4_19>:
    80050150:	6552                	ld	a0,272(sp)
    80050152:	aaaf1393          	.insn	4, 0xaaaf1393
    80050156:	a79d                	j	800508bc <_end_data4+0x6bc>
    80050158:	cb91                	beqz	a5,8005016c <d_4_20+0xc>
    8005015a:	83b6                	mv	t2,a3
    8005015c:	ccf1                	beqz	s1,80050238 <_end_data4+0x38>
    8005015e:	d1c8                	sw	a0,36(a1)

0000000080050160 <d_4_20>:
    80050160:	839e                	mv	t2,t2
    80050162:	4a6e                	lw	s4,216(sp)
    80050164:	1a056717          	auipc	a4,0x1a056
    80050168:	daa6                	sw	s1,116(sp)
    8005016a:	8b4deff3          	csrrsi	t6,0x8b4,27
    8005016e:	a686                	fsd	ft1,328(sp)

0000000080050170 <d_4_21>:
    80050170:	5566                	lw	a0,120(sp)
    80050172:	715d                	addi	sp,sp,-80
    80050174:	b708                	fsd	fa0,40(a4)
    80050176:	6bf9                	lui	s7,0x1e
    80050178:	6ae6                	ld	s5,88(sp)
    8005017a:	209d                	addiw	ra,ra,7
    8005017c:	9ef0                	.insn	2, 0x9ef0
    8005017e:	8629                	srai	a2,a2,0xa

0000000080050180 <d_4_22>:
    80050180:	58c5                	li	a7,-15
    80050182:	9eb8                	.insn	2, 0x9eb8
    80050184:	4ac1                	li	s5,16
    80050186:	d489                	beqz	s1,80050090 <d_4_7>
    80050188:	bb3a                	fsd	fa4,432(sp)
    8005018a:	8982                	jr	s3
    8005018c:	c0b6                	sw	a3,64(sp)
    8005018e:	1e9a                	slli	t4,t4,0x26

0000000080050190 <d_4_23>:
    80050190:	7ee4                	ld	s1,248(a3)
    80050192:	4cd2                	lw	s9,20(sp)
    80050194:	068e                	slli	a3,a3,0x3
    80050196:	6906                	ld	s2,64(sp)
    80050198:	dffe948f          	.insn	4, 0xdffe948f
    8005019c:	3f2c1dff  	.insn	12, 0x0deeb510ba1898f43f2c1dff
    800501a4:	 

00000000800501a0 <d_4_24>:
    800501a0:	98f4                	.insn	2, 0x98f4
    800501a2:	ba18                	fsd	fa4,48(a2)
    800501a4:	b510                	fsd	fa2,40(a0)
    800501a6:	0dee                	slli	s11,s11,0x1b
    800501a8:	4e5bc03b          	.insn	4, 0x4e5bc03b
    800501ac:	f992                	sd	tp,240(sp)
    800501ae:	          	ld	t0,744(s4)

00000000800501b0 <d_4_25>:
    800501b0:	2e8a                	fld	ft9,128(sp)
    800501b2:	b286                	fsd	ft1,352(sp)
    800501b4:	2e87566f          	jal	a2,800c549c <_end+0x6529c>
    800501b8:	f20d50ef          	jal	800258d8 <_end_data1+0x56d8>
    800501bc:	22c1                	addiw	t0,t0,16
    800501be:	1bac                	addi	a1,sp,504

00000000800501c0 <d_4_26>:
    800501c0:	9142                	add	sp,sp,a6
    800501c2:	1aea                	slli	s5,s5,0x3a
    800501c4:	d91d                	beqz	a0,800500fa <d_4_13+0xa>
    800501c6:	917e                	add	sp,sp,t6
    800501c8:	4665                	li	a2,25
    800501ca:	ec85                	bnez	s1,80050202 <_end_data4+0x2>
    800501cc:	6e56                	ld	t3,336(sp)
    800501ce:	36c0                	fld	fs0,168(a3)

00000000800501d0 <d_4_27>:
    800501d0:	94da                	add	s1,s1,s6
    800501d2:	02d5                	addi	t0,t0,21
    800501d4:	7a25                	lui	s4,0xfffe9
    800501d6:	6caf2d8f          	.insn	4, 0x6caf2d8f
    800501da:	6055                	c.lui	zero,0x15
    800501dc:	2214                	fld	fa3,0(a2)
    800501de:	c374310b          	.insn	4, 0xc374310b
    800501e2:	8eca                	mv	t4,s2
    800501e4:	e3a6                	sd	s1,448(sp)
    800501e6:	f480                	sd	s0,40(s1)
    800501e8:	f0e1                	bnez	s1,800501a8 <d_4_24+0x8>
    800501ea:	e985                	bnez	a1,8005021a <_end_data4+0x1a>
    800501ec:	a39f 1713 411a      	.insn	6, 0x411a1713a39f
    800501f2:	2ad0                	fld	fa2,144(a3)
    800501f4:	6e24                	ld	s1,88(a2)
    800501f6:	381e                	fld	fa6,480(sp)
    800501f8:	e705180b          	.insn	4, 0xe705180b
    800501fc:	965d                	srai	a2,a2,0x37
    800501fe:	411e                	lw	sp,196(sp)

Disassembly of section .data.random5:

0000000080060000 <_random_data5>:
    80060000:	bbf6                	fsd	ft9,496(sp)
    80060002:	77d3088f          	.insn	4, 0x77d3088f
    80060006:	23d5                	addiw	t2,t2,21 # fffffffffffef015 <_end+0xffffffff7ff8ee15>
    80060008:	b0f8                	fsd	fa4,224(s1)
    8006000a:	7d1fcbf3          	.insn	4, 0x7d1fcbf3
    8006000e:	de5d                	beqz	a2,8005ffcc <_end_data4+0xfdcc>
    80060010:	eb84                	sd	s1,16(a5)
    80060012:	fdaa                	sd	a0,248(sp)
    80060014:	9e92                	add	t4,t4,tp
    80060016:	f440                	sd	s0,168(s0)
    80060018:	f8f4                	sd	a3,240(s1)
    8006001a:	8fd6                	mv	t6,s5
    8006001c:	bfae                	fsd	fa1,504(sp)
    8006001e:	7e85                	lui	t4,0xfffe1

0000000080060020 <d_5_0>:
    80060020:	b2a1                	j	8005f968 <_end_data4+0xf768>
    80060022:	bbf28b87          	.insn	4, 0xbbf28b87
    80060026:	059e                	slli	a1,a1,0x7
    80060028:	e51e                	sd	t2,136(sp)
    8006002a:	6c8fe5b3          	.insn	4, 0x6c8fe5b3
    8006002e:	          	.insn	4, 0x5f1d1d6b

0000000080060030 <d_5_1>:
    80060030:	5f1d                	li	t5,-25
    80060032:	3eb0                	fld	fa2,120(a3)
    80060034:	0828                	addi	a0,sp,24
    80060036:	94dd                	srai	s1,s1,0x37
    80060038:	f386951b          	.insn	4, 0xf386951b
    8006003c:	46f4                	lw	a3,76(a3)
    8006003e:	ed5a                	sd	s6,152(sp)

0000000080060040 <d_5_2>:
    80060040:	b23c                	fsd	fa5,96(a2)
    80060042:	fb36                	sd	a3,432(sp)
    80060044:	8841b21b          	.insn	4, 0x8841b21b
    80060048:	0b9d                	addi	s7,s7,7 # 1e007 <_start-0x7ffe1ff9>
    8006004a:	639a118b          	.insn	4, 0x639a118b
    8006004e:	5d5f        	.insn	6, 0xd47d5f845d5f

0000000080060050 <d_5_3>:
    80060050:	5f84                	lw	s1,56(a5)
    80060052:	d47d                	beqz	s0,80060040 <d_5_2>
    80060054:	4c98                	lw	a4,24(s1)
    80060056:	d404ccef          	jal	s9,7ffac596 <_start-0x53a6a>
    8006005a:	be4fe1e3          	bltu	t6,tp,8005fc3c <_end_data4+0xfa3c>
    8006005e:	a500                	fsd	fs0,8(a0)

0000000080060060 <d_5_4>:
    80060060:	948b2f23          	sw	s0,-1698(s6) # fffffffffffe695e <_end+0xffffffff7ff8675e>
    80060064:	6386                	ld	t2,64(sp)
    80060066:	cd1e                	sw	t2,152(sp)
    80060068:	d694                	sw	a3,40(a3)
    8006006a:	46a2                	lw	a3,8(sp)
    8006006c:	677f e7a2   	.insn	22, 0x9ba49364253931eadf54943ad5dc1414063ee7a2677f
    80060074:	    
    8006007c:	   

0000000080060070 <d_5_5>:
    80060070:	063e                	slli	a2,a2,0xf
    80060072:	1414                	addi	a3,sp,544
    80060074:	d5dc                	sw	a5,44(a1)
    80060076:	943a                	add	s0,s0,a4
    80060078:	df54                	sw	a3,60(a4)
    8006007a:	31ea                	fld	ft3,184(sp)
    8006007c:	2539                	addiw	a0,a0,14
    8006007e:	9364                	.insn	2, 0x9364

0000000080060080 <d_5_6>:
    80060080:	9ba4                	.insn	2, 0x9ba4
    80060082:	158d651b          	.insn	4, 0x158d651b
    80060086:	40d8d337          	lui	t1,0x40d8d
    8006008a:	445e                	lw	s0,212(sp)
    8006008c:	04dc7c87          	vluxei64.v	v25,(s8),v13,v0.t

0000000080060090 <d_5_7>:
    80060090:	021f ebc8 afec      	.insn	6, 0xafecebc8021f
    80060096:	e4c6                	sd	a7,72(sp)
    80060098:	6fd6                	ld	t6,336(sp)
    8006009a:	16594727          	.insn	4, 0x16594727
    8006009e:	ed78                	sd	a4,216(a0)

00000000800600a0 <d_5_8>:
    800600a0:	9f96                	add	t6,t6,t0
    800600a2:	1122                	slli	sp,sp,0x28
    800600a4:	e6a1                	bnez	a3,800600ec <d_5_12+0xc>
    800600a6:	d8ed                	beqz	s1,80060098 <d_5_7+0x8>
    800600a8:	37c6                	fld	fa5,112(sp)
    800600aa:	9ef4                	.insn	2, 0x9ef4
    800600ac:	2855                	addiw	a6,a6,21
    800600ae:	0739                	addi	a4,a4,14 # 9a0a6172 <_end+0x1a045f72>

00000000800600b0 <d_5_9>:
    800600b0:	7cd8                	ld	a4,184(s1)
    800600b2:	e41e                	sd	t2,8(sp)
    800600b4:	182c                	addi	a1,sp,56
    800600b6:	647a                	ld	s0,408(sp)
    800600b8:	756715e3          	bne	a4,s6,80061002 <_end+0xe02>
    800600bc:	bc6a                	fsd	fs10,56(sp)
    800600be:	af51                	j	80060852 <_end+0x652>

00000000800600c0 <d_5_10>:
    800600c0:	941c                	.insn	2, 0x941c
    800600c2:	30c9                	addiw	ra,ra,-14
    800600c4:	48e4494f          	fnmadd.s	fs2,fs0,fa4,fs1,rmm
    800600c8:	95e4                	.insn	2, 0x95e4
    800600ca:	49a4                	lw	s1,80(a1)
    800600cc:	9bd2                	add	s7,s7,s4
    800600ce:	          	.insn	4, 0x7d1c1657

00000000800600d0 <d_5_11>:
    800600d0:	7d1c                	ld	a5,56(a0)
    800600d2:	cb01                	beqz	a4,800600e2 <d_5_12+0x2>
    800600d4:	4cb9                	li	s9,14
    800600d6:	5690                	lw	a2,40(a3)
    800600d8:	9371                	srli	a4,a4,0x3c
    800600da:	a420                	fsd	fs0,72(s0)
    800600dc:	808f82ab          	.insn	4, 0x808f82ab

00000000800600e0 <d_5_12>:
    800600e0:	3f8a                	fld	ft11,160(sp)
    800600e2:	68f5                	lui	a7,0x1d
    800600e4:	3e6d                	addiw	t3,t3,-5
    800600e6:	aedc                	fsd	fa5,152(a3)
    800600e8:	a43e                	fsd	fa5,8(sp)
    800600ea:	192a                	slli	s2,s2,0x2a
    800600ec:	b98c                	fsd	fa1,48(a1)
    800600ee:	a6a2                	fsd	fs0,328(sp)

00000000800600f0 <d_5_13>:
    800600f0:	dac0                	sw	s0,52(a3)
    800600f2:	4885                	li	a7,1
    800600f4:	89e1                	andi	a1,a1,24
    800600f6:	9a21                	andi	a2,a2,-24
    800600f8:	6c99dcb3          	.insn	4, 0x6c99dcb3
    800600fc:	b942                	fsd	fa6,176(sp)
    800600fe:	          	fnmsub.s	ft5,fs11,ft0,ft11,unknown

0000000080060100 <d_5_14>:
    80060100:	f80d                	bnez	s0,80060032 <d_5_1+0x2>
    80060102:	5b2e                	lw	s6,232(sp)
    80060104:	7002                	.insn	2, 0x7002
    80060106:	bfd1                	j	800600da <d_5_11+0xa>
    80060108:	6e70                	ld	a2,216(a2)
    8006010a:	0628                	addi	a0,sp,776
    8006010c:	2e38                	fld	fa4,88(a2)
    8006010e:	          	bne	a3,sp,80060706 <_end+0x506>

0000000080060110 <d_5_15>:
    80060110:	5e26                	lw	t3,104(sp)
    80060112:	222d                	addiw	tp,tp,11 # b <_start-0x7ffffff5>
    80060114:	355e                	fld	fa0,496(sp)
    80060116:	6e20                	ld	s0,88(a2)
    80060118:	f6d5                	bnez	a3,800600c4 <d_5_10+0x4>
    8006011a:	c3f6                	sw	t4,196(sp)
    8006011c:	c638                	sw	a4,72(a2)
    8006011e:	097d                	addi	s2,s2,31 # fffffffffffef01f <_end+0xffffffff7ff8ee1f>

0000000080060120 <d_5_16>:
    80060120:	c04d                	beqz	s0,800601c2 <d_5_26+0x2>
    80060122:	d7cc                	sw	a1,44(a5)
    80060124:	919dec57          	vmulhu.vx	v24,v25,s11,v0.t
    80060128:	e59a8cf3          	.insn	4, 0xe59a8cf3
    8006012c:	61ec                	ld	a1,192(a1)
    8006012e:	          	.insn	4, 0x5c9a24b3

0000000080060130 <d_5_17>:
    80060130:	5c9a                	lw	s9,164(sp)
    80060132:	4aee                	lw	s5,216(sp)
    80060134:	9822                	add	a6,a6,s0
    80060136:	b041                	j	8005f9b6 <_end_data4+0xf7b6>
    80060138:	26a2                	fld	fa3,8(sp)
    8006013a:	fb9d                	bnez	a5,80060070 <d_5_5>
    8006013c:	fbf4                	sd	a3,240(a5)
    8006013e:	          	.insn	4, 0x779c6607

0000000080060140 <d_5_18>:
    80060140:	779c                	ld	a5,40(a5)
    80060142:	b7f1                	j	8006010e <d_5_14+0xe>
    80060144:	e1f9                	bnez	a1,8006020a <_end+0xa>
    80060146:	eb80ce2b          	.insn	4, 0xeb80ce2b
    8006014a:	4415                	li	s0,5
    8006014c:	74260943          	.insn	4, 0x74260943

0000000080060150 <d_5_19>:
    80060150:	41c4                	lw	s1,4(a1)
    80060152:	a11c                	fsd	fa5,0(a0)
    80060154:	5af1726b          	.insn	4, 0x5af1726b
    80060158:	e0c1                	bnez	s1,800601d8 <d_5_27+0x8>
    8006015a:	0546                	slli	a0,a0,0x11
    8006015c:	1a78290f          	.insn	4, 0x1a78290f

0000000080060160 <d_5_20>:
    80060160:	1e773a43          	.insn	4, 0x1e773a43
    80060164:	bd41                	j	8005fff4 <_end_data4+0xfdf4>
    80060166:	7758                	ld	a4,168(a4)
    80060168:	5770                	lw	a2,108(a4)
    8006016a:	66d2823b          	.insn	4, 0x66d2823b
    8006016e:	8248                	.insn	2, 0x8248

0000000080060170 <d_5_21>:
    80060170:	2e34                	fld	fa3,88(a2)
    80060172:	6c6e                	ld	s8,216(sp)
    80060174:	9d4ab42b          	.insn	4, 0x9d4ab42b
    80060178:	db4a                	sw	s2,180(sp)
    8006017a:	29df17ab          	.insn	4, 0x29df17ab
    8006017e:	          	.insn	4, 0xdd37dc4f

0000000080060180 <d_5_22>:
    80060180:	3fd3dd37          	lui	s10,0x3fd3d
    80060184:	1b1d                	addi	s6,s6,-25
    80060186:	3185                	addiw	gp,gp,-31 # ffffffffafbebfe1 <_end+0xffffffff2fb8bde1>
    80060188:	a6ac                	fsd	fa1,72(a3)
    8006018a:	c091                	beqz	s1,8006018e <d_5_22+0xe>
    8006018c:	649565c7          	.insn	4, 0x649565c7

0000000080060190 <d_5_23>:
    80060190:	da8404eb          	.insn	4, 0xda8404eb
    80060194:	0274                	addi	a3,sp,268
    80060196:	eda52b1b          	.insn	4, 0xeda52b1b
    8006019a:	5d95                	li	s11,-27
    8006019c:	24e9                	addiw	s1,s1,26 # fffffffffffe201a <_end+0xffffffff7ff81e1a>
    8006019e:	8d02                	jr	s10

00000000800601a0 <d_5_24>:
    800601a0:	394fd657          	vfslide1up.vf	v12,v20,ft11,v0.t
    800601a4:	59fe                	lw	s3,252(sp)
    800601a6:	2066                	fld	ft0,88(sp)
    800601a8:	7da0                	ld	s0,120(a1)
    800601aa:	2981                	sext.w	s3,s3
    800601ac:	34312517          	auipc	a0,0x34312

00000000800601b0 <d_5_25>:
    800601b0:	fa8bab33          	.insn	4, 0xfa8bab33
    800601b4:	780a                	ld	a6,160(sp)
    800601b6:	6218                	ld	a4,0(a2)
    800601b8:	1762                	slli	a4,a4,0x38
    800601ba:	0c10                	addi	a2,sp,528
    800601bc:	1c55                	addi	s8,s8,-11
    800601be:	0e02                	c.slli64	t3

00000000800601c0 <d_5_26>:
    800601c0:	4878                	lw	a4,84(s0)
    800601c2:	158d                	addi	a1,a1,-29 # db3ffe3 <_start-0x724c001d>
    800601c4:	9152e533          	.insn	4, 0x9152e533
    800601c8:	f754                	sd	a3,168(a4)
    800601ca:	d995                	beqz	a1,800600fe <d_5_13+0xe>
    800601cc:	dd42                	sw	a6,184(sp)
    800601ce:	4956                	lw	s2,84(sp)

00000000800601d0 <d_5_27>:
    800601d0:	7bbd                	lui	s7,0xfffef
    800601d2:	fef0                	sd	a2,248(a3)
    800601d4:	f392                	sd	tp,480(sp)
    800601d6:	2de8                	fld	fa0,216(a1)
    800601d8:	3b0e                	fld	fs6,224(sp)
    800601da:	baf6                	fsd	ft9,368(sp)
    800601dc:	215f834f          	fnmadd.s	ft6,ft11,fs5,ft4,rne
    800601e0:	4efe                	lw	t4,220(sp)
    800601e2:	789e                	ld	a7,480(sp)
    800601e4:	990e                	add	s2,s2,gp
    800601e6:	c65e                	sw	s7,12(sp)
    800601e8:	1a74                	addi	a3,sp,316
    800601ea:	f659                	bnez	a2,80060178 <d_5_21+0x8>
    800601ec:	2284                	fld	fs1,0(a3)
    800601ee:	47cd                	li	a5,19
    800601f0:	8068                	.insn	2, 0x8068
    800601f2:	d37a                	sw	t5,164(sp)
    800601f4:	4cd1                	li	s9,20
    800601f6:	8d3e                	mv	s10,a5
    800601f8:	1def9bd3          	.insn	4, 0x1def9bd3
    800601fc:	6b6a                	ld	s6,152(sp)
    800601fe:	a2a6                	fsd	fs1,320(sp)

Disassembly of section .riscv.attributes:

0000000000000000 <.riscv.attributes>:
   0:	ee41                	bnez	a2,98 <_start-0x7fffff68>
   2:	0000                	unimp
   4:	7200                	ld	s0,32(a2)
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <_start-0x7fffffec>
   c:	00e4                	addi	s1,sp,76
   e:	0000                	unimp
  10:	7205                	lui	tp,0xfffe1
  12:	3676                	fld	fa2,376(sp)
  14:	6934                	ld	a3,80(a0)
  16:	7032                	.insn	2, 0x7032
  18:	5f31                	li	t5,-20
  1a:	326d                	addiw	tp,tp,-5 # fffffffffffe0ffb <_end+0xffffffff7ff80dfb>
  1c:	3070                	fld	fa2,224(s0)
  1e:	615f 7032 5f31      	.insn	6, 0x5f317032615f
  24:	3266                	fld	ft4,120(sp)
  26:	3270                	fld	fa2,224(a2)
  28:	645f 7032 5f32      	.insn	6, 0x5f327032645f
  2e:	30703263          	.insn	4, 0x30703263
  32:	765f 7031 5f30      	.insn	6, 0x5f307031765f
  38:	3168                	fld	fa0,224(a0)
  3a:	3070                	fld	fa2,224(s0)
  3c:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  42:	316d                	addiw	sp,sp,-5
  44:	3070                	fld	fa2,224(s0)
  46:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  4c:	3170                	fld	fa2,224(a0)
  4e:	3070                	fld	fa2,224(s0)
  50:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  56:	317a                	fld	ft2,440(sp)
  58:	3070                	fld	fa2,224(s0)
  5a:	7a5f 6369 7273      	.insn	6, 0x727363697a5f
  60:	7032                	.insn	2, 0x7032
  62:	5f30                	lw	a2,120(a4)
  64:	697a                	ld	s2,408(sp)
  66:	6566                	ld	a0,88(sp)
  68:	636e                	ld	t1,216(sp)
  6a:	6965                	lui	s2,0x19
  6c:	7032                	.insn	2, 0x7032
  6e:	5f30                	lw	a2,120(a4)
  70:	6d7a                	ld	s10,408(sp)
  72:	756d                	lui	a0,0xffffb
  74:	316c                	fld	fa1,224(a0)
  76:	3070                	fld	fa2,224(s0)
  78:	7a5f 6161 6f6d      	.insn	6, 0x6f6d61617a5f
  7e:	7031                	c.lui	zero,0xfffec
  80:	5f30                	lw	a2,120(a4)
  82:	617a                	ld	sp,408(sp)
  84:	726c                	ld	a1,224(a2)
  86:	70316373          	csrrsi	t1,0x703,2
  8a:	5f30                	lw	a2,120(a4)
  8c:	637a                	ld	t1,408(sp)
  8e:	3161                	addiw	sp,sp,-8
  90:	3070                	fld	fa2,224(s0)
  92:	7a5f 6463 7031      	.insn	6, 0x703164637a5f
  98:	5f30                	lw	a2,120(a4)
  9a:	767a                	ld	a2,440(sp)
  9c:	3365                	addiw	t1,t1,-7 # ffffffffffff9ff9 <_end+0xffffffff7ff99df9>
  9e:	6632                	ld	a2,264(sp)
  a0:	7031                	c.lui	zero,0xfffec
  a2:	5f30                	lw	a2,120(a4)
  a4:	767a                	ld	a2,440(sp)
  a6:	3365                	addiw	t1,t1,-7
  a8:	7832                	ld	a6,296(sp)
  aa:	7031                	c.lui	zero,0xfffec
  ac:	5f30                	lw	a2,120(a4)
  ae:	767a                	ld	a2,440(sp)
  b0:	3665                	addiw	a2,a2,-7
  b2:	6434                	ld	a3,72(s0)
  b4:	7031                	c.lui	zero,0xfffec
  b6:	5f30                	lw	a2,120(a4)
  b8:	767a                	ld	a2,440(sp)
  ba:	3665                	addiw	a2,a2,-7
  bc:	6634                	ld	a3,72(a2)
  be:	7031                	c.lui	zero,0xfffec
  c0:	5f30                	lw	a2,120(a4)
  c2:	767a                	ld	a2,440(sp)
  c4:	3665                	addiw	a2,a2,-7
  c6:	7834                	ld	a3,112(s0)
  c8:	7031                	c.lui	zero,0xfffec
  ca:	5f30                	lw	a2,120(a4)
  cc:	767a                	ld	a2,440(sp)
  ce:	316c                	fld	fa1,224(a0)
  d0:	3832                	fld	fa6,296(sp)
  d2:	3162                	fld	ft2,56(sp)
  d4:	3070                	fld	fa2,224(s0)
  d6:	7a5f 6c76 3233      	.insn	6, 0x32336c767a5f
  dc:	3162                	fld	ft2,56(sp)
  de:	3070                	fld	fa2,224(s0)
  e0:	7a5f 6c76 3436      	.insn	6, 0x34366c767a5f
  e6:	3162                	fld	ft2,56(sp)
  e8:	3070                	fld	fa2,224(s0)
  ea:	0800                	addi	s0,sp,16
  ec:	0a01                	addi	s4,s4,0 # fffffffffffe9000 <_end+0xffffffff7ff88e00>
  ee:	0b                	.byte	0x0b
