
output_8_14/.input_0.elf:     file format elf64-littleriscv


Disassembly of section .text.init:

0000000080000000 <_start>:
    80000000:	00010f97          	auipc	t6,0x10
    80000004:	000f8f93          	mv	t6,t6
    80000008:	000fb083          	ld	ra,0(t6) # 80010000 <_random_data0>
    8000000c:	008fb103          	ld	sp,8(t6)
    80000010:	010fb183          	ld	gp,16(t6)
    80000014:	018fb203          	ld	tp,24(t6)
    80000018:	020fb283          	ld	t0,32(t6)
    8000001c:	028fb303          	ld	t1,40(t6)
    80000020:	030fb383          	ld	t2,48(t6)
    80000024:	038fb403          	ld	s0,56(t6)
    80000028:	040fb483          	ld	s1,64(t6)
    8000002c:	048fb503          	ld	a0,72(t6)
    80000030:	050fb583          	ld	a1,80(t6)
    80000034:	058fb603          	ld	a2,88(t6)
    80000038:	060fb683          	ld	a3,96(t6)
    8000003c:	068fb703          	ld	a4,104(t6)
    80000040:	070fb783          	ld	a5,112(t6)
    80000044:	078fb803          	ld	a6,120(t6)
    80000048:	080fb883          	ld	a7,128(t6)
    8000004c:	088fb903          	ld	s2,136(t6)
    80000050:	090fb983          	ld	s3,144(t6)
    80000054:	098fba03          	ld	s4,152(t6)
    80000058:	0a0fba83          	ld	s5,160(t6)
    8000005c:	0a8fbb03          	ld	s6,168(t6)
    80000060:	0b0fbb83          	ld	s7,176(t6)
    80000064:	0b8fbc03          	ld	s8,184(t6)
    80000068:	0c0fbc83          	ld	s9,192(t6)
    8000006c:	0c8fbd03          	ld	s10,200(t6)
    80000070:	0d0fbd83          	ld	s11,208(t6)
    80000074:	0d8fbe03          	ld	t3,216(t6)
    80000078:	0e0fbe83          	ld	t4,224(t6)
    8000007c:	0e8fbf03          	ld	t5,232(t6)
    80000080:	0f0fbf83          	ld	t6,240(t6)
    80000084:	a06d                	j	8000012e <reset_vector>

0000000080000086 <init_freg>:
    80000086:	00020f97          	auipc	t6,0x20
    8000008a:	f7af8f93          	addi	t6,t6,-134 # 80020000 <_random_data1>
    8000008e:	000fa007          	flw	ft0,0(t6)
    80000092:	008fa087          	flw	ft1,8(t6)
    80000096:	010fa107          	flw	ft2,16(t6)
    8000009a:	018fb187          	fld	ft3,24(t6)
    8000009e:	020fb207          	fld	ft4,32(t6)
    800000a2:	028fb287          	fld	ft5,40(t6)
    800000a6:	030fb307          	fld	ft6,48(t6)
    800000aa:	038fa387          	flw	ft7,56(t6)
    800000ae:	040fb407          	fld	fs0,64(t6)
    800000b2:	048fb487          	fld	fs1,72(t6)
    800000b6:	050fa507          	flw	fa0,80(t6)
    800000ba:	058fb587          	fld	fa1,88(t6)
    800000be:	060fb607          	fld	fa2,96(t6)
    800000c2:	068fb687          	fld	fa3,104(t6)
    800000c6:	070fa707          	flw	fa4,112(t6)
    800000ca:	078fb787          	fld	fa5,120(t6)
    800000ce:	080fb807          	fld	fa6,128(t6)
    800000d2:	088fa887          	flw	fa7,136(t6)
    800000d6:	090fa907          	flw	fs2,144(t6)
    800000da:	098fa987          	flw	fs3,152(t6)
    800000de:	0a0fba07          	fld	fs4,160(t6)
    800000e2:	0a8faa87          	flw	fs5,168(t6)
    800000e6:	0b0fbb07          	fld	fs6,176(t6)
    800000ea:	0b8fbb87          	fld	fs7,184(t6)
    800000ee:	0c0fbc07          	fld	fs8,192(t6)
    800000f2:	0c8fbc87          	fld	fs9,200(t6)
    800000f6:	0d0fbd07          	fld	fs10,208(t6)
    800000fa:	0d8fbd87          	fld	fs11,216(t6)
    800000fe:	0e0fbe07          	fld	ft8,224(t6)
    80000102:	0e8fae87          	flw	ft9,232(t6)
    80000106:	0f0faf07          	flw	ft10,240(t6)
    8000010a:	0f8faf87          	flw	ft11,248(t6)
    8000010e:	8082                	ret

0000000080000110 <trap_stvec>:
    80000110:	14102373          	csrr	t1,sepc
    80000114:	0311                	addi	t1,t1,4
    80000116:	14131073          	csrw	sepc,t1
    8000011a:	10200073          	sret
    8000011e:	0001                	nop

0000000080000120 <_end_trap>:
    80000120:	34102373          	csrr	t1,mepc
    80000124:	0311                	addi	t1,t1,4
    80000126:	34131073          	csrw	mepc,t1
    8000012a:	30200073          	mret

000000008000012e <reset_vector>:
    8000012e:	30005073          	csrwi	mstatus,0
    80000132:	f1402573          	csrr	a0,mhartid
    80000136:	e101                	bnez	a0,80000136 <reset_vector+0x8>
    80000138:	00000297          	auipc	t0,0x0
    8000013c:	01828293          	addi	t0,t0,24 # 80000150 <reset_vector+0x22>
    80000140:	30529073          	csrw	mtvec,t0
    80000144:	30205073          	csrwi	medeleg,0
    80000148:	30305073          	csrwi	mideleg,0
    8000014c:	30405073          	csrwi	mie,0
    80000150:	00000297          	auipc	t0,0x0
    80000154:	01028293          	addi	t0,t0,16 # 80000160 <reset_vector+0x32>
    80000158:	30529073          	csrw	mtvec,t0
    8000015c:	18005073          	csrwi	satp,0
    80000160:	00000297          	auipc	t0,0x0
    80000164:	02028293          	addi	t0,t0,32 # 80000180 <reset_vector+0x52>
    80000168:	30529073          	csrw	mtvec,t0
    8000016c:	0010029b          	addiw	t0,zero,1
    80000170:	12d6                	slli	t0,t0,0x35
    80000172:	12fd                	addi	t0,t0,-1
    80000174:	3b029073          	csrw	pmpaddr0,t0
    80000178:	42fd                	li	t0,31
    8000017a:	3a029073          	csrw	pmpcfg0,t0
    8000017e:	0001                	nop
    80000180:	00000297          	auipc	t0,0x0
    80000184:	fa028293          	addi	t0,t0,-96 # 80000120 <_end_trap>
    80000188:	30529073          	csrw	mtvec,t0
    8000018c:	4181                	li	gp,0
    8000018e:	4505                	li	a0,1
    80000190:	057e                	slli	a0,a0,0x1f
    80000192:	00055a63          	bgez	a0,800001a6 <reset_vector+0x78>
    80000196:	0ff0000f          	fence
    8000019a:	4185                	li	gp,1
    8000019c:	05d00893          	li	a7,93
    800001a0:	4501                	li	a0,0
    800001a2:	00000073          	ecall
    800001a6:	00000297          	auipc	t0,0x0
    800001aa:	f6a28293          	addi	t0,t0,-150 # 80000110 <trap_stvec>
    800001ae:	10529073          	csrw	stvec,t0
    800001b2:	62ad                	lui	t0,0xb
    800001b4:	1092829b          	addiw	t0,t0,265 # b109 <_start-0x7fff4ef7>
    800001b8:	3022a073          	csrs	medeleg,t0
    800001bc:	6521                	lui	a0,0x8
    800001be:	8005051b          	addiw	a0,a0,-2048 # 7800 <_start-0x7fff8800>
    800001c2:	30052073          	csrs	mstatus,a0
    800001c6:	00305073          	csrwi	fcsr,0
    800001ca:	ebdff0ef          	jal	80000086 <init_freg>
    800001ce:	b0201073          	csrw	minstret,zero
    800001d2:	f1402573          	csrr	a0,mhartid
    800001d6:	00000297          	auipc	t0,0x0
    800001da:	02a28293          	addi	t0,t0,42 # 80000200 <_end_prefix>
    800001de:	34129073          	csrw	mepc,t0
    800001e2:	4281                	li	t0,0
    800001e4:	30200073          	mret
    800001e8:	00000013          	nop
    800001ec:	00000013          	nop
    800001f0:	00000013          	nop
    800001f4:	00000013          	nop
    800001f8:	00000013          	nop
    800001fc:	00000013          	nop

0000000080000200 <_end_prefix>:
    80000200:	28cf12d3          	fmax.s	ft5,ft10,fa2

0000000080000204 <_l1>:
    80000204:	00010897          	auipc	a7,0x10
    80000208:	e8c88893          	addi	a7,a7,-372 # 80010090 <d_0_7>
    8000020c:	0048a607          	flw	fa2,4(a7)

0000000080000210 <_l2>:
    80000210:	30005073          	csrwi	mstatus,0
    80000214:	7a1362f3          	csrrsi	t0,tdata1,6

0000000080000218 <_l3>:
    80000218:	00030497          	auipc	s1,0x30
    8000021c:	f3848493          	addi	s1,s1,-200 # 80030150 <d_2_19>
    80000220:	0044bc23          	sd	tp,24(s1)

0000000080000224 <_l4>:
    80000224:	293f00d3          	fmin.s	ft1,ft10,fs3

0000000080000228 <_l5>:
    80000228:	555ca713          	slti	a4,s9,1365

000000008000022c <_l6>:
    8000022c:	ffca7e37          	lui	t3,0xffca7
    80000230:	d2de0e1b          	addiw	t3,t3,-723 # ffffffffffca6d2d <_end+0xffffffff7fc46b2d>
    80000234:	0e32                	slli	t3,t3,0xc
    80000236:	72fe0e13          	addi	t3,t3,1839
    8000023a:	0e3a                	slli	t3,t3,0xe
    8000023c:	8ade0e13          	addi	t3,t3,-1875
    80000240:	0e36                	slli	t3,t3,0xd
    80000242:	6d3e0e13          	addi	t3,t3,1747
    80000246:	7a5e2e73          	csrrs	t3,tcontrol,t3
    8000024a:	8f72                	mv	t5,t3

000000008000024c <_l7>:
    8000024c:	00050f17          	auipc	t5,0x50
    80000250:	dd4f0f13          	addi	t5,t5,-556 # 80050020 <d_4_0>
    80000254:	00af2427          	fsw	fa0,8(t5)

0000000080000258 <_l8>:
    80000258:	00040c97          	auipc	s9,0x40
    8000025c:	e88c8c93          	addi	s9,s9,-376 # 800400e0 <d_3_12>
    80000260:	ffe00db7          	lui	s11,0xffe00
    80000264:	01bcccb3          	xor	s9,s9,s11
    80000268:	ff5c80a3          	sb	s5,-31(s9)

000000008000026c <_l9>:
    8000026c:	00020717          	auipc	a4,0x20
    80000270:	de470713          	addi	a4,a4,-540 # 80020050 <d_1_3>
    80000274:	0741                	addi	a4,a4,16
    80000276:	c19734af          	amominu.d	s1,s9,(a4)

000000008000027a <_l10>:
    8000027a:	c00d0a53          	fcvt.w.s	s4,fs10,rne

000000008000027e <_l11>:
    8000027e:	005423b7          	lui	t2,0x542
    80000282:	2473839b          	addiw	t2,t2,583 # 542247 <_start-0x7fabddb9>
    80000286:	03b6                	slli	t2,t2,0xd
    80000288:	2b338393          	addi	t2,t2,691
    8000028c:	03b2                	slli	t2,t2,0xc
    8000028e:	58138393          	addi	t2,t2,1409
    80000292:	03b6                	slli	t2,t2,0xd
    80000294:	2d238393          	addi	t2,t2,722
    80000298:	f153af73          	csrrs	t5,0xf15,t2
    8000029c:	c07a                	sw	t5,0(sp)

000000008000029e <_l12>:
    8000029e:	0040af37          	lui	t5,0x40a
    800002a2:	ce3f0f1b          	addiw	t5,t5,-797 # 409ce3 <_start-0x7fbf631d>
    800002a6:	0f32                	slli	t5,t5,0xc
    800002a8:	6bbf0f13          	addi	t5,t5,1723
    800002ac:	0f3a                	slli	t5,t5,0xe
    800002ae:	e7ff0f13          	addi	t5,t5,-385
    800002b2:	0f3a                	slli	t5,t5,0xe
    800002b4:	7e2f0f13          	addi	t5,t5,2018
    800002b8:	255f13f3          	csrrw	t2,vsireg4,t5
    800002bc:	8e9e                	mv	t4,t2

00000000800002be <_l13>:
    800002be:	07738463          	beq	t2,s7,80000326 <_l22>

00000000800002c2 <_l14>:
    800002c2:	7a87e2f3          	csrrsi	t0,mcontext,15
    800002c6:	8d96                	mv	s11,t0

00000000800002c8 <_l15>:
    800002c8:	00050997          	auipc	s3,0x50
    800002cc:	e6898993          	addi	s3,s3,-408 # 80050130 <d_4_17>
    800002d0:	09e1                	addi	s3,s3,24
    800002d2:	ffe00bb7          	lui	s7,0xffe00
    800002d6:	0179c9b3          	xor	s3,s3,s7
    800002da:	2179bdaf          	amoxor.d	s11,s7,(s3)

00000000800002de <_l16>:
    800002de:	00030497          	auipc	s1,0x30
    800002e2:	e4248493          	addi	s1,s1,-446 # 80030120 <d_2_16>
    800002e6:	04c1                	addi	s1,s1,16
    800002e8:	09c4bc2f          	amoswap.d	s8,t3,(s1)

00000000800002ec <_l17>:
    800002ec:	7a35de73          	csrrwi	t3,tdata3,11
    800002f0:	8172                	mv	sp,t3

00000000800002f2 <_l18>:
    800002f2:	35316ff3          	csrrsi	t6,mireg3,2
    800002f6:	847e                	mv	s0,t6

00000000800002f8 <_l19>:
    800002f8:	0bc00b6f          	jal	s6,800003b4 <_l38>

00000000800002fc <_l20>:
    800002fc:	4e05                	li	t3,1
    800002fe:	104e1e73          	csrrw	t3,sie,t3
    80000302:	8a72                	mv	s4,t3
    80000304:	c072                	sw	t3,0(sp)

0000000080000306 <_l21>:
    80000306:	ff284f37          	lui	t5,0xff284
    8000030a:	9bdf0f1b          	addiw	t5,t5,-1603 # ffffffffff2839bd <_end+0xffffffff7f2237bd>
    8000030e:	0f32                	slli	t5,t5,0xc
    80000310:	a1ff0f13          	addi	t5,t5,-1505
    80000314:	0f36                	slli	t5,t5,0xd
    80000316:	b5bf0f13          	addi	t5,t5,-1189
    8000031a:	0f36                	slli	t5,t5,0xd
    8000031c:	720f0f13          	addi	t5,t5,1824
    80000320:	342f3ff3          	csrrc	t6,mcause,t5
    80000324:	8dfe                	mv	s11,t6

0000000080000326 <_l22>:
    80000326:	0153803b          	addw	zero,t2,s5

000000008000032a <_l23>:
    8000032a:	190e4563          	blt	t3,a6,800004b4 <_l61>

000000008000032e <_l24>:
    8000032e:	f00886d3          	fmv.w.x	fa3,a7

0000000080000332 <_l25>:
    80000332:	01fd6a13          	ori	s4,s10,31

0000000080000336 <_l26>:
    80000336:	f00583d3          	fmv.w.x	ft7,a1

000000008000033a <_l27>:
    8000033a:	c736f613          	andi	a2,a3,-909

000000008000033e <_l28>:
    8000033e:	00060217          	auipc	tp,0x60
    80000342:	dc220213          	addi	tp,tp,-574 # 80060100 <d_5_14>
    80000346:	1271                	addi	tp,tp,-4 # fffffffffffffffc <_end+0xffffffff7ff9fdfc>
    80000348:	ffe00537          	lui	a0,0xffe00
    8000034c:	00a24233          	xor	tp,tp,a0
    80000350:	00a2292f          	amoadd.w	s2,a0,(tp)

0000000080000354 <_l29>:
    80000354:	00000293          	li	t0,0
    80000358:	35329ff3          	csrrw	t6,mireg3,t0
    8000035c:	8ffe                	mv	t6,t6
    8000035e:	c07e                	sw	t6,0(sp)

0000000080000360 <_l30>:
    80000360:	00010117          	auipc	sp,0x10
    80000364:	cf010113          	addi	sp,sp,-784 # 80010050 <d_0_3>
    80000368:	1161                	addi	sp,sp,-8
    8000036a:	00d1262f          	amoadd.w	a2,a3,(sp)

000000008000036e <_l31>:
    8000036e:	00000697          	auipc	a3,0x0
    80000372:	1e468693          	addi	a3,a3,484 # 80000552 <_l82>
    80000376:	14169073          	csrw	sepc,a3
    8000037a:	10200073          	sret

000000008000037e <_l32>:
    8000037e:	e0081253          	fclass.s	tp,fa6

0000000080000382 <_l33>:
    80000382:	5a89d3f3          	csrrwi	t2,scontext,19
    80000386:	8b9e                	mv	s7,t2
    80000388:	c01e                	sw	t2,0(sp)

000000008000038a <_l34>:
    8000038a:	c0018153          	fcvt.w.s	sp,ft3,rne

000000008000038e <_l35>:
    8000038e:	00040c17          	auipc	s8,0x40
    80000392:	e22c0c13          	addi	s8,s8,-478 # 800401b0 <d_3_25>
    80000396:	1c41                	addi	s8,s8,-16
    80000398:	c13c3daf          	amominu.d	s11,s3,(s8)

000000008000039c <_l36>:
    8000039c:	00060297          	auipc	t0,0x60
    800003a0:	d9428293          	addi	t0,t0,-620 # 80060130 <d_5_17>
    800003a4:	ffe00e37          	lui	t3,0xffe00
    800003a8:	01c2c2b3          	xor	t0,t0,t3
    800003ac:	00f2ac23          	sw	a5,24(t0)

00000000800003b0 <_l37>:
    800003b0:	7a0df373          	csrrci	t1,tselect,27

00000000800003b4 <_l38>:
    800003b4:	21511153          	fsgnjn.s	ft2,ft2,fs5

00000000800003b8 <_l39>:
    800003b8:	c0008753          	fcvt.w.s	a4,ft1,rne

00000000800003bc <_l40>:
    800003bc:	00060517          	auipc	a0,0x60
    800003c0:	c8450513          	addi	a0,a0,-892 # 80060040 <d_5_2>
    800003c4:	00452007          	flw	ft0,4(a0)

00000000800003c8 <_l41>:
    800003c8:	41085dbb          	sraw	s11,a6,a6

00000000800003cc <_l42>:
    800003cc:	00000f93          	li	t6,0
    800003d0:	151faef3          	csrrs	t4,sireg,t6
    800003d4:	89f6                	mv	s3,t4

00000000800003d6 <_l43>:
    800003d6:	00000897          	auipc	a7,0x0
    800003da:	15688893          	addi	a7,a7,342 # 8000052c <_l73>
    800003de:	fea89a83          	lh	s5,-22(a7)

00000000800003e2 <_l44>:
    800003e2:	01db863b          	addw	a2,s7,t4

00000000800003e6 <_l45>:
    800003e6:	00040517          	auipc	a0,0x40
    800003ea:	dba50513          	addi	a0,a0,-582 # 800401a0 <d_3_24>
    800003ee:	1521                	addi	a0,a0,-24
    800003f0:	100536af          	lr.d	a3,(a0)

00000000800003f4 <_l46>:
    800003f4:	fd181f37          	lui	t5,0xfd181
    800003f8:	5d5f0f1b          	addiw	t5,t5,1493 # fffffffffd1815d5 <_end+0xffffffff7d1213d5>
    800003fc:	0f32                	slli	t5,t5,0xc
    800003fe:	509f0f13          	addi	t5,t5,1289
    80000402:	0f36                	slli	t5,t5,0xd
    80000404:	4f3f0f13          	addi	t5,t5,1267
    80000408:	0f32                	slli	t5,t5,0xc
    8000040a:	6a7f0f13          	addi	t5,t5,1703
    8000040e:	7aaf13f3          	csrrw	t2,mscontext,t5

0000000080000412 <_l47>:
    80000412:	01f085d3          	fadd.s	fa1,ft1,ft11,rne

0000000080000416 <_l48>:
    80000416:	017d061b          	addiw	a2,s10,23

000000008000041a <_l49>:
    8000041a:	11961f63          	bne	a2,s9,80000538 <_l76>

000000008000041e <_l50>:
    8000041e:	00030c17          	auipc	s8,0x30
    80000422:	db2c0c13          	addi	s8,s8,-590 # 800301d0 <d_2_27>
    80000426:	0c41                	addi	s8,s8,16
    80000428:	40bc3f2f          	amoor.d	t5,a1,(s8)

000000008000042c <_l51>:
    8000042c:	ff110eb7          	lui	t4,0xff110
    80000430:	bbde8e9b          	addiw	t4,t4,-1091 # ffffffffff10fbbd <_end+0xffffffff7f0af9bd>
    80000434:	0eb6                	slli	t4,t4,0xd
    80000436:	9b1e8e93          	addi	t4,t4,-1615
    8000043a:	0eba                	slli	t4,t4,0xe
    8000043c:	b07e8e93          	addi	t4,t4,-1273
    80000440:	0eb2                	slli	t4,t4,0xc
    80000442:	5f1e8e93          	addi	t4,t4,1521
    80000446:	251ea2f3          	csrrs	t0,vsireg,t4
    8000044a:	8c16                	mv	s8,t0

000000008000044c <_l52>:
    8000044c:	30005073          	csrwi	mstatus,0
    80000450:	fff01e37          	lui	t3,0xfff01
    80000454:	805e0e1b          	addiw	t3,t3,-2043 # fffffffffff00805 <_end+0xffffffff7fea0605>
    80000458:	0e46                	slli	t3,t3,0x11
    8000045a:	84fe0e13          	addi	t3,t3,-1969
    8000045e:	0e32                	slli	t3,t3,0xc
    80000460:	fb9e0e13          	addi	t3,t3,-71
    80000464:	0e36                	slli	t3,t3,0xd
    80000466:	bf3e0e13          	addi	t3,t3,-1037
    8000046a:	001e2f73          	csrrs	t5,fflags,t3
    8000046e:	827a                	mv	tp,t5
    80000470:	c07a                	sw	t5,0(sp)

0000000080000472 <_l53>:
    80000472:	218b0cd3          	fsgnj.s	fs9,fs6,fs8

0000000080000476 <_l54>:
    80000476:	10618053          	fmul.s	ft0,ft3,ft6,rne

000000008000047a <_l55>:
    8000047a:	00030897          	auipc	a7,0x30
    8000047e:	cd688893          	addi	a7,a7,-810 # 80030150 <d_2_19>
    80000482:	0008be03          	ld	t3,0(a7)

0000000080000486 <_l56>:
    80000486:	00060897          	auipc	a7,0x60
    8000048a:	bfa88893          	addi	a7,a7,-1030 # 80060080 <d_5_6>
    8000048e:	0108d383          	lhu	t2,16(a7)

0000000080000492 <_l57>:
    80000492:	00040d97          	auipc	s11,0x40
    80000496:	d2ed8d93          	addi	s11,s11,-722 # 800401c0 <d_3_26>
    8000049a:	01cda707          	flw	fa4,28(s11)

000000008000049e <_l58>:
    8000049e:	48cc0fcf          	fnmadd.s	ft11,fs8,fa2,fs1,rne

00000000800004a2 <_l59>:
    800004a2:	00020697          	auipc	a3,0x20
    800004a6:	cde68693          	addi	a3,a3,-802 # 80020180 <d_1_22>
    800004aa:	00568903          	lb	s2,5(a3)

00000000800004ae <_l60>:
    800004ae:	7a036e73          	csrrsi	t3,tselect,6
    800004b2:	80f2                	mv	ra,t3

00000000800004b4 <_l61>:
    800004b4:	0187fe93          	andi	t4,a5,24

00000000800004b8 <_l62>:
    800004b8:	fb5d2593          	slti	a1,s10,-75

00000000800004bc <_l63>:
    800004bc:	00000117          	auipc	sp,0x0
    800004c0:	13c10113          	addi	sp,sp,316 # 800005f8 <_l97>
    800004c4:	14111073          	csrw	sepc,sp
    800004c8:	10200073          	sret

00000000800004cc <_l64>:
    800004cc:	fe2b3e37          	lui	t3,0xfe2b3
    800004d0:	c03e0e1b          	addiw	t3,t3,-1021 # fffffffffe2b2c03 <_end+0xffffffff7e252a03>
    800004d4:	0e36                	slli	t3,t3,0xd
    800004d6:	d7fe0e13          	addi	t3,t3,-641
    800004da:	0e36                	slli	t3,t3,0xd
    800004dc:	10de0e13          	addi	t3,t3,269
    800004e0:	0e32                	slli	t3,t3,0xc
    800004e2:	e2be0e13          	addi	t3,t3,-469
    800004e6:	001e2ff3          	csrrs	t6,fflags,t3
    800004ea:	897e                	mv	s2,t6

00000000800004ec <_l65>:
    800004ec:	00ea5337          	lui	t1,0xea5
    800004f0:	ad33031b          	addiw	t1,t1,-1325 # ea4ad3 <_start-0x7f15b52d>
    800004f4:	0332                	slli	t1,t1,0xc
    800004f6:	036d                	addi	t1,t1,27
    800004f8:	0332                	slli	t1,t1,0xc
    800004fa:	76330313          	addi	t1,t1,1891
    800004fe:	0332                	slli	t1,t1,0xc
    80000500:	80c30313          	addi	t1,t1,-2036
    80000504:	32231373          	csrrw	t1,minstretcfg,t1
    80000508:	8c1a                	mv	s8,t1
    8000050a:	c01a                	sw	t1,0(sp)

000000008000050c <_l66>:
    8000050c:	00a9541b          	srliw	s0,s2,0xa

0000000080000510 <_l67>:
    80000510:	e00108d3          	fmv.x.w	a7,ft2

0000000080000514 <_l68>:
    80000514:	05c002ef          	jal	t0,80000570 <_l85>

0000000080000518 <_l69>:
    80000518:	d03e8d53          	fcvt.s.lu	fs10,t4,rne

000000008000051c <_l70>:
    8000051c:	7b14e2f3          	csrrsi	t0,dpc,9

0000000080000520 <_l71>:
    80000520:	53fd                	li	t2,-1
    80000522:	7a03b2f3          	csrrc	t0,tselect,t2
    80000526:	8816                	mv	a6,t0

0000000080000528 <_l72>:
    80000528:	7ffe8d93          	addi	s11,t4,2047

000000008000052c <_l73>:
    8000052c:	41a382bb          	subw	t0,t2,s10

0000000080000530 <_l74>:
    80000530:	344f92f3          	csrrw	t0,mip,t6

0000000080000534 <_l75>:
    80000534:	a0532953          	feq.s	s2,ft6,ft5

0000000080000538 <_l76>:
    80000538:	c0048253          	fcvt.w.s	tp,fs1,rne

000000008000053c <_l77>:
    8000053c:	6a8eae73          	csrrs	t3,hcontext,t4

0000000080000540 <_l78>:
    80000540:	e3b0b297          	auipc	t0,0xe3b0b

0000000080000544 <_l79>:
    80000544:	1504eff3          	csrrsi	t6,siselect,9
    80000548:	8dfe                	mv	s11,t6

000000008000054a <_l80>:
    8000054a:	215592d3          	fsgnjn.s	ft5,fa1,fs5

000000008000054e <_l81>:
    8000054e:	d0028353          	fcvt.s.w	ft6,t0,rne

0000000080000552 <_l82>:
    80000552:	30005073          	csrwi	mstatus,0
    80000556:	5a8be373          	csrrsi	t1,scontext,23
    8000055a:	879a                	mv	a5,t1
    8000055c:	c01a                	sw	t1,0(sp)

000000008000055e <_l83>:
    8000055e:	255b52f3          	csrrwi	t0,vsireg4,22
    80000562:	8716                	mv	a4,t0

0000000080000564 <_l84>:
    80000564:	00040a97          	auipc	s5,0x40
    80000568:	bfca8a93          	addi	s5,s5,-1028 # 80040160 <d_3_20>
    8000056c:	000aea03          	lwu	s4,0(s5)

0000000080000570 <_l85>:
    80000570:	ffc7a3b7          	lui	t2,0xffc7a
    80000574:	e0b3839b          	addiw	t2,t2,-501 # ffffffffffc79e0b <_end+0xffffffff7fc19c0b>
    80000578:	03b6                	slli	t2,t2,0xd
    8000057a:	76338393          	addi	t2,t2,1891
    8000057e:	03ba                	slli	t2,t2,0xe
    80000580:	91138393          	addi	t2,t2,-1775
    80000584:	03b2                	slli	t2,t2,0xc
    80000586:	30238393          	addi	t2,t2,770
    8000058a:	722393f3          	csrrw	t2,minstretcfgh,t2
    8000058e:	831e                	mv	t1,t2

0000000080000590 <_l86>:
    80000590:	00000617          	auipc	a2,0x0
    80000594:	06860613          	addi	a2,a2,104 # 800005f8 <_l97>
    80000598:	34161073          	csrw	mepc,a2
    8000059c:	30200073          	mret

00000000800005a0 <_l87>:
    800005a0:	011014bb          	sllw	s1,zero,a7

00000000800005a4 <_l88>:
    800005a4:	c0118ed3          	fcvt.wu.s	t4,ft3,rne

00000000800005a8 <_l89>:
    800005a8:	03f35d93          	srli	s11,t1,0x3f

00000000800005ac <_l90>:
    800005ac:	00030f17          	auipc	t5,0x30
    800005b0:	ad4f0f13          	addi	t5,t5,-1324 # 80030080 <d_2_6>
    800005b4:	8f7a                	mv	t5,t5
    800005b6:	100f31af          	lr.d	gp,(t5)

00000000800005ba <_l91>:
    800005ba:	30005073          	csrwi	mstatus,0
    800005be:	30405073          	csrwi	mie,0
    800005c2:	7a8353f3          	csrrwi	t2,mcontext,6
    800005c6:	871e                	mv	a4,t2
    800005c8:	c01e                	sw	t2,0(sp)

00000000800005ca <_l92>:
    800005ca:	00040597          	auipc	a1,0x40
    800005ce:	b2658593          	addi	a1,a1,-1242 # 800400f0 <d_3_13>
    800005d2:	ff05b903          	ld	s2,-16(a1)

00000000800005d6 <_l93>:
    800005d6:	7b11fe73          	csrrci	t3,dpc,3

00000000800005da <_l94>:
    800005da:	206110d3          	fsgnjn.s	ft1,ft2,ft6

00000000800005de <_l95>:
    800005de:	00040e17          	auipc	t3,0x40
    800005e2:	ad2e0e13          	addi	t3,t3,-1326 # 800400b0 <d_3_9>
    800005e6:	0e21                	addi	t3,t3,8
    800005e8:	e0fe3f2f          	amomaxu.d	t5,a5,(t3)

00000000800005ec <_l96>:
    800005ec:	00030717          	auipc	a4,0x30
    800005f0:	bb470713          	addi	a4,a4,-1100 # 800301a0 <d_2_24>
    800005f4:	ffa74503          	lbu	a0,-6(a4)

00000000800005f8 <_l97>:
    800005f8:	ffd74337          	lui	t1,0xffd74
    800005fc:	ab33031b          	addiw	t1,t1,-1357 # ffffffffffd73ab3 <_end+0xffffffff7fd138b3>
    80000600:	0332                	slli	t1,t1,0xc
    80000602:	e8d30313          	addi	t1,t1,-371
    80000606:	0346                	slli	t1,t1,0x11
    80000608:	dbd30313          	addi	t1,t1,-579
    8000060c:	0332                	slli	t1,t1,0xc
    8000060e:	ef730313          	addi	t1,t1,-265
    80000612:	7a4333f3          	csrrc	t2,tinfo,t1
    80000616:	c01e                	sw	t2,0(sp)

0000000080000618 <_l98>:
    80000618:	0000100f          	fence.i

000000008000061c <_l99>:
    8000061c:	20300bd3          	fsgnj.s	fs7,ft0,ft3

0000000080000620 <_good_exit>:
    80000620:	00002097          	auipc	ra,0x2
    80000624:	be008093          	addi	ra,ra,-1056 # 80002200 <csr_output_data>
    80000628:	10002173          	csrr	sp,sstatus
    8000062c:	0420bc23          	sd	sp,88(ra)
    80000630:	10402173          	csrr	sp,sie
    80000634:	0620b823          	sd	sp,112(ra)
    80000638:	10502173          	csrr	sp,stvec
    8000063c:	0620bc23          	sd	sp,120(ra)
    80000640:	10602173          	csrr	sp,scounteren
    80000644:	0820b023          	sd	sp,128(ra)
    80000648:	14002173          	csrr	sp,sscratch
    8000064c:	0820b423          	sd	sp,136(ra)
    80000650:	14102173          	csrr	sp,sepc
    80000654:	0820b823          	sd	sp,144(ra)
    80000658:	14202173          	csrr	sp,scause
    8000065c:	0820bc23          	sd	sp,152(ra)
    80000660:	14302173          	csrr	sp,stval
    80000664:	0a20b023          	sd	sp,160(ra)
    80000668:	14402173          	csrr	sp,sip
    8000066c:	f7f17113          	andi	sp,sp,-129
    80000670:	0a20b423          	sd	sp,168(ra)
    80000674:	18002173          	csrr	sp,satp
    80000678:	0a20b823          	sd	sp,176(ra)
    8000067c:	f1402173          	csrr	sp,mhartid
    80000680:	0a20bc23          	sd	sp,184(ra)
    80000684:	30002173          	csrr	sp,mstatus
    80000688:	0c20b023          	sd	sp,192(ra)
    8000068c:	30202173          	csrr	sp,medeleg
    80000690:	0c20b423          	sd	sp,200(ra)
    80000694:	30302173          	csrr	sp,mideleg
    80000698:	0c20b823          	sd	sp,208(ra)
    8000069c:	30402173          	csrr	sp,mie
    800006a0:	0c20bc23          	sd	sp,216(ra)
    800006a4:	30502173          	csrr	sp,mtvec
    800006a8:	0e20b023          	sd	sp,224(ra)
    800006ac:	30602173          	csrr	sp,mcounteren
    800006b0:	0e20b423          	sd	sp,232(ra)
    800006b4:	34002173          	csrr	sp,mscratch
    800006b8:	0e20b823          	sd	sp,240(ra)
    800006bc:	34102173          	csrr	sp,mepc
    800006c0:	0e20bc23          	sd	sp,248(ra)
    800006c4:	34202173          	csrr	sp,mcause
    800006c8:	1020b023          	sd	sp,256(ra)
    800006cc:	34302173          	csrr	sp,mtval
    800006d0:	1020b423          	sd	sp,264(ra)
    800006d4:	34402173          	csrr	sp,mip
    800006d8:	f7f17113          	andi	sp,sp,-129
    800006dc:	1020b823          	sd	sp,272(ra)
    800006e0:	3a002173          	csrr	sp,pmpcfg0
    800006e4:	1020bc23          	sd	sp,280(ra)
    800006e8:	3b002173          	csrr	sp,pmpaddr0
    800006ec:	1220bc23          	sd	sp,312(ra)
    800006f0:	3b102173          	csrr	sp,pmpaddr1
    800006f4:	1420b023          	sd	sp,320(ra)
    800006f8:	3b202173          	csrr	sp,pmpaddr2
    800006fc:	1420b423          	sd	sp,328(ra)
    80000700:	3b302173          	csrr	sp,pmpaddr3
    80000704:	1420b823          	sd	sp,336(ra)
    80000708:	3b402173          	csrr	sp,pmpaddr4
    8000070c:	1420bc23          	sd	sp,344(ra)
    80000710:	3b502173          	csrr	sp,pmpaddr5
    80000714:	1620b023          	sd	sp,352(ra)
    80000718:	3b602173          	csrr	sp,pmpaddr6
    8000071c:	1620b423          	sd	sp,360(ra)
    80000720:	3b702173          	csrr	sp,pmpaddr7
    80000724:	1620b823          	sd	sp,368(ra)
    80000728:	6519                	lui	a0,0x6
    8000072a:	30052073          	csrs	mstatus,a0

000000008000072e <fcsrs_dump>:
    8000072e:	00102173          	frflags	sp
    80000732:	0420b023          	sd	sp,64(ra)
    80000736:	00202173          	frrm	sp
    8000073a:	0420b423          	sd	sp,72(ra)
    8000073e:	00302173          	frcsr	sp
    80000742:	0420b823          	sd	sp,80(ra)

0000000080000746 <reg_dump>:
    80000746:	00002097          	auipc	ra,0x2
    8000074a:	8ba08093          	addi	ra,ra,-1862 # 80002000 <begin_signature>
    8000074e:	0000b023          	sd	zero,0(ra)
    80000752:	0020b823          	sd	sp,16(ra)
    80000756:	0030bc23          	sd	gp,24(ra)
    8000075a:	0240b023          	sd	tp,32(ra)
    8000075e:	0250b423          	sd	t0,40(ra)
    80000762:	0260b823          	sd	t1,48(ra)
    80000766:	0270bc23          	sd	t2,56(ra)
    8000076a:	0480b023          	sd	s0,64(ra)
    8000076e:	0490b423          	sd	s1,72(ra)
    80000772:	04a0b823          	sd	a0,80(ra)
    80000776:	04b0bc23          	sd	a1,88(ra)
    8000077a:	06c0b023          	sd	a2,96(ra)
    8000077e:	06d0b423          	sd	a3,104(ra)
    80000782:	06e0b823          	sd	a4,112(ra)
    80000786:	06f0bc23          	sd	a5,120(ra)
    8000078a:	0900b023          	sd	a6,128(ra)
    8000078e:	0910b423          	sd	a7,136(ra)
    80000792:	0920b823          	sd	s2,144(ra)
    80000796:	0930bc23          	sd	s3,152(ra)
    8000079a:	0b40b023          	sd	s4,160(ra)
    8000079e:	0b50b423          	sd	s5,168(ra)
    800007a2:	0b60b823          	sd	s6,176(ra)
    800007a6:	0b70bc23          	sd	s7,184(ra)
    800007aa:	0d80b023          	sd	s8,192(ra)
    800007ae:	0d90b423          	sd	s9,200(ra)
    800007b2:	0db0bc23          	sd	s11,216(ra)
    800007b6:	0fc0b023          	sd	t3,224(ra)
    800007ba:	0fd0b423          	sd	t4,232(ra)
    800007be:	0fe0b823          	sd	t5,240(ra)

00000000800007c2 <freg_dump>:
    800007c2:	00002097          	auipc	ra,0x2
    800007c6:	93e08093          	addi	ra,ra,-1730 # 80002100 <freg_output_data>
    800007ca:	0010a427          	fsw	ft1,8(ra)
    800007ce:	0020a827          	fsw	ft2,16(ra)
    800007d2:	0270ac27          	fsw	ft7,56(ra)
    800007d6:	0490a427          	fsw	fs1,72(ra)
    800007da:	04a0a827          	fsw	fa0,80(ra)
    800007de:	06c0a027          	fsw	fa2,96(ra)
    800007e2:	06d0a427          	fsw	fa3,104(ra)
    800007e6:	0b50a427          	fsw	fs5,168(ra)
    800007ea:	0b60a827          	fsw	fs6,176(ra)
    800007ee:	0d90a427          	fsw	fs9,200(ra)
    800007f2:	0da0a827          	fsw	fs10,208(ra)
    800007f6:	0fc0a027          	fsw	ft8,224(ra)
    800007fa:	0fd0a427          	fsw	ft9,232(ra)
    800007fe:	0fe0a827          	fsw	ft10,240(ra)
    80000802:	0ff0ac27          	fsw	ft11,248(ra)
    80000806:	00002097          	auipc	ra,0x2
    8000080a:	8fa08093          	addi	ra,ra,-1798 # 80002100 <freg_output_data>
    8000080e:	0000b027          	fsd	ft0,0(ra)
    80000812:	0030bc27          	fsd	ft3,24(ra)
    80000816:	0240b027          	fsd	ft4,32(ra)
    8000081a:	0250b427          	fsd	ft5,40(ra)
    8000081e:	0260b827          	fsd	ft6,48(ra)
    80000822:	0480b027          	fsd	fs0,64(ra)
    80000826:	04b0bc27          	fsd	fa1,88(ra)
    8000082a:	06e0b827          	fsd	fa4,112(ra)
    8000082e:	06f0bc27          	fsd	fa5,120(ra)
    80000832:	0900b027          	fsd	fa6,128(ra)
    80000836:	0910b427          	fsd	fa7,136(ra)
    8000083a:	0920b827          	fsd	fs2,144(ra)
    8000083e:	0930bc27          	fsd	fs3,152(ra)
    80000842:	0b40b027          	fsd	fs4,160(ra)
    80000846:	0b70bc27          	fsd	fs7,184(ra)
    8000084a:	0d80b027          	fsd	fs8,192(ra)
    8000084e:	0db0bc27          	fsd	fs11,216(ra)
    80000852:	4501                	li	a0,0
    80000854:	0005006b          	.insn	4, 0x0005006b
    80000858:	4185                	li	gp,1
    8000085a:	00000f17          	auipc	t5,0x0
    8000085e:	7a3f2323          	sw	gp,1958(t5) # 80001000 <tohost>
    80000862:	a001                	j	80000862 <freg_dump+0xa0>

0000000080000864 <_end_main>:
	...
    80000874:	00000013          	nop
    80000878:	00000013          	nop
    8000087c:	00000013          	nop
    80000880:	00000013          	nop
    80000884:	00000013          	nop

Disassembly of section .tohost:

0000000080001000 <tohost>:
	...

0000000080001040 <fromhost>:
	...

Disassembly of section .data:

0000000080002000 <begin_signature>:
	...

0000000080002008 <reg_x1_output>:
	...

0000000080002010 <reg_x2_output>:
	...

0000000080002018 <reg_x3_output>:
	...

0000000080002020 <reg_x4_output>:
	...

0000000080002028 <reg_x5_output>:
	...

0000000080002030 <reg_x6_output>:
	...

0000000080002038 <reg_x7_output>:
	...

0000000080002040 <reg_x8_output>:
	...

0000000080002048 <reg_x9_output>:
	...

0000000080002050 <reg_x10_output>:
	...

0000000080002058 <reg_x11_output>:
	...

0000000080002060 <reg_x12_output>:
	...

0000000080002068 <reg_x13_output>:
	...

0000000080002070 <reg_x14_output>:
	...

0000000080002078 <reg_x15_output>:
	...

0000000080002080 <reg_x16_output>:
	...

0000000080002088 <reg_x17_output>:
	...

0000000080002090 <reg_x18_output>:
	...

0000000080002098 <reg_x19_output>:
	...

00000000800020a0 <reg_x20_output>:
	...

00000000800020a8 <reg_x21_output>:
	...

00000000800020b0 <reg_x22_output>:
	...

00000000800020b8 <reg_x23_output>:
	...

00000000800020c0 <reg_x24_output>:
	...

00000000800020c8 <reg_x25_output>:
	...

00000000800020d0 <reg_x26_output>:
	...

00000000800020d8 <reg_x27_output>:
	...

00000000800020e0 <reg_x28_output>:
	...

00000000800020e8 <reg_x29_output>:
	...

00000000800020f0 <reg_x30_output>:
	...

00000000800020f8 <reg_x31_output>:
	...

0000000080002100 <freg_output_data>:
	...

0000000080002108 <reg_f1_output>:
	...

0000000080002110 <reg_f2_output>:
	...

0000000080002118 <reg_f3_output>:
	...

0000000080002120 <reg_f4_output>:
	...

0000000080002128 <reg_f5_output>:
	...

0000000080002130 <reg_f6_output>:
	...

0000000080002138 <reg_f7_output>:
	...

0000000080002140 <reg_f8_output>:
	...

0000000080002148 <reg_f9_output>:
	...

0000000080002150 <reg_f10_output>:
	...

0000000080002158 <reg_f11_output>:
	...

0000000080002160 <reg_f12_output>:
	...

0000000080002168 <reg_f13_output>:
	...

0000000080002170 <reg_f14_output>:
	...

0000000080002178 <reg_f15_output>:
	...

0000000080002180 <reg_f16_output>:
	...

0000000080002188 <reg_f17_output>:
	...

0000000080002190 <reg_f18_output>:
	...

0000000080002198 <reg_f19_output>:
	...

00000000800021a0 <reg_f20_output>:
	...

00000000800021a8 <reg_f21_output>:
	...

00000000800021b0 <reg_f22_output>:
	...

00000000800021b8 <reg_f23_output>:
	...

00000000800021c0 <reg_f24_output>:
	...

00000000800021c8 <reg_f25_output>:
	...

00000000800021d0 <reg_f26_output>:
	...

00000000800021d8 <reg_f27_output>:
	...

00000000800021e0 <reg_f28_output>:
	...

00000000800021e8 <reg_f29_output>:
	...

00000000800021f0 <reg_f30_output>:
	...

00000000800021f8 <reg_f31_output>:
	...

0000000080002200 <csr_output_data>:
	...

0000000080002208 <uie_output>:
	...

0000000080002210 <utvec_output>:
	...

0000000080002218 <uscratch_output>:
	...

0000000080002220 <uepc_output>:
	...

0000000080002228 <ucause_output>:
	...

0000000080002230 <utval_output>:
	...

0000000080002238 <uip_output>:
	...

0000000080002240 <fflags_output>:
	...

0000000080002248 <frm_output>:
	...

0000000080002250 <fcsr_output>:
	...

0000000080002258 <sstatus_output>:
	...

0000000080002260 <sedeleg_output>:
	...

0000000080002268 <sideleg_output>:
	...

0000000080002270 <sie_output>:
	...

0000000080002278 <stvec_output>:
	...

0000000080002280 <scounteren_output>:
	...

0000000080002288 <sscratch_output>:
	...

0000000080002290 <sepc_output>:
	...

0000000080002298 <scause_output>:
	...

00000000800022a0 <stval_output>:
	...

00000000800022a8 <sip_output>:
	...

00000000800022b0 <satp_output>:
	...

00000000800022b8 <mhartid_output>:
	...

00000000800022c0 <mstatus_output>:
	...

00000000800022c8 <medeleg_output>:
	...

00000000800022d0 <mideleg_output>:
	...

00000000800022d8 <mie_output>:
	...

00000000800022e0 <mtvec_output>:
	...

00000000800022e8 <mcounteren_output>:
	...

00000000800022f0 <mscratch_output>:
	...

00000000800022f8 <mepc_output>:
	...

0000000080002300 <mcause_output>:
	...

0000000080002308 <mtval_output>:
	...

0000000080002310 <mip_output>:
	...

0000000080002318 <pmpcfg0_output>:
	...

0000000080002320 <pmpcfg1_output>:
	...

0000000080002328 <pmpcfg2_output>:
	...

0000000080002330 <pmpcfg3_output>:
	...

0000000080002338 <pmpaddr0_output>:
	...

0000000080002340 <pmpaddr1_output>:
	...

0000000080002348 <pmpaddr2_output>:
	...

0000000080002350 <pmpaddr3_output>:
	...

0000000080002358 <pmpaddr4_output>:
	...

0000000080002360 <pmpaddr5_output>:
	...

0000000080002368 <pmpaddr6_output>:
	...

0000000080002370 <pmpaddr7_output>:
	...

0000000080002378 <pmpaddr8_output>:
	...

0000000080002380 <pmpaddr9_output>:
	...

0000000080002388 <pmpaddr10_output>:
	...

0000000080002390 <pmpaddr11_output>:
	...

0000000080002398 <pmpaddr12_output>:
	...

00000000800023a0 <pmpaddr13_output>:
	...

00000000800023a8 <pmpaddr14_output>:
	...

00000000800023b0 <pmpaddr15_output>:
	...

00000000800023b8 <mcycle_output>:
	...

00000000800023c0 <minstret_output>:
	...

00000000800023c8 <mcycleh_output>:
	...

00000000800023d0 <minstreth_output>:
	...

Disassembly of section .data.random0:

0000000080010000 <_random_data0>:
    80010000:	67e7e60b          	.insn	4, 0x67e7e60b
    80010004:	0006                	c.slli	zero,0x1
    80010006:	d8d640e7          	.insn	4, 0xd8d640e7
    8001000a:	ef62                	sd	s8,408(sp)
    8001000c:	9d9e                	add	s11,s11,t2
    8001000e:	2922beff 27e404a3 	.insn	16, 0x7b6032e111f42ba427e404a32922beff
    80010016:	11f42ba4 7b6032e1 
    8001001e:	          	sb	s7,-202(s10)

0000000080010020 <d_0_0>:
    80010020:	f37d                	bnez	a4,80010006 <_random_data0+0x6>
    80010022:	016ad4f7          	.insn	4, 0x016ad4f7
    80010026:	34f8e1c7          	.insn	4, 0x34f8e1c7
    8001002a:	3bbc                	fld	fa5,112(a5)
    8001002c:	e3fbc00b          	.insn	4, 0xe3fbc00b

0000000080010030 <d_0_1>:
    80010030:	5de1                	li	s11,-8
    80010032:	c730                	sw	a2,72(a4)
    80010034:	d032                	sw	a2,32(sp)
    80010036:	bea8                	fsd	fa0,120(a3)
    80010038:	e52d                	bnez	a0,800100a2 <d_0_8+0x2>
    8001003a:	a91c                	fsd	fa5,16(a0)
    8001003c:	8355                	srli	a4,a4,0x15
    8001003e:	909c                	.insn	2, 0x909c

0000000080010040 <d_0_2>:
    80010040:	3b20e99b          	.insn	4, 0x3b20e99b
    80010044:	7132                	ld	sp,296(sp)
    80010046:	8951                	andi	a0,a0,20
    80010048:	4caec5c7          	.insn	4, 0x4caec5c7
    8001004c:	36d4                	fld	fa3,168(a3)
    8001004e:	ce22                	sw	s0,28(sp)

0000000080010050 <d_0_3>:
    80010050:	3456                	fld	fs0,368(sp)
    80010052:	c342                	sw	a6,132(sp)
    80010054:	c962af3b          	.insn	4, 0xc962af3b
    80010058:	1d78c6b3          	.insn	4, 0x1d78c6b3
    8001005c:	02c4                	addi	s1,sp,324
    8001005e:	          	.insn	4, 0xd1dd97af

0000000080010060 <d_0_4>:
    80010060:	d1dd                	beqz	a1,80010006 <_random_data0+0x6>
    80010062:	f9d5                	bnez	a1,80010016 <_random_data0+0x16>
    80010064:	02f9                	addi	t0,t0,30 # 63b0b55e <_start-0x1c4f4aa2>
    80010066:	122a                	slli	tp,tp,0x2a
    80010068:	e851                	bnez	s0,800100fc <d_0_13+0xc>
    8001006a:	3dcc                	fld	fa1,184(a1)
    8001006c:	931e                	add	t1,t1,t2
    8001006e:	2c10                	fld	fa2,24(s0)

0000000080010070 <d_0_5>:
    80010070:	4a02                	lw	s4,0(sp)
    80010072:	c74e                	sw	s3,140(sp)
    80010074:	bf4c                	fsd	fa1,184(a4)
    80010076:	21ea                	fld	ft3,152(sp)
    80010078:	36c6ce43          	.insn	4, 0x36c6ce43
    8001007c:	f274488b          	.insn	4, 0xf274488b

0000000080010080 <d_0_6>:
    80010080:	bd6c                	fsd	fa1,248(a0)
    80010082:	8d9bf9a3          	.insn	4, 0x8d9bf9a3
    80010086:	1d32                	slli	s10,s10,0x2c
    80010088:	2f91                	addiw	t6,t6,4
    8001008a:	f2c0                	sd	s0,160(a3)
    8001008c:	3fcd                	addiw	t6,t6,-13
    8001008e:	656c                	ld	a1,200(a0)

0000000080010090 <d_0_7>:
    80010090:	3c58                	fld	fa4,184(s0)
    80010092:	7c52                	ld	s8,304(sp)
    80010094:	c2a2                	sw	s0,68(sp)
    80010096:	d61e                	sw	t2,44(sp)
    80010098:	0344                	addi	s1,sp,388
    8001009a:	8d46                	mv	s10,a7
    8001009c:	fd7f45cb          	.insn	4, 0xfd7f45cb

00000000800100a0 <d_0_8>:
    800100a0:	f9d9                	bnez	a1,80010036 <d_0_1+0x6>
    800100a2:	fd209db3          	.insn	4, 0xfd209db3
    800100a6:	381fbeaf          	.insn	4, 0x381fbeaf
    800100aa:	20e1                	addiw	ra,ra,24
    800100ac:	2cdc                	fld	fa5,152(s1)
    800100ae:	875e                	mv	a4,s7

00000000800100b0 <d_0_9>:
    800100b0:	02d2                	slli	t0,t0,0x14
    800100b2:	485c                	lw	a5,20(s0)
    800100b4:	3f81                	addiw	t6,t6,-32
    800100b6:	074b0b23          	sb	s4,118(s6)
    800100ba:	d83d8ab7          	lui	s5,0xd83d8
    800100be:	d31c                	sw	a5,32(a4)

00000000800100c0 <d_0_10>:
    800100c0:	5964                	lw	s1,116(a0)
    800100c2:	29ca                	fld	fs3,144(sp)
    800100c4:	20a0c4ef          	jal	s1,8001c2ce <_end_data0+0xc0ce>
    800100c8:	05cd                	addi	a1,a1,19
    800100ca:	bd26                	fsd	fs1,184(sp)
    800100cc:	9f04c2e7          	.insn	4, 0x9f04c2e7

00000000800100d0 <d_0_11>:
    800100d0:	c1b5bbc7          	fmsub.s	fs7,fa1,fs11,fs8,rup
    800100d4:	5a4e                	lw	s4,240(sp)
    800100d6:	4eb48097          	auipc	ra,0x4eb48
    800100da:	b0e1                	j	8000f9a2 <end_signature+0xd5c2>
    800100dc:	8802                	jr	a6
    800100de:	          	.insn	4, 0x8ea7979b

00000000800100e0 <d_0_12>:
    800100e0:	e0ba8ea7          	.insn	4, 0xe0ba8ea7
    800100e4:	9deed4c7          	.insn	4, 0x9deed4c7
    800100e8:	57a9                	li	a5,-22
    800100ea:	7dc54efb          	.insn	4, 0x7dc54efb
    800100ee:	          	.insn	4, 0xfc9eda4f

00000000800100f0 <d_0_13>:
    800100f0:	fc9e                	sd	t2,120(sp)
    800100f2:	cf69                	beqz	a4,800101cc <d_0_26+0xc>
    800100f4:	b740                	fsd	fs0,168(a4)
    800100f6:	8a45                	andi	a2,a2,17
    800100f8:	1bf4                	addi	a3,sp,508
    800100fa:	b4962e0b          	.insn	4, 0xb4962e0b
    800100fe:	bc01                	j	8000fb0e <end_signature+0xd72e>

0000000080010100 <d_0_14>:
    80010100:	d50a                	sw	sp,168(sp)
    80010102:	61c2eccb          	fnmsub.s	fs9,ft5,ft8,fa2,unknown
    80010106:	9509                	srai	a0,a0,0x22
    80010108:	960c                	.insn	2, 0x960c
    8001010a:	c5dfd077          	.insn	4, 0xc5dfd077
    8001010e:	8e7f    	.insn	10, 0x09b0e13c78f85c308e7f
    80010116:	 

0000000080010110 <d_0_15>:
    80010110:	5c30                	lw	a2,120(s0)
    80010112:	78f8                	ld	a4,240(s1)
    80010114:	e13c                	sd	a5,64(a0)
    80010116:	09b0                	addi	a2,sp,216
    80010118:	9497e78f          	.insn	4, 0x9497e78f
    8001011c:	a0a745ab          	.insn	4, 0xa0a745ab

0000000080010120 <d_0_16>:
    80010120:	be64                	fsd	fs1,248(a2)
    80010122:	0a5e                	slli	s4,s4,0x17
    80010124:	d218a9a3          	sw	ra,-717(a7)
    80010128:	c616                	sw	t0,12(sp)
    8001012a:	de6e                	sw	s11,60(sp)
    8001012c:	0e92                	slli	t4,t4,0x4
    8001012e:	83a8                	.insn	2, 0x83a8

0000000080010130 <d_0_17>:
    80010130:	1b65                	addi	s6,s6,-7
    80010132:	0f42                	slli	t5,t5,0x10
    80010134:	b176                	fsd	ft9,160(sp)
    80010136:	d3315fe7          	.insn	4, 0xd3315fe7
    8001013a:	5454                	lw	a3,44(s0)
    8001013c:	4844                	lw	s1,20(s0)
    8001013e:	          	fnmsub.s	fs7,fs6,fa6,ft6,unknown

0000000080010140 <d_0_18>:
    80010140:	d197310b          	.insn	4, 0xd197310b
    80010144:	707a                	.insn	2, 0x707a
    80010146:	719e                	ld	gp,480(sp)
    80010148:	7af8                	ld	a4,240(a3)
    8001014a:	dec0                	sw	s0,60(a3)
    8001014c:	ab76                	fsd	ft9,400(sp)
    8001014e:	087a                	slli	a6,a6,0x1e

0000000080010150 <d_0_19>:
    80010150:	e4924b2f          	.insn	4, 0xe4924b2f
    80010154:	822e                	mv	tp,a1
    80010156:	dc48b9db          	.insn	4, 0xdc48b9db
    8001015a:	0e59                	addi	t3,t3,22
    8001015c:	5978                	lw	a4,116(a0)
    8001015e:	1de8                	addi	a0,sp,764

0000000080010160 <d_0_20>:
    80010160:	3d52                	fld	fs10,304(sp)
    80010162:	b7e6                	fsd	fs9,488(sp)
    80010164:	0e65                	addi	t3,t3,25
    80010166:	7e99d0ab          	.insn	4, 0x7e99d0ab
    8001016a:	4f127563          	bgeu	tp,a7,80010654 <_end_data0+0x454>
    8001016e:	1ca9                	addi	s9,s9,-22

0000000080010170 <d_0_21>:
    80010170:	5d41                	li	s10,-16
    80010172:	5541                	li	a0,-16
    80010174:	96ec4c67          	.insn	4, 0x96ec4c67
    80010178:	78b4                	ld	a3,112(s1)
    8001017a:	be00                	fsd	fs0,56(a2)
    8001017c:	64a9e4b3          	.insn	4, 0x64a9e4b3

0000000080010180 <d_0_22>:
    80010180:	0e60                	addi	s0,sp,796
    80010182:	0c6e                	slli	s8,s8,0x1b
    80010184:	64f20323          	sb	a5,1606(tp) # 646 <_start-0x7ffff9ba>
    80010188:	8a61                	andi	a2,a2,24
    8001018a:	7a5eb78f          	.insn	4, 0x7a5eb78f
    8001018e:	5275                	li	tp,-3

0000000080010190 <d_0_23>:
    80010190:	70c9                	lui	ra,0xffff2
    80010192:	a361                	j	8001071a <_end_data0+0x51a>
    80010194:	522a                	lw	tp,168(sp)
    80010196:	89b9                	andi	a1,a1,14
    80010198:	8348                	.insn	2, 0x8348
    8001019a:	930e                	add	t1,t1,gp
    8001019c:	afee                	fsd	fs11,472(sp)
    8001019e:	3905                	addiw	s2,s2,-31

00000000800101a0 <d_0_24>:
    800101a0:	632d                	lui	t1,0xb
    800101a2:	73f4                	ld	a3,224(a5)
    800101a4:	62d3d253          	.insn	4, 0x62d3d253
    800101a8:	7196                	ld	gp,352(sp)
    800101aa:	bb9a                	fsd	ft6,496(sp)
    800101ac:	a1939ed3          	flt.s	t4,ft7,fs9

00000000800101b0 <d_0_25>:
    800101b0:	a2d6                	fsd	fs5,320(sp)
    800101b2:	eb50                	sd	a2,144(a4)
    800101b4:	cddb0533          	.insn	4, 0xcddb0533
    800101b8:	9ac8                	.insn	2, 0x9ac8
    800101ba:	89a2                	mv	s3,s0
    800101bc:	94d7eae3          	bltu	a5,a3,8000fb10 <end_signature+0xd730>

00000000800101c0 <d_0_26>:
    800101c0:	ae1d                	j	800104f6 <_end_data0+0x2f6>
    800101c2:	4fbd                	li	t6,15
    800101c4:	0ba03e53          	fsub.d	ft8,ft0,fs10,rup
    800101c8:	1e3e                	slli	t3,t3,0x2f
    800101ca:	7b62                	ld	s6,56(sp)
    800101cc:	4b88                	lw	a0,16(a5)
    800101ce:	9290                	.insn	2, 0x9290

00000000800101d0 <d_0_27>:
    800101d0:	4d66                	lw	s10,88(sp)
    800101d2:	d876                	sw	t4,48(sp)
    800101d4:	a2925e8f          	.insn	4, 0xa2925e8f
    800101d8:	28669247          	fmsub.s	ft4,fa3,ft6,ft5,rtz
    800101dc:	f498                	sd	a4,40(s1)
    800101de:	c8c6d8ff d838d8e8 	.insn	20, 0x8e66db8acdc910aaa2370f9ed838d8e8c8c6d8ff
    800101e6:	a2370f9e cdc910aa 
    800101ee:	8e66db8a 
    800101f2:	bf5e                	fsd	fs7,440(sp)
    800101f4:	d190                	sw	a2,32(a1)
    800101f6:	0bed                	addi	s7,s7,27 # ffffffffffe0001b <_end+0xffffffff7fd9fe1b>
    800101f8:	d1fa                	sw	t5,224(sp)
    800101fa:	abc4                	fsd	fs1,144(a5)
    800101fc:	256904cb          	.insn	4, 0x256904cb

Disassembly of section .data.random1:

0000000080020000 <_random_data1>:
    80020000:	dea5                	beqz	a3,8001ff78 <_end_data0+0xfd78>
    80020002:	765a                	ld	a2,432(sp)
    80020004:	486a0c3f be715907 	.insn	8, 0xbe715907486a0c3f
    8002000c:	480a                	lw	a6,128(sp)
    8002000e:	2d7e                	fld	fs10,472(sp)
    80020010:	26dd                	addiw	a3,a3,23
    80020012:	df60                	sw	s0,124(a4)
    80020014:	5c11                	li	s8,-28
    80020016:	2d98                	fld	fa4,24(a1)
    80020018:	942d                	srai	s0,s0,0x2b
    8002001a:	2b50                	fld	fa2,144(a4)
    8002001c:	b345                	j	8001fdbc <_end_data0+0xfbbc>
    8002001e:	d8b4                	sw	a3,112(s1)

0000000080020020 <d_1_0>:
    80020020:	c645                	beqz	a2,800200c8 <d_1_10+0x8>
    80020022:	5038c7cb          	fnmsub.s	fa5,fa7,ft3,fa0,rmm
    80020026:	06b64027          	.insn	4, 0x06b64027
    8002002a:	edff bd26 6ea5  	.insn	22, 0xe82a8859bdaea5da334bf8eed9e31dde6ea5bd26edff
    80020032:	    
    8002003a:	   

0000000080020030 <d_1_1>:
    80020030:	1dde                	slli	s11,s11,0x37
    80020032:	f8eed9e3          	bge	t4,a4,8001ffc4 <_end_data0+0xfdc4>
    80020036:	a5da334b          	.insn	4, 0xa5da334b
    8002003a:	bdae                	fsd	fa1,248(sp)
    8002003c:	8859                	andi	s0,s0,22
    8002003e:	e82a                	sd	a0,16(sp)

0000000080020040 <d_1_2>:
    80020040:	bd6d                	j	8001fefa <_end_data0+0xfcfa>
    80020042:	7f70                	ld	a2,248(a4)
    80020044:	bc86                	fsd	ft1,120(sp)
    80020046:	16d8                	addi	a4,sp,868
    80020048:	bc3ad233          	.insn	4, 0xbc3ad233
    8002004c:	8cbce44b          	.insn	4, 0x8cbce44b

0000000080020050 <d_1_3>:
    80020050:	3685                	addiw	a3,a3,-31
    80020052:	c82353bb          	.insn	4, 0xc82353bb
    80020056:	118e                	slli	gp,gp,0x23
    80020058:	0511f0af          	.insn	4, 0x0511f0af
    8002005c:	2432                	fld	fs0,264(sp)
    8002005e:	9fd2                	add	t6,t6,s4

0000000080020060 <d_1_4>:
    80020060:	c521                	beqz	a0,800200a8 <d_1_8+0x8>
    80020062:	b191345b          	.insn	4, 0xb191345b
    80020066:	54ca                	lw	s1,176(sp)
    80020068:	fff2                	sd	t3,504(sp)
    8002006a:	7ef9e7cb          	.insn	4, 0x7ef9e7cb
    8002006e:	          	.insn	4, 0x61e5f93b

0000000080020070 <d_1_5>:
    80020070:	61e5                	lui	gp,0x19
    80020072:	fde0                	sd	s0,248(a1)
    80020074:	beb2                	fsd	fa2,376(sp)
    80020076:	aef6                	fsd	ft9,344(sp)
    80020078:	aec6                	fsd	fa7,344(sp)
    8002007a:	76371d17          	auipc	s10,0x76371
    8002007e:	d8f8                	sw	a4,116(s1)

0000000080020080 <d_1_6>:
    80020080:	3b22                	fld	fs6,40(sp)
    80020082:	8fa9                	xor	a5,a5,a0
    80020084:	2bd9                	addiw	s7,s7,22
    80020086:	4ef6                	lw	t4,92(sp)
    80020088:	1b3a                	slli	s6,s6,0x2e
    8002008a:	2d14                	fld	fa3,24(a0)
    8002008c:	84e0                	.insn	2, 0x84e0
    8002008e:	c668                	sw	a0,76(a2)

0000000080020090 <d_1_7>:
    80020090:	9188                	.insn	2, 0x9188
    80020092:	33c5                	addiw	t2,t2,-15
    80020094:	4455                	li	s0,21
    80020096:	e0f1                	bnez	s1,8002015a <d_1_19+0xa>
    80020098:	07a4e833          	.insn	4, 0x07a4e833
    8002009c:	e6e9                	bnez	a3,80020166 <d_1_20+0x6>
    8002009e:	9876                	add	a6,a6,t4

00000000800200a0 <d_1_8>:
    800200a0:	54cd                	li	s1,-13
    800200a2:	3f4a                	fld	ft10,176(sp)
    800200a4:	2db8                	fld	fa4,88(a1)
    800200a6:	5dd2ab13          	slti	s6,t0,1501
    800200aa:	9081                	srli	s1,s1,0x20
    800200ac:	ecb4                	sd	a3,88(s1)
    800200ae:	5069                	c.li	zero,-6

00000000800200b0 <d_1_9>:
    800200b0:	6d98cdef          	jal	s11,800acf88 <_end+0x4cd88>
    800200b4:	d540                	sw	s0,44(a0)
    800200b6:	b928                	fsd	fa0,112(a0)
    800200b8:	7f0eb87b          	.insn	4, 0x7f0eb87b
    800200bc:	9c9c                	.insn	2, 0x9c9c
    800200be:	8cf0                	.insn	2, 0x8cf0

00000000800200c0 <d_1_10>:
    800200c0:	9e11d91b          	.insn	4, 0x9e11d91b
    800200c4:	f889                	bnez	s1,8001ffd6 <_end_data0+0xfdd6>
    800200c6:	3535                	addiw	a0,a0,-19 # 5fed <_start-0x7fffa013>
    800200c8:	1ccd                	addi	s9,s9,-13
    800200ca:	7201                	lui	tp,0xfffe0
    800200cc:	bd06                	fsd	ft1,184(sp)
    800200ce:	2549                	addiw	a0,a0,18

00000000800200d0 <d_1_11>:
    800200d0:	9b44                	.insn	2, 0x9b44
    800200d2:	8082                	ret
    800200d4:	3e72                	fld	ft8,312(sp)
    800200d6:	16f2                	slli	a3,a3,0x3c
    800200d8:	240d                	addiw	s0,s0,3
    800200da:	7a70                	ld	a2,240(a2)
    800200dc:	4426                	lw	s0,72(sp)
    800200de:	8245                	srli	a2,a2,0x11

00000000800200e0 <d_1_12>:
    800200e0:	4638                	lw	a4,72(a2)
    800200e2:	0234                	addi	a3,sp,264
    800200e4:	35de64ef          	jal	s1,80106c40 <_end+0xa6a40>
    800200e8:	6e9f 5418 9f9a      	.insn	6, 0x9f9a54186e9f
    800200ee:	f0a1                	bnez	s1,8002002e <d_1_0+0xe>

00000000800200f0 <d_1_13>:
    800200f0:	3b7c                	fld	fa5,240(a4)
    800200f2:	83fb5733          	.insn	4, 0x83fb5733
    800200f6:	31c5                	addiw	gp,gp,-15 # 18ff1 <_start-0x7ffe700f>
    800200f8:	49d9                	li	s3,22
    800200fa:	d9cbb4d7          	.insn	4, 0xd9cbb4d7
    800200fe:	7538                	ld	a4,104(a0)

0000000080020100 <d_1_14>:
    80020100:	c8f0                	sw	a2,84(s1)
    80020102:	42bc                	lw	a5,64(a3)
    80020104:	34adbc53          	.insn	4, 0x34adbc53
    80020108:	c0e5                	beqz	s1,800201e8 <d_1_27+0x18>
    8002010a:	2359                	addiw	t1,t1,22 # b016 <_start-0x7fff4fea>
    8002010c:	adce66f3          	csrrsi	a3,0xadc,28

0000000080020110 <d_1_15>:
    80020110:	fdd9                	bnez	a1,800200ae <d_1_8+0xe>
    80020112:	afea                	fsd	fs10,472(sp)
    80020114:	c745                	beqz	a4,800201bc <d_1_25+0xc>
    80020116:	3a1cb60b          	.insn	4, 0x3a1cb60b
    8002011a:	4945                	li	s2,17
    8002011c:	0379                	addi	t1,t1,30
    8002011e:	d3bd                	beqz	a5,80020084 <d_1_6+0x4>

0000000080020120 <d_1_16>:
    80020120:	c21aec0f          	.insn	4, 0xc21aec0f
    80020124:	bb0ac7e7          	.insn	4, 0xbb0ac7e7
    80020128:	a278                	fsd	fa4,192(a2)
    8002012a:	e408a83b          	.insn	4, 0xe408a83b
    8002012e:	698d                	lui	s3,0x3

0000000080020130 <d_1_17>:
    80020130:	4709                	li	a4,2
    80020132:	4a0a                	lw	s4,128(sp)
    80020134:	6d95                	lui	s11,0x5
    80020136:	5f10accf          	.insn	4, 0x5f10accf
    8002013a:	639c8857          	vmseq.vv	v16,v25,v25
    8002013e:	7f60                	ld	s0,248(a4)

0000000080020140 <d_1_18>:
    80020140:	7a92                	ld	s5,288(sp)
    80020142:	f1ac                	sd	a1,96(a1)
    80020144:	20b0174b          	fnmsub.s	fa4,ft0,fa1,ft4,rtz
    80020148:	d0dc                	sw	a5,36(s1)
    8002014a:	f605                	bnez	a2,80020072 <d_1_5+0x2>
    8002014c:	adc5                	j	8002083c <_end_data1+0x63c>
    8002014e:	c745                	beqz	a4,800201f6 <d_1_27+0x26>

0000000080020150 <d_1_19>:
    80020150:	0f2221f3          	csrrs	gp,0xf2,tp
    80020154:	9e64                	.insn	2, 0x9e64
    80020156:	dfd0880f          	.insn	4, 0xdfd0880f
    8002015a:	94e4                	.insn	2, 0x94e4
    8002015c:	853a                	mv	a0,a4
    8002015e:	73ac                	ld	a1,96(a5)

0000000080020160 <d_1_20>:
    80020160:	6258                	ld	a4,128(a2)
    80020162:	58df 0ab1 75b9      	.insn	6, 0x75b90ab158df
    80020168:	a52d                	j	80020792 <_end_data1+0x592>
    8002016a:	c6d6                	sw	s5,76(sp)
    8002016c:	1b24                	addi	s1,sp,440
    8002016e:	9056                	c.add	zero,s5

0000000080020170 <d_1_21>:
    80020170:	fbf1                	bnez	a5,80020144 <d_1_18+0x4>
    80020172:	6296                	ld	t0,320(sp)
    80020174:	8aa5                	andi	a3,a3,9
    80020176:	5c20                	lw	s0,120(s0)
    80020178:	09b6                	slli	s3,s3,0xd
    8002017a:	8b58cebb          	.insn	4, 0x8b58cebb
    8002017e:	6980                	ld	s0,16(a1)

0000000080020180 <d_1_22>:
    80020180:	6b90                	ld	a2,16(a5)
    80020182:	d64e                	sw	s3,44(sp)
    80020184:	5aac                	lw	a1,112(a3)
    80020186:	b772                	fsd	ft8,424(sp)
    80020188:	e9c5                	bnez	a1,80020238 <_end_data1+0x38>
    8002018a:	33a2d887          	.insn	4, 0x33a2d887
    8002018e:	30c6                	fld	ft1,112(sp)

0000000080020190 <d_1_23>:
    80020190:	5d81                	li	s11,-32
    80020192:	2894                	fld	fa3,16(s1)
    80020194:	839d                	srli	a5,a5,0x7
    80020196:	4cf4                	lw	a3,92(s1)
    80020198:	d819788f          	.insn	4, 0xd819788f
    8002019c:	e180                	sd	s0,0(a1)
    8002019e:	71ee                	ld	gp,248(sp)

00000000800201a0 <d_1_24>:
    800201a0:	9bc1                	andi	a5,a5,-16
    800201a2:	aee4                	fsd	fs1,216(a3)
    800201a4:	14c9                	addi	s1,s1,-14
    800201a6:	90fa3bbb          	.insn	4, 0x90fa3bbb
    800201aa:	e406                	sd	ra,8(sp)
    800201ac:	cbfb770b          	.insn	4, 0xcbfb770b

00000000800201b0 <d_1_25>:
    800201b0:	b8e9                	j	8001fa8a <_end_data0+0xf88a>
    800201b2:	1ba0cd53          	fdiv.d	fs10,ft1,fs10,rmm
    800201b6:	9f35                	addw	a4,a4,a3
    800201b8:	f01f ab56 721d      	.insn	6, 0x721dab56f01f
    800201be:	8ce6                	mv	s9,s9

00000000800201c0 <d_1_26>:
    800201c0:	8379                	srli	a4,a4,0x1e
    800201c2:	91b0                	.insn	2, 0x91b0
    800201c4:	0001                	nop
    800201c6:	b1d6                	fsd	fs5,224(sp)
    800201c8:	4b14                	lw	a3,16(a4)
    800201ca:	6b51                	lui	s6,0x14
    800201cc:	93c450cb          	fnmsub.d	ft1,fs0,ft8,fs2,unknown

00000000800201d0 <d_1_27>:
    800201d0:	f084                	sd	s1,32(s1)
    800201d2:	dc335dfb          	.insn	4, 0xdc335dfb
    800201d6:	1999                	addi	s3,s3,-26 # 2fe6 <_start-0x7fffd01a>
    800201d8:	fc28                	sd	a0,120(s0)
    800201da:	1c79                	addi	s8,s8,-2
    800201dc:	dba5                	beqz	a5,8002014c <d_1_18+0xc>
    800201de:	de22                	sw	s0,60(sp)
    800201e0:	3030                	fld	fa2,96(s0)
    800201e2:	76aa6d4b          	.insn	4, 0x76aa6d4b
    800201e6:	0449                	addi	s0,s0,18
    800201e8:	cb67c9c3          	fmadd.d	fs3,fa5,fs6,fs9,rmm
    800201ec:	bc11                	j	8001fc00 <_end_data0+0xfa00>
    800201ee:	a2a9                	j	80020338 <_end_data1+0x138>
    800201f0:	d954ff93          	andi	t6,s1,-619
    800201f4:	8fd6                	mv	t6,s5
    800201f6:	1f97771b          	.insn	4, 0x1f97771b
    800201fa:	d686                	sw	ra,108(sp)
    800201fc:	7132                	ld	sp,296(sp)
    800201fe:	8b8d                	andi	a5,a5,3

Disassembly of section .data.random2:

0000000080030000 <_random_data2>:
    80030000:	92a8                	.insn	2, 0x92a8
    80030002:	40da                	lw	ra,148(sp)
    80030004:	52ba                	lw	t0,172(sp)
    80030006:	3d92                	fld	fs11,288(sp)
    80030008:	f5ad                	bnez	a1,8002ff72 <_end_data1+0xfd72>
    8003000a:	6a59                	lui	s4,0x16
    8003000c:	6800                	ld	s0,16(s0)
    8003000e:	8780                	.insn	2, 0x8780
    80030010:	a28e                	fsd	ft3,320(sp)
    80030012:	3862                	fld	fa6,56(sp)
    80030014:	d71ca28b          	.insn	4, 0xd71ca28b
    80030018:	29bfdc4f          	fnmadd.s	fs8,ft11,fs11,ft5,unknown
    8003001c:	b298                	fsd	fa4,32(a3)
    8003001e:	3af9                	addiw	s5,s5,-2 # ffffffffd83d7ffe <_end+0xffffffff58377dfe>

0000000080030020 <d_2_0>:
    80030020:	2c7ca833          	.insn	4, 0x2c7ca833
    80030024:	56edb483          	ld	s1,1390(s11) # 556e <_start-0x7fffaa92>
    80030028:	0f4d                	addi	t5,t5,19
    8003002a:	af59                	j	800307c0 <_end_data2+0x5c0>
    8003002c:	d8b5                	beqz	s1,8002ffa0 <_end_data1+0xfda0>
    8003002e:	3800                	fld	fs0,48(s0)

0000000080030030 <d_2_1>:
    80030030:	8c94                	.insn	2, 0x8c94
    80030032:	ecfd0907          	vloxseg8ei8.v	v18,(s10),v15,v0.t
    80030036:	d989                	beqz	a1,8002ff48 <_end_data1+0xfd48>
    80030038:	c1500a1b          	addiw	s4,zero,-1003
    8003003c:	2938                	fld	fa4,80(a0)
    8003003e:	1c5f        	.insn	6, 0xb7d5b4871c5f

0000000080030040 <d_2_2>:
    80030040:	b7d5b487          	fld	fs1,-1155(a1)
    80030044:	5ad1                	li	s5,-12
    80030046:	c2b6a727          	fsw	fa1,-978(a3)
    8003004a:	1f05                	addi	t5,t5,-31
    8003004c:	1b16                	slli	s6,s6,0x25
    8003004e:	          	fmadd.d	fa1,fa2,ft8,fs0,rup

0000000080030050 <d_2_3>:
    80030050:	43c6                	lw	t2,80(sp)
    80030052:	96a4                	.insn	2, 0x96a4
    80030054:	1f5ad14f          	.insn	4, 0x1f5ad14f
    80030058:	918abf3f 2e89a720 	.insn	8, 0x2e89a720918abf3f

0000000080030060 <d_2_4>:
    80030060:	a908                	fsd	fa0,16(a0)
    80030062:	12d9                	addi	t0,t0,-10
    80030064:	00e5                	addi	ra,ra,25 # ffffffffffff2019 <_end+0xffffffff7ff91e19>
    80030066:	46df 1c34 921d      	.insn	6, 0x921d1c3446df
    8003006c:	a9bf78d7          	.insn	4, 0xa9bf78d7

0000000080030070 <d_2_5>:
    80030070:	7682                	ld	a3,32(sp)
    80030072:	c154                	sw	a3,4(a0)
    80030074:	cb55                	beqz	a4,80030128 <d_2_16+0x8>
    80030076:	066d                	addi	a2,a2,27
    80030078:	34ec                	fld	fa1,232(s1)
    8003007a:	39ad                	addiw	s3,s3,-21
    8003007c:	168bb5e3          	.insn	4, 0x168bb5e3

0000000080030080 <d_2_6>:
    80030080:	fa90b2cb          	fnmsub.d	ft5,ft1,fs1,ft11,rup
    80030084:	d962228f          	.insn	4, 0xd962228f
    80030088:	b666                	fsd	fs9,296(sp)
    8003008a:	1ea5                	addi	t4,t4,-23
    8003008c:	2fd5                	addiw	t6,t6,21
    8003008e:	d725                	beqz	a4,8002fff6 <_end_data1+0xfdf6>

0000000080030090 <d_2_7>:
    80030090:	79ad8dcb          	fnmsub.s	fs11,fs11,fs10,fa5,rne
    80030094:	4eee2877          	.insn	4, 0x4eee2877
    80030098:	2f59                	addiw	t5,t5,22
    8003009a:	6c1a                	ld	s8,384(sp)
    8003009c:	91b9                	srli	a1,a1,0x2e
    8003009e:	8b88                	.insn	2, 0x8b88

00000000800300a0 <d_2_8>:
    800300a0:	0a64                	addi	s1,sp,284
    800300a2:	599f c58a f560      	.insn	6, 0xf560c58a599f
    800300a8:	6ac1780b          	.insn	4, 0x6ac1780b
    800300ac:	f61f8f83          	lb	t6,-159(t6)

00000000800300b0 <d_2_9>:
    800300b0:	1f2e                	slli	t5,t5,0x2b
    800300b2:	5a28                	lw	a0,112(a2)
    800300b4:	da5be7ab          	.insn	4, 0xda5be7ab
    800300b8:	468a3d03          	ld	s10,1128(s4) # 16468 <_start-0x7ffe9b98>
    800300bc:	10cc                	addi	a1,sp,100
    800300be:	45d5                	li	a1,21

00000000800300c0 <d_2_10>:
    800300c0:	aef9                	j	8003049e <_end_data2+0x29e>
    800300c2:	4a11                	li	s4,4
    800300c4:	8e3d                	xor	a2,a2,a5
    800300c6:	03a6                	slli	t2,t2,0x9
    800300c8:	97836a67          	.insn	4, 0x97836a67
    800300cc:	db4e6c2f          	.insn	4, 0xdb4e6c2f

00000000800300d0 <d_2_11>:
    800300d0:	ad49                	j	80030762 <_end_data2+0x562>
    800300d2:	d9be1ec7          	fmsub.s	ft9,ft8,fs11,fs11,rtz
    800300d6:	f300                	sd	s0,32(a4)
    800300d8:	43a6                	lw	t2,72(sp)
    800300da:	7096                	ld	ra,352(sp)
    800300dc:	b108                	fsd	fa0,32(a0)
    800300de:	f981                	bnez	a1,8002ffee <_end_data1+0xfdee>

00000000800300e0 <d_2_12>:
    800300e0:	2ccd9e43          	.insn	4, 0x2ccd9e43
    800300e4:	8bfefc3b          	.insn	4, 0x8bfefc3b
    800300e8:	81936d3b          	.insn	4, 0x81936d3b
    800300ec:	4919                	li	s2,6
    800300ee:	          	.insn	4, 0x12cc75eb

00000000800300f0 <d_2_13>:
    800300f0:	12cc                	addi	a1,sp,356
    800300f2:	bdba                	fsd	fa4,248(sp)
    800300f4:	49b4                	lw	a3,80(a1)
    800300f6:	94c72b33          	.insn	4, 0x94c72b33
    800300fa:	4cf4a6e3          	.insn	4, 0x4cf4a6e3
    800300fe:	e041                	bnez	s0,8003017e <d_2_21+0xe>

0000000080030100 <d_2_14>:
    80030100:	f01509a3          	sb	ra,-237(a0)
    80030104:	ea19fa27          	vssseg8e64.v	v20,(s3),ra
    80030108:	26df beba bd29      	.insn	6, 0xbd29beba26df
    8003010e:	71c8                	ld	a0,160(a1)

0000000080030110 <d_2_15>:
    80030110:	bd64                	fsd	fs1,248(a0)
    80030112:	3fe8b7bb          	.insn	4, 0x3fe8b7bb
    80030116:	6915                	lui	s2,0x5
    80030118:	5e2e117b          	.insn	4, 0x5e2e117b
    8003011c:	c054                	sw	a3,4(s0)
    8003011e:	1b6e                	slli	s6,s6,0x3b

0000000080030120 <d_2_16>:
    80030120:	31c96f47          	fmsub.s	ft10,fs2,ft8,ft6,unknown
    80030124:	87f8                	.insn	2, 0x87f8
    80030126:	012dd827          	.insn	4, 0x012dd827
    8003012a:	e8c4421b          	.insn	4, 0xe8c4421b
    8003012e:	3cf6                	fld	fs9,376(sp)

0000000080030130 <d_2_17>:
    80030130:	e7d602c7          	.insn	4, 0xe7d602c7
    80030134:	b856                	fsd	fs5,48(sp)
    80030136:	95a73377          	.insn	4, 0x95a73377
    8003013a:	d328                	sw	a0,96(a4)
    8003013c:	3af8                	fld	fa4,240(a3)
    8003013e:	6734                	ld	a3,72(a4)

0000000080030140 <d_2_18>:
    80030140:	ffff                	.insn	2, 0xffff
    80030142:	71f4                	ld	a3,224(a1)
    80030144:	8270                	.insn	2, 0x8270
    80030146:	5529                	li	a0,-22
    80030148:	614c                	ld	a1,128(a0)
    8003014a:	2ce0                	fld	fs0,216(s1)
    8003014c:	7606                	ld	a2,96(sp)
    8003014e:	d9e4                	sw	s1,116(a1)

0000000080030150 <d_2_19>:
    80030150:	9fe2                	add	t6,t6,s8
    80030152:	ad1a                	fsd	ft6,152(sp)
    80030154:	94b1                	srai	s1,s1,0x2c
    80030156:	ae1190a7          	.insn	4, 0xae1190a7
    8003015a:	d1cd                	beqz	a1,800300fc <d_2_13+0xc>
    8003015c:	241b23e3          	.insn	4, 0x241b23e3

0000000080030160 <d_2_20>:
    80030160:	99f4                	.insn	2, 0x99f4
    80030162:	f157a6db          	.insn	4, 0xf157a6db
    80030166:	397cb60f          	.insn	4, 0x397cb60f
    8003016a:	926a                	add	tp,tp,s10
    8003016c:	9091                	srli	s1,s1,0x24
    8003016e:	3f6d                	addiw	t5,t5,-5

0000000080030170 <d_2_21>:
    80030170:	342e                	fld	fs0,232(sp)
    80030172:	9f6e                	add	t5,t5,s11
    80030174:	acea719b          	.insn	4, 0xacea719b
    80030178:	0ae5                	addi	s5,s5,25
    8003017a:	5e34                	lw	a3,120(a2)
    8003017c:	d36c                	sw	a1,100(a4)
    8003017e:	95c5                	srai	a1,a1,0x31

0000000080030180 <d_2_22>:
    80030180:	fe7d                	bnez	a2,8003017e <d_2_21+0xe>
    80030182:	2690                	fld	fa2,8(a3)
    80030184:	5f7c                	lw	a5,124(a4)
    80030186:	7343c79b          	.insn	4, 0x7343c79b
    8003018a:	ed852a37          	lui	s4,0xed852
    8003018e:	a775                	j	8003093a <_end_data2+0x73a>

0000000080030190 <d_2_23>:
    80030190:	3110                	fld	fa2,32(a0)
    80030192:	fcd2                	sd	s4,120(sp)
    80030194:	aa3e                	fsd	fa5,272(sp)
    80030196:	e7a4                	sd	s1,72(a5)
    80030198:	fe8c                	sd	a1,56(a3)
    8003019a:	adde                	fsd	fs7,216(sp)
    8003019c:	7536                	ld	a0,360(sp)
    8003019e:	f5c1                	bnez	a1,80030126 <d_2_16+0x6>

00000000800301a0 <d_2_24>:
    800301a0:	0dfe12ab          	.insn	4, 0x0dfe12ab
    800301a4:	e904                	sd	s1,16(a0)
    800301a6:	def7c4bb          	.insn	4, 0xdef7c4bb
    800301aa:	65f5                	lui	a1,0x1d
    800301ac:	166a                	slli	a2,a2,0x3a
    800301ae:	          	.insn	4, 0x534d9257

00000000800301b0 <d_2_25>:
    800301b0:	534d                	li	t1,-13
    800301b2:	eddd                	bnez	a1,80030270 <_end_data2+0x70>
    800301b4:	049a                	slli	s1,s1,0x6
    800301b6:	ee325ef7          	.insn	4, 0xee325ef7
    800301ba:	d2251d8b          	.insn	4, 0xd2251d8b
    800301be:	          	fnmadd.s	fs1,ft3,ft2,fa7,rne

00000000800301c0 <d_2_26>:
    800301c0:	8821                	andi	s0,s0,8
    800301c2:	bb3d                	j	8002ff00 <_end_data1+0xfd00>
    800301c4:	6551                	lui	a0,0x14
    800301c6:	80e2                	mv	ra,s8
    800301c8:	843c5a1b          	.insn	4, 0x843c5a1b
    800301cc:	34df 21b4       	.insn	6, 0x58c621b434df

00000000800301d0 <d_2_27>:
    800301d0:	58c6                	lw	a7,112(sp)
    800301d2:	62b1                	lui	t0,0xc
    800301d4:	5925                	li	s2,-23
    800301d6:	b124                	fsd	fs1,96(a0)
    800301d8:	f89eddc3          	fmadd.s	fs11,ft9,fs1,ft11,unknown
    800301dc:	6985                	lui	s3,0x1
    800301de:	27ebbd03          	ld	s10,638(s7)
    800301e2:	9b9c                	.insn	2, 0x9b9c
    800301e4:	11d2                	slli	gp,gp,0x34
    800301e6:	f296                	sd	t0,352(sp)
    800301e8:	710a4203          	lbu	tp,1808(s4) # ffffffffed852710 <_end+0xffffffff6d7f2510>
    800301ec:	c27c                	sw	a5,68(a2)
    800301ee:	a6450cd7          	vsra.vv	v25,v4,v10
    800301f2:	dc85                	beqz	s1,8003012a <d_2_16+0xa>
    800301f4:	e360                	sd	s0,192(a4)
    800301f6:	ded17fd3          	.insn	4, 0xded17fd3
    800301fa:	3158                	fld	fa4,160(a0)
    800301fc:	f3ba                	sd	a4,480(sp)
    800301fe:	3006                	fld	ft0,96(sp)

Disassembly of section .data.random3:

0000000080040000 <_random_data3>:
    80040000:	06cc                	addi	a1,sp,836
    80040002:	7ac2                	ld	s5,48(sp)
    80040004:	f7ca8eaf          	.insn	4, 0xf7ca8eaf
    80040008:	fa99                	bnez	a3,8003ff1e <_end_data2+0xfd1e>
    8004000a:	d282                	sw	zero,100(sp)
    8004000c:	9788ba3f 0c7130f3 	.insn	8, 0x0c7130f39788ba3f
    80040014:	e5e2                	sd	s8,200(sp)
    80040016:	4d90                	lw	a2,24(a1)
    80040018:	8980                	.insn	2, 0x8980
    8004001a:	da2b9d57          	vfwsub.wv	v26,v2,v23
    8004001e:	4705                	li	a4,1

0000000080040020 <d_3_0>:
    80040020:	272b0767          	jalr	a4,626(s6) # 14272 <_start-0x7ffebd8e>
    80040024:	fdb9                	bnez	a1,8003ff82 <_end_data2+0xfd82>
    80040026:	19c8                	addi	a0,sp,244
    80040028:	6915844f          	fnmadd.s	fs0,fa1,fa7,fa3,rne
    8004002c:	5586                	lw	a1,96(sp)
    8004002e:	ee38                	sd	a4,88(a2)

0000000080040030 <d_3_1>:
    80040030:	cbde89cf          	fnmadd.d	fs3,ft9,ft9,fs9,rne
    80040034:	9d82                	jalr	s11
    80040036:	4c3a                	lw	s8,140(sp)
    80040038:	fb2a                	sd	a0,432(sp)
    8004003a:	f31f c9be 9a52      	.insn	6, 0x9a52c9bef31f

0000000080040040 <d_3_2>:
    80040040:	f0f1                	bnez	s1,80040004 <_random_data3+0x4>
    80040042:	9bce                	add	s7,s7,s3
    80040044:	6339c60f          	.insn	4, 0x6339c60f
    80040048:	4232b1ab          	.insn	4, 0x4232b1ab
    8004004c:	6558                	ld	a4,136(a0)
    8004004e:	f812                	sd	tp,48(sp)

0000000080040050 <d_3_3>:
    80040050:	a184                	fsd	fs1,0(a1)
    80040052:	5d66                	lw	s10,120(sp)
    80040054:	3d8e                	fld	fs11,224(sp)
    80040056:	78dc                	ld	a5,176(s1)
    80040058:	07c0                	addi	s0,sp,964
    8004005a:	fae9                	bnez	a3,8004002c <d_3_0+0xc>
    8004005c:	daec                	sw	a1,116(a3)
    8004005e:	f3f0                	sd	a2,224(a5)

0000000080040060 <d_3_4>:
    80040060:	cf748a6f          	jal	s4,7ff88d56 <_start-0x772aa>
    80040064:	2e5f bb59 efd8      	.insn	6, 0xefd8bb592e5f
    8004006a:	1359                	addi	t1,t1,-10
    8004006c:	a630                	fsd	fa2,72(a2)
    8004006e:	ed18                	sd	a4,24(a0)

0000000080040070 <d_3_5>:
    80040070:	3374                	fld	fa3,224(a4)
    80040072:	0d0d                	addi	s10,s10,3 # f639107d <_end+0x76330e7d>
    80040074:	8b06660f          	.insn	4, 0x8b06660f
    80040078:	b9ee9ec7          	fmsub.s	ft9,ft9,ft10,fs7,rtz
    8004007c:	4b0d                	li	s6,3
    8004007e:	9dfe                	add	s11,s11,t6

0000000080040080 <d_3_6>:
    80040080:	0752                	slli	a4,a4,0x14
    80040082:	2404                	fld	fs1,8(s0)
    80040084:	4ac1                	li	s5,16
    80040086:	d51a                	sw	t1,168(sp)
    80040088:	c48e                	sw	gp,72(sp)
    8004008a:	1621                	addi	a2,a2,-24
    8004008c:	7a9a                	ld	s5,416(sp)
    8004008e:	9519                	srai	a0,a0,0x26

0000000080040090 <d_3_7>:
    80040090:	6f81                	.insn	2, 0x6f81
    80040092:	5fdd                	li	t6,-9
    80040094:	985ddcd3          	.insn	4, 0x985ddcd3
    80040098:	0eaa                	slli	t4,t4,0xa
    8004009a:	636e874f          	fnmadd.d	fa4,ft9,fs6,fa2,rne
    8004009e:	fcc5                	bnez	s1,80040056 <d_3_3+0x6>

00000000800400a0 <d_3_8>:
    800400a0:	6fe2                	ld	t6,24(sp)
    800400a2:	4ec5                	li	t4,17
    800400a4:	6f68                	ld	a0,216(a4)
    800400a6:	8c88                	.insn	2, 0x8c88
    800400a8:	8f74                	.insn	2, 0x8f74
    800400aa:	3e40                	fld	fs0,184(a2)
    800400ac:	25de                	fld	fa1,464(sp)
    800400ae:	af34                	fsd	fa3,88(a4)

00000000800400b0 <d_3_9>:
    800400b0:	db88                	sw	a0,48(a5)
    800400b2:	b6dac53f bff1170c 	.insn	8, 0xbff1170cb6dac53f
    800400ba:	d1e4                	sw	s1,100(a1)
    800400bc:	ddc6                	sw	a7,248(sp)
    800400be:	fc18                	sd	a4,56(s0)

00000000800400c0 <d_3_10>:
    800400c0:	de3a3e37          	lui	t3,0xde3a3
    800400c4:	a9ea                	fsd	fs10,208(sp)
    800400c6:	c8d5                	beqz	s1,8004017a <d_3_21+0xa>
    800400c8:	757d                	lui	a0,0xfffff
    800400ca:	e215                	bnez	a2,800400ee <d_3_12+0xe>
    800400cc:	19c4                	addi	s1,sp,244
    800400ce:	ffad                	bnez	a5,80040048 <d_3_2+0x8>

00000000800400d0 <d_3_11>:
    800400d0:	ecff dffc dcd9 d61a 	.insn	22, 0x498381c05dd3b1b60fdc2d051788d61adcd9dffcecff
    800400d8:	1788 2d05 0fdc b1b6 
    800400e0:	   

00000000800400e0 <d_3_12>:
    800400e0:	81c05dd3          	.insn	4, 0x81c05dd3
    800400e4:	e9ba4983          	lbu	s3,-357(s4)
    800400e8:	4e82                	lw	t4,0(sp)
    800400ea:	ccf8                	sw	a4,92(s1)
    800400ec:	65824223          	.insn	4, 0x65824223

00000000800400f0 <d_3_13>:
    800400f0:	cc7c                	sw	a5,92(s0)
    800400f2:	a56e                	fsd	fs11,136(sp)
    800400f4:	0da6                	slli	s11,s11,0x9
    800400f6:	28e8                	fld	fa0,208(s1)
    800400f8:	ea3a                	sd	a4,272(sp)
    800400fa:	b69e                	fsd	ft7,360(sp)
    800400fc:	b2bc                	fsd	fa5,96(a3)
    800400fe:	a01f        	.insn	6, 0x1a7cd25da01f

0000000080040100 <d_3_14>:
    80040100:	d25d                	beqz	a2,800400a6 <d_3_8+0x6>
    80040102:	1a7c                	addi	a5,sp,316
    80040104:	d5e8                	sw	a0,108(a1)
    80040106:	7e90                	ld	a2,56(a3)
    80040108:	1862                	slli	a6,a6,0x38
    8004010a:	e481                	bnez	s1,80040112 <d_3_15+0x2>
    8004010c:	3b5f 018b       	.insn	6, 0x7aad018b3b5f

0000000080040110 <d_3_15>:
    80040110:	7aad                	lui	s5,0xfffeb
    80040112:	ed775703          	lhu	a4,-297(a4)
    80040116:	cc8a                	sw	sp,88(sp)
    80040118:	565c                	lw	a5,44(a2)
    8004011a:	4e3c                	lw	a5,88(a2)
    8004011c:	a5f4                	fsd	fa3,200(a1)
    8004011e:	          	.insn	4, 0xfd2c52fb

0000000080040120 <d_3_16>:
    80040120:	fd2c                	sd	a1,120(a0)
    80040122:	aa744707          	.insn	4, 0xaa744707
    80040126:	715b83c7          	fmsub.s	ft7,fs7,fs5,fa4,rne
    8004012a:	a1d8                	fsd	fa4,128(a1)
    8004012c:	327c                	fld	fa5,224(a2)
    8004012e:	9099                	srli	s1,s1,0x26

0000000080040130 <d_3_17>:
    80040130:	464e                	lw	a2,208(sp)
    80040132:	83fd3df3          	csrrc	s11,0x83f,s10
    80040136:	ecd1                	bnez	s1,800401d2 <d_3_27+0x2>
    80040138:	40f8                	lw	a4,68(s1)
    8004013a:	d5aa                	sw	a0,232(sp)
    8004013c:	b55e10bb          	.insn	4, 0xb55e10bb

0000000080040140 <d_3_18>:
    80040140:	2e24                	fld	fs1,88(a2)
    80040142:	82e1c92f          	.insn	4, 0x82e1c92f
    80040146:	6f76                	ld	t5,344(sp)
    80040148:	3e58da4b          	.insn	4, 0x3e58da4b
    8004014c:	42be                	lw	t0,204(sp)
    8004014e:	          	.insn	4, 0xa6da45af

0000000080040150 <d_3_19>:
    80040150:	a6da                	fsd	fs6,328(sp)
    80040152:	3c2a                	fld	fs8,168(sp)
    80040154:	6089                	lui	ra,0x2
    80040156:	33ca                	fld	ft7,176(sp)
    80040158:	2d2c                	fld	fa1,88(a0)
    8004015a:	a896                	fsd	ft5,80(sp)
    8004015c:	1281                	addi	t0,t0,-32 # bfe0 <_start-0x7fff4020>
    8004015e:	d969                	beqz	a0,80040130 <d_3_17>

0000000080040160 <d_3_20>:
    80040160:	920a                	add	tp,tp,sp
    80040162:	f9fc                	sd	a5,240(a1)
    80040164:	587a3e4b          	fnmsub.s	ft8,fs4,ft7,fa1,rup
    80040168:	3ff9                	addiw	t6,t6,-2
    8004016a:	24e9                	addiw	s1,s1,26
    8004016c:	df01                	beqz	a4,80040084 <d_3_6+0x4>
    8004016e:	417f    	.insn	18, 0x832ff4a98e2d7a94bbe662e573a1f88b417f
    80040176:	    
    8004017e:	 

0000000080040170 <d_3_21>:
    80040170:	73a1f88b          	.insn	4, 0x73a1f88b
    80040174:	62e5                	lui	t0,0x19
    80040176:	bbe6                	fsd	fs9,496(sp)
    80040178:	7a94                	ld	a3,48(a3)
    8004017a:	8e2d                	xor	a2,a2,a1
    8004017c:	f4a9                	bnez	s1,800400c6 <d_3_10+0x6>
    8004017e:	          	.insn	4, 0x8b9a832f

0000000080040180 <d_3_22>:
    80040180:	8b9a                	mv	s7,t1
    80040182:	df0bb597          	auipc	a1,0xdf0bb
    80040186:	c1c5                	beqz	a1,80040226 <_end_data3+0x26>
    80040188:	b792                	fsd	ft4,488(sp)
    8004018a:	3d24                	fld	fs1,120(a0)
    8004018c:	fc7f                	.insn	2, 0xfc7f
    8004018e:	579a                	lw	a5,164(sp)

0000000080040190 <d_3_23>:
    80040190:	4c9f a816 aaf5      	.insn	6, 0xaaf5a8164c9f
    80040196:	24a7ab87          	flw	fs7,586(a5)
    8004019a:	4ab364b7          	lui	s1,0x4ab36
    8004019e:	17b5                	addi	a5,a5,-19

00000000800401a0 <d_3_24>:
    800401a0:	d910                	sw	a2,48(a0)
    800401a2:	9056                	c.add	zero,s5
    800401a4:	59e49ea7          	.insn	4, 0x59e49ea7
    800401a8:	f0ca                	sd	s2,96(sp)
    800401aa:	2978                	fld	fa4,208(a0)
    800401ac:	c82647c7          	fmsub.s	fa5,fa2,ft2,fs9,rmm

00000000800401b0 <d_3_25>:
    800401b0:	00e4                	addi	s1,sp,76
    800401b2:	990d                	andi	a0,a0,-29
    800401b4:	525c                	lw	a5,36(a2)
    800401b6:	08b0                	addi	a2,sp,88
    800401b8:	efdc                	sd	a5,152(a5)
    800401ba:	c436                	sw	a3,8(sp)
    800401bc:	9d7d4733          	.insn	4, 0x9d7d4733

00000000800401c0 <d_3_26>:
    800401c0:	91e0becb          	fnmsub.s	ft9,ft1,ft10,fs2,rup
    800401c4:	4dda                	lw	s11,148(sp)
    800401c6:	d294                	sw	a3,32(a3)
    800401c8:	6a2e                	ld	s4,200(sp)
    800401ca:	7326                	ld	t1,104(sp)
    800401cc:	58e9241b          	.insn	4, 0x58e9241b

00000000800401d0 <d_3_27>:
    800401d0:	e72d1907          	.insn	4, 0xe72d1907
    800401d4:	afba                	fsd	fa4,472(sp)
    800401d6:	8d76                	mv	s10,t4
    800401d8:	538e                	lw	t2,224(sp)
    800401da:	b7dc37f3          	csrrc	a5,0xb7d,s8
    800401de:	ff00                	sd	s0,56(a4)
    800401e0:	cca0                	sw	s0,88(s1)
    800401e2:	cc102d37          	lui	s10,0xcc102
    800401e6:	a9d4                	fsd	fa3,144(a1)
    800401e8:	6ed53ccb          	.insn	4, 0x6ed53ccb
    800401ec:	2ed2                	fld	ft9,272(sp)
    800401ee:	1676ac8f          	.insn	4, 0x1676ac8f
    800401f2:	092746cf          	fnmadd.s	fa3,fa4,fs2,ft1,rmm
    800401f6:	84e5b6ab          	.insn	4, 0x84e5b6ab
    800401fa:	7e26                	ld	t3,104(sp)
    800401fc:	369e1b97          	auipc	s7,0x369e1

Disassembly of section .data.random4:

0000000080050000 <_random_data4>:
    80050000:	643e                	ld	s0,456(sp)
    80050002:	6d79                	lui	s10,0x1e
    80050004:	ccd1                	beqz	s1,800500a0 <d_4_8>
    80050006:	fc6dd1b3          	.insn	4, 0xfc6dd1b3
    8005000a:	7ff50903          	lb	s2,2047(a0) # fffffffffffff7ff <_end+0xffffffff7ff9f5ff>
    8005000e:	02a9                	addi	t0,t0,10 # 1900a <_start-0x7ffe6ff6>
    80050010:	0e19                	addi	t3,t3,6 # ffffffffde3a3006 <_end+0xffffffff5e342e06>
    80050012:	f599                	bnez	a1,8004ff20 <_end_data3+0xfd20>
    80050014:	33f5                	addiw	t2,t2,-3
    80050016:	3cf8                	fld	fa4,248(s1)
    80050018:	fce4                	sd	s1,248(s1)
    8005001a:	7620                	ld	s0,104(a2)
    8005001c:	297d                	addiw	s2,s2,31 # 501f <_start-0x7fffafe1>
    8005001e:	5469                	li	s0,-6

0000000080050020 <d_4_0>:
    80050020:	9701                	srai	a4,a4,0x20
    80050022:	b51c                	fsd	fa5,40(a0)
    80050024:	667a                	ld	a2,408(sp)
    80050026:	291d755b          	.insn	4, 0x291d755b
    8005002a:	19064de7          	.insn	4, 0x19064de7
    8005002e:	42d5                	li	t0,21

0000000080050030 <d_4_1>:
    80050030:	758c                	ld	a1,40(a1)
    80050032:	ae32                	fsd	fa2,280(sp)
    80050034:	5485                	li	s1,-31
    80050036:	fbf1                	bnez	a5,8005000a <_random_data4+0xa>
    80050038:	116d                	addi	sp,sp,-5
    8005003a:	03f4                	addi	a3,sp,460
    8005003c:	e0d4                	sd	a3,128(s1)
    8005003e:	1994                	addi	a3,sp,240

0000000080050040 <d_4_2>:
    80050040:	0006                	c.slli	zero,0x1
    80050042:	acec                	fsd	fa1,216(s1)
    80050044:	999e                	add	s3,s3,t2
    80050046:	9215                	srli	a2,a2,0x25
    80050048:	165c4443          	.insn	4, 0x165c4443
    8005004c:	995c                	.insn	2, 0x995c
    8005004e:	8474                	.insn	2, 0x8474

0000000080050050 <d_4_3>:
    80050050:	5349                	li	t1,-14
    80050052:	7efe                	ld	t4,504(sp)
    80050054:	cc00                	sw	s0,24(s0)
    80050056:	38ed                	addiw	a7,a7,-5
    80050058:	3106                	fld	ft2,96(sp)
    8005005a:	e3c6                	sd	a7,448(sp)
    8005005c:	796d                	lui	s2,0xffffb
    8005005e:	95f0                	.insn	2, 0x95f0

0000000080050060 <d_4_4>:
    80050060:	c7df 95f8 9104      	.insn	6, 0x910495f8c7df
    80050066:	d69a                	sw	t1,108(sp)
    80050068:	1014                	addi	a3,sp,32
    8005006a:	902c                	.insn	2, 0x902c
    8005006c:	c002                	sw	zero,0(sp)
    8005006e:	1ad0                	addi	a2,sp,372

0000000080050070 <d_4_5>:
    80050070:	bad57d4f          	fnmadd.d	fs10,fa0,fa3,fs7
    80050074:	e5c2                	sd	a6,200(sp)
    80050076:	13fe                	slli	t2,t2,0x3f
    80050078:	9a38f1e3          	bgeu	a7,gp,8004fa1a <_end_data3+0xf81a>
    8005007c:	e00a                	sd	sp,0(sp)
    8005007e:	b688                	fsd	fa0,40(a3)

0000000080050080 <d_4_6>:
    80050080:	6afc                	ld	a5,208(a3)
    80050082:	d662                	sw	s8,44(sp)
    80050084:	35ac                	fld	fa1,104(a1)
    80050086:	7365                	lui	t1,0xffff9
    80050088:	60faeda3          	.insn	4, 0x60faeda3
    8005008c:	a699                	j	800503d2 <_end_data4+0x1d2>
    8005008e:	5a65                	li	s4,-7

0000000080050090 <d_4_7>:
    80050090:	c444                	sw	s1,12(s0)
    80050092:	7b8c                	ld	a1,48(a5)
    80050094:	2339c8a3          	.insn	4, 0x2339c8a3
    80050098:	f344                	sd	s1,160(a4)
    8005009a:	dfb0                	sw	a2,120(a5)
    8005009c:	5272                	lw	tp,60(sp)
    8005009e:	fb45                	bnez	a4,8005004e <d_4_2+0xe>

00000000800500a0 <d_4_8>:
    800500a0:	8d90                	.insn	2, 0x8d90
    800500a2:	ae7ffb8b          	.insn	4, 0xae7ffb8b
    800500a6:	f686e143          	.insn	4, 0xf686e143
    800500aa:	0666                	slli	a2,a2,0x19
    800500ac:	db05                	beqz	a4,8004ffdc <_end_data3+0xfddc>
    800500ae:	          	.insn	4, 0xa134f9bb

00000000800500b0 <d_4_9>:
    800500b0:	a134                	fsd	fa3,64(a0)
    800500b2:	6c6c                	ld	a1,216(s0)
    800500b4:	db4ff87b          	.insn	4, 0xdb4ff87b
    800500b8:	2aa1                	addiw	s5,s5,8 # fffffffffffeb008 <_end+0xffffffff7ff8ae08>
    800500ba:	3eae96a7          	.insn	4, 0x3eae96a7
    800500be:	          	bltu	a4,sp,8004f4ee <_end_data3+0xf2ee>

00000000800500c0 <d_4_10>:
    800500c0:	4e77c227          	.insn	4, 0x4e77c227
    800500c4:	8da2                	mv	s11,s0
    800500c6:	29d9                	addiw	s3,s3,22 # 1016 <_start-0x7fffefea>
    800500c8:	714e6aef          	jal	s5,801367dc <_end+0xd65dc>
    800500cc:	2f58                	fld	fa4,152(a4)
    800500ce:	70b1                	lui	ra,0xfffec

00000000800500d0 <d_4_11>:
    800500d0:	bb3cfb23          	.insn	4, 0xbb3cfb23
    800500d4:	f176                	sd	t4,160(sp)
    800500d6:	fa1a8af3          	.insn	4, 0xfa1a8af3
    800500da:	c05a                	sw	s6,0(sp)
    800500dc:	0d19                	addi	s10,s10,6 # 1e006 <_start-0x7ffe1ffa>
    800500de:	48e2                	lw	a7,24(sp)

00000000800500e0 <d_4_12>:
    800500e0:	78a8                	ld	a0,112(s1)
    800500e2:	d91e                	sw	t2,176(sp)
    800500e4:	3871                	addiw	a6,a6,-4
    800500e6:	e026                	sd	s1,0(sp)
    800500e8:	6e88                	ld	a0,24(a3)
    800500ea:	98ac                	.insn	2, 0x98ac
    800500ec:	22ee                	fld	ft5,216(sp)
    800500ee:	2c61                	addiw	s8,s8,24

00000000800500f0 <d_4_13>:
    800500f0:	6140                	ld	s0,128(a0)
    800500f2:	093a                	slli	s2,s2,0xe
    800500f4:	095c                	addi	a5,sp,148
    800500f6:	2ba9                	addiw	s7,s7,10 # ffffffffb6a21206 <_end+0xffffffff369c1006>
    800500f8:	2e98                	fld	fa4,24(a3)
    800500fa:	7eed                	lui	t4,0xffffb
    800500fc:	1a9d                	addi	s5,s5,-25
    800500fe:	9aee                	add	s5,s5,s11

0000000080050100 <d_4_14>:
    80050100:	6602                	ld	a2,0(sp)
    80050102:	b3e8e627          	.insn	4, 0xb3e8e627
    80050106:	bade                	fsd	fs7,368(sp)
    80050108:	9091                	srli	s1,s1,0x24
    8005010a:	7ed9                	lui	t4,0xffff6
    8005010c:	157e                	slli	a0,a0,0x3f
    8005010e:	8471                	srai	s0,s0,0x1c

0000000080050110 <d_4_15>:
    80050110:	b570                	fsd	fa2,232(a0)
    80050112:	7825                	lui	a6,0xfffe9
    80050114:	9e6c                	.insn	2, 0x9e6c
    80050116:	0b78                	addi	a4,sp,412
    80050118:	4b7f d05b 11ab 2c10 	.insn	18, 0xc276e3d71a5b2e76f8392c1011abd05b4b7f
    80050120:	    
    80050128:	 

0000000080050120 <d_4_16>:
    80050120:	f839                	bnez	s0,80050076 <d_4_5+0x6>
    80050122:	2e76                	fld	ft8,344(sp)
    80050124:	e3d71a5b          	.insn	4, 0xe3d71a5b
    80050128:	c276                	sw	t4,4(sp)
    8005012a:	fb84                	sd	s1,48(a5)
    8005012c:	fdd02593          	slti	a1,zero,-35

0000000080050130 <d_4_17>:
    80050130:	9262                	add	tp,tp,s8
    80050132:	d415                	beqz	s0,8005005e <d_4_3+0xe>
    80050134:	363a9e03          	lh	t3,867(s5)
    80050138:	ac9200a3          	sb	s1,-1343(tp) # fffffffffffdfac1 <_end+0xffffffff7ff7f8c1>
    8005013c:	6a39                	lui	s4,0xe
    8005013e:	cff9                	beqz	a5,8005021c <_end_data4+0x1c>

0000000080050140 <d_4_18>:
    80050140:	9181                	srli	a1,a1,0x20
    80050142:	49fa76b3          	.insn	4, 0x49fa76b3
    80050146:	7c89                	lui	s9,0xfffe2
    80050148:	9c3ad55b          	.insn	4, 0x9c3ad55b
    8005014c:	f36e                	sd	s11,416(sp)
    8005014e:	b254                	fsd	fa3,160(a2)

0000000080050150 <d_4_19>:
    80050150:	86d2                	mv	a3,s4
    80050152:	033c                	addi	a5,sp,392
    80050154:	335e                	fld	ft6,496(sp)
    80050156:	5de8                	lw	a0,124(a1)
    80050158:	dca62937          	lui	s2,0xdca62
    8005015c:	db94                	sw	a3,48(a5)
    8005015e:	b52c                	fsd	fa1,104(a0)

0000000080050160 <d_4_20>:
    80050160:	1cad                	addi	s9,s9,-21 # fffffffffffe1feb <_end+0xffffffff7ff81deb>
    80050162:	c3a2                	sw	s0,196(sp)
    80050164:	dbe6cd1b          	.insn	4, 0xdbe6cd1b
    80050168:	1685                	addi	a3,a3,-31
    8005016a:	380c31c7          	fmsub.s	ft3,fs8,ft0,ft7,rup
    8005016e:	          	.insn	4, 0x1ecea1db

0000000080050170 <d_4_21>:
    80050170:	1ece                	slli	t4,t4,0x33
    80050172:	1975                	addi	s2,s2,-3 # ffffffffdca61ffd <_end+0xffffffff5ca01dfd>
    80050174:	0896fe4b          	fnmsub.s	ft8,fa3,fs1,ft1
    80050178:	cda6                	sw	s1,216(sp)
    8005017a:	f99a                	sd	t1,240(sp)
    8005017c:	cca4                	sw	s1,88(s1)
    8005017e:	          	csrrwi	s5,mhpmcounter24h,7

0000000080050180 <d_4_22>:
    80050180:	6753b983          	ld	s3,1653(t2)
    80050184:	34ca60e7          	.insn	4, 0x34ca60e7
    80050188:	ad4a86bf 1362efad 	.insn	8, 0x1362efadad4a86bf

0000000080050190 <d_4_23>:
    80050190:	f321                	bnez	a4,800500d0 <d_4_11>
    80050192:	b425                	j	8004fbba <_end_data3+0xf9ba>
    80050194:	22f5b9d7          	.insn	4, 0x22f5b9d7
    80050198:	95a6                	add	a1,a1,s1
    8005019a:	8824                	.insn	2, 0x8824
    8005019c:	dad35f23          	.insn	4, 0xdad35f23

00000000800501a0 <d_4_24>:
    800501a0:	6e30                	ld	a2,88(a2)
    800501a2:	dd54                	sw	a3,60(a0)
    800501a4:	c3036c53          	.insn	4, 0xc3036c53
    800501a8:	701d                	c.lui	zero,0xfffe7
    800501aa:	da007fd3          	.insn	4, 0xda007fd3
    800501ae:	          	.insn	4, 0x05a99dfb

00000000800501b0 <d_4_25>:
    800501b0:	05a9                	addi	a1,a1,10 # 5f0fb18c <_start-0x20f04e74>
    800501b2:	78c4                	ld	s1,176(s1)
    800501b4:	2334                	fld	fa3,64(a4)
    800501b6:	d958                	sw	a4,52(a0)
    800501b8:	58b6                	lw	a7,108(sp)
    800501ba:	bb11                	j	8004fece <_end_data3+0xfcce>
    800501bc:	9fe2                	add	t6,t6,s8
    800501be:	fc5a                	sd	s6,56(sp)

00000000800501c0 <d_4_26>:
    800501c0:	43e9                	li	t2,26
    800501c2:	84d13d43          	.insn	4, 0x84d13d43
    800501c6:	c27e                	sw	t6,4(sp)
    800501c8:	9a39                	andi	a2,a2,-18
    800501ca:	3cf8e3b3          	.insn	4, 0x3cf8e3b3
    800501ce:	a915                	j	80050602 <_end_data4+0x402>

00000000800501d0 <d_4_27>:
    800501d0:	4441                	li	s0,16
    800501d2:	c0e4                	sw	s1,68(s1)
    800501d4:	54d2                	lw	s1,52(sp)
    800501d6:	158a                	slli	a1,a1,0x22
    800501d8:	312c318f          	.insn	4, 0x312c318f
    800501dc:	45a0                	lw	s0,72(a1)
    800501de:	de9d                	beqz	a3,8005011c <d_4_15+0xc>
    800501e0:	9889                	andi	s1,s1,-30
    800501e2:	37a4                	fld	fs1,104(a5)
    800501e4:	9798                	.insn	2, 0x9798
    800501e6:	0eb8                	addi	a4,sp,856
    800501e8:	fd68                	sd	a0,248(a0)
    800501ea:	0cc0                	addi	s0,sp,596
    800501ec:	7f48                	ld	a0,184(a4)
    800501ee:	a22d                	j	80050318 <_end_data4+0x118>
    800501f0:	4f638d27          	vsoxseg3ei8.v	v26,(t2),v22
    800501f4:	9f5a                	add	t5,t5,s6
    800501f6:	ac55                	j	800504aa <_end_data4+0x2aa>
    800501f8:	5eddbf77          	.insn	4, 0x5eddbf77
    800501fc:	0588                	addi	a0,sp,704
    800501fe:	cf78                	sw	a4,92(a4)

Disassembly of section .data.random5:

0000000080060000 <_random_data5>:
    80060000:	71c6745b          	.insn	4, 0x71c6745b
    80060004:	f0c0                	sd	s0,160(s1)
    80060006:	6c18e78f          	.insn	4, 0x6c18e78f
    8006000a:	0c0c                	addi	a1,sp,528
    8006000c:	ac99                	j	80060262 <_end+0x62>
    8006000e:	f28a                	sd	sp,352(sp)
    80060010:	09da                	slli	s3,s3,0x16
    80060012:	4f6e                	lw	t5,216(sp)
    80060014:	145f0b63          	beq	t5,t0,8006016a <d_5_20+0xa>
    80060018:	4c80                	lw	s0,24(s1)
    8006001a:	2de6                	fld	fs11,88(sp)
    8006001c:	57a6                	lw	a5,104(sp)
    8006001e:	42fa                	lw	t0,156(sp)

0000000080060020 <d_5_0>:
    80060020:	f04b3ecb          	fnmsub.s	ft9,fs6,ft4,ft10,rup
    80060024:	fbe5                	bnez	a5,80060014 <_random_data5+0x14>
    80060026:	5f52                	lw	t5,52(sp)
    80060028:	f9a5                	bnez	a1,8005ff98 <_end_data4+0xfd98>
    8006002a:	1e7a                	slli	t3,t3,0x3e
    8006002c:	d4e1                	beqz	s1,8005fff4 <_end_data4+0xfdf4>
    8006002e:	          	.insn	4, 0xb6d8d81b

0000000080060030 <d_5_1>:
    80060030:	b6d8                	fsd	fa4,168(a3)
    80060032:	d664                	sw	s1,108(a2)
    80060034:	15afc917          	auipc	s2,0x15afc
    80060038:	6b5d                	lui	s6,0x17
    8006003a:	097a                	slli	s2,s2,0x1e
    8006003c:	2864                	fld	fs1,208(s0)
    8006003e:	bffe                	fsd	ft11,504(sp)

0000000080060040 <d_5_2>:
    80060040:	2c04                	fld	fs1,24(s0)
    80060042:	5c54                	lw	a3,60(s0)
    80060044:	f1cd                	bnez	a1,8005ffe6 <_end_data4+0xfde6>
    80060046:	e61b1db3          	.insn	4, 0xe61b1db3
    8006004a:	86a144b3          	.insn	4, 0x86a144b3
    8006004e:	f988                	sd	a0,48(a1)

0000000080060050 <d_5_3>:
    80060050:	d5fa75bb          	.insn	4, 0xd5fa75bb
    80060054:	17c66363          	bltu	a2,t3,800601ba <d_5_25+0xa>
    80060058:	602a                	.insn	2, 0x602a
    8006005a:	f97e                	sd	t6,176(sp)
    8006005c:	53c6                	lw	t2,112(sp)
    8006005e:	          	.insn	4, 0xab42f65b

0000000080060060 <d_5_4>:
    80060060:	ab42                	fsd	fa6,400(sp)
    80060062:	c3e0                	sw	s0,68(a5)
    80060064:	e610                	sd	a2,8(a2)
    80060066:	00fe                	slli	ra,ra,0x1f
    80060068:	d964                	sw	s1,116(a0)
    8006006a:	c872                	sw	t3,16(sp)
    8006006c:	ede6                	sd	s9,216(sp)
    8006006e:	          	.insn	4, 0x7863d333

0000000080060070 <d_5_5>:
    80060070:	bc957863          	bgeu	a0,s1,8005f440 <_end_data4+0xf240>
    80060074:	ce62                	sw	s8,28(sp)
    80060076:	b3b1                	j	8005fdc2 <_end_data4+0xfbc2>
    80060078:	0a46                	slli	s4,s4,0x11
    8006007a:	8b82                	jr	s7
    8006007c:	1679                	addi	a2,a2,-2
    8006007e:	26c2                	fld	fa3,16(sp)

0000000080060080 <d_5_6>:
    80060080:	cdac                	sw	a1,88(a1)
    80060082:	548a                	lw	s1,160(sp)
    80060084:	a5f5                	j	80060770 <_end+0x570>
    80060086:	52ae                	lw	t0,232(sp)
    80060088:	5972                	lw	s2,60(sp)
    8006008a:	ee42                	sd	a6,280(sp)
    8006008c:	519f 7e7a       	.insn	6, 0xda747e7a519f

0000000080060090 <d_5_7>:
    80060090:	da74                	sw	a3,116(a2)
    80060092:	597d                	li	s2,-1
    80060094:	aad5                	j	80060288 <_end+0x88>
    80060096:	647f 32ad a5b8 d971 	.insn	22, 0x38b15015cc998c2f2b5eb7351fb9d971a5b832ad647f
    8006009e:	1fb9    
    800600a6:	   

00000000800600a0 <d_5_8>:
    800600a0:	b735                	j	8005ffcc <_end_data4+0xfdcc>
    800600a2:	2b5e                	fld	fs6,464(sp)
    800600a4:	cc998c2f          	.insn	4, 0xcc998c2f
    800600a8:	5015                	c.li	zero,-27
    800600aa:	38b1                	addiw	a7,a7,-20
    800600ac:	a50169eb          	.insn	4, 0xa50169eb

00000000800600b0 <d_5_9>:
    800600b0:	890d3b87          	fld	fs7,-1904(s10)
    800600b4:	7e99                	lui	t4,0xfffe6
    800600b6:	72ba                	ld	t0,424(sp)
    800600b8:	9ffe                	add	t6,t6,t6
    800600ba:	35d5                	addiw	a1,a1,-11
    800600bc:	405da58b          	.insn	4, 0x405da58b

00000000800600c0 <d_5_10>:
    800600c0:	0650                	addi	a2,sp,772
    800600c2:	f0d1                	bnez	s1,80060046 <d_5_2+0x6>
    800600c4:	0a85026b          	.insn	4, 0x0a85026b
    800600c8:	2a4d                	addiw	s4,s4,19 # e013 <_start-0x7fff1fed>
    800600ca:	4465                	li	s0,25
    800600cc:	2516                	fld	fa0,320(sp)
    800600ce:	0765                	addi	a4,a4,25

00000000800600d0 <d_5_11>:
    800600d0:	b035                	j	8005f8fc <_end_data4+0xf6fc>
    800600d2:	4819                	li	a6,6
    800600d4:	6bd33d6f          	jal	s10,80093f90 <_end+0x33d90>
    800600d8:	c4370fd7          	vwredsum.vs	v31,v3,v14,v0.t
    800600dc:	0291497b          	.insn	4, 0x0291497b

00000000800600e0 <d_5_12>:
    800600e0:	69ba                	ld	s3,392(sp)
    800600e2:	7645                	lui	a2,0xffff1
    800600e4:	9942                	add	s2,s2,a6
    800600e6:	c0da586f          	jal	a6,80005cf2 <end_signature+0x3912>
    800600ea:	fb9e                	sd	t2,496(sp)
    800600ec:	706c8be3          	beq	s9,t1,80061002 <_end+0xe02>

00000000800600f0 <d_5_13>:
    800600f0:	66af34a7          	fsd	fa0,1641(t5)
    800600f4:	fdee                	sd	s11,248(sp)
    800600f6:	7dc1                	lui	s11,0xffff0
    800600f8:	7a36                	ld	s4,360(sp)
    800600fa:	03350de7          	jalr	s11,51(a0)
    800600fe:	4ed6                	lw	t4,84(sp)

0000000080060100 <d_5_14>:
    80060100:	2fa0                	fld	fs0,88(a5)
    80060102:	b276                	fsd	ft9,288(sp)
    80060104:	3fc6                	fld	ft11,112(sp)
    80060106:	953c                	.insn	2, 0x953c
    80060108:	1b7c                	addi	a5,sp,444
    8006010a:	0f6c                	addi	a1,sp,924
    8006010c:	c79f c864       	.insn	6, 0x769ec864c79f

0000000080060110 <d_5_15>:
    80060110:	769e                	ld	a3,480(sp)
    80060112:	08d79db7          	lui	s11,0x8d79
    80060116:	d908                	sw	a0,48(a0)
    80060118:	e87a                	sd	t5,16(sp)
    8006011a:	b548                	fsd	fa0,168(a0)
    8006011c:	b261                	j	8005faa4 <_end_data4+0xf8a4>
    8006011e:	5fc2                	lw	t6,48(sp)

0000000080060120 <d_5_16>:
    80060120:	21ca                	fld	ft3,144(sp)
    80060122:	2196                	fld	ft3,320(sp)
    80060124:	2ed566a7          	vsoxseg2ei32.v	v13,(a0),v13
    80060128:	e7155dc3          	.insn	4, 0xe7155dc3
    8006012c:	b42f02b7          	lui	t0,0xb42f0

0000000080060130 <d_5_17>:
    80060130:	87ff 07ad a5b1 008d 	.insn	10, 0xbfa2008da5b107ad87ff
    80060138:	bfa2 
    8006013a:	d86d                	beqz	s0,8006012c <d_5_16+0xc>
    8006013c:	1861                	addi	a6,a6,-8 # fffffffffffe8ff8 <_end+0xffffffff7ff88df8>
    8006013e:	7451                	lui	s0,0xffff4

0000000080060140 <d_5_18>:
    80060140:	ddf435f3          	csrrc	a1,0xddf,s0
    80060144:	6712                	ld	a4,256(sp)
    80060146:	2554                	fld	fa3,136(a0)
    80060148:	f210                	sd	a2,32(a2)
    8006014a:	2281dd53          	.insn	4, 0x2281dd53
    8006014e:	3394                	fld	fa3,32(a5)

0000000080060150 <d_5_19>:
    80060150:	834fdbbb          	.insn	4, 0x834fdbbb
    80060154:	78b34907          	.insn	4, 0x78b34907
    80060158:	ff1c                	sd	a5,56(a4)
    8006015a:	fb51                	bnez	a4,800600ee <d_5_12+0xe>
    8006015c:	e2883433          	.insn	4, 0xe2883433

0000000080060160 <d_5_20>:
    80060160:	051a67fb          	.insn	4, 0x051a67fb
    80060164:	b1a5                	j	8005fdcc <_end_data4+0xfbcc>
    80060166:	d0e4                	sw	s1,100(s1)
    80060168:	70b968b7          	lui	a7,0x70b96
    8006016c:	2dbc                	fld	fa5,88(a1)
    8006016e:	eb92                	sd	tp,464(sp)

0000000080060170 <d_5_21>:
    80060170:	423d                	li	tp,15
    80060172:	3d82                	fld	fs11,32(sp)
    80060174:	c78d42d3          	.insn	4, 0xc78d42d3
    80060178:	8e80                	.insn	2, 0x8e80
    8006017a:	77a199d3          	.insn	4, 0x77a199d3
    8006017e:	97a0                	.insn	2, 0x97a0

0000000080060180 <d_5_22>:
    80060180:	c9ec                	sw	a1,84(a1)
    80060182:	3461                	addiw	s0,s0,-8 # ffffffffffff3ff8 <_end+0xffffffff7ff93df8>
    80060184:	0278                	addi	a4,sp,268
    80060186:	21b21f73          	csrrw	t5,0x21b,tp
    8006018a:	96e6                	add	a3,a3,s9
    8006018c:	f614                	sd	a3,40(a2)
    8006018e:	          	.insn	4, 0x76ff8d87

0000000080060190 <d_5_23>:
    80060190:	76ff                	.insn	2, 0x76ff
    80060192:	e29d                	bnez	a3,800601b8 <d_5_25+0x8>
    80060194:	b79c                	fsd	fa5,40(a5)
    80060196:	f895                	bnez	s1,800600ca <d_5_10+0xa>
    80060198:	b4f0                	fsd	fa2,232(s1)
    8006019a:	2de8                	fld	fa0,216(a1)
    8006019c:	471d2e2f          	amoor.w.aqrl	t3,a7,(s10)

00000000800601a0 <d_5_24>:
    800601a0:	796e5797          	auipc	a5,0x796e5
    800601a4:	2634287b          	.insn	4, 0x2634287b
    800601a8:	cf80                	sw	s0,24(a5)
    800601aa:	ceae                	sw	a1,92(sp)
    800601ac:	d80e                	sw	gp,48(sp)
    800601ae:	8142                	mv	sp,a6

00000000800601b0 <d_5_25>:
    800601b0:	2add07bb          	.insn	4, 0x2add07bb
    800601b4:	478d                	li	a5,3
    800601b6:	ca886cd7          	vwsubu.vx	v25,v8,a6
    800601ba:	82c828fb          	.insn	4, 0x82c828fb
    800601be:	          	.insn	4, 0x3155d20f

00000000800601c0 <d_5_26>:
    800601c0:	3155                	addiw	sp,sp,-11
    800601c2:	a328                	fsd	fa0,64(a4)
    800601c4:	89ad                	andi	a1,a1,11
    800601c6:	0d980cfb          	.insn	4, 0x0d980cfb
    800601ca:	36c5                	addiw	a3,a3,-15
    800601cc:	bfd0536f          	jal	t1,7ff65dc8 <_start-0x9a238>

00000000800601d0 <d_5_27>:
    800601d0:	a36a                	fsd	fs10,384(sp)
    800601d2:	0459                	addi	s0,s0,22
    800601d4:	bf19                	j	800600ea <d_5_12+0xa>
    800601d6:	2111                	addiw	sp,sp,4
    800601d8:	4e08                	lw	a0,24(a2)
    800601da:	e3b5                	bnez	a5,8006023e <_end+0x3e>
    800601dc:	93cd                	srli	a5,a5,0x33
    800601de:	4f0c                	lw	a1,24(a4)
    800601e0:	6f8d                	lui	t6,0x3
    800601e2:	e5abf7a7          	vsuxseg8ei64.v	v15,(s7),v26,v0.t
    800601e6:	d3bc                	sw	a5,96(a5)
    800601e8:	97b9                	srai	a5,a5,0x2e
    800601ea:	810d4f7b          	.insn	4, 0x810d4f7b
    800601ee:	1f09                	addi	t5,t5,-30
    800601f0:	8e7efe73          	csrrci	t3,0x8e7,29
    800601f4:	7b42                	ld	s6,48(sp)
    800601f6:	8555                	srai	a0,a0,0x15
    800601f8:	1279                	addi	tp,tp,-2 # fffffffffffffffe <_end+0xffffffff7ff9fdfe>
    800601fa:	84fb0bcb          	.insn	4, 0x84fb0bcb
    800601fe:	888b                	.short	0x888b

Disassembly of section .riscv.attributes:

0000000000000000 <.riscv.attributes>:
   0:	ee41                	bnez	a2,98 <_start-0x7fffff68>
   2:	0000                	unimp
   4:	7200                	ld	s0,32(a2)
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <_start-0x7fffffec>
   c:	00e4                	addi	s1,sp,76
   e:	0000                	unimp
  10:	7205                	lui	tp,0xfffe1
  12:	3676                	fld	fa2,376(sp)
  14:	6934                	ld	a3,80(a0)
  16:	7032                	.insn	2, 0x7032
  18:	5f31                	li	t5,-20
  1a:	326d                	addiw	tp,tp,-5 # fffffffffffe0ffb <_end+0xffffffff7ff80dfb>
  1c:	3070                	fld	fa2,224(s0)
  1e:	615f 7032 5f31      	.insn	6, 0x5f317032615f
  24:	3266                	fld	ft4,120(sp)
  26:	3270                	fld	fa2,224(a2)
  28:	645f 7032 5f32      	.insn	6, 0x5f327032645f
  2e:	30703263          	.insn	4, 0x30703263
  32:	765f 7031 5f30      	.insn	6, 0x5f307031765f
  38:	3168                	fld	fa0,224(a0)
  3a:	3070                	fld	fa2,224(s0)
  3c:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  42:	316d                	addiw	sp,sp,-5
  44:	3070                	fld	fa2,224(s0)
  46:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  4c:	3170                	fld	fa2,224(a0)
  4e:	3070                	fld	fa2,224(s0)
  50:	7a5f 6369 6f62      	.insn	6, 0x6f6263697a5f
  56:	317a                	fld	ft2,440(sp)
  58:	3070                	fld	fa2,224(s0)
  5a:	7a5f 6369 7273      	.insn	6, 0x727363697a5f
  60:	7032                	.insn	2, 0x7032
  62:	5f30                	lw	a2,120(a4)
  64:	697a                	ld	s2,408(sp)
  66:	6566                	ld	a0,88(sp)
  68:	636e                	ld	t1,216(sp)
  6a:	6965                	lui	s2,0x19
  6c:	7032                	.insn	2, 0x7032
  6e:	5f30                	lw	a2,120(a4)
  70:	6d7a                	ld	s10,408(sp)
  72:	756d                	lui	a0,0xffffb
  74:	316c                	fld	fa1,224(a0)
  76:	3070                	fld	fa2,224(s0)
  78:	7a5f 6161 6f6d      	.insn	6, 0x6f6d61617a5f
  7e:	7031                	c.lui	zero,0xfffec
  80:	5f30                	lw	a2,120(a4)
  82:	617a                	ld	sp,408(sp)
  84:	726c                	ld	a1,224(a2)
  86:	70316373          	csrrsi	t1,0x703,2
  8a:	5f30                	lw	a2,120(a4)
  8c:	637a                	ld	t1,408(sp)
  8e:	3161                	addiw	sp,sp,-8
  90:	3070                	fld	fa2,224(s0)
  92:	7a5f 6463 7031      	.insn	6, 0x703164637a5f
  98:	5f30                	lw	a2,120(a4)
  9a:	767a                	ld	a2,440(sp)
  9c:	3365                	addiw	t1,t1,-7 # ffffffffffff9ff9 <_end+0xffffffff7ff99df9>
  9e:	6632                	ld	a2,264(sp)
  a0:	7031                	c.lui	zero,0xfffec
  a2:	5f30                	lw	a2,120(a4)
  a4:	767a                	ld	a2,440(sp)
  a6:	3365                	addiw	t1,t1,-7
  a8:	7832                	ld	a6,296(sp)
  aa:	7031                	c.lui	zero,0xfffec
  ac:	5f30                	lw	a2,120(a4)
  ae:	767a                	ld	a2,440(sp)
  b0:	3665                	addiw	a2,a2,-7 # ffffffffffff0ff9 <_end+0xffffffff7ff90df9>
  b2:	6434                	ld	a3,72(s0)
  b4:	7031                	c.lui	zero,0xfffec
  b6:	5f30                	lw	a2,120(a4)
  b8:	767a                	ld	a2,440(sp)
  ba:	3665                	addiw	a2,a2,-7
  bc:	6634                	ld	a3,72(a2)
  be:	7031                	c.lui	zero,0xfffec
  c0:	5f30                	lw	a2,120(a4)
  c2:	767a                	ld	a2,440(sp)
  c4:	3665                	addiw	a2,a2,-7
  c6:	7834                	ld	a3,112(s0)
  c8:	7031                	c.lui	zero,0xfffec
  ca:	5f30                	lw	a2,120(a4)
  cc:	767a                	ld	a2,440(sp)
  ce:	316c                	fld	fa1,224(a0)
  d0:	3832                	fld	fa6,296(sp)
  d2:	3162                	fld	ft2,56(sp)
  d4:	3070                	fld	fa2,224(s0)
  d6:	7a5f 6c76 3233      	.insn	6, 0x32336c767a5f
  dc:	3162                	fld	ft2,56(sp)
  de:	3070                	fld	fa2,224(s0)
  e0:	7a5f 6c76 3436      	.insn	6, 0x34366c767a5f
  e6:	3162                	fld	ft2,56(sp)
  e8:	3070                	fld	fa2,224(s0)
  ea:	0800                	addi	s0,sp,16
  ec:	0a01                	addi	s4,s4,0
  ee:	0b                	.byte	0x0b
