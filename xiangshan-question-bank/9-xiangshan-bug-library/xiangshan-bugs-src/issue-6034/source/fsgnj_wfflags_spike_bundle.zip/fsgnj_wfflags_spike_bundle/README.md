# fsgnj_wfflags Spike difftest bundle

This bundle captures the `vfsgnj.vv` FS dirty mismatch reproduced with Spike as the difftest reference.

## Key failure

Instruction under test:

```text
pc 0x80000054, inst 0x22219257, vfsgnj.vv v4, v2, v3
```

Spike REF keeps `FS=Initial, VS=Dirty`:

```text
mstatus right = 0x8000000a00002600
sstatus right = 0x8000000200002600
```

DUT reports `FS=Dirty, VS=Dirty`:

```text
mstatus wrong = 0x8000000a00006600
sstatus wrong = 0x8000000200006600
```

## Reproduce

Run from `/nfs/home/nanyunhao`:

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/verilator-compile/emu \
  -b 0 -e 9000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/bin/fsgnj_wfflags_difftest.bin \
  --diff /nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/ref/riscv64-spike-so \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/wave/fsgnj_wfflags_spike.fst
```

## Contents

- `logs/fsgnj_wfflags_spike.log`: Spike difftest failure without waveform.
- `logs/fsgnj_wfflags_spike_wave.log`: Spike difftest failure from the waveform run.
- `logs/spike_error_excerpt.txt`: minimal CSR mismatch excerpt.
- `instr/commit_instr_trace_spike.txt`: commit instruction trace around the abort.
- `instr/commit_group_trace_spike.txt`: commit group trace around the abort.
- `instr/fsgnj_wfflags_difftest.objdump.txt`: ELF disassembly.
- `instr/fsgnj_wfflags_difftest.build_txt`: build-generated instruction listing.
- `wave/fsgnj_wfflags_spike.fst`: Verilator FST waveform, covering the failure at `cycleCnt = 8424`.
- `src/fsgnj_wfflags_difftest.S`: source testcase.
- `bin/fsgnj_wfflags_difftest.{elf,bin}`: testcase artifacts.
- `ref/riscv64-spike-so`: Spike difftest reference library used for reproduction.
