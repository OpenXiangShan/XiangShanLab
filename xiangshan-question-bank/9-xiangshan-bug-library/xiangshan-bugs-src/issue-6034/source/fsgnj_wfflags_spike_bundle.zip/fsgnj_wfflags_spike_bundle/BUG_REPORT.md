# Bug Report: `vfsgnj.vv` incorrectly dirties `mstatus.FS`

## Branch

`master (kunminghu-v2)`

## Describe the Bug

Buggy decode/commit interaction around `wfflags` and `dirtyFs`.

The instruction `vfsgnj.vv` is currently included in `wfflagsInsts`:

```scala
VFSGNJ_VV, VFSGNJN_VV, VFSGNJX_VV,
```

This causes `decodedInst.wfflags` to be asserted for `vfsgnj.vv`.

Later, ROB commit treats any instruction with `wflags` as dirtying the scalar floating-point state:

```scala
robCommitEntry.dirtyFs := robEntry.fpWen || robEntry.wflags
```

So even though `vfsgnj.vv` writes only a vector register and does not write scalar FP registers or `fflags`, the DUT marks `mstatus.FS` as Dirty after the instruction retires.

The failing instruction in this testcase is:

```text
pc 0x80000054, inst 0x22219257, vfsgnj.vv v4, v2, v3
```

Spike reference reports the expected status after the instruction:

```text
mstatus = 0x8000000a00002600
sstatus = 0x8000000200002600
```

This encodes:

```text
FS = Initial
VS = Dirty
```

The DUT reports:

```text
mstatus = 0x8000000a00006600
sstatus = 0x8000000200006600
```

This encodes:

```text
FS = Dirty
VS = Dirty
```

So the DUT incorrectly dirties scalar FP state (`FS`) when retiring `vfsgnj.vv`.

## Expected Behavior

For `vfsgnj.vv v4, v2, v3`:

- `VS` should become Dirty, because the instruction writes vector register `v4`.
- `FS` should remain Initial, because the instruction does not write scalar FP registers or `fflags`.
- `fflags` should remain unchanged.

Expected status after the instruction:

```text
mstatus FS=Initial, VS=Dirty
mstatus low status bits = 0x2600
```

## Actual Behavior

DUT status after retiring `vfsgnj.vv`:

```text
mstatus low status bits = 0x6600
```

That means:

```text
FS=Dirty, VS=Dirty
```

This mismatches Spike:

```text
mstatus different at pc = 0xca57146625f1, right = 0x8000000a00002600, wrong = 0x8000000a00006600
sstatus different at pc = 0xca57146625f1, right = 0x8000000200002600, wrong = 0x8000000200006600
Core 0: ABORT
```

## Suspected Root Cause

The decode table marks `VFSGNJ_*` as `wfflags`, but sign-injection instructions do not produce floating-point exception flags.

Because `wfflags` is later converted into `dirtyFs`, this over-approximated decode bit becomes architecturally visible:

```text
VFSGNJ_VV -> decodedInst.wfflags = 1
decodedInst.wfflags -> robEntry.wflags = 1
robEntry.wflags -> robCommitEntry.dirtyFs = 1
dirtyFs -> mstatus.FS := Dirty
```

Relevant local code:

- `/nfs/home/nanyunhao/XiangShan_V2/src/main/scala/xiangshan/backend/decode/DecodeUnit.scala`
  - `wfflagsInsts` includes `VFSGNJ_VV`, `VFSGNJN_VV`, `VFSGNJX_VV`.
  - `decodedInst.wfflags := wfflagsInsts.map(_ === inst.ALL).reduce(_ || _)`
- `/nfs/home/nanyunhao/XiangShan_V2/src/main/scala/xiangshan/backend/rob/RobBundles.scala`
  - `robCommitEntry.dirtyFs := robEntry.fpWen || robEntry.wflags`
- `/nfs/home/nanyunhao/XiangShan_V2/src/main/scala/xiangshan/backend/fu/CSR.scala`
  - `csrio.fpu.dirty_fs` causes `mstatus.fs := "b11".U`

## Environment

Branch: `kunminghu-v2`

Reference model used for reproduction:

```text
/nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/ref/riscv64-spike-so
```

## To Reproduce

Bundle path:

```text
/nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle
```

Run:

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/verilator-compile/emu \
  -b 0 -e 9000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/bin/fsgnj_wfflags_difftest.bin \
  --diff /nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/ref/riscv64-spike-so \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/NANYUNHAO/fsgnj_wfflags_spike_bundle/wave/fsgnj_wfflags_spike.fst
```

Failure point:

```text
Core-0 instrCnt = 45, cycleCnt = 8424
```

## Attached Evidence

- `logs/fsgnj_wfflags_spike.log`: Spike difftest failure without waveform.
- `logs/fsgnj_wfflags_spike_wave.log`: Spike difftest failure with waveform dump.
- `logs/spike_error_excerpt.txt`: minimal CSR mismatch excerpt.
- `instr/commit_instr_trace_spike.txt`: commit instruction trace showing `vfsgnj.vv`.
- `instr/fsgnj_wfflags_difftest.objdump.txt`: ELF disassembly.
- `wave/fsgnj_wfflags_spike.fst`: waveform covering the mismatch at `cycleCnt = 8424`.
- `src/fsgnj_wfflags_difftest.S`: source testcase.

## Additional Context

Stock NEMU does not expose this mismatch for this testcase because its current `vfsgnj` path also dirties `FS`, so REF and DUT agree on the same incorrect state. Spike exposes the issue directly.
