#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path


SIGNALS = {
    "valid": ("_backend_io_frontend_toFtq_redirect_valid",),
    "pc": ("_backend_io_frontend_toFtq_redirect_bits_pc",),
    "target": ("_backend_io_frontend_toFtq_redirect_bits_target",),
    "isRVC": ("_backend_io_frontend_toFtq_redirect_bits_isRVC",),
    "ftqOffset": ("_backend_io_frontend_toFtq_redirect_bits_ftqOffset",),
    "isMisPred": ("_backend_io_frontend_toFtq_redirect_bits_isMisPred",),
    "taken": ("_backend_io_frontend_toFtq_redirect_bits_taken",),
    "level": ("_backend_io_frontend_toFtq_redirect_bits_level",),
    "branchType": ("_backend_io_frontend_toFtq_redirect_bits_attribute_branchType",),
    "ftqFlag": ("_backend_io_frontend_toFtq_redirect_bits_ftqIdx_flag",),
    "ftqValue": ("_backend_io_frontend_toFtq_redirect_bits_ftqIdx_value",),
    "backendIGPF": ("_backend_io_frontend_toFtq_redirect_bits_backendIGPF",),
    "backendIPF": ("_backend_io_frontend_toFtq_redirect_bits_backendIPF",),
    "backendIAF": ("_backend_io_frontend_toFtq_redirect_bits_backendIAF",),
}

REQUIRED = ("valid", "pc", "target", "isRVC", "ftqOffset", "isMisPred", "taken")
HEX_FIELDS = {"pc", "target", "calcRedirectPc", "seqNext"}
PC_MASK = (1 << 50) - 1


def parse_objdump(path: Path) -> int:
    for line in path.read_text(errors="replace").splitlines():
        if "<victim_branch>:" in line:
            return int(line.split()[0], 16)
    raise SystemExit(f"victim_branch label not found in {path}")


def clean_var_name(name: str) -> str:
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_var(line: str, scope: list[str]):
    parts = line.split()
    if len(parts) < 5 or parts[0] != "$var":
        return None
    width = int(parts[2])
    code = parts[3]
    name = clean_var_name(" ".join(parts[4:-1]))
    full_name = ".".join(scope + [name]) if scope else name
    return {
        "code": code,
        "width": width,
        "name": name,
        "full_name": full_name,
    }


def parse_header(path: Path):
    scope: list[str] = []
    vars_seen = []
    timescale = None
    in_timescale = False

    with path.open("r", errors="replace") as f:
        for line in f:
            stripped = line.strip()
            if stripped == "$enddefinitions $end":
                break
            if stripped.startswith("$timescale"):
                in_timescale = True
                timescale = stripped.removeprefix("$timescale").replace("$end", "").strip()
                if "$end" in stripped:
                    in_timescale = False
                continue
            if in_timescale:
                timescale = (timescale + " " + stripped.replace("$end", "").strip()).strip()
                if "$end" in stripped:
                    in_timescale = False
                continue
            if stripped.startswith("$scope "):
                parts = stripped.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if stripped.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            if stripped.startswith("$var "):
                var = parse_var(stripped, scope)
                if var:
                    vars_seen.append(var)

    return vars_seen, timescale


def choose_signals(vars_seen):
    selected = {}
    all_candidates = {}
    for field, suffixes in SIGNALS.items():
        candidates = []
        for var in vars_seen:
            if any(var["full_name"].endswith(suffix) or var["name"].endswith(suffix) for suffix in suffixes):
                candidates.append(var)
        if not candidates:
            for var in vars_seen:
                if any(suffix in var["full_name"] for suffix in suffixes):
                    candidates.append(var)
        all_candidates[field] = candidates
        if candidates:
            selected[field] = sorted(candidates, key=lambda v: (len(v["full_name"]), v["full_name"]))[0]

    missing = [field for field in REQUIRED if field not in selected]
    if missing:
        nearby = [
            var["full_name"]
            for var in vars_seen
            if "frontend_toFtq_redirect" in var["full_name"]
        ][:80]
        raise SystemExit(
            "missing required VCD signals: "
            + ", ".join(missing)
            + "\nnearby redirect signals:\n"
            + "\n".join(nearby)
        )
    return selected, all_candidates


def parse_value(bits: str, base: int = 2):
    bits = bits.strip()
    if not bits or any(ch in bits.lower() for ch in "xz"):
        return None
    return int(bits, base)


def add_derived_fields(event: dict) -> None:
    pc_offset = event["ftqOffset"] << 1
    if event["isRVC"] == 0:
        pc_offset -= 2
    event["calcRedirectPc"] = (event["pc"] + pc_offset) & PC_MASK
    event["seqNext"] = event["calcRedirectPc"] + (2 if event["isRVC"] else 4)
    event["redirectType"] = 2 if event["seqNext"] == event["target"] else int(event["isMisPred"] != 0)
    fault_bits = [event.get("backendIGPF", 0), event.get("backendIPF", 0), event.get("backendIAF", 0)]
    event["backendFault"] = int(any(bit == 1 for bit in fault_bits))


def capture_events(path: Path, selected):
    id_to_fields = {}
    values = {field: None for field in selected}
    for field, var in selected.items():
        id_to_fields.setdefault(var["code"], []).append(field)

    events = []
    current_time = None
    in_body = False

    def flush():
        if current_time is None or values.get("valid") != 1:
            return
        if any(values.get(field) is None for field in REQUIRED):
            return
        event = {"cycle": current_time}
        for field, value in values.items():
            if value is not None:
                event[field] = value
        add_derived_fields(event)
        events.append(event)

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if line[0] == "#":
                flush()
                current_time = int(line[1:])
                continue
            if line[0] in "01xXzZ":
                code = line[1:].strip()
                fields = id_to_fields.get(code)
                if not fields:
                    continue
                value = None if line[0] in "xXzZ" else int(line[0])
                for field in fields:
                    values[field] = value
                continue
            if line[0] in "bBrRhH":
                parts = line.split()
                if len(parts) != 2:
                    continue
                code = parts[1]
                fields = id_to_fields.get(code)
                if not fields:
                    continue
                base = 16 if line[0] in "hH" else 2
                value = parse_value(parts[0][1:], base=base)
                for field in fields:
                    values[field] = value
        flush()

    return events


def jsonify_event(event):
    out = {}
    for key, value in event.items():
        out[key] = hex(value) if key in HEX_FIELDS else value
    return out


def main() -> int:
    if len(sys.argv) != 4:
        print("usage: parse_cbnez_vcd.py <wave.vcd> <objdump> <out.json>", file=sys.stderr)
        return 2

    vcd_path = Path(sys.argv[1])
    objdump_path = Path(sys.argv[2])
    out_path = Path(sys.argv[3])

    victim_pc = parse_objdump(objdump_path)
    expected_target = victim_pc + 2
    vars_seen, timescale = parse_header(vcd_path)
    selected, _ = choose_signals(vars_seen)
    events = capture_events(vcd_path, selected)

    matching = [
        event
        for event in events
        if event["pc"] == victim_pc
        and event["target"] == expected_target
        and event["isMisPred"] == 1
        and event["taken"] == 0
    ]
    bad = [
        event
        for event in matching
        if event["isRVC"] == 0 and event["calcRedirectPc"] != victim_pc
    ]

    result = {
        "passed": bool(bad),
        "vcd": str(vcd_path),
        "vcd_timescale": timescale,
        "victim_pc": hex(victim_pc),
        "expected_false_branch_target": hex(expected_target),
        "total_redirect_events": len(events),
        "matching_false_branch_redirects": [jsonify_event(event) for event in matching],
        "bad_redirects": [jsonify_event(event) for event in bad],
        "selected_vcd_signals": {
            field: {
                "code": var["code"],
                "width": var["width"],
                "full_name": var["full_name"],
            }
            for field, var in selected.items()
        },
        "success_predicate": (
            "Find a backend redirect for the compressed c.bnez at victim_branch with "
            "target=victim_pc+2, isMisPred=1, taken=0, but redirect.bits.isRVC=0. "
            "Using Redirect.getPcOffset with the observed VCD metadata then computes a "
            "redirect CFI PC different from the actual compressed branch PC."
        ),
    }

    out_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
