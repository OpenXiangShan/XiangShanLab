# XiangShan Zicbop Prefetch No-Progress PoC

This package contains two reduced PoC pairs for a potential XiangShan no-progress bug triggered by legal RISC-V Zicbop software prefetch hint instructions.

Each seed directory contains:

- `app_buggy.elf`: keeps the trigger prefetch instruction and is expected to reach `SIMLEN` without stop.
- `app_ok.elf`: replaces only the trigger instruction with a direct jump to the final block and is expected to stop normally.
- `*.dump`: disassembly for the corresponding ELF.

## Tested Target

```text
Project: OpenXiangShan/XiangShan
Commit: ed346cdc8ca174210c48df96620b8887329f8e92
Config: TLMinimalConfig
Top used by Verilator control harness: top_tiny_soc
Simulator: Verilator 5.032
Golden reference: Spike RISC-V ISA Simulator 1.1.1-dev
Spike source: riscv-isa-sim commit d1efcdffffee57bab0fdbd2b377c6132b37556fd
```

## Trigger Instructions

### seed_500937

```text
PC:   0x80009dc8
word: 0xea176013
objdump text: ori x0,x14,-351
Spike decode: prefetch.r -352(a4)
buggy dump trigger line: seed_500937/app_buggy.elf.dump:935
```

### seed_502992

```text
PC:   0x8000134c
word: 0x74076013
objdump text: ori x0,x14,1856
Spike decode: prefetch.i 1856(a4)
buggy dump trigger line: seed_502992/app_buggy.elf.dump:304
```

## Exact Lines in the Dumps

The line numbers below refer to the `.dump` files in this package.

### seed_500937

`seed_500937/app_buggy.elf.dump`

```text
line 236: 8000556c: 05d0406f           jal x0,0x80009dc8
line 935: 80009dc8: ea176013           ori x0,x14,-351   <-- trigger, Spike: prefetch.r -352(a4)
line 936: 80009dcc: 63d0f06f           jal x0,0x80019c08
```

`seed_500937/app_ok.elf.dump`

```text
line 236: 8000556c: 05d0406f           jal x0,0x80009dc8
line 935: 80009dc8: 6410f06f           jal x0,0x80019c08  <-- trigger replaced by direct final jump
```

### seed_502992

`seed_502992/app_buggy.elf.dump`

```text
line 1174: 800069b0: 99dfa06f          jal x0,0x8000134c
line 304:  8000134c: 74076013          ori x0,x14,1856    <-- trigger, Spike: prefetch.i 1856(a4)
line 305:  80001350: 6e00106f          jal x0,0x80002a30
```

`seed_502992/app_ok.elf.dump`

```text
line 1174: 800069b0: 99dfa06f          jal x0,0x8000134c
line 304:  8000134c: 6e40106f          jal x0,0x80002a30  <-- trigger replaced by direct final jump
```

## Minimal Source-Level Trigger Snippets

The ELF pairs above are the authoritative reduced reproducers because they include the restored architectural context used during reduction. The snippets below show the minimal instruction pattern that should be useful for writing an independent regression test. If your assembler does not support Zicbop prefetch mnemonics, use the raw `.word` encodings shown here.

### prefetch.r trigger pattern

```asm
    .option norvc
    .section .text
    .globl _start
_start:
    li a4, 0
    .word 0xea176013        # prefetch.r -352(a4); may disassemble as ori x0,x14,-351

    # Reaching this code means the hint did not hang the core.
    # Replace STOP_MMIO with the stop address used by your test harness.
    li t0, 0x60000000
    li t1, 1
    sd t1, 0(t0)
```

### prefetch.i trigger pattern

```asm
    .option norvc
    .section .text
    .globl _start
_start:
    li a4, 0
    .word 0x74076013        # prefetch.i 1856(a4); may disassemble as ori x0,x14,1856

    # Reaching this code means the hint did not hang the core.
    # Replace STOP_MMIO with the stop address used by your test harness.
    li t0, 0x60000000
    li t1, 1
    sd t1, 0(t0)
```

## Reproduction Command Shape

Run the buggy ELF:

```bash
SIMLEN=50000 \
SIMSRAMELF=/path/to/seed_500937/app_buggy.elf \
TRACEFILE=/tmp/vanilla_headtail_500937_buggy.vcd \
/path/to/Vtop_tiny_soc
```

For `seed_502992`, replace `SIMSRAMELF` with:

```text
/path/to/seed_502992/app_buggy.elf
```

Run the corresponding `app_ok.elf` with the same command to confirm the control case reaches the final stop request.

## Expected Results

`SIMLEN=50000`.

| Case | ELF | Expected result |
| --- | --- | --- |
| seed_500937 | `app_ok.elf` | stop request observed, 24 register dumps |
| seed_500937 | `app_buggy.elf` | reaches `SIMLEN`, no stop, no register dump |
| seed_502992 | `app_ok.elf` | stop request observed, 24 register dumps |
| seed_502992 | `app_buggy.elf` | reaches `SIMLEN`, no stop, no register dump |

Observed timing in one run:

```text
seed_500937 app_ok.elf:     stopped normally, about 20 s
seed_500937 app_buggy.elf:  reached SIMLEN, about 251 s
seed_502992 app_ok.elf:     stopped normally, about 19 s
seed_502992 app_buggy.elf:  reached SIMLEN, about 243 s
```

## File List

```text
seed_500937/app_buggy.elf
seed_500937/app_ok.elf
seed_500937/app_buggy.elf.dump
seed_500937/app_ok.elf.dump
seed_502992/app_buggy.elf
seed_502992/app_ok.elf
seed_502992/app_buggy.elf.dump
seed_502992/app_ok.elf.dump
README.md
```
