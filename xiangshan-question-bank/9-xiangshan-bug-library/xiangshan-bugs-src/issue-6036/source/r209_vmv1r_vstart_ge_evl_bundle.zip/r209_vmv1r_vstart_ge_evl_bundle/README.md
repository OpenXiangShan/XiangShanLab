# r209_vmv1r_vstart_ge_evl bundle

This bundle captures the `vmv<nr>r.v` `vstart >= evl` illegal-instruction mismatch.

## Key Failure

Instruction sequence:

```asm
vsetivli zero, 4, e64, m1, ta, ma
csrr t0, vlenb
srli t0, t0, 3
csrw vstart, t0
vmv1r.v v8, v10
```

For `vmv1r.v` with `SEW=64`, `evl = VLEN / 64 = vlenb / 8`. The testcase sets `vstart = evl`.

NEMU REF reports illegal instruction:

```text
mcause right = 0x2
mepc   right = 0x800000d0
mtval  right = 0x9ea03457
vstart right = 0x2
```

DUT does not trap:

```text
mcause wrong = 0x0
mepc   wrong = 0x0
mtval  wrong = 0x0
vstart wrong = 0x0
```

Failure point:

```text
Core 0: ABORT at pc = 0xffffb3a31236d5d2
Core-0 instrCnt = 42, cycleCnt = 8385
```

## Wave

V2 wave file:

```text
/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r209_vmv1r_vstart_ge_evl/r209_vmv1r_vstart_ge_evl.fst
```

Bundle hard link:

```text
wave/r209_vmv1r_vstart_ge_evl.fst
```

## Reproduce

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/emu \
  -b 0 -e 10000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r209_vmv1r_vstart_ge_evl_bundle/bin/r209_vmv1r_vstart_ge_evl.elf \
  --diff /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r209_vmv1r_vstart_ge_evl_bundle/ref/riscv64-nemu-interpreter-so \
  -C 10000 \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r209_vmv1r_vstart_ge_evl/r209_vmv1r_vstart_ge_evl.fst
```

## Contents

- `BUG_REPORT.md`: issue-format summary.
- `src/r209_vmv1r_vstart_ge_evl.S`: source testcase.
- `bin/r209_vmv1r_vstart_ge_evl.{elf,bin}`: testcase artifacts.
- `logs/r209_vmv1r_vstart_ge_evl.log`: original batch log.
- `logs/r209_vmv1r_vstart_ge_evl.wave.log`: V2 wave run log.
- `logs/r209_error_excerpt.txt`: compact mismatch excerpt.
- `instr/r209_vmv1r_vstart_ge_evl.objdump.txt`: disassembly.
- `instr/r209_commit_*_nemu.txt`: commit traces.
- `wave/r209_vmv1r_vstart_ge_evl.fst`: waveform.
- `ref/riscv64-nemu-interpreter-so`: NEMU REF used by the run.
- `summary/failing_case.tsv`: summary row for this case.

