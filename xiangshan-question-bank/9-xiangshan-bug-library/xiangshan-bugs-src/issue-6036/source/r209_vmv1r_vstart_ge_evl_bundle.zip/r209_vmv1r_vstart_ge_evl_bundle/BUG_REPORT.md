# Bug Report: `r209_vmv1r_vstart_ge_evl`

## Branch

`master (kunminghu-v2)`

## Describe the Bug

The `vmv<nr>r.v` `vstart >= evl` reserved case does not raise illegal instruction in DUT.

Instruction sequence:

```asm
vsetivli zero, 4, e64, m1, ta, ma
csrr t0, vlenb
srli t0, t0, 3
csrw vstart, t0
vmv1r.v v8, v10
```

For `vmv1r.v` and `SEW=64`:

```text
evl = NREG * VLEN / SEW = VLEN / 64 = vlenb / 8
```

The testcase writes `vstart = vlenb / 8`, so `vstart >= evl`.

NEMU REF traps:

```text
mcause = 0x2
mepc   = 0x800000d0
mtval  = 0x9ea03457
vstart = 0x2
```

DUT does not trap and `vstart` diverges:

```text
mcause = 0x0
mepc   = 0x0
mtval  = 0x0
vstart = 0x0
```

Key mismatch:

```text
mepc different at pc = 0xffffb3a31236d5d2, right = 0x00000000800000d0, wrong = 0x0000000000000000
mtval different at pc = 0xffffb3a31236d5d2, right = 0x000000009ea03457, wrong = 0x0000000000000000
mcause different at pc = 0xffffb3a31236d5d2, right = 0x0000000000000002, wrong = 0x0000000000000000
vstart different at pc = 0xffffb3a31236d5d2, right = 0x0000000000000002, wrong = 0x0000000000000000
Core 0: ABORT at pc = 0xffffb3a31236d5d2
```

## Expected Behavior

`vmv1r.v` should raise illegal instruction when `vstart >= evl`.

## Actual Behavior

DUT executes past the instruction without taking the illegal-instruction exception, and `vstart` is cleared/changed to `0`.

## Environment

Reference model:

```text
ref/riscv64-nemu-interpreter-so
```

V2 waveform:

```text
/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r209_vmv1r_vstart_ge_evl/r209_vmv1r_vstart_ge_evl.fst
```

## To Reproduce

```bash
/nfs/home/nanyunhao/XiangShan_V2/build/emu \
  -b 0 -e 10000 \
  -i /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r209_vmv1r_vstart_ge_evl_bundle/bin/r209_vmv1r_vstart_ge_evl.elf \
  --diff /nfs/home/nanyunhao/NANYUNHAO/vector_it_failures_20260522_split/r209_vmv1r_vstart_ge_evl_bundle/ref/riscv64-nemu-interpreter-so \
  -C 10000 \
  --dump-wave-full \
  --wave-path=/nfs/home/nanyunhao/XiangShan_V2/it_vector_case_waves_20260528/r209_vmv1r_vstart_ge_evl/r209_vmv1r_vstart_ge_evl.fst
```

## Attached Evidence

- `logs/r209_vmv1r_vstart_ge_evl.log`
- `logs/r209_vmv1r_vstart_ge_evl.wave.log`
- `logs/r209_error_excerpt.txt`
- `instr/r209_vmv1r_vstart_ge_evl.objdump.txt`
- `instr/r209_commit_group_trace_nemu.txt`
- `instr/r209_commit_instr_trace_nemu.txt`
- `src/r209_vmv1r_vstart_ge_evl.S`
- `bin/r209_vmv1r_vstart_ge_evl.{elf,bin}`
- `wave/r209_vmv1r_vstart_ge_evl.fst`
- `summary/failing_case.tsv`

