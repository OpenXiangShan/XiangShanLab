#include <klib.h>

int main(void)
{
printf("testing instructions\n");
asm volatile ( "DIVW x30,x1,x7" );
asm volatile ( "SLT x1,x5,x7" );
asm volatile ( "SRL x10,x11,x8" );
asm volatile ( "SLTU x6,x20,x16" );
asm volatile ( "SRLI x20,x25,8" );
asm volatile ( "SLTU x17,x11,x13" );
asm volatile ( "SRA x15,x22,x29" );
asm volatile ( "OR x7,x11,x0" );
asm volatile ( "SLTIU x4,x13,-1627" );
asm volatile ( "ADDIW x16,x5,-875" );

asm volatile ( "LHU x23, -1848(x12)" );

return 0;
}
