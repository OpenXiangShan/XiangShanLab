/home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/tests/store_misalign_fault.o: \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/tests/store_misalign_fault.c \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/libs/klib/include/klib.h \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/am/am.h \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/am/include/arch/riscv64-xs.h \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/am/include/arch/riscv64-nemu.h \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/am/include/arch/riscv32-nemu.h \
 /home/grads/c/chenc/new_CBFuzz/thehuzz/master_xs/software/xiangshan/libs/klib/include/printf.h
