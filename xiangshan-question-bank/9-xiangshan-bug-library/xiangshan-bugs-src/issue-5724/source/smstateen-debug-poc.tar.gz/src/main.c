#include <klib.h>

#define CSR_READ(csr) ({                          \
    unsigned long __v;                            \
    asm volatile("csrr %0, " #csr                 \
                 : "=r"(__v) : : "memory");       \
    __v;                                          \
})

#define CSR_WRITE(csr, val) ({                    \
    unsigned long __v = (unsigned long)(val);     \
    asm volatile("csrw " #csr ", %0"              \
                 : : "rK"(__v) : "memory");       \
})

#define MSTATUS_MPP_MASK  (3UL << 11)
#define MSTATUS_MPP_S     (1UL << 11)

void __attribute__((naked, noinline)) s_mode_spin(void) {
    asm volatile(
        ".option push\n"
        ".option norvc\n"
        "1: j 1b\n"
        ".option pop\n"
    );
}

int main() {
    printf("\n=== Smstateen Debug Mode PoC ===\n\n");

    unsigned long mstateen0;
    asm volatile("csrr %0, 0x30C" : "=r"(mstateen0) : : "memory");
    printf("  mstateen0 = 0x%lx  (CONTEXT[57]=%ld)\n",
           mstateen0, (mstateen0 >> 57) & 1);

    CSR_WRITE(pmpaddr0, ~0UL);
    CSR_WRITE(pmpcfg0, 0x0F);
    CSR_WRITE(mie, 0);

    unsigned long mstatus = CSR_READ(mstatus);
    mstatus = (mstatus & ~MSTATUS_MPP_MASK) | MSTATUS_MPP_S;
    CSR_WRITE(mstatus, mstatus);
    CSR_WRITE(mepc, (unsigned long)s_mode_spin);

    printf("  Dropping to S-mode, spin at 0x%lx\n", (unsigned long)s_mode_spin);
    printf("  Hart will be halted by debugger from S-mode.\n\n");

    asm volatile("mret");
    return 1;
}
