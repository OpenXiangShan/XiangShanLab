#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
RISCV_NM="${RISCV_NM:-/opt/riscv/bin/riscv64-unknown-elf-nm}"
EMU="${EMU:-/root/HardwareAgent/XiangShan/build/emu}"

WARM_ITERS="${WARM_ITERS:-2048}"
PROBE_ITERS="${PROBE_ITERS:-32}"
CYCLES="${CYCLES:-30000}"
WAVE_BEGIN="${WAVE_BEGIN:-22000}"
WAVE_END="${WAVE_END:-26000}"
TIMEOUT_SECS="${TIMEOUT_SECS:-240}"

if [[ ! -x "$EMU" ]]; then
  echo "missing executable emulator: $EMU" >&2
  exit 2
fi

for secret in 0 1; do
  prefix="noalt_secret_${secret}"
  elf="${prefix}.elf"
  bin="${prefix}.bin"
  objdump="${prefix}.objdump"
  symbols="${prefix}.symbols"
  wave="${prefix}_${WAVE_BEGIN}_${WAVE_END}.vcd"
  run_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.run.log"
  monitor_json="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.json"
  monitor_log="${prefix}_${WAVE_BEGIN}_${WAVE_END}.monitor.log"

  echo "[build] SECRET_VALUE=${secret}"
  "$RISCV_GCC" \
    -nostdlib -nostartfiles -static \
    -march=rv64gc_zicsr -mabi=lp64d \
    -Wl,--no-relax \
    -DSECRET_VALUE="$secret" \
    -DWARM_ITERS="$WARM_ITERS" \
    -DPROBE_ITERS="$PROBE_ITERS" \
    -T linker.ld \
    -o "$elf" \
    ittage_noalt_secret_probe.S
  "$RISCV_OBJCOPY" -O binary "$elf" "$bin"
  "$RISCV_OBJDUMP" -d -t "$elf" > "$objdump"
  "$RISCV_NM" -n "$elf" > "$symbols"

  echo "[run] SECRET_VALUE=${secret}"
  timeout "${TIMEOUT_SECS}s" "$EMU" \
    -i "$bin" \
    --no-diff \
    -C "$CYCLES" \
    -b "$WAVE_BEGIN" \
    -e "$WAVE_END" \
    --dump-wave-full \
    --wave-path="$wave" \
    > "$run_log" 2>&1

  echo "[monitor] SECRET_VALUE=${secret}"
  python3 ./monitor_noalt_secret_probe.py \
    "$wave" "$symbols" \
    --json-out "$monitor_json" \
    > "$monitor_log"
done

python3 - <<'PY'
import json
from pathlib import Path

rows = {}
for secret in (0, 1):
    path = next(Path(".").glob(f"noalt_secret_{secret}_*.monitor.json"))
    rows[secret] = json.loads(path.read_text())

summary = {}
for secret in (0, 1):
    r = rows[secret]
    summary[str(secret)] = {
        "no_alt_event_count": r["no_alt_event_count"],
        "no_alt_train_targets": r["no_alt_train_targets"],
        "secret_no_alt_event_count": r["secret_window"]["no_alt_event_count"],
        "secret_useful_values": r["secret_window"]["table_useful_values"],
        "probe_redirect_count": r["probe_window"]["redirect_count"],
        "probe_wrongpath_gadget_load_count": r["probe_window"]["wrongpath_gadget_load_count"],
        "probe_delta_values": r["stores"]["result_probe_delta_values"],
    }

verdict = {
    "both_variants_reproduce_no_alt_altdiffers": int(
        rows[0]["no_alt_event_count"] > 0
        and rows[1]["no_alt_event_count"] > 0
    ),
    "secret_controls_no_alt_target": int(
        rows[0]["no_alt_train_targets"] != rows[1]["no_alt_train_targets"]
    ),
    "secret_controls_buggy_useful_write": int(
        rows[0]["secret_window"]["table_useful_values"]
        != rows[1]["secret_window"]["table_useful_values"]
    ),
    "wrongpath_gadget_load_observed": int(
        rows[0]["probe_window"]["wrongpath_gadget_load_count"] > 0
        or rows[1]["probe_window"]["wrongpath_gadget_load_count"] > 0
    ),
}
Path("verdict.json").write_text(json.dumps({"summary": summary, "verdict": verdict}, indent=2, sort_keys=True) + "\n")
print(json.dumps({"summary": summary, "verdict": verdict}, indent=2, sort_keys=True))
if not (
    verdict["both_variants_reproduce_no_alt_altdiffers"]
    and verdict["secret_controls_buggy_useful_write"]
    and verdict["wrongpath_gadget_load_observed"]
):
    raise SystemExit(1)
PY
