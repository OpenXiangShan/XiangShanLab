#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


CORE = "TOP.SimTop.cpu.l_soc.core_with_l2.core"
BACKEND = f"{CORE}.backend"
ITTAGE = f"{CORE}.frontend.inner_bpu.ittage"

VAR_RE = re.compile(r"\$var\s+\S+\s+\d+\s+(\S+)\s+(.+?)\s+\$end")


def clean_name(name: str) -> str:
    name = name.strip()
    if name.startswith("\\"):
        name = name[1:]
    return re.sub(r"\s+\[[^\]]+\]$", "", name)


def parse_value(value: str | None) -> int | None:
    if value is None:
        return None
    value = value.strip().lower()
    if value in {"0", "1"}:
        return int(value)
    if value in {"x", "z"}:
        return None
    if value.startswith("b"):
        bits = value[1:]
        if not bits or any(ch in bits for ch in "xz"):
            return None
        return int(bits, 2)
    return None


def pruned_to_addr(value: int | None) -> int | None:
    if value is None:
        return None
    return int(value) << 1


def parse_symbols(path: Path) -> dict[str, int]:
    out: dict[str, int] = {}
    for line in path.read_text(errors="replace").splitlines():
        parts = line.split()
        if len(parts) >= 3:
            try:
                out[parts[2]] = int(parts[0], 16)
            except ValueError:
                pass
    return out


def hex_or_none(value: int | None) -> str | None:
    if value is None:
        return None
    return f"0x{value:x}"


def build_exact_wanted() -> dict[str, str]:
    wanted = {
        f"{ITTAGE}.updateValid_probe": "ittage_update_valid",
        f"{ITTAGE}.t1_meta_r_provider_valid": "provider_valid",
        f"{ITTAGE}.t1_meta_r_altProvider_valid": "alt_provider_valid",
        f"{ITTAGE}.t1_meta_r_altDiffers": "alt_differs",
        f"{ITTAGE}.t1_meta_providerTarget_r_addr": "provider_target",
        f"{ITTAGE}.t1_meta_altProviderTarget_r_addr": "alt_provider_target",
        f"{ITTAGE}.t1_meta_r_providerUsefulCnt_value": "provider_useful",
        f"{ITTAGE}.t1_meta_r_providerCnt_value": "provider_cnt",
        f"{ITTAGE}.t1_meta_provider_bits_r": "provider_bits",
        f"{ITTAGE}.t1_meta_altProvider_bits_r": "alt_provider_bits",
        f"{BACKEND}.io_frontend_toFtq_redirect_valid": "redirect_valid",
        f"{BACKEND}.io_frontend_toFtq_redirect_bits_pc": "redirect_pc",
        f"{BACKEND}.io_frontend_toFtq_redirect_bits_target": "redirect_target",
        f"{BACKEND}.io_frontend_toFtq_redirect_bits_isMisPred": "redirect_mispredict",
        f"{CORE}.auto_memBlock_inner_dcache_client_out_a_ready": "dcache_a_ready",
        f"{CORE}.auto_memBlock_inner_dcache_client_out_a_valid": "dcache_a_valid",
        f"{CORE}.auto_memBlock_inner_dcache_client_out_a_bits_address": "dcache_a_addr",
        f"{CORE}.auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr": "dcache_a_vaddr",
    }
    for table in range(8):
        prefix = f"{ITTAGE}.tables_{table}_io_update"
        wanted[f"{prefix}_valid_probe"] = f"table{table}_update_valid"
        wanted[f"{prefix}_correct_r"] = f"table{table}_update_correct"
        wanted[f"{prefix}_alloc_r"] = f"table{table}_update_alloc"
        wanted[f"{prefix}_usefulCntValid_r"] = f"table{table}_useful_valid"
        wanted[f"{prefix}_usefulCnt_r_value"] = f"table{table}_useful"
        wanted[f"{prefix}_startPc_r_addr"] = f"table{table}_start_pc"
    for branch in range(8):
        wanted[f"{ITTAGE}.io_train_branches_{branch}_valid"] = f"train_b{branch}_valid"
        wanted[f"{ITTAGE}.io_train_branches_{branch}_bits_target_addr"] = f"train_b{branch}_target"
        wanted[f"{ITTAGE}.io_train_branches_{branch}_bits_taken"] = f"train_b{branch}_taken"
        wanted[f"{ITTAGE}.io_train_branches_{branch}_bits_mispredict"] = f"train_b{branch}_mispredict"
    for slot in range(3):
        endpoint = "store" if slot == 0 else f"store_{slot}"
        wanted[f"TOP.SimTop.endpoint.{endpoint}.io_valid"] = f"store{slot}_valid"
        wanted[f"TOP.SimTop.endpoint.{endpoint}.io_bits_valid"] = f"store{slot}_bits_valid"
        wanted[f"TOP.SimTop.endpoint.{endpoint}.io_bits_addr"] = f"store{slot}_addr"
        wanted[f"TOP.SimTop.endpoint.{endpoint}.io_bits_data"] = f"store{slot}_data"
        wanted[f"TOP.SimTop.endpoint.{endpoint}.io_bits_pc"] = f"store{slot}_pc"
    return wanted


def suffix_wanted(full: str) -> tuple[str, str] | None:
    for unit in range(4):
        needle = f"memBlock.inner_LoadUnit_{unit}"
        if needle in full:
            if full.endswith("io_dcache_req_valid"):
                return f"lu{unit}_req_valid", full
            if full.endswith("io_dcache_req_ready"):
                return f"lu{unit}_req_ready", full
            if full.endswith("io_dcache_req_bits_vaddr"):
                return f"lu{unit}_req_vaddr", full
            if full.endswith("io_dcache_s1_kill"):
                return f"lu{unit}_s1_kill", full
            if full.endswith("io_dcache_s2_kill"):
                return f"lu{unit}_s2_kill", full
    return None


def select_signals(path: Path):
    exact_wanted = build_exact_wanted()
    selected: dict[str, dict[str, str]] = {}
    code_to_keys: dict[str, list[str]] = {}
    scope: list[str] = []

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if line == "$enddefinitions $end":
                break
            if line.startswith("$scope"):
                parts = line.split()
                if len(parts) >= 3:
                    scope.append(parts[2])
                continue
            if line.startswith("$upscope"):
                if scope:
                    scope.pop()
                continue
            match = VAR_RE.match(line)
            if not match:
                continue
            code, raw_name = match.groups()
            full = ".".join(scope + [clean_name(raw_name)])
            logical = exact_wanted.get(full)
            if logical is None:
                suffix = suffix_wanted(full)
                if suffix is not None:
                    logical, _ = suffix
            if logical is None:
                continue
            selected[logical] = {"code": code, "full": full}
            code_to_keys.setdefault(code, []).append(logical)

    return selected, code_to_keys


def parse_vcd(path: Path, symbols: dict[str, int]):
    selected, code_to_keys = select_signals(path)
    values = {key: None for key in selected}
    now: int | None = None
    in_body = False

    required_symbols = [
        "indirect_site",
        "loop_target_a",
        "loop_target_b",
        "target_b_gadget_load",
        "oracle_line",
        "result_secret_begin",
        "result_secret_delta",
        "result_probe_begin",
        "result_probe_delta",
        "result_done",
    ]
    missing_symbols = [name for name in required_symbols if name not in symbols]
    if missing_symbols:
        raise SystemExit(f"missing symbols: {missing_symbols}")

    ittage_updates = []
    no_alt_events = []
    table_updates = []
    redirects = []
    load_events = []
    dcache_events = []
    stores = []

    def val(key: str) -> int | None:
        return parse_value(values.get(key))

    def sample(time: int | None):
        if time is None:
            return

        if val("ittage_update_valid") == 1:
            train_branches = []
            for branch in range(8):
                if val(f"train_b{branch}_valid") != 1:
                    continue
                train_branches.append(
                    {
                        "slot": branch,
                        "target": hex_or_none(pruned_to_addr(val(f"train_b{branch}_target"))),
                        "taken": val(f"train_b{branch}_taken"),
                        "mispredict": val(f"train_b{branch}_mispredict"),
                    }
                )
            row = {
                "time": time,
                "provider_valid": val("provider_valid"),
                "alt_provider_valid": val("alt_provider_valid"),
                "alt_differs": val("alt_differs"),
                "provider_target": hex_or_none(pruned_to_addr(val("provider_target"))),
                "alt_provider_target": hex_or_none(pruned_to_addr(val("alt_provider_target"))),
                "provider_bits": val("provider_bits"),
                "alt_provider_bits": val("alt_provider_bits"),
                "provider_useful": val("provider_useful"),
                "provider_cnt": val("provider_cnt"),
                "train_branches": train_branches,
            }
            ittage_updates.append(row)
            if (
                row["provider_valid"] == 1
                and row["alt_provider_valid"] == 0
                and row["alt_differs"] == 1
            ):
                no_alt_events.append(row)

        for table in range(8):
            if val(f"table{table}_update_valid") == 1:
                table_updates.append(
                    {
                        "time": time,
                        "table": table,
                        "start_pc": hex_or_none(pruned_to_addr(val(f"table{table}_start_pc"))),
                        "correct": val(f"table{table}_update_correct"),
                        "alloc": val(f"table{table}_update_alloc"),
                        "useful_valid": val(f"table{table}_useful_valid"),
                        "useful": val(f"table{table}_useful"),
                    }
                )

        if val("redirect_valid") == 1:
            redirects.append(
                {
                    "time": time,
                    "pc": hex_or_none(val("redirect_pc")),
                    "target": hex_or_none(val("redirect_target")),
                    "is_mispredict": val("redirect_mispredict"),
                }
            )

        oracle = symbols["oracle_line"]
        oracle_mask = ~0x3f
        for unit in range(4):
            req_valid = val(f"lu{unit}_req_valid") == 1
            req_ready = val(f"lu{unit}_req_ready")
            req_vaddr = val(f"lu{unit}_req_vaddr")
            s1_kill = val(f"lu{unit}_s1_kill")
            s2_kill = val(f"lu{unit}_s2_kill")
            if req_valid and req_vaddr is not None and (req_vaddr & oracle_mask) == (oracle & oracle_mask):
                load_events.append(
                    {
                        "time": time,
                        "unit": unit,
                        "vaddr": hex_or_none(req_vaddr),
                        "ready": req_ready,
                        "s1_kill": s1_kill,
                        "s2_kill": s2_kill,
                    }
                )

        dcache_vaddr = val("dcache_a_vaddr")
        dcache_addr = val("dcache_a_addr")
        if val("dcache_a_valid") == 1 and val("dcache_a_ready") == 1:
            if (
                (dcache_vaddr is not None and (dcache_vaddr & oracle_mask) == (oracle & oracle_mask))
                or (dcache_addr is not None and (dcache_addr & oracle_mask) == (oracle & oracle_mask))
            ):
                dcache_events.append(
                    {
                        "time": time,
                        "addr": hex_or_none(dcache_addr),
                        "vaddr": hex_or_none(dcache_vaddr),
                    }
                )

        store_targets = {
            symbols["result_secret_begin"]: "result_secret_begin",
            symbols["result_secret_delta"]: "result_secret_delta",
            symbols["result_probe_begin"]: "result_probe_begin",
            symbols["result_probe_delta"]: "result_probe_delta",
            symbols["result_done"]: "result_done",
        }
        for slot in range(3):
            valid = val(f"store{slot}_valid") == 1
            bits_valid = val(f"store{slot}_bits_valid")
            addr = val(f"store{slot}_addr")
            if valid and bits_valid in (None, 1) and addr in store_targets:
                stores.append(
                    {
                        "time": time,
                        "slot": slot,
                        "name": store_targets[addr],
                        "addr": hex_or_none(addr),
                        "data": val(f"store{slot}_data"),
                        "pc": hex_or_none(val(f"store{slot}_pc")),
                    }
                )

    with path.open("r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if not in_body:
                if line == "$enddefinitions $end":
                    in_body = True
                continue
            if line.startswith("#"):
                sample(now)
                now = int(line[1:])
                continue
            if line[0] in "01xXzZ":
                code = line[1:].strip()
                value = line[0]
                for key in code_to_keys.get(code, []):
                    values[key] = value
                continue
            if line[0] in "bB":
                parts = line.split()
                if len(parts) == 2:
                    value, code = parts
                    for key in code_to_keys.get(code, []):
                        values[key] = value
        sample(now)

    def first_store_time(name: str) -> int | None:
        matches = [row["time"] for row in stores if row["name"] == name]
        return min(matches) if matches else None

    secret_begin = first_store_time("result_secret_begin")
    secret_done = first_store_time("result_secret_delta")
    probe_begin = first_store_time("result_probe_begin")
    probe_done = first_store_time("result_probe_delta")

    def in_window(row, start, end):
        if start is not None and row["time"] < start:
            return False
        if end is not None and row["time"] > end:
            return False
        return True

    secret_context_start = None if secret_begin is None else secret_begin - 800
    secret_context_end = None if secret_done is None else secret_done + 200
    secret_ittage_updates = [row for row in ittage_updates if in_window(row, secret_context_start, secret_context_end)]
    secret_events = [row for row in no_alt_events if in_window(row, secret_context_start, secret_context_end)]
    secret_updates = [
        row
        for row in table_updates
        if in_window(row, secret_context_start, secret_context_end)
        and row["start_pc"] == hex_or_none(symbols["indirect_site"])
        and row["useful_valid"] == 1
    ]
    probe_redirects = [
        row
        for row in redirects
        if in_window(row, probe_begin, probe_done)
        and row["pc"] == hex_or_none(symbols["indirect_site"])
        and row["target"] == hex_or_none(symbols["loop_target_a"])
        and row["is_mispredict"] == 1
    ]
    probe_loads = [row for row in load_events if in_window(row, probe_begin, probe_done)]
    probe_dcache = [row for row in dcache_events if in_window(row, probe_begin, probe_done)]

    store_values: dict[str, list[int | None]] = {}
    for row in stores:
        store_values.setdefault(row["name"], []).append(row["data"])

    no_alt_train_targets = sorted(
        {
            branch["target"]
            for row in no_alt_events
            for branch in row["train_branches"]
            if branch.get("taken") == 1 and branch.get("target") is not None
        }
    )

    missing_logicals = sorted(
        key
        for key in [
            "ittage_update_valid",
            "provider_valid",
            "alt_provider_valid",
            "alt_differs",
            "provider_target",
            "provider_useful",
            "redirect_valid",
            "dcache_a_valid",
            "store0_valid",
        ]
        if key not in selected
    )

    return {
        "wave": str(path),
        "symbols": {name: hex(symbols[name]) for name in required_symbols},
        "selected_signal_count": len(selected),
        "missing_logicals": missing_logicals,
        "window_times": {
            "secret_begin": secret_begin,
            "secret_done": secret_done,
            "secret_context_start": secret_context_start,
            "secret_context_end": secret_context_end,
            "probe_begin": probe_begin,
            "probe_done": probe_done,
        },
        "stores": {
            "all": stores[:64],
            "result_secret_delta_values": store_values.get("result_secret_delta", [])[:8],
            "result_probe_delta_values": store_values.get("result_probe_delta", [])[:8],
            "result_done_values": store_values.get("result_done", [])[:8],
        },
        "ittage_update_count": len(ittage_updates),
        "first_ittage_updates": ittage_updates[:16],
        "no_alt_event_count": len(no_alt_events),
        "no_alt_train_targets": no_alt_train_targets,
        "first_no_alt_events": no_alt_events[:16],
        "secret_window": {
            "ittage_update_count": len(secret_ittage_updates),
            "ittage_updates": secret_ittage_updates[:16],
            "no_alt_event_count": len(secret_events),
            "no_alt_events": secret_events[:16],
            "table_update_count": len(secret_updates),
            "table_updates": secret_updates[:16],
            "table_useful_values": [row["useful"] for row in secret_updates[:16]],
        },
        "probe_window": {
            "redirect_count": len(probe_redirects),
            "redirects": probe_redirects[:16],
            "wrongpath_gadget_load_count": len(probe_loads),
            "wrongpath_gadget_loads": probe_loads[:16],
            "dcache_oracle_event_count": len(probe_dcache),
            "dcache_oracle_events": probe_dcache[:16],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("wave", type=Path)
    parser.add_argument("symbols", type=Path)
    parser.add_argument("--json-out", type=Path, required=True)
    args = parser.parse_args()

    symbols = parse_symbols(args.symbols)
    result = parse_vcd(args.wave, symbols)
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "no_alt_event_count": result["no_alt_event_count"],
        "secret_window": result["secret_window"],
        "probe_window": result["probe_window"],
        "window_times": result["window_times"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
