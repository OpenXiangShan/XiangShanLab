#!/usr/bin/env python3
import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path


VCD = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("poc_abtb_dcache_gadget_9700_10100.vcd")
ELF = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("poc_abtb_dcache_gadget.elf")
START_TIME = int(sys.argv[3]) if len(sys.argv) > 3 else 19400
END_TIME = int(sys.argv[4]) if len(sys.argv) > 4 else 20250


def load_symbols(path):
    out = subprocess.check_output(["/opt/riscv/bin/riscv64-unknown-elf-nm", "-n", str(path)], text=True)
    syms = {}
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 3:
            syms[parts[2]] = int(parts[0], 16)
    secret = syms["secret_data"]
    probe = syms["probe_array"]
    # The PoC sets secret_data to 7, and uses byte * 64 as the probe index.
    syms["probe_secret_line"] = probe + 7 * 64
    return syms


SYMS = load_symbols(ELF)
TARGETS = {
    "branch_site": SYMS["branch_site"],
    "fallthrough": SYMS["fallthrough"],
    "gadget": SYMS["gadget"],
    "train_data": SYMS["train_data"],
    "secret_data": SYMS["secret_data"],
    "flag_zero": SYMS["flag_zero"],
    "probe_array": SYMS["probe_array"],
    "probe_secret_line": SYMS["probe_secret_line"],
}


def h(value):
    if value is None:
        return None
    return hex(value)


def value_to_int(raw):
    if raw is None:
        return None
    if any(c in raw for c in "xzXZ"):
        return None
    if raw == "":
        return None
    return int(raw, 2)


def line_addr(addr, line_size=64):
    if addr is None:
        return None
    return addr & ~(line_size - 1)


def classes_for_addr(addr):
    if addr is None:
        return []
    out = []
    aliases = {addr}
    if addr >= 0x40000000:
        aliases.add(addr + 0x40000000)
    if addr >= 0x80000000:
        aliases.add(addr - 0x40000000)
    for name, target in TARGETS.items():
        if addr == target or target in aliases:
            out.append(name)
        elif line_addr(addr) == line_addr(target) or any(line_addr(a) == line_addr(target) for a in aliases):
            out.append(name + "_line")
    return sorted(set(out))


def pc_byte_addr(encoded_addr):
    if encoded_addr is None:
        return None
    return encoded_addr << 1


def classes_for_pc(encoded_addr):
    return classes_for_addr(pc_byte_addr(encoded_addr))


def parse_header(path):
    scopes = []
    code_to_names = {}
    name_to_code = {}
    header_end = 0
    with path.open() as f:
        for lineno, line in enumerate(f, 1):
            s = line.strip()
            if s.startswith("$scope"):
                p = s.split()
                scopes.append(p[2])
            elif s.startswith("$upscope"):
                scopes.pop()
            elif s.startswith("$var"):
                p = s.split()
                code = p[3]
                name = p[4]
                full = ".".join(scopes + [name])
                code_to_names.setdefault(code, []).append(full)
                name_to_code[full] = code
            elif s.startswith("$enddefinitions"):
                header_end = lineno
                break
    return header_end, code_to_names, name_to_code


def find_code(name_to_code, suffix):
    matches = [(name, code) for name, code in name_to_code.items() if name.endswith(suffix)]
    if not matches:
        raise KeyError(f"missing VCD signal suffix: {suffix}")
    return matches[0][1]


HEADER_END, CODE_NAMES, NAME_CODE = parse_header(VCD)

SIG = {
    "abtb_enable": find_code(NAME_CODE, ".core.frontend.io_csrCtrl_bp_ctrl_abtbEnable"),
    "pred_ready": find_code(NAME_CODE, ".core.frontend._inner_ftq_io_fromBpu_prediction_ready"),
    "pred_valid": find_code(NAME_CODE, ".core.frontend._inner_bpu_io_toFtq_prediction_valid"),
    "pred_start": find_code(NAME_CODE, ".core.frontend._inner_bpu_io_toFtq_prediction_bits_startPc_addr"),
    "pred_target": find_code(NAME_CODE, ".core.frontend._inner_bpu_io_toFtq_prediction_bits_target_addr"),
    "bpu_s2_valid": find_code(NAME_CODE, ".core.frontend.inner_bpu.s2_valid"),
    "bpu_s2_start": find_code(NAME_CODE, ".core.frontend.inner_bpu.s2_startPc_addr"),
    "abtb_s2_valid": find_code(NAME_CODE, ".core.frontend.inner_bpu.abtb.s2_valid"),
    "abtb_s2_start": find_code(NAME_CODE, ".core.frontend.inner_bpu.abtb.s2_startPc_addr"),
    "ftq_ic_req_ready": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_req_ready"),
    "ftq_ic_req_valid": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_req_valid"),
    "ftq_ic_req_start": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_req_bits_startVAddr_addr"),
    "ic_resp_valid": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_resp_valid"),
    "ic_resp_vaddr": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_resp_bits_vAddr_0_addr"),
    "ic_hit0": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_perf_rawHits_0"),
    "ic_hit1": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_perf_rawHits_1"),
    "ic_miss_ready": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_missReq_ready"),
    "ic_miss_valid": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_missReq_valid"),
    "ic_miss_blk": find_code(NAME_CODE, ".core.frontend.inner_icache.mainPipe.io_missReq_bits_blkPAddr"),
    "ic_outer_ready": find_code(NAME_CODE, ".core.frontend.auto_inner_icache_client_out_a_ready"),
    "ic_outer_valid": find_code(NAME_CODE, ".core.frontend.auto_inner_icache_client_out_a_valid"),
    "ic_outer_addr": find_code(NAME_CODE, ".core.frontend.auto_inner_icache_client_out_a_bits_address"),
    "dc_outer_ready": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_ready"),
    "dc_outer_valid": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_valid"),
    "dc_outer_addr": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_bits_address"),
    "dc_outer_vaddr": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr"),
    "dc_outer_opcode": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_bits_opcode"),
    "dc_outer_size": find_code(NAME_CODE, ".core.auto_memBlock_inner_dcache_client_out_a_bits_size"),
}

for unit in range(3):
    prefix = f".core.memBlock._inner_LoadUnit_{unit}_io_lqWrite"
    SIG[f"lu{unit}_valid"] = find_code(NAME_CODE, prefix + "_valid")
    SIG[f"lu{unit}_pc"] = find_code(NAME_CODE, prefix + "_bits_uop_pc")
    SIG[f"lu{unit}_vaddr"] = find_code(NAME_CODE, prefix + "_bits_vaddr")
    SIG[f"lu{unit}_paddr"] = find_code(NAME_CODE, prefix + "_bits_paddr")


WATCH_CODES = set(SIG.values())


def get(vals, name):
    return value_to_int(vals.get(SIG[name]))


def is_one(vals, name):
    return vals.get(SIG[name]) == "1"


counts = Counter()
first = {}
rows = {
    "stale_prediction": [],
    "icache_observable": [],
    "loadunit_data_dependent": [],
    "dcache_outer": [],
}


def add_count(name, event):
    counts[name] += 1
    first.setdefault(name, event)


def keep(bucket, row, limit=20):
    if len(rows[bucket]) < limit:
        rows[bucket].append(row)


def snapshot(t, vals):
    if t is None or t < START_TIME or t > END_TIME:
        return
    cycle = t // 2
    abtb_enabled = vals.get(SIG["abtb_enable"])
    pred_fire = is_one(vals, "pred_valid") and is_one(vals, "pred_ready")
    pred_start = get(vals, "pred_start")
    pred_target = get(vals, "pred_target")
    bpu_s2 = get(vals, "bpu_s2_start")
    abtb_s2 = get(vals, "abtb_s2_start")
    disabled_pred = pred_fire and abtb_enabled == "0" and is_one(vals, "abtb_s2_valid")
    pc_mismatch = disabled_pred and bpu_s2 is not None and abtb_s2 is not None and bpu_s2 != abtb_s2

    ic_req_fire = is_one(vals, "ftq_ic_req_valid") and is_one(vals, "ftq_ic_req_ready")
    ic_resp = is_one(vals, "ic_resp_valid")
    ic_hit = ic_resp and (is_one(vals, "ic_hit0") or is_one(vals, "ic_hit1"))
    ic_miss_fire = is_one(vals, "ic_miss_valid") and is_one(vals, "ic_miss_ready")
    ic_outer_fire = is_one(vals, "ic_outer_valid") and is_one(vals, "ic_outer_ready")

    if disabled_pred:
        event = {
            "t": t,
            "cycle": cycle,
            "abtb_enable": abtb_enabled,
            "bpu_s2_start": h(bpu_s2),
            "bpu_s2_start_byte": h(pc_byte_addr(bpu_s2)),
            "bpu_s2_start_class": classes_for_pc(bpu_s2),
            "abtb_s2_start": h(abtb_s2),
            "abtb_s2_start_byte": h(pc_byte_addr(abtb_s2)),
            "abtb_s2_start_class": classes_for_pc(abtb_s2),
            "pred_start": h(pred_start),
            "pred_start_byte": h(pc_byte_addr(pred_start)),
            "pred_start_class": classes_for_pc(pred_start),
            "pred_target": h(pred_target),
            "pred_target_byte": h(pc_byte_addr(pred_target)),
            "pred_target_class": classes_for_pc(pred_target),
            "ic_req_fire": ic_req_fire,
            "ic_req_start": h(get(vals, "ftq_ic_req_start")),
            "ic_req_start_byte": h(pc_byte_addr(get(vals, "ftq_ic_req_start"))),
            "ic_req_start_class": classes_for_pc(get(vals, "ftq_ic_req_start")),
            "ic_resp_valid": ic_resp,
            "ic_resp_vaddr": h(get(vals, "ic_resp_vaddr")),
            "ic_resp_vaddr_byte": h(pc_byte_addr(get(vals, "ic_resp_vaddr"))),
            "ic_resp_vaddr_class": classes_for_pc(get(vals, "ic_resp_vaddr")),
            "ic_hit": ic_hit,
        }
        add_count("disabled_abtb_prediction_fire", event)
        keep("stale_prediction", event)
        if pc_mismatch:
            add_count("disabled_abtb_pc_mismatch", event)
        if ic_req_fire or ic_resp:
            add_count("disabled_abtb_with_icache_activity", event)
            keep("icache_observable", event)

    if ic_req_fire:
        add_count("icache_fetch_req_fire", {"t": t, "cycle": cycle, "start": h(get(vals, "ftq_ic_req_start"))})
    if ic_resp:
        add_count("icache_resp_valid", {"t": t, "cycle": cycle, "vaddr": h(get(vals, "ic_resp_vaddr")), "hit": ic_hit})
    if ic_hit:
        add_count("icache_hit_resp", {"t": t, "cycle": cycle, "vaddr": h(get(vals, "ic_resp_vaddr"))})
    if ic_miss_fire:
        add_count("icache_miss_req_fire", {"t": t, "cycle": cycle, "blk": h(get(vals, "ic_miss_blk"))})
    if ic_outer_fire:
        add_count("icache_outer_a_fire", {"t": t, "cycle": cycle, "addr": h(get(vals, "ic_outer_addr"))})

    for unit in range(3):
        if is_one(vals, f"lu{unit}_valid"):
            pc = get(vals, f"lu{unit}_pc")
            paddr = get(vals, f"lu{unit}_paddr")
            vaddr = get(vals, f"lu{unit}_vaddr")
            cls = classes_for_addr(paddr) or classes_for_addr(vaddr)
            row = {
                "t": t,
                "cycle": cycle,
                "unit": unit,
                "pc": h(pc),
                "vaddr": h(vaddr),
                "paddr": h(paddr),
                "class": cls,
            }
            add_count("loadunit_lqwrite", row)
            if "secret_data" in cls:
                add_count("loadunit_secret_data", row)
                keep("loadunit_data_dependent", row)
            if "probe_secret_line" in cls:
                add_count("loadunit_probe_secret_line", row)
                keep("loadunit_data_dependent", row)
            if any(c.startswith("gadget") for c in classes_for_addr(pc)):
                add_count("loadunit_gadget_pc", row)

    if is_one(vals, "dc_outer_valid") and is_one(vals, "dc_outer_ready"):
        addr = get(vals, "dc_outer_addr")
        vaddr = get(vals, "dc_outer_vaddr")
        cls = classes_for_addr(addr) or classes_for_addr(vaddr)
        row = {
            "t": t,
            "cycle": cycle,
            "addr": h(addr),
            "vaddr": h(vaddr),
            "opcode": get(vals, "dc_outer_opcode"),
            "size": get(vals, "dc_outer_size"),
            "class": cls,
        }
        add_count("dcache_outer_a_fire", row)
        keep("dcache_outer", row)
        if "flag_zero" in cls:
            add_count("dcache_outer_flag_zero", row)
        if "probe_secret_line" in cls:
            add_count("dcache_outer_probe_secret_line", row)


vals = {}
current_time = None
scalar_re = re.compile(r"^([01xzXZ])(.+)$")

with VCD.open() as f:
    for _ in range(HEADER_END):
        next(f)
    for line in f:
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            snapshot(current_time, vals)
            current_time = int(line[1:])
            if current_time > END_TIME + 20:
                break
            continue
        if line[0] in "bB":
            parts = line.split(" ", 1)
            if len(parts) == 2 and parts[1] in WATCH_CODES:
                vals[parts[1]] = parts[0][1:]
        else:
            m = scalar_re.match(line)
            if m and m.group(2) in WATCH_CODES:
                vals[m.group(2)] = m.group(1)

snapshot(current_time, vals)

summary = {
    "vcd": str(VCD),
    "time_window": [START_TIME, END_TIME],
    "targets": {k: h(v) for k, v in TARGETS.items()},
    "counts": dict(sorted(counts.items())),
    "first": first,
    "rows": rows,
    "notes": [
        "probe_secret_line is probe_array + secret_data_byte(7) * 64.",
        "ICache proof here is L1 fetch request/response/hit activity; this run does not require an ICache outer miss.",
        "DCache outer A-channel to probe_secret_line is a data-dependent microarchitectural side channel, not an architectural wrong commit proof.",
    ],
}

print(json.dumps(summary, indent=2, sort_keys=True))
