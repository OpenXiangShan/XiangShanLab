#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU_VCD="${EMU_VCD:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

"$RISCV_GCC" \
  -march=rv64gc \
  -mabi=lp64 \
  -mcmodel=medany \
  -nostdlib \
  -nostartfiles \
  -T linker.ld \
  -Wl,--no-relax \
  -o poc.elf \
  poc.S
"$RISCV_OBJCOPY" -O binary poc.elf poc.bin
"$RISCV_OBJDUMP" -d -t poc.elf > poc.objdump

"$EMU_VCD" \
  --max-cycles=20000 \
  -b 8000 \
  -e 9500 \
  --dump-wave-full \
  --wave-path=stale_target.vcd \
  -i poc.bin \
  > stale_target.run.log 2>&1 || true

python3 parse_stale_target_vcd.py \
  stale_target.vcd \
  poc.objdump \
  stale_target.run.log \
  stale_target.monitor.json \
  > stale_target.monitor.log 2>&1
