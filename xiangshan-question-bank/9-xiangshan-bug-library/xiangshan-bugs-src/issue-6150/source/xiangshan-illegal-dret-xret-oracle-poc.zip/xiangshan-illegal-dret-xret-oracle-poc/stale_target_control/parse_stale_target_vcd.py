#!/usr/bin/env python3
import json
import re
import sys


SIGNALS = {
    "wb_valid": "io_fromWB_wbData_0_valid",
    "wb_ex2": "io_fromWB_wbData_0_bits_exceptionVec_2",
    "wb_redir_valid": "io_fromWB_wbData_0_bits_redirect_valid",
    "wb_redir_target": "io_fromWB_wbData_0_bits_redirect_bits_target",
    "wb_redir_fullTarget": "io_fromWB_wbData_0_bits_redirect_bits_fullTarget",
    "wb_redir_rob": "io_fromWB_wbData_0_bits_redirect_bits_robIdx_value",
    "wb_redir_igpf": "io_fromWB_wbData_0_bits_redirect_bits_backendIGPF",
    "wb_redir_ipf": "io_fromWB_wbData_0_bits_redirect_bits_backendIPF",
    "wb_redir_iaf": "io_fromWB_wbData_0_bits_redirect_bits_backendIAF",
    "stage2_valid": "io_stage2Redirect_valid",
    "stage2_target": "io_stage2Redirect_bits_target",
    "stage2_igpf": "io_stage2Redirect_bits_backendIGPF",
    "stage2_ipf": "io_stage2Redirect_bits_backendIPF",
    "stage2_iaf": "io_stage2Redirect_bits_backendIAF",
    "ftq_valid": "io_backend_toFtq_redirect_valid",
    "ftq_target": "io_backend_toFtq_redirect_bits_target",
    "ftq_igpf": "io_backend_toFtq_redirect_bits_backendIGPF",
    "ftq_ipf": "io_backend_toFtq_redirect_bits_backendIPF",
    "ftq_iaf": "io_backend_toFtq_redirect_bits_backendIAF",
    "ftq_to_ifu_valid": "_inner_ftq_io_toIfu_req_valid",
    "ftq_to_ifu_start": "_inner_ftq_io_toIfu_req_bits_fetch_0_startVAddr_addr",
    "ftq_to_icache_valid": "_inner_ftq_io_toICache_fetchReq_valid",
    "ftq_to_icache_start": "_inner_ftq_io_toICache_fetchReq_bits_startVAddr_addr",
    "icache_req_ready": "_inner_icache_io_fromFtq_fetchReq_ready",
    "icache_resp_valid": "_inner_icache_io_toIfu_fetchResp_valid",
    "icache_resp_vaddr": "_inner_icache_io_toIfu_fetchResp_bits_vAddr_0_addr",
    "dcache_a_ready": "auto_memBlock_inner_dcache_client_out_a_ready",
    "dcache_a_valid": "auto_memBlock_inner_dcache_client_out_a_valid",
    "dcache_a_opcode": "auto_memBlock_inner_dcache_client_out_a_bits_opcode",
    "dcache_a_addr": "auto_memBlock_inner_dcache_client_out_a_bits_address",
    "dcache_a_user_vaddr": "auto_memBlock_inner_dcache_client_out_a_bits_user_vaddr",
    "ls0_valid": "_memBlock_io_mem_to_ooo_lsTopdownInfo_0_s1_vaddr_valid",
    "ls0_vaddr": "_memBlock_io_mem_to_ooo_lsTopdownInfo_0_s1_vaddr_bits",
    "ls1_valid": "_memBlock_io_mem_to_ooo_lsTopdownInfo_1_s1_vaddr_valid",
    "ls1_vaddr": "_memBlock_io_mem_to_ooo_lsTopdownInfo_1_s1_vaddr_bits",
    "ls2_valid": "_memBlock_io_mem_to_ooo_lsTopdownInfo_2_s1_vaddr_valid",
    "ls2_vaddr": "_memBlock_io_mem_to_ooo_lsTopdownInfo_2_s1_vaddr_bits",
    "mem_wb0_valid": "_memBlock_io_mem_to_ooo_intWriteback_0_0_toRob_valid",
    "mem_wb0_vaddr": "_memBlock_io_mem_to_ooo_intWriteback_0_0_toRob_bits_debugInfo_vaddr",
    "mem_wb0_paddr": "_memBlock_io_mem_to_ooo_intWriteback_0_0_toRob_bits_debugInfo_paddr",
    "mem_wb0_rf_valid": "_memBlock_io_mem_to_ooo_intWriteback_0_0_toIntRf_valid",
    "mem_wb0_from_load": "_memBlock_io_mem_to_ooo_intWriteback_0_0_toIntRf_bits_isFromLoadUnit",
    "mem_wb1_valid": "_memBlock_io_mem_to_ooo_intWriteback_1_0_toRob_valid",
    "mem_wb1_vaddr": "_memBlock_io_mem_to_ooo_intWriteback_1_0_toRob_bits_debugInfo_vaddr",
    "mem_wb1_paddr": "_memBlock_io_mem_to_ooo_intWriteback_1_0_toRob_bits_debugInfo_paddr",
    "mem_wb1_rf_valid": "_memBlock_io_mem_to_ooo_intWriteback_1_0_toIntRf_valid",
    "mem_wb2_valid": "_memBlock_io_mem_to_ooo_intWriteback_2_0_toRob_valid",
    "mem_wb2_vaddr": "_memBlock_io_mem_to_ooo_intWriteback_2_0_toRob_bits_debugInfo_vaddr",
    "mem_wb2_paddr": "_memBlock_io_mem_to_ooo_intWriteback_2_0_toRob_bits_debugInfo_paddr",
    "mem_wb2_rf_valid": "_memBlock_io_mem_to_ooo_intWriteback_2_0_toIntRf_valid",
}

for i in range(8):
    SIGNALS[f"cf{i}_valid"] = f"_frontend_io_backend_cfVec_{i}_valid"
    SIGNALS[f"cf{i}_instr"] = f"_frontend_io_backend_cfVec_{i}_bits_instr"
    SIGNALS[f"cf{i}_pc"] = f"_frontend_io_backend_cfVec_{i}_bits_pc"
    SIGNALS[f"lsq{i}_req_valid"] = f"_backend_io_mem_lsqEnqIO_req_{i}_valid"
    SIGNALS[f"lsq{i}_req_instr"] = f"_backend_io_mem_lsqEnqIO_req_{i}_bits_instr"
    SIGNALS[f"lsq{i}_req_pc"] = f"_backend_io_mem_lsqEnqIO_req_{i}_bits_pc"


def parse_symbol(objdump, symbol):
    sym_re = re.compile(rf"^([0-9a-fA-F]+)\s+.+\s{re.escape(symbol)}$")
    label_re = re.compile(rf"^([0-9a-fA-F]+)\s+<{re.escape(symbol)}>:$")
    with open(objdump, "r", errors="ignore") as f:
        for line in f:
            m = sym_re.search(line.strip()) or label_re.search(line.strip())
            if m:
                return int(m.group(1), 16)
    raise SystemExit(f"could not find symbol {symbol} in {objdump}")


def parse_header(path):
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    found = {}
    names = {}
    with open(path, "r", errors="ignore") as f:
        for line in f:
            if "$enddefinitions" in line:
                break
            m = var_re.search(line)
            if not m:
                continue
            _, code, name = m.groups()
            base = name.split()[0]
            for key, suffix in SIGNALS.items():
                if base.endswith(suffix) or base == suffix:
                    if key not in found or len(base) < len(names[key]):
                        found[key] = code
                        names[key] = base
    missing = [key for key in SIGNALS if key not in found]
    if missing:
        raise SystemExit(f"missing VCD signals: {', '.join(missing)}")
    return found, names


def as_int(value):
    if value is None:
        return None
    if any(c in value.lower() for c in "xz"):
        return value
    return int(value, 2) if value else 0


def parse_vcd(path, code_by_key):
    key_by_code = {}
    for key, code in code_by_key.items():
        key_by_code.setdefault(code, []).append(key)
    values = {key: None for key in code_by_key}
    events = []
    time = 0
    past_header = False

    def snapshot():
        snap = {key: as_int(value) for key, value in values.items()}
        if not (
            snap.get("wb_valid") == 1
            or snap.get("wb_redir_valid") == 1
            or snap.get("stage2_valid") == 1
            or snap.get("ftq_valid") == 1
            or snap.get("ftq_to_ifu_valid") == 1
            or snap.get("ftq_to_icache_valid") == 1
            or snap.get("icache_resp_valid") == 1
            or snap.get("dcache_a_valid") == 1
            or snap.get("ls0_valid") == 1
            or snap.get("ls1_valid") == 1
            or snap.get("ls2_valid") == 1
            or snap.get("mem_wb0_valid") == 1
            or snap.get("mem_wb1_valid") == 1
            or snap.get("mem_wb2_valid") == 1
            or any(snap.get(f"cf{i}_valid") == 1 for i in range(8))
            or any(snap.get(f"lsq{i}_req_valid") == 1 for i in range(8))
        ):
            return
        rec = {"time": time}
        rec.update(snap)
        if not events or events[-1] != rec:
            events.append(rec)

    with open(path, "r", errors="ignore") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not past_header:
                if "$enddefinitions" in line:
                    past_header = True
                continue
            if not line:
                continue
            if line[0] == "#":
                time = int(line[1:])
                continue
            if line[0] in "01xz":
                code = line[1:]
                if code in key_by_code:
                    for key in key_by_code[code]:
                        values[key] = line[0]
                    snapshot()
            elif line[0] in "bB":
                parts = line.split()
                if len(parts) >= 2 and parts[1] in key_by_code:
                    for key in key_by_code[parts[1]]:
                        values[key] = parts[0][1:]
                    snapshot()
    return events


def zero_fault(event, prefix):
    return (
        event.get(f"{prefix}_igpf") == 0
        and event.get(f"{prefix}_ipf") == 0
        and event.get(f"{prefix}_iaf") == 0
    )


def line_base(addr, line_bytes=64):
    return addr & ~(line_bytes - 1)


def in_line(addr, target, line_bytes=64):
    if not isinstance(addr, int):
        return False
    return line_base(addr, line_bytes) == line_base(target, line_bytes)


def in_pruned_line(addr, target, line_bytes=64, inst_offset_bits=1):
    if not isinstance(addr, int):
        return False
    return in_line(addr << inst_offset_bits, target, line_bytes)


def in_range(addr, start, end):
    return isinstance(addr, int) and start <= addr < end


def main():
    if len(sys.argv) != 5:
        raise SystemExit(
            "usage: parse_stale_target_vcd.py <wave.vcd> <objdump> <run.log> <out.json>"
        )
    wave, objdump, run_log, out_json = sys.argv[1:]
    victim_entry = parse_symbol(objdump, "victim_entry")
    victim_attack_path = parse_symbol(objdump, "victim_attack_path")
    trap_handler = parse_symbol(objdump, "trap_handler")
    dret_site = parse_symbol(objdump, "dret_site")
    secret_byte = parse_symbol(objdump, "secret_byte")
    probe_array = parse_symbol(objdump, "probe_array")
    # Keep this in sync with poc.S: secret_byte contains 7 and the probe stride is 64.
    secret_value = 7
    probe_target = probe_array + secret_value * 64

    codes, names = parse_header(wave)
    events = parse_vcd(wave, codes)

    illegal_redirects = [
        e
        for e in events
        if e.get("wb_valid") == 1
        and e.get("wb_ex2") == 1
        and e.get("wb_redir_valid") == 1
    ]
    controlled_wb = [
        e
        for e in illegal_redirects
        if e.get("wb_redir_target") == victim_entry and zero_fault(e, "wb_redir")
    ]
    controlled_ftq = [
        e
        for e in events
        if e.get("ftq_valid") == 1
        and e.get("ftq_target") == victim_entry
        and zero_fault(e, "ftq")
    ]
    illegal_time = min((e["time"] for e in illegal_redirects), default=None)

    post_illegal_events = [
        e for e in events if illegal_time is not None and e["time"] >= illegal_time
    ]
    post_illegal_fetch_reqs = [
        e
        for e in post_illegal_events
        if (
            e.get("ftq_to_ifu_valid") == 1
            and in_pruned_line(e.get("ftq_to_ifu_start"), victim_entry)
        )
        or (
            e.get("ftq_to_icache_valid") == 1
            and e.get("icache_req_ready") == 1
            and in_pruned_line(e.get("ftq_to_icache_start"), victim_entry)
        )
    ]
    post_illegal_icache_resps = [
        e
        for e in post_illegal_events
        if e.get("icache_resp_valid") == 1 and in_pruned_line(e.get("icache_resp_vaddr"), victim_entry)
    ]
    frontend_cf_events = []
    for e in post_illegal_events:
        for idx in range(8):
            if e.get(f"cf{idx}_valid") == 1:
                rec = {
                    "port": idx,
                    "time": e["time"],
                    "pc": e.get(f"cf{idx}_pc"),
                    "instr": e.get(f"cf{idx}_instr"),
                }
                rec.update(e)
                frontend_cf_events.append(rec)
    victim_frontend_cf_events = [
        e for e in frontend_cf_events if in_range(e.get("pc"), victim_entry, trap_handler)
    ]
    victim_attack_frontend_cf_events = [
        e
        for e in frontend_cf_events
        if in_range(e.get("pc"), victim_attack_path, trap_handler)
    ]
    lsq_req_events = []
    for e in post_illegal_events:
        for idx in range(8):
            if e.get(f"lsq{idx}_req_valid") == 1:
                rec = {
                    "port": idx,
                    "time": e["time"],
                    "pc": e.get(f"lsq{idx}_req_pc"),
                    "instr": e.get(f"lsq{idx}_req_instr"),
                }
                rec.update(e)
                lsq_req_events.append(rec)
    victim_lsq_req_events = [
        e for e in lsq_req_events if in_range(e.get("pc"), victim_entry, trap_handler)
    ]
    secret_load_lsq_req_events = [
        e for e in lsq_req_events if e.get("pc") == victim_attack_path
    ]
    probe_load_lsq_req_events = [
        e for e in lsq_req_events if e.get("pc") == victim_attack_path + 12
    ]
    dcache_requests = [
        e
        for e in post_illegal_events
        if e.get("dcache_a_valid") == 1 and e.get("dcache_a_ready") == 1
    ]
    ls_vaddr_events = []
    for e in post_illegal_events:
        for idx in range(3):
            if e.get(f"ls{idx}_valid") == 1:
                rec = {"port": idx, "time": e["time"], "vaddr": e.get(f"ls{idx}_vaddr")}
                rec.update(e)
                ls_vaddr_events.append(rec)
    mem_wb_events = []
    for e in post_illegal_events:
        for idx in range(3):
            if e.get(f"mem_wb{idx}_valid") == 1:
                rec = {
                    "port": idx,
                    "time": e["time"],
                    "vaddr": e.get(f"mem_wb{idx}_vaddr"),
                    "paddr": e.get(f"mem_wb{idx}_paddr"),
                    "rf_valid": e.get(f"mem_wb{idx}_rf_valid"),
                }
                rec.update(e)
                mem_wb_events.append(rec)
    secret_dcache_requests = [
        e
        for e in dcache_requests
        if in_line(e.get("dcache_a_addr"), secret_byte)
        or in_line(e.get("dcache_a_user_vaddr"), secret_byte & ((1 << 44) - 1))
    ]
    probe_dcache_requests = [
        e
        for e in dcache_requests
        if in_line(e.get("dcache_a_addr"), probe_target)
        or in_line(e.get("dcache_a_user_vaddr"), probe_target & ((1 << 44) - 1))
    ]
    secret_ls_events = [e for e in ls_vaddr_events if in_line(e.get("vaddr"), secret_byte)]
    probe_ls_events = [e for e in ls_vaddr_events if in_line(e.get("vaddr"), probe_target)]
    secret_mem_wb_events = [
        e for e in mem_wb_events if in_line(e.get("vaddr"), secret_byte) or in_line(e.get("paddr"), secret_byte)
    ]
    probe_mem_wb_events = [
        e for e in mem_wb_events if in_line(e.get("vaddr"), probe_target) or in_line(e.get("paddr"), probe_target)
    ]

    with open(run_log, "r", errors="ignore") as f:
        log_tail = f.read()[-4096:]

    result = {
        "predicate_result": "reproduced" if controlled_wb and controlled_ftq else "not_reproduced",
        "fetch_side_effect_result": "reproduced" if post_illegal_fetch_reqs or post_illegal_icache_resps else "not_reproduced",
        "frontend_to_backend_result": "reproduced" if victim_frontend_cf_events else "not_reproduced",
        "backend_lsq_result": "reproduced" if victim_lsq_req_events else "not_reproduced",
        "data_side_effect_result": "reproduced"
        if (
            secret_dcache_requests
            or probe_dcache_requests
            or secret_ls_events
            or probe_ls_events
            or secret_mem_wb_events
            or probe_mem_wb_events
        )
        else "not_reproduced",
        "success_predicate": (
            "illegal DRET writeback raises EX_II and redirect_valid while the redirect target "
            "equals the earlier legal MRET target victim_entry, all backend fault bits are zero, "
            "and the same controlled redirect reaches backend-to-FTQ"
        ),
        "symbols": {
            "dret_site": dret_site,
            "probe_array": probe_array,
            "probe_target_for_secret_7": probe_target,
            "secret_byte": secret_byte,
            "victim_attack_path": victim_attack_path,
            "victim_entry": victim_entry,
            "victim_gadget_end": trap_handler,
        },
        "signals": names,
        "illegal_redirects": illegal_redirects,
        "controlled_wb_redirects": controlled_wb,
        "controlled_ftq_redirects": controlled_ftq,
        "post_illegal_fetch_reqs": post_illegal_fetch_reqs,
        "post_illegal_icache_resps": post_illegal_icache_resps,
        "post_illegal_frontend_cf_events": frontend_cf_events,
        "post_illegal_victim_frontend_cf_events": victim_frontend_cf_events,
        "post_illegal_victim_attack_frontend_cf_events": victim_attack_frontend_cf_events,
        "post_illegal_lsq_req_events": lsq_req_events,
        "post_illegal_victim_lsq_req_events": victim_lsq_req_events,
        "post_illegal_secret_load_lsq_req_events": secret_load_lsq_req_events,
        "post_illegal_probe_load_lsq_req_events": probe_load_lsq_req_events,
        "post_illegal_dcache_requests": dcache_requests,
        "post_illegal_ls_vaddr_events": ls_vaddr_events,
        "post_illegal_mem_wb_events": mem_wb_events,
        "secret_dcache_requests": secret_dcache_requests,
        "probe_dcache_requests": probe_dcache_requests,
        "secret_ls_events": secret_ls_events,
        "probe_ls_events": probe_ls_events,
        "secret_mem_wb_events": secret_mem_wb_events,
        "probe_mem_wb_events": probe_mem_wb_events,
        "run_log_tail": log_tail,
    }
    with open(out_json, "w") as f:
        json.dump(result, f, indent=2, sort_keys=True)

    print(json.dumps({
        "predicate_result": result["predicate_result"],
        "fetch_side_effect_result": result["fetch_side_effect_result"],
        "frontend_to_backend_result": result["frontend_to_backend_result"],
        "backend_lsq_result": result["backend_lsq_result"],
        "data_side_effect_result": result["data_side_effect_result"],
        "victim_entry": hex(victim_entry),
        "victim_attack_path": hex(victim_attack_path),
        "victim_gadget_end": hex(trap_handler),
        "dret_site": hex(dret_site),
        "secret_byte": hex(secret_byte),
        "probe_target_for_secret_7": hex(probe_target),
        "illegal_redirect_count": len(illegal_redirects),
        "controlled_wb_count": len(controlled_wb),
        "controlled_ftq_count": len(controlled_ftq),
        "post_illegal_fetch_req_count": len(post_illegal_fetch_reqs),
        "post_illegal_icache_resp_count": len(post_illegal_icache_resps),
        "post_illegal_victim_frontend_cf_count": len(victim_frontend_cf_events),
        "post_illegal_victim_attack_frontend_cf_count": len(victim_attack_frontend_cf_events),
        "post_illegal_victim_lsq_req_count": len(victim_lsq_req_events),
        "post_illegal_secret_load_lsq_req_count": len(secret_load_lsq_req_events),
        "post_illegal_probe_load_lsq_req_count": len(probe_load_lsq_req_events),
        "secret_dcache_request_count": len(secret_dcache_requests),
        "probe_dcache_request_count": len(probe_dcache_requests),
        "secret_ls_event_count": len(secret_ls_events),
        "probe_ls_event_count": len(probe_ls_events),
        "secret_mem_wb_event_count": len(secret_mem_wb_events),
        "probe_mem_wb_event_count": len(probe_mem_wb_events),
        "first_controlled_wb": controlled_wb[:1],
        "first_controlled_ftq": controlled_ftq[:1],
        "first_post_illegal_fetch_req": post_illegal_fetch_reqs[:1],
        "first_post_illegal_victim_frontend_cf": victim_frontend_cf_events[:1],
        "first_post_illegal_victim_attack_frontend_cf": victim_attack_frontend_cf_events[:1],
        "first_post_illegal_victim_lsq_req": victim_lsq_req_events[:1],
        "first_post_illegal_secret_load_lsq_req": secret_load_lsq_req_events[:1],
        "first_post_illegal_probe_load_lsq_req": probe_load_lsq_req_events[:1],
        "first_secret_dcache_request": secret_dcache_requests[:1],
        "first_probe_dcache_request": probe_dcache_requests[:1],
        "first_secret_ls_event": secret_ls_events[:1],
        "first_probe_ls_event": probe_ls_events[:1],
        "first_secret_mem_wb_event": secret_mem_wb_events[:1],
        "first_probe_mem_wb_event": probe_mem_wb_events[:1],
    }, indent=2, sort_keys=True))
    if result["predicate_result"] != "reproduced":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
