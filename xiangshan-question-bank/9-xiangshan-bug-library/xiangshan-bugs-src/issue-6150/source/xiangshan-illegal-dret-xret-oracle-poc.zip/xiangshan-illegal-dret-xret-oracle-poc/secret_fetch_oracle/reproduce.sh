#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

RISCV_GCC="${RISCV_GCC:-/opt/riscv/bin/riscv64-unknown-elf-gcc}"
RISCV_OBJCOPY="${RISCV_OBJCOPY:-/opt/riscv/bin/riscv64-unknown-elf-objcopy}"
RISCV_OBJDUMP="${RISCV_OBJDUMP:-/opt/riscv/bin/riscv64-unknown-elf-objdump}"
EMU_VCD="${EMU_VCD:-/root/HardwareAgent/XiangShan/build_vcd/emu}"

for secret in 0 1; do
  "$RISCV_GCC" \
    -march=rv64gc \
    -mabi=lp64 \
    -mcmodel=medany \
    -nostdlib \
    -nostartfiles \
    -T linker.ld \
    -Wl,--no-relax \
    -DSECRET_VALUE="${secret}" \
    -o "poc_secret${secret}.elf" \
    poc.S
  "$RISCV_OBJCOPY" -O binary "poc_secret${secret}.elf" "poc_secret${secret}.bin"
  "$RISCV_OBJDUMP" -d -t "poc_secret${secret}.elf" > "poc_secret${secret}.objdump"

  "$EMU_VCD" \
    --max-cycles=20000 \
    -b 8000 \
    -e 9800 \
    --dump-wave-full \
    --wave-path="secret${secret}.vcd" \
    -i "poc_secret${secret}.bin" \
    > "secret${secret}.run.log" 2>&1 || true

  python3 parse_fetch_oracle_vcd.py \
    "secret${secret}.vcd" \
    "poc_secret${secret}.objdump" \
    "secret${secret}.run.log" \
    "secret${secret}.monitor.json" \
    "${secret}" \
    > "secret${secret}.monitor.log" 2>&1
done

python3 compare_fetch_oracle.py secret0.monitor.json secret1.monitor.json > comparison.log
