#!/usr/bin/env python3
import json
import sys


def load(path):
    with open(path) as f:
        return json.load(f)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: compare_fetch_oracle.py <secret0.json> <secret1.json>")
    a = load(sys.argv[1])
    b = load(sys.argv[2])
    ok = (
        a["expected_secret"] == 0
        and b["expected_secret"] == 1
        and a["predicate_result"] == "reproduced"
        and b["predicate_result"] == "reproduced"
        and a["fetch_oracle_result"] == "reproduced"
        and b["fetch_oracle_result"] == "reproduced"
        and a["selected_target"] == a["symbols"]["leak_target0"]
        and b["selected_target"] == b["symbols"]["leak_target1"]
        and a["selected_target"] != b["selected_target"]
    )
    summary = {
        "cross_variant_secret_oracle": "reproduced" if ok else "not_reproduced",
        "secret0_selected_target": hex(a["selected_target"]),
        "secret0_selected_fetch_oracle_count": len(a["selected_fetches_oracle_window"]),
        "secret0_unselected_fetch_oracle_count": len(a["unselected_fetches_oracle_window"]),
        "secret0_selected_refill_oracle_count": len(a["selected_icache_refills_oracle_window"]),
        "secret0_unselected_refill_oracle_count": len(a["unselected_icache_refills_oracle_window"]),
        "secret1_selected_target": hex(b["selected_target"]),
        "secret1_selected_fetch_oracle_count": len(b["selected_fetches_oracle_window"]),
        "secret1_unselected_fetch_oracle_count": len(b["unselected_fetches_oracle_window"]),
        "secret1_selected_refill_oracle_count": len(b["selected_icache_refills_oracle_window"]),
        "secret1_unselected_refill_oracle_count": len(b["unselected_icache_refills_oracle_window"]),
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
