#!/usr/bin/env python3
import json
import re
import sys


SIGNALS = {
    "wb_valid": "io_fromWB_wbData_0_valid",
    "wb_ex2": "io_fromWB_wbData_0_bits_exceptionVec_2",
    "wb_redir_valid": "io_fromWB_wbData_0_bits_redirect_valid",
    "wb_redir_target": "io_fromWB_wbData_0_bits_redirect_bits_target",
    "wb_redir_fullTarget": "io_fromWB_wbData_0_bits_redirect_bits_fullTarget",
    "wb_redir_igpf": "io_fromWB_wbData_0_bits_redirect_bits_backendIGPF",
    "wb_redir_ipf": "io_fromWB_wbData_0_bits_redirect_bits_backendIPF",
    "wb_redir_iaf": "io_fromWB_wbData_0_bits_redirect_bits_backendIAF",
    "ftq_valid": "io_backend_toFtq_redirect_valid",
    "ftq_target": "io_backend_toFtq_redirect_bits_target",
    "ftq_igpf": "io_backend_toFtq_redirect_bits_backendIGPF",
    "ftq_ipf": "io_backend_toFtq_redirect_bits_backendIPF",
    "ftq_iaf": "io_backend_toFtq_redirect_bits_backendIAF",
    "ftq_to_ifu_valid": "_inner_ftq_io_toIfu_req_valid",
    "ftq_to_ifu_start": "_inner_ftq_io_toIfu_req_bits_fetch_0_startVAddr_addr",
    "ftq_to_icache_valid": "_inner_ftq_io_toICache_fetchReq_valid",
    "ftq_to_icache_start": "_inner_ftq_io_toICache_fetchReq_bits_startVAddr_addr",
    "icache_req_ready": "_inner_icache_io_fromFtq_fetchReq_ready",
    "icache_resp_valid": "_inner_icache_io_toIfu_fetchResp_valid",
    "icache_resp_vaddr": "_inner_icache_io_toIfu_fetchResp_bits_vAddr_0_addr",
    "icache_client_a_valid": "_frontend_auto_inner_icache_client_out_a_valid",
    "icache_client_a_addr": "_frontend_auto_inner_icache_client_out_a_bits_address",
}

for i in range(8):
    SIGNALS[f"cf{i}_valid"] = f"_frontend_io_backend_cfVec_{i}_valid"
    SIGNALS[f"cf{i}_pc"] = f"_frontend_io_backend_cfVec_{i}_bits_pc"
for i in range(8):
    SIGNALS[f"lsq{i}_valid"] = f"_backend_io_mem_lsqEnqIO_req_{i}_valid"
    SIGNALS[f"lsq{i}_pc"] = f"_backend_io_mem_lsqEnqIO_req_{i}_bits_pc"


def parse_symbol(objdump, symbol):
    sym_re = re.compile(rf"^([0-9a-fA-F]+)\s+.+\s{re.escape(symbol)}$")
    label_re = re.compile(rf"^([0-9a-fA-F]+)\s+<{re.escape(symbol)}>:$")
    with open(objdump, "r", errors="ignore") as f:
        for line in f:
            m = sym_re.search(line.strip()) or label_re.search(line.strip())
            if m:
                return int(m.group(1), 16)
    raise SystemExit(f"could not find symbol {symbol} in {objdump}")


def parse_header(path):
    var_re = re.compile(r"\$var\s+\S+\s+(\d+)\s+(\S+)\s+(.+?)\s+\$end")
    found = {}
    names = {}
    with open(path, "r", errors="ignore") as f:
        for line in f:
            if "$enddefinitions" in line:
                break
            m = var_re.search(line)
            if not m:
                continue
            _, code, name = m.groups()
            base = name.split()[0]
            for key, suffix in SIGNALS.items():
                if base.endswith(suffix) or base == suffix:
                    if key not in found or len(base) < len(names[key]):
                        found[key] = code
                        names[key] = base
    missing = [key for key in SIGNALS if key not in found]
    if missing:
        raise SystemExit(f"missing VCD signals: {', '.join(missing)}")
    return found, names


def as_int(value):
    if value is None:
        return None
    if any(c in value.lower() for c in "xz"):
        return value
    return int(value, 2) if value else 0


def parse_vcd(path, code_by_key):
    key_by_code = {}
    for key, code in code_by_key.items():
        key_by_code.setdefault(code, []).append(key)
    values = {key: None for key in code_by_key}
    events = []
    time = 0
    past_header = False

    def snapshot():
        snap = {key: as_int(value) for key, value in values.items()}
        if not (
            snap.get("wb_valid") == 1
            or snap.get("wb_redir_valid") == 1
            or snap.get("ftq_valid") == 1
            or snap.get("ftq_to_ifu_valid") == 1
            or snap.get("ftq_to_icache_valid") == 1
            or snap.get("icache_resp_valid") == 1
            or snap.get("icache_client_a_valid") == 1
            or any(snap.get(f"cf{i}_valid") == 1 for i in range(8))
            or any(snap.get(f"lsq{i}_valid") == 1 for i in range(8))
        ):
            return
        rec = {"time": time}
        rec.update(snap)
        if not events or events[-1] != rec:
            events.append(rec)

    with open(path, "r", errors="ignore") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not past_header:
                if "$enddefinitions" in line:
                    past_header = True
                continue
            if not line:
                continue
            if line[0] == "#":
                time = int(line[1:])
                continue
            if line[0] in "01xz":
                code = line[1:]
                if code in key_by_code:
                    for key in key_by_code[code]:
                        values[key] = line[0]
                    snapshot()
            elif line[0] in "bB":
                parts = line.split()
                if len(parts) >= 2 and parts[1] in key_by_code:
                    for key in key_by_code[parts[1]]:
                        values[key] = parts[0][1:]
                    snapshot()
    return events


def zero_fault(event, prefix):
    return (
        event.get(f"{prefix}_igpf") == 0
        and event.get(f"{prefix}_ipf") == 0
        and event.get(f"{prefix}_iaf") == 0
    )


def line_base(addr, line_bytes=64):
    return addr & ~(line_bytes - 1)


def in_line(addr, target, line_bytes=64):
    return isinstance(addr, int) and line_base(addr, line_bytes) == line_base(target, line_bytes)


def in_pruned_line(addr, target, line_bytes=64, inst_offset_bits=1):
    return isinstance(addr, int) and in_line(addr << inst_offset_bits, target, line_bytes)


def in_range(addr, start, end):
    return isinstance(addr, int) and start <= addr < end


def matches_target_fetch(event, target):
    return (
        event.get("ftq_to_ifu_valid") == 1
        and in_pruned_line(event.get("ftq_to_ifu_start"), target)
    ) or (
        event.get("ftq_to_icache_valid") == 1
        and event.get("icache_req_ready") == 1
        and in_pruned_line(event.get("ftq_to_icache_start"), target)
    )


def matches_target_icache_resp(event, target):
    return event.get("icache_resp_valid") == 1 and in_pruned_line(event.get("icache_resp_vaddr"), target)


def matches_target_refill(event, target):
    return event.get("icache_client_a_valid") == 1 and in_line(event.get("icache_client_a_addr"), target)


def main():
    if len(sys.argv) != 6:
        raise SystemExit(
            "usage: parse_fetch_oracle_vcd.py <wave.vcd> <objdump> <run.log> <out.json> <expected-secret-bit>"
        )

    wave, objdump, run_log, out_json, expected_s = sys.argv[1:]
    expected_secret = int(expected_s, 0)
    if expected_secret not in (0, 1):
        raise SystemExit("expected-secret-bit must be 0 or 1")

    target0 = parse_symbol(objdump, "leak_target0")
    target1 = parse_symbol(objdump, "leak_target1")
    selected = target1 if expected_secret else target0
    unselected = target0 if expected_secret else target1
    dret_site = parse_symbol(objdump, "dret_site")
    after_dret = parse_symbol(objdump, "after_dret")
    trap_handler = parse_symbol(objdump, "trap_handler")

    codes, names = parse_header(wave)
    events = parse_vcd(wave, codes)
    illegal_redirects = [
        e
        for e in events
        if e.get("wb_valid") == 1 and e.get("wb_ex2") == 1 and e.get("wb_redir_valid") == 1
    ]
    selected_wb = [
        e
        for e in illegal_redirects
        if e.get("wb_redir_target") == selected and zero_fault(e, "wb_redir")
    ]
    selected_ftq = [
        e
        for e in events
        if e.get("ftq_valid") == 1
        and e.get("ftq_target") == selected
        and zero_fault(e, "ftq")
    ]
    illegal_time = min((e["time"] for e in illegal_redirects), default=None)
    post = [e for e in events if illegal_time is not None and e["time"] >= illegal_time]
    oracle_window = 64
    oracle_post = [
        e for e in post if illegal_time is not None and e["time"] <= illegal_time + oracle_window
    ]
    selected_ftq_post = [e for e in selected_ftq if illegal_time is not None and e["time"] >= illegal_time]

    selected_fetches = [e for e in post if matches_target_fetch(e, selected)]
    unselected_fetches = [e for e in post if matches_target_fetch(e, unselected)]
    selected_resps = [e for e in post if matches_target_icache_resp(e, selected)]
    unselected_resps = [e for e in post if matches_target_icache_resp(e, unselected)]
    selected_refills = [e for e in post if matches_target_refill(e, selected)]
    unselected_refills = [e for e in post if matches_target_refill(e, unselected)]
    selected_fetches_oracle = [e for e in oracle_post if matches_target_fetch(e, selected)]
    unselected_fetches_oracle = [e for e in oracle_post if matches_target_fetch(e, unselected)]
    selected_resps_oracle = [e for e in oracle_post if matches_target_icache_resp(e, selected)]
    unselected_resps_oracle = [e for e in oracle_post if matches_target_icache_resp(e, unselected)]
    selected_refills_oracle = [e for e in oracle_post if matches_target_refill(e, selected)]
    unselected_refills_oracle = [e for e in oracle_post if matches_target_refill(e, unselected)]

    cf_selected = []
    lsq_selected = []
    for e in post:
        for idx in range(8):
            if e.get(f"cf{idx}_valid") == 1 and in_range(e.get(f"cf{idx}_pc"), selected, selected + 4):
                cf_selected.append({"time": e["time"], "port": idx, "pc": e.get(f"cf{idx}_pc")})
            if e.get(f"lsq{idx}_valid") == 1 and in_range(e.get(f"lsq{idx}_pc"), selected, selected + 4):
                lsq_selected.append({"time": e["time"], "port": idx, "pc": e.get(f"lsq{idx}_pc")})

    with open(run_log, "r", errors="ignore") as f:
        log_tail = f.read()[-4096:]

    leakage_reproduced = bool(
        selected_wb
        and selected_ftq_post
        and (selected_fetches_oracle or selected_resps_oracle or selected_refills_oracle)
    )
    isolation_ok = (
        not unselected_fetches_oracle
        and not unselected_resps_oracle
        and not unselected_refills_oracle
    )
    result = {
        "expected_secret": expected_secret,
        "predicate_result": "reproduced" if selected_wb and selected_ftq_post else "not_reproduced",
        "fetch_oracle_result": "reproduced" if leakage_reproduced and isolation_ok else "not_reproduced",
        "oracle_window_after_illegal_time": oracle_window,
        "selected_target": selected,
        "unselected_target": unselected,
        "symbols": {
            "after_dret": after_dret,
            "dret_site": dret_site,
            "leak_target0": target0,
            "leak_target1": target1,
            "trap_handler": trap_handler,
        },
        "signals": names,
        "illegal_redirects": illegal_redirects,
        "selected_wb_redirects": selected_wb,
        "selected_ftq_redirects": selected_ftq,
        "selected_ftq_redirects_post_illegal": selected_ftq_post,
        "selected_fetches": selected_fetches,
        "unselected_fetches": unselected_fetches,
        "selected_icache_resps": selected_resps,
        "unselected_icache_resps": unselected_resps,
        "selected_icache_refills": selected_refills,
        "unselected_icache_refills": unselected_refills,
        "selected_fetches_oracle_window": selected_fetches_oracle,
        "unselected_fetches_oracle_window": unselected_fetches_oracle,
        "selected_icache_resps_oracle_window": selected_resps_oracle,
        "unselected_icache_resps_oracle_window": unselected_resps_oracle,
        "selected_icache_refills_oracle_window": selected_refills_oracle,
        "unselected_icache_refills_oracle_window": unselected_refills_oracle,
        "selected_cf_events": cf_selected,
        "selected_lsq_events": lsq_selected,
        "run_log_tail": log_tail,
    }
    with open(out_json, "w") as f:
        json.dump(result, f, indent=2, sort_keys=True)

    summary = {
        "expected_secret": expected_secret,
        "predicate_result": result["predicate_result"],
        "fetch_oracle_result": result["fetch_oracle_result"],
        "selected_target": hex(selected),
        "unselected_target": hex(unselected),
        "illegal_redirect_count": len(illegal_redirects),
        "selected_wb_count": len(selected_wb),
        "selected_ftq_count": len(selected_ftq_post),
        "selected_fetch_count": len(selected_fetches),
        "unselected_fetch_count": len(unselected_fetches),
        "selected_icache_resp_count": len(selected_resps),
        "unselected_icache_resp_count": len(unselected_resps),
        "selected_icache_refill_count": len(selected_refills),
        "unselected_icache_refill_count": len(unselected_refills),
        "oracle_window_after_illegal_time": oracle_window,
        "selected_fetch_oracle_count": len(selected_fetches_oracle),
        "unselected_fetch_oracle_count": len(unselected_fetches_oracle),
        "selected_icache_resp_oracle_count": len(selected_resps_oracle),
        "unselected_icache_resp_oracle_count": len(unselected_resps_oracle),
        "selected_icache_refill_oracle_count": len(selected_refills_oracle),
        "unselected_icache_refill_oracle_count": len(unselected_refills_oracle),
        "selected_cf_count": len(cf_selected),
        "selected_lsq_count": len(lsq_selected),
        "first_selected_wb": selected_wb[:1],
        "first_selected_ftq": selected_ftq_post[:1],
        "first_selected_fetch": selected_fetches_oracle[:1],
        "first_selected_icache_resp": selected_resps_oracle[:1],
        "first_selected_icache_refill": selected_refills_oracle[:1],
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    if result["predicate_result"] != "reproduced" or result["fetch_oracle_result"] != "reproduced":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
